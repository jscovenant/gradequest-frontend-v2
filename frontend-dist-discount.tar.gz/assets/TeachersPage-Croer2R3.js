import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{p as t}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as n,E as r,P as i,R as a,d as o,f as ee,l as te,u as ne}from"./index-D6TxbaCx.js";import{t as re}from"./PeopleImportPanel-CHz9v6Iy.js";var s=e(),c=t(),l=e=>e?e.charAt(0).toUpperCase()+e.slice(1).toLowerCase():``,u=e=>[l(e?.firstname),l(e?.surname)].filter(Boolean).join(` `).trim(),ie=e=>((e?.firstname||``).trim().charAt(0).toUpperCase()+(e?.surname||``).trim().charAt(0).toUpperCase()).trim()||`T`;function ae(){let e=new Date().getHours();return e<12?`Good morning`:e<17?`Good afternoon`:`Good evening`}function d(e){return String(e)===`1`||e===1||String(e).toLowerCase()===`active`}var oe=[{value:`active`,label:`Active`,hint:`Can log in and work`},{value:`suspended`,label:`Suspended`,hint:`Temporarily blocked`},{value:`inactive`,label:`Inactive`,hint:`Hidden from normal work`},{value:`resigned`,label:`Resigned`,hint:`No longer with school`},{value:`all`,label:`All`,hint:`Show every teacher`}],f=e=>{let t=String(e?.teacher_status||``).toLowerCase();return[`active`,`suspended`,`inactive`,`resigned`].includes(t)?t:d(e?.status)?`active`:`inactive`},p=e=>{let t=String(e||`active`).toLowerCase();return t===`suspended`?`Suspended`:t===`inactive`?`Inactive`:t===`resigned`?`Resigned`:`Active`},se=e=>{let t=String(e||`active`).toLowerCase();return t===`suspended`?`db-pill--warn`:t===`inactive`?`db-pill--no`:t===`resigned`?`db-pill--info`:`db-pill--ok`};function m(){let{showSuccess:e,showError:t}=te(),[l,d]=(0,s.useState)(!1),[m,ce]=(0,s.useState)([]),[h,le]=(0,s.useState)(``),[g,_]=(0,s.useState)(1),[ue]=(0,s.useState)(8),[v,de]=(0,s.useState)(1),[y,b]=(0,s.useState)(!1),[x,fe]=(0,s.useState)(!1),[S,pe]=(0,s.useState)(`active`),[C,me]=(0,s.useState)({active:0,suspended:0,inactive:0,resigned:0}),[he,ge]=(0,s.useState)(null),[_e,ve]=(0,s.useState)([]),[w,T]=(0,s.useState)(null),[E,D]=(0,s.useState)(null),[O,k]=(0,s.useState)(!1),[A,ye]=(0,s.useState)(!1),[j,M]=(0,s.useState)(!1),[N,P]=(0,s.useState)({}),[be,F]=(0,s.useState)(null),[xe,I]=(0,s.useState)(``),[L,R]=(0,s.useState)(``),[z,B]=(0,s.useState)(!1),[V,H]=(0,s.useState)(`overview`),[Se,U]=(0,s.useState)(!1),[W,Ce]=(0,s.useState)(!1),[G,K]=(0,s.useState)({firstname:``,surname:``,email:``,phone:``,sex:``,dob:``,address:``,username:``,level_id:``}),[we,Te]=(0,s.useState)(null),[Ee,De]=(0,s.useState)(``),q=e=>a(e,`/media/profile.jpg`),J=async()=>{b(!0);try{let e=await i.get(`/all-teachers`,{params:{page:g,perPage:ue,search:h,teacher_status:S}}),t=e.data.teachers;ce(t.data||t),de(t.last_page||1),me({active:Number(e.data.status_counts?.active||0),suspended:Number(e.data.status_counts?.suspended||0),inactive:Number(e.data.status_counts?.inactive||0),resigned:Number(e.data.status_counts?.resigned||0)})}catch(e){console.error(e),t(e?.response?.data?.message??`Failed to load teachers`)}finally{b(!1)}},Oe=async()=>{try{let e=await i.get(`/levels`);ve(e.data.levels||e.data||[])}catch{ve([])}};(0,s.useEffect)(()=>{J()},[g,h,S]),(0,s.useEffect)(()=>{Oe()},[]);let ke=async e=>{T(e),k(!0),M(!1),P({}),F(null),I(``),B(!1),R(``),H(`overview`);try{let t=await i.get(`/teachers/view/${e.id}`);D(t.data),R(t.data.decrypted_password||``)}catch(e){console.error(e),t(e?.response?.data?.message??`Failed to load teacher profile`),T(null)}finally{k(!1)}},Y=()=>{T(null),D(null),M(!1),P({}),F(null),I(``),B(!1),R(``),H(`overview`)},Ae=async()=>{if(w){k(!0),H(`overview`);try{let e=await i.get(`/teachers/edit/${w.id}`),t=e.data.teacher;M(!0),D(e=>({...e||{},teacher:t})),P({firstname:t.firstname||``,surname:t.surname||``,email:t.email||``,phone:t.phone||``,dob:t.dob||``,sex:t.sex||``,address:t.address||``,level_id:e.data.level_id??t.teacher_enrollment?.level_id??``,password:``}),I(e.data.photo_url||q(t.photo))}catch(e){console.error(e),t(e?.response?.data?.message??`Failed to fetch teacher for edit`)}finally{k(!1)}}},je=()=>{M(!1),P({}),F(null),I(``)},Me=e=>{let t=e.target.files?.[0];if(!t)return;F(t);let n=new FileReader;n.onloadend=()=>I(n.result),n.readAsDataURL(t)},Ne=async()=>{if(w){ye(!0);try{let t=new FormData;Object.entries(N).forEach(([e,n])=>{n!=null&&t.append(e,n)}),be&&t.append(`photo`,be),t.append(`_method`,`PUT`);let n=await i.post(`/teachers/${w.id}`,t,{headers:{"Content-Type":`multipart/form-data`}});e(n.data.message||`Teacher updated successfully!`),await J(),n.data?.teacher&&(D(e=>({...e||{},teacher:n.data.teacher})),T(n.data.teacher)),R(n.data?.decrypted_password||``),B(!!n.data?.password_updated),n.data?.password_updated&&H(`security`),M(!1),F(null),I(``)}catch(e){console.error(e),t(e?.response?.data?.message||`Failed to update teacher`)}finally{ye(!1)}}},Pe=async n=>{if(window.confirm(`Delete ${u(n)}?`)){b(!0);try{await i.delete(`/teachers/${n.id}`),e(`Teacher deleted successfully`),J()}catch(e){console.error(e),t(e?.response?.data?.message||`Failed to delete teacher`)}finally{b(!1)}}},Fe=async(n,r)=>{if(f(n)===r)return;let a=null;if(!(r!==`active`&&(a=window.prompt(`Reason for marking ${u(n)||`this teacher`} as ${p(r)}?`),a===null))&&window.confirm(`Confirm ${p(r)} for ${u(n)||`this teacher`}?`)){ge(n.id);try{let t=await i.patch(`/teachers/${n.id}/lifecycle-status`,{teacher_status:r,reason:a}),o=t.data.teacher||{...n,teacher_status:r};e(t.data.message||`Teacher status updated successfully.`),await J(),w?.id===n.id&&(T(o),D(e=>e&&{...e,teacher:o}))}catch(e){console.error(e),t(e?.response?.data?.message||`Could not update teacher status`)}finally{ge(null)}}},Ie=()=>{K({firstname:``,surname:``,email:``,phone:``,sex:``,dob:``,address:``,username:``,level_id:``}),Te(null),De(``),U(!0)},X=()=>{W||U(!1)},Le=e=>{let t=e.target.files?.[0];if(!t)return;Te(t);let n=new FileReader;n.onloadend=()=>De(n.result),n.readAsDataURL(t)},Re=async()=>{if(!G.firstname.trim())return t(`First name is required`);if(!G.surname.trim())return t(`Surname is required`);if(!G.level_id)return t(`Please select a class (level)`);Ce(!0);try{let t=new FormData;t.append(`firstname`,G.firstname.trim()),t.append(`surname`,G.surname.trim()),t.append(`role`,`Teacher`),t.append(`level_id`,String(G.level_id)),G.email&&t.append(`email`,G.email),G.phone&&t.append(`phone`,G.phone),G.sex&&t.append(`sex`,G.sex),G.dob&&t.append(`dob`,G.dob),G.address&&t.append(`address`,G.address),G.username&&t.append(`username`,G.username),we&&t.append(`photo`,we);let n=await i.post(`/register-teacher`,t,{headers:{"Content-Type":`multipart/form-data`}});e(n.data.message||`Teacher registered successfully!`),U(!1),_(1),await J();let r=n.data.user;r?.id&&ke(r)}catch(e){console.error(e),t(e?.response?.data?.message||`Failed to register teacher`)}finally{Ce(!1)}},ze=m?.length??0,Z=C.active,Q=C.suspended,$=C.inactive,Be=C.resigned;return(0,c.jsxs)(c.Fragment,{children:[(0,c.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');

        .db-main {
          background: #F8FAFC;
          min-height: 100vh;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          padding: 24px 28px 40px;
          width: 100%;
          max-width: 100%;
        }

        @media (max-width: 767.98px) {
          .db-main {
            padding: 16px 12px 32px !important;
          }
        }

        .db-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 18px;
          padding: 32px 36px;
          position: relative;
          overflow: hidden;
          margin-bottom: 24px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
        }

        @media (max-width: 767.98px) {
          .db-hero {
            padding: 20px 18px !important;
            border-radius: 14px !important;
            margin-bottom: 16px !important;
          }
        }

        .db-hero-glow {
          position: absolute;
          top: -60px;
          right: -60px;
          width: 320px;
          height: 320px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.15) 0%, transparent 65%);
          pointer-events: none;
        }

        .db-hero-glow2 {
          position: absolute;
          bottom: -40px;
          left: 25%;
          width: 220px;
          height: 220px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(37, 99, 235, 0.10) 0%, transparent 70%);
          pointer-events: none;
        }

        .db-hero-inner {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: 24px;
          flex-wrap: wrap;
        }

        .db-session-badge {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.20);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius: 999px;
          padding: 4px 12px;
          margin-bottom: 12px;
        }

        .db-session-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #10B981;
          animation: dbPulse 2s ease infinite;
        }

        @keyframes dbPulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: .4; transform: scale(1.5); }
        }

        .db-greeting {
          font-size: 26px;
          font-weight: 800;
          color: #fff;
          line-height: 1.1;
          margin-bottom: 8px;
        }

        .db-greeting em {
          font-style: normal;
          color: #FBBF24;
        }

        .db-hero-sub {
          font-size: 13.5px;
          color: #CBD5E1;
          line-height: 1.6;
          max-width: 640px;
          margin-bottom: 20px;
        }

        @media (max-width: 767.98px) {
          .db-greeting {
            font-size: 20px !important;
          }
          .db-hero-sub {
            font-size: 12.5px !important;
            margin-bottom: 16px !important;
          }
        }

        .db-hero-btns {
          display: flex;
          gap: 10px;
          flex-wrap: wrap;
        }

        .db-btn-gold {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 9px 18px;
          font-size: 13px;
          font-weight: 700;
          color: #FFFFFF;
          background: #D97706;
          border: none;
          border-radius: 10px;
          cursor: pointer;
          transition: all .2s ease;
          text-decoration: none;
          white-space: nowrap;
        }

        .db-btn-gold:hover {
          background: #B45309;
          transform: translateY(-1px);
          color: #fff;
        }

        .db-btn-outline {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 9px 18px;
          font-size: 13px;
          font-weight: 600;
          color: #FFFFFF;
          background: rgba(255, 255, 255, 0.10);
          border: 1px solid rgba(255, 255, 255, 0.20);
          border-radius: 10px;
          cursor: pointer;
          transition: all .2s ease;
        }

        .db-btn-outline:hover {
          background: rgba(255, 255, 255, 0.18);
          color: #fff;
        }

        .db-btn-outline:disabled, .db-btn-gold:disabled {
          opacity: .55;
          cursor: not-allowed;
          transform: none;
        }

        @media (max-width: 575.98px) {
          .db-hero-btns {
            width: 100% !important;
          }
          .db-btn-gold, .db-btn-outline {
            width: 100% !important;
            justify-content: center !important;
          }
        }

        .db-hero-stat-card {
          background: rgba(255, 255, 255, 0.08);
          border: 1px solid rgba(255, 255, 255, 0.15);
          backdrop-filter: blur(8px);
          border-radius: 14px;
          padding: 20px 24px;
          min-width: 260px;
        }

        @media (max-width: 767.98px) {
          .db-hero-stat-card {
            width: 100% !important;
            min-width: unset !important;
            padding: 16px 18px !important;
          }
        }

        .db-hero-stat-item {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 14px;
        }

        .db-hero-stat-label {
          font-size: 12px;
          font-weight: 400;
          color: #CBD5E1;
        }

        .db-hero-stat-val {
          font-size: 18px;
          font-weight: 800;
          color: #FBBF24;
        }

        .db-hero-stat-sep {
          height: 1px;
          background: rgba(255, 255, 255, 0.08);
          margin: 10px 0;
        }

        @keyframes dbSpin {
          to { transform: rotate(360deg); }
        }

        .db-stats {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 16px;
          margin-bottom: 18px;
        }

        @media (max-width: 1199.98px) {
          .db-stats { grid-template-columns: repeat(2, 1fr); }
        }

        @media (max-width: 575.98px) {
          .db-stats { grid-template-columns: 1fr; }
        }

        .db-stat {
          background: #fff;
          border: 1px solid #E2E8F0;
          border-radius: 14px;
          padding: 20px 18px;
          position: relative;
          overflow: hidden;
          transition: box-shadow .25s, transform .25s;
          box-shadow: 0 2px 8px rgba(15, 39, 68, 0.04);
        }

        .db-stat:hover {
          box-shadow: 0 8px 24px rgba(15, 39, 68, 0.08);
          transform: translateY(-3px);
        }

        .db-stat::before {
          content: "";
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          height: 3px;
          background: var(--sc, #b45309);
          transform: scaleX(0);
          transform-origin: left;
          transition: transform .3s ease;
        }

        .db-stat:hover::before {
          transform: scaleX(1);
        }

        .db-stat-head {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          margin-bottom: 12px;
        }

        .db-stat-icon {
          width: 42px;
          height: 42px;
          border-radius: 10px;
          background: var(--si, #fef3c7);
          color: var(--sc, #b45309);
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .db-stat-label {
          font-size: 12px;
          font-weight: 600;
          color: #64748B;
          margin-bottom: 4px;
          letter-spacing: .02em;
        }

        .db-stat-val {
          font-size: 26px;
          font-weight: 800;
          color: #0F2744;
          line-height: 1;
        }

        .db-stat-footer {
          display: flex;
          align-items: center;
          gap: 6px;
          margin-top: 12px;
          padding-top: 12px;
          border-top: 1px solid #F1F5F9;
          font-size: 12px;
          color: #64748B;
        }

        .db-panel {
          background: #fff;
          border: 1px solid #E2E8F0;
          border-radius: 16px;
          overflow: hidden;
          margin-bottom: 22px;
          box-shadow: 0 2px 8px rgba(15, 39, 68, 0.04);
        }

        .db-panel-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 18px 20px;
          border-bottom: 1px solid #E2E8F0;
          gap: 12px;
        }

        @media (max-width: 767.98px) {
          .db-panel-head {
            padding: 14px 16px !important;
            flex-direction: column !important;
            align-items: flex-start !important;
          }
        }

        .db-panel-title-group {
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .db-panel-icon {
          width: 38px;
          height: 38px;
          border-radius: 10px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: var(--pi, #fef3c7);
          color: var(--pc, #b45309);
          flex-shrink: 0;
        }

        .db-panel-title {
          font-size: 16px;
          font-weight: 800;
          color: #0F2744;
          margin: 0;
        }

        .db-panel-sub {
          font-size: 12px;
          font-weight: 400;
          color: #64748B;
          margin: 2px 0 0;
        }

        .db-refresh-btn {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 7px 14px;
          font-size: 12px;
          font-weight: 600;
          color: #475569;
          background: #FFFFFF;
          border: 1px solid #CBD5E1;
          border-radius: 10px;
          cursor: pointer;
          transition: background .2s;
        }

        .db-refresh-btn:hover {
          background: #F1F5F9;
        }

        .db-refresh-btn:disabled {
          opacity: .55;
          cursor: not-allowed;
        }

        .db-toolbar {
          padding: 16px 20px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          flex-wrap: wrap;
          gap: 14px;
          border-bottom: 1px solid #E2E8F0;
        }

        @media (max-width: 767.98px) {
          .db-toolbar {
            padding: 12px 14px !important;
            flex-direction: column !important;
            align-items: stretch !important;
          }
        }

        .db-input {
          border: 1.5px solid #CBD5E1;
          background: #fff;
          border-radius: 10px;
          padding: 10px 14px;
          font-size: 13.5px;
          color: #0F2744;
          outline: none;
          min-height: 42px;
          transition: all 0.2s ease;
        }

        .db-input:focus {
          border-color: #D97706;
          box-shadow: 0 0 0 3px rgba(217, 119, 6, 0.15);
        }

        .db-actions {
          display: flex;
          gap: 10px;
          flex-wrap: wrap;
          align-items: center;
        }

        @media (max-width: 767.98px) {
          .db-actions {
            width: 100% !important;
            justify-content: stretch !important;
          }
          .db-actions .db-mini-btn {
            flex: 1 1 auto !important;
            text-align: center !important;
            justify-content: center !important;
          }
        }

        .db-mini-btn {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          border-radius: 10px;
          padding: 9px 16px;
          font-size: 13px;
          font-weight: 700;
          border: 1px solid #CBD5E1;
          background: #FFFFFF;
          color: #0F2744;
          cursor: pointer;
          transition: all .2s ease;
          min-height: 40px;
          white-space: nowrap;
        }

        .db-mini-btn:hover {
          background: #F1F5F9;
          transform: translateY(-1px);
        }

        .db-mini-btn--p {
          background: #FBBF24;
          border: none;
          color: #0F2744;
          box-shadow: 0 2px 8px rgba(251, 191, 36, 0.3);
        }

        .db-mini-btn--p:hover {
          background: #F59E0B;
        }

        .db-icon-btn {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          width: 36px;
          height: 36px;
          border-radius: 10px;
          font-size: 14px;
          border: 1px solid #CBD5E1;
          background: #FFFFFF;
          color: #0F2744;
          cursor: pointer;
          transition: all .2s ease;
          flex-shrink: 0;
        }

        .db-icon-btn:hover {
          background: #F1F5F9;
          transform: translateY(-1px);
        }

        .db-pill {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 4px 10px;
          border-radius: 999px;
          font-size: 11.5px;
          font-weight: 700;
        }

        .db-pill--info {
          background: rgba(37, 99, 235, 0.12);
          color: #1E40AF;
        }

        .db-pill--gold {
          background: rgba(217, 119, 6, 0.14);
          color: #92400E;
        }

        .db-pill--muted {
          background: #F1F5F9;
          color: #64748B;
        }

        .db-pill--ok {
          background: rgba(16, 185, 129, 0.14);
          color: #065F46;
        }

        .db-pill--no {
          background: rgba(239, 68, 68, 0.12);
          color: #991B1B;
        }

        .db-pill--warn {
          background: rgba(245, 158, 11, 0.14);
          color: #92400E;
        }

        .db-filter-tabs {
          display: flex;
          gap: 8px;
          flex-wrap: wrap;
          align-items: center;
          width: 100%;
        }

        @media (max-width: 767.98px) {
          .db-filter-tabs {
            display: grid !important;
            grid-template-columns: repeat(2, 1fr) !important;
            gap: 8px !important;
          }
        }

        @media (max-width: 480px) {
          .db-filter-tabs {
            grid-template-columns: 1fr !important;
          }
        }

        .db-filter-tab {
          border: 1px solid #CBD5E1;
          background: #fff;
          color: #64748B;
          border-radius: 10px;
          padding: 8px 12px;
          cursor: pointer;
          transition: all .2s ease;
          text-align: left;
          min-height: 44px;
        }

        .db-filter-tab:hover {
          background: #F8FAFC;
          border-color: #94A3B8;
        }

        .db-filter-tab--active {
          background: #0A192F !important;
          border-color: #0A192F !important;
          color: #fff !important;
        }

        .db-filter-tab-label {
          display: block;
          font-size: 12.5px;
          font-weight: 700;
          line-height: 1.1;
        }

        .db-filter-tab-count {
          display: block;
          font-size: 11px;
          opacity: .75;
          margin-top: 3px;
        }

        .db-status-select {
          border: 1.5px solid #CBD5E1;
          background: #fff;
          border-radius: 10px;
          padding: 6px 10px;
          font-size: 12.5px;
          font-weight: 700;
          color: #0F2744;
          outline: none;
          min-height: 36px;
        }

        .db-status-select:focus {
          border-color: #D97706;
          box-shadow: 0 0 0 3px rgba(217, 119, 6, 0.15);
        }

        .db-status-select:disabled {
          opacity: .55;
          cursor: not-allowed;
        }

        .db-table {
          width: 100%;
          border-collapse: collapse;
        }

        .db-table th {
          padding: 12px 16px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #64748B;
          background: #F8FAFC;
          border-bottom: 1px solid #E2E8F0;
          text-align: left;
          white-space: nowrap;
        }

        .db-table td {
          padding: 14px 16px;
          font-size: 13.5px;
          color: #1E293B;
          border-bottom: 1px solid #E2E8F0;
          vertical-align: middle;
        }

        .db-table tbody tr {
          transition: background .15s;
        }

        .db-table tbody tr:hover {
          background: #F8FAFC;
        }

        .db-avatar {
          width: 44px;
          height: 44px;
          border-radius: 999px;
          border: 1px solid #E2E8F0;
          overflow: hidden;
          background: #fff;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
        }

        .db-avatar img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .db-avatar-fallback {
          background: #E0E7FF;
          color: #4338CA;
          font-weight: 800;
        }

        .db-empty {
          padding: 46px 16px;
          text-align: center;
          color: #64748B;
          font-size: 13.5px;
        }

        .db-modal-backdrop {
          position: fixed;
          inset: 0;
          background: rgba(10, 25, 47, 0.70);
          backdrop-filter: blur(8px);
          -webkit-backdrop-filter: blur(8px);
          z-index: 1200;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 16px;
        }

        .db-modal {
          width: min(1100px, 96vw);
          max-height: 92vh;
          background: #fff;
          border-radius: 18px;
          overflow: hidden;
          box-shadow: 0 25px 60px -12px rgba(15, 39, 68, 0.35);
          border: 1px solid rgba(15, 39, 68, 0.12);
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
        }

        .db-modal-head {
          padding: 22px 28px 16px;
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 100%);
          color: #fff;
          position: relative;
          overflow: hidden;
          border-bottom: 1px solid rgba(255, 255, 255, 0.12);
        }

        .db-modal-head::before {
          content: "";
          position: absolute;
          inset: 0;
          background-image:
            linear-gradient(rgba(255, 255, 255, 0.035) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255, 255, 255, 0.035) 1px, transparent 1px);
          background-size: 24px 24px;
          pointer-events: none;
        }

        .db-modal-glow {
          position: absolute;
          top: -40px;
          right: -40px;
          width: 280px;
          height: 280px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.20) 0%, transparent 65%);
        }

        .db-modal-row {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: 16px;
          flex-wrap: wrap;
        }

        .db-modal-left {
          display: flex;
          align-items: center;
          gap: 14px;
        }

        .db-modal-title {
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          font-size: 18px;
          font-weight: 800;
          color: #FFFFFF;
          margin: 0;
        }

        .db-modal-sub {
          margin: 4px 0 0;
          font-size: 12.5px;
          color: #CBD5E1;
        }

        .db-modal-body {
          background: #F8FAFC;
          padding: 24px;
          overflow: auto;
          max-height: calc(92vh - 78px);
        }

        @media (max-width: 767.98px) {
          .db-modal-body {
            padding: 16px 14px !important;
          }
          .db-modal-head {
            padding: 18px 18px 14px !important;
          }
        }

        .db-card {
          background: #fff;
          border: 1px solid #E2E8F0;
          border-radius: 14px;
          overflow: hidden;
          box-shadow: 0 2px 10px rgba(15, 39, 68, 0.04);
        }

        .db-card-inner {
          padding: 20px;
        }

        @media (max-width: 767.98px) {
          .db-card-inner {
            padding: 14px !important;
          }
        }

        .db-kv-grid {
          display: grid;
          grid-template-columns: repeat(3, minmax(220px, 1fr));
          gap: 12px;
        }

        @media (max-width: 991.98px) {
          .db-kv-grid { grid-template-columns: 1fr; }
        }

        .db-kv {
          border: 1px solid #E2E8F0;
          border-radius: 12px;
          background: #F8FAFC;
          padding: 12px 16px;
        }

        .db-kv-label {
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #64748B;
          display: flex;
          align-items: center;
          gap: 8px;
          margin-bottom: 6px;
        }

        .db-kv-val {
          font-size: 14px;
          font-weight: 800;
          color: #0F2744;
        }

        .db-tabs {
          display: flex;
          gap: 4px;
          margin-top: 16px;
          position: relative;
          z-index: 1;
          border-bottom: 2px solid rgba(255, 255, 255, 0.08);
          overflow-x: auto;
        }

        .db-tab {
          border: none;
          background: transparent;
          color: rgba(255, 255, 255, 0.7);
          border-radius: 8px 8px 0 0;
          padding: 9px 16px;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s ease;
          white-space: nowrap;
        }

        .db-tab:hover {
          color: #FFFFFF;
          background: rgba(255, 255, 255, 0.08);
        }

        .db-tab--active {
          background: rgba(217, 119, 6, 0.18);
          color: #FBBF24;
          border-bottom: 2px solid #FBBF24;
          font-weight: 700;
        }

        .db-form-grid {
          display: grid;
          grid-template-columns: repeat(2, minmax(260px, 1fr));
          gap: 16px;
        }

        @media (max-width: 991.98px) {
          .db-form-grid { grid-template-columns: 1fr; }
        }

        .db-label {
          font-size: 12px;
          font-weight: 700;
          color: #0F2744;
          margin-bottom: 6px;
        }

        .db-select {
          border: 1.5px solid #CBD5E1;
          background: #fff;
          border-radius: 10px;
          padding: 10px 14px;
          font-size: 13.5px;
          color: #0F2744;
          outline: none;
          min-height: 42px;
          width: 100%;
          transition: all 0.2s ease;
        }

        .db-select:focus {
          border-color: #D97706;
          box-shadow: 0 0 0 3px rgba(217, 119, 6, 0.15);
        }

        .db-muted {
          color: #64748B;
          font-size: 12.5px;
        }
      `}),(0,c.jsx)(ee,{sidebarOpen:l,setSidebarOpen:d}),(0,c.jsx)(n,{title:`Teachers`}),(0,c.jsx)(`div`,{className:`container-fluid`,children:(0,c.jsxs)(`div`,{className:`row`,children:[(0,c.jsx)(o,{sidebarOpen:l,setSidebarOpen:d}),(0,c.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto gq-app-main db-main d-flex flex-column min-vh-100`,children:[(y||A||W)&&(0,c.jsx)(r,{message:W?`Creating teacher...`:A?`Saving teacher...`:`Loading teachers...`}),(0,c.jsxs)(`div`,{className:`db-hero`,children:[(0,c.jsx)(`div`,{className:`db-hero-glow`,"aria-hidden":`true`}),(0,c.jsx)(`div`,{className:`db-hero-glow2`,"aria-hidden":`true`}),(0,c.jsxs)(`div`,{className:`db-hero-inner`,children:[(0,c.jsxs)(`div`,{children:[(0,c.jsxs)(`div`,{className:`db-session-badge`,children:[(0,c.jsx)(`span`,{className:`db-session-dot`}),`Teachers ·`,` `,(0,c.jsxs)(`span`,{style:{color:`#94a3b8`},children:[`page `,g,` / `,v]}),` `,`· `,(0,c.jsxs)(`span`,{style:{color:`#94a3b8`},children:[ze,` on this page`]})]}),(0,c.jsxs)(`h1`,{className:`db-greeting`,children:[ae(),`, `,(0,c.jsxs)(`em`,{children:[`Admin`,`.`]})]}),(0,c.jsx)(`p`,{className:`db-hero-sub`,children:`Search teachers, view profiles, edit details, update class enrollment, manage login credentials, and control staff access when a teacher is suspended, inactive, or has resigned.`}),(0,c.jsxs)(`div`,{className:`db-hero-btns`,children:[(0,c.jsxs)(`button`,{className:`db-btn-gold`,onClick:Ie,children:[(0,c.jsx)(`span`,{style:{width:14,height:14,borderRadius:6,background:`rgba(15,23,42,0.10)`,display:`inline-flex`,alignItems:`center`,justifyContent:`center`},children:`+`}),`Add Teacher`]}),(0,c.jsxs)(`button`,{className:`db-btn-outline`,onClick:()=>J(),disabled:y,children:[(0,c.jsx)(`span`,{style:{width:14,height:14,borderRadius:`50%`,border:`2px solid rgba(255,255,255,0.25)`,borderTopColor:`#fff`,display:`inline-block`,animation:y?`dbSpin 0.8s linear infinite`:`none`}}),`Refresh`]}),(0,c.jsx)(`button`,{className:`db-btn-outline`,onClick:()=>fe(e=>!e),disabled:y,children:x?`Close Import`:`Import Teachers`})]})]}),(0,c.jsxs)(`div`,{className:`db-hero-stat-card d-none d-md-block`,children:[(0,c.jsx)(`div`,{style:{fontSize:11,fontWeight:900,letterSpacing:`0.14em`,textTransform:`uppercase`,color:`#c9a84c`,marginBottom:10},children:`Quick stats`}),(0,c.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,c.jsx)(`span`,{className:`db-hero-stat-label`,children:`Active`}),(0,c.jsx)(`span`,{className:`db-hero-stat-val`,children:Z})]}),(0,c.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,c.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,c.jsx)(`span`,{className:`db-hero-stat-label`,children:`Suspended`}),(0,c.jsx)(`span`,{className:`db-hero-stat-val`,children:Q})]}),(0,c.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,c.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,c.jsx)(`span`,{className:`db-hero-stat-label`,children:`Inactive`}),(0,c.jsx)(`span`,{className:`db-hero-stat-val`,children:$})]}),(0,c.jsx)(`div`,{style:{marginTop:12,paddingTop:12,borderTop:`1px solid rgba(255,255,255,0.06)`},children:(0,c.jsxs)(`div`,{style:{fontSize:12,color:`#94a3b8`},children:[`Tip: Click `,(0,c.jsx)(`b`,{style:{color:`#fff`},children:`View`}),` to open profile.`]})})]})]})]}),(0,c.jsx)(`div`,{className:`db-stats`,children:[{title:`Teachers (Page)`,value:ze,color:`#1e40af`,bg:`#dbeafe`,hint:`loaded in current view`},{title:`Active`,value:Z,color:`#15803d`,bg:`#dcfce7`,hint:`status active`},{title:`Suspended`,value:Q,color:`#b45309`,bg:`#fef3c7`,hint:`temporarily blocked`},{title:`Inactive / Resigned`,value:$+Be,color:`#475569`,bg:`#e2e8f0`,hint:`not in active service`}].map((e,t)=>(0,c.jsxs)(`div`,{className:`db-stat`,style:{"--sc":e.color,"--si":e.bg},children:[(0,c.jsxs)(`div`,{className:`db-stat-head`,children:[(0,c.jsx)(`div`,{className:`db-stat-icon`,children:t===0?(0,c.jsxs)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 20 20`,fill:`none`,children:[(0,c.jsx)(`circle`,{cx:`8`,cy:`6`,r:`3`,stroke:`currentColor`,strokeWidth:`1.5`}),(0,c.jsx)(`path`,{d:`M2 18c0-3.314 2.686-6 6-6`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`}),(0,c.jsx)(`circle`,{cx:`15`,cy:`10`,r:`2.5`,stroke:`currentColor`,strokeWidth:`1.4`})]}):t===1?(0,c.jsxs)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 20 20`,fill:`none`,children:[(0,c.jsx)(`path`,{d:`M16 6l-7 9-3-3`,stroke:`currentColor`,strokeWidth:`1.7`,strokeLinecap:`round`,strokeLinejoin:`round`}),(0,c.jsx)(`circle`,{cx:`10`,cy:`10`,r:`8`,stroke:`currentColor`,strokeWidth:`1.2`,opacity:`0.35`})]}):t===2?(0,c.jsxs)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 20 20`,fill:`none`,children:[(0,c.jsx)(`path`,{d:`M4 10h12`,stroke:`currentColor`,strokeWidth:`1.7`,strokeLinecap:`round`}),(0,c.jsx)(`circle`,{cx:`10`,cy:`10`,r:`8`,stroke:`currentColor`,strokeWidth:`1.2`,opacity:`0.35`})]}):(0,c.jsxs)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 20 20`,fill:`none`,children:[(0,c.jsx)(`path`,{d:`M6 5h8M6 10h8M6 15h5`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`}),(0,c.jsx)(`path`,{d:`M14 14l2 2`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})]})}),(0,c.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,style:{color:`#c8bfb5`},children:[(0,c.jsx)(`circle`,{cx:`4`,cy:`8`,r:`1.2`,fill:`currentColor`}),(0,c.jsx)(`circle`,{cx:`8`,cy:`8`,r:`1.2`,fill:`currentColor`}),(0,c.jsx)(`circle`,{cx:`12`,cy:`8`,r:`1.2`,fill:`currentColor`})]})]}),(0,c.jsx)(`p`,{className:`db-stat-label`,children:e.title}),(0,c.jsx)(`div`,{className:`db-stat-val`,children:e.value}),(0,c.jsx)(`div`,{className:`db-stat-footer`,children:(0,c.jsx)(`span`,{className:`db-pill db-pill--muted`,children:e.hint})})]},e.title))}),(0,c.jsxs)(`div`,{className:`db-panel`,children:[(0,c.jsxs)(`div`,{className:`db-panel-head`,children:[(0,c.jsxs)(`div`,{className:`db-panel-title-group`,children:[(0,c.jsx)(`div`,{className:`db-panel-icon`,style:{"--pi":`#fef3c7`,"--pc":`#b45309`},children:(0,c.jsx)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:(0,c.jsx)(`path`,{d:`M4 3h8M5 7h6M6 11h4`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})})}),(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`p`,{className:`db-panel-title`,children:`Teacher Directory`}),(0,c.jsx)(`p`,{className:`db-panel-sub`,children:`Search by name, email or phone. View profile to edit or manage credentials.`})]})]}),(0,c.jsxs)(`button`,{className:`db-refresh-btn`,onClick:()=>J(),disabled:y,children:[(0,c.jsxs)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,style:{animation:y?`dbSpin 0.8s linear infinite`:`none`},children:[(0,c.jsx)(`path`,{d:`M12 7A5 5 0 112 7`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,c.jsx)(`path`,{d:`M12 3v4h-4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),y?`Loading…`:`Refresh`]})]}),(0,c.jsx)(`div`,{className:`db-toolbar`,children:(0,c.jsxs)(`div`,{style:{display:`flex`,gap:10,flexWrap:`wrap`,alignItems:`center`,width:`100%`},children:[(0,c.jsxs)(`div`,{style:{flex:`1 1 360px`,minWidth:260},children:[(0,c.jsx)(`input`,{className:`db-input`,style:{width:`100%`},placeholder:`Search teachers (name, email, phone)…`,value:h,onChange:e=>{le(e.target.value),_(1)}}),(0,c.jsx)(`div`,{className:`db-muted`,style:{marginTop:6},children:`Tip: Clearing search will return the full list again.`})]}),(0,c.jsx)(`div`,{className:`db-filter-tabs`,children:oe.map(e=>{let t=e.value===`all`?Z+Q+$+Be:C[e.value];return(0,c.jsxs)(`button`,{className:`db-filter-tab ${S===e.value?`db-filter-tab--active`:``}`,onClick:()=>{pe(e.value),_(1)},title:e.hint,children:[(0,c.jsx)(`span`,{className:`db-filter-tab-label`,children:e.label}),(0,c.jsxs)(`span`,{className:`db-filter-tab-count`,children:[t,` teacher(s)`]})]},e.value)})}),(0,c.jsxs)(`div`,{className:`db-actions`,style:{marginLeft:`auto`},children:[h.trim()?(0,c.jsx)(`button`,{className:`db-mini-btn`,onClick:()=>{le(``),_(1)},title:`Clear search`,children:`✕ Clear`}):null,(0,c.jsx)(`button`,{className:`db-mini-btn db-mini-btn--p`,onClick:Ie,children:`+ Add Teacher`}),(0,c.jsx)(`button`,{className:`db-mini-btn`,onClick:()=>fe(e=>!e),children:x?`Close Import`:`Import`})]})]})}),x&&(0,c.jsx)(re,{kind:`teachers`,onImported:J}),(0,c.jsx)(`div`,{style:{overflowX:`auto`},children:(0,c.jsxs)(`table`,{className:`db-table`,children:[(0,c.jsx)(`thead`,{children:(0,c.jsxs)(`tr`,{children:[(0,c.jsx)(`th`,{style:{minWidth:360},children:`Teacher`}),(0,c.jsx)(`th`,{style:{width:170},children:`Staff ID`}),(0,c.jsx)(`th`,{style:{width:260},children:`Class`}),(0,c.jsx)(`th`,{style:{width:140},children:`Status`}),(0,c.jsx)(`th`,{style:{width:220,textAlign:`right`},children:`Action`})]})}),(0,c.jsx)(`tbody`,{children:y?(0,c.jsx)(`tr`,{children:(0,c.jsxs)(`td`,{colSpan:5,className:`db-empty`,children:[(0,c.jsx)(`div`,{style:{fontWeight:900,color:`#1a1a2e`},children:`Loading teachers…`}),(0,c.jsx)(`div`,{style:{marginTop:6},children:`Please wait.`})]})}):m.length===0?(0,c.jsx)(`tr`,{children:(0,c.jsxs)(`td`,{colSpan:5,className:`db-empty`,children:[(0,c.jsx)(`div`,{style:{fontWeight:900,color:`#1a1a2e`},children:`No teachers found`}),(0,c.jsx)(`div`,{style:{marginTop:6},children:`Try a different search or add a new teacher.`})]})}):m.map(e=>{let t=f(e),n=e.level?.name||e.teacher_enrollment?.level?.name||`—`;return(0,c.jsxs)(`tr`,{children:[(0,c.jsx)(`td`,{children:(0,c.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:12},children:[(0,c.jsx)(`div`,{className:`db-avatar ${e.photo?``:`db-avatar-fallback`}`,children:e.photo?(0,c.jsx)(`img`,{src:q(e.photo),alt:u(e)}):(0,c.jsx)(`span`,{children:ie(e)})}),(0,c.jsxs)(`div`,{style:{minWidth:0},children:[(0,c.jsx)(`div`,{style:{fontWeight:900,color:`#1a1a2e`,lineHeight:1.2},children:u(e)||`—`}),(0,c.jsxs)(`div`,{className:`db-muted`,style:{overflow:`hidden`,textOverflow:`ellipsis`,whiteSpace:`nowrap`,maxWidth:520},children:[e.email||`—`,` `,e.phone?`· ${e.phone}`:``]})]})]})}),(0,c.jsx)(`td`,{children:(0,c.jsx)(`span`,{className:`db-pill db-pill--info`,children:e.reg_no||`—`})}),(0,c.jsx)(`td`,{children:(0,c.jsx)(`span`,{className:`db-pill db-pill--gold`,children:n})}),(0,c.jsx)(`td`,{children:(0,c.jsx)(`span`,{className:`db-pill ${se(t)}`,children:p(t)})}),(0,c.jsx)(`td`,{style:{textAlign:`right`},children:(0,c.jsxs)(`div`,{style:{display:`inline-flex`,gap:8,flexWrap:`wrap`,justifyContent:`flex-end`},children:[(0,c.jsxs)(`select`,{className:`db-status-select`,value:t,disabled:he===e.id,onChange:t=>Fe(e,t.target.value),title:`Change teacher access status`,children:[(0,c.jsx)(`option`,{value:`active`,children:`Active`}),(0,c.jsx)(`option`,{value:`suspended`,children:`Suspended`}),(0,c.jsx)(`option`,{value:`inactive`,children:`Inactive`}),(0,c.jsx)(`option`,{value:`resigned`,children:`Resigned`})]}),(0,c.jsx)(`button`,{className:`db-icon-btn db-icon-btn--p`,onClick:()=>ke(e),title:`View Profile: ${u(e)}`,"aria-label":`View Teacher Profile`,children:(0,c.jsxs)(`svg`,{width:`15`,height:`15`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,c.jsx)(`path`,{d:`M1 8s2.5-5 7-5 7 5 7 5-2.5 5-7 5-7-5-7-5z`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinejoin:`round`}),(0,c.jsx)(`circle`,{cx:`8`,cy:`8`,r:`2.5`,stroke:`currentColor`,strokeWidth:`1.4`})]})}),(0,c.jsx)(`button`,{className:`db-icon-btn db-icon-btn--r`,onClick:()=>Pe(e),title:`Delete Teacher: ${u(e)}`,"aria-label":`Delete Teacher`,children:(0,c.jsx)(`svg`,{width:`15`,height:`15`,viewBox:`0 0 16 16`,fill:`none`,children:(0,c.jsx)(`path`,{d:`M2 4h12M5 4V2.5a.5.5 0 01.5-.5h5a.5.5 0 01.5.5V4M6 7v5M10 7v5M3.5 4l.8 9.2a1 1 0 001 .8h5.4a1 1 0 001-.8L12.5 4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})})})]})})]},e.id)})})]})}),(0,c.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,gap:12,flexWrap:`wrap`,padding:`14px 20px`,borderTop:`1px solid rgba(0,0,0,0.06)`,background:`#fff`},children:[(0,c.jsxs)(`div`,{className:`db-muted`,children:[`Page `,(0,c.jsx)(`b`,{style:{color:`#1a1a2e`},children:g}),` of `,(0,c.jsx)(`b`,{style:{color:`#1a1a2e`},children:v})]}),(0,c.jsxs)(`div`,{style:{display:`flex`,gap:10,flexWrap:`wrap`},children:[(0,c.jsx)(`button`,{className:`db-mini-btn`,disabled:g===1,onClick:()=>_(e=>e-1),children:`← Previous`}),(0,c.jsx)(`button`,{className:`db-mini-btn`,disabled:g===v,onClick:()=>_(e=>e+1),children:`Next →`})]})]})]}),(0,c.jsx)(`div`,{className:`mt-auto`,style:{paddingTop:18},children:(0,c.jsx)(ne,{})})]})]})}),Se&&(0,c.jsx)(`div`,{className:`db-modal-backdrop`,onMouseDown:X,children:(0,c.jsxs)(`div`,{className:`db-modal`,onMouseDown:e=>e.stopPropagation(),children:[(0,c.jsxs)(`div`,{className:`db-modal-head`,children:[(0,c.jsx)(`div`,{className:`db-modal-glow`,"aria-hidden":`true`}),(0,c.jsxs)(`div`,{className:`db-modal-row`,children:[(0,c.jsxs)(`div`,{className:`db-modal-left`,children:[(0,c.jsx)(`div`,{className:`db-avatar`,style:{width:62,height:62,borderColor:`rgba(255,255,255,0.25)`},children:Ee?(0,c.jsx)(`img`,{src:Ee,alt:`Preview`}):(0,c.jsx)(`span`,{style:{color:`#e8c97a`,fontWeight:900},children:`+`})}),(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`p`,{className:`db-modal-title`,children:`Add Teacher`}),(0,c.jsx)(`p`,{className:`db-modal-sub`,children:`Create a staff account and assign a class (Level). Password is auto-generated.`})]})]}),(0,c.jsxs)(`div`,{style:{display:`flex`,gap:10,flexWrap:`wrap`,alignItems:`center`},children:[(0,c.jsxs)(`label`,{className:`db-btn-outline`,style:{margin:0},children:[`Upload Photo`,(0,c.jsx)(`input`,{type:`file`,accept:`image/*`,onChange:Le,style:{display:`none`}})]}),(0,c.jsx)(`button`,{className:`db-btn-outline`,onClick:X,disabled:W,children:`Close`})]})]})]}),(0,c.jsxs)(`div`,{className:`db-modal-body`,children:[(0,c.jsx)(`div`,{className:`db-card`,children:(0,c.jsxs)(`div`,{className:`db-card-inner`,children:[(0,c.jsxs)(`div`,{style:{display:`flex`,alignItems:`flex-end`,justifyContent:`space-between`,gap:12,flexWrap:`wrap`,marginBottom:10},children:[(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`div`,{style:{fontFamily:`Lora, serif`,fontWeight:900,color:`#1a1a2e`},children:`Teacher Information`}),(0,c.jsx)(`div`,{className:`db-muted`,children:`Fields marked * are required.`})]}),(0,c.jsx)(`span`,{className:`db-pill db-pill--muted`,children:`Only admins should create staff accounts`})]}),(0,c.jsxs)(`div`,{className:`db-form-grid`,children:[(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`div`,{className:`db-label`,children:`First name *`}),(0,c.jsx)(`input`,{className:`db-input`,style:{width:`100%`},value:G.firstname,onChange:e=>K({...G,firstname:e.target.value}),placeholder:`e.g. Adeola`})]}),(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`div`,{className:`db-label`,children:`Surname *`}),(0,c.jsx)(`input`,{className:`db-input`,style:{width:`100%`},value:G.surname,onChange:e=>K({...G,surname:e.target.value}),placeholder:`e.g. Johnson`})]}),(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`div`,{className:`db-label`,children:`Username`}),(0,c.jsx)(`input`,{className:`db-input`,style:{width:`100%`},value:G.username,onChange:e=>K({...G,username:e.target.value}),placeholder:`e.g. adeola.j`})]}),(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`div`,{className:`db-label`,children:`Email`}),(0,c.jsx)(`input`,{className:`db-input`,style:{width:`100%`},type:`email`,value:G.email,onChange:e=>K({...G,email:e.target.value}),placeholder:`teacher@email.com`})]}),(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`div`,{className:`db-label`,children:`Phone`}),(0,c.jsx)(`input`,{className:`db-input`,style:{width:`100%`},value:G.phone,onChange:e=>K({...G,phone:e.target.value}),placeholder:`080...`})]}),(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`div`,{className:`db-label`,children:`Gender`}),(0,c.jsxs)(`select`,{className:`db-select`,value:G.sex,onChange:e=>K({...G,sex:e.target.value}),children:[(0,c.jsx)(`option`,{value:``,children:`Select`}),(0,c.jsx)(`option`,{value:`male`,children:`Male`}),(0,c.jsx)(`option`,{value:`female`,children:`Female`})]})]}),(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`div`,{className:`db-label`,children:`DOB`}),(0,c.jsx)(`input`,{className:`db-input`,style:{width:`100%`},type:`date`,value:G.dob,onChange:e=>K({...G,dob:e.target.value})})]}),(0,c.jsxs)(`div`,{style:{gridColumn:`1 / -1`},children:[(0,c.jsx)(`div`,{className:`db-label`,children:`Address`}),(0,c.jsx)(`input`,{className:`db-input`,style:{width:`100%`},value:G.address,onChange:e=>K({...G,address:e.target.value}),placeholder:`Teacher address`})]}),(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`div`,{className:`db-label`,children:`Assign Class (Level) *`}),(0,c.jsxs)(`select`,{className:`db-select`,value:G.level_id,onChange:e=>K({...G,level_id:e.target.value}),children:[(0,c.jsx)(`option`,{value:``,children:`Select class`}),_e.map(e=>(0,c.jsx)(`option`,{value:e.id,children:e.name},e.id))]}),(0,c.jsx)(`div`,{className:`db-muted`,style:{marginTop:6},children:`A random password is generated automatically. View it later from the teacher profile.`})]}),(0,c.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,justifyContent:`flex-end`,gap:10},children:[(0,c.jsx)(`button`,{className:`db-mini-btn db-mini-btn--p`,onClick:Re,disabled:W,title:`Create Teacher`,children:W?(0,c.jsxs)(c.Fragment,{children:[(0,c.jsx)(`span`,{style:{width:14,height:14,borderRadius:`50%`,border:`2px solid rgba(67,56,202,0.25)`,borderTopColor:`#4338ca`,display:`inline-block`,animation:`dbSpin 0.8s linear infinite`}}),`Creating…`]}):(0,c.jsx)(c.Fragment,{children:`Create Teacher`})}),(0,c.jsx)(`button`,{className:`db-mini-btn`,onClick:X,disabled:W,children:`Cancel`})]})]})]})}),(0,c.jsx)(`div`,{style:{marginTop:12},className:`db-muted`,children:`Security note: share credentials only with the teacher and encourage password change after first login.`})]})]})}),w&&(0,c.jsx)(`div`,{className:`db-modal-backdrop`,onMouseDown:Y,children:(0,c.jsxs)(`div`,{className:`db-modal`,onMouseDown:e=>e.stopPropagation(),children:[(0,c.jsxs)(`div`,{className:`db-modal-head`,children:[(0,c.jsx)(`div`,{className:`db-modal-glow`,"aria-hidden":`true`}),(0,c.jsxs)(`div`,{className:`db-modal-row`,children:[(0,c.jsxs)(`div`,{className:`db-modal-left`,children:[(0,c.jsx)(`div`,{className:`db-avatar`,style:{width:62,height:62,borderColor:`rgba(255,255,255,0.25)`},children:(0,c.jsx)(`img`,{src:xe||q(E?.teacher?.photo||w.photo),alt:`Teacher`})}),(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`p`,{className:`db-modal-title`,children:E?.teacher?u(E.teacher):u(w)}),(0,c.jsxs)(`p`,{className:`db-modal-sub`,children:[`Staff ID: `,(0,c.jsx)(`b`,{style:{color:`#fff`},children:E?.teacher?.reg_no??w.reg_no??`-`}),` `,`· Class:`,` `,(0,c.jsx)(`b`,{style:{color:`#fff`},children:E?.teacher?.teacher_enrollment?.level?.name??E?.teacher?.level?.name??w.level?.name??`-`})]})]})]}),(0,c.jsxs)(`div`,{style:{display:`flex`,gap:10,flexWrap:`wrap`,alignItems:`center`},children:[!O&&!j&&(0,c.jsx)(`button`,{className:`db-btn-gold`,onClick:Ae,children:`Edit`}),!O&&j&&(0,c.jsxs)(c.Fragment,{children:[(0,c.jsx)(`button`,{className:`db-btn-gold`,onClick:Ne,disabled:A,children:A?`Saving…`:`Save`}),(0,c.jsx)(`button`,{className:`db-btn-outline`,onClick:je,disabled:A,children:`Cancel`})]}),(0,c.jsx)(`button`,{className:`db-btn-outline`,onClick:Y,children:`Close`})]})]}),(0,c.jsxs)(`div`,{className:`db-tabs`,children:[(0,c.jsx)(`button`,{className:`db-tab ${V===`overview`?`db-tab--active`:``}`,onClick:()=>H(`overview`),disabled:O,children:`Overview`}),(0,c.jsx)(`button`,{className:`db-tab ${V===`security`?`db-tab--active`:``}`,onClick:()=>H(`security`),disabled:O,children:`Security`})]})]}),(0,c.jsxs)(`div`,{className:`db-modal-body`,children:[O?(0,c.jsx)(`div`,{className:`db-card`,children:(0,c.jsxs)(`div`,{className:`db-card-inner`,style:{textAlign:`center`,padding:30},children:[(0,c.jsx)(`div`,{style:{width:26,height:26,borderRadius:`50%`,border:`3px solid rgba(0,0,0,0.10)`,borderTopColor:`#0f172a`,display:`inline-block`,animation:`dbSpin 0.8s linear infinite`}}),(0,c.jsx)(`div`,{className:`db-muted`,style:{marginTop:10},children:`Loading teacher details…`})]})}):E?.teacher?(0,c.jsxs)(c.Fragment,{children:[V===`overview`&&(0,c.jsx)(`div`,{className:`db-card`,children:(0,c.jsxs)(`div`,{className:`db-card-inner`,children:[(0,c.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,gap:10,flexWrap:`wrap`,marginBottom:12},children:[(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`div`,{style:{fontFamily:`Lora, serif`,fontWeight:900,color:`#1a1a2e`},children:j?`Edit Teacher Information`:`Teacher Details`}),(0,c.jsx)(`div`,{className:`db-muted`,children:j?`Update personal, contact and class enrollment.`:`Personal, contact and enrollment summary.`})]}),j?(0,c.jsxs)(`label`,{className:`db-mini-btn db-mini-btn--p`,style:{margin:0},children:[`Change Photo`,(0,c.jsx)(`input`,{type:`file`,accept:`image/*`,onChange:Me,style:{display:`none`}})]}):(0,c.jsxs)(`span`,{className:`db-pill db-pill--muted`,children:[`ID: `,E.teacher?.id]})]}),j?(0,c.jsxs)(`div`,{className:`db-form-grid`,children:[(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`div`,{className:`db-label`,children:`First name *`}),(0,c.jsx)(`input`,{className:`db-input`,style:{width:`100%`},value:N.firstname,onChange:e=>P({...N,firstname:e.target.value})})]}),(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`div`,{className:`db-label`,children:`Surname *`}),(0,c.jsx)(`input`,{className:`db-input`,style:{width:`100%`},value:N.surname,onChange:e=>P({...N,surname:e.target.value})})]}),(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`div`,{className:`db-label`,children:`Email *`}),(0,c.jsx)(`input`,{className:`db-input`,style:{width:`100%`},type:`email`,value:N.email,onChange:e=>P({...N,email:e.target.value})})]}),(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`div`,{className:`db-label`,children:`Phone`}),(0,c.jsx)(`input`,{className:`db-input`,style:{width:`100%`},value:N.phone,onChange:e=>P({...N,phone:e.target.value})})]}),(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`div`,{className:`db-label`,children:`Gender`}),(0,c.jsxs)(`select`,{className:`db-select`,value:N.sex,onChange:e=>P({...N,sex:e.target.value}),children:[(0,c.jsx)(`option`,{value:``,children:`Select`}),(0,c.jsx)(`option`,{value:`male`,children:`Male`}),(0,c.jsx)(`option`,{value:`female`,children:`Female`})]})]}),(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`div`,{className:`db-label`,children:`DOB`}),(0,c.jsx)(`input`,{className:`db-input`,style:{width:`100%`},type:`date`,value:N.dob,onChange:e=>P({...N,dob:e.target.value})})]}),(0,c.jsxs)(`div`,{style:{gridColumn:`1 / -1`},children:[(0,c.jsx)(`div`,{className:`db-label`,children:`Address`}),(0,c.jsx)(`input`,{className:`db-input`,style:{width:`100%`},value:N.address,onChange:e=>P({...N,address:e.target.value})})]}),(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`div`,{className:`db-label`,children:`Class (Level)`}),(0,c.jsxs)(`select`,{className:`db-select`,value:N.level_id??``,onChange:e=>P({...N,level_id:e.target.value}),children:[(0,c.jsx)(`option`,{value:``,children:`Select class`}),_e.map(e=>(0,c.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]}),(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`div`,{className:`db-label`,children:`New password (optional)`}),(0,c.jsx)(`input`,{className:`db-input`,style:{width:`100%`,fontFamily:`ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace`},value:N.password,onChange:e=>P({...N,password:e.target.value}),placeholder:`Leave empty to keep current`})]})]}):(0,c.jsxs)(`div`,{className:`db-kv-grid`,children:[(0,c.jsxs)(`div`,{className:`db-kv`,children:[(0,c.jsx)(`div`,{className:`db-kv-label`,children:`Full name`}),(0,c.jsx)(`div`,{className:`db-kv-val`,children:u(E.teacher)||`N/A`})]}),(0,c.jsxs)(`div`,{className:`db-kv`,children:[(0,c.jsx)(`div`,{className:`db-kv-label`,children:`Email`}),(0,c.jsx)(`div`,{className:`db-kv-val`,children:E.teacher?.email||`N/A`})]}),(0,c.jsxs)(`div`,{className:`db-kv`,children:[(0,c.jsx)(`div`,{className:`db-kv-label`,children:`Phone`}),(0,c.jsx)(`div`,{className:`db-kv-val`,children:E.teacher?.phone||`N/A`})]}),(0,c.jsxs)(`div`,{className:`db-kv`,children:[(0,c.jsx)(`div`,{className:`db-kv-label`,children:`Gender`}),(0,c.jsx)(`div`,{className:`db-kv-val`,children:E.teacher?.sex||`N/A`})]}),(0,c.jsxs)(`div`,{className:`db-kv`,children:[(0,c.jsx)(`div`,{className:`db-kv-label`,children:`DOB`}),(0,c.jsx)(`div`,{className:`db-kv-val`,children:E.teacher?.dob||`N/A`})]}),(0,c.jsxs)(`div`,{className:`db-kv`,children:[(0,c.jsx)(`div`,{className:`db-kv-label`,children:`Address`}),(0,c.jsx)(`div`,{className:`db-kv-val`,children:E.teacher?.address||`N/A`})]}),(0,c.jsxs)(`div`,{className:`db-kv`,children:[(0,c.jsx)(`div`,{className:`db-kv-label`,children:`Class`}),(0,c.jsx)(`div`,{className:`db-kv-val`,children:E.teacher?.teacher_enrollment?.level?.name||E.teacher?.level?.name||`N/A`})]}),(0,c.jsxs)(`div`,{className:`db-kv`,children:[(0,c.jsx)(`div`,{className:`db-kv-label`,children:`Staff ID`}),(0,c.jsx)(`div`,{className:`db-kv-val`,children:E.teacher?.reg_no??`-`})]}),(0,c.jsxs)(`div`,{className:`db-kv`,children:[(0,c.jsx)(`div`,{className:`db-kv-label`,children:`Status`}),(0,c.jsxs)(`div`,{className:`db-kv-val`,style:{display:`flex`,gap:8,flexWrap:`wrap`,alignItems:`center`},children:[(0,c.jsx)(`span`,{className:`db-pill ${se(f(E.teacher))}`,children:p(f(E.teacher))}),(0,c.jsxs)(`select`,{className:`db-status-select`,value:f(E.teacher),disabled:he===E.teacher?.id,onChange:e=>Fe(E.teacher,e.target.value),title:`Change teacher access status`,children:[(0,c.jsx)(`option`,{value:`active`,children:`Active`}),(0,c.jsx)(`option`,{value:`suspended`,children:`Suspended`}),(0,c.jsx)(`option`,{value:`inactive`,children:`Inactive`}),(0,c.jsx)(`option`,{value:`resigned`,children:`Resigned`})]})]}),E.teacher?.teacher_status_reason?(0,c.jsxs)(`div`,{className:`db-muted`,style:{marginTop:6},children:[`Reason: `,E.teacher.teacher_status_reason]}):null]})]})]})}),V===`security`&&(0,c.jsx)(`div`,{className:`db-card`,children:(0,c.jsxs)(`div`,{className:`db-card-inner`,children:[(0,c.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,gap:10,flexWrap:`wrap`,marginBottom:12},children:[(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`div`,{style:{fontFamily:`Lora, serif`,fontWeight:900,color:`#1a1a2e`},children:`Login Credentials`}),(0,c.jsx)(`div`,{className:`db-muted`,children:`Returned from /teachers/view/:id (handle securely).`})]}),(0,c.jsx)(`span`,{className:`db-pill db-pill--gold`,children:`Security`})]}),(0,c.jsxs)(`div`,{className:`db-kv-grid`,children:[(0,c.jsxs)(`div`,{className:`db-kv`,children:[(0,c.jsx)(`div`,{className:`db-kv-label`,children:`Username`}),(0,c.jsx)(`div`,{className:`db-kv-val`,children:E.teacher?.username??`-`})]}),(0,c.jsxs)(`div`,{className:`db-kv`,children:[(0,c.jsx)(`div`,{className:`db-kv-label`,children:`Staff ID (Reg No)`}),(0,c.jsx)(`div`,{className:`db-kv-val`,children:E.teacher?.reg_no??`-`})]}),(0,c.jsxs)(`div`,{className:`db-kv`,style:{gridColumn:`1 / -1`},children:[(0,c.jsx)(`div`,{className:`db-kv-label`,children:`Default password`}),(0,c.jsxs)(`div`,{style:{display:`flex`,gap:10,flexWrap:`wrap`,alignItems:`center`},children:[(0,c.jsx)(`input`,{className:`db-input`,style:{flex:`1 1 320px`,minWidth:240,fontFamily:`ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace`},readOnly:!0,type:z?`text`:`password`,value:L||`N/A`}),(0,c.jsx)(`button`,{className:`db-mini-btn db-mini-btn--p`,onClick:()=>B(e=>!e),disabled:!L,title:z?`Hide password`:`Show password`,children:z?`Hide`:`Show`}),(0,c.jsx)(`button`,{className:`db-mini-btn db-mini-btn--g`,onClick:()=>{if(!L)return t(`No password to copy`);navigator.clipboard.writeText(L).then(()=>e(`Password copied!`))},disabled:!L,title:`Copy password`,children:`Copy`})]}),L?null:(0,c.jsxs)(`div`,{className:`db-muted`,style:{marginTop:8},children:[`No decrypted password returned. Confirm backend returns `,(0,c.jsx)(`code`,{children:`decrypted_password`}),`.`]})]})]})]})})]}):(0,c.jsx)(`div`,{className:`db-card`,children:(0,c.jsxs)(`div`,{className:`db-card-inner`,children:[(0,c.jsx)(`div`,{style:{fontWeight:900,color:`#1a1a2e`},children:`No teacher details available.`}),(0,c.jsx)(`div`,{className:`db-muted`,style:{marginTop:6},children:`Try closing and reopening the profile.`})]})}),(0,c.jsxs)(`div`,{style:{marginTop:12,display:`flex`,justifyContent:`space-between`,flexWrap:`wrap`,gap:10},children:[(0,c.jsx)(`div`,{className:`db-muted`,children:`Tip: Use tabs to switch between Overview and Security.`}),(0,c.jsx)(`button`,{className:`db-mini-btn`,onClick:Y,children:`Close`})]})]})]})})]})}export{m as default};