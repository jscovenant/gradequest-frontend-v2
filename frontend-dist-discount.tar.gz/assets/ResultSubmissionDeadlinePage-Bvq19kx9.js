import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{p as t}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as n,E as r,P as i,d as a,f as o,u as s}from"./index-D6TxbaCx.js";var c=e(),l=t();function u(e){if(!e)return`Not set`;let t=new Date(e);return Number.isNaN(t.getTime())?e:t.toLocaleDateString(void 0,{year:`numeric`,month:`short`,day:`numeric`})}function d(e){if(!e)return{label:`No deadline`,color:`var(--bs-secondary, rgb(255,200,87))`,bg:`rgba(255,200,87,0.12)`,border:`rgba(255,200,87,0.22)`};let t=new Date,n=new Date(e).getTime()-t.getTime(),r=Math.ceil(n/(1e3*60*60*24));return r<0?{label:`Overdue`,color:`var(--bs-danger, rgb(239,68,68))`,bg:`rgba(239,68,68,0.10)`,border:`rgba(239,68,68,0.20)`}:r<=3?{label:`Due soon`,color:`var(--bs-warning, rgb(245,158,11))`,bg:`rgba(245,158,11,0.12)`,border:`rgba(245,158,11,0.22)`}:{label:`Scheduled`,color:`var(--bs-success, rgb(34,197,94))`,bg:`rgba(34,197,94,0.10)`,border:`rgba(34,197,94,0.18)`}}function f(e){return e===`published`?{color:`var(--bs-success, rgb(34,197,94))`,bg:`rgba(34,197,94,0.10)`}:e===`approved`?{color:`var(--bs-info, rgb(59,130,246))`,bg:`rgba(59,130,246,0.10)`}:e===`computed`?{color:`var(--bs-warning, rgb(245,158,11))`,bg:`rgba(245,158,11,0.10)`}:{color:`var(--bs-primary, rgb(211,0,176))`,bg:`rgba(211,0,176,0.08)`}}function p(){let[e,t]=(0,c.useState)(!1),[p,m]=(0,c.useState)(!0),[h,g]=(0,c.useState)(!1),[_,v]=(0,c.useState)([]),[y,b]=(0,c.useState)(null),[x,S]=(0,c.useState)(``),[C,w]=(0,c.useState)(``),[T,E]=(0,c.useState)(``),[D,O]=(0,c.useState)(``),[k,A]=(0,c.useState)(!1),[j,M]=(0,c.useState)(null),[N,P]=(0,c.useState)(``),[F,I]=(0,c.useState)(null),L=async()=>{m(!0),b(null);try{v((await i.get(`/admin/result-batches`,{params:{status:C||void 0,term:T||void 0,session:D||void 0}})).data.data||[])}catch(e){b(e?.response?.data?.message||`Unable to load result batches.`),v([])}finally{m(!1)}};(0,c.useEffect)(()=>{L()},[C,T,D]);let R=(0,c.useMemo)(()=>{let e=x.trim().toLowerCase();return e?_.filter(t=>[t.class_name,t.term,t.session,t.status,String(t.id)].filter(Boolean).join(` `).toLowerCase().includes(e)):_},[_,x]),z=(0,c.useMemo)(()=>Array.from(new Set(_.map(e=>e.term).filter(Boolean))),[_]),B=(0,c.useMemo)(()=>Array.from(new Set(_.map(e=>e.session).filter(Boolean))),[_]),V=e=>{M(e),P(e.submission_deadline?e.submission_deadline.slice(0,10):``),A(!0),I(null)},H=()=>{h||(A(!1),M(null),P(``))},U=async()=>{if(!(!j||!N)){g(!0),b(null),I(null);try{let e=await i.post(`/admin/result-batches/${j.id}/set-deadline`,{submission_deadline:N});I(e.data.message||`Deadline updated successfully.`),v(t=>t.map(t=>t.id===j.id?{...t,submission_deadline:e.data.data.submission_deadline}:t)),M(t=>t&&{...t,submission_deadline:e.data.data.submission_deadline}),setTimeout(()=>{A(!1)},700)}catch(e){b(e?.response?.data?.message||`Unable to update submission deadline.`)}finally{g(!1)}}},W=_.filter(e=>!!e.submission_deadline).length,G=_.filter(e=>!e.submission_deadline).length,K=_.filter(e=>e.status===`published`).length,q=_.filter(e=>e.status===`draft`).length;return(0,l.jsxs)(l.Fragment,{children:[(0,l.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');

        .rd-main {
          background: #F8FAFC;
          min-height: 100vh;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          padding: 24px 28px 0;
        }

        .rd-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          color: #fff;
          border-radius: 18px;
          padding: 32px 36px;
          position: relative;
          overflow: hidden;
          margin-bottom: 24px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
        }

        .rd-hero-glow {
          position: absolute;
          width: 320px;
          height: 320px;
          top: -70px;
          right: -70px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.15) 0%, transparent 68%);
        }

        .rd-hero-inner {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: 20px;
          flex-wrap: wrap;
        }

        .rd-kicker {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: .04em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.20);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius: 999px;
          padding: 4px 12px;
          margin-bottom: 12px;
        }

        .rd-kicker-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #10B981;
        }

        .rd-title {
          font-size: 26px;
          font-weight: 800;
          line-height: 1.1;
          margin: 0 0 8px;
          color: #fff;
        }

        .rd-title em {
          color: #FBBF24;
          font-style: normal;
        }

        .rd-sub {
          color: #CBD5E1;
          font-size: 13.5px;
          max-width: 580px;
          line-height: 1.6;
          margin: 0;
        }

        .rd-hero-card {
          background: rgba(255,255,255,0.08);
          border: 1px solid rgba(255,255,255,0.15);
          border-radius: 14px;
          padding: 18px 20px;
          min-width: 250px;
          backdrop-filter: blur(10px);
        }

        .rd-hero-card-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 16px;
        }

        .rd-hero-card-row + .rd-hero-card-row {
          margin-top: 12px;
          padding-top: 12px;
          border-top: 1px solid rgba(255,255,255,0.08);
        }

        .rd-hero-label {
          font-size: 12px;
          color: #CBD5E1;
        }

        .rd-hero-value {
          font-size: 18px;
          color: #FBBF24;
          font-weight: 800;
        }

        .rd-stats {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 16px;
          margin-bottom: 24px;
        }

        @media (max-width: 1199.98px) {
          .rd-stats { grid-template-columns: repeat(2, 1fr); }
        }

        @media (max-width: 575.98px) {
          .rd-stats { grid-template-columns: 1fr; }
        }

        .rd-stat {
          background: #fff;
          border: 1px solid #E2E8F0;
          border-radius: 16px;
          padding: 20px 22px;
          box-shadow: 0 4px 16px rgba(15,39,68,0.03);
        }

        .rd-stat-label {
          font-size: 11.5px;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.04em;
          color: #64748B;
          margin-bottom: 6px;
        }

        .rd-stat-value {
          font-size: 26px;
          font-weight: 800;
          line-height: 1;
          color: #0F2744;
        }

        .rd-stat-sub {
          margin-top: 12px;
          padding-top: 12px;
          border-top: 1px solid #E2E8F0;
          font-size: 12px;
          color: #64748B;
        }

        .rd-panel {
          background: #fff;
          border: 1px solid #E2E8F0;
          border-radius: 16px;
          overflow: hidden;
          margin-bottom: 24px;
          box-shadow: 0 4px 16px rgba(15,39,68,0.03);
        }

        .rd-panel-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 14px;
          padding: 18px 20px;
          border-bottom: 1px solid #E2E8F0;
          flex-wrap: wrap;
        }

        .rd-panel-title {
          font-size: 16px;
          font-weight: 800;
          color: #0F2744;
          margin: 0;
        }

        .rd-panel-sub {
          font-size: 12px;
          color: #9a8a7a;
          margin: 2px 0 0;
        }

        .rd-toolbar {
          display: grid;
          grid-template-columns: 1.2fr repeat(3, .7fr) auto;
          gap: 12px;
          padding: 18px 22px;
          border-bottom: 1px solid rgba(0,0,0,0.06);
          background: rgba(252,248,248,0.85);
        }

        @media (max-width: 991.98px) {
          .rd-toolbar {
            grid-template-columns: 1fr 1fr;
          }
        }

        @media (max-width: 575.98px) {
          .rd-toolbar {
            grid-template-columns: 1fr;
          }
        }

        .rd-input,
        .rd-select {
          width: 100%;
          border: 1px solid var(--rd-border);
          border-radius: 10px;
          padding: 11px 12px;
          font-size: 13px;
          color: var(--rd-dark);
          background: #fff;
          outline: none;
          transition: border-color .2s, box-shadow .2s;
        }

        .rd-input:focus,
        .rd-select:focus {
          border-color: rgba(255,200,87,0.55);
          box-shadow: 0 0 0 4px rgba(255,200,87,0.10);
        }

        .rd-btn,
        .rd-btn-outline {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 7px;
          border-radius: 10px;
          padding: 11px 16px;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          transition: all .2s ease;
          text-decoration: none;
          white-space: nowrap;
        }

        .rd-btn {
          border: none;
          background: var(--rd-accent);
          color: var(--rd-dark);
        }

        .rd-btn:hover {
          background: #ffe0a0;
          transform: translateY(-1px);
        }

        .rd-btn-outline {
          border: 1px solid var(--rd-border);
          background: #fff;
          color: #7a6a5a;
        }

        .rd-btn-outline:hover {
          background: #f7f3ed;
        }

        .rd-table-wrap {
          overflow: auto;
        }

        .rd-table {
          width: 100%;
          border-collapse: collapse;
        }

        .rd-table th {
          text-align: left;
          font-size: 11px;
          text-transform: uppercase;
          letter-spacing: .09em;
          color: #9a8a7a;
          padding: 12px 16px;
          background: var(--rd-light);
          border-bottom: 1px solid rgba(0,0,0,0.06);
          white-space: nowrap;
        }

        .rd-table td {
          padding: 14px 16px;
          border-bottom: 1px solid rgba(0,0,0,0.06);
          font-size: 13px;
          color: #50485a;
          vertical-align: middle;
        }

        .rd-table tbody tr:hover {
          background: rgba(252,248,248,0.7);
        }

        .rd-class {
          font-weight: 700;
          color: var(--rd-dark);
        }

        .rd-muted {
          color: #9a8a7a;
          font-size: 12px;
        }

        .rd-pill {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          border-radius: 999px;
          padding: 5px 10px;
          font-size: 11px;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: .08em;
        }

        .rd-deadline-box {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          border: 1px solid var(--dd-border);
          background: var(--dd-bg);
          color: var(--dd-color);
          border-radius: 999px;
          padding: 6px 10px;
          font-size: 12px;
          font-weight: 600;
        }

        .rd-action-link {
          border: none;
          background: transparent;
          color: var(--rd-primary);
          font-size: 12.5px;
          font-weight: 700;
          cursor: pointer;
          padding: 0;
        }

        .rd-action-link:hover {
          text-decoration: underline;
        }

        .rd-empty {
          padding: 44px 20px;
          text-align: center;
          color: #9a8a7a;
          font-size: 13px;
        }

        .rd-error {
          margin: 0 22px 18px;
          display: flex;
          gap: 10px;
          align-items: flex-start;
          border: 1px solid rgba(239,68,68,0.20);
          background: rgba(239,68,68,0.06);
          color: var(--rd-danger);
          border-radius: 10px;
          padding: 12px 14px;
          font-size: 13px;
        }

        .rd-success {
          margin: 0 22px 18px;
          display: flex;
          gap: 10px;
          align-items: flex-start;
          border: 1px solid rgba(34,197,94,0.20);
          background: rgba(34,197,94,0.06);
          color: var(--rd-success);
          border-radius: 10px;
          padding: 12px 14px;
          font-size: 13px;
        }

        .rd-modal-backdrop {
          position: fixed;
          inset: 0;
          background: rgba(5,0,8,0.45);
          backdrop-filter: blur(3px);
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 20px;
          z-index: 1060;
        }

        .rd-modal {
          width: 100%;
          max-width: 520px;
          background: #fff;
          border: 1px solid var(--rd-border);
          border-radius: 18px;
          overflow: hidden;
          box-shadow: 0 24px 60px rgba(0,0,0,0.18);
        }

        .rd-modal-head {
          padding: 20px 22px 16px;
          border-bottom: 1px solid rgba(0,0,0,0.06);
        }

        .rd-modal-title {
          margin: 0;
          font-family: 'Playfair Display', serif;
          font-size: 22px;
          color: var(--rd-dark);
        }

        .rd-modal-sub {
          margin: 6px 0 0;
          font-size: 13px;
          color: #8f7f70;
        }

        .rd-modal-body {
          padding: 20px 22px;
        }

        .rd-field {
          margin-bottom: 16px;
        }

        .rd-label {
          display: block;
          font-size: 12px;
          font-weight: 700;
          color: #7a6a5a;
          margin-bottom: 8px;
          letter-spacing: .04em;
          text-transform: uppercase;
        }

        .rd-meta-card {
          border: 1px solid var(--rd-border);
          background: var(--rd-light);
          border-radius: 12px;
          padding: 14px;
          margin-bottom: 16px;
        }

        .rd-meta-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 12px;
        }

        .rd-meta-item small {
          display: block;
          font-size: 11px;
          color: #9a8a7a;
          text-transform: uppercase;
          letter-spacing: .08em;
          margin-bottom: 4px;
        }

        .rd-meta-item strong {
          font-size: 13px;
          color: var(--rd-dark);
        }

        .rd-modal-foot {
          padding: 16px 22px 20px;
          border-top: 1px solid rgba(0,0,0,0.06);
          display: flex;
          justify-content: flex-end;
          gap: 10px;
          flex-wrap: wrap;
        }

        .rd-skeleton {
          height: 14px;
          border-radius: 7px;
          background: linear-gradient(90deg, #f0ebe3 25%, #e8e0d5 50%, #f0ebe3 75%);
          background-size: 200% 100%;
          animation: rdSkeleton 1.4s ease infinite;
        }

        @keyframes rdSkeleton {
          from { background-position: 200% 0; }
          to { background-position: -200% 0; }
        }
      `}),(0,l.jsx)(o,{sidebarOpen:e,setSidebarOpen:t}),(0,l.jsx)(n,{title:`Result Submission Deadlines`}),(0,l.jsx)(`div`,{className:`container-fluid`,children:(0,l.jsxs)(`div`,{className:`row`,children:[(0,l.jsx)(a,{sidebarOpen:e}),(0,l.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto rd-main`,children:[p&&(0,l.jsx)(r,{message:`Loading result batches…`}),(0,l.jsxs)(`div`,{className:`rd-hero`,children:[(0,l.jsx)(`div`,{className:`rd-hero-glow`,"aria-hidden":`true`}),(0,l.jsxs)(`div`,{className:`rd-hero-inner`,children:[(0,l.jsxs)(`div`,{children:[(0,l.jsxs)(`div`,{className:`rd-kicker`,children:[(0,l.jsx)(`span`,{className:`rd-kicker-dot`}),`Result Monitoring`]}),(0,l.jsxs)(`h1`,{className:`rd-title`,children:[`Set submission `,(0,l.jsx)(`em`,{children:`deadlines`}),` for result batches.`]}),(0,l.jsx)(`p`,{className:`rd-sub`,children:`Give each class batch a clear deadline so your monitoring engine can detect incomplete uploads, warn the academic team, and surface overdue result submissions before publication.`})]}),(0,l.jsxs)(`div`,{className:`rd-hero-card`,children:[(0,l.jsxs)(`div`,{className:`rd-hero-card-row`,children:[(0,l.jsx)(`span`,{className:`rd-hero-label`,children:`Batches with deadline`}),(0,l.jsx)(`span`,{className:`rd-hero-value`,children:W})]}),(0,l.jsxs)(`div`,{className:`rd-hero-card-row`,children:[(0,l.jsx)(`span`,{className:`rd-hero-label`,children:`No deadline yet`}),(0,l.jsx)(`span`,{className:`rd-hero-value`,children:G})]}),(0,l.jsxs)(`div`,{className:`rd-hero-card-row`,children:[(0,l.jsx)(`span`,{className:`rd-hero-label`,children:`Published batches`}),(0,l.jsx)(`span`,{className:`rd-hero-value`,children:K})]})]})]})]}),(0,l.jsxs)(`div`,{className:`rd-stats`,children:[(0,l.jsxs)(`div`,{className:`rd-stat`,children:[(0,l.jsx)(`div`,{className:`rd-stat-label`,children:`Total Batches`}),(0,l.jsx)(`div`,{className:`rd-stat-value`,children:_.length}),(0,l.jsx)(`div`,{className:`rd-stat-sub`,children:`All fetched result batches`})]}),(0,l.jsxs)(`div`,{className:`rd-stat`,children:[(0,l.jsx)(`div`,{className:`rd-stat-label`,children:`Draft`}),(0,l.jsx)(`div`,{className:`rd-stat-value`,children:q}),(0,l.jsx)(`div`,{className:`rd-stat-sub`,children:`Still open for entry`})]}),(0,l.jsxs)(`div`,{className:`rd-stat`,children:[(0,l.jsx)(`div`,{className:`rd-stat-label`,children:`With Deadline`}),(0,l.jsx)(`div`,{className:`rd-stat-value`,children:W}),(0,l.jsx)(`div`,{className:`rd-stat-sub`,children:`Ready for monitoring`})]}),(0,l.jsxs)(`div`,{className:`rd-stat`,children:[(0,l.jsx)(`div`,{className:`rd-stat-label`,children:`Without Deadline`}),(0,l.jsx)(`div`,{className:`rd-stat-value`,children:G}),(0,l.jsx)(`div`,{className:`rd-stat-sub`,children:`Needs admin action`})]})]}),(0,l.jsxs)(`div`,{className:`rd-panel`,children:[(0,l.jsxs)(`div`,{className:`rd-panel-head`,children:[(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`h2`,{className:`rd-panel-title`,children:`Result Batch Deadlines`}),(0,l.jsx)(`p`,{className:`rd-panel-sub`,children:`Search, filter, and assign submission deadlines batch by batch.`})]}),(0,l.jsxs)(`button`,{className:`rd-btn-outline`,onClick:L,children:[(0,l.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,children:[(0,l.jsx)(`path`,{d:`M12 7A5 5 0 112 7`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,l.jsx)(`path`,{d:`M12 3v4h-4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),`Refresh`]})]}),(0,l.jsxs)(`div`,{className:`rd-toolbar`,children:[(0,l.jsx)(`input`,{className:`rd-input`,placeholder:`Search by class, session, term, batch ID...`,value:x,onChange:e=>S(e.target.value)}),(0,l.jsxs)(`select`,{className:`rd-select`,value:C,onChange:e=>w(e.target.value),children:[(0,l.jsx)(`option`,{value:``,children:`All statuses`}),(0,l.jsx)(`option`,{value:`draft`,children:`Draft`}),(0,l.jsx)(`option`,{value:`computed`,children:`Computed`}),(0,l.jsx)(`option`,{value:`approved`,children:`Approved`}),(0,l.jsx)(`option`,{value:`published`,children:`Published`})]}),(0,l.jsxs)(`select`,{className:`rd-select`,value:T,onChange:e=>E(e.target.value),children:[(0,l.jsx)(`option`,{value:``,children:`All terms`}),z.map(e=>(0,l.jsx)(`option`,{value:e,children:e},e))]}),(0,l.jsxs)(`select`,{className:`rd-select`,value:D,onChange:e=>O(e.target.value),children:[(0,l.jsx)(`option`,{value:``,children:`All sessions`}),B.map(e=>(0,l.jsx)(`option`,{value:e,children:e},e))]}),(0,l.jsx)(`button`,{className:`rd-btn-outline`,onClick:()=>{S(``),w(``),E(``),O(``)},children:`Reset`})]}),y&&(0,l.jsxs)(`div`,{className:`rd-error`,children:[(0,l.jsxs)(`svg`,{width:`15`,height:`15`,viewBox:`0 0 16 16`,fill:`none`,style:{flexShrink:0},children:[(0,l.jsx)(`circle`,{cx:`8`,cy:`8`,r:`7`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,l.jsx)(`path`,{d:`M8 5v3.5M8 10.5v.5`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`})]}),y]}),(0,l.jsx)(`div`,{className:`rd-table-wrap`,children:(0,l.jsxs)(`table`,{className:`rd-table`,children:[(0,l.jsx)(`thead`,{children:(0,l.jsxs)(`tr`,{children:[(0,l.jsx)(`th`,{children:`Class`}),(0,l.jsx)(`th`,{children:`Session / Term`}),(0,l.jsx)(`th`,{children:`Status`}),(0,l.jsx)(`th`,{children:`Deadline`}),(0,l.jsx)(`th`,{children:`Updated`}),(0,l.jsx)(`th`,{})]})}),(0,l.jsx)(`tbody`,{children:p?Array.from({length:6}).map((e,t)=>(0,l.jsxs)(`tr`,{children:[(0,l.jsx)(`td`,{children:(0,l.jsx)(`div`,{className:`rd-skeleton`,style:{width:120}})}),(0,l.jsx)(`td`,{children:(0,l.jsx)(`div`,{className:`rd-skeleton`,style:{width:140}})}),(0,l.jsx)(`td`,{children:(0,l.jsx)(`div`,{className:`rd-skeleton`,style:{width:80}})}),(0,l.jsx)(`td`,{children:(0,l.jsx)(`div`,{className:`rd-skeleton`,style:{width:120}})}),(0,l.jsx)(`td`,{children:(0,l.jsx)(`div`,{className:`rd-skeleton`,style:{width:100}})}),(0,l.jsx)(`td`,{children:(0,l.jsx)(`div`,{className:`rd-skeleton`,style:{width:70}})})]},t)):R.length===0?(0,l.jsx)(`tr`,{children:(0,l.jsx)(`td`,{colSpan:6,className:`rd-empty`,children:`No result batches found for the selected filters.`})}):R.map(e=>{let t=d(e.submission_deadline),n=f(e.status);return(0,l.jsxs)(`tr`,{children:[(0,l.jsxs)(`td`,{children:[(0,l.jsx)(`div`,{className:`rd-class`,children:e.class_name||`Class ${e.class_id}`}),(0,l.jsxs)(`div`,{className:`rd-muted`,children:[`Batch #`,e.id]})]}),(0,l.jsxs)(`td`,{children:[(0,l.jsx)(`div`,{children:e.session}),(0,l.jsx)(`div`,{className:`rd-muted`,children:e.term})]}),(0,l.jsx)(`td`,{children:(0,l.jsx)(`span`,{className:`rd-pill`,style:{color:n.color,background:n.bg},children:e.status})}),(0,l.jsxs)(`td`,{children:[(0,l.jsx)(`span`,{className:`rd-deadline-box`,style:{"--dd-color":t.color,"--dd-bg":t.bg,"--dd-border":t.border},children:u(e.submission_deadline)}),(0,l.jsx)(`div`,{className:`rd-muted`,style:{marginTop:6},children:t.label})]}),(0,l.jsx)(`td`,{children:(0,l.jsx)(`div`,{children:u(e.updated_at)})}),(0,l.jsx)(`td`,{style:{textAlign:`right`},children:(0,l.jsx)(`button`,{className:`rd-action-link`,onClick:()=>V(e),children:e.submission_deadline?`Edit deadline`:`Set deadline`})})]},e.id)})})]})})]}),(0,l.jsx)(s,{})]})]})}),k&&j&&(0,l.jsx)(`div`,{className:`rd-modal-backdrop`,onClick:H,children:(0,l.jsxs)(`div`,{className:`rd-modal`,onClick:e=>e.stopPropagation(),children:[(0,l.jsxs)(`div`,{className:`rd-modal-head`,children:[(0,l.jsx)(`h3`,{className:`rd-modal-title`,children:`Set submission deadline`}),(0,l.jsx)(`p`,{className:`rd-modal-sub`,children:`This deadline will be used by the monitoring engine to track incomplete result uploads.`})]}),(0,l.jsxs)(`div`,{className:`rd-modal-body`,children:[y&&(0,l.jsxs)(`div`,{className:`rd-error`,style:{margin:`0 0 16px`},children:[(0,l.jsxs)(`svg`,{width:`15`,height:`15`,viewBox:`0 0 16 16`,fill:`none`,style:{flexShrink:0},children:[(0,l.jsx)(`circle`,{cx:`8`,cy:`8`,r:`7`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,l.jsx)(`path`,{d:`M8 5v3.5M8 10.5v.5`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`})]}),y]}),F&&(0,l.jsxs)(`div`,{className:`rd-success`,style:{margin:`0 0 16px`},children:[(0,l.jsxs)(`svg`,{width:`15`,height:`15`,viewBox:`0 0 16 16`,fill:`none`,style:{flexShrink:0},children:[(0,l.jsx)(`circle`,{cx:`8`,cy:`8`,r:`7`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,l.jsx)(`path`,{d:`M5 8.5l2 2 4-4`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),F]}),(0,l.jsx)(`div`,{className:`rd-meta-card`,children:(0,l.jsxs)(`div`,{className:`rd-meta-grid`,children:[(0,l.jsxs)(`div`,{className:`rd-meta-item`,children:[(0,l.jsx)(`small`,{children:`Class`}),(0,l.jsx)(`strong`,{children:j.class_name||`Class ${j.class_id}`})]}),(0,l.jsxs)(`div`,{className:`rd-meta-item`,children:[(0,l.jsx)(`small`,{children:`Batch`}),(0,l.jsxs)(`strong`,{children:[`#`,j.id]})]}),(0,l.jsxs)(`div`,{className:`rd-meta-item`,children:[(0,l.jsx)(`small`,{children:`Session`}),(0,l.jsx)(`strong`,{children:j.session})]}),(0,l.jsxs)(`div`,{className:`rd-meta-item`,children:[(0,l.jsx)(`small`,{children:`Term`}),(0,l.jsx)(`strong`,{children:j.term})]})]})}),(0,l.jsxs)(`div`,{className:`rd-field`,children:[(0,l.jsx)(`label`,{className:`rd-label`,children:`Submission deadline`}),(0,l.jsx)(`input`,{type:`date`,className:`rd-input`,value:N,onChange:e=>P(e.target.value),min:new Date().toISOString().slice(0,10)})]})]}),(0,l.jsxs)(`div`,{className:`rd-modal-foot`,children:[(0,l.jsx)(`button`,{className:`rd-btn-outline`,onClick:H,disabled:h,children:`Cancel`}),(0,l.jsx)(`button`,{className:`rd-btn`,onClick:U,disabled:h||!N,children:h?`Saving...`:j.submission_deadline?`Update deadline`:`Set deadline`})]})]})})]})}export{p as default};