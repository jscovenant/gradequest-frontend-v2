import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{C as t,p as n}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{B as r,C as i,P as a,d as o,f as s,u as c}from"./index-D6TxbaCx.js";var l=e();const u={list:e=>a.get(`/support/tickets`,{params:e}),create:e=>a.post(`/support/tickets`,e),show:e=>a.get(`/support/tickets/${e}`),reply:(e,t,n=!1)=>a.post(`/support/tickets/${e}/replies`,{message:t,internal_note:n}),update:(e,t)=>a.patch(`/support/tickets/${e}`,t),assign:(e,t)=>a.patch(`/support/tickets/${e}/assign`,{assigned_to:t}),assignees:()=>a.get(`/support/assignees`)};var d=n(),f={open:`Open`,in_progress:`In Progress`,waiting_for_school:`Awaiting Reply`,resolved:`Resolved`,closed:`Closed`},p={open:`db-badge--red`,in_progress:`db-badge--blue`,waiting_for_school:`db-badge--amber`,resolved:`db-badge--green`,closed:`db-badge--gray`},m=[`technical`,`billing`,`results`,`account`,`training`,`other`],h=[`low`,`normal`,`high`,`urgent`],g=e=>e?e.name||`${e.firstname||``} ${e.surname||``}`.trim()||e.email:`Unassigned`,_=e=>e?new Date(e).toLocaleString():``;function v(){let e=r(),n=[`super-admin`,`platform-staff`].includes(String(e?.role||``).toLowerCase()),[a,v]=t(),[y,b]=(0,l.useState)(!1),[x,S]=(0,l.useState)([]),[C,w]=(0,l.useState)(null),[T,E]=(0,l.useState)([]),[D,O]=(0,l.useState)(!0),[k,A]=(0,l.useState)(!1),[j,M]=(0,l.useState)(``),[N,P]=(0,l.useState)(``),[F,I]=(0,l.useState)(``),[L,R]=(0,l.useState)(``),[z,B]=(0,l.useState)(!1),[V,H]=(0,l.useState)(!1),[U,W]=(0,l.useState)({subject:``,category:`technical`,priority:`normal`,message:``}),G=(0,l.useMemo)(()=>x.filter(e=>![`resolved`,`closed`].includes(e.status)).length,[x]),K=(0,l.useMemo)(()=>x.filter(e=>[`resolved`,`closed`].includes(e.status)).length,[x]),q=async()=>{O(!0),M(``);try{let{data:e}=await u.list({...N?{search:N}:{},...F?{status:F}:{}});S(e.tickets?.data||[]);let t=a.get(`ticket`);t&&await J(t)}catch(e){M(e.response?.data?.message||`Unable to load support tickets.`)}finally{O(!1)}},J=async e=>{M(``);try{let{data:t}=await u.show(e);w(t.ticket),v({ticket:e})}catch(e){M(e.response?.data?.message||`Unable to open this ticket.`)}};(0,l.useEffect)(()=>{q()},[F]),(0,l.useEffect)(()=>{n&&u.assignees().then(({data:e})=>E(e.assignees||[])).catch(()=>void 0)},[n]);let Y=async e=>{e.preventDefault(),A(!0),M(``);try{let{data:e}=await u.create(U);H(!1),W({subject:``,category:`technical`,priority:`normal`,message:``}),await q(),await J(e.ticket.public_id)}catch(e){M(e.response?.data?.message||Object.values(e.response?.data?.errors||{})?.flat()?.[0]||`Unable to create ticket.`)}finally{A(!1)}},X=async e=>{if(e.preventDefault(),!(!C||!L.trim())){A(!0),M(``);try{let{data:e}=await u.reply(C.public_id,L,z);w(e.ticket),R(``),B(!1),await q()}catch(e){M(e.response?.data?.message||`Unable to send reply.`)}finally{A(!1)}}},Z=async e=>{if(C){A(!0);try{await u.update(C.public_id,e),await J(C.public_id),await q()}catch(e){M(e.response?.data?.message||`Unable to update ticket.`)}finally{A(!1)}}},Q=async e=>{if(C){A(!0);try{await u.assign(C.public_id,e?Number(e):null),await J(C.public_id),await q()}catch(e){M(e.response?.data?.message||`Unable to assign ticket.`)}finally{A(!1)}}};return(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(i,{title:n?`Support Desk`:`Support & Helpdesk`}),(0,d.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');

        :root {
          --sp-dark: #0F2744;
          --sp-accent: #D97706;
          --sp-accent-dim: rgba(217, 119, 6, 0.10);
          --sp-accent-border: rgba(217, 119, 6, 0.25);
          --sp-light: #FFFFFF;
          --sp-border: #E2E8F0;
        }

        .db-main {
          min-height: 100vh;
          margin-left: 280px;
          width: calc(100% - 280px);
          padding: max(96px, calc(78px + env(safe-area-inset-top))) 28px 48px;
          background: #F8FAFC;
          color: #0F172A;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
        }

        @media (max-width: 1199px) {
          .db-main {
            margin-left: 0;
            width: 100%;
            padding: max(88px, calc(72px + env(safe-area-inset-top))) 16px 32px;
          }
        }

        /* Hero */
        .db-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 18px;
          padding: 32px 36px;
          position: relative;
          overflow: hidden;
          margin-bottom: 24px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
        }
        .db-hero-glow {
          position: absolute;
          top: -90px;
          right: -40px;
          width: 380px;
          height: 380px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.15), transparent 70%);
          pointer-events: none;
        }
        .db-hero-inner {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 28px;
          flex-wrap: wrap;
        }
        .db-kicker {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.20);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius: 999px;
          padding: 4px 12px;
          margin-bottom: 12px;
        }
        .db-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #10B981;
        }
        .db-title {
          font-size: 26px;
          font-weight: 800;
          color: #fff;
          line-height: 1.15;
          margin: 0 0 8px;
        }
        .db-title em {
          color: #FBBF24;
          font-style: normal;
        }
        .db-hero-sub {
          font-size: 13.5px;
          color: #CBD5E1;
          line-height: 1.6;
          max-width: 600px;
          margin: 0;
        }
        .db-btn-gold {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          background: #D97706;
          color: #FFFFFF;
          font-weight: 700;
          font-size: 13px;
          padding: 9px 18px;
          border-radius: 10px;
          border: none;
          transition: all 0.2s ease;
          cursor: pointer;
        }
        .db-btn-gold:hover {
          background: #B45309;
          transform: translateY(-1px);
          color: #FFFFFF;
        }
        .db-hero-stats {
          background: rgba(255,255,255,0.06);
          border: 1px solid rgba(255,255,255,0.1);
          border-radius: 14px;
          padding: 16px 20px;
          min-width: 260px;
          backdrop-filter: blur(10px);
        }
        .db-hero-row {
          display: flex;
          justify-content: space-between;
          gap: 24px;
          padding: 6px 0;
          color: #94a3b8;
          font-size: 12.5px;
        }
        .db-hero-row + .db-hero-row {
          border-top: 1px solid rgba(255,255,255,0.08);
        }
        .db-hero-row strong {
          font-family: "Playfair Display", Georgia, serif;
          color: #fff;
          font-size: 16px;
        }

        /* KPI Cards */
        .db-stats {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
          gap: 16px;
          margin-bottom: 24px;
        }
        .db-stat {
          background: #fff;
          border: 1px solid var(--sp-border);
          border-radius: 16px;
          padding: 20px;
          position: relative;
          overflow: hidden;
          transition: transform 0.2s, box-shadow 0.2s;
        }
        .db-stat:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 24px rgba(5,0,8,0.06);
        }
        .db-stat::before {
          content: "";
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          height: 3px;
          background: var(--sc, #c9a84c);
        }
        .db-stat-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 12px;
        }
        .db-stat-label {
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          color: #7a6a5a;
        }
        .db-stat-icon {
          width: 36px;
          height: 36px;
          border-radius: 10px;
          background: var(--si, rgba(201,168,76,0.12));
          color: var(--sc, #c9a84c);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 16px;
        }
        .db-stat-val {
          font-family: "Playfair Display", Georgia, serif;
          font-size: 26px;
          font-weight: 700;
          color: #1a1a2e;
          line-height: 1.1;
        }
        .db-stat-sub {
          font-size: 11.5px;
          color: #9a8a7a;
          margin-top: 4px;
        }

        /* Panel */
        .db-panel {
          background: #fff;
          border: 1px solid var(--sp-border);
          border-radius: 16px;
          box-shadow: 0 4px 20px rgba(5,0,8,0.04);
          overflow: hidden;
        }
        .db-panel-head {
          padding: 18px 22px;
          border-bottom: 1px solid var(--sp-border);
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 16px;
          flex-wrap: wrap;
          background: #faf8f5;
        }
        .db-panel-title {
          font-family: "Playfair Display", Georgia, serif;
          font-size: 16px;
          font-weight: 700;
          color: #1a1a2e;
          margin: 0;
        }
        .db-panel-sub {
          font-size: 11.5px;
          color: #7a6a5a;
          margin: 2px 0 0;
        }

        /* Badges */
        .db-badge {
          display: inline-flex;
          align-items: center;
          gap: 5px;
          padding: 4px 10px;
          border-radius: 999px;
          font-size: 11.5px;
          font-weight: 700;
          white-space: nowrap;
        }
        .db-badge--blue { background: rgba(59,130,246,0.12); color: #1d4ed8; }
        .db-badge--green { background: rgba(34,197,94,0.14); color: #15803d; }
        .db-badge--amber { background: rgba(245,158,11,0.14); color: #b45309; }
        .db-badge--red { background: rgba(239,68,68,0.12); color: #dc2626; }
        .db-badge--gray { background: rgba(100,116,139,0.14); color: #475569; }

        /* Ticket card list */
        .sp-ticket-item {
          width: 100%;
          text-align: left;
          background: #fff;
          border: none;
          border-bottom: 1px solid var(--sp-border);
          padding: 16px 20px;
          cursor: pointer;
          transition: all 0.15s ease;
          display: block;
        }
        .sp-ticket-item:hover {
          background: #faf8f5;
        }
        .sp-ticket-item--active {
          background: rgba(255,200,87,0.1) !important;
          border-left: 4px solid var(--sp-accent);
        }

        /* Modal */
        .sp-modal-overlay {
          position: fixed;
          inset: 0;
          background: rgba(5,0,8,0.65);
          backdrop-filter: blur(4px);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1050;
          padding: 20px;
        }
        .sp-modal {
          background: #fff;
          border-radius: 18px;
          border: 1px solid var(--sp-border);
          box-shadow: 0 20px 48px rgba(5,0,8,0.25);
          width: 100%;
          max-width: 580px;
          overflow: hidden;
          animation: spModalIn 0.2s ease-out;
        }
        @keyframes spModalIn {
          from { opacity: 0; transform: scale(0.96) translateY(8px); }
          to { opacity: 1; transform: scale(1) translateY(0); }
        }
        .sp-modal-head {
          padding: 20px 24px;
          background: linear-gradient(135deg, #050008 0%, #140a20 100%);
          color: #fff;
          display: flex;
          align-items: center;
          justify-content: space-between;
        }
        .sp-modal-title {
          font-family: "Playfair Display", Georgia, serif;
          font-size: 18px;
          font-weight: 700;
          margin: 0;
        }
        .sp-modal-close {
          background: rgba(255,255,255,0.1);
          border: none;
          color: #fff;
          width: 32px;
          height: 32px;
          border-radius: 8px;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          transition: background 0.2s;
        }
        .sp-modal-close:hover {
          background: rgba(255,255,255,0.2);
        }
        .sp-modal-body {
          padding: 24px;
        }
        .sp-modal-foot {
          padding: 16px 24px;
          background: #faf8f5;
          border-top: 1px solid var(--sp-border);
          display: flex;
          justify-content: flex-end;
          gap: 10px;
        }
      `}),(0,d.jsx)(s,{sidebarOpen:y,setSidebarOpen:b,title:n?`Support Desk`:`SchoolProfit Support`}),(0,d.jsx)(`div`,{className:`container-fluid`,children:(0,d.jsxs)(`div`,{className:`row`,children:[(0,d.jsx)(o,{sidebarOpen:y,setSidebarOpen:b}),(0,d.jsxs)(`main`,{className:`db-main d-flex flex-column`,children:[(0,d.jsxs)(`div`,{className:`db-hero`,children:[(0,d.jsx)(`div`,{className:`db-hero-glow`}),(0,d.jsxs)(`div`,{className:`db-hero-inner`,children:[(0,d.jsxs)(`div`,{children:[(0,d.jsxs)(`div`,{className:`db-kicker`,children:[(0,d.jsx)(`span`,{className:`db-dot`}),n?`Platform Support Operations`:`Technical Helpdesk & Inquiries`]}),(0,d.jsxs)(`h1`,{className:`db-title`,children:[n?`Customer Support `:`Support & `,(0,d.jsx)(`em`,{children:n?`Desk`:`Assistance`})]}),(0,d.jsx)(`p`,{className:`db-hero-sub`,children:n?`Manage incoming support tickets, triage technical questions, and reply to school administrators.`:`Submit technical inquiries, report discrepancies, and chat directly with SchoolProfit support engineers.`}),!n&&(0,d.jsx)(`div`,{className:`mt-3`,children:(0,d.jsxs)(`button`,{className:`db-btn-gold`,onClick:()=>H(!0),children:[(0,d.jsx)(`svg`,{width:`15`,height:`15`,viewBox:`0 0 16 16`,fill:`none`,children:(0,d.jsx)(`path`,{d:`M8 2v12M2 8h12`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`})}),`Open New Support Ticket`]})})]}),(0,d.jsxs)(`div`,{className:`db-hero-stats d-none d-md-block`,children:[(0,d.jsxs)(`div`,{className:`db-hero-row`,children:[(0,d.jsx)(`span`,{children:`Active Tickets`}),(0,d.jsx)(`strong`,{children:G})]}),(0,d.jsxs)(`div`,{className:`db-hero-row`,children:[(0,d.jsx)(`span`,{children:`Resolved Tickets`}),(0,d.jsx)(`strong`,{children:K})]}),(0,d.jsxs)(`div`,{className:`db-hero-row`,children:[(0,d.jsx)(`span`,{children:`Official Email`}),(0,d.jsx)(`strong`,{style:{fontSize:13,fontFamily:`sans-serif`},children:`support@gradequest.com.ng`})]})]})]})]}),j&&(0,d.jsxs)(`div`,{className:`alert alert-danger d-flex align-items-center gap-2 mb-4`,role:`alert`,children:[(0,d.jsx)(`i`,{className:`bi bi-exclamation-triangle-fill`}),(0,d.jsx)(`div`,{children:j})]}),(0,d.jsxs)(`div`,{className:`db-stats`,children:[(0,d.jsxs)(`div`,{className:`db-stat`,style:{"--sc":`#2563eb`,"--si":`rgba(37,99,235,0.10)`},children:[(0,d.jsxs)(`div`,{className:`db-stat-head`,children:[(0,d.jsx)(`span`,{className:`db-stat-label`,children:`Total Tickets`}),(0,d.jsx)(`div`,{className:`db-stat-icon`,children:(0,d.jsx)(`i`,{className:`bi bi-ticket-detailed`})})]}),(0,d.jsx)(`div`,{className:`db-stat-val`,children:x.length}),(0,d.jsx)(`div`,{className:`db-stat-sub`,children:`All time recorded tickets`})]}),(0,d.jsxs)(`div`,{className:`db-stat`,style:{"--sc":`#dc2626`,"--si":`rgba(220,38,38,0.10)`},children:[(0,d.jsxs)(`div`,{className:`db-stat-head`,children:[(0,d.jsx)(`span`,{className:`db-stat-label`,children:`Open / In Progress`}),(0,d.jsx)(`div`,{className:`db-stat-icon`,children:(0,d.jsx)(`i`,{className:`bi bi-hourglass-split`})})]}),(0,d.jsx)(`div`,{className:`db-stat-val`,children:G}),(0,d.jsx)(`div`,{className:`db-stat-sub`,children:`Currently awaiting resolution`})]}),(0,d.jsxs)(`div`,{className:`db-stat`,style:{"--sc":`#15803d`,"--si":`rgba(34,197,94,0.12)`},children:[(0,d.jsxs)(`div`,{className:`db-stat-head`,children:[(0,d.jsx)(`span`,{className:`db-stat-label`,children:`Resolved / Closed`}),(0,d.jsx)(`div`,{className:`db-stat-icon`,children:(0,d.jsx)(`i`,{className:`bi bi-check-circle`})})]}),(0,d.jsx)(`div`,{className:`db-stat-val`,children:K}),(0,d.jsx)(`div`,{className:`db-stat-sub`,children:`Successfully addressed`})]}),(0,d.jsxs)(`div`,{className:`db-stat`,style:{"--sc":`#b45309`,"--si":`rgba(245,158,11,0.12)`},children:[(0,d.jsxs)(`div`,{className:`db-stat-head`,children:[(0,d.jsx)(`span`,{className:`db-stat-label`,children:`Response SLA`}),(0,d.jsx)(`div`,{className:`db-stat-icon`,children:(0,d.jsx)(`i`,{className:`bi bi-lightning-charge`})})]}),(0,d.jsx)(`div`,{className:`db-stat-val`,style:{fontSize:20},children:`Active`}),(0,d.jsx)(`div`,{className:`db-stat-sub`,children:`Email notifications enabled`})]})]}),(0,d.jsxs)(`div`,{className:`row g-4`,children:[(0,d.jsx)(`div`,{className:`col-xl-5`,children:(0,d.jsxs)(`div`,{className:`db-panel h-100`,children:[(0,d.jsx)(`div`,{className:`db-panel-head`,children:(0,d.jsxs)(`div`,{className:`w-100 d-flex gap-2`,children:[(0,d.jsxs)(`div`,{className:`position-relative flex-grow-1`,children:[(0,d.jsx)(`input`,{className:`form-control`,style:{borderRadius:10,borderColor:`#e5ddd3`,fontSize:13,paddingLeft:34},placeholder:`Search tickets, subject, school...`,value:N,onChange:e=>P(e.target.value),onKeyDown:e=>e.key===`Enter`&&q()}),(0,d.jsx)(`i`,{className:`bi bi-search position-absolute text-muted`,style:{left:12,top:`50%`,transform:`translateY(-50%)`,fontSize:13}})]}),(0,d.jsxs)(`select`,{className:`form-select`,style:{maxWidth:140,borderRadius:10,borderColor:`#e5ddd3`,fontSize:13},value:F,onChange:e=>I(e.target.value),children:[(0,d.jsx)(`option`,{value:``,children:`All Statuses`}),Object.entries(f).map(([e,t])=>(0,d.jsx)(`option`,{value:e,children:t},e))]}),(0,d.jsx)(`button`,{className:`btn`,style:{background:`#f5f1eb`,border:`1px solid #e5ddd3`,borderRadius:10},onClick:q,title:`Refresh Tickets`,children:(0,d.jsx)(`i`,{className:`bi bi-arrow-clockwise`})})]})}),(0,d.jsx)(`div`,{style:{maxHeight:`68vh`,overflowY:`auto`},children:D?(0,d.jsxs)(`div`,{className:`p-5 text-center text-muted`,children:[(0,d.jsx)(`div`,{className:`spinner-border spinner-border-sm text-warning me-2`}),`Loading tickets…`]}):x.length===0?(0,d.jsxs)(`div`,{className:`p-5 text-center text-muted`,children:[(0,d.jsx)(`i`,{className:`bi bi-inbox fs-1 d-block mb-2 text-secondary opacity-50`}),(0,d.jsx)(`strong`,{children:`No support tickets found`}),(0,d.jsx)(`p`,{className:`small mb-0 text-muted`,children:N?`No tickets matched your search criteria.`:`You have not submitted any support tickets.`})]}):x.map(e=>(0,d.jsxs)(`button`,{className:`sp-ticket-item ${C?.public_id===e.public_id?`sp-ticket-item--active`:``}`,onClick:()=>J(e.public_id),children:[(0,d.jsxs)(`div`,{className:`d-flex justify-content-between align-items-start gap-2`,children:[(0,d.jsx)(`strong`,{className:`text-truncate`,style:{color:`#1a1a2e`,fontSize:14},children:e.subject}),(0,d.jsx)(`span`,{className:`db-badge ${p[e.status]||`db-badge--gray`}`,children:f[e.status]||e.status})]}),(0,d.jsxs)(`div`,{className:`small text-muted mt-1 d-flex align-items-center gap-2 flex-wrap`,children:[(0,d.jsx)(`span`,{style:{fontWeight:600,color:`#7a6a5a`},children:e.ticket_number}),n&&e.school?.school_name&&(0,d.jsxs)(`span`,{children:[`· `,e.school.school_name]}),(0,d.jsxs)(`span`,{className:`text-capitalize`,children:[`· `,e.category]})]}),(0,d.jsxs)(`div`,{className:`d-flex justify-content-between align-items-center small mt-2 pt-1`,children:[(0,d.jsxs)(`span`,{className:`badge ${e.priority===`urgent`?`bg-danger`:e.priority===`high`?`bg-warning text-dark`:`bg-light text-secondary border`}`,style:{fontSize:10,textTransform:`uppercase`},children:[e.priority,` priority`]}),(0,d.jsx)(`span`,{className:`text-muted`,style:{fontSize:11},children:_(e.last_reply_at)})]})]},e.public_id))})]})}),(0,d.jsx)(`div`,{className:`col-xl-7`,children:C?(0,d.jsxs)(`div`,{className:`db-panel h-100 d-flex flex-column`,children:[(0,d.jsxs)(`div`,{className:`p-4 border-bottom`,style:{background:`#faf8f5`},children:[(0,d.jsxs)(`div`,{className:`d-flex justify-content-between align-items-start gap-3`,children:[(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`div`,{className:`small text-muted`,style:{fontWeight:600},children:C.ticket_number}),(0,d.jsx)(`h4`,{className:`mb-1`,style:{fontFamily:`Playfair Display, serif`,color:`#1a1a2e`},children:C.subject}),(0,d.jsxs)(`div`,{className:`small text-muted`,children:[C.school?.school_name||C.school?.name||`Your School`,` · Category:`,` `,(0,d.jsx)(`span`,{className:`text-capitalize fw-semibold`,children:C.category})]})]}),(0,d.jsx)(`span`,{className:`db-badge ${p[C.status]||`db-badge--gray`}`,children:f[C.status]||C.status})]}),n&&(0,d.jsxs)(`div`,{className:`row g-2 mt-3 pt-3 border-top`,children:[(0,d.jsxs)(`div`,{className:`col-md-6`,children:[(0,d.jsx)(`label`,{className:`form-label small mb-1 fw-bold text-muted`,children:`Assignee`}),(0,d.jsxs)(`select`,{className:`form-select form-select-sm`,value:C.assignee?.id||``,disabled:k,onChange:e=>Q(e.target.value),children:[(0,d.jsx)(`option`,{value:``,children:`Unassigned`}),T.map(e=>(0,d.jsxs)(`option`,{value:e.id,children:[e.name,` (`,e.email,`)`]},e.id))]})]}),(0,d.jsxs)(`div`,{className:`col-md-3`,children:[(0,d.jsx)(`label`,{className:`form-label small mb-1 fw-bold text-muted`,children:`Status`}),(0,d.jsx)(`select`,{className:`form-select form-select-sm`,value:C.status,disabled:k,onChange:e=>Z({status:e.target.value}),children:Object.entries(f).map(([e,t])=>(0,d.jsx)(`option`,{value:e,children:t},e))})]}),(0,d.jsxs)(`div`,{className:`col-md-3`,children:[(0,d.jsx)(`label`,{className:`form-label small mb-1 fw-bold text-muted`,children:`Priority`}),(0,d.jsx)(`select`,{className:`form-select form-select-sm`,value:C.priority,disabled:k,onChange:e=>Z({priority:e.target.value}),children:h.map(e=>(0,d.jsx)(`option`,{value:e,children:e.toUpperCase()},e))})]})]})]}),(0,d.jsx)(`div`,{className:`p-4 flex-grow-1`,style:{maxHeight:`48vh`,overflowY:`auto`,background:`#f8f6f2`},children:(C.messages||[]).map(e=>{let t=e.sender_type===(n?`support`:`school`);return(0,d.jsx)(`div`,{className:`d-flex mb-3 ${t?`justify-content-end`:`justify-content-start`}`,children:(0,d.jsxs)(`div`,{style:{maxWidth:`82%`,background:e.is_internal_note?`#fffbeb`:t?`#050008`:`#ffffff`,color:e.is_internal_note||!t?`#1a1a2e`:`#ffffff`,border:e.is_internal_note?`1px solid #fde68a`:t?`1px solid rgba(255,200,87,0.2)`:`1px solid #ede8e0`,borderRadius:14,padding:`12px 16px`,boxShadow:`0 2px 8px rgba(0,0,0,0.04)`},children:[(0,d.jsxs)(`div`,{className:`small fw-bold mb-1 d-flex align-items-center gap-1`,children:[e.is_internal_note&&(0,d.jsx)(`i`,{className:`bi bi-lock text-warning me-1`}),e.is_internal_note?`Internal Note · `:``,(0,d.jsx)(`span`,{style:{color:t?`#e8c97a`:`#7a6a5a`},children:g(e.user)})]}),(0,d.jsx)(`div`,{style:{whiteSpace:`pre-wrap`,fontSize:13.5,lineHeight:1.5},children:e.message}),(0,d.jsx)(`div`,{className:`small mt-1 text-end`,style:{opacity:.65,fontSize:11},children:_(e.created_at)})]})},e.id)})}),(0,d.jsx)(`form`,{className:`p-4 border-top`,style:{background:`#fff`},onSubmit:X,children:C.status===`closed`?(0,d.jsxs)(`div`,{className:`alert alert-secondary d-flex align-items-center justify-content-between mb-0`,children:[(0,d.jsx)(`span`,{children:`This ticket is closed.`}),n&&(0,d.jsx)(`button`,{type:`button`,className:`btn btn-sm btn-outline-primary`,onClick:()=>Z({status:`open`}),children:`Reopen Ticket`})]}):(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(`textarea`,{className:`form-control mb-2`,rows:3,placeholder:`Write your response...`,style:{borderRadius:10,borderColor:`#e5ddd3`,fontSize:13.5},value:L,onChange:e=>R(e.target.value),required:!0}),(0,d.jsxs)(`div`,{className:`d-flex justify-content-between align-items-center flex-wrap gap-2`,children:[n?(0,d.jsxs)(`label`,{className:`form-check mb-0`,children:[(0,d.jsx)(`input`,{className:`form-check-input`,type:`checkbox`,checked:z,onChange:e=>B(e.target.checked)}),(0,d.jsx)(`span`,{className:`form-check-label small text-muted`,children:`Internal note (school cannot see this)`})]}):(0,d.jsxs)(`small`,{className:`text-muted`,children:[(0,d.jsx)(`i`,{className:`bi bi-envelope me-1`}),`Support engineers are notified instantly by email.`]}),(0,d.jsx)(`button`,{className:`db-btn-gold`,disabled:k||!L.trim(),style:{padding:`8px 18px`,fontSize:12.5},children:k?`Sending…`:z?`Add Internal Note`:`Send Reply`})]})]})})]}):(0,d.jsx)(`div`,{className:`db-panel h-100 d-flex align-items-center justify-content-center py-5 text-center text-muted`,children:(0,d.jsxs)(`div`,{className:`p-4`,children:[(0,d.jsx)(`div`,{style:{width:56,height:56,borderRadius:16,background:`var(--sp-accent-dim)`,color:`rgb(180,83,9)`,display:`inline-flex`,alignItems:`center`,justifyContent:`center`,fontSize:24,marginBottom:12},children:(0,d.jsx)(`i`,{className:`bi bi-chat-left-text`})}),(0,d.jsx)(`h5`,{style:{fontFamily:`Playfair Display, serif`,color:`#1a1a2e`,marginBottom:6},children:`Select a Ticket`}),(0,d.jsx)(`p`,{className:`text-muted small mb-0`,style:{maxWidth:300},children:`Click on any ticket in the list on the left to view the messages, status, and replies.`})]})})})]}),(0,d.jsx)(`div`,{className:`mt-5`,children:(0,d.jsx)(c,{})})]})]})}),V&&(0,d.jsx)(`div`,{className:`sp-modal-overlay`,children:(0,d.jsx)(`div`,{className:`sp-modal`,children:(0,d.jsxs)(`form`,{onSubmit:Y,children:[(0,d.jsxs)(`div`,{className:`sp-modal-head`,children:[(0,d.jsx)(`h5`,{className:`sp-modal-title`,children:`Open Support Ticket`}),(0,d.jsx)(`button`,{type:`button`,className:`sp-modal-close`,onClick:()=>H(!1),children:(0,d.jsx)(`i`,{className:`bi bi-x-lg`})})]}),(0,d.jsxs)(`div`,{className:`sp-modal-body`,children:[(0,d.jsx)(`label`,{className:`form-label small fw-bold text-muted`,children:`Subject / Summary`}),(0,d.jsx)(`input`,{className:`form-control mb-3`,maxLength:180,required:!0,value:U.subject,onChange:e=>W({...U,subject:e.target.value}),placeholder:`e.g. Issue generating third term broadsheet`,style:{borderRadius:8,borderColor:`#e5ddd3`}}),(0,d.jsxs)(`div`,{className:`row g-3 mb-3`,children:[(0,d.jsxs)(`div`,{className:`col-6`,children:[(0,d.jsx)(`label`,{className:`form-label small fw-bold text-muted`,children:`Category`}),(0,d.jsx)(`select`,{className:`form-select`,value:U.category,onChange:e=>W({...U,category:e.target.value}),style:{borderRadius:8,borderColor:`#e5ddd3`},children:m.map(e=>(0,d.jsx)(`option`,{value:e,className:`text-capitalize`,children:e},e))})]}),(0,d.jsxs)(`div`,{className:`col-6`,children:[(0,d.jsx)(`label`,{className:`form-label small fw-bold text-muted`,children:`Priority`}),(0,d.jsx)(`select`,{className:`form-select`,value:U.priority,onChange:e=>W({...U,priority:e.target.value}),style:{borderRadius:8,borderColor:`#e5ddd3`},children:h.map(e=>(0,d.jsx)(`option`,{value:e,className:`text-capitalize`,children:e},e))})]})]}),(0,d.jsx)(`label`,{className:`form-label small fw-bold text-muted`,children:`Detailed Description`}),(0,d.jsx)(`textarea`,{className:`form-control`,rows:5,minLength:10,maxLength:1e4,required:!0,value:U.message,onChange:e=>W({...U,message:e.target.value}),placeholder:`Provide complete details including the page, steps to reproduce, or any error message...`,style:{borderRadius:8,borderColor:`#e5ddd3`}})]}),(0,d.jsxs)(`div`,{className:`sp-modal-foot`,children:[(0,d.jsx)(`button`,{type:`button`,className:`btn btn-sm`,style:{background:`#f5f1eb`,color:`#7a6a5a`},onClick:()=>H(!1),children:`Cancel`}),(0,d.jsx)(`button`,{className:`db-btn-gold`,disabled:k,children:k?`Creating…`:`Submit Ticket`})]})]})})})]})}export{v as default};