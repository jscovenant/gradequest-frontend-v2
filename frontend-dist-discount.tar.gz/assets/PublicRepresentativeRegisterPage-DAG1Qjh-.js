import{i as e}from"./rolldown-runtime-CWU8vmCm.js";import{Ut as t}from"./vendor-misc-OZLc0tLq.js";import{h as n,p as r,x as i}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as a,S as o,w as s}from"./index-D6TxbaCx.js";var c=e(t(),1);const l=[{state:`Abia`,lgas:[`Aba North`,`Aba South`,`Arochukwu`,`Bende`,`Ikwuano`,`Isiala Ngwa North`,`Isiala Ngwa South`,`Isuikwuato`,`Obi Ngwa`,`Ohafia`,`Osisioma`,`Ugwunagbo`,`Ukwa East`,`Ukwa West`,`Umuahia North`,`Umuahia South`,`Umu Nneochi`]},{state:`Adamawa`,lgas:[`Demsa`,`Fufore`,`Ganye`,`Girei`,`Gombi`,`Guyuk`,`Hong`,`Jada`,`Lamurde`,`Madagali`,`Maiha`,`Mayo Belwa`,`Michika`,`Mubi North`,`Mubi South`,`Numan`,`Shelleng`,`Song`,`Toungo`,`Yola North`,`Yola South`]},{state:`Akwa Ibom`,lgas:`Abak.Eastern Obolo.Eket.Esit Eket.Essien Udim.Etim Ekpo.Etinan.Ibeno.Ibesikpo Asutan.Ibiono Ibom.Ika.Ikono.Ikot Abasi.Ikot Ekpene.Ini.Itu.Mbo.Mkpat Enin.Nsit Atai.Nsit Ibom.Nsit Ubium.Obot Akara.Okobo.Onna.Oron.Oruk Anam.Udung Uko.Ukanafun.Uruan.Urue Offong/Oruko.Uyo`.split(`.`)},{state:`Anambra`,lgas:[`Aguata`,`Anambra East`,`Anambra West`,`Anaocha`,`Awka North`,`Awka South`,`Ayamelum`,`Dunukofia`,`Ekwusigo`,`Idemili North`,`Idemili South`,`Ihiala`,`Njikoka`,`Nnewi North`,`Nnewi South`,`Ogbaru`,`Onitsha North`,`Onitsha South`,`Orumba North`,`Orumba South`,`Oyi`]},{state:`Bauchi`,lgas:[`Alkaleri`,`Bauchi`,`Bogoro`,`Damban`,`Darazo`,`Dass`,`Gamawa`,`Ganjuwa`,`Giade`,`Itas/Gadau`,`Jama'are`,`Katagum`,`Kirfi`,`Misau`,`Ningi`,`Shira`,`Tafawa Balewa`,`Toro`,`Warji`,`Zaki`]},{state:`Bayelsa`,lgas:[`Brass`,`Ekeremor`,`Kolokuma/Opokuma`,`Nembe`,`Ogbia`,`Sagbama`,`Southern Ijaw`,`Yenagoa`]},{state:`Benue`,lgas:[`Ado`,`Agatu`,`Apa`,`Buruku`,`Gboko`,`Guma`,`Gwer East`,`Gwer West`,`Katsina-Ala`,`Konshisha`,`Kwande`,`Logo`,`Makurdi`,`Obi`,`Ogbadibo`,`Ohimini`,`Oju`,`Okpokwu`,`Otukpo`,`Tarka`,`Ukum`,`Ushongo`,`Vandeikya`]},{state:`Borno`,lgas:`Abadam.Askira/Uba.Bama.Bayo.Biu.Chibok.Damboa.Dikwa.Gubio.Guzamala.Gwoza.Hawul.Jere.Kaga.Kala/Balge.Konduga.Kukawa.Kwaya Kusar.Mafa.Magumeri.Maiduguri.Marte.Mobbar.Monguno.Ngala.Nganzai.Shani`.split(`.`)},{state:`Cross River`,lgas:[`Abi`,`Akamkpa`,`Akpabuyo`,`Bakassi`,`Bekwarra`,`Biase`,`Boki`,`Calabar Municipal`,`Calabar South`,`Etung`,`Ikom`,`Obanliku`,`Obubra`,`Obudu`,`Odukpani`,`Ogoja`,`Yakuur`,`Yala`]},{state:`Delta`,lgas:[`Aniocha North`,`Aniocha South`,`Bomadi`,`Burutu`,`Ethiope East`,`Ethiope West`,`Ika North East`,`Ika South`,`Isoko North`,`Isoko South`,`Ndokwa East`,`Ndokwa West`,`Okpe`,`Oshimili North`,`Oshimili South`,`Patani`,`Sapele`,`Udu`,`Ughelli North`,`Ughelli South`,`Ukwuani`,`Uvwie`,`Warri North`,`Warri South`,`Warri South West`]},{state:`Ebonyi`,lgas:[`Abakaliki`,`Afikpo North`,`Afikpo South (Edda)`,`Ebonyi`,`Ezza North`,`Ezza South`,`Ikwo`,`Ishielu`,`Ivo`,`Izzi`,`Ohaozara`,`Ohaukwu`,`Onicha`]},{state:`Edo`,lgas:[`Akoko-Edo`,`Egor`,`Esan Central`,`Esan North-East`,`Esan South-East`,`Esan West`,`Etsako Central`,`Etsako East`,`Etsako West`,`Igueben`,`Ikpoba Okha`,`Oredo`,`Orhionmwon`,`Ovia North-East`,`Ovia South-West`,`Owan East`,`Owan West`,`Uhunmwonde`]},{state:`Ekiti`,lgas:[`Ado Ekiti`,`Efon`,`Ekiti East`,`Ekiti South-West`,`Ekiti West`,`Emure`,`Gbonyin`,`Ido Osi`,`Ijero`,`Ikole`,`Ilejemeje`,`Irepodun/Ifelodun`,`Ise/Orun`,`Moba`,`Oye`]},{state:`Enugu`,lgas:[`Aninri`,`Awgu`,`Enugu East`,`Enugu North`,`Enugu South`,`Ezeagu`,`Igbo Etiti`,`Igbo Eze North`,`Igbo Eze South`,`Isi Uzo`,`Nkanu East`,`Nkanu West`,`Nsukka`,`Oji River`,`Udenu`,`Udi`,`Uzo Uwani`]},{state:`Federal Capital Territory (FCT)`,alias:`Abuja`,lgas:[`Abaji`,`Abuja Municipal (AMAC)`,`Bwari`,`Gwagwalada`,`Kuje`,`Kwali`]},{state:`Gombe`,lgas:[`Akko`,`Balanga`,`Billiri`,`Dukku`,`Funakaye`,`Gombe`,`Kaltungo`,`Kwami`,`Nafada`,`Shongom`,`Yamaltu/Deba`]},{state:`Imo`,lgas:`Aboh Mbaise.Ahiazu Mbaise.Ehime Mbano.Ezinihitte.Ideato North.Ideato South.Ihitte/Uboma.Ikeduru.Isiala Mbano.Isu.Mbaitoli.Ngor Okpala.Njaba.Nkwerre.Nwangele.Obowo.Oguta.Ohaji/Egbema.Okigwe.Onuimo.Orlu.Orsu.Oru East.Oru West.Owerri Municipal.Owerri North.Owerri West`.split(`.`)},{state:`Jigawa`,lgas:`Auyo.Babura.Biriniwa.Birnin Kudu.Buji.Dutse.Gagarawa.Garki.Gumel.Guri.Gwaram.Gwiwa.Hadejia.Jahun.Kafin Hausa.Kaugama.Kazaure.Kiri Kasama.Kiyawa.Maigatari.Malam Madori.Miga.Ringim.Roni.Sule Tankarkar.Taura.Yankwashi`.split(`.`)},{state:`Kaduna`,lgas:[`Birnin Gwari`,`Chikun`,`Giwa`,`Igabi`,`Ikara`,`Jaba`,`Jema'a`,`Kachia`,`Kaduna North`,`Kaduna South`,`Kagarko`,`Kajuru`,`Kaura`,`Kauru`,`Kubau`,`Kudan`,`Lere`,`Makarfi`,`Sabon Gari`,`Sanga`,`Soba`,`Zangon Kataf`,`Zaria`]},{state:`Kano`,lgas:`Ajingi.Albasu.Bagwai.Bebeji.Bichi.Bunkure.Dala.Dambatta.Dawakin Kudu.Dawakin Tofa.Doguwa.Fagge.Gabasawa.Garko.Garun Mallam.Gaya.Gezawa.Gwale.Gwarzo.Kabo.Kano Municipal.Karaye.Kibiya.Kiru.Kumbotso.Kunchi.Kura.Madobi.Makoda.Minjibir.Nasarawa.Rano.Rimin Gado.Rogo.Shanono.Sumaila.Takai.Tarauni.Tofa.Tsanyawa.Tudun Wada.Ungogo.Warawa.Wudil`.split(`.`)},{state:`Katsina`,lgas:`Bakori.Batagarawa.Batsari.Baure.Bindawa.Charanchi.Dandume.Danja.Dan Musa.Daura.Dutsi.Dutsin Ma.Faskari.Funtua.Ingawa.Jibia.Kafur.Kaita.Kankara.Kankia.Katsina.Kurfi.Kusada.Mai'Adua.Malumfashi.Mani.Mashi.Matazu.Musawa.Rimi.Sabuwa.Safana.Sandamu.Zango`.split(`.`)},{state:`Kebbi`,lgas:[`Aleiro`,`Arewa Dandi`,`Argungu`,`Augie`,`Bagudo`,`Birnin Kebbi`,`Bunza`,`Dandi`,`Fakai`,`Gwandu`,`Jega`,`Kalgo`,`Koko/Besse`,`Maiyama`,`Ngaski`,`Sakaba`,`Shanga`,`Suru`,`Danko/Wasagu`,`Yauri`,`Zuru`]},{state:`Kogi`,lgas:[`Adavi`,`Ajaokuta`,`Ankpa`,`Bassa`,`Dekina`,`Ibaji`,`Idah`,`Igalamela Odolu`,`Ijumu`,`Kabba/Bunu`,`Koton Karfe`,`Lokoja`,`Mopa Muro`,`Ofu`,`Ogori/Magongo`,`Okehi`,`Okene`,`Olamaboro`,`Omala`,`Yagba East`,`Yagba West`]},{state:`Kwara`,lgas:[`Asa`,`Baruten`,`Edu`,`Ekiti`,`Ifelodun`,`Ilorin East`,`Ilorin South`,`Ilorin West`,`Irepodun`,`Isin`,`Kaiama`,`Moro`,`Offa`,`Oke Ero`,`Oyun`,`Pategi`]},{state:`Lagos`,lgas:[`Agege`,`Ajeromi-Ifelodun`,`Alimosho`,`Amuwo-Odofin`,`Apapa`,`Badagry`,`Epe`,`Eti Osa`,`Ibeju-Lekki`,`Ifako-Ijaiye`,`Ikeja`,`Ikorodu`,`Kosofe`,`Lagos Island`,`Lagos Mainland`,`Mushin`,`Ojo`,`Oshodi-Isolo`,`Shomolu`,`Surulere`]},{state:`Nasarawa`,lgas:[`Akwanga`,`Awe`,`Doma`,`Karu`,`Keana`,`Keffi`,`Kokona`,`Lafia`,`Nasarawa`,`Nasarawa Egon`,`Obi`,`Toto`,`Wamba`]},{state:`Niger`,lgas:[`Agaie`,`Agwara`,`Bida`,`Borgu`,`Bosso`,`Chanchaga`,`Edati`,`Gbako`,`Gurara`,`Katcha`,`Kontagora`,`Lapai`,`Lavun`,`Magama`,`Mariga`,`Mashegu`,`Mokwa`,`Moya`,`Paikoro`,`Rafi`,`Rijau`,`Shiroro`,`Suleja`,`Tafa`,`Wushishi`]},{state:`Ogun`,lgas:[`Abeokuta North`,`Abeokuta South`,`Ado-Odo/Ota`,`Ewekoro`,`Ifo`,`Ijebu East`,`Ijebu North`,`Ijebu North East`,`Ijebu Ode`,`Ikenne`,`Imeko Afon`,`Ipokia`,`Obafemi Owode`,`Odogbolu`,`Odeda`,`Ogun Waterside`,`Remo North`,`Sagamu`,`Yewa North`,`Yewa South`]},{state:`Ondo`,lgas:[`Akoko North-East`,`Akoko North-West`,`Akoko South-East`,`Akoko South-West`,`Akure North`,`Akure South`,`Ese Odo`,`Idanre`,`Ifedore`,`Ilaje`,`Ile Oluji/Okeigbo`,`Irele`,`Odigbo`,`Okitipupa`,`Ondo East`,`Ondo West`,`Ose`,`Owo`]},{state:`Osun`,lgas:`Aiyedaade.Aiyedire.Atakunmosa East.Atakunmosa West.Boluwaduro.Boripe.Ede North.Ede South.Egbedore.Ejigbo.Ife Central.Ife East.Ife North.Ife South.Ifedayo.Ifelodun.Ila.Ilesa East.Ilesa West.Irepodun.Irewole.Isokan.Iwo.Obokun.Odo Otin.Ola Oluwa.Olorunda.Oriade.Orolu.Osogbo`.split(`.`)},{state:`Oyo`,lgas:`Afijio.Akinyele.Atiba.Atisbo.Egbeda.Ibadan North.Ibadan North-East.Ibadan North-West.Ibadan South-East.Ibadan South-West.Ibarapa Central.Ibarapa East.Ibarapa North.Ido.Irepo.Iseyin.Itesiwaju.Iwajowa.Kajola.Lagelu.Ogbomosho North.Ogbomosho South.Ogo Oluwa.Olorunsogo.Oluyole.Ona Ara.Orelope.Ori Ire.Oyo East.Oyo West.Saki East.Saki West.Surulere`.split(`.`)},{state:`Plateau`,lgas:[`Barkin Ladi`,`Bassa`,`Bokkos`,`Jos East`,`Jos North`,`Jos South`,`Kanam`,`Kanke`,`Langtang North`,`Langtang South`,`Mangu`,`Mikang`,`Pankshin`,`Qua'an Pan`,`Riyom`,`Shendam`,`Wase`]},{state:`Rivers`,lgas:[`Abua/Odual`,`Ahoada East`,`Ahoada West`,`Akuku-Toru`,`Andoni`,`Asari-Toru`,`Bonny`,`Degema`,`Eleme`,`Emohua`,`Etche`,`Gokana`,`Ikwerre`,`Khana`,`Obio/Akpor`,`Ogba/Egbema/Ndoni`,`Ogu/Bolo`,`Okrika`,`Omuma`,`Opobo/Nkoro`,`Oyigbo`,`Port Harcourt`,`Tai`]},{state:`Sokoto`,lgas:[`Binji`,`Bodinga`,`Dange Shuni`,`Gada`,`Goronyo`,`Gudu`,`Gwadabawa`,`Illela`,`Isa`,`Kebbe`,`Kware`,`Rabah`,`Sabon Birni`,`Shagari`,`Silame`,`Sokoto North`,`Sokoto South`,`Tambuwal`,`Tangaza`,`Tureta`,`Wamako`,`Wurno`,`Yabo`]},{state:`Taraba`,lgas:[`Ardo Kola`,`Bali`,`Donga`,`Gashaka`,`Gassol`,`Ibi`,`Jalingo`,`Karim Lamido`,`Kurmi`,`Lau`,`Sardauna`,`Takum`,`Ussa`,`Wukari`,`Yorro`,`Zing`]},{state:`Yobe`,lgas:[`Bade`,`Bursari`,`Damaturu`,`Fika`,`Fune`,`Geidam`,`Gujba`,`Gulani`,`Jakusko`,`Karasuwa`,`Machina`,`Nangere`,`Nguru`,`Potiskum`,`Tarmuwa`,`Yunusari`,`Yusufari`]},{state:`Zamfara`,lgas:[`Anka`,`Bakura`,`Birnin Magaji/Kiyaw`,`Bukkuyum`,`Bungudu`,`Gummi`,`Gusau`,`Kaura Namoda`,`Maradun`,`Maru`,`Shinkafi`,`Talata Mafara`,`Tsafe`,`Zurmi`]}];var u=r(),d={firstname:``,surname:``,email:``,phone:``,state:``,lga:``,region:``,password:``,password_confirmation:``,next_of_kin_name:``,next_of_kin_phone:``,highest_qualification:`B.Sc / HND`,bank_name:``,account_number:``,account_name:``,past_experience:``};function f(){let{platform:e}=o(),t=e?.sales_partner_term_1_commission??30,r=e?.sales_partner_retention_commission??12,[f,p]=(0,c.useState)(d),[m,h]=(0,c.useState)(!1),[g,_]=(0,c.useState)(``),[v,y]=(0,c.useState)(null);i();let b=(0,c.useMemo)(()=>{if(!f.state)return[];let e=l.find(e=>e.state===f.state);return e?e.lgas:[]},[f.state]),x=e=>{let{name:t,value:n}=e.target;p(e=>({...e,[t]:n}))};return(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(a,{title:`Become a Sales Representative | SchoolProfit Partner Network`}),(0,u.jsx)(`style`,{children:`
        .gq-rep-page {
          min-height: 100vh;
          background: #F8FAFC;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
          color: #0F2744;
          display: flex;
          flex-direction: column;
        }

        .gq-rep-nav {
          background: #FFFFFF;
          border-bottom: 1px solid #E2E8F0;
          padding: 16px 28px;
          display: flex;
          align-items: center;
          justify-content: space-between;
        }

        .gq-rep-logo {
          display: flex;
          align-items: center;
          gap: 10px;
          text-decoration: none;
        }

        .gq-rep-logo-badge {
          width: 40px;
          height: 40px;
          border-radius: 10px;
          background: linear-gradient(135deg, #0F2744 0%, #1E3A8A 100%);
          border: 1px solid rgba(217, 119, 6, 0.35);
          display: flex;
          align-items: center;
          justify-content: center;
          box-shadow: 0 4px 12px rgba(15, 39, 68, 0.15);
          flex-shrink: 0;
        }

        .gq-rep-logo-img {
          width: 26px;
          height: 26px;
          object-fit: contain;
          display: block;
        }

        .gq-rep-logo-text {
          font-size: 21px;
          font-weight: 800;
          color: #0F2744;
          letter-spacing: -0.02em;
        }

        .gq-rep-logo-text span {
          color: #D97706;
        }

        .gq-rep-hero {
          background: linear-gradient(135deg, #0F2744 0%, #1E3A8A 50%, #0A192F 100%);
          color: #FFFFFF;
          padding: 60px 24px;
          text-align: center;
          position: relative;
          overflow: hidden;
        }

        .gq-rep-hero::before {
          content: '';
          position: absolute;
          inset: 0;
          background-image: radial-gradient(circle, rgba(251, 191, 36, 0.08) 1px, transparent 1px);
          background-size: 32px 32px;
          pointer-events: none;
        }

        .gq-rep-badge {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          background: rgba(217, 119, 6, 0.15);
          border: 1px solid rgba(251, 191, 36, 0.4);
          color: #FDE68A;
          padding: 6px 14px;
          border-radius: 999px;
          font-size: 13px;
          font-weight: 700;
          margin-bottom: 20px;
          letter-spacing: 0.03em;
        }

        .gq-rep-title {
          font-size: 38px;
          font-weight: 800;
          line-height: 1.2;
          margin: 0 0 16px 0;
          letter-spacing: -0.02em;
        }

        .gq-rep-title span {
          color: #FBBF24;
          font-style: italic;
        }

        .gq-rep-sub {
          max-width: 720px;
          margin: 0 auto;
          font-size: 17px;
          line-height: 1.6;
          color: #CBD5E1;
        }

        .gq-rep-main {
          max-width: 1100px;
          margin: -40px auto 60px;
          padding: 0 20px;
          width: 100%;
          position: relative;
          z-index: 10;
        }

        .gq-rep-grid {
          display: grid;
          grid-template-columns: 1fr 1.35fr;
          gap: 28px;
          align-items: flex-start;
        }

        @media (max-width: 960px) {
          .gq-rep-grid {
            grid-template-columns: 1fr;
          }
          .gq-rep-hero {
            padding: 44px 20px;
          }
          .gq-rep-title {
            font-size: 28px;
          }
        }

        .gq-rep-perks-card {
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: 20px;
          padding: 32px;
          box-shadow: 0 10px 25px -5px rgba(15, 39, 68, 0.06);
        }

        .gq-perk-item {
          display: flex;
          align-items: flex-start;
          gap: 16px;
          margin-bottom: 24px;
        }

        .gq-perk-item:last-child {
          margin-bottom: 0;
        }

        .gq-perk-icon {
          width: 44px;
          height: 44px;
          border-radius: 12px;
          background: #ECFDF5;
          color: #059669;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 20px;
          flex-shrink: 0;
        }

        .gq-perk-icon.gold {
          background: #FEF3C7;
          color: #D97706;
        }

        .gq-perk-icon.blue {
          background: #EFF6FF;
          color: #1D4ED8;
        }

        .gq-perk-content h4 {
          margin: 0 0 4px 0;
          font-size: 16px;
          font-weight: 700;
          color: #0F2744;
        }

        .gq-perk-content p {
          margin: 0;
          font-size: 13.5px;
          line-height: 1.5;
          color: #475569;
        }

        .gq-rep-form-card {
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: 20px;
          padding: 36px;
          box-shadow: 0 12px 30px -5px rgba(15, 39, 68, 0.08);
        }

        .gq-form-section-title {
          font-size: 17px;
          font-weight: 700;
          color: #0F2744;
          display: flex;
          align-items: center;
          gap: 10px;
          padding-bottom: 12px;
          border-bottom: 1px solid #E2E8F0;
          margin: 24px 0 18px 0;
        }

        .gq-form-section-title:first-of-type {
          margin-top: 0;
        }

        .gq-form-row {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 16px;
          margin-bottom: 16px;
        }

        @media (max-width: 640px) {
          .gq-form-row {
            grid-template-columns: 1fr;
          }
        }

        .gq-form-group {
          margin-bottom: 16px;
        }

        .gq-form-group label {
          display: block;
          font-size: 13px;
          font-weight: 600;
          color: #334155;
          margin-bottom: 6px;
        }

        .gq-form-group label span.req {
          color: #DC2626;
        }

        .gq-form-input,
        .gq-form-select,
        .gq-form-textarea {
          width: 100%;
          padding: 11px 14px;
          border: 1.5px solid #E2E8F0;
          border-radius: 10px;
          font-size: 14px;
          color: #0F172A;
          background: #FFFFFF;
          transition: all 0.2s ease;
          box-sizing: border-box;
        }

        .gq-form-input:focus,
        .gq-form-select:focus,
        .gq-form-textarea:focus {
          outline: none;
          border-color: #1D4ED8;
          box-shadow: 0 0 0 3px rgba(29, 78, 216, 0.12);
        }

        .gq-btn-primary {
          width: 100%;
          padding: 14px 20px;
          background: linear-gradient(135deg, #0F2744 0%, #1E3A8A 100%);
          color: #FFFFFF;
          border: none;
          border-radius: 12px;
          font-size: 15.5px;
          font-weight: 700;
          cursor: pointer;
          transition: all 0.25s ease;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 10px;
          box-shadow: 0 6px 18px rgba(15, 39, 68, 0.2);
        }

        .gq-btn-primary:hover:not(:disabled) {
          transform: translateY(-2px);
          box-shadow: 0 10px 24px rgba(15, 39, 68, 0.28);
          background: linear-gradient(135deg, #1E3A8A 0%, #0F2744 100%);
        }

        .gq-btn-primary:disabled {
          opacity: 0.65;
          cursor: not-allowed;
        }

        .gq-alert-error {
          background: #FEF2F2;
          border: 1px solid #FCA5A5;
          color: #991B1B;
          padding: 14px 16px;
          border-radius: 10px;
          font-size: 13.5px;
          margin-bottom: 20px;
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .gq-success-card {
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: 20px;
          padding: 44px 32px;
          text-align: center;
          box-shadow: 0 12px 32px rgba(15, 39, 68, 0.08);
          max-width: 680px;
          margin: 0 auto;
        }

        .gq-success-icon {
          width: 72px;
          height: 72px;
          background: #FEF3C7;
          border: 2px solid #FDE68A;
          border-radius: 50%;
          color: #D97706;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 36px;
          margin: 0 auto 20px;
        }

        .gq-summary-box {
          background: #F8FAFC;
          border: 1px solid #E2E8F0;
          border-radius: 14px;
          padding: 20px;
          margin: 24px 0;
          text-align: left;
        }

        .gq-summary-row {
          display: flex;
          justify-content: space-between;
          padding: 8px 0;
          border-bottom: 1px dashed #E2E8F0;
          font-size: 14px;
        }

        .gq-summary-row:last-child {
          border-bottom: none;
        }
      `}),(0,u.jsx)(a,{title:`Become a Sales Representative | SchoolProfit Partner Network`}),(0,u.jsx)(`style`,{children:`
        .gq-rep-page {
          min-height: 100vh;
          background: #F8FAFC;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
          color: #0F2744;
          display: flex;
          flex-direction: column;
        }

        .gq-rep-nav {
          background: #FFFFFF;
          border-bottom: 1px solid #E2E8F0;
          padding: 16px 28px;
          display: flex;
          align-items: center;
          justify-content: space-between;
        }

        .gq-rep-logo {
          display: flex;
          align-items: center;
          gap: 10px;
          text-decoration: none;
        }

        .gq-rep-logo-badge {
          width: 40px;
          height: 40px;
          border-radius: 10px;
          background: transparent;
          display: flex;
          align-items: center;
          justify-content: center;
        }
      `}),(0,u.jsxs)(`div`,{className:`gq-rep-page`,children:[(0,u.jsxs)(`header`,{className:`gq-rep-nav`,children:[(0,u.jsxs)(n,{to:`/`,className:`gq-rep-logo`,children:[(0,u.jsx)(`div`,{className:`gq-rep-logo-badge`,children:(0,u.jsx)(`img`,{src:`/media/logo/schoolprofit-icon.svg`,alt:`SchoolProfit Logo`,className:`gq-rep-logo-img`,style:{width:`32px`,height:`32px`},onError:e=>{let t=e.currentTarget;t.style.display=`none`}})}),(0,u.jsxs)(`div`,{className:`gq-rep-logo-text`,children:[`School`,(0,u.jsx)(`span`,{style:{color:`#059669`},children:`Profit`})]})]}),(0,u.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`14px`},children:[(0,u.jsx)(`span`,{style:{fontSize:`14px`,color:`#64748B`},children:`Already registered?`}),(0,u.jsx)(n,{to:`/login`,style:{fontSize:`14px`,fontWeight:`700`,color:`#1D4ED8`,textDecoration:`none`,padding:`8px 16px`,border:`1px solid #E2E8F0`,borderRadius:`8px`,background:`#FFFFFF`},children:`Sign In`})]})]}),(0,u.jsxs)(`section`,{className:`gq-rep-hero`,children:[(0,u.jsxs)(`div`,{className:`gq-rep-badge`,children:[(0,u.jsx)(`i`,{className:`bi bi-award-fill`}),` SchoolProfit Partner & Representative Program`]}),(0,u.jsxs)(`h1`,{className:`gq-rep-title`,children:[`Empower Schools. `,(0,u.jsx)(`span`,{children:`Earn Recurring Royalties.`})]}),(0,u.jsxs)(`p`,{className:`gq-rep-sub`,children:[`Join our nationwide network of education sales partners. Introduce SchoolProfit to schools in your state or region and earn up to `,t,`% first-term commission with `,r,`% termly recurring retention.`]})]}),(0,u.jsx)(`main`,{className:`gq-rep-main`,children:v?(0,u.jsxs)(`div`,{className:`gq-success-card`,children:[(0,u.jsx)(`div`,{className:`gq-success-icon`,children:(0,u.jsx)(`i`,{className:`bi bi-clock-history`})}),(0,u.jsx)(`h2`,{style:{fontSize:`26px`,fontWeight:`800`,color:`#0F2744`,margin:`0 0 10px 0`},children:`Application Submitted for Verification`}),(0,u.jsx)(`p`,{style:{fontSize:`15px`,color:`#475569`,lineHeight:`1.6`,margin:`0 auto`,maxWidth:`520px`},children:`Thank you for applying to become a SchoolProfit Sales Representative! Your application has been registered and is currently awaiting administrative approval.`}),(0,u.jsxs)(`div`,{className:`gq-summary-box`,children:[(0,u.jsxs)(`div`,{className:`gq-summary-row`,children:[(0,u.jsx)(`span`,{style:{color:`#64748B`},children:`Applicant Name:`}),(0,u.jsx)(`strong`,{style:{color:`#0F2744`},children:v.name})]}),(0,u.jsxs)(`div`,{className:`gq-summary-row`,children:[(0,u.jsx)(`span`,{style:{color:`#64748B`},children:`Registered Email:`}),(0,u.jsx)(`strong`,{style:{color:`#0F2744`},children:v.email})]}),(0,u.jsxs)(`div`,{className:`gq-summary-row`,children:[(0,u.jsx)(`span`,{style:{color:`#64748B`},children:`Assigned Application Code:`}),(0,u.jsx)(`span`,{style:{background:`#0F2744`,color:`#FBBF24`,padding:`2px 8px`,borderRadius:`6px`,fontWeight:`700`,fontSize:`13px`},children:v.code})]}),(0,u.jsxs)(`div`,{className:`gq-summary-row`,children:[(0,u.jsx)(`span`,{style:{color:`#64748B`},children:`Review Status:`}),(0,u.jsx)(`strong`,{style:{color:`#D97706`},children:`● Pending Admin Approval`})]})]}),(0,u.jsxs)(`div`,{style:{background:`#F0FDF4`,border:`1px solid #BBF7D0`,borderRadius:`12px`,padding:`16px 20px`,textAlign:`left`,marginBottom:`28px`},children:[(0,u.jsxs)(`h4`,{style:{margin:`0 0 6px 0`,color:`#047857`,fontSize:`14px`,fontWeight:`700`},children:[(0,u.jsx)(`i`,{className:`bi bi-info-circle-fill`,style:{marginRight:`8px`}}),`What happens next?`]}),(0,u.jsxs)(`p`,{style:{margin:0,fontSize:`13.5px`,color:`#065F46`,lineHeight:`1.5`},children:[`Our administrative team will review your application within `,(0,u.jsx)(`strong`,{children:`24 business hours`}),`. As soon as your account is approved, you will receive an email confirmation and can immediately log in to access your Sales Workspace, referral link, and marketing toolkits.`]})]}),(0,u.jsxs)(`div`,{style:{display:`flex`,gap:`14px`,justifyContent:`center`},children:[(0,u.jsx)(n,{to:`/`,style:{padding:`12px 24px`,background:`#F1F5F9`,color:`#334155`,textDecoration:`none`,borderRadius:`10px`,fontWeight:`700`,fontSize:`14.5px`},children:`Return to Home`}),(0,u.jsx)(n,{to:`/login`,style:{padding:`12px 28px`,background:`linear-gradient(135deg, #0F2744 0%, #1E3A8A 100%)`,color:`#FFFFFF`,textDecoration:`none`,borderRadius:`10px`,fontWeight:`700`,fontSize:`14.5px`,boxShadow:`0 4px 12px rgba(15, 39, 68, 0.2)`},children:`Go to Login Portal`})]})]}):(0,u.jsxs)(`div`,{className:`gq-rep-grid`,children:[(0,u.jsxs)(`aside`,{className:`gq-rep-perks-card`,children:[(0,u.jsxs)(`div`,{style:{marginBottom:`24px`},children:[(0,u.jsx)(`span`,{style:{fontSize:`12px`,fontWeight:`800`,color:`#D97706`,textTransform:`uppercase`,letterSpacing:`0.08em`},children:`Why Partner With Us`}),(0,u.jsx)(`h3`,{style:{margin:`6px 0 0 0`,fontSize:`22px`,fontWeight:`800`,color:`#0F2744`},children:`Unmatched Partnership Rewards`})]}),(0,u.jsxs)(`div`,{className:`gq-perk-item`,children:[(0,u.jsx)(`div`,{className:`gq-perk-icon gold`,children:(0,u.jsx)(`i`,{className:`bi bi-cash-stack`})}),(0,u.jsxs)(`div`,{className:`gq-perk-content`,children:[(0,u.jsxs)(`h4`,{children:[`Up to `,t,`% First-Term Royalties`]}),(0,u.jsxs)(`p`,{children:[`Earn an industry-leading `,t,`% direct commission on the initial onboarding subscription of every school you register.`]})]})]}),(0,u.jsxs)(`div`,{className:`gq-perk-item`,children:[(0,u.jsx)(`div`,{className:`gq-perk-icon`,children:(0,u.jsx)(`i`,{className:`bi bi-arrow-repeat`})}),(0,u.jsxs)(`div`,{className:`gq-perk-content`,children:[(0,u.jsxs)(`h4`,{children:[r,`% Recurring Termly Retention`]}),(0,u.jsxs)(`p`,{children:[`Build true passive income. Continue earning `,r,`% on every subsequent term renewal as long as your registered schools stay active.`]})]})]}),(0,u.jsxs)(`div`,{className:`gq-perk-item`,children:[(0,u.jsx)(`div`,{className:`gq-perk-icon blue`,children:(0,u.jsx)(`i`,{className:`bi bi-speedometer2`})}),(0,u.jsxs)(`div`,{className:`gq-perk-content`,children:[(0,u.jsx)(`h4`,{children:`Dedicated Sales Workspace`}),(0,u.jsx)(`p`,{children:`Access your real-time lead tracker, custom branded landing page, automated commission ledger, and bank settlement profile.`})]})]}),(0,u.jsxs)(`div`,{className:`gq-perk-item`,children:[(0,u.jsx)(`div`,{className:`gq-perk-icon gold`,children:(0,u.jsx)(`i`,{className:`bi bi-folder-check`})}),(0,u.jsxs)(`div`,{className:`gq-perk-content`,children:[(0,u.jsx)(`h4`,{children:`Official Marketing Toolkit`}),(0,u.jsx)(`p`,{children:`Download branded presentation decks, school proposal templates, flyers, and WhatsApp sales pitch scripts ready for action.`})]})]}),(0,u.jsxs)(`div`,{style:{marginTop:`28px`,padding:`16px`,background:`#F8FAFC`,borderRadius:`12px`,border:`1px solid #E2E8F0`},children:[(0,u.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:`10px`,color:`#0F2744`,fontWeight:`700`,fontSize:`13.5px`},children:[(0,u.jsx)(`i`,{className:`bi bi-shield-check`,style:{color:`#059669`,fontSize:`18px`}}),`Verified Partner Security`]}),(0,u.jsx)(`p`,{style:{margin:`6px 0 0 0`,fontSize:`12.5px`,color:`#64748B`,lineHeight:`1.4`},children:`All accounts undergo administrative credential checks before activation to maintain professional representation standards.`})]})]}),(0,u.jsxs)(`section`,{className:`gq-rep-form-card`,children:[(0,u.jsx)(`h3`,{style:{margin:`0 0 8px 0`,fontSize:`22px`,fontWeight:`800`,color:`#0F2744`},children:`Representative Application Form`}),(0,u.jsx)(`p`,{style:{margin:`0 0 24px 0`,fontSize:`14px`,color:`#64748B`},children:`Fill in your personal and regional details below to initiate your partner registration.`}),g&&(0,u.jsxs)(`div`,{className:`gq-alert-error`,children:[(0,u.jsx)(`i`,{className:`bi bi-exclamation-triangle-fill`}),(0,u.jsx)(`span`,{children:g})]}),(0,u.jsxs)(`form`,{onSubmit:async e=>{if(e.preventDefault(),_(``),!f.state){_(`Please select your primary operating state from the dropdown.`);return}if(!f.lga){_(`Please select your primary Local Government Area (LGA).`);return}if(f.password!==f.password_confirmation){_(`Passwords do not match. Please verify and try again.`);return}if(f.password.length<8){_(`Password must be at least 8 characters in length.`);return}h(!0);try{let e=`${f.lga}, ${f.state}`;y((await s.post(`/public/sales-representatives/register`,{...f,region:e})).data?.data||{code:`SUBMITTED`,name:`${f.firstname} ${f.surname}`,email:f.email,status:`pending_approval`})}catch(e){_(e?.response?.data?.message||`Could not submit your application. Please ensure all required fields are filled and try again.`)}finally{h(!1)}},children:[(0,u.jsxs)(`div`,{className:`gq-form-section-title`,children:[(0,u.jsx)(`i`,{className:`bi bi-person-badge-fill`,style:{color:`#1D4ED8`}}),`Personal & Contact Details`]}),(0,u.jsxs)(`div`,{className:`gq-form-row`,children:[(0,u.jsxs)(`div`,{className:`gq-form-group`,children:[(0,u.jsxs)(`label`,{children:[`First Name `,(0,u.jsx)(`span`,{className:`req`,children:`*`})]}),(0,u.jsx)(`input`,{type:`text`,name:`firstname`,required:!0,value:f.firstname,onChange:x,placeholder:`e.g. Samuel`,className:`gq-form-input`})]}),(0,u.jsxs)(`div`,{className:`gq-form-group`,children:[(0,u.jsxs)(`label`,{children:[`Last Name / Surname `,(0,u.jsx)(`span`,{className:`req`,children:`*`})]}),(0,u.jsx)(`input`,{type:`text`,name:`surname`,required:!0,value:f.surname,onChange:x,placeholder:`e.g. Adebayo`,className:`gq-form-input`})]})]}),(0,u.jsxs)(`div`,{className:`gq-form-row`,children:[(0,u.jsxs)(`div`,{className:`gq-form-group`,children:[(0,u.jsxs)(`label`,{children:[`Email Address `,(0,u.jsx)(`span`,{className:`req`,children:`*`})]}),(0,u.jsx)(`input`,{type:`email`,name:`email`,required:!0,value:f.email,onChange:x,placeholder:`e.g. samuel@example.com`,className:`gq-form-input`})]}),(0,u.jsxs)(`div`,{className:`gq-form-group`,children:[(0,u.jsxs)(`label`,{children:[`Phone / WhatsApp Number `,(0,u.jsx)(`span`,{className:`req`,children:`*`})]}),(0,u.jsx)(`input`,{type:`tel`,name:`phone`,required:!0,value:f.phone,onChange:x,placeholder:`e.g. 08012345678`,className:`gq-form-input`})]})]}),(0,u.jsxs)(`div`,{className:`gq-form-row`,children:[(0,u.jsxs)(`div`,{className:`gq-form-group`,children:[(0,u.jsxs)(`label`,{children:[`Operating State `,(0,u.jsx)(`span`,{className:`req`,children:`*`})]}),(0,u.jsxs)(`select`,{name:`state`,required:!0,value:f.state,onChange:e=>{let t=e.target.value;p(e=>({...e,state:t,lga:``,region:t}))},className:`gq-form-select`,children:[(0,u.jsx)(`option`,{value:``,children:`-- Select Operating State --`}),l.map(e=>(0,u.jsxs)(`option`,{value:e.state,children:[e.state,` `,e.alias?`(${e.alias})`:``]},e.state))]})]}),(0,u.jsxs)(`div`,{className:`gq-form-group`,children:[(0,u.jsxs)(`label`,{children:[`Primary LGA / District `,(0,u.jsx)(`span`,{className:`req`,children:`*`})]}),(0,u.jsxs)(`select`,{name:`lga`,required:!0,disabled:!f.state,value:f.lga,onChange:e=>{let t=e.target.value;p(e=>({...e,lga:t,region:t?`${t}, ${e.state}`:e.state}))},className:`gq-form-select`,children:[(0,u.jsx)(`option`,{value:``,children:f.state?`-- Select Local Government Area --`:`-- Select state first --`}),b.map(e=>(0,u.jsx)(`option`,{value:e,children:e},e))]})]})]}),(0,u.jsxs)(`div`,{className:`gq-form-section-title`,children:[(0,u.jsx)(`i`,{className:`bi bi-lock-fill`,style:{color:`#1D4ED8`}}),`Account Security Password`]}),(0,u.jsxs)(`div`,{className:`gq-form-row`,children:[(0,u.jsxs)(`div`,{className:`gq-form-group`,children:[(0,u.jsxs)(`label`,{children:[`Create Password `,(0,u.jsx)(`span`,{className:`req`,children:`*`})]}),(0,u.jsx)(`input`,{type:`password`,name:`password`,required:!0,minLength:8,value:f.password,onChange:x,placeholder:`Minimum 8 characters`,className:`gq-form-input`})]}),(0,u.jsxs)(`div`,{className:`gq-form-group`,children:[(0,u.jsxs)(`label`,{children:[`Confirm Password `,(0,u.jsx)(`span`,{className:`req`,children:`*`})]}),(0,u.jsx)(`input`,{type:`password`,name:`password_confirmation`,required:!0,minLength:8,value:f.password_confirmation,onChange:x,placeholder:`Re-enter password`,className:`gq-form-input`})]})]}),(0,u.jsxs)(`div`,{className:`gq-form-section-title`,children:[(0,u.jsx)(`i`,{className:`bi bi-people-fill`,style:{color:`#1D4ED8`}}),`Next of Kin Information (Optional)`]}),(0,u.jsxs)(`div`,{className:`gq-form-row`,children:[(0,u.jsxs)(`div`,{className:`gq-form-group`,children:[(0,u.jsx)(`label`,{children:`Next of Kin Full Name`}),(0,u.jsx)(`input`,{type:`text`,name:`next_of_kin_name`,value:f.next_of_kin_name,onChange:x,placeholder:`e.g. Mary Adebayo`,className:`gq-form-input`})]}),(0,u.jsxs)(`div`,{className:`gq-form-group`,children:[(0,u.jsx)(`label`,{children:`Next of Kin Phone`}),(0,u.jsx)(`input`,{type:`tel`,name:`next_of_kin_phone`,value:f.next_of_kin_phone,onChange:x,placeholder:`e.g. 08087654321`,className:`gq-form-input`})]})]}),(0,u.jsxs)(`div`,{className:`gq-form-group`,children:[(0,u.jsx)(`label`,{children:`Relationship to Next of Kin`}),(0,u.jsx)(`input`,{type:`text`,name:`next_of_kin_relationship`,value:f.next_of_kin_relationship,onChange:x,placeholder:`e.g. Spouse, Brother, Sister, Parent`,className:`gq-form-input`})]}),(0,u.jsxs)(`div`,{className:`gq-form-group`,children:[(0,u.jsx)(`label`,{children:`Brief Background / Sales Experience (Optional)`}),(0,u.jsx)(`textarea`,{name:`notes`,rows:3,value:f.notes,onChange:x,placeholder:`Share any brief experience you have in school outreach, education consulting, or marketing...`,className:`gq-form-textarea`})]}),(0,u.jsx)(`button`,{type:`submit`,disabled:m,className:`gq-btn-primary`,children:m?(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`span`,{className:`spinner-border spinner-border-sm`,role:`status`,"aria-hidden":`true`}),`Submitting Application…`]}):(0,u.jsx)(u.Fragment,{children:`Submit Partner Application →`})}),(0,u.jsx)(`p`,{style:{textAlign:`center`,fontSize:`12px`,color:`#64748B`,margin:`16px 0 0 0`},children:`By submitting, you agree to SchoolProfit’s Partner Terms and Code of Conduct. Applications require administrator verification before activation.`})]})]})]})})]})]})}export{f as default};