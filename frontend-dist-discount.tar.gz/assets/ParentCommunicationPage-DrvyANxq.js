import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{h as t,p as n}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as r,E as i,P as a,d as o,f as s,u as c}from"./index-D6TxbaCx.js";var l=e(),u=n(),d=()=>{let e=new Date().getHours();return e<12?`Good morning`:e<17?`Good afternoon`:`Good evening`};function f(){let[e,n]=(0,l.useState)(!1),[f,p]=(0,l.useState)(!0),[m,h]=(0,l.useState)([]),[g,_]=(0,l.useState)(0),[v,y]=(0,l.useState)(`all`),[b,x]=(0,l.useState)(``),[S,C]=(0,l.useState)(null),w=async()=>{try{p(!0);let e=await a.get(`/parent/communication`);h(e.data.communications||[]),_(e.data.unread_count||0)}catch(e){console.error(`Failed to load communications`,e)}finally{p(!1)}};(0,l.useEffect)(()=>{w()},[]);let T=m.filter(e=>{if(v===`notice`&&e.category!==`notice`&&e.category!==`general`||v===`fee_alert`&&e.category!==`fee_alert`&&e.type!==`fee`||v===`academic`&&e.category!==`academic`)return!1;if(b){let t=b.toLowerCase();return e.title.toLowerCase().includes(t)||e.message.toLowerCase().includes(t)||e.sender.toLowerCase().includes(t)||e.date.toLowerCase().includes(t)}return!0}),E=e=>e.type===`fee`||e.category===`fee_alert`?(0,u.jsxs)(`span`,{className:`badge bg-warning-subtle text-warning fw-bold px-2 py-1`,children:[(0,u.jsx)(`i`,{className:`bi bi-cash-stack me-1`}),`Fee Notice`]}):e.category===`academic`?(0,u.jsxs)(`span`,{className:`badge bg-primary-subtle text-primary fw-bold px-2 py-1`,children:[(0,u.jsx)(`i`,{className:`bi bi-mortarboard-fill me-1`}),`Academic Alert`]}):(0,u.jsxs)(`span`,{className:`badge bg-info-subtle text-info fw-bold px-2 py-1`,children:[(0,u.jsx)(`i`,{className:`bi bi-megaphone-fill me-1`}),`General Announcement`]});return(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');

        .p-comm-main {
          background: #F8FAFC;
          min-height: 100vh;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          padding: calc(66px + 24px) 28px 40px !important;
        }

        @media (max-width: 767.98px) {
          .p-comm-main {
            padding: calc(66px + 16px) 14px 36px !important;
          }
        }

        .p-comm-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 18px;
          padding: 32px 36px;
          color: #FFFFFF;
          margin-bottom: 24px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
          position: relative;
          overflow: hidden;
        }

        @media (max-width: 767.98px) {
          .p-comm-hero {
            padding: 20px 18px !important;
            border-radius: 14px !important;
            margin-bottom: 16px !important;
          }
        }

        .p-comm-hero::before {
          content: '';
          position: absolute;
          inset: 0;
          background-image:
            linear-gradient(rgba(255, 255, 255, 0.035) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255, 255, 255, 0.035) 1px, transparent 1px);
          background-size: 32px 32px;
          pointer-events: none;
        }

        .p-comm-hero-glow {
          position: absolute;
          top: -40px;
          right: -40px;
          width: 320px;
          height: 320px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.2) 0%, transparent 65%);
          pointer-events: none;
        }

        .p-comm-hero-inner {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          flex-wrap: wrap;
          gap: 20px;
        }

        .p-comm-badge {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.20);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius: 100px;
          padding: 4px 12px;
          margin-bottom: 12px;
        }

        .p-comm-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #10B981;
          box-shadow: 0 0 6px #10B981;
        }

        .p-comm-title {
          font-size: 26px;
          font-weight: 800;
          color: #FFFFFF;
          line-height: 1.1;
          margin-bottom: 8px;
        }

        .p-comm-title em {
          font-style: normal;
          color: #FBBF24;
        }

        .p-comm-sub {
          font-size: 13.5px;
          color: #CBD5E1;
          line-height: 1.6;
          max-width: 620px;
          margin-bottom: 0;
        }

        @media (max-width: 767.98px) {
          .p-comm-title {
            font-size: 20px !important;
          }
          .p-comm-sub {
            font-size: 12.5px !important;
          }
        }

        /* Notice Card */
        .p-notice-card {
          background: #FFFFFF;
          border: 1px solid rgba(15, 39, 68, 0.08);
          border-radius: 16px;
          padding: 20px 24px;
          margin-bottom: 16px;
          box-shadow: 0 2px 8px rgba(15, 39, 68, 0.04);
          transition: all 0.2s ease;
          position: relative;
        }

        .p-notice-card:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 24px rgba(15, 39, 68, 0.08);
          border-color: #CBD5E1;
        }

        .p-notice-card.unread {
          border-left: 4px solid #F59E0B;
          background: #FCFDFE;
        }

        .p-notice-meta {
          display: flex;
          align-items: center;
          gap: 12px;
          font-size: 12px;
          color: #64748B;
          margin-bottom: 8px;
          flex-wrap: wrap;
        }

        .p-notice-title {
          font-size: 16px;
          font-weight: 700;
          color: #0F2744;
          margin-bottom: 8px;
        }

        .p-notice-body {
          font-size: 14px;
          color: #334155;
          line-height: 1.6;
          margin-bottom: 12px;
        }
      `}),(0,u.jsx)(s,{sidebarOpen:e,setSidebarOpen:n}),(0,u.jsx)(r,{title:`Communication & Broadcasts - SchoolProfit`}),(0,u.jsx)(`div`,{className:`container-fluid`,children:(0,u.jsxs)(`div`,{className:`row`,children:[(0,u.jsx)(o,{sidebarOpen:e,setSidebarOpen:n}),(0,u.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto gq-app-main p-comm-main d-flex flex-column min-vh-100`,children:[f&&(0,u.jsx)(i,{message:`Loading announcements and notices...`}),(0,u.jsxs)(`div`,{className:`p-comm-hero`,children:[(0,u.jsx)(`div`,{className:`p-comm-hero-glow`}),(0,u.jsxs)(`div`,{className:`p-comm-hero-inner`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsxs)(`div`,{className:`p-comm-badge`,children:[(0,u.jsx)(`span`,{className:`p-comm-dot`}),`Parent Portal · Communication Center`]}),(0,u.jsxs)(`h1`,{className:`p-comm-title`,children:[d(),`, `,(0,u.jsx)(`em`,{children:`Parent.`})]}),(0,u.jsx)(`p`,{className:`p-comm-sub`,children:`Stay informed with official school announcements, administrative circulars, fee billing reminders, and academic notifications.`})]}),g>0&&(0,u.jsxs)(`div`,{className:`badge bg-warning text-dark p-2 px-3 fw-bold rounded-pill`,children:[(0,u.jsx)(`i`,{className:`bi bi-bell-fill me-1`}),g,` Unread Notice`,g>1?`s`:``]})]})]}),(0,u.jsxs)(`div`,{className:`d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3`,children:[(0,u.jsxs)(`div`,{className:`btn-group`,children:[(0,u.jsxs)(`button`,{type:`button`,className:`btn btn-sm ${v===`all`?`btn-dark`:`btn-outline-secondary`}`,onClick:()=>y(`all`),children:[`All Notices (`,m.length,`)`]}),(0,u.jsx)(`button`,{type:`button`,className:`btn btn-sm ${v===`notice`?`btn-dark`:`btn-outline-secondary`}`,onClick:()=>y(`notice`),children:`Announcements`}),(0,u.jsx)(`button`,{type:`button`,className:`btn btn-sm ${v===`fee_alert`?`btn-dark`:`btn-outline-secondary`}`,onClick:()=>y(`fee_alert`),children:`Fee Alerts`}),(0,u.jsx)(`button`,{type:`button`,className:`btn btn-sm ${v===`academic`?`btn-dark`:`btn-outline-secondary`}`,onClick:()=>y(`academic`),children:`Academic`})]}),(0,u.jsxs)(`div`,{className:`d-flex gap-2 align-items-center`,children:[(0,u.jsx)(`input`,{type:`text`,className:`form-control form-control-sm`,style:{maxWidth:240,borderRadius:8},placeholder:`Search notices, senders...`,value:b,onChange:e=>x(e.target.value)}),(0,u.jsxs)(`button`,{type:`button`,className:`btn btn-sm btn-outline-secondary d-flex align-items-center gap-1`,onClick:w,children:[(0,u.jsx)(`i`,{className:`bi bi-arrow-clockwise`}),`Refresh`]})]})]}),T.length===0?(0,u.jsxs)(`div`,{className:`card border-0 shadow-sm rounded-4 p-5 text-center my-4 bg-white`,children:[(0,u.jsx)(`i`,{className:`bi bi-chat-square-dots text-secondary fs-1 mb-3`}),(0,u.jsx)(`h5`,{className:`fw-bold text-dark mb-1`,children:`No Announcements or Messages Found`}),(0,u.jsx)(`p`,{className:`text-muted small mb-0`,children:`You are all caught up! New notices and school circulars will appear here as soon as they are published.`})]}):(0,u.jsx)(`div`,{className:`row`,children:(0,u.jsx)(`div`,{className:`col-12`,children:T.map(e=>(0,u.jsxs)(`div`,{className:`p-notice-card ${e.is_read?``:`unread`}`,children:[(0,u.jsxs)(`div`,{className:`d-flex justify-content-between align-items-start flex-wrap gap-2 mb-2`,children:[(0,u.jsxs)(`div`,{className:`p-notice-meta`,children:[E(e),(0,u.jsxs)(`span`,{className:`fw-semibold text-dark`,children:[(0,u.jsx)(`i`,{className:`bi bi-person-fill me-1 text-muted`}),e.sender]}),(0,u.jsx)(`span`,{children:`•`}),(0,u.jsxs)(`span`,{children:[e.date,` (`,e.time_ago,`)`]})]}),!e.is_read&&(0,u.jsx)(`span`,{className:`badge bg-warning text-dark fw-bold`,style:{fontSize:`11px`},children:`New`})]}),(0,u.jsx)(`h3`,{className:`p-notice-title`,children:e.title}),(0,u.jsx)(`p`,{className:`p-notice-body`,children:e.message}),(0,u.jsx)(`div`,{className:`d-flex align-items-center gap-2 mt-3 pt-2 border-top`,children:e.action_url?(0,u.jsxs)(t,{to:e.action_url,className:`btn btn-sm btn-primary rounded-pill px-3 fw-bold`,children:[`View Related Page `,(0,u.jsx)(`i`,{className:`bi bi-arrow-right ms-1`})]}):(0,u.jsx)(`button`,{type:`button`,className:`btn btn-sm btn-outline-secondary rounded-pill px-3`,onClick:()=>C(e),children:`Read Full Details`})})]},e.id))})}),S&&(0,u.jsx)(`div`,{className:`modal show d-block gq-modal-backdrop`,style:{background:`rgba(15, 39, 68, 0.55)`,backdropFilter:`blur(4px)`},children:(0,u.jsx)(`div`,{className:`modal-dialog modal-dialog-centered`,children:(0,u.jsxs)(`div`,{className:`modal-content rounded-4 border-0 shadow-lg overflow-hidden`,children:[(0,u.jsxs)(`div`,{className:`modal-header text-white`,style:{background:`linear-gradient(135deg, #0A192F 0%, #0F2744 100%)`},children:[(0,u.jsxs)(`h5`,{className:`modal-title fw-bold fs-6`,children:[(0,u.jsx)(`i`,{className:`bi bi-info-circle me-2 text-warning`}),`Notice Details`]}),(0,u.jsx)(`button`,{type:`button`,className:`btn-close btn-close-white`,onClick:()=>C(null)})]}),(0,u.jsxs)(`div`,{className:`modal-body p-4`,children:[(0,u.jsx)(`div`,{className:`mb-3`,children:E(S)}),(0,u.jsx)(`h4`,{className:`fw-bold text-dark mb-2`,children:S.title}),(0,u.jsxs)(`div`,{className:`small text-muted mb-3`,children:[`From: `,(0,u.jsx)(`strong`,{children:S.sender}),` · `,S.date]}),(0,u.jsx)(`div`,{className:`p-3 bg-light rounded-3 text-dark mb-3`,style:{lineHeight:1.7,fontSize:14},children:S.message})]}),(0,u.jsx)(`div`,{className:`modal-footer bg-light`,children:(0,u.jsx)(`button`,{type:`button`,className:`btn btn-secondary rounded-pill px-4`,onClick:()=>C(null),children:`Close`})})]})})}),(0,u.jsx)(c,{})]})]})})]})}export{f as default};