import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{f as t,p as n,u as r}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{B as i,C as a,E as o,P as s,d as ee,f as te,l as ne,u as re}from"./index-D6TxbaCx.js";var c=e(),l=n();function u(e){if(!e)return`-`;let t=new Date(e);return Number.isNaN(t.getTime())?String(e):t.toLocaleString()}function d(e){return e?e.length<=4?e:`${e.slice(0,2)}••••••${e.slice(-2)}`:``}function ie(){let e=new Date().getHours();return e<12?`Good morning`:e<17?`Good afternoon`:`Good evening`}function ae(e){let t=e.trim();if(t.startsWith(`GQ_STAFF_ATTENDANCE:`))return t.replace(`GQ_STAFF_ATTENDANCE:`,``).trim();try{let e=JSON.parse(t);return String(e?.attendance_token||e?.token||``).trim()}catch{return``}}function oe(){return new Promise((e,t)=>{if(!navigator.geolocation){t(Error(`Location is not supported on this browser.`));return}navigator.geolocation.getCurrentPosition(t=>e({latitude:t.coords.latitude,longitude:t.coords.longitude,accuracy:t.coords.accuracy}),()=>t(Error(`Allow location access before marking attendance.`)),{enableHighAccuracy:!0,timeout:12e3,maximumAge:0})})}function se(e){if(!e)return 0;let t=new Date(e).getTime()-Date.now();return Math.max(0,Math.ceil(t/1e3))}function f(){let[e,n]=(0,c.useState)(!1),{showError:f,showSuccess:p,showWarning:m}=ne(),h=(0,c.useMemo)(()=>i(),[]),ce=String(h?.role||``).toLowerCase(),g=[`admin`,`super-admin`,`superadmin`].includes(ce),[_,v]=(0,c.useState)(!1),[y,b]=(0,c.useState)(!1),[x,S]=(0,c.useState)(null),[C,le]=(0,c.useState)(`environment`),[w,ue]=(0,c.useState)(`auto`),[T,E]=(0,c.useState)(null),[D,O]=(0,c.useState)(!1),k=(0,c.useMemo)(()=>typeof window<`u`&&window.location.protocol===`http:`&&window.location.hostname!==`localhost`&&window.location.hostname!==`127.0.0.1`,[]),A=async()=>{try{if(S(null),k){S(`Modern browsers require HTTPS (SSL) for live camera access. Please use HTTPS or use manual code entry below.`);return}if(!navigator.mediaDevices?.getUserMedia){S(`Camera access is not supported on this browser.`);return}(await navigator.mediaDevices.getUserMedia({video:{facingMode:C}})).getTracks().forEach(e=>e.stop()),b(!0),S(null),p?.(`Camera permission granted!`)}catch(e){console.error(`Camera permission error:`,e);let t=e?.name||``;S(t===`NotAllowedError`||t===`PermissionDeniedError`?`Camera permission denied. Tap the lock/tune icon beside your address bar to allow camera access.`:t===`NotFoundError`||t===`DevicesNotFoundError`?`No camera found on this device.`:e?.message||`Unable to access camera.`)}},[de,fe]=(0,c.useState)(``),[pe,me]=(0,c.useState)(0),[j,M]=(0,c.useState)(``),[N,P]=(0,c.useState)(null),[F,I]=(0,c.useState)(null),[L,R]=(0,c.useState)(``),[z,B]=(0,c.useState)(``),[V,H]=(0,c.useState)(``),[he,U]=(0,c.useState)(``),[W,G]=(0,c.useState)(null),[ge,_e]=(0,c.useState)(Date.now()),[K,q]=(0,c.useState)([]),[J,Y]=(0,c.useState)(!1),ve=(0,c.useMemo)(()=>y&&!_,[y,_]),X=()=>le(e=>e===`environment`?`user`:`environment`),Z=async e=>{try{await navigator.clipboard.writeText(e),p?.(`Copied`)}catch{f?.(`Copy failed`)}},ye=e=>{let t=(e||``).toLowerCase();return t===`checkin`?{bg:`#dcfce7`,fg:`#166534`,text:`CHECK-IN`}:t===`checkout`?{bg:`#dbeafe`,fg:`#1d4ed8`,text:`CHECK-OUT`}:{bg:`#e2e8f0`,fg:`#0f172a`,text:(e||`NONE`).toUpperCase()}},be=async()=>{try{O(!0);let e=await s.post(`/staff-attendance/session`,{mode:w});E({token:e.data.token,qr_payload:e.data.qr_payload,mode:e.data.mode,expires_at:e.data.expires_at,ttl_seconds:e.data.ttl_seconds,settings:e.data.settings}),p?.(e.data?.message||`Attendance QR generated`)}catch(e){console.error(e),f?.(e?.response?.data?.message||`Failed to generate attendance QR`)}finally{O(!1)}},xe=async()=>{if(g)try{let e=await s.get(`/staff-attendance/session`);e.data?.data&&E(e.data.data)}catch(e){console.error(e)}};(0,c.useEffect)(()=>{xe()},[]),(0,c.useEffect)(()=>{let e=window.setInterval(()=>_e(Date.now()),1e3);return()=>window.clearInterval(e)},[]);let Se=async(e,t)=>{let n=e.trim();if(!n)return;let r=Date.now();if(!(n===de&&r-pe<4e3)){fe(n),me(r);try{v(!0),R(n),U(new Date().toISOString()),P(null),I(null),B(``),H(``),G(null);let e=ae(n)||n,i=null;i=await oe();let a=(await s.post(`/staff-attendance/mark`,{attendance_token:e,latitude:i?.latitude,longitude:i?.longitude,accuracy:Number.isFinite(i?.accuracy)?i?.accuracy:void 0,source:t,mode:`auto`})).data;if(!a?.success){let e=a?.message||`Failed to mark attendance`;f?.(e),H(e),B(a?.action||`none`),q(t=>[{id:r,created_at:new Date().toISOString(),qr_value:n,status:`failed`,note:e,action:a?.action,user:a?.user,distance_meters:a?.distance_meters},...t]);return}let o=a?.message||`Attendance marked`;p?.(o),P(a.user||null),I(a.attendance||null),B(String(a.action||``)),H(o),G(a.distance_meters??null),q(e=>[{id:r,created_at:new Date().toISOString(),qr_value:n,status:`success`,note:o,action:a?.action,user:a?.user,distance_meters:a?.distance_meters},...e])}catch(e){console.error(e);let t=e?.response?.data?.message||e?.message||(e?.response?.status===404?`Attendance endpoint not found. Add POST /api/staff-attendance/mark in Laravel.`:`Failed to mark attendance`);f?.(t),H(t),B(`none`),P(e?.response?.data?.user||h||null),q(i=>[{id:r,created_at:new Date().toISOString(),qr_value:n,status:`failed`,note:t,user:e?.response?.data?.user||h||void 0},...i])}finally{v(!1)}}},Ce=async()=>{let e=j.trim();if(!e)return m?.(`Enter live attendance QR value`);await Se(e,`manual`),M(``)},Q=(0,c.useMemo)(()=>se(T?.expires_at),[T?.expires_at,ge]),$=(0,c.useMemo)(()=>({total:K.length,success:K.filter(e=>e.status===`success`).length,failed:K.filter(e=>e.status===`failed`).length}),[K]);return(0,l.jsxs)(l.Fragment,{children:[(0,l.jsx)(`style`,{children:`
    /* ======= StaffQrAttendancePage - Modern SaaS style ======= */
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');
    .db-main {
      background: #F8FAFC;
      min-height: 100vh;
      font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
      padding: 24px 28px 0;
    }
    @media (max-width: 991.98px) { .db-main { padding: 18px 14px 0; } }

    .db-hero {
      background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
      border-radius: 18px;
      padding: 32px 36px;
      position: relative;
      overflow: hidden;
      margin: 10px 0 24px;
      box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
    }
    .db-hero-glow {
      position: absolute;
      top: -60px;
      right: -60px;
      width: 320px;
      height: 320px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(217, 119, 6, 0.15) 0%, transparent 65%);
      pointer-events: none;
    }
    .db-hero-glow2 {
      position: absolute;
      bottom: -40px;
      left: 26%;
      width: 220px;
      height: 220px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(37, 99, 235, 0.10) 0%, transparent 70%);
      pointer-events: none;
    }
    .db-hero-inner {
      position: relative;
      z-index: 1;
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
      gap: 28px;
      flex-wrap: wrap;
    }

    .db-session-badge {
      display: inline-flex;
      align-items: center;
      gap: 7px;
      font-size: 11.5px;
      font-weight: 700;
      letter-spacing: 0.04em;
      text-transform: uppercase;
      color: #FBBF24;
      background: rgba(217, 119, 6, 0.20);
      border: 1px solid rgba(217, 119, 6, 0.35);
      border-radius: 100px;
      padding: 4px 12px;
      margin-bottom: 12px;
    }
    .db-session-dot {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: #10B981;
      animation: dbPulse 2s ease infinite;
    }
    @keyframes dbPulse {
      0%,100% { opacity: 1; transform: scale(1); }
      50% { opacity: 0.4; transform: scale(1.5); }
    }
    .db-greeting {
      font-size: 26px;
      font-weight: 800;
      color: #fff;
      line-height: 1.1;
      margin-bottom: 8px;
    }
    .db-greeting em { font-style: normal; color: #FBBF24; }

    .db-hero-sub {
      font-size: 13.5px;
      color: #CBD5E1;
      line-height: 1.6;
      max-width: 720px;
      margin-bottom: 20px;
    }
    .db-hero-btns { display: flex; gap: 10px; flex-wrap: wrap; }

    .db-btn-gold {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 9px 18px;
      font-size: 13px;
      font-weight: 700;
      color: #FFFFFF;
      background: #D97706;
      border: none;
      border-radius: 10px;
      cursor: pointer;
      transition: all 0.2s ease;
      white-space: nowrap;
    }
    .db-btn-gold:hover { background: #B45309; transform: translateY(-1px); color: #FFFFFF; }
    .db-btn-gold:disabled { opacity: 0.55; cursor: not-allowed; transform: none; }

    .db-btn-outline {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 9px 18px;
      font-size: 13px;
      font-weight: 600;
      color: #FFFFFF;
      background: rgba(255, 255, 255, 0.10);
      border: 1px solid rgba(255, 255, 255, 0.20);
      border-radius: 10px;
      cursor: pointer;
      transition: all 0.2s ease;
      white-space: nowrap;
    }
    .db-btn-outline:hover { background: rgba(255, 255, 255, 0.18); color: #fff; }
    .db-btn-outline:disabled { opacity: 0.55; cursor: not-allowed; }

    .db-hero-stat-card {
      background: rgba(255, 255, 255, 0.08);
      border: 1px solid rgba(255, 255, 255, 0.15);
      backdrop-filter: blur(8px);
      border-radius: 14px;
      padding: 18px 20px;
      min-width: 330px;
    }
    @media (max-width: 991.98px) { .db-hero { padding: 24px 20px; } .db-hero-stat-card { min-width: 0; width: 100%; } }
    .db-hero-stat-row { display: flex; flex-direction: column; gap: 10px; }
    .db-hero-stat-item { display: flex; justify-content: space-between; align-items: center; gap: 16px; }
    .db-hero-stat-label { font-size: 12px; font-weight: 400; color: #CBD5E1; }
    .db-hero-stat-val {
      font-size: 18px;
      font-weight: 800;
      color: #FBBF24;
    }
    .db-hero-stat-sep { height: 1px; background: rgba(255, 255, 255, 0.08); }

    .db-panel {
      background: #ffffff;
      border: 1px solid #ede8e0;
      border-radius: 14px;
      overflow: hidden;
      box-shadow: 0 2px 10px rgba(15,23,42,0.04);
    }
    .db-panel-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 16px 18px;
      border-bottom: 1px solid rgba(0, 0, 0, 0.06);
      gap: 12px;
      flex-wrap: wrap;
    }
    .db-panel-title {
      font-family: "Lora", serif;
      font-size: 16px;
      font-weight: 800;
      color: #1a1a2e;
      margin: 0;
    }
    .db-panel-sub { font-size: 11.5px; font-weight: 300; color: #9a8a7a; margin: 0; }

    .db-pill {
      display: inline-flex;
      align-items: center;
      font-size: 12px;
      font-weight: 700;
      padding: 3px 10px;
      border-radius: 999px;
      background: rgba(30, 64, 175, 0.08);
      color: #1e40af;
      border: 1px solid rgba(30, 64, 175, 0.12);
      white-space: nowrap;
    }
    .db-pill--gold {
      background: rgba(180, 83, 9, 0.08);
      color: #b45309;
      border-color: rgba(180, 83, 9, 0.14);
    }
    .db-pill--violet {
      background: rgba(124, 58, 237, 0.08);
      color: #7c3aed;
      border-color: rgba(124, 58, 237, 0.12);
    }
    .db-pill--green {
      background: rgba(6, 95, 70, 0.08);
      color: #065f46;
      border-color: rgba(6, 95, 70, 0.12);
    }
    .db-pill--red {
      background: rgba(185, 28, 28, 0.08);
      color: #b91c1c;
      border-color: rgba(185, 28, 28, 0.12);
    }
    .db-pill--slate {
      background: rgba(100,116,139,0.10);
      color: #334155;
      border-color: rgba(100,116,139,0.14);
    }

    .db-refresh-btn {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 8px 12px;
      font-size: 12px;
      font-weight: 600;
      color: #7a6a5a;
      background: #f5f1eb;
      border: 1px solid #e5ddd3;
      border-radius: 10px;
      cursor: pointer;
      transition: background 0.2s;
      white-space: nowrap;
    }
    .db-refresh-btn:hover { background: #ede8e0; }
    .db-refresh-btn:disabled { opacity: 0.55; cursor: not-allowed; }

    .db-grid2 { display: grid; grid-template-columns: 1.15fr 0.85fr; gap: 18px; margin: 16px 0 18px; }
    @media (max-width: 991.98px) { .db-grid2 { grid-template-columns: 1fr; } }

    .db-input {
      width: 100%;
      padding: 10px 12px;
      border-radius: 10px;
      border: 1px solid #e5ddd3;
      outline: none;
      font-size: 13px;
      background: #fff;
    }
    .db-input:focus { border-color: rgba(201,168,76,0.7); box-shadow: 0 0 0 3px rgba(201,168,76,0.18); }

    .db-table { width: 100%; border-collapse: collapse; }
    .db-table th {
      padding: 10px 14px;
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: #9a8a7a;
      background: #faf8f5;
      border-bottom: 1px solid rgba(0, 0, 0, 0.06);
      text-align: left;
      white-space: nowrap;
    }
    .db-table td {
      padding: 12px 14px;
      font-size: 13.5px;
      color: #4a4a5a;
      border-bottom: 1px solid rgba(0, 0, 0, 0.06);
      vertical-align: middle;
    }
    .db-table tbody tr:hover { background: #faf8f5; }

    .db-foot {
      padding: 12px 18px;
      display: flex;
      justify-content: space-between;
      gap: 12px;
      flex-wrap: wrap;
      border-top: 1px solid rgba(0,0,0,0.06);
      color: #9a8a7a;
      font-size: 12px;
    }

    .db-codeBox {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      padding: 12px 12px;
      border-radius: 12px;
      background: #0b1220;
      color: #fff;
      border: 1px solid rgba(255,255,255,0.08);
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
      letter-spacing: 0.08em;
      font-size: 13px;
    }
    .db-miniBtn {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 8px 10px;
      border-radius: 10px;
      border: 1px solid rgba(255,255,255,0.12);
      background: rgba(255,255,255,0.08);
      color: #fff;
      font-size: 12px;
      font-weight: 700;
      cursor: pointer;
      white-space: nowrap;
    }
    .db-miniBtn:hover { background: rgba(255,255,255,0.14); }
    .db-miniBtn:disabled { opacity: 0.55; cursor: not-allowed; }

    .db-card {
      background: #fff;
      border: 1px solid #ede8e0;
      border-radius: 14px;
      box-shadow: 0 2px 10px rgba(15,23,42,0.04);
      overflow: hidden;
    }
    .db-card-body { padding: 16px 18px; }

    .db-avatar {
      width: 46px;
      height: 46px;
      border-radius: 50%;
      background: #e2e8f0;
      overflow: hidden;
      display: flex;
      align-items: center;
      justify-content: center;
      flex: 0 0 auto;
      border: 1px solid rgba(0,0,0,0.06);
    }
    .db-avatar img { width: 100%; height: 100%; object-fit: cover; }
    .db-muted { color: #9a8a7a; }
    .db-strong { font-weight: 900; color: #1a1a2e; }
    .db-rowline { display: flex; align-items: center; justify-content: space-between; gap: 12px; }
    .db-sep { height: 1px; background: rgba(0,0,0,0.06); margin: 10px 0; }

    .scanWrap {
      position: relative;
      border-radius: 16px;
      border: 1px solid rgba(0,0,0,0.08);
      background: #0b1220;
      overflow: hidden;
      min-height: 360px;
    }
    .scanOverlay {
      position: absolute;
      inset: 0;
      pointer-events: none;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .scanFrame {
      width: 230px;
      height: 230px;
      border-radius: 20px;
      border: 2px dashed rgba(255,255,255,0.55);
      box-shadow: 0 0 0 9999px rgba(0,0,0,0.15) inset;
    }
    .scanPaused {
      height: 360px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      color: #fff;
      opacity: 0.9;
      gap: 6px;
    }

    .logItem {
      border: 1px solid rgba(0,0,0,0.06);
      border-radius: 14px;
      background: #fff;
      padding: 12px 14px;
    }
    .logTop { display: flex; justify-content: space-between; gap: 12px; }
    .logBadges { display: flex; flex-direction: column; gap: 8px; align-items: flex-end; }
    .tag {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      border-radius: 999px;
      padding: 7px 10px;
      font-weight: 900;
      font-size: 12px;
      white-space: nowrap;
    }
  `}),(0,l.jsx)(te,{sidebarOpen:e,setSidebarOpen:n}),(0,l.jsx)(a,{title:`Staff Qr Attendance`}),(0,l.jsx)(`div`,{className:`container-fluid`,children:(0,l.jsxs)(`div`,{className:`row`,children:[(0,l.jsx)(ee,{sidebarOpen:e}),(0,l.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto db-main`,children:[_&&(0,l.jsx)(o,{message:`Marking attendance...`}),(0,l.jsxs)(`div`,{className:`db-hero`,children:[(0,l.jsx)(`div`,{className:`db-hero-glow`,"aria-hidden":`true`}),(0,l.jsx)(`div`,{className:`db-hero-glow2`,"aria-hidden":`true`}),(0,l.jsxs)(`div`,{className:`db-hero-inner`,children:[(0,l.jsxs)(`div`,{children:[(0,l.jsxs)(`div`,{className:`db-session-badge`,children:[(0,l.jsx)(`span`,{className:`db-session-dot`}),`Attendance • Staff QR`]}),(0,l.jsxs)(`h1`,{className:`db-greeting`,children:[ie(),`, `,(0,l.jsx)(`em`,{children:`Admin.`})]}),(0,l.jsx)(`p`,{className:`db-hero-sub`,children:`Generate a school attendance QR code, then staff scan it from their own logged-in device. The system identifies the staff account and confirms the scan location before check-in or check-out.`}),(0,l.jsxs)(`div`,{className:`db-hero-btns`,children:[(0,l.jsxs)(`button`,{className:`db-btn-gold`,onClick:()=>b(!0),disabled:_,title:`Start camera`,children:[(0,l.jsx)(`i`,{className:`bi bi-camera-video`}),`Start scanner`]}),(0,l.jsxs)(`button`,{className:`db-btn-outline`,onClick:X,disabled:_,children:[(0,l.jsx)(`i`,{className:`bi bi-arrow-repeat`}),`Switch camera`]}),(0,l.jsxs)(`button`,{className:`db-btn-outline`,onClick:()=>{b(!1),m?.(`Scanner paused.`)},disabled:_,children:[(0,l.jsx)(`i`,{className:`bi bi-pause`}),`Pause`]})]})]}),(0,l.jsx)(`div`,{className:`db-hero-stat-card d-none d-md-block`,children:(0,l.jsxs)(`div`,{className:`db-hero-stat-row`,children:[(0,l.jsxs)(`div`,{className:`db-rowline`,children:[(0,l.jsx)(`span`,{className:`db-hero-stat-label`,children:`Scans`}),(0,l.jsx)(`span`,{className:`db-hero-stat-val`,children:$.total})]}),(0,l.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,l.jsxs)(`div`,{className:`db-rowline`,children:[(0,l.jsx)(`span`,{className:`db-hero-stat-label`,children:`Success`}),(0,l.jsx)(`span`,{className:`db-hero-stat-val`,children:$.success})]}),(0,l.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,l.jsxs)(`div`,{className:`db-rowline`,children:[(0,l.jsx)(`span`,{className:`db-hero-stat-label`,children:`Failed`}),(0,l.jsx)(`span`,{className:`db-hero-stat-val`,children:$.failed})]}),(0,l.jsx)(`div`,{className:`db-sep`}),(0,l.jsxs)(`div`,{style:{fontSize:12,color:`#cbd5e1`,lineHeight:1.6},children:[`Auto mode uses a single endpoint: `,(0,l.jsx)(`b`,{children:`POST /staff-attendance/mark`}),`.`]})]})})]})]}),g&&(0,l.jsxs)(`div`,{className:`db-panel`,style:{marginBottom:18},children:[(0,l.jsxs)(`div`,{className:`db-panel-head`,children:[(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`p`,{className:`db-panel-title`,children:`School live QR`}),(0,l.jsx)(`p`,{className:`db-panel-sub`,children:`Generate a short-lived QR for staff to scan on arrival or departure`})]}),(0,l.jsxs)(`div`,{style:{display:`flex`,gap:8,flexWrap:`wrap`,alignItems:`center`},children:[(0,l.jsxs)(`select`,{className:`db-input`,style:{width:150},value:w,onChange:e=>ue(e.target.value),disabled:D||_,children:[(0,l.jsx)(`option`,{value:`auto`,children:`Auto`}),(0,l.jsx)(`option`,{value:`checkin`,children:`Check-in only`}),(0,l.jsx)(`option`,{value:`checkout`,children:`Check-out only`})]}),(0,l.jsxs)(`button`,{className:`db-btn-gold`,onClick:be,disabled:D||_,children:[(0,l.jsx)(`i`,{className:`bi bi-qr-code`}),D?`Generating...`:`Generate QR`]})]})]}),(0,l.jsx)(`div`,{className:`db-card-body`,children:T?(0,l.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`repeat(auto-fit, minmax(210px, 1fr))`,gap:18,alignItems:`center`},children:[(0,l.jsx)(`div`,{style:{background:`#fff`,border:`1px solid #ede8e0`,borderRadius:16,padding:16,display:`flex`,justifyContent:`center`},children:(0,l.jsx)(r,{value:T.qr_payload,size:190,includeMargin:!0,level:`H`})}),(0,l.jsxs)(`div`,{style:{display:`grid`,gap:10},children:[(0,l.jsx)(`div`,{className:`db-strong`,children:`Display this QR at the school gate or staff room.`}),(0,l.jsxs)(`div`,{className:`db-muted`,style:{fontSize:12.5,lineHeight:1.6},children:[`Expires at `,(0,l.jsx)(`b`,{children:u(T.expires_at)}),`. Radius:`,` `,(0,l.jsxs)(`b`,{children:[T.settings?.allowed_radius_meters??`configured`,` meters`]}),`. Mode:`,` `,(0,l.jsx)(`b`,{children:T.mode}),`.`]}),(0,l.jsx)(`div`,{className:`db-pill`,style:{width:`fit-content`,background:Q>0?`#dcfce7`:`#fee2e2`,color:Q>0?`#166534`:`#991b1b`,borderColor:`transparent`},children:Q>0?`${Q}s remaining`:`Expired - generate a new QR`}),(0,l.jsxs)(`div`,{className:`db-codeBox`,children:[(0,l.jsx)(`span`,{style:{fontWeight:900},children:d(T.token)}),(0,l.jsxs)(`button`,{className:`db-miniBtn`,onClick:()=>Z(T.qr_payload),children:[(0,l.jsx)(`i`,{className:`bi bi-clipboard`}),` Copy QR value`]})]})]})]}):(0,l.jsx)(`div`,{style:{padding:18,color:`#9a8a7a`,textAlign:`center`},children:`No live QR yet. Generate one when staff are ready to mark attendance.`})})]}),(0,l.jsx)(`div`,{className:`db-panel`,style:{marginBottom:18},children:(0,l.jsxs)(`div`,{className:`db-card-body`,style:{display:`flex`,gap:12,alignItems:`flex-start`},children:[(0,l.jsx)(`div`,{className:`miniCardIcon`,children:(0,l.jsx)(`i`,{className:`bi bi-geo-alt`})}),(0,l.jsxs)(`div`,{style:{display:`grid`,gap:4},children:[(0,l.jsx)(`div`,{className:`db-strong`,style:{fontSize:13.5},children:`Location permission`}),(0,l.jsxs)(`div`,{className:`db-muted`,style:{fontSize:12.5,lineHeight:1.6},children:[`When your browser asks for location access, choose `,(0,l.jsx)(`b`,{children:`Allow`}),`. If you already blocked it, click the lock or site settings icon beside the address bar, allow `,(0,l.jsx)(`b`,{children:`Location`}),`, then refresh this page.`]})]})]})}),(0,l.jsxs)(`div`,{className:`db-grid2`,children:[(0,l.jsxs)(`div`,{className:`db-panel`,children:[(0,l.jsxs)(`div`,{className:`db-panel-head`,children:[(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`p`,{className:`db-panel-title`,children:`QR Scanner`}),(0,l.jsx)(`p`,{className:`db-panel-sub`,children:`Scan staff QR → auto check-in/out`})]}),(0,l.jsxs)(`div`,{style:{display:`flex`,gap:8,flexWrap:`wrap`},children:[(0,l.jsxs)(`button`,{className:`db-refresh-btn`,onClick:()=>b(e=>!e),disabled:_,children:[(0,l.jsx)(`i`,{className:`bi ${y?`bi-pause`:`bi-play`}`}),y?`Pause`:`Start`]}),(0,l.jsxs)(`button`,{className:`db-refresh-btn`,onClick:X,disabled:_,children:[(0,l.jsx)(`i`,{className:`bi bi-arrow-repeat`}),`Switch`]})]})]}),(0,l.jsxs)(`div`,{className:`db-card-body`,children:[k&&(0,l.jsxs)(`div`,{className:`alert alert-warning mb-3`,style:{fontSize:13,borderRadius:12},children:[(0,l.jsx)(`i`,{className:`bi bi-shield-exclamation me-2`}),(0,l.jsx)(`strong`,{children:`Notice:`}),` You are viewing this page over plain `,(0,l.jsx)(`code`,{children:`http://`}),`. Modern mobile browsers (Chrome/Safari) require `,(0,l.jsx)(`strong`,{children:`HTTPS (SSL)`}),` or domain certificate for live camera access. If camera does not start, please use the `,(0,l.jsx)(`strong`,{children:`Manual Entry`}),` below.`]}),(0,l.jsxs)(`div`,{className:`scanWrap`,children:[x?(0,l.jsxs)(`div`,{className:`scanPaused`,style:{padding:`24px 16px`,textAlign:`center`},children:[(0,l.jsx)(`i`,{className:`bi bi-camera-video-off text-danger`,style:{fontSize:38}}),(0,l.jsx)(`div`,{style:{fontWeight:800,fontSize:15,marginTop:8,color:`#991b1b`},children:`Camera Access Notice`}),(0,l.jsx)(`div`,{style:{fontSize:12.5,maxWidth:320,margin:`8px auto 14px`,color:`#64748b`,lineHeight:1.5},children:x}),(0,l.jsx)(`div`,{style:{display:`flex`,gap:8,justifyContent:`center`,flexWrap:`wrap`},children:(0,l.jsxs)(`button`,{type:`button`,className:`db-btn-gold`,onClick:()=>void A(),style:{fontSize:13,padding:`8px 16px`},children:[(0,l.jsx)(`i`,{className:`bi bi-camera-video`}),` Try Enabling Camera`]})}),(0,l.jsxs)(`div`,{style:{fontSize:11.5,color:`#94a3b8`,marginTop:14,lineHeight:1.5,textAlign:`left`,background:`#f8fafc`,padding:`10px 14px`,borderRadius:8},children:[(0,l.jsx)(`strong`,{children:`How to allow camera on your device:`}),(0,l.jsx)(`br`,{}),`• `,(0,l.jsx)(`b`,{children:`Android / Chrome:`}),` Tap the tune/lock icon in the URL bar → Permissions → Camera → Allow.`,(0,l.jsx)(`br`,{}),`• `,(0,l.jsx)(`b`,{children:`iPhone / Safari:`}),` Tap `,(0,l.jsx)(`b`,{children:`AA`}),` or page settings in URL bar → Website Settings → Camera → Allow.`]})]}):y?(0,l.jsx)(t,{constraints:{facingMode:C},onScan:e=>{if(!ve)return;let t=String(e?.[0]?.rawValue||``).trim();t&&(b(!1),Se(t,`camera`).finally(()=>{setTimeout(()=>b(!0),1400)}))},onError:e=>{console.error(e),S(k?`Live camera requires HTTPS (SSL). Modern browsers block camera on plain HTTP IP addresses. Please use manual entry or connect via domain HTTPS.`:`Camera error or permission denied. Please allow camera permissions in your browser.`),b(!1)},styles:{container:{width:`100%`,height:360},video:{width:`100%`,height:360,objectFit:`cover`}}}):(0,l.jsxs)(`div`,{className:`scanPaused`,style:{padding:24,textAlign:`center`},children:[(0,l.jsx)(`i`,{className:`bi bi-camera-video-off`,style:{fontSize:38}}),(0,l.jsx)(`div`,{style:{fontWeight:800,fontSize:15,marginTop:8},children:`Scanner Ready`}),(0,l.jsx)(`div`,{style:{fontSize:12.5,opacity:.85,margin:`6px 0 16px`},children:`Click the button below to start your device camera.`}),(0,l.jsxs)(`button`,{type:`button`,className:`db-btn-gold`,onClick:()=>void A(),children:[(0,l.jsx)(`i`,{className:`bi bi-camera-video`}),` Start Camera Scanner`]})]}),y&&!x&&(0,l.jsx)(`div`,{className:`scanOverlay`,"aria-hidden":`true`,children:(0,l.jsx)(`div`,{className:`scanFrame`})})]}),(0,l.jsx)(`div`,{className:`db-sep`}),(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`div`,{className:`db-strong`,style:{fontSize:14,marginBottom:6},children:`Manual entry (fallback)`}),(0,l.jsxs)(`div`,{style:{display:`flex`,gap:10,flexWrap:`wrap`,alignItems:`center`},children:[(0,l.jsx)(`input`,{className:`db-input`,style:{flex:1,minWidth:240},placeholder:`Paste live attendance QR value...`,value:j,onChange:e=>M(e.target.value),onKeyDown:e=>{e.key===`Enter`&&Ce()},disabled:_}),(0,l.jsxs)(`button`,{className:`db-btn-gold`,onClick:Ce,disabled:_,children:[(0,l.jsx)(`i`,{className:`bi bi-check2-circle`}),`Mark`]})]}),(0,l.jsx)(`div`,{style:{marginTop:8,fontSize:12,color:`#9a8a7a`},children:`If camera permission fails, paste the live QR value and mark attendance.`})]})]}),(0,l.jsxs)(`div`,{className:`db-foot`,children:[(0,l.jsxs)(`div`,{children:[`Mode: `,(0,l.jsx)(`b`,{children:y?`Camera`:`Paused`}),` • Facing: `,(0,l.jsx)(`b`,{children:C})]}),(0,l.jsx)(`div`,{children:`Throttle: same code ignored for 4s`})]})]}),(0,l.jsxs)(`div`,{style:{display:`grid`,gap:18},children:[(0,l.jsxs)(`div`,{className:`db-panel`,children:[(0,l.jsxs)(`div`,{className:`db-panel-head`,children:[(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`p`,{className:`db-panel-title`,children:`Last action`}),(0,l.jsx)(`p`,{className:`db-panel-sub`,children:`Staff + check-in/out result`})]}),(0,l.jsxs)(`button`,{className:`db-refresh-btn`,onClick:()=>Y(e=>!e),disabled:!L,title:`Reveal/Mask code`,children:[(0,l.jsx)(`i`,{className:`bi ${J?`bi-eye-slash`:`bi-eye`}`}),J?`Mask`:`Reveal`]})]}),(0,l.jsx)(`div`,{className:`db-card-body`,children:(0,l.jsx)(`div`,{className:`db-card`,children:(0,l.jsxs)(`div`,{className:`db-card-body`,children:[(0,l.jsxs)(`div`,{style:{display:`flex`,gap:12,alignItems:`center`},children:[(0,l.jsx)(`div`,{className:`db-avatar`,style:{width:54,height:54},children:N?.photo?(0,l.jsx)(`img`,{src:N.photo,alt:`staff`}):(0,l.jsx)(`i`,{className:`bi bi-person-fill`,style:{color:`#64748b`,fontSize:22}})}),(0,l.jsxs)(`div`,{style:{flex:1,minWidth:0},children:[(0,l.jsx)(`div`,{className:`db-strong`,style:{fontSize:14},children:N?`${N.firstname??``} ${N.surname??``}`.trim():`-`}),(0,l.jsx)(`div`,{className:`db-muted`,style:{fontSize:12},children:N?.email||`-`}),(0,l.jsxs)(`div`,{className:`db-muted`,style:{fontSize:12},children:[`Reg No: `,(0,l.jsx)(`b`,{children:N?.reg_no||`-`})]})]}),z?(()=>{let e=ye(z);return(0,l.jsx)(`span`,{className:`db-pill`,style:{background:e.bg,color:e.fg,borderColor:`transparent`},children:e.text})})():(0,l.jsx)(`span`,{className:`db-pill db-pill--slate`,children:`—`})]}),(0,l.jsx)(`div`,{style:{height:12}}),(0,l.jsxs)(`div`,{className:`db-codeBox`,children:[(0,l.jsx)(`span`,{style:{fontWeight:900},children:J?L:d(L)||`—`}),(0,l.jsxs)(`button`,{className:`db-miniBtn`,onClick:()=>L&&Z(L),disabled:!L,children:[(0,l.jsx)(`i`,{className:`bi bi-clipboard`}),` Copy`]})]}),(0,l.jsxs)(`div`,{style:{marginTop:10,fontSize:12,color:`#9a8a7a`},children:[`Time: `,(0,l.jsx)(`b`,{children:he?u(he):`—`})]}),W!==null&&(0,l.jsxs)(`div`,{style:{marginTop:8,fontSize:12.5,color:`#1a1a2e`,lineHeight:1.5},children:[(0,l.jsx)(`i`,{className:`bi bi-geo-alt`,style:{marginRight:6,color:`#16a34a`}}),`Location checked: about `,(0,l.jsxs)(`b`,{children:[W,`m`]}),` from the configured school point.`]}),V&&(0,l.jsxs)(`div`,{style:{marginTop:8,fontSize:12.5,color:`#1a1a2e`,lineHeight:1.5},children:[(0,l.jsx)(`i`,{className:`bi bi-info-circle`,style:{marginRight:6,color:`#64748b`}}),V]}),F&&(0,l.jsxs)(l.Fragment,{children:[(0,l.jsx)(`div`,{className:`db-sep`}),(0,l.jsxs)(`div`,{style:{display:`grid`,gap:8},children:[(0,l.jsxs)(`div`,{className:`db-rowline`,children:[(0,l.jsx)(`span`,{className:`db-muted`,style:{fontSize:12},children:`Date`}),(0,l.jsx)(`span`,{className:`db-strong`,style:{fontSize:12.5},children:F.att_date})]}),(0,l.jsxs)(`div`,{className:`db-rowline`,children:[(0,l.jsx)(`span`,{className:`db-muted`,style:{fontSize:12},children:`Check-in`}),(0,l.jsx)(`span`,{className:`db-strong`,style:{fontSize:12.5},children:u(F.check_in_at)})]}),(0,l.jsxs)(`div`,{className:`db-rowline`,children:[(0,l.jsx)(`span`,{className:`db-muted`,style:{fontSize:12},children:`Check-out`}),(0,l.jsx)(`span`,{className:`db-strong`,style:{fontSize:12.5},children:u(F.check_out_at)})]})]})]}),(0,l.jsx)(`div`,{style:{height:12}}),(0,l.jsxs)(`div`,{style:{display:`flex`,gap:10,flexWrap:`wrap`},children:[(0,l.jsxs)(`button`,{className:`db-refresh-btn`,onClick:()=>{P(null),I(null),R(``),B(``),H(``),U(``),G(null),Y(!1)},disabled:_,children:[(0,l.jsx)(`i`,{className:`bi bi-arrow-repeat`}),`Clear panel`]}),(0,l.jsxs)(`button`,{className:`db-refresh-btn`,onClick:()=>{Z([`Name: ${(N?`${N.firstname??``} ${N.surname??``}`.trim():`-`)||`-`}`,`Reg No: ${N?.reg_no||`-`}`,`Email: ${N?.email||`-`}`,`Action: ${z||`-`}`,`Date: ${F?.att_date??`-`}`,`Check-in: ${F?.check_in_at??`-`}`,`Check-out: ${F?.check_out_at??`-`}`,`Message: ${V||`-`}`,`Distance: ${W===null?`-`:`${W}m`}`,`Code: ${L||`-`}`].join(`
`))},disabled:!L,children:[(0,l.jsx)(`i`,{className:`bi bi-share`}),`Copy details`]})]})]})})}),(0,l.jsxs)(`div`,{className:`db-foot`,children:[(0,l.jsxs)(`div`,{children:[`Endpoint: `,(0,l.jsx)(`b`,{children:`POST /staff-attendance/mark`})]}),(0,l.jsxs)(`div`,{children:[`Mode: `,(0,l.jsx)(`b`,{children:`auto`})]})]})]}),(0,l.jsxs)(`div`,{className:`db-panel`,children:[(0,l.jsxs)(`div`,{className:`db-panel-head`,children:[(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`p`,{className:`db-panel-title`,children:`Scan log`}),(0,l.jsx)(`p`,{className:`db-panel-sub`,children:`UI log (latest first)`})]}),(0,l.jsxs)(`button`,{className:`db-refresh-btn`,onClick:()=>q([]),disabled:K.length===0,title:`Clear logs`,children:[(0,l.jsx)(`i`,{className:`bi bi-trash3`}),`Clear`]})]}),(0,l.jsxs)(`div`,{className:`db-card-body`,children:[K.length===0?(0,l.jsx)(`div`,{style:{padding:18,textAlign:`center`,color:`#9a8a7a`},children:`No scans yet. Start scanning to see activity here.`}):(0,l.jsx)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:10,maxHeight:380,overflow:`auto`},children:K.map(e=>{let t=e.user?`${e.user.firstname??``} ${e.user.surname??``}`.trim():`Unknown staff`,n=ye(e.action),r=e.status===`success`;return(0,l.jsxs)(`div`,{className:`logItem`,children:[(0,l.jsxs)(`div`,{className:`logTop`,children:[(0,l.jsxs)(`div`,{style:{minWidth:0},children:[(0,l.jsx)(`div`,{className:`db-strong`,style:{fontSize:13.5},children:t}),(0,l.jsx)(`div`,{className:`db-muted`,style:{fontSize:12},children:u(e.created_at)}),(0,l.jsx)(`div`,{style:{marginTop:6,fontSize:12.5,color:`#4a4a5a`,lineHeight:1.5},children:e.note})]}),(0,l.jsxs)(`div`,{className:`logBadges`,children:[(0,l.jsx)(`span`,{className:`tag`,style:{background:r?`#dcfce7`:`#fee2e2`,color:r?`#166534`:`#991b1b`},children:r?`SUCCESS`:`FAILED`}),(0,l.jsx)(`span`,{className:`tag`,style:{background:n.bg,color:n.fg,fontSize:11,padding:`6px 10px`},children:n.text})]})]}),(0,l.jsxs)(`div`,{style:{marginTop:10,display:`flex`,alignItems:`center`,justifyContent:`space-between`,gap:10},children:[(0,l.jsx)(`div`,{style:{fontFamily:`ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace`,fontSize:12.5,color:`#0b1220`,letterSpacing:`0.06em`},children:d(e.qr_value)}),(0,l.jsxs)(`button`,{className:`db-refresh-btn`,onClick:()=>void Z(e.qr_value),children:[(0,l.jsx)(`i`,{className:`bi bi-clipboard`}),`Copy`]})]})]},e.id)})}),(0,l.jsx)(`div`,{style:{marginTop:12,fontSize:12,color:`#9a8a7a`},children:`Tip: Scan once to check-in. Scan again later to check-out (auto mode).`})]}),(0,l.jsxs)(`div`,{className:`db-foot`,children:[(0,l.jsx)(`div`,{children:`Keep camera steady; align QR within the frame.`}),(0,l.jsx)(`div`,{children:`Manual entry is supported.`})]})]})]})]}),(0,l.jsx)(`div`,{className:`mt-auto`,children:(0,l.jsx)(re,{})})]})]})})]})}export{f as default};