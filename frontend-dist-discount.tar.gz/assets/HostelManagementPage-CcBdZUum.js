import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{p as t}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as n,P as r,d as i,f as a,u as o}from"./index-D6TxbaCx.js";var s=e();const c={dashboard:e=>r.get(`/hostels`,{params:e}),createHostel:e=>r.post(`/hostels`,e),updateHostel:(e,t)=>r.patch(`/hostels/${e}`,t),createRoom:(e,t)=>r.post(`/hostels/${e}/rooms`,t),updateRoom:(e,t)=>r.patch(`/hostels/rooms/${e}`,t),allocate:e=>r.post(`/hostels/allocations`,e),checkout:(e,t)=>r.post(`/hostels/allocations/${e}/checkout`,{reason:t}),transfer:(e,t,n)=>r.post(`/hostels/allocations/${e}/transfer`,{hostel_room_id:t,reason:n})};var l=t(),u={name:``,gender:`mixed`,warden_name:``,warden_phone:``,address:``},d=e=>e?.response?.data?.message||Object.values(e?.response?.data?.errors||{}).flat()[0]||`Something went wrong.`,f=e=>`${e.firstname||``} ${e.surname||``}`.trim();function p(){let[e,t]=(0,s.useState)(!1),[r,p]=(0,s.useState)({hostels:[],students:[],allocations:[],history:[],sessions:[],terms:[],summary:{hostels:0,rooms:0,capacity:0,occupied:0}}),[m,h]=(0,s.useState)(!0),[g,_]=(0,s.useState)(!1),[v,y]=(0,s.useState)(``),[b,x]=(0,s.useState)(``),[S,C]=(0,s.useState)(u),[w,T]=(0,s.useState)({hostel_id:``,name:``,floor:``,capacity:1}),[E,D]=(0,s.useState)({student_id:``,hostel_room_id:``,session_id:``,term_id:``,notes:``}),[O,k]=(0,s.useState)(``),[A,j]=(0,s.useState)(``),[M,N]=(0,s.useState)(``),[P,F]=(0,s.useState)({allocation_id:0,room_id:``,reason:``}),I=async()=>{h(!0),y(``);try{let e=await c.dashboard({...A?{session_id:A}:{},...M?{term_id:M}:{}});p(e.data),D(t=>({...t,session_id:t.session_id||String(e.data.selected_session_id||``),term_id:t.term_id||String(e.data.selected_term_id||``)}))}catch(e){y(String(d(e)))}finally{h(!1)}};(0,s.useEffect)(()=>{I()},[A,M]);let L=(0,s.useMemo)(()=>r.hostels.flatMap(e=>e.rooms.map(t=>({...t,hostel:e}))),[r.hostels]).filter(e=>e.is_active&&e.hostel.is_active&&e.occupied<e.capacity),R=r.allocations.filter(e=>`${f(e.student)} ${e.student.reg_no||``} ${e.hostel.name} ${e.room.name}`.toLowerCase().includes(O.toLowerCase())),z=r.summary.capacity?Math.round(r.summary.occupied/r.summary.capacity*100):0,B=async(e,t)=>{_(!0),y(``),x(``);try{return await e(),x(t),await I(),!0}catch(e){return y(String(d(e))),!1}finally{_(!1)}},V=async e=>{e.preventDefault(),await B(()=>c.createHostel(S),`Hostel created successfully.`)&&C(u)},H=async e=>{e.preventDefault(),await B(()=>c.createRoom(Number(w.hostel_id),w),`Room added successfully.`)&&T({hostel_id:``,name:``,floor:``,capacity:1})},U=async e=>{e.preventDefault(),await B(()=>c.allocate(E),`Student allocated successfully.`)&&D(e=>({student_id:``,hostel_room_id:``,session_id:e.session_id,term_id:e.term_id,notes:``}))},W=e=>{let t=window.prompt(`Hostel name`,e.name);if(!t)return;let n=window.prompt(`Warden name`,e.warden_name||``)??e.warden_name;B(()=>c.updateHostel(e.id,{name:t,warden_name:n}),`Hostel updated.`)},G=e=>{let t=window.prompt(`Room name`,e.name);if(!t)return;let n=Number(window.prompt(`Bed capacity`,String(e.capacity)));n&&B(()=>c.updateRoom(e.id,{name:t,capacity:n}),`Room updated.`)},K=async()=>{!P.allocation_id||!P.room_id||P.reason.trim().length<3||await B(()=>c.transfer(P.allocation_id,Number(P.room_id),P.reason),`Student transferred successfully.`)&&F({allocation_id:0,room_id:``,reason:``})};return(0,l.jsxs)(l.Fragment,{children:[(0,l.jsx)(n,{title:`Hostel Management`}),(0,l.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');

        :root {
          --sp-dark: #0F2744;
          --sp-accent: #D97706;
          --sp-accent-dim: rgba(217, 119, 6, 0.10);
          --sp-accent-border: rgba(217, 119, 6, 0.25);
          --sp-light: #FFFFFF;
          --sp-border: #E2E8F0;
        }

        .db-main {
          padding: 24px 28px 48px;
          background: #F8FAFC;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          min-height: 100vh;
        }

        /* Hero */
        .db-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 18px;
          padding: 32px 36px;
          position: relative;
          overflow: hidden;
          margin-bottom: 24px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
        }
        .db-hero-glow {
          position: absolute;
          top: -90px;
          right: -40px;
          width: 380px;
          height: 380px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.15), transparent 70%);
          pointer-events: none;
        }
        .db-hero-inner {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 28px;
          flex-wrap: wrap;
        }
        .db-kicker {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.20);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius: 999px;
          padding: 4px 12px;
          margin-bottom: 12px;
        }
        .db-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #10B981;
        }
        .db-title {
          font-size: 26px;
          font-weight: 800;
          color: #fff;
          line-height: 1.15;
          margin: 0 0 8px;
        }
        .db-title em {
          color: #FBBF24;
          font-style: normal;
        }
        .db-hero-sub {
          font-size: 13.5px;
          color: #CBD5E1;
          line-height: 1.6;
          max-width: 600px;
          margin: 0;
        }
        .db-btn-gold {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          background: #D97706;
          color: #FFFFFF;
          font-weight: 700;
          font-size: 13px;
          padding: 9px 18px;
          border-radius: 10px;
          border: none;
          cursor: pointer;
          transition: all 0.2s ease;
        }
        .db-btn-gold:hover {
          background: #B45309;
          transform: translateY(-1px);
          color: #FFFFFF;
        }
          text-decoration: none;
        }
        .db-btn-gold:hover {
          background: linear-gradient(135deg, #d4b55a 0%, #c4a245 100%);
          transform: translateY(-1px);
          color: #050008;
        }
        .db-hero-stats {
          background: rgba(255,255,255,0.06);
          border: 1px solid rgba(255,255,255,0.1);
          border-radius: 14px;
          padding: 16px 20px;
          min-width: 260px;
          backdrop-filter: blur(10px);
        }
        .db-hero-row {
          display: flex;
          justify-content: space-between;
          gap: 24px;
          padding: 6px 0;
          color: #94a3b8;
          font-size: 12.5px;
        }
        .db-hero-row + .db-hero-row {
          border-top: 1px solid rgba(255,255,255,0.08);
        }
        .db-hero-row strong {
          font-family: "Playfair Display", Georgia, serif;
          color: #fff;
          font-size: 16px;
        }

        /* KPI Cards */
        .db-stats {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
          gap: 16px;
          margin-bottom: 24px;
        }
        .db-stat {
          background: #fff;
          border: 1px solid var(--sp-border);
          border-radius: 16px;
          padding: 20px;
          position: relative;
          overflow: hidden;
          transition: transform 0.2s, box-shadow 0.2s;
        }
        .db-stat:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 24px rgba(5,0,8,0.06);
        }
        .db-stat::before {
          content: "";
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          height: 3px;
          background: var(--sc, #c9a84c);
        }
        .db-stat-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 12px;
        }
        .db-stat-label {
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          color: #7a6a5a;
        }
        .db-stat-icon {
          width: 36px;
          height: 36px;
          border-radius: 10px;
          background: var(--si, rgba(201,168,76,0.12));
          color: var(--sc, #c9a84c);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 16px;
        }
        .db-stat-val {
          font-family: "Playfair Display", Georgia, serif;
          font-size: 26px;
          font-weight: 700;
          color: #1a1a2e;
          line-height: 1.1;
        }
        .db-stat-sub {
          font-size: 11.5px;
          color: #9a8a7a;
          margin-top: 4px;
        }

        /* Panel */
        .db-panel {
          background: #fff;
          border: 1px solid var(--sp-border);
          border-radius: 16px;
          box-shadow: 0 4px 20px rgba(5,0,8,0.04);
          overflow: hidden;
        }
        .db-panel-head {
          padding: 18px 22px;
          border-bottom: 1px solid var(--sp-border);
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 16px;
          flex-wrap: wrap;
          background: #faf8f5;
        }
        .db-panel-title {
          font-family: "Playfair Display", Georgia, serif;
          font-size: 16px;
          font-weight: 700;
          color: #1a1a2e;
          margin: 0;
        }
        .db-panel-sub {
          font-size: 11.5px;
          color: #7a6a5a;
          margin: 2px 0 0;
        }

        /* Forms */
        .db-form-label {
          font-size: 12px;
          font-weight: 600;
          color: #5a4d41;
          margin-bottom: 5px;
        }
        .db-form-control, .db-form-select {
          border: 1px solid #e5ddd3;
          border-radius: 10px;
          padding: 8px 12px;
          font-size: 13px;
          background: #fff;
          color: #1a1a2e;
        }
        .db-form-control:focus, .db-form-select:focus {
          border-color: #c9a84c;
          box-shadow: 0 0 0 3px rgba(201,168,76,0.18);
          outline: none;
        }

        /* Badges */
        .db-badge {
          display: inline-flex;
          align-items: center;
          gap: 5px;
          padding: 4px 10px;
          border-radius: 999px;
          font-size: 11.5px;
          font-weight: 700;
          white-space: nowrap;
        }
        .db-badge--blue { background: rgba(59,130,246,0.12); color: #1d4ed8; }
        .db-badge--green { background: rgba(34,197,94,0.14); color: #15803d; }
        .db-badge--amber { background: rgba(245,158,11,0.14); color: #b45309; }
        .db-badge--red { background: rgba(239,68,68,0.12); color: #dc2626; }
        .db-badge--gray { background: rgba(100,116,139,0.14); color: #475569; }

        /* Icon action buttons */
        .db-icon-btn {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          width: 34px;
          height: 34px;
          border-radius: 8px;
          font-size: 14px;
          border: 1px solid #e5ddd3;
          background: #f5f1eb;
          color: #7a6a5a;
          cursor: pointer;
          transition: all 0.2s ease;
          flex-shrink: 0;
        }
        .db-icon-btn:hover { background: #ede8e0; transform: translateY(-1px); }
        .db-icon-btn--p { background: rgba(99,102,241,0.12); border-color: rgba(99,102,241,0.25); color: #4338ca; }
        .db-icon-btn--p:hover { background: rgba(99,102,241,0.22); }
        .db-icon-btn--r { background: rgba(244,63,94,0.10); border-color: rgba(244,63,94,0.25); color: #be123c; }
        .db-icon-btn--r:hover { background: rgba(244,63,94,0.20); }
      `}),(0,l.jsx)(a,{sidebarOpen:e,setSidebarOpen:t,title:`Hostel Management`}),(0,l.jsx)(`div`,{className:`container-fluid`,children:(0,l.jsxs)(`div`,{className:`row`,children:[(0,l.jsx)(i,{sidebarOpen:e,setSidebarOpen:t}),(0,l.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto db-main`,children:[(0,l.jsxs)(`div`,{className:`db-hero`,children:[(0,l.jsx)(`div`,{className:`db-hero-glow`}),(0,l.jsxs)(`div`,{className:`db-hero-inner`,children:[(0,l.jsxs)(`div`,{children:[(0,l.jsxs)(`div`,{className:`db-kicker`,children:[(0,l.jsx)(`span`,{className:`db-dot`}),`Accommodation Operations & Housing`]}),(0,l.jsxs)(`h1`,{className:`db-title`,children:[`Hostel `,(0,l.jsx)(`em`,{children:`Management`})]}),(0,l.jsx)(`p`,{className:`db-hero-sub`,children:`Configure dormitory buildings, manage bed space capacity, allocate student accommodation, and track live occupancy.`})]}),(0,l.jsxs)(`div`,{className:`db-hero-stats d-none d-md-block`,children:[(0,l.jsxs)(`div`,{className:`db-hero-row`,children:[(0,l.jsx)(`span`,{children:`Occupancy Rate`}),(0,l.jsxs)(`strong`,{children:[z,`%`]})]}),(0,l.jsxs)(`div`,{className:`db-hero-row`,children:[(0,l.jsx)(`span`,{children:`Available Spaces`}),(0,l.jsx)(`strong`,{children:Math.max(0,r.summary.capacity-r.summary.occupied)})]}),(0,l.jsxs)(`div`,{className:`db-hero-row`,children:[(0,l.jsx)(`span`,{children:`Active Hostels`}),(0,l.jsx)(`strong`,{children:r.summary.hostels})]})]})]})]}),v&&(0,l.jsxs)(`div`,{className:`alert alert-danger d-flex align-items-center gap-2 mb-4`,role:`alert`,children:[(0,l.jsx)(`i`,{className:`bi bi-exclamation-triangle-fill`}),(0,l.jsx)(`div`,{children:v})]}),b&&(0,l.jsxs)(`div`,{className:`alert alert-success d-flex align-items-center gap-2 mb-4`,role:`alert`,children:[(0,l.jsx)(`i`,{className:`bi bi-check-circle-fill`}),(0,l.jsx)(`div`,{children:b})]}),(0,l.jsx)(`div`,{className:`db-panel mb-4`,children:(0,l.jsxs)(`div`,{className:`p-3 d-flex flex-wrap align-items-end gap-3`,style:{background:`#faf8f5`},children:[(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Academic Session`}),(0,l.jsxs)(`select`,{className:`form-select db-form-select`,value:A,onChange:e=>j(e.target.value),children:[(0,l.jsx)(`option`,{value:``,children:`Current Session`}),r.sessions.map(e=>(0,l.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]}),(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Term`}),(0,l.jsxs)(`select`,{className:`form-select db-form-select`,value:M,onChange:e=>N(e.target.value),children:[(0,l.jsx)(`option`,{value:``,children:`All Terms`}),r.terms.map(e=>(0,l.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]}),(0,l.jsxs)(`button`,{className:`db-btn-gold ms-auto`,onClick:()=>{let e=[[`Admission No`,`Student`,`Gender`,`Hostel`,`Room`,`Session`,`Term`,`Allocated`],...R.map(e=>[e.student.reg_no||``,f(e.student),e.student.sex||``,e.hostel.name,e.room.name,e.session?.name||``,e.term?.name||``,new Date(e.allocated_at).toLocaleDateString()])],t=new Blob([e.map(e=>e.map(e=>`"${String(e).replaceAll(`"`,`""`)}"`).join(`,`)).join(`
`)],{type:`text/csv`}),n=document.createElement(`a`);n.href=URL.createObjectURL(t),n.download=`hostel-allocations.csv`,n.click(),URL.revokeObjectURL(n.href)},disabled:!R.length,style:{padding:`8px 16px`,fontSize:12.5},children:[(0,l.jsx)(`i`,{className:`bi bi-download`}),`Export Allocations CSV`]})]})}),(0,l.jsxs)(`div`,{className:`db-stats`,children:[(0,l.jsxs)(`div`,{className:`db-stat`,style:{"--sc":`#2563eb`,"--si":`rgba(37,99,235,0.10)`},children:[(0,l.jsxs)(`div`,{className:`db-stat-head`,children:[(0,l.jsx)(`span`,{className:`db-stat-label`,children:`Hostels`}),(0,l.jsx)(`div`,{className:`db-stat-icon`,children:(0,l.jsx)(`i`,{className:`bi bi-buildings`})})]}),(0,l.jsx)(`div`,{className:`db-stat-val`,children:r.summary.hostels}),(0,l.jsx)(`div`,{className:`db-stat-sub`,children:`Accommodation buildings`})]}),(0,l.jsxs)(`div`,{className:`db-stat`,style:{"--sc":`#0891b2`,"--si":`rgba(8,145,178,0.10)`},children:[(0,l.jsxs)(`div`,{className:`db-stat-head`,children:[(0,l.jsx)(`span`,{className:`db-stat-label`,children:`Rooms`}),(0,l.jsx)(`div`,{className:`db-stat-icon`,children:(0,l.jsx)(`i`,{className:`bi bi-door-open`})})]}),(0,l.jsx)(`div`,{className:`db-stat-val`,children:r.summary.rooms}),(0,l.jsx)(`div`,{className:`db-stat-sub`,children:`Configured dormitory rooms`})]}),(0,l.jsxs)(`div`,{className:`db-stat`,style:{"--sc":`#b45309`,"--si":`rgba(245,158,11,0.12)`},children:[(0,l.jsxs)(`div`,{className:`db-stat-head`,children:[(0,l.jsx)(`span`,{className:`db-stat-label`,children:`Bed Capacity`}),(0,l.jsx)(`div`,{className:`db-stat-icon`,children:(0,l.jsx)(`i`,{className:`bi bi-grid-3x3-gap`})})]}),(0,l.jsx)(`div`,{className:`db-stat-val`,children:r.summary.capacity}),(0,l.jsx)(`div`,{className:`db-stat-sub`,children:`Total student bed spaces`})]}),(0,l.jsxs)(`div`,{className:`db-stat`,style:{"--sc":`#15803d`,"--si":`rgba(34,197,94,0.12)`},children:[(0,l.jsxs)(`div`,{className:`db-stat-head`,children:[(0,l.jsx)(`span`,{className:`db-stat-label`,children:`Students Housed`}),(0,l.jsx)(`div`,{className:`db-stat-icon`,children:(0,l.jsx)(`i`,{className:`bi bi-people`})})]}),(0,l.jsx)(`div`,{className:`db-stat-val`,children:r.summary.occupied}),(0,l.jsxs)(`div`,{className:`db-stat-sub`,children:[z,`% occupancy rate`]})]})]}),(0,l.jsxs)(`div`,{className:`row g-4 mb-4`,children:[(0,l.jsx)(`div`,{className:`col-xl-4`,children:(0,l.jsxs)(`div`,{className:`db-panel h-100`,children:[(0,l.jsx)(`div`,{className:`db-panel-head`,children:(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`h5`,{className:`db-panel-title`,children:`Add Hostel`}),(0,l.jsx)(`p`,{className:`db-panel-sub`,children:`Create an accommodation building`})]})}),(0,l.jsxs)(`form`,{className:`p-4`,onSubmit:V,children:[(0,l.jsxs)(`div`,{className:`mb-3`,children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Hostel Name`}),(0,l.jsx)(`input`,{className:`form-control db-form-control`,required:!0,value:S.name,onChange:e=>C({...S,name:e.target.value}),placeholder:`e.g. Mandela Hall`})]}),(0,l.jsxs)(`div`,{className:`row g-2 mb-3`,children:[(0,l.jsxs)(`div`,{className:`col-5`,children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Gender`}),(0,l.jsxs)(`select`,{className:`form-select db-form-select`,value:S.gender,onChange:e=>C({...S,gender:e.target.value}),children:[(0,l.jsx)(`option`,{value:`mixed`,children:`Mixed`}),(0,l.jsx)(`option`,{value:`male`,children:`Male`}),(0,l.jsx)(`option`,{value:`female`,children:`Female`})]})]}),(0,l.jsxs)(`div`,{className:`col-7`,children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Warden Name`}),(0,l.jsx)(`input`,{className:`form-control db-form-control`,value:S.warden_name,onChange:e=>C({...S,warden_name:e.target.value}),placeholder:`e.g. Mr. Okon`})]})]}),(0,l.jsxs)(`div`,{className:`mb-4`,children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Warden Phone`}),(0,l.jsx)(`input`,{className:`form-control db-form-control`,value:S.warden_phone,onChange:e=>C({...S,warden_phone:e.target.value}),placeholder:`e.g. 08012345678`})]}),(0,l.jsx)(`button`,{className:`db-btn-gold w-100 justify-content-center`,disabled:g,children:`Create Hostel`})]})]})}),(0,l.jsx)(`div`,{className:`col-xl-4`,children:(0,l.jsxs)(`div`,{className:`db-panel h-100`,children:[(0,l.jsx)(`div`,{className:`db-panel-head`,children:(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`h5`,{className:`db-panel-title`,children:`Add Room`}),(0,l.jsx)(`p`,{className:`db-panel-sub`,children:`Capacity is the available bed count`})]})}),(0,l.jsxs)(`form`,{className:`p-4`,onSubmit:H,children:[(0,l.jsxs)(`div`,{className:`mb-3`,children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Hostel`}),(0,l.jsxs)(`select`,{className:`form-select db-form-select`,required:!0,value:w.hostel_id,onChange:e=>T({...w,hostel_id:e.target.value}),children:[(0,l.jsx)(`option`,{value:``,children:`Select hostel`}),r.hostels.filter(e=>e.is_active).map(e=>(0,l.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]}),(0,l.jsxs)(`div`,{className:`row g-2 mb-3`,children:[(0,l.jsxs)(`div`,{className:`col-7`,children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Room Name / No.`}),(0,l.jsx)(`input`,{className:`form-control db-form-control`,required:!0,value:w.name,onChange:e=>T({...w,name:e.target.value}),placeholder:`e.g. Room 101`})]}),(0,l.jsxs)(`div`,{className:`col-5`,children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Capacity`}),(0,l.jsx)(`input`,{className:`form-control db-form-control`,type:`number`,min:1,max:1e3,required:!0,value:w.capacity,onChange:e=>T({...w,capacity:Number(e.target.value)})})]})]}),(0,l.jsxs)(`div`,{className:`mb-4`,children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Floor / Block`}),(0,l.jsx)(`input`,{className:`form-control db-form-control`,value:w.floor,onChange:e=>T({...w,floor:e.target.value}),placeholder:`e.g. Ground Floor`})]}),(0,l.jsx)(`button`,{className:`db-btn-gold w-100 justify-content-center`,disabled:g||!r.hostels.length,children:`Add Room`})]})]})}),(0,l.jsx)(`div`,{className:`col-xl-4`,children:(0,l.jsxs)(`div`,{className:`db-panel h-100`,children:[(0,l.jsx)(`div`,{className:`db-panel-head`,children:(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`h5`,{className:`db-panel-title`,children:`Allocate Student`}),(0,l.jsx)(`p`,{className:`db-panel-sub`,children:`Only rooms with vacant spaces shown`})]})}),(0,l.jsxs)(`form`,{className:`p-4`,onSubmit:U,children:[(0,l.jsxs)(`div`,{className:`mb-3`,children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Student`}),(0,l.jsxs)(`select`,{className:`form-select db-form-select`,required:!0,value:E.student_id,onChange:e=>D({...E,student_id:e.target.value}),children:[(0,l.jsx)(`option`,{value:``,children:`Select student`}),r.students.map(e=>(0,l.jsxs)(`option`,{value:e.id,children:[f(e),` `,e.reg_no?`(${e.reg_no})`:``]},e.id))]})]}),(0,l.jsxs)(`div`,{className:`mb-3`,children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Room`}),(0,l.jsxs)(`select`,{className:`form-select db-form-select`,required:!0,value:E.hostel_room_id,onChange:e=>D({...E,hostel_room_id:e.target.value}),children:[(0,l.jsx)(`option`,{value:``,children:`Select available room`}),L.map(e=>(0,l.jsxs)(`option`,{value:e.id,children:[e.hostel.name,` · `,e.name,` (`,e.capacity-e.occupied,` vacant)`]},e.id))]})]}),(0,l.jsxs)(`div`,{className:`row g-2 mb-3`,children:[(0,l.jsxs)(`div`,{className:`col-7`,children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Session`}),(0,l.jsx)(`select`,{className:`form-select db-form-select`,required:!0,value:E.session_id,onChange:e=>D({...E,session_id:e.target.value}),children:r.sessions.map(e=>(0,l.jsx)(`option`,{value:e.id,children:e.name},e.id))})]}),(0,l.jsxs)(`div`,{className:`col-5`,children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Term`}),(0,l.jsxs)(`select`,{className:`form-select db-form-select`,value:E.term_id,onChange:e=>D({...E,term_id:e.target.value}),children:[(0,l.jsx)(`option`,{value:``,children:`All Year`}),r.terms.map(e=>(0,l.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]})]}),(0,l.jsxs)(`div`,{className:`mb-4`,children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Notes (Optional)`}),(0,l.jsx)(`input`,{className:`form-control db-form-control`,value:E.notes,onChange:e=>D({...E,notes:e.target.value}),placeholder:`e.g. Special medical need`})]}),(0,l.jsx)(`button`,{className:`db-btn-gold w-100 justify-content-center`,disabled:g||!L.length,children:`Allocate Student`})]})]})})]}),(0,l.jsxs)(`div`,{className:`db-panel mb-4`,children:[(0,l.jsx)(`div`,{className:`db-panel-head`,children:(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`h5`,{className:`db-panel-title`,children:`Hostels and Room Occupancy`}),(0,l.jsx)(`p`,{className:`db-panel-sub`,children:`Real-time capacity and occupant breakdown`})]})}),(0,l.jsx)(`div`,{className:`p-4`,children:(0,l.jsxs)(`div`,{className:`row g-3`,children:[r.hostels.map(e=>(0,l.jsx)(`div`,{className:`col-xl-6`,children:(0,l.jsxs)(`div`,{className:`p-3 border rounded-3 h-100`,style:{background:`#faf8f5`},children:[(0,l.jsxs)(`div`,{className:`d-flex justify-content-between align-items-start`,children:[(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`h5`,{className:`mb-1`,style:{fontFamily:`Playfair Display, serif`,color:`#1a1a2e`},children:e.name}),(0,l.jsxs)(`div`,{className:`small text-muted text-capitalize`,children:[e.gender,` · Warden: `,e.warden_name||`Unassigned`]})]}),(0,l.jsx)(`span`,{className:`db-badge ${e.is_active?`db-badge--green`:`db-badge--gray`}`,children:e.is_active?`Active`:`Inactive`})]}),(0,l.jsxs)(`div`,{className:`row g-2 mt-2`,children:[e.rooms.map(e=>{let t=Math.min(100,e.capacity?e.occupied/e.capacity*100:0);return(0,l.jsx)(`div`,{className:`col-sm-6`,children:(0,l.jsxs)(`div`,{className:`p-2 bg-white rounded-3 border`,style:{borderColor:`#e5ddd3`},children:[(0,l.jsxs)(`div`,{className:`d-flex justify-content-between small fw-bold`,children:[(0,l.jsx)(`span`,{children:e.name}),(0,l.jsxs)(`span`,{style:{color:t>=100?`#dc2626`:`#15803d`},children:[e.occupied,`/`,e.capacity]})]}),(0,l.jsx)(`div`,{className:`progress mt-2`,style:{height:6,background:`#f0ece4`},children:(0,l.jsx)(`div`,{className:`progress-bar`,style:{width:`${t}%`,background:t>=100?`#dc2626`:t>=75?`#f59e0b`:`#22c55e`}})}),(0,l.jsxs)(`div`,{className:`d-flex justify-content-between mt-1 text-muted`,style:{fontSize:11},children:[(0,l.jsx)(`span`,{children:e.floor||`Ground Floor`}),(0,l.jsxs)(`span`,{children:[e.capacity-e.occupied,` left`]})]})]})},e.id)}),!e.rooms.length&&(0,l.jsx)(`div`,{className:`text-muted small p-2`,children:`No rooms added to this hostel yet.`})]})]})},e.id)),!m&&!r.hostels.length&&(0,l.jsx)(`div`,{className:`text-center text-muted py-5`,children:`No hostels configured yet. Use the form above to add your first hostel.`})]})})]}),(0,l.jsxs)(`div`,{className:`db-panel mb-4`,children:[(0,l.jsxs)(`div`,{className:`db-panel-head`,children:[(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`h5`,{className:`db-panel-title`,children:`Current Residents`}),(0,l.jsx)(`p`,{className:`db-panel-sub`,children:`Active student room allocations`})]}),(0,l.jsxs)(`div`,{className:`position-relative`,style:{maxWidth:280},children:[(0,l.jsx)(`input`,{className:`form-control db-form-control`,placeholder:`Search student or room...`,value:O,onChange:e=>k(e.target.value),style:{paddingLeft:32}}),(0,l.jsx)(`i`,{className:`bi bi-search position-absolute text-muted`,style:{left:10,top:`50%`,transform:`translateY(-50%)`,fontSize:12}})]})]}),(0,l.jsx)(`div`,{className:`table-responsive`,children:(0,l.jsxs)(`table`,{className:`table align-middle mb-0`,style:{fontSize:13.5},children:[(0,l.jsx)(`thead`,{style:{background:`#faf8f5`},children:(0,l.jsxs)(`tr`,{children:[(0,l.jsx)(`th`,{className:`ps-4 text-muted small fw-bold`,children:`Student`}),(0,l.jsx)(`th`,{className:`text-muted small fw-bold`,children:`Hostel`}),(0,l.jsx)(`th`,{className:`text-muted small fw-bold`,children:`Room`}),(0,l.jsx)(`th`,{className:`text-muted small fw-bold`,children:`Allocated Date`}),(0,l.jsx)(`th`,{className:`text-end pe-4 text-muted small fw-bold`,children:`Actions`})]})}),(0,l.jsxs)(`tbody`,{children:[R.map(e=>(0,l.jsxs)(`tr`,{style:{borderBottom:`1px solid #ede8e0`},children:[(0,l.jsxs)(`td`,{className:`ps-4`,children:[(0,l.jsx)(`strong`,{style:{color:`#1a1a2e`},children:f(e.student)}),(0,l.jsx)(`div`,{className:`small text-muted`,children:e.student.reg_no||e.student.email})]}),(0,l.jsx)(`td`,{children:(0,l.jsx)(`span`,{className:`db-badge db-badge--blue`,children:e.hostel.name})}),(0,l.jsx)(`td`,{children:e.room.name}),(0,l.jsx)(`td`,{className:`text-muted`,children:new Date(e.allocated_at).toLocaleDateString()}),(0,l.jsx)(`td`,{className:`text-end pe-4`,children:(0,l.jsx)(`button`,{className:`db-icon-btn db-icon-btn--r`,disabled:g,title:`Check out student from room`,onClick:()=>window.confirm(`Check this student out of the hostel?`)&&B(()=>c.checkout(e.id),`Student checked out successfully.`),children:(0,l.jsx)(`i`,{className:`bi bi-box-arrow-right`})})})]},e.id)),!m&&!R.length&&(0,l.jsx)(`tr`,{children:(0,l.jsx)(`td`,{colSpan:5,className:`text-center text-muted py-5`,children:`No active student allocations found.`})})]})]})})]}),(0,l.jsxs)(`div`,{className:`db-panel mb-4`,children:[(0,l.jsx)(`div`,{className:`db-panel-head`,children:(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`h5`,{className:`db-panel-title`,children:`Transfer a Resident`}),(0,l.jsx)(`p`,{className:`db-panel-sub`,children:`Move an active resident to another room while preserving history`})]})}),(0,l.jsx)(`div`,{className:`p-4`,children:(0,l.jsxs)(`div`,{className:`row g-3 align-items-end`,children:[(0,l.jsxs)(`div`,{className:`col-md-4`,children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Resident`}),(0,l.jsxs)(`select`,{className:`form-select db-form-select`,value:P.allocation_id||``,onChange:e=>F({...P,allocation_id:Number(e.target.value)}),children:[(0,l.jsx)(`option`,{value:``,children:`Select resident`}),r.allocations.map(e=>(0,l.jsxs)(`option`,{value:e.id,children:[f(e.student),` · `,e.hostel.name,`/`,e.room.name]},e.id))]})]}),(0,l.jsxs)(`div`,{className:`col-md-3`,children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Destination Room`}),(0,l.jsxs)(`select`,{className:`form-select db-form-select`,value:P.room_id,onChange:e=>F({...P,room_id:e.target.value}),children:[(0,l.jsx)(`option`,{value:``,children:`Select destination room`}),L.map(e=>(0,l.jsxs)(`option`,{value:e.id,children:[e.hostel.name,` · `,e.name]},e.id))]})]}),(0,l.jsxs)(`div`,{className:`col-md-3`,children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Reason for Transfer`}),(0,l.jsx)(`input`,{className:`form-control db-form-control`,value:P.reason,onChange:e=>F({...P,reason:e.target.value}),placeholder:`e.g. Upgraded room`})]}),(0,l.jsx)(`div`,{className:`col-md-2`,children:(0,l.jsx)(`button`,{className:`db-btn-gold w-100 justify-content-center`,disabled:g||!P.allocation_id||!P.room_id||P.reason.trim().length<3,onClick:K,children:`Transfer`})})]})})]}),(0,l.jsxs)(`div`,{className:`db-panel mb-4`,children:[(0,l.jsx)(`div`,{className:`db-panel-head`,children:(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`h5`,{className:`db-panel-title`,children:`Manage Buildings & Rooms`}),(0,l.jsx)(`p`,{className:`db-panel-sub`,children:`Edit details or toggle operational status`})]})}),(0,l.jsx)(`div`,{className:`table-responsive`,children:(0,l.jsxs)(`table`,{className:`table align-middle mb-0`,style:{fontSize:13.5},children:[(0,l.jsx)(`thead`,{style:{background:`#faf8f5`},children:(0,l.jsxs)(`tr`,{children:[(0,l.jsx)(`th`,{className:`ps-4 text-muted small fw-bold`,children:`Building / Room`}),(0,l.jsx)(`th`,{className:`text-muted small fw-bold`,children:`Gender / Floor`}),(0,l.jsx)(`th`,{className:`text-muted small fw-bold`,children:`Bed Spaces`}),(0,l.jsx)(`th`,{className:`text-muted small fw-bold`,children:`Status`}),(0,l.jsx)(`th`,{className:`text-end pe-4 text-muted small fw-bold`,children:`Actions`})]})}),(0,l.jsx)(`tbody`,{children:r.hostels.flatMap(e=>[(0,l.jsxs)(`tr`,{style:{background:`#fbf9f6`,borderBottom:`1px solid #ede8e0`},children:[(0,l.jsxs)(`td`,{className:`ps-4 fw-bold`,style:{color:`#1a1a2e`},children:[(0,l.jsx)(`i`,{className:`bi bi-building me-2 text-warning`}),e.name]}),(0,l.jsx)(`td`,{className:`text-capitalize`,children:e.gender}),(0,l.jsxs)(`td`,{children:[(0,l.jsx)(`strong`,{children:e.rooms.reduce((e,t)=>e+t.capacity,0)}),` total beds`]}),(0,l.jsx)(`td`,{children:(0,l.jsx)(`span`,{className:`db-badge ${e.is_active?`db-badge--green`:`db-badge--gray`}`,children:e.is_active?`Active`:`Inactive`})}),(0,l.jsxs)(`td`,{className:`text-end pe-4`,children:[(0,l.jsx)(`button`,{className:`db-icon-btn db-icon-btn--p me-2`,title:`Edit Hostel`,onClick:()=>W(e),children:(0,l.jsx)(`i`,{className:`bi bi-pencil`})}),(0,l.jsx)(`button`,{className:`db-icon-btn`,title:e.is_active?`Deactivate Hostel`:`Activate Hostel`,onClick:()=>B(()=>c.updateHostel(e.id,{is_active:!e.is_active}),e.is_active?`Hostel deactivated.`:`Hostel activated.`),children:(0,l.jsx)(`i`,{className:`bi ${e.is_active?`bi-toggle-on text-success`:`bi-toggle-off text-muted`}`})})]})]},`h-${e.id}`),...e.rooms.map(e=>(0,l.jsxs)(`tr`,{style:{borderBottom:`1px solid #ede8e0`},children:[(0,l.jsxs)(`td`,{className:`ps-5 text-muted`,children:[(0,l.jsx)(`span`,{className:`me-2`,children:`↳`}),e.name]}),(0,l.jsx)(`td`,{className:`text-muted`,children:e.floor||`—`}),(0,l.jsxs)(`td`,{children:[e.occupied,`/`,e.capacity,` beds`]}),(0,l.jsx)(`td`,{children:(0,l.jsx)(`span`,{className:`db-badge ${e.is_active?`db-badge--green`:`db-badge--gray`}`,children:e.is_active?`Active`:`Inactive`})}),(0,l.jsxs)(`td`,{className:`text-end pe-4`,children:[(0,l.jsx)(`button`,{className:`db-icon-btn db-icon-btn--p me-2`,title:`Edit Room`,onClick:()=>G(e),children:(0,l.jsx)(`i`,{className:`bi bi-pencil`})}),(0,l.jsx)(`button`,{className:`db-icon-btn`,title:e.is_active?`Deactivate Room`:`Activate Room`,onClick:()=>B(()=>c.updateRoom(e.id,{is_active:!e.is_active}),e.is_active?`Room deactivated.`:`Room activated.`),children:(0,l.jsx)(`i`,{className:`bi ${e.is_active?`bi-toggle-on text-success`:`bi-toggle-off text-muted`}`})})]})]},`r-${e.id}`))])})]})})]}),(0,l.jsxs)(`div`,{className:`db-panel mb-4`,children:[(0,l.jsx)(`div`,{className:`db-panel-head`,children:(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`h5`,{className:`db-panel-title`,children:`Allocation History Log`}),(0,l.jsx)(`p`,{className:`db-panel-sub`,children:`Auditable history of assignments, check-outs, and transfers`})]})}),(0,l.jsx)(`div`,{className:`table-responsive`,children:(0,l.jsxs)(`table`,{className:`table align-middle mb-0`,style:{fontSize:13.5},children:[(0,l.jsx)(`thead`,{style:{background:`#faf8f5`},children:(0,l.jsxs)(`tr`,{children:[(0,l.jsx)(`th`,{className:`ps-4 text-muted small fw-bold`,children:`Student`}),(0,l.jsx)(`th`,{className:`text-muted small fw-bold`,children:`Action`}),(0,l.jsx)(`th`,{className:`text-muted small fw-bold`,children:`Movement`}),(0,l.jsx)(`th`,{className:`text-muted small fw-bold`,children:`Reason`}),(0,l.jsx)(`th`,{className:`text-muted small fw-bold`,children:`Date & Time`})]})}),(0,l.jsxs)(`tbody`,{children:[r.history.map(e=>(0,l.jsxs)(`tr`,{style:{borderBottom:`1px solid #ede8e0`},children:[(0,l.jsxs)(`td`,{className:`ps-4`,children:[(0,l.jsx)(`strong`,{style:{color:`#1a1a2e`},children:f(e.student)}),(0,l.jsx)(`div`,{className:`small text-muted`,children:e.student.reg_no})]}),(0,l.jsx)(`td`,{children:(0,l.jsx)(`span`,{className:`db-badge ${e.action.includes(`checkout`)?`db-badge--red`:e.action.includes(`transfer`)?`db-badge--amber`:`db-badge--green`}`,children:e.action.replaceAll(`_`,` `)})}),(0,l.jsxs)(`td`,{children:[e.from_hostel?.name?`${e.from_hostel.name}/${e.from_room?.name||``} → `:``,e.to_hostel?.name?`${e.to_hostel.name}/${e.to_room?.name||``}`:`Checked out`]}),(0,l.jsx)(`td`,{className:`text-muted`,children:e.reason||`—`}),(0,l.jsx)(`td`,{className:`text-muted`,children:new Date(e.created_at).toLocaleString()})]},e.id)),!r.history.length&&(0,l.jsx)(`tr`,{children:(0,l.jsx)(`td`,{colSpan:5,className:`text-center text-muted py-4`,children:`No allocation history recorded yet.`})})]})]})})]}),(0,l.jsx)(`div`,{className:`mt-5`,children:(0,l.jsx)(o,{})})]})]})})]})}export{p as default};