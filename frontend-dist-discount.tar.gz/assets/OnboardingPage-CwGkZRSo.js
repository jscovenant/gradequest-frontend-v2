import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{p as t,x as n}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{A as r,C as i,D as a,M as o,N as s,O as c,j as l,k as ee,l as u}from"./index-D6TxbaCx.js";var d=e(),f=t();function p(e){if(!e)return 0;let t=[e.email_verified,e.current_session,e.all_terms_exist,e.terms_accepted,e.bonus_given];return Math.round(t.filter(Boolean).length/t.length*100)}function m(e){return e.email_verified?e.current_session?e.all_terms_exist?e.terms_accepted?`bonus`:`agreement`:`terms`:`session`:`email`}function h({number:e,title:t,subtitle:n,done:r,active:i,children:a}){return(0,f.jsxs)(`div`,{className:`ob-step ${r?`ob-step--done`:i?`ob-step--active`:`ob-step--pending`}`,children:[(0,f.jsx)(`div`,{className:`ob-step-connector`,"aria-hidden":`true`}),(0,f.jsxs)(`div`,{className:`ob-step-row`,children:[(0,f.jsx)(`div`,{className:`ob-step-badge`,"aria-hidden":`true`,children:r?(0,f.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,children:(0,f.jsx)(`path`,{d:`M2 7l3.5 3.5 6.5-6`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`})}):e}),(0,f.jsxs)(`div`,{className:`ob-step-content`,children:[(0,f.jsxs)(`div`,{className:`ob-step-head`,children:[(0,f.jsxs)(`div`,{className:`ob-step-title-wrap`,children:[(0,f.jsx)(`span`,{className:`ob-step-title`,children:t}),r&&(0,f.jsx)(`span`,{className:`ob-badge ob-badge--done`,children:`Completed`}),i&&!r&&(0,f.jsx)(`span`,{className:`ob-badge ob-badge--active`,children:`Up next`})]}),(0,f.jsx)(`p`,{className:`ob-step-sub`,children:n})]}),(0,f.jsx)(`div`,{style:{display:(i||r)&&a?`block`:`none`},className:`ob-step-body`,children:a})]})]})]})}function g(){return(0,f.jsxs)(`div`,{className:`ob-skeleton-wrap`,children:[(0,f.jsx)(`div`,{className:`ob-skel ob-skel--title`}),(0,f.jsx)(`div`,{className:`ob-skel ob-skel--sub`}),(0,f.jsx)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:12,marginTop:24},children:[1,2,3,4].map(e=>(0,f.jsx)(`div`,{className:`ob-skel-card`,children:(0,f.jsxs)(`div`,{style:{display:`flex`,gap:14,alignItems:`center`},children:[(0,f.jsx)(`div`,{className:`ob-skel ob-skel--circle`}),(0,f.jsxs)(`div`,{style:{flex:1},children:[(0,f.jsx)(`div`,{className:`ob-skel`,style:{width:`40%`,height:12,marginBottom:8}}),(0,f.jsx)(`div`,{className:`ob-skel`,style:{width:`70%`,height:10}})]})]})},e))})]})}function _(){let e=n(),{showToast:t}=u(),[_,v]=(0,d.useState)(!0),[y,b]=(0,d.useState)(null),[x,S]=(0,d.useState)(``),[C,w]=(0,d.useState)(!1),[T,E]=(0,d.useState)(!1),[te,D]=(0,d.useState)(!1),[O,k]=(0,d.useState)(``),[A,j]=(0,d.useState)(``),[M,N]=(0,d.useState)(``),[P,F]=(0,d.useState)(!0),[I,L]=(0,d.useState)(!1),ne=[`First Term`,`Second Term`,`Third Term`],[R,z]=(0,d.useState)(`First Term`),[B,V]=(0,d.useState)(!0),[H,U]=(0,d.useState)(!1),[W,G]=(0,d.useState)(!1),[K,q]=(0,d.useState)(!1),[J,Y]=(0,d.useState)(!1),X=(0,d.useMemo)(()=>p(y),[y]),Z=(0,d.useMemo)(()=>y?m(y):null,[y]),Q=async()=>{v(!0);try{let n=await r();b(n),n.bonus_given&&(t(`Activation complete. Redirecting`,`success`),e(`/dashboard`,{replace:!0}))}catch(n){t(n?.response?.data?.message||`Unable to load onboarding status.`,`error`),e(`/login`,{replace:!0})}finally{v(!1)}};(0,d.useEffect)(()=>{Q()},[]);let $=async()=>{if(x.trim().length!==5){t(`Enter the 5-digit code.`,`error`);return}w(!0);try{await s(x.trim()),t(`Email verified.`,`success`),S(``),await Q()}catch(e){t(e?.response?.data?.message||`Invalid code.`,`error`)}finally{w(!1)}},re=async()=>{E(!0);try{await l(),t(`Code resent  check your inbox.`,`success`)}catch(e){t(e?.response?.data?.message||`Failed to resend.`,`error`)}finally{E(!1)}},ie=async()=>{if(!O.trim()){t(`Enter a session name, e.g., 2025/2026.`,`error`);return}if(A&&!M||!A&&M){t(`Provide both start and end dates, or leave both empty.`,`error`);return}if(A&&M&&M<A){t(`End date cannot be before start date.`,`error`);return}L(!0);try{await o({name:O.trim(),start_date:A||void 0,end_date:M||void 0,make_current:P}),t(P?`Session saved and set as current.`:`Session saved.`,`success`),await Q()}catch(e){t(e?.response?.data?.message||`Failed to save session.`,`error`)}finally{L(!1)}},ae=async()=>{U(!0);try{await ee({terms:[...ne],make_current:B,current_term:R}),t(B?`Terms created and current term set.`:`Terms created.`,`success`),await Q()}catch(e){t(e?.response?.data?.message||`Failed to create terms.`,`error`)}finally{U(!1)}},oe=async()=>{Y(!0);try{t((await c())?.message||`Bonus activated.`,`success`),await Q()}catch(e){t(e?.response?.data?.message||`Complete all steps first.`,`error`)}finally{Y(!1)}},se=async()=>{if(!W){t(`Please confirm that you accept the Terms and Conditions.`,`error`);return}q(!0);try{await a(),t(`Terms and Conditions accepted.`,`success`),await Q()}catch(e){t(e?.response?.data?.message||`Unable to record your acceptance.`,`error`)}finally{q(!1)}};return(0,f.jsxs)(f.Fragment,{children:[(0,f.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,700;1,400&family=DM+Sans:wght@300;400;500&display=swap');

        *, *::before, *::after { box-sizing: border-box; margin:0; padding:0; }

        .ob-page {
          min-height: 100vh;
          background: #f5f1eb;
          font-family: 'DM Sans', sans-serif;
          display: grid;
          grid-template-columns: 340px 1fr;
          gap: 0;
        }

        @media (max-width: 900px) {
          .ob-page { grid-template-columns: 1fr; }
          .ob-sidebar { display: none !important; }
        }

        /*  LEFT SIDEBAR  */
        .ob-sidebar {
          background: #0f172a;
          min-height: 100vh;
          padding: 48px 40px;
          position: sticky;
          top: 0;
          height: 100vh;
          overflow-y: auto;
          display: flex;
          flex-direction: column;
          gap: 0;
        }

        .ob-sidebar::before {
          content: '';
          position: absolute; inset:0;
          background-image: radial-gradient(circle, rgba(255,255,255,0.045) 1px, transparent 1px);
          background-size: 24px 24px;
          pointer-events: none;
        }

        .ob-sidebar-glow {
          position: absolute; bottom: -60px; left: -60px;
          width: 380px; height: 380px; border-radius: 50%;
          background: radial-gradient(circle, rgba(201,168,76,0.08) 0%, transparent 65%);
          pointer-events: none;
        }

        .ob-sidebar-inner { position: relative; z-index:1; display:flex; flex-direction:column; height:100%; }

        /* Logo */
        .ob-logo {
          display: inline-flex; align-items: center; gap: 10px;
          text-decoration: none; margin-bottom: 48px;
        }
        .ob-logo-mark {
          width: 38px; height: 38px; border-radius: 10px;
          background: linear-gradient(135deg, #c9a84c, #e8c97a);
          display: flex; align-items: center; justify-content: center;
        }
        .ob-logo-name { font-family:'Lora',serif; font-size:19px; font-weight:700; color:#fff; }
        .ob-logo-pill {
          font-size:9px; font-weight:500; letter-spacing:0.1em; text-transform:uppercase;
          color:#c9a84c; background:rgba(201,168,76,0.12); border:1px solid rgba(201,168,76,0.25);
          border-radius:100px; padding:2px 7px;
        }

        /* Left headline */
        .ob-sidebar-head { margin-bottom: 32px; }
        .ob-sidebar-kicker {
          display: flex; align-items: center; gap: 7px;
          font-size:11px; font-weight:500; letter-spacing:0.18em; text-transform:uppercase;
          color:#c9a84c; margin-bottom:12px;
        }
        .ob-sidebar-kicker-line { width:20px; height:1px; background:#d97706; opacity:0.6; }
        .ob-sidebar-title {
          font-family:'Lora',serif; font-size:clamp(22px,2vw,28px); font-weight:700;
          color:#fff; line-height:1.15;
        }
        .ob-sidebar-title em { font-style:italic; color:#e8c97a; }
        .ob-sidebar-sub { font-size:13px; font-weight:300; color:#64748b; line-height:1.75; margin-top:10px; }

        /* Progress ring */
        .ob-ring-wrap {
          display: flex; flex-direction: column; align-items: center; gap: 16px;
          padding: 28px 0; margin-bottom:32px;
          border-top:1px solid rgba(255,255,255,0.06);
          border-bottom:1px solid rgba(255,255,255,0.06);
        }

        .ob-ring { position: relative; width:100px; height:100px; }

        .ob-ring svg { transform: rotate(-90deg); }

        .ob-ring-track { fill:none; stroke:rgba(255,255,255,0.06); stroke-width:6; }
        .ob-ring-fill {
          fill:none; stroke:#c9a84c; stroke-width:6;
          stroke-linecap:round;
          stroke-dasharray: 283;
          transition: stroke-dashoffset 0.8s cubic-bezier(0.4,0,0.2,1);
        }

        .ob-ring-text {
          position:absolute; inset:0;
          display:flex; flex-direction:column; align-items:center; justify-content:center;
        }

        .ob-ring-pct {
          font-family:'Lora',serif; font-size:26px; font-weight:700; color:#fff; line-height:1;
        }

        .ob-ring-label { font-size:10px; font-weight:300; color:#64748b; margin-top:2px; }

        .ob-ring-caption { font-size:12px; font-weight:300; color:#64748b; text-align:center; }

        /* Sidebar step indicators */
        .ob-sidebar-steps { display:flex; flex-direction:column; gap:14px; flex:1; }

        .ob-sidebar-step {
          display:flex; align-items:center; gap:12px;
          opacity:0.45; transition:opacity 0.3s;
        }
        .ob-sidebar-step--done  { opacity:1; }
        .ob-sidebar-step--active { opacity:1; }

        .ob-sidebar-dot {
          width:28px; height:28px; border-radius:50%; flex-shrink:0;
          border:1.5px solid rgba(255,255,255,0.12);
          display:flex; align-items:center; justify-content:center;
          font-size:11px; font-weight:700; color:#64748b;
          transition:background 0.3s, border-color 0.3s, color 0.3s;
        }
        .ob-sidebar-step--done .ob-sidebar-dot {
          background:rgba(34,197,94,0.15); border-color:rgba(34,197,94,0.4); color:#22c55e;
        }
        .ob-sidebar-step--active .ob-sidebar-dot {
          background:rgba(201,168,76,0.15); border-color:rgba(201,168,76,0.5); color:#c9a84c;
          animation: obDotPulse 2s ease infinite;
        }
        @keyframes obDotPulse {
          0%,100% { box-shadow:0 0 0 0 rgba(201,168,76,0.3); }
          50%      { box-shadow:0 0 0 8px rgba(201,168,76,0); }
        }

        .ob-sidebar-step-label {
          font-size:13px; font-weight:400; color:#94a3b8;
          transition:color 0.3s;
        }
        .ob-sidebar-step--active .ob-sidebar-step-label { color:#e2e8f0; }
        .ob-sidebar-step--done  .ob-sidebar-step-label { color:#64748b; }

        /* Sidebar quote */
        .ob-sidebar-quote { margin-top:auto; padding-top:28px; }
        .ob-quote-text {
          font-family:'Lora',serif; font-style:italic;
          font-size:13px; color:#475569; line-height:1.7; margin-bottom:8px;
        }
        .ob-quote-author { font-size:11.5px; color:#334155; }
        .ob-quote-line { display:inline-block; width:16px; height:1px; background:#c9a84c; opacity:0.5; vertical-align:middle; margin-right:6px; }

        /*  MAIN AREA  */
        .ob-main {
          padding: 48px 52px;
          max-width: 680px;
        }

        @media (max-width: 640px) { .ob-main { padding: 32px 20px; } }

        /* Mobile logo */
        .ob-mobile-logo {
          display:none; align-items:center; gap:9px;
          text-decoration:none; margin-bottom:32px;
        }
        @media (max-width:900px) { .ob-mobile-logo { display:flex; } }

        /* Header */
        .ob-header { margin-bottom:36px; }
        .ob-eyebrow {
          display:flex; align-items:center; gap:7px;
          font-size:11px; font-weight:500; letter-spacing:0.18em; text-transform:uppercase;
          color:#b45309; margin-bottom:10px;
        }
        .ob-eyebrow-line { width:20px; height:1px; background:#d97706; opacity:0.6; }
        .ob-title { font-family:'Lora',serif; font-size:clamp(24px,3vw,34px); font-weight:700; color:#1a1a2e; line-height:1.1; }
        .ob-title em { font-style:italic; color:#b45309; }
        .ob-subtitle { font-size:14px; font-weight:300; color:#7a6a5a; line-height:1.75; margin-top:8px; max-width:460px; }

        /* Bonus banner */
        .ob-bonus-banner {
          display:flex; align-items:center; gap:14px;
          background:#fff;
          border:1px solid #e8c97a;
          border-radius:12px; padding:16px 20px;
          margin-bottom:32px;
        }
        .ob-bonus-icon {
          width:42px; height:42px; border-radius:10px; flex-shrink:0;
          background:linear-gradient(135deg,#fef3c7,#fde68a);
          display:flex; align-items:center; justify-content:center;
          color:#b45309;
        }
        .ob-bonus-text { flex:1; }
        .ob-bonus-title { font-size:13.5px; font-weight:500; color:#1a1a2e; margin-bottom:2px; }
        .ob-bonus-sub { font-size:12px; font-weight:300; color:#9a8a7a; line-height:1.5; }

        /* Refresh btn */
        .ob-refresh {
          display:inline-flex; align-items:center; gap:6px;
          padding:7px 14px; font-size:12px; font-weight:400;
          color:#7a6a5a; background:#f5f1eb;
          border:1px solid #e5ddd3; border-radius:7px;
          cursor:pointer; transition:background 0.2s;
          flex-shrink:0;
        }
        .ob-refresh:hover { background:#ede8e0; }
        .ob-refresh:disabled { opacity:0.45; cursor:not-allowed; }

        /*  Steps  */
        .ob-steps { display:flex; flex-direction:column; position:relative; }

        .ob-step {
          display:flex; flex-direction:column;
          position:relative;
          animation: obFadeUp 0.5s ease both;
        }

        ${[0,1,2,3].map(e=>`.ob-step:nth-child(${e+1}) { animation-delay:${e*.07}s; }`).join(` `)}

        @keyframes obFadeUp {
          from { opacity:0; transform:translateY(12px); }
          to   { opacity:1; transform:translateY(0); }
        }

        .ob-step-connector {
          position:absolute; left:17px; top:40px; bottom:0;
          width:1px; background:rgba(0,0,0,0.08);
        }
        .ob-step:last-child .ob-step-connector { display:none; }

        .ob-step-row {
          display:flex; gap:16px; padding-bottom:28px;
        }

        .ob-step-badge {
          width:36px; height:36px; border-radius:50%; flex-shrink:0;
          display:flex; align-items:center; justify-content:center;
          font-family:'Lora',serif; font-size:14px; font-weight:700;
          transition:background 0.3s, border-color 0.3s, color 0.3s;
          margin-top:2px;
        }

        .ob-step--done .ob-step-badge {
          background:rgba(34,197,94,0.1); border:1.5px solid rgba(34,197,94,0.35); color:#22c55e;
        }
        .ob-step--active .ob-step-badge {
          background:#1a1a2e; border:1.5px solid #1a1a2e; color:#e8c97a;
          box-shadow: 0 0 0 4px rgba(26,26,46,0.08);
        }
        .ob-step--pending .ob-step-badge {
          background:#fff; border:1.5px solid #e5ddd3; color:#c8bfb5;
        }

        .ob-step-content { flex:1; min-width:0; }

        .ob-step-head { margin-bottom:4px; }
        .ob-step-title-wrap { display:flex; align-items:center; gap:8px; flex-wrap:wrap; margin-bottom:3px; }

        .ob-step-title {
          font-family:'Lora',serif; font-size:16px; font-weight:700;
          color:#1a1a2e;
        }
        .ob-step--pending .ob-step-title { color:#b5a090; }

        .ob-badge {
          font-size:10.5px; font-weight:500; letter-spacing:0.06em;
          border-radius:100px; padding:2px 9px; line-height:1.6;
        }
        .ob-badge--done  { background:rgba(34,197,94,0.1); color:#065f46; border:1px solid rgba(34,197,94,0.25); }
        .ob-badge--active { background:rgba(180,83,9,0.1); color:#b45309; border:1px solid rgba(180,83,9,0.2); }

        .ob-step-sub { font-size:13px; font-weight:300; color:#9a8a7a; line-height:1.65; }
        .ob-step--pending .ob-step-sub { color:#c8bfb5; }

        /* Step body card */
        .ob-step-body {
          margin-top:16px;
          background:#fff;
          border:1px solid #e8e0d5;
          border-radius:12px;
          padding:22px;
        }

        /*  Form elements  */
        .ob-label {
          display:block; font-size:12px; font-weight:500; color:#4a4a5a;
          margin-bottom:7px; letter-spacing:0.02em;
        }
        .ob-hint { font-size:11.5px; font-weight:300; color:#b5a090; margin-top:5px; }

        .ob-input-wrap { position:relative; }
        .ob-input-icon {
          position:absolute; left:13px; top:50%;
          transform:translateY(-50%); color:#b5a090;
          pointer-events:none; display:flex; align-items:center;
        }

        .ob-input, .ob-select {
          width:100%; background:#fff;
          border:1.5px solid #e5ddd3; border-radius:9px;
          padding:11px 13px 11px 40px;
          font-family:'DM Sans',sans-serif; font-size:13.5px; color:#1a1a2e;
          outline:none; -webkit-appearance:none;
          transition:border-color 0.2s, box-shadow 0.2s;
        }
        .ob-input-plain { padding-left:13px; }
        .ob-input:focus, .ob-select:focus {
          border-color:#c9a84c;
          box-shadow: 0 0 0 3px rgba(201,168,76,0.12);
        }
        .ob-input::placeholder { color:#bdb3a8; }

        /* OTP input */
        .ob-otp-wrap { position:relative; }
        .ob-otp {
          width:100%; letter-spacing:0.5em; font-size:22px; font-weight:700;
          text-align:center; background:#fff;
          border:2px solid #e5ddd3; border-radius:12px;
          padding:14px; font-family:'Lora',serif; color:#1a1a2e;
          outline:none;
          transition:border-color 0.2s, box-shadow 0.2s;
        }
        .ob-otp:focus {
          border-color:#c9a84c;
          box-shadow: 0 0 0 4px rgba(201,168,76,0.12);
        }
        .ob-otp::placeholder { color:#e5ddd3; letter-spacing:0.3em; font-size:18px; }

        /* 2-col grid */
        .ob-row2 { display:grid; grid-template-columns:1fr 1fr; gap:12px; }
        @media (max-width:520px) { .ob-row2 { grid-template-columns:1fr; } }

        /* Toggle switch */
        .ob-toggle-row {
          display:flex; align-items:center; justify-content:space-between;
          padding:10px 14px; background:#faf8f5;
          border:1px solid #e8e0d5; border-radius:8px; cursor:pointer;
          user-select:none;
        }
        .ob-toggle-label { font-size:13px; font-weight:400; color:#4a4a5a; }
        .ob-toggle { position:relative; width:36px; height:20px; cursor:pointer; }
        .ob-toggle input { opacity:0; width:0; height:0; }
        .ob-toggle-track {
          position:absolute; inset:0; border-radius:100px;
          background:#e5ddd3; transition:background 0.2s;
        }
        .ob-toggle input:checked + .ob-toggle-track { background:#c9a84c; }
        .ob-toggle-thumb {
          position:absolute; top:3px; left:3px;
          width:14px; height:14px; border-radius:50%;
          background:#fff; transition:transform 0.2s;
          pointer-events:none;
        }
        .ob-toggle input:checked ~ .ob-toggle-thumb { transform:translateX(16px); }

        /* Term pills */
        .ob-term-pills { display:flex; gap:8px; flex-wrap:wrap; margin-bottom:14px; }
        .ob-term-pill {
          padding:7px 16px; font-size:13px; font-weight:400;
          border:1.5px solid #e5ddd3; border-radius:100px;
          background:#fff; color:#7a6a5a;
          cursor:pointer; transition:background 0.2s, border-color 0.2s, color 0.2s;
        }
        .ob-term-pill--selected {
          background:#1a1a2e; border-color:#1a1a2e; color:#e8c97a;
        }

        /* Bonus claim card */
        .ob-bonus-claim {
          display:flex; flex-direction:column; align-items:center; gap:8px;
          padding:24px 20px; background:#faf8f5;
          border:1px dashed #e8c97a; border-radius:12px;
          text-align:center; margin-bottom:0;
        }
        .ob-bonus-amount {
          font-family:'Lora',serif; font-size:36px; font-weight:700; color:#b45309;
        }
        .ob-bonus-desc { font-size:13px; font-weight:300; color:#7a6a5a; max-width:280px; line-height:1.65; }

        /* Buttons */
        .ob-btn-primary {
          width:100%; padding:12px 20px;
          font-family:'DM Sans',sans-serif; font-size:14px; font-weight:500;
          color:#fff; background:#1a1a2e; border:none; border-radius:9px;
          cursor:pointer; display:flex; align-items:center; justify-content:center; gap:8px;
          transition:background 0.2s, transform 0.2s, box-shadow 0.2s;
          margin-top:16px;
        }
        .ob-btn-primary:hover:not(:disabled) {
          background:#0a0f1e; transform:translateY(-1px);
          box-shadow:0 6px 20px rgba(0,0,0,0.15);
        }
        .ob-btn-primary:disabled { opacity:0.55; cursor:not-allowed; }

        .ob-btn-claim {
          width:100%; padding:14px 20px;
          font-family:'DM Sans',sans-serif; font-size:14.5px; font-weight:500;
          color:#0f172a; background:#c9a84c; border:none; border-radius:10px;
          cursor:pointer; display:flex; align-items:center; justify-content:center; gap:8px;
          transition:background 0.2s, transform 0.2s, box-shadow 0.2s;
          margin-top:16px;
        }
        .ob-btn-claim:hover:not(:disabled) {
          background:#e8c97a; transform:translateY(-1px);
          box-shadow:0 6px 20px rgba(201,168,76,0.3);
        }
        .ob-btn-claim:disabled { opacity:0.55; cursor:not-allowed; }

        .ob-btn-link {
          background:none; border:none; padding:0;
          font-size:13px; font-weight:400; color:#b45309;
          cursor:pointer; text-decoration:underline; text-underline-offset:2px;
          transition:color 0.2s;
        }
        .ob-btn-link:hover { color:#92400e; }
        .ob-btn-link:disabled { opacity:0.45; cursor:not-allowed; }

        /* Spinner */
        .ob-spinner {
          width:15px; height:15px; border-radius:50%;
          border:2px solid rgba(255,255,255,0.3); border-top-color:#fff;
          animation:obSpin 0.7s linear infinite; flex-shrink:0;
        }
        .ob-spinner--dark { border:2px solid rgba(0,0,0,0.15); border-top-color:#0f172a; }
        @keyframes obSpin { to { transform:rotate(360deg); } }

        /* Footer note */
        .ob-footer { text-align:center; font-size:12px; font-weight:300; color:#b5a090; margin-top:36px; }
        .ob-footer a { color:#b45309; text-decoration:none; }

        /*  Skeleton  */
        .ob-skeleton-wrap { padding:12px 0; }
        .ob-skel {
          border-radius:6px; background:#ece8e0;
          background: linear-gradient(90deg,#ece8e0 25%,#e0dad2 50%,#ece8e0 75%);
          background-size:200% 100%;
          animation:obSkelAnim 1.4s ease infinite;
        }
        @keyframes obSkelAnim { from{background-position:200% 0;} to{background-position:-200% 0;} }
        .ob-skel--title { width:55%; height:16px; margin-bottom:10px; }
        .ob-skel--sub   { width:75%; height:12px; }
        .ob-skel--circle { width:36px; height:36px; border-radius:50%; flex-shrink:0; }
        .ob-skel-card { background:#fff; border:1px solid #e8e0d5; border-radius:12px; padding:18px; }
      `}),(0,f.jsx)(i,{title:`Onboarding`}),(0,f.jsxs)(`div`,{className:`ob-page`,children:[(0,f.jsxs)(`aside`,{className:`ob-sidebar`,style:{display:`flex`},children:[(0,f.jsx)(`div`,{className:`ob-sidebar-glow`,"aria-hidden":`true`}),(0,f.jsxs)(`div`,{className:`ob-sidebar-inner`,children:[(0,f.jsxs)(`a`,{href:`/`,className:`ob-logo`,children:[(0,f.jsx)(`span`,{className:`ob-logo-mark`,children:(0,f.jsxs)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 24 24`,fill:`none`,children:[(0,f.jsx)(`polygon`,{points:`12,2 22,19 2,19`,stroke:`#0a0f1e`,strokeWidth:`2`,strokeLinejoin:`round`,fill:`none`}),(0,f.jsx)(`path`,{d:`M12 8v5M12 15.5v.5`,stroke:`#0a0f1e`,strokeWidth:`2.2`,strokeLinecap:`round`})]})}),(0,f.jsx)(`span`,{className:`ob-logo-name`,children:`GradiosEdu`}),(0,f.jsx)(`span`,{className:`ob-logo-pill`,children:`AI`})]}),(0,f.jsxs)(`div`,{className:`ob-sidebar-head`,children:[(0,f.jsxs)(`div`,{className:`ob-sidebar-kicker`,children:[(0,f.jsx)(`span`,{className:`ob-sidebar-kicker-line`}),`School activation`]}),(0,f.jsxs)(`h2`,{className:`ob-sidebar-title`,children:[`You're almost`,(0,f.jsx)(`br`,{}),(0,f.jsx)(`em`,{children:`ready to go.`})]}),(0,f.jsx)(`p`,{className:`ob-sidebar-sub`,children:`Five quick steps and your school management platform is fully live.`})]}),(0,f.jsxs)(`div`,{className:`ob-ring-wrap`,children:[(0,f.jsxs)(`div`,{className:`ob-ring`,children:[(0,f.jsxs)(`svg`,{width:`100`,height:`100`,viewBox:`0 0 100 100`,children:[(0,f.jsx)(`circle`,{className:`ob-ring-track`,cx:`50`,cy:`50`,r:`45`}),(0,f.jsx)(`circle`,{className:`ob-ring-fill`,cx:`50`,cy:`50`,r:`45`,style:{strokeDashoffset:283-283*X/100}})]}),(0,f.jsxs)(`div`,{className:`ob-ring-text`,children:[(0,f.jsxs)(`span`,{className:`ob-ring-pct`,children:[X,`%`]}),(0,f.jsx)(`span`,{className:`ob-ring-label`,children:`complete`})]})]}),(0,f.jsxs)(`p`,{className:`ob-ring-caption`,children:[`Most schools finish this`,(0,f.jsx)(`br`,{}),`in under 2 minutes.`]})]}),(0,f.jsx)(`div`,{className:`ob-sidebar-steps`,children:[{key:`email`,label:`Verify email`},{key:`session`,label:`Set academic session`},{key:`terms`,label:`Create term structure`},{key:`agreement`,label:`Accept Terms & Conditions`},{key:`bonus`,label:`Claim welcome bonus`}].map((e,t)=>{let n=y?m(y)!==e.key&&(e.key===`email`&&y.email_verified||e.key===`session`&&y.current_session||e.key===`terms`&&y.all_terms_exist||e.key===`agreement`&&y.terms_accepted||e.key===`bonus`&&y.bonus_given):!1,r=Z===e.key;return(0,f.jsxs)(`div`,{className:`ob-sidebar-step ${n?`ob-sidebar-step--done`:r?`ob-sidebar-step--active`:``}`,children:[(0,f.jsx)(`div`,{className:`ob-sidebar-dot`,children:n?(0,f.jsx)(`svg`,{width:`11`,height:`11`,viewBox:`0 0 12 12`,fill:`none`,children:(0,f.jsx)(`path`,{d:`M1.5 6l3 3 6-6`,stroke:`currentColor`,strokeWidth:`1.8`,strokeLinecap:`round`,strokeLinejoin:`round`})}):t+1}),(0,f.jsx)(`span`,{className:`ob-sidebar-step-label`,children:e.label})]},e.key)})}),(0,f.jsxs)(`div`,{className:`ob-sidebar-quote`,children:[(0,f.jsx)(`p`,{className:`ob-quote-text`,children:`"Setup took 90 seconds. We were uploading results the same afternoon."`}),(0,f.jsxs)(`span`,{className:`ob-quote-author`,children:[(0,f.jsx)(`span`,{className:`ob-quote-line`}),`Mr. Tunde Balogun  Sunrise Academy, Abuja`]})]})]})]}),(0,f.jsxs)(`main`,{className:`ob-main`,children:[(0,f.jsxs)(`a`,{href:`/`,className:`ob-mobile-logo`,children:[(0,f.jsx)(`span`,{className:`ob-logo-mark`,style:{width:32,height:32,borderRadius:8},children:(0,f.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 24 24`,fill:`none`,children:[(0,f.jsx)(`polygon`,{points:`12,2 22,19 2,19`,stroke:`#0a0f1e`,strokeWidth:`2`,strokeLinejoin:`round`,fill:`none`}),(0,f.jsx)(`path`,{d:`M12 8v5M12 15.5v.5`,stroke:`#0a0f1e`,strokeWidth:`2.2`,strokeLinecap:`round`})]})}),(0,f.jsx)(`span`,{style:{fontFamily:`'Lora',serif`,fontSize:17,fontWeight:700,color:`#1a1a2e`},children:`GradiosEdu`})]}),(0,f.jsx)(`div`,{className:`ob-header`,children:(0,f.jsxs)(`div`,{style:{display:`flex`,alignItems:`flex-start`,justifyContent:`space-between`,gap:12,flexWrap:`wrap`},children:[(0,f.jsxs)(`div`,{children:[(0,f.jsxs)(`div`,{className:`ob-eyebrow`,children:[(0,f.jsx)(`span`,{className:`ob-eyebrow-line`}),`Step `,_?``:y?[`email`,`session`,`terms`,`agreement`,`bonus`].indexOf(Z||`bonus`)+1:``,` of 5`]}),(0,f.jsxs)(`h1`,{className:`ob-title`,children:[`Activate your`,(0,f.jsx)(`br`,{}),(0,f.jsx)(`em`,{children:`GradiosEdu school.`})]}),(0,f.jsxs)(`p`,{className:`ob-subtitle`,children:[`Complete four steps and unlock your `,(0,f.jsx)(`strong`,{style:{color:`#b45309`},children:`5,000 GradiosEduPlus wallet credit`}),`.`]})]}),(0,f.jsxs)(`button`,{className:`ob-refresh`,onClick:Q,disabled:_,children:[(0,f.jsxs)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,style:{animation:_?`obSpin 0.8s linear infinite`:`none`},children:[(0,f.jsx)(`path`,{d:`M12 7A5 5 0 112 7`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,f.jsx)(`path`,{d:`M12 3v4h-4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),_?`Refreshing`:`Refresh`]})]})}),!_&&y&&!y.bonus_given&&(0,f.jsxs)(`div`,{className:`ob-bonus-banner`,children:[(0,f.jsx)(`div`,{className:`ob-bonus-icon`,"aria-hidden":`true`,children:(0,f.jsx)(`svg`,{width:`20`,height:`20`,viewBox:`0 0 24 24`,fill:`none`,children:(0,f.jsx)(`path`,{d:`M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinejoin:`round`})})}),(0,f.jsxs)(`div`,{className:`ob-bonus-text`,children:[(0,f.jsx)(`div`,{className:`ob-bonus-title`,children:`5,000 GradiosEduPlus wallet credit waiting for you`}),(0,f.jsx)(`div`,{className:`ob-bonus-sub`,children:`Complete all steps to claim. Credit goes directly to your school wallet and expires after 30 days if unused.`})]})]}),_&&!y&&(0,f.jsx)(g,{}),y&&(0,f.jsxs)(`div`,{className:`ob-steps`,children:[(0,f.jsx)(h,{number:1,title:`Verify your email address`,subtitle:`Enter the 5-digit code we sent to your registered email.`,done:y.email_verified,active:Z===`email`,children:!y.email_verified&&(0,f.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:14},children:[(0,f.jsxs)(`div`,{children:[(0,f.jsx)(`label`,{className:`ob-label`,children:`Verification code`}),(0,f.jsx)(`input`,{className:`ob-otp`,inputMode:`numeric`,maxLength:5,placeholder:`    `,value:x,onChange:e=>S(e.target.value.replace(/\D/g,``)),onFocus:()=>D(!0),onBlur:()=>D(!1),onKeyDown:e=>e.key===`Enter`&&$()}),(0,f.jsx)(`p`,{className:`ob-hint`,children:`Check your spam folder if you don't see it.`})]}),(0,f.jsx)(`button`,{className:`ob-btn-primary`,onClick:$,disabled:C||x.length<5,children:C?(0,f.jsxs)(f.Fragment,{children:[(0,f.jsx)(`span`,{className:`ob-spinner`}),`\xA0Verifying`]}):(0,f.jsxs)(f.Fragment,{children:[(0,f.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,children:(0,f.jsx)(`path`,{d:`M2 7l3.5 3.5 6.5-6`,stroke:`currentColor`,strokeWidth:`1.8`,strokeLinecap:`round`,strokeLinejoin:`round`})}),`Verify Email`]})}),(0,f.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`},children:[(0,f.jsx)(`span`,{style:{fontSize:12.5,color:`#9a8a7a`,fontWeight:300},children:`Didn't receive the code?`}),(0,f.jsx)(`button`,{className:`ob-btn-link`,onClick:re,disabled:T,children:T?`Sending`:`Resend code `})]})]})}),(0,f.jsx)(h,{number:2,title:`Set your academic session`,subtitle:`This drives your result sheets, reports, and term structure.`,done:y.current_session,active:Z===`session`,children:!y.current_session&&(0,f.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:14},children:[(0,f.jsxs)(`div`,{children:[(0,f.jsx)(`label`,{className:`ob-label`,htmlFor:`sessionName`,children:`Session name`}),(0,f.jsxs)(`div`,{className:`ob-input-wrap`,children:[(0,f.jsx)(`span`,{className:`ob-input-icon`,children:(0,f.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,f.jsx)(`rect`,{x:`1`,y:`3`,width:`14`,height:`11`,rx:`2`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,f.jsx)(`path`,{d:`M5 1v3M11 1v3M1 7h14`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`})]})}),(0,f.jsx)(`input`,{id:`sessionName`,className:`ob-input`,placeholder:`e.g. 2025/2026`,value:O,onChange:e=>k(e.target.value)})]})]}),(0,f.jsxs)(`div`,{className:`ob-row2`,children:[(0,f.jsxs)(`div`,{children:[(0,f.jsxs)(`label`,{className:`ob-label`,children:[`Start date `,(0,f.jsx)(`span`,{style:{color:`#b5a090`,fontWeight:300},children:`(optional)`})]}),(0,f.jsx)(`input`,{className:`ob-input ob-input-plain`,type:`date`,value:A,onChange:e=>j(e.target.value)})]}),(0,f.jsxs)(`div`,{children:[(0,f.jsxs)(`label`,{className:`ob-label`,children:[`End date `,(0,f.jsx)(`span`,{style:{color:`#b5a090`,fontWeight:300},children:`(optional)`})]}),(0,f.jsx)(`input`,{className:`ob-input ob-input-plain`,type:`date`,value:M,onChange:e=>N(e.target.value)})]})]}),(0,f.jsxs)(`label`,{className:`ob-toggle-row`,htmlFor:`makeCurrentSessionToggle`,children:[(0,f.jsx)(`span`,{className:`ob-toggle-label`,children:`Set as current session`}),(0,f.jsxs)(`span`,{className:`ob-toggle`,children:[(0,f.jsx)(`input`,{type:`checkbox`,id:`makeCurrentSessionToggle`,checked:P,onChange:e=>F(e.target.checked)}),(0,f.jsx)(`span`,{className:`ob-toggle-track`}),(0,f.jsx)(`span`,{className:`ob-toggle-thumb`})]})]}),(0,f.jsx)(`button`,{className:`ob-btn-primary`,onClick:ie,disabled:I||!O.trim(),children:I?(0,f.jsxs)(f.Fragment,{children:[(0,f.jsx)(`span`,{className:`ob-spinner`}),`Saving`]}):(0,f.jsxs)(f.Fragment,{children:[(0,f.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,children:(0,f.jsx)(`path`,{d:`M1 7h12M7 1l6 6-6 6`,stroke:`currentColor`,strokeWidth:`1.7`,strokeLinecap:`round`,strokeLinejoin:`round`})}),`Save Session`]})})]})}),(0,f.jsx)(h,{number:3,title:`Create your term structure`,subtitle:`We'll create First, Second, and Third Term  choose which is active now.`,done:y.all_terms_exist,active:Z===`terms`,children:!y.all_terms_exist&&(0,f.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:14},children:[(0,f.jsxs)(`div`,{children:[(0,f.jsx)(`label`,{className:`ob-label`,children:`Current term`}),(0,f.jsx)(`div`,{className:`ob-term-pills`,children:[`First Term`,`Second Term`,`Third Term`].map(e=>(0,f.jsx)(`button`,{type:`button`,className:`ob-term-pill ${R===e&&B?`ob-term-pill--selected`:``}`,onClick:()=>{z(e),V(!0)},children:e},e))}),(0,f.jsx)(`p`,{className:`ob-hint`,children:`We'll auto-create all three terms. The selected one becomes active.`})]}),(0,f.jsxs)(`label`,{className:`ob-toggle-row`,htmlFor:`makeCurrentTermToggle`,children:[(0,f.jsx)(`span`,{className:`ob-toggle-label`,children:`Mark selected term as current`}),(0,f.jsxs)(`span`,{className:`ob-toggle`,children:[(0,f.jsx)(`input`,{type:`checkbox`,id:`makeCurrentTermToggle`,checked:B,onChange:e=>V(e.target.checked)}),(0,f.jsx)(`span`,{className:`ob-toggle-track`}),(0,f.jsx)(`span`,{className:`ob-toggle-thumb`})]})]}),(0,f.jsx)(`button`,{className:`ob-btn-primary`,onClick:ae,disabled:H,children:H?(0,f.jsxs)(f.Fragment,{children:[(0,f.jsx)(`span`,{className:`ob-spinner`}),`Creating terms`]}):(0,f.jsxs)(f.Fragment,{children:[(0,f.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,children:(0,f.jsx)(`path`,{d:`M1 7h12M7 1l6 6-6 6`,stroke:`currentColor`,strokeWidth:`1.7`,strokeLinecap:`round`,strokeLinejoin:`round`})}),`Create All Terms`]})})]})}),(0,f.jsx)(h,{number:4,title:`Accept the Terms and Conditions`,subtitle:`Review and accept the current GradiosEdu terms (${y.terms_version}).`,done:y.terms_accepted,active:Z===`agreement`,children:!y.terms_accepted&&(0,f.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:14},children:[(0,f.jsxs)(`label`,{className:`ob-toggle-row`,htmlFor:`acceptTermsCheckbox`,children:[(0,f.jsxs)(`span`,{className:`ob-toggle-label`,children:[`I am authorized to bind this school and I accept the`,` `,(0,f.jsx)(`a`,{href:`/terms-and-conditions`,target:`_blank`,rel:`noreferrer`,onClick:e=>e.stopPropagation(),children:`GradiosEdu Terms and Conditions`}),`.`]}),(0,f.jsx)(`input`,{id:`acceptTermsCheckbox`,type:`checkbox`,checked:W,onChange:e=>G(e.target.checked)})]}),(0,f.jsx)(`button`,{className:`ob-btn-primary`,onClick:se,disabled:!W||K,children:K?(0,f.jsxs)(f.Fragment,{children:[(0,f.jsx)(`span`,{className:`ob-spinner`}),`Recording acceptance`]}):`Accept Terms and Continue`})]})}),(0,f.jsx)(h,{number:5,title:`Claim your welcome bonus`,subtitle:`All steps complete - your 5,000 GradiosEduPlus wallet credit is ready.`,done:y.bonus_given,active:Z===`bonus`,children:!y.bonus_given&&(0,f.jsxs)(`div`,{className:`ob-bonus-claim`,children:[(0,f.jsx)(`div`,{style:{fontSize:32},"aria-hidden":`true`}),(0,f.jsx)(`div`,{className:`ob-bonus-amount`,children:`5,000`}),(0,f.jsx)(`p`,{className:`ob-bonus-desc`,children:`Credited directly to your school wallet for GradiosEduPlus subscription. It expires after 30 days if it is not used.`}),(0,f.jsx)(`button`,{className:`ob-btn-claim`,onClick:oe,disabled:J,style:{maxWidth:280},children:J?(0,f.jsxs)(f.Fragment,{children:[(0,f.jsx)(`span`,{className:`ob-spinner ob-spinner--dark`}),`Activating`]}):(0,f.jsxs)(f.Fragment,{children:[(0,f.jsx)(`svg`,{width:`15`,height:`15`,viewBox:`0 0 16 16`,fill:`none`,children:(0,f.jsx)(`path`,{d:`M8 2l2 4h4l-3 2.6 1.2 4L8 10.3 3.8 12.6 5 8.6 2 6h4z`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinejoin:`round`})}),`Claim 5,000 & Activate`]})})]})})]}),(0,f.jsxs)(`p`,{className:`ob-footer`,children:[`Need help? Contact`,` `,(0,f.jsx)(`a`,{href:`mailto:support@gradequest.com`,children:`support@gradequest.com`}),` `,`after activation.`]})]})]})]})}export{_ as default};