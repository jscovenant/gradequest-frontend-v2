import{i as e}from"./rolldown-runtime-CWU8vmCm.js";import{Ut as t}from"./vendor-misc-OZLc0tLq.js";import{S as n,h as r,p as i}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as a,b as o,w as s,x as c,y as l}from"./index-D6TxbaCx.js";var u=e(t(),1),d=i();function f(){let{slug:e}=n(),[t,i]=(0,u.useState)(null),[f,p]=(0,u.useState)([]),[m,h]=(0,u.useState)(!0),[g,_]=(0,u.useState)(``),[v,y]=(0,u.useState)(!1);(0,u.useEffect)(()=>{window.scrollTo(0,0),e&&(async()=>{h(!0),_(``);try{let t=await s.get(`/blog/${e}`);t.data?.status&&t.data?.data?i(t.data.data):_(`The requested article could not be found.`)}catch(e){_(e?.response?.data?.message||`Article not found or has been moved.`)}finally{h(!1)}})()},[e]),(0,u.useEffect)(()=>{(async()=>{try{p(((await s.get(`/frontend-blogs`)).data?.data||[]).filter(t=>t.slug!==e).slice(0,3))}catch{}})()},[e]);let b=()=>{navigator.clipboard.writeText(window.location.href),y(!0),setTimeout(()=>y(!1),2500)},x=e=>{if(!e)return null;try{let t=e.match(/^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/);return t&&t[2].length===11?`https://www.youtube.com/embed/${t[2]}`:null}catch{return null}};return m?(0,d.jsx)(l,{}):(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(a,{title:t?`${t.title} — SchoolProfit Insights`:`Article — SchoolProfit Insights`}),(0,d.jsx)(`style`,{children:`
        .gq-blog-detail-root {
          font-family: 'Plus Jakarta Sans', -apple-system, sans-serif;
          background: #FAFAFA;
          color: #1E293B;
          min-height: 100vh;
        }

        .gq-article-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 100%);
          color: #FFFFFF;
          padding: 80px 20px 60px 20px;
          text-align: center;
          position: relative;
          overflow: hidden;
        }

        .gq-article-hero::after {
          content: "";
          position: absolute;
          inset: 0;
          background: radial-gradient(circle at 80% 20%, rgba(251, 191, 36, 0.1) 0%, transparent 60%);
          pointer-events: none;
        }

        .gq-article-category {
          display: inline-block;
          background: rgba(251, 191, 36, 0.15);
          border: 1px solid rgba(251, 191, 36, 0.35);
          color: #FBBF24;
          font-size: 12px;
          font-weight: 800;
          text-transform: uppercase;
          letter-spacing: 0.1em;
          padding: 6px 14px;
          border-radius: 999px;
          margin-bottom: 16px;
        }

        .gq-article-title {
          font-family: 'Lora', 'Playfair Display', serif;
          font-size: 38px;
          font-weight: 800;
          line-height: 1.3;
          max-width: 860px;
          margin: 0 auto 20px auto;
          color: #FFFFFF;
        }

        @media (max-width: 768px) {
          .gq-article-title {
            font-size: 28px;
          }
        }

        .gq-article-meta {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 18px;
          font-size: 14px;
          color: #94A3B8;
          flex-wrap: wrap;
        }

        .gq-article-container {
          max-width: 820px;
          margin: -40px auto 60px auto;
          background: #FFFFFF;
          border-radius: 20px;
          border: 1px solid #E2E8F0;
          box-shadow: 0 16px 40px -10px rgba(15, 39, 68, 0.08);
          padding: 40px 48px;
          position: relative;
          z-index: 5;
        }

        @media (max-width: 768px) {
          .gq-article-container {
            margin: -20px 14px 40px 14px;
            padding: 24px 20px;
          }
        }

        .gq-article-thumbnail {
          width: 100%;
          max-height: 440px;
          object-fit: cover;
          border-radius: 14px;
          margin-bottom: 32px;
          border: 1px solid #E2E8F0;
        }

        .gq-article-body {
          font-size: 17px;
          line-height: 1.85;
          color: #334155;
        }

        .gq-article-body p {
          margin-bottom: 22px;
        }

        .gq-article-body h2 {
          font-size: 24px;
          font-weight: 800;
          color: #0F2744;
          margin: 36px 0 16px 0;
        }

        .gq-article-body h3 {
          font-size: 20px;
          font-weight: 700;
          color: #0F2744;
          margin: 28px 0 12px 0;
        }

        .gq-article-body blockquote {
          border-left: 4px solid #D97706;
          padding: 12px 20px;
          background: #FFFBEB;
          border-radius: 0 10px 10px 0;
          font-style: italic;
          color: #92400E;
          margin: 24px 0;
        }

        .gq-article-body ul, .gq-article-body ol {
          margin-bottom: 24px;
          padding-left: 24px;
        }

        .gq-article-body li {
          margin-bottom: 8px;
        }

        .gq-share-bar {
          border-top: 1px solid #E2E8F0;
          border-bottom: 1px solid #E2E8F0;
          padding: 18px 0;
          margin: 40px 0;
          display: flex;
          align-items: center;
          justify-content: space-between;
          flex-wrap: wrap;
          gap: 14px;
        }

        .gq-share-btn {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 8px 16px;
          border-radius: 8px;
          font-size: 13px;
          font-weight: 700;
          text-decoration: none;
          transition: all 0.2s ease;
          border: 1px solid #E2E8F0;
          color: #334155;
          background: #F8FAFC;
        }

        .gq-share-btn:hover {
          background: #0F2744;
          color: #FFFFFF;
          border-color: #0F2744;
        }

        .gq-cta-card {
          background: linear-gradient(135deg, #0F2744 0%, #1D4ED8 100%);
          border-radius: 16px;
          color: #FFFFFF;
          padding: 36px;
          text-align: center;
          margin: 40px 0 0 0;
        }
      `}),(0,d.jsxs)(`div`,{className:`gq-blog-detail-root`,children:[(0,d.jsx)(o,{}),g||!t?(0,d.jsxs)(`div`,{className:`container py-5 text-center`,style:{minHeight:`60vh`,display:`flex`,flexDirection:`column`,justifyContent:`center`,alignItems:`center`},children:[(0,d.jsx)(`i`,{className:`bi bi-file-earmark-x fs-1 text-danger mb-3`}),(0,d.jsx)(`h2`,{className:`fw-bold mb-2`,children:`Article Not Found`}),(0,d.jsx)(`p`,{className:`text-muted mb-4`,children:g||`The article you are looking for does not exist or has been unpublished.`}),(0,d.jsx)(r,{to:`/`,className:`btn btn-primary fw-bold px-4 py-2`,style:{borderRadius:`10px`},children:`← Return to Homepage`})]}):(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(`section`,{className:`gq-article-hero`,children:(0,d.jsxs)(`div`,{className:`container`,children:[(0,d.jsx)(`span`,{className:`gq-article-category`,children:t.category||`Education Insight`}),(0,d.jsx)(`h1`,{className:`gq-article-title`,children:t.title}),(0,d.jsxs)(`div`,{className:`gq-article-meta`,children:[(0,d.jsxs)(`span`,{children:[(0,d.jsx)(`i`,{className:`bi bi-calendar3 me-1.5 text-warning`}),` `,(e=>{if(!e)return`Recent`;let t=new Date(e);return Number.isNaN(t.getTime())?`Recent`:t.toLocaleDateString(`en-GB`,{day:`2-digit`,month:`short`,year:`numeric`})})(t.created_at)]}),(0,d.jsx)(`span`,{children:`•`}),(0,d.jsxs)(`span`,{children:[(0,d.jsx)(`i`,{className:`bi bi-clock me-1.5 text-warning`}),` `,(e=>{if(!e)return`3 min read`;let t=e.replace(/<[^>]*>/g,``).split(/\s+/).length;return`${Math.max(1,Math.ceil(t/200))} min read`})(t.body)]}),(0,d.jsx)(`span`,{children:`•`}),(0,d.jsxs)(`span`,{children:[(0,d.jsx)(`i`,{className:`bi bi-person-check me-1.5 text-warning`}),` SchoolProfit Editorial`]})]})]})}),(0,d.jsx)(`main`,{className:`container`,children:(0,d.jsxs)(`article`,{className:`gq-article-container`,children:[t.thumbnail&&(0,d.jsx)(`img`,{src:t.thumbnail_url||`/${t.thumbnail}`,alt:t.title,className:`gq-article-thumbnail`}),(0,d.jsx)(`div`,{className:`gq-article-body`,dangerouslySetInnerHTML:{__html:t.body||t.excerpt||`<p>No content available.</p>`}}),t.youtube_url&&x(t.youtube_url)&&(0,d.jsxs)(`div`,{style:{marginTop:`36px`,marginBottom:`36px`},children:[(0,d.jsxs)(`h4`,{style:{fontWeight:800,color:`#0F2744`,marginBottom:`14px`,fontSize:`18px`},children:[(0,d.jsx)(`i`,{className:`bi bi-youtube text-danger me-2`}),`Watch Video Presentation`]}),(0,d.jsx)(`div`,{style:{position:`relative`,paddingBottom:`56.25%`,height:0,overflow:`hidden`,borderRadius:`12px`,border:`1px solid #E2E8F0`},children:(0,d.jsx)(`iframe`,{src:x(t.youtube_url),title:t.title,style:{position:`absolute`,top:0,left:0,width:`100%`,height:`100%`,border:0},allow:`accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture`,allowFullScreen:!0})})]}),(0,d.jsxs)(`div`,{className:`gq-share-bar`,children:[(0,d.jsxs)(`div`,{className:`d-flex align-items-center gap-2`,children:[(0,d.jsx)(`span`,{className:`fw-bold text-dark`,style:{fontSize:`13.5px`},children:`Share article:`}),(0,d.jsxs)(`a`,{href:`https://api.whatsapp.com/send?text=${encodeURIComponent(`${t.title} - Read more on SchoolProfit: ${window.location.href}`)}`,target:`_blank`,rel:`noopener noreferrer`,className:`gq-share-btn`,children:[(0,d.jsx)(`i`,{className:`bi bi-whatsapp text-success`}),` WhatsApp`]}),(0,d.jsxs)(`a`,{href:`https://twitter.com/intent/tweet?text=${encodeURIComponent(t.title)}&url=${encodeURIComponent(window.location.href)}`,target:`_blank`,rel:`noopener noreferrer`,className:`gq-share-btn`,children:[(0,d.jsx)(`i`,{className:`bi bi-twitter-x`}),` Share`]})]}),(0,d.jsxs)(`button`,{type:`button`,onClick:b,className:`gq-share-btn`,children:[(0,d.jsx)(`i`,{className:v?`bi bi-check2 text-success`:`bi bi-link-45deg`}),v?`Link Copied!`:`Copy Link`]})]}),(0,d.jsxs)(`div`,{className:`d-flex align-items-center justify-content-between flex-wrap gap-3`,children:[(0,d.jsx)(r,{to:`/`,className:`text-decoration-none fw-bold text-primary d-inline-flex align-items-center gap-1.5`,style:{fontSize:`14px`},children:`← Back to SchoolProfit Homepage`}),(0,d.jsx)(`a`,{href:`#more-articles`,className:`text-decoration-none fw-bold text-secondary`,style:{fontSize:`14px`},children:`Explore More Insights ↓`})]}),(0,d.jsxs)(`div`,{className:`gq-cta-card`,children:[(0,d.jsx)(`span`,{className:`badge px-3 py-1.5 mb-2`,style:{background:`#FBBF24`,color:`#0F2744`,fontWeight:800,fontSize:`12px`},children:`Transform Your School`}),(0,d.jsx)(`h3`,{className:`fw-bold mb-2 text-white`,style:{fontSize:`22px`},children:`Ready to modernize your academic & financial operations?`}),(0,d.jsx)(`p`,{className:`text-white-50 mb-4`,style:{fontSize:`14.5px`,maxWidth:`520px`,margin:`0 auto 20px auto`},children:`Join hundreds of leading schools already using SchoolProfit for computerized report cards, instant fee collection, and offline CBT exams.`}),(0,d.jsxs)(`div`,{className:`d-flex justify-content-center gap-3 flex-wrap`,children:[(0,d.jsx)(r,{to:`/book-demo`,className:`btn btn-warning fw-bold px-4 py-2.5 text-dark`,style:{borderRadius:`10px`},children:`Book a Free Demo →`}),(0,d.jsx)(`a`,{href:`https://wa.me/2348165748374?text=Hello%20SchoolProfit%2C%20I%20want%20to%20learn%20more%20about%20your%20software`,target:`_blank`,rel:`noreferrer`,className:`btn btn-outline-light fw-bold px-4 py-2.5`,style:{borderRadius:`10px`},children:`Chat on WhatsApp`})]})]})]})}),f.length>0&&(0,d.jsx)(`section`,{id:`more-articles`,className:`py-5`,style:{background:`#F1F5F9`,borderTop:`1px solid #E2E8F0`},children:(0,d.jsxs)(`div`,{className:`container`,style:{maxWidth:`1080px`},children:[(0,d.jsxs)(`div`,{className:`text-center mb-4`,children:[(0,d.jsx)(`span`,{style:{color:`#D97706`,fontWeight:800,fontSize:`12px`,textTransform:`uppercase`,letterSpacing:`0.08em`},children:`Related Insights`}),(0,d.jsx)(`h3`,{className:`fw-bold text-dark mb-0`,style:{fontSize:`24px`},children:`More Articles You May Like`})]}),(0,d.jsx)(`div`,{className:`row g-4 justify-content-center`,children:f.map(e=>(0,d.jsx)(`div`,{className:`col-12 col-md-6 col-lg-4`,children:(0,d.jsxs)(`div`,{className:`card h-100 border-0 shadow-sm`,style:{borderRadius:`14px`,overflow:`hidden`,transition:`transform 0.2s ease`},children:[e.thumbnail?(0,d.jsx)(`img`,{src:e.thumbnail_url||`/${e.thumbnail}`,alt:e.title,style:{height:`160px`,objectFit:`cover`,width:`100%`}}):(0,d.jsx)(`div`,{style:{height:`160px`,background:`linear-gradient(135deg, #0F2744 0%, #1E3A8A 100%)`,display:`flex`,alignItems:`center`,justifyContent:`center`,color:`#FBBF24`},children:(0,d.jsx)(`i`,{className:`bi bi-journal-text fs-1`})}),(0,d.jsxs)(`div`,{className:`card-body p-3.5 d-flex flex-column`,children:[(0,d.jsx)(`span`,{className:`badge bg-light text-primary align-self-start mb-2 fw-bold`,style:{fontSize:`11px`},children:e.category||`General`}),(0,d.jsx)(`h5`,{className:`card-title fw-bold text-dark mb-2`,style:{fontSize:`16px`,lineHeight:`1.4`},children:e.title}),(0,d.jsx)(`p`,{className:`card-text text-muted flex-grow-1`,style:{fontSize:`13px`,lineHeight:`1.5`},children:e.excerpt?e.excerpt.slice(0,100)+`...`:`Discover key insights and best practices in school administration.`}),(0,d.jsx)(r,{to:`/blog/${e.slug}`,className:`fw-bold text-primary text-decoration-none mt-2 d-inline-flex align-items-center gap-1`,style:{fontSize:`13px`},children:`Read Article →`})]})]})},e.id))})]})})]}),(0,d.jsx)(c,{})]})]})}export{f as default};