import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{h as t,p as n}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as r,E as i,P as a,d as o,f as s,l as c,u as l}from"./index-D6TxbaCx.js";var u=e(),d=n(),f=null;function ee(){return window.PaystackPop?Promise.resolve():f||(f=new Promise((e,t)=>{let n=document.createElement(`script`);n.src=`https://js.paystack.co/v2/inline.js`,n.async=!0,n.onload=()=>e(),n.onerror=()=>t(Error(`Could not load Paystack checkout.`)),document.body.appendChild(n)}),f)}function p(e){let t=e?.response?.status,n=e?.response?.data;return t===409?n?.message??n?.error??`This fee is already assigned.`:t===404?n?.message??`Resource not found.`:t===422?n?.message??`Please verify all required fields.`:n?.message??e?.message??`Something went wrong.`}function m(e){return Number(e??0).toLocaleString(`en-NG`,{style:`currency`,currency:`NGN`,maximumFractionDigits:0})}function h(){let{showSuccess:e,showError:n,showWarning:f}=c(),[h,te]=(0,u.useState)(!1),[ne,re]=(0,u.useState)(!0),[ie,ae]=(0,u.useState)([]),[oe,se]=(0,u.useState)([]),[ce,le]=(0,u.useState)([]),[ue,g]=(0,u.useState)(!0),[_,v]=(0,u.useState)(``),[y,de]=(0,u.useState)(!1),[b,x]=(0,u.useState)(null),[S,C]=(0,u.useState)(``),[w,T]=(0,u.useState)(``),[E,D]=(0,u.useState)(``),[O,k]=(0,u.useState)([]),[fe,A]=(0,u.useState)(!1),[j,M]=(0,u.useState)({}),[N,P]=(0,u.useState)(null),[pe,F]=(0,u.useState)(!1),[I,L]=(0,u.useState)(null),[R,z]=(0,u.useState)(null),[B,V]=(0,u.useState)(``),[H,U]=(0,u.useState)(``),[W,G]=(0,u.useState)(!1),[K,q]=(0,u.useState)(null);(0,u.useEffect)(()=>{let e=window.setTimeout(()=>re(!1),80);return()=>window.clearTimeout(e)},[]),(0,u.useEffect)(()=>{let e=!0;async function t(){try{g(!0);let[t,n,r]=await Promise.all([a.get(`/sections`),a.get(`/facademic-sessions`),a.get(`/fterms`)]);if(!e)return;let i=t.data?.data??t.data??[];ae(Array.isArray(i)?i.map(e=>({id:e.id,name:e.name})):[]);let o=n.data?.data??n.data??[],s=(Array.isArray(o)?o:[]).map(e=>({id:e.id,name:e.name??e.session??e.title??``}));se(s),s.length>0&&!w&&T(s[0].id);let c=r.data?.data??r.data??[],l=(Array.isArray(c)?c:[]).map(e=>({id:e.id,name:e.name??e.term??``}));le(l),l.length>0&&!E&&D(l[0].id)}catch(e){console.error(e),n(p(e)||`Failed to load fee configuration options.`)}finally{e&&g(!1)}}return t(),()=>{e=!1}},[]);async function J(){let t=_.trim();if(!t)return f(`Please enter a student admission or registration number.`);try{de(!0);let r=await a.get(`/students/search`,{params:{query:t}}),i=r.data?.data??r.data??[],o=Array.isArray(i)?i:[],s=o.find(e=>(e.reg_no??``).toLowerCase()===t.toLowerCase())??o[0];if(!s)return x(null),P(null),n(`No student found matching that registration number.`);x(s),s.section_id&&C(s.section_id),e(`Found student: ${s.firstname} ${s.surname}`),await Z(s.reg_no)}catch(e){console.error(e),n(p(e)||`Failed to search student.`)}finally{de(!1)}}(0,u.useEffect)(()=>{b?.id&&S&&w&&E&&me(b.id,Number(S),Number(w),Number(E))},[b?.id,S,w,E]);async function me(e,t,n,r){try{A(!0),M({});let i=await a.post(`/fees/fetch-types`,{student_id:e,section_id:t,session_id:n,term_id:r});k(Array.isArray(i.data?.fee_types)?i.data.fee_types:[])}catch(e){console.error(e),k([])}finally{A(!1)}}let Y=(0,u.useMemo)(()=>Object.entries(j).filter(([e,t])=>t).map(([e])=>Number(e)),[j]),he=(0,u.useMemo)(()=>{if(!O.length)return 0;let e=new Map(O.map(e=>[e.id,e]));return Y.reduce((t,n)=>t+(e.get(n)?.amount??0),0)},[Y,O]);function X(e){M(t=>({...t,[e]:!t[e]}))}function ge(){let e={};O.forEach(t=>e[t.id]=!0),M(e)}function _e(){M({})}async function ve(){if(!b?.id)return n(`Please search and select a student first.`);if(!S||!w||!E)return n(`Please select Section, Session, and Term.`);if(Y.length===0)return n(`Select at least one fee type to assign.`);try{L(`fees:assign`),e((await a.post(`/fees/assign`,{student_id:b.id,section_id:Number(S),session_id:Number(w),term_id:Number(E),fee_type_ids:Y})).data?.message??`Fee(s) assigned successfully.`),await Z(b.reg_no),_e()}catch(e){console.error(e),n(p(e))}finally{L(null)}}async function Z(e){if(e.trim())try{F(!0),P((await a.get(`/fees/student/details`,{params:{reg_no:e.trim(),session_id:w||void 0,term_id:E||void 0}})).data)}catch(e){console.error(e),P(null)}finally{F(!1)}}async function ye(t){if(window.confirm(`Are you sure you want to remove this fee assignment? (Paid fees cannot be removed)`))try{L(`fees:remove:${t}`),e((await a.delete(`/student-fees/${t}`)).data?.message??`Fee assignment removed.`),b?.reg_no&&await Z(b.reg_no)}catch(e){console.error(e),n(p(e))}finally{L(null)}}function be(e){z({id:e.id,label:e.fee_type?.name??`Fee #${e.id}`,balance:e.balance}),V(String(e.balance)),U(``),q(null)}function Q(){W||z(null)}async function xe(){if(!R)return;let t=Number(B);if(!t||t<100){q(`Enter an amount of at least ₦100.`);return}if(t>R.balance){q(`Amount cannot exceed outstanding balance of ${m(R.balance)}.`);return}if(!H.trim()){q(`Enter the parent or payer email address for receipt.`);return}q(null),G(!0);try{let{data:r}=await a.post(`/fees/online/initialize`,{student_fee_id:R.id,amount:t,email:H.trim()});await ee(),z(null),new window.PaystackPop().resumeTransaction(r.access_code,{onSuccess:async t=>{try{await a.get(`/fees/online/verify/${t.reference}`),e(`Payment completed successfully!`)}catch{f(`Payment processed. Updating records...`)}finally{G(!1),b?.reg_no&&await Z(b.reg_no)}},onCancel:()=>{G(!1),f(`Payment was cancelled.`)},onError:e=>{G(!1),n(e?.message||`Payment could not be completed.`)}})}catch(e){console.error(e),G(!1),q(p(e))}}let $=(0,u.useMemo)(()=>{let e=N?.fees??[],t=e.reduce((e,t)=>e+Number(t.total_amount??0),0),n=e.reduce((e,t)=>e+Number(t.amount_paid??0),0),r=e.reduce((e,t)=>e+Number(t.balance??0),0),i=t>0?Math.round(n/t*100):0;return{totalAmount:t,totalPaid:n,totalBal:r,count:e.length,percent:i}},[N]);return(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(r,{title:`Fee Assignments & Allocations`}),(0,d.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');
        .fa-main {
          min-height: 100vh;
          background: #F8FAFC;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          padding: calc(var(--gq-topnav-height, 66px) + 20px) 24px 48px;
          overflow-x: hidden;
          box-sizing: border-box;
        }
        @media(max-width: 767.98px) {
          .fa-main { padding: calc(var(--gq-topnav-height, 66px) + 12px) 12px 36px; }
        }
        .fa-shell { max-width: 1280px; margin: 0 auto; width: 100%; }
        
        /* Hero Banner */
        .fa-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 18px;
          padding: 28px 32px;
          color: #fff;
          position: relative;
          overflow: hidden;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
          margin-bottom: 22px;
        }
        @media(max-width: 767.98px) {
          .fa-hero { padding: 20px 16px; border-radius: 14px; }
        }
        .fa-hero-glow {
          position: absolute;
          top: -60px;
          right: -60px;
          width: 280px;
          height: 280px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.15) 0%, transparent 65%);
          pointer-events: none;
        }
        .fa-hero h1 { font-size: 24px; font-weight: 800; margin: 0 0 6px; color: #fff; }
        @media(max-width: 767.98px) { .fa-hero h1 { font-size: 19px; } }
        .fa-hero p { margin: 0; color: #CBD5E1; font-size: 13.5px; max-width: 680px; line-height: 1.55; }
        .fa-badge {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          font-size: 11px;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.04em;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.20);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius: 100px;
          padding: 4px 10px;
          margin-bottom: 10px;
        }
        .fa-hero-actions { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 14px; }
        .fa-btn-gold {
          background: #D97706;
          color: #fff;
          font-weight: 700;
          font-size: 13px;
          padding: 8px 16px;
          border-radius: 10px;
          border: none;
          text-decoration: none;
          display: inline-flex;
          align-items: center;
          gap: 7px;
          cursor: pointer;
          transition: all 0.2s;
        }
        .fa-btn-gold:hover { background: #B45309; color: #fff; transform: translateY(-1px); }
        .fa-btn-soft {
          background: rgba(255, 255, 255, 0.12);
          color: #fff;
          font-weight: 600;
          font-size: 13px;
          padding: 8px 16px;
          border-radius: 10px;
          border: 1px solid rgba(255, 255, 255, 0.22);
          text-decoration: none;
          display: inline-flex;
          align-items: center;
          gap: 7px;
          cursor: pointer;
        }
        .fa-btn-soft:hover { background: rgba(255, 255, 255, 0.20); color: #fff; }

        /* Main Workspace Grid */
        .fa-grid {
          display: grid;
          grid-template-columns: 460px minmax(0, 1fr);
          gap: 20px;
          align-items: start;
        }
        @media(max-width: 1024px) {
          .fa-grid { grid-template-columns: 1fr; }
        }

        /* Panels */
        .fa-card {
          background: #fff;
          border: 1px solid #E2E8F0;
          border-radius: 16px;
          box-shadow: 0 4px 16px rgba(15, 39, 68, 0.03);
          overflow: hidden;
          margin-bottom: 18px;
        }
        .fa-card-head {
          padding: 16px 20px;
          border-bottom: 1px solid #F1F5F9;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 10px;
          background: #fff;
        }
        .fa-card-title {
          font-size: 15px;
          font-weight: 800;
          color: #0F2744;
          margin: 0;
          display: flex;
          align-items: center;
          gap: 8px;
        }
        .fa-card-body { padding: 18px 20px; }
        @media(max-width: 767.98px) {
          .fa-card-body { padding: 14px 14px; }
        }

        /* Step numbers */
        .fa-step-badge {
          width: 24px;
          height: 24px;
          border-radius: 50%;
          background: #0F2744;
          color: #fff;
          font-size: 12px;
          font-weight: 800;
          display: inline-flex;
          align-items: center;
          justify-content: center;
        }

        /* Inputs & Dropdowns */
        .fa-label {
          display: block;
          font-size: 11.5px;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.03em;
          color: #475569;
          margin-bottom: 6px;
        }
        .fa-input, .fa-select {
          width: 100%;
          border: 1px solid #CBD5E1;
          border-radius: 10px;
          padding: 9px 12px;
          font-size: 13.5px;
          font-weight: 600;
          color: #0F2744;
          background: #F8FAFC;
          outline: none;
          transition: all 0.2s;
          box-sizing: border-box;
        }
        .fa-input:focus, .fa-select:focus {
          border-color: #D97706;
          background: #fff;
          box-shadow: 0 0 0 3px rgba(217, 119, 6, 0.12);
        }

        /* Student Identity Card */
        .fa-student-card {
          background: linear-gradient(135deg, #F8FAFC 0%, #EEF2F6 100%);
          border: 1px solid #CBD5E1;
          border-radius: 12px;
          padding: 14px;
          display: flex;
          align-items: center;
          gap: 12px;
          margin-top: 12px;
        }
        .fa-student-avatar {
          width: 44px;
          height: 44px;
          border-radius: 10px;
          background: #0F2744;
          color: #FBBF24;
          font-weight: 800;
          font-size: 16px;
          display: grid;
          place-items: center;
          flex-shrink: 0;
        }
        .fa-student-info h4 { font-size: 14.5px; font-weight: 800; margin: 0 0 2px; color: #0F2744; }
        .fa-student-info p { font-size: 12px; color: #64748B; margin: 0; }

        /* Fee Checklist */
        .fa-fee-item {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 11px 14px;
          border: 1px solid #E2E8F0;
          border-radius: 10px;
          margin-bottom: 8px;
          background: #fff;
          cursor: pointer;
          transition: all 0.15s;
        }
        .fa-fee-item:hover { border-color: #CBD5E1; background: #F8FAFC; }
        .fa-fee-item.selected {
          border-color: #D97706;
          background: #FFFBEB;
        }
        .fa-fee-info strong { display: block; font-size: 13.5px; color: #0F2744; }
        .fa-fee-info span { font-size: 12px; color: #64748B; }
        .fa-fee-amount { font-size: 14px; font-weight: 800; color: #0F2744; }

        /* Ledger Summary Tiles */
        .fa-stat-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 12px;
          margin-bottom: 16px;
        }
        @media(max-width: 640px) {
          .fa-stat-grid { grid-template-columns: 1fr; gap: 8px; }
        }
        .fa-stat-tile {
          background: #F8FAFC;
          border: 1px solid #E2E8F0;
          border-radius: 12px;
          padding: 14px;
        }
        .fa-stat-tile span { display: block; font-size: 11px; font-weight: 700; color: #64748B; text-transform: uppercase; }
        .fa-stat-tile strong { display: block; font-size: 18px; font-weight: 800; color: #0F2744; margin-top: 4px; }
        .fa-stat-tile.bal strong { color: #DC2626; }
        .fa-stat-tile.paid strong { color: #16A34A; }

        /* Status Pills */
        .fa-pill {
          display: inline-flex;
          align-items: center;
          padding: 4px 10px;
          border-radius: 999px;
          font-size: 11px;
          font-weight: 700;
          text-transform: capitalize;
        }
        .fa-pill-paid { background: #DCFCE7; color: #166534; }
        .fa-pill-partial { background: #FEF3C7; color: #92400E; }
        .fa-pill-unpaid { background: #FEE2E2; color: #991B1B; }

        /* Ledger Table */
        .fa-table-wrap {
          width: 100%;
          overflow-x: auto;
          -webkit-overflow-scrolling: touch;
          border: 1px solid #E2E8F0;
          border-radius: 12px;
          margin-top: 10px;
        }
        .fa-table {
          width: 100%;
          min-width: 640px;
          border-collapse: collapse;
          font-size: 13px;
        }
        .fa-table th {
          background: #F8FAFC;
          color: #475569;
          font-weight: 700;
          text-transform: uppercase;
          font-size: 11px;
          letter-spacing: 0.03em;
          padding: 11px 14px;
          border-bottom: 1px solid #E2E8F0;
          text-align: left;
        }
        .fa-table td {
          padding: 12px 14px;
          border-bottom: 1px solid #F1F5F9;
          vertical-align: middle;
          color: #334155;
        }
        .fa-table tr:last-child td { border-bottom: none; }
        .fa-table tr:hover td { background: #F8FAFC; }

        /* Actions */
        .fa-action-btn {
          border: 1px solid #E2E8F0;
          background: #fff;
          color: #0F2744;
          font-size: 12px;
          font-weight: 700;
          padding: 6px 12px;
          border-radius: 8px;
          display: inline-flex;
          align-items: center;
          gap: 5px;
          cursor: pointer;
          transition: all 0.15s;
        }
        .fa-action-btn:hover { background: #F1F5F9; border-color: #CBD5E1; }
        .fa-action-btn.pay {
          background: #0F2744;
          color: #fff;
          border-color: #0F2744;
        }
        .fa-action-btn.pay:hover { background: #1E3A8A; }
        .fa-action-btn.del { color: #DC2626; }
        .fa-action-btn.del:hover { background: #FEE2E2; border-color: #FECACA; }

        /* Modal */
        .fa-modal-backdrop {
          position: fixed;
          inset: 0;
          background: rgba(15, 39, 68, 0.6);
          backdrop-filter: blur(4px);
          z-index: 2000;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 16px;
        }
        .fa-modal {
          background: #fff;
          border-radius: 16px;
          width: min(480px, 100%);
          box-shadow: 0 20px 60px rgba(15, 39, 68, 0.2);
          overflow: hidden;
        }
        .fa-modal-head {
          padding: 16px 20px;
          border-bottom: 1px solid #E2E8F0;
          display: flex;
          align-items: center;
          justify-content: space-between;
        }
        .fa-modal-head h3 { font-size: 16px; font-weight: 800; margin: 0; color: #0F2744; }
        .fa-modal-body { padding: 20px; }
      `}),(0,d.jsx)(s,{sidebarOpen:h,setSidebarOpen:te,title:`Fee Assignments & Allocations`}),(0,d.jsx)(`div`,{className:`container-fluid`,children:(0,d.jsxs)(`div`,{className:`row`,children:[(0,d.jsx)(o,{sidebarOpen:h,setSidebarOpen:te}),(0,d.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto db-main fa-main`,children:[ne&&(0,d.jsx)(i,{message:`Loading Fee Management...`}),(0,d.jsxs)(`div`,{className:`fa-shell`,children:[(0,d.jsxs)(`section`,{className:`fa-hero`,children:[(0,d.jsx)(`div`,{className:`fa-hero-glow`}),(0,d.jsxs)(`div`,{style:{position:`relative`,zIndex:1},children:[(0,d.jsxs)(`span`,{className:`fa-badge`,children:[(0,d.jsx)(`i`,{className:`bi bi-shield-check me-1`}),` Student Fee Management`]}),(0,d.jsx)(`h1`,{children:`Fee Assignments & Allocations`}),(0,d.jsx)(`p`,{children:`Assign termly tuition, levies, and school fees to students, inspect live financial ledgers, and collect instant payments.`}),(0,d.jsxs)(`div`,{className:`fa-hero-actions`,children:[(0,d.jsxs)(t,{to:`/fees/structure`,className:`fa-btn-soft`,children:[(0,d.jsx)(`i`,{className:`bi bi-gear me-1`}),` Configure Fee Structures`]}),(0,d.jsxs)(t,{to:`/fees/payments`,className:`fa-btn-soft`,children:[(0,d.jsx)(`i`,{className:`bi bi-wallet2 me-1`}),` View All Student Payments`]})]})]})]}),(0,d.jsxs)(`div`,{className:`fa-grid`,children:[(0,d.jsxs)(`div`,{children:[(0,d.jsxs)(`div`,{className:`fa-card`,children:[(0,d.jsxs)(`div`,{className:`fa-card-head`,children:[(0,d.jsxs)(`div`,{className:`fa-card-title`,children:[(0,d.jsx)(`span`,{className:`fa-step-badge`,children:`1`}),` Student Lookup`]}),b&&(0,d.jsx)(`button`,{className:`btn btn-sm btn-link text-muted p-0 text-decoration-none`,onClick:()=>{x(null),P(null),v(``)},children:`Clear`})]}),(0,d.jsxs)(`div`,{className:`fa-card-body`,children:[(0,d.jsx)(`label`,{className:`fa-label`,children:`Admission / Reg Number`}),(0,d.jsxs)(`div`,{className:`d-flex gap-2`,children:[(0,d.jsx)(`input`,{className:`fa-input`,placeholder:`e.g. GQ/2026/001`,value:_,onChange:e=>v(e.target.value),onKeyDown:e=>e.key===`Enter`&&J()}),(0,d.jsx)(`button`,{className:`fa-btn-gold`,onClick:J,disabled:y||!_.trim(),children:y?`Finding...`:`Find`})]}),b&&(0,d.jsxs)(`div`,{className:`fa-student-card`,children:[(0,d.jsx)(`div`,{className:`fa-student-avatar`,children:b.firstname?.charAt(0)||`S`}),(0,d.jsxs)(`div`,{className:`fa-student-info`,children:[(0,d.jsxs)(`h4`,{children:[b.firstname,` `,b.surname]}),(0,d.jsxs)(`p`,{children:[`Reg No: `,(0,d.jsx)(`strong`,{children:b.reg_no})]})]})]})]})]}),(0,d.jsxs)(`div`,{className:`fa-card`,children:[(0,d.jsx)(`div`,{className:`fa-card-head`,children:(0,d.jsxs)(`div`,{className:`fa-card-title`,children:[(0,d.jsx)(`span`,{className:`fa-step-badge`,children:`2`}),` Billing Period`]})}),(0,d.jsx)(`div`,{className:`fa-card-body`,children:(0,d.jsxs)(`div`,{className:`row g-2`,children:[(0,d.jsxs)(`div`,{className:`col-12 col-sm-6`,children:[(0,d.jsx)(`label`,{className:`fa-label`,children:`Academic Session`}),(0,d.jsxs)(`select`,{className:`fa-select`,value:w,onChange:e=>T(e.target.value?Number(e.target.value):``),children:[(0,d.jsx)(`option`,{value:``,children:`Select Session`}),oe.map(e=>(0,d.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]}),(0,d.jsxs)(`div`,{className:`col-12 col-sm-6`,children:[(0,d.jsx)(`label`,{className:`fa-label`,children:`Term`}),(0,d.jsxs)(`select`,{className:`fa-select`,value:E,onChange:e=>D(e.target.value?Number(e.target.value):``),children:[(0,d.jsx)(`option`,{value:``,children:`Select Term`}),ce.map(e=>(0,d.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]}),(0,d.jsxs)(`div`,{className:`col-12`,children:[(0,d.jsx)(`label`,{className:`fa-label`,children:`Class Section`}),(0,d.jsxs)(`select`,{className:`fa-select`,value:S,onChange:e=>C(e.target.value?Number(e.target.value):``),children:[(0,d.jsx)(`option`,{value:``,children:`Select Section / Class`}),ie.map(e=>(0,d.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]})]})})]}),(0,d.jsxs)(`div`,{className:`fa-card`,children:[(0,d.jsxs)(`div`,{className:`fa-card-head`,children:[(0,d.jsxs)(`div`,{className:`fa-card-title`,children:[(0,d.jsx)(`span`,{className:`fa-step-badge`,children:`3`}),` Select & Assign Fees`]}),O.length>0&&(0,d.jsxs)(`div`,{className:`d-flex gap-2`,children:[(0,d.jsx)(`button`,{className:`btn btn-sm btn-outline-secondary py-0 px-2`,onClick:ge,children:`All`}),(0,d.jsx)(`button`,{className:`btn btn-sm btn-outline-secondary py-0 px-2`,onClick:_e,children:`None`})]})]}),(0,d.jsx)(`div`,{className:`fa-card-body`,children:fe?(0,d.jsxs)(`div`,{className:`text-center py-4 text-muted`,children:[(0,d.jsx)(`div`,{className:`spinner-border spinner-border-sm me-2`}),` Loading fee types...`]}):b?O.length===0?(0,d.jsx)(`div`,{className:`text-center py-4 text-muted`,style:{fontSize:13},children:`No fee types configured for this section and period.`}):(0,d.jsxs)(`div`,{children:[O.map(e=>{let t=!!j[e.id];return(0,d.jsxs)(`div`,{className:`fa-fee-item ${t?`selected`:``}`,onClick:()=>X(e.id),children:[(0,d.jsxs)(`div`,{className:`d-flex align-items-center gap-2`,children:[(0,d.jsx)(`input`,{type:`checkbox`,className:`form-check-input mt-0`,checked:t,onChange:()=>X(e.id)}),(0,d.jsx)(`div`,{className:`fa-fee-info`,children:(0,d.jsx)(`strong`,{children:e.name})})]}),(0,d.jsx)(`div`,{className:`fa-fee-amount`,children:m(e.amount)})]},e.id)}),Y.length>0&&(0,d.jsxs)(`div`,{className:`mt-3 p-3 bg-light rounded-3 d-flex justify-content-between align-items-center`,children:[(0,d.jsxs)(`div`,{children:[(0,d.jsxs)(`small`,{className:`text-muted d-block`,children:[`Selected `,Y.length,` fee(s)`]}),(0,d.jsx)(`strong`,{className:`text-primary fs-6`,children:m(he)})]}),(0,d.jsx)(`button`,{className:`fa-btn-gold`,onClick:ve,disabled:I===`fees:assign`,children:I===`fees:assign`?`Assigning...`:`Assign to Student`})]})]}):(0,d.jsx)(`div`,{className:`text-center py-4 text-muted`,style:{fontSize:13},children:`Search and select a student above to view applicable fee types.`})})]})]}),(0,d.jsx)(`div`,{children:(0,d.jsxs)(`div`,{className:`fa-card`,children:[(0,d.jsxs)(`div`,{className:`fa-card-head`,children:[(0,d.jsxs)(`div`,{className:`fa-card-title`,children:[(0,d.jsx)(`i`,{className:`bi bi-journal-check text-primary`}),` Student Financial Ledger`]}),N?.student&&(0,d.jsx)(`span`,{className:`badge bg-light text-dark border`,children:N.student.class||N.student.section||`Student`})]}),(0,d.jsx)(`div`,{className:`fa-card-body`,children:pe?(0,d.jsxs)(`div`,{className:`text-center py-5 text-muted`,children:[(0,d.jsx)(`div`,{className:`spinner-border spinner-border-sm me-2`}),` Loading student ledger...`]}):N?(0,d.jsxs)(`div`,{children:[(0,d.jsxs)(`div`,{className:`fa-stat-grid`,children:[(0,d.jsxs)(`div`,{className:`fa-stat-tile`,children:[(0,d.jsx)(`span`,{children:`Total Assigned`}),(0,d.jsx)(`strong`,{children:m($.totalAmount)})]}),(0,d.jsxs)(`div`,{className:`fa-stat-tile paid`,children:[(0,d.jsx)(`span`,{children:`Total Paid`}),(0,d.jsx)(`strong`,{children:m($.totalPaid)})]}),(0,d.jsxs)(`div`,{className:`fa-stat-tile bal`,children:[(0,d.jsx)(`span`,{children:`Outstanding`}),(0,d.jsx)(`strong`,{children:m($.totalBal)})]})]}),(0,d.jsxs)(`div`,{className:`mb-4`,children:[(0,d.jsxs)(`div`,{className:`d-flex justify-content-between small text-muted mb-1 font-monospace`,children:[(0,d.jsx)(`span`,{children:`Payment Progress`}),(0,d.jsxs)(`span`,{children:[$.percent,`%`]})]}),(0,d.jsx)(`div`,{className:`progress`,style:{height:8,borderRadius:4},children:(0,d.jsx)(`div`,{className:`progress-bar ${$.percent===100?`bg-success`:`bg-warning`}`,style:{width:`${$.percent}%`}})})]}),(0,d.jsx)(`h6`,{className:`fw-bold text-dark mb-2`,children:`Assigned Fee Items`}),N.fees.length===0?(0,d.jsx)(`div`,{className:`p-4 bg-light rounded-3 text-center text-muted small`,children:`No fees assigned for this student yet. Use Step 3 to assign fees.`}):(0,d.jsx)(`div`,{className:`fa-table-wrap`,children:(0,d.jsxs)(`table`,{className:`fa-table`,children:[(0,d.jsx)(`thead`,{children:(0,d.jsxs)(`tr`,{children:[(0,d.jsx)(`th`,{children:`Fee Item`}),(0,d.jsx)(`th`,{children:`Total`}),(0,d.jsx)(`th`,{children:`Paid`}),(0,d.jsx)(`th`,{children:`Balance`}),(0,d.jsx)(`th`,{children:`Status`}),(0,d.jsx)(`th`,{className:`text-end`,children:`Actions`})]})}),(0,d.jsx)(`tbody`,{children:N.fees.map(e=>(0,d.jsxs)(`tr`,{children:[(0,d.jsxs)(`td`,{children:[(0,d.jsx)(`strong`,{children:e.fee_type?.name||`Fee #${e.fee_type_id}`}),(0,d.jsxs)(`div`,{className:`small text-muted`,children:[e.session?.name,` • `,e.term?.name]})]}),(0,d.jsx)(`td`,{children:m(e.total_amount)}),(0,d.jsx)(`td`,{className:`text-success fw-bold`,children:m(e.amount_paid)}),(0,d.jsx)(`td`,{className:e.balance>0?`text-danger fw-bold`:`text-muted`,children:m(e.balance)}),(0,d.jsx)(`td`,{children:(0,d.jsx)(`span`,{className:`fa-pill fa-pill-${e.status||(e.balance===0?`paid`:`unpaid`)}`,children:e.status||(e.balance===0?`paid`:`unpaid`)})}),(0,d.jsx)(`td`,{className:`text-end`,children:(0,d.jsxs)(`div`,{className:`d-inline-flex gap-2`,children:[e.balance>0&&(0,d.jsxs)(`button`,{className:`fa-action-btn pay`,onClick:()=>be(e),title:`Collect payment online via Paystack`,children:[(0,d.jsx)(`i`,{className:`bi bi-credit-card`}),` Pay`]}),e.amount_paid===0&&(0,d.jsx)(`button`,{className:`fa-action-btn del`,onClick:()=>ye(e.id),disabled:I===`fees:remove:${e.id}`,title:`Remove assigned fee`,children:(0,d.jsx)(`i`,{className:`bi bi-trash`})})]})})]},e.id))})]})})]}):(0,d.jsxs)(`div`,{className:`text-center py-5 text-muted`,children:[(0,d.jsx)(`i`,{className:`bi bi-search display-6 d-block mb-2 text-secondary opacity-50`}),(0,d.jsx)(`h6`,{className:`fw-bold text-dark`,children:`No Student Selected`}),(0,d.jsx)(`p`,{className:`small text-muted mb-0`,children:`Search a student by registration number on the left to inspect their fees and payments.`})]})})]})})]})]}),(0,d.jsx)(l,{})]})]})}),R&&(0,d.jsx)(`div`,{className:`fa-modal-backdrop`,onClick:Q,children:(0,d.jsxs)(`div`,{className:`fa-modal`,onClick:e=>e.stopPropagation(),children:[(0,d.jsxs)(`div`,{className:`fa-modal-head`,children:[(0,d.jsx)(`h3`,{children:`Collect Fee Payment`}),(0,d.jsx)(`button`,{className:`btn-close`,onClick:Q,disabled:W})]}),(0,d.jsxs)(`div`,{className:`fa-modal-body`,children:[(0,d.jsxs)(`div`,{className:`p-3 bg-light rounded-3 mb-3`,children:[(0,d.jsx)(`small`,{className:`text-muted d-block`,children:`Fee Item`}),(0,d.jsx)(`strong`,{className:`fs-6 text-dark`,children:R.label}),(0,d.jsxs)(`div`,{className:`d-flex justify-content-between mt-2 pt-2 border-top`,children:[(0,d.jsx)(`span`,{className:`small text-muted`,children:`Outstanding Balance`}),(0,d.jsx)(`span`,{className:`fw-bold text-danger`,children:m(R.balance)})]})]}),K&&(0,d.jsx)(`div`,{className:`alert alert-danger py-2 small mb-3`,children:K}),(0,d.jsxs)(`div`,{className:`mb-3`,children:[(0,d.jsx)(`label`,{className:`fa-label`,children:`Amount to Collect (₦)`}),(0,d.jsx)(`input`,{type:`number`,className:`fa-input`,value:B,onChange:e=>V(e.target.value),placeholder:`Enter amount`,disabled:W})]}),(0,d.jsxs)(`div`,{className:`mb-4`,children:[(0,d.jsx)(`label`,{className:`fa-label`,children:`Payer / Parent Email (for receipt)`}),(0,d.jsx)(`input`,{type:`email`,className:`fa-input`,value:H,onChange:e=>U(e.target.value),placeholder:`parent@example.com`,disabled:W})]}),(0,d.jsx)(`div`,{className:`d-grid`,children:(0,d.jsx)(`button`,{className:`fa-btn-gold justify-content-center py-2 fs-6`,onClick:xe,disabled:W,children:W?(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(`span`,{className:`spinner-border spinner-border-sm me-2`}),` Initializing Paystack...`]}):(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(`i`,{className:`bi bi-credit-card me-2`}),` Make Payment with Paystack`]})})})]})]})})]})}export{h as default};