import{i as e}from"./rolldown-runtime-CWU8vmCm.js";import{Ut as t}from"./vendor-misc-OZLc0tLq.js";import{p as n}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as r,E as i,P as a,d as o,f as ee,l as te,u as ne}from"./index-D6TxbaCx.js";var s=e(t(),1),c=n();function l(e){let t=e?.response?.status,n=e?.response?.data;if(t===409)return n?.message??`This item already exists.`;if(t===422){let e=n?.errors;if(e){let t=e[Object.keys(e)[0]]?.[0];if(t)return t}return n?.message??`Validation error.`}return n?.message??e?.message??`Something went wrong.`}function u(e){return e===!0||e===1||e===`1`}function d(e){if(!e)return`—`;let t=new Date(e);return Number.isNaN(t.getTime())?e:t.toLocaleDateString(void 0,{day:`2-digit`,month:`short`,year:`numeric`})}function re(){let e=new Date().getHours();return e<12?`Good morning`:e<17?`Good afternoon`:`Good evening`}var ie=(e,t,n)=>Math.max(t,Math.min(n,e));function ae(){let{showSuccess:e,showError:t}=te(),[n,ae]=(0,s.useState)(!1),[f,p]=(0,s.useState)(`sessions`),[m,oe]=(0,s.useState)(!1),[h,g]=(0,s.useState)(``),[_,v]=(0,s.useState)(null),[y,se]=(0,s.useState)([]),[b,ce]=(0,s.useState)([]),[le,x]=(0,s.useState)(!0),[S,C]=(0,s.useState)(!0),[w,T]=(0,s.useState)(!0),[ue,E]=(0,s.useState)(!1),[de,D]=(0,s.useState)(!1),[fe,O]=(0,s.useState)(!1),[pe,k]=(0,s.useState)(!1),[me,he]=(0,s.useState)(``),[A,ge]=(0,s.useState)(``),[j,_e]=(0,s.useState)(``),[M,N]=(0,s.useState)(null),[P,F]=(0,s.useState)(``),[I,L]=(0,s.useState)(``),[R,z]=(0,s.useState)(``),[B,V]=(0,s.useState)({name:``,start_date:``,end_date:``}),[H,ve]=(0,s.useState)(null),[U,W]=(0,s.useState)({name:``,start_date:``,end_date:``,status:`Active`}),G=e=>_===e;async function K(){try{C(!0),se((await a.get(`/terms`,{params:m?{archived:1}:void 0})).data??[])}catch(e){t(l(e))}finally{C(!1)}}async function q(){try{T(!0),ce((await a.get(`/sessions`,{params:m?{archived:1}:void 0})).data??[])}catch(e){t(l(e))}finally{T(!1)}}(0,s.useEffect)(()=>{x(!0),Promise.all([q(),K()]).finally(()=>x(!1))},[m]),(0,s.useEffect)(()=>{g(``)},[f,m]);let J=(0,s.useMemo)(()=>y.find(e=>(e.status??``).toLowerCase()===`active`),[y]),ye=(0,s.useMemo)(()=>b.find(e=>u(e.is_current)),[b]),be=(0,s.useMemo)(()=>{let e=h.trim().toLowerCase();return e?y.filter(t=>(t.name??``).toLowerCase().includes(e)):y},[y,h]),xe=(0,s.useMemo)(()=>{let e=h.trim().toLowerCase();return e?b.filter(t=>`${t.name??``} ${t.start_date??``} ${t.end_date??``}`.toLowerCase().includes(e)):b},[b,h]),Se=b.length,Ce=y.length;(0,s.useMemo)(()=>y.filter(e=>(e.status??``).toLowerCase()===`active`).length,[y]);let we=(0,s.useMemo)(()=>b.filter(e=>u(e.is_current)).length,[b]),[Te,Y]=(0,s.useState)(1);(0,s.useEffect)(()=>Y(1),[h,f,y.length,b.length]);let X=f===`sessions`?xe:be,Z=(0,s.useMemo)(()=>Math.max(1,Math.ceil(X.length/10)),[X.length]),Q=ie(Te,1,Z),$=(0,s.useMemo)(()=>{let e=(Q-1)*10;return X.slice(e,e+10)},[X,Q]);async function Ee(){let n=me.trim();if(!n)return t(`Please enter a term name.`);if(A&&j&&j<A)return t(`Term end date cannot be before start date.`);try{v(`term:create`),e((await a.post(`/terms`,{name:n,start_date:A||null,end_date:j||null})).data?.message??`Term created.`),he(``),ge(``),_e(``),E(!1),await K()}catch(e){t(l(e))}finally{v(null)}}function De(e){N(e.id),F(e.name??``),L(e.start_date??``),z(e.end_date??``),D(!0)}async function Oe(){if(!M)return;let n=P.trim();if(!n)return t(`Please enter a term name.`);if(I&&R&&R<I)return t(`Term end date cannot be before start date.`);try{v(`term:update:${M}`),e((await a.put(`/terms/${M}`,{name:n,start_date:I||null,end_date:R||null})).data?.message??`Term updated.`),D(!1),N(null),F(``),L(``),z(``),await K()}catch(e){t(l(e))}finally{v(null)}}async function ke(n){try{v(`term:setactive:${n}`),e((await a.put(`/terms/${n}/status`)).data?.message??`Term set as active.`),await K()}catch(e){t(l(e))}finally{v(null)}}async function Ae(n){if(window.confirm(`Archive "${n.name}"?\n\nArchived terms will be hidden from future result entry, but old student results will remain safe.`))try{v(`term:archive:${n.id}`),e((await a.delete(`/terms/${n.id}`)).data?.message??`Term archived.`),await K()}catch(e){t(l(e))}finally{v(null)}}async function je(n){try{v(`term:restore:${n.id}`),e((await a.post(`/terms/${n.id}/restore`)).data?.message??`Term restored.`),await K()}catch(e){t(l(e))}finally{v(null)}}async function Me(){let n=B.name.trim();if(!n)return t(`Please enter a session name.`);if(!B.start_date)return t(`Please select a start date.`);if(!B.end_date)return t(`Please select an end date.`);try{v(`session:create`),e((await a.post(`/sessions`,{name:n,start_date:B.start_date,end_date:B.end_date})).data?.message??`Session created.`),V({name:``,start_date:``,end_date:``}),O(!1),await q()}catch(e){t(l(e))}finally{v(null)}}function Ne(e){ve(e.id),W({name:e.name??``,start_date:e.start_date??``,end_date:e.end_date??``,status:e.status??`Active`}),k(!0)}async function Pe(){if(!H)return;let n=U.name.trim();if(!n)return t(`Please enter a session name.`);if(!U.start_date)return t(`Please select a start date.`);if(!U.end_date)return t(`Please select an end date.`);try{v(`session:update:${H}`),e((await a.put(`/sessions/${H}`,{name:n,start_date:U.start_date,end_date:U.end_date,status:U.status})).data?.message??`Session updated.`),k(!1),ve(null),await q()}catch(e){t(l(e))}finally{v(null)}}async function Fe(n){try{v(`session:current:${n}`),e((await a.post(`/sessions/set-current/${n}`)).data?.message??`Current session updated.`),await q()}catch(e){t(l(e))}finally{v(null)}}async function Ie(n){if(window.confirm(`Archive "${n.name}"?\n\nArchived sessions will be hidden from future result entry, but old student results will remain safe.`))try{v(`session:archive:${n.id}`),e((await a.delete(`/sessions/${n.id}`)).data?.message??`Academic session archived.`),await q()}catch(e){t(l(e))}finally{v(null)}}async function Le(n){try{v(`session:restore:${n.id}`),e((await a.post(`/sessions/${n.id}/restore`)).data?.message??`Academic session restored.`),await q()}catch(e){t(l(e))}finally{v(null)}}let Re=[{color:`#b45309`,bg:`#fef3c7`,label:`Sessions total`},{color:`#065f46`,bg:`#d1fae5`,label:`Terms total`},{color:`#1e40af`,bg:`#dbeafe`,label:`Current session`},{color:`#7c3aed`,bg:`#ede9fe`,label:`Active term`}];return(0,c.jsxs)(c.Fragment,{children:[(0,c.jsx)(`style`,{children:`
        /* ======= AcademicCalendarPage - Modern SaaS style ======= */
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');
        .db-main {
          background: #F8FAFC;
          min-height: 100vh;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          padding: 24px 28px 0;
        }

        .db-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 18px;
          padding: 32px 36px;
          position: relative;
          overflow: hidden;
          margin-bottom: 24px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
        }
        .db-hero-glow {
          position: absolute;
          top: -60px;
          right: -60px;
          width: 320px;
          height: 320px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.15) 0%, transparent 65%);
          pointer-events: none;
        }
        .db-hero-glow2 {
          position: absolute;
          bottom: -40px;
          left: 30%;
          width: 200px;
          height: 200px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(37, 99, 235, 0.10) 0%, transparent 70%);
          pointer-events: none;
        }
        .db-hero-inner {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 28px;
          flex-wrap: wrap;
        }

        .db-session-badge {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.20);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius: 100px;
          padding: 4px 12px;
          margin-bottom: 12px;
        }
        .db-session-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #10B981;
          animation: dbPulse 2s ease infinite;
        }
        @keyframes dbPulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.4; transform: scale(1.5); }
        }

        .db-greeting {
          font-size: 26px;
          font-weight: 800;
          color: #fff;
          line-height: 1.1;
          margin-bottom: 8px;
        }
        .db-greeting em { font-style: normal; color: #FBBF24; }

        .db-hero-sub {
          font-size: 13.5px;
          color: #CBD5E1;
          line-height: 1.6;
          max-width: 720px;
          margin-bottom: 20px;
        }

        .db-hero-btns { display:flex; gap:10px; flex-wrap:wrap; }

        .db-btn-gold {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 9px 18px;
          font-size: 13px;
          font-weight: 700;
          color: #FFFFFF;
          background: #D97706;
          border: none;
          border-radius: 10px;
          cursor: pointer;
          transition: all 0.2s ease;
          text-decoration: none;
          white-space: nowrap;
        }
        .db-btn-gold:hover { background: #B45309; transform: translateY(-1px); color: #FFFFFF; }

        .db-btn-outline {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 9px 18px;
          font-size: 13px;
          font-weight: 600;
          color: #FFFFFF;
          background: rgba(255, 255, 255, 0.10);
          border: 1px solid rgba(255, 255, 255, 0.20);
          border-radius: 10px;
          cursor: pointer;
          transition: all 0.2s ease;
          white-space: nowrap;
        }
        .db-btn-outline:hover {
          background: rgba(255, 255, 255, 0.18);
          color: #fff;
        }

        .db-hero-stat-card {
          background: rgba(255, 255, 255, 0.08);
          border: 1px solid rgba(255, 255, 255, 0.15);
          backdrop-filter: blur(8px);
          border-radius: 14px;
          padding: 20px 24px;
          min-width: 240px;
        }
        .db-hero-stat-row { display:flex; flex-direction:column; gap:10px; }
        .db-hero-stat-item { display:flex; justify-content:space-between; align-items:center; gap:16px; }
        .db-hero-stat-label { font-size: 12px; font-weight: 400; color: #CBD5E1; }
        .db-hero-stat-val { font-size: 18px; font-weight: 800; color: #FBBF24; }
        .db-hero-stat-sep { height: 1px; background: rgba(255, 255, 255, 0.08); }

        .db-tabs {
          display:inline-flex;
          gap: 8px;
          padding: 6px;
          border-radius: 14px;
          background: rgba(255,255,255,0.06);
          border: 1px solid rgba(255,255,255,0.10);
        }
        .db-tab {
          display:inline-flex;
          align-items:center;
          gap: 8px;
          padding: 8px 12px;
          border-radius: 12px;
          cursor:pointer;
          font-size: 13px;
          font-weight: 700;
          border: 1px solid transparent;
          color: rgba(255,255,255,0.78);
          background: transparent;
          transition: background .2s, border-color .2s, color .2s;
          white-space: nowrap;
        }
        .db-tab:hover { background: rgba(255,255,255,0.06); color: #fff; }
        .db-tab-active {
          background: rgba(201,168,76,0.12);
          border-color: rgba(201,168,76,0.26);
          color: #e8c97a;
        }

        .db-stats {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 16px;
          margin-bottom: 18px;
        }
        @media (max-width: 1199.98px) { .db-stats { grid-template-columns: repeat(2, 1fr);} }
        @media (max-width: 575.98px) { .db-stats { grid-template-columns: 1fr; } }

        .db-stat {
          background: #fff;
          border: 1px solid #ede8e0;
          border-radius: 14px;
          padding: 22px 20px;
          position: relative;
          overflow: hidden;
          cursor: default;
          transition: box-shadow 0.25s, transform 0.25s;
        }
        .db-stat:hover { box-shadow: 0 8px 28px rgba(0,0,0,0.08); transform: translateY(-3px); }
        .db-stat::before {
          content: "";
          position: absolute;
          top: 0; left: 0; right: 0;
          height: 3px;
          background: var(--sc, #b45309);
          transform: scaleX(0);
          transform-origin: left;
          transition: transform 0.3s ease;
        }
        .db-stat:hover::before { transform: scaleX(1); }

        .db-stat-head { display:flex; align-items:flex-start; justify-content:space-between; margin-bottom: 14px; }
        .db-stat-icon {
          width: 42px; height: 42px;
          border-radius: 10px;
          background: var(--si, #fef3c7);
          color: var(--sc, #b45309);
          display:flex; align-items:center; justify-content:center;
          transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
        }
        .db-stat:hover .db-stat-icon { transform: scale(1.1) rotate(-4deg); }
        .db-stat-more { color: #c8bfb5; padding: 2px; }
        .db-stat-label { font-size: 12px; font-weight: 500; color: #9a8a7a; margin-bottom: 6px; letter-spacing: .03em; }
        .db-stat-val { font-family: "Lora", Georgia, serif; font-size: 28px; font-weight: 700; color: #1a1a2e; line-height: 1; }
        .db-stat-footer {
          display:flex; align-items:center; gap:6px;
          margin-top: 12px; padding-top: 10px;
          border-top: 1px solid rgba(0,0,0,0.06);
          font-size: 12px; color: #9a8a7a;
        }
        .db-stat-trend { color:#22c55e; font-weight:600; }

        .db-panel {
          background: #fff;
          border: 1px solid #ede8e0;
          border-radius: 14px;
          overflow: hidden;
          margin-bottom: 24px;
        }
        .db-panel-head {
          display:flex;
          align-items:center;
          justify-content: space-between;
          padding: 18px 20px 16px;
          border-bottom: 1px solid rgba(0,0,0,0.06);
          gap: 12px;
          flex-wrap: wrap;
        }
        .db-panel-title {
          font-family: "Lora", serif;
          font-size: 16px;
          font-weight: 700;
          color: #1a1a2e;
          margin: 0;
        }
        .db-panel-sub {
          font-size: 11.5px;
          font-weight: 300;
          color: #9a8a7a;
          margin: 0;
        }

        .db-toolbar { display:flex; align-items:center; gap: 10px; flex-wrap: wrap; }
        .db-input {
          display:flex;
          align-items:center;
          gap: 8px;
          padding: 10px 12px;
          background: #faf8f5;
          border: 1px solid #e5ddd3;
          border-radius: 12px;
          min-width: 280px;
        }
        .db-input input {
          border: none;
          outline: none;
          background: transparent;
          width: 100%;
          font-size: 13.5px;
          color: #1a1a2e;
        }
        .db-chip-btn {
          display:inline-flex;
          align-items:center;
          gap: 6px;
          padding: 8px 12px;
          font-size: 12.5px;
          font-weight: 700;
          color: #7a6a5a;
          background: #f5f1eb;
          border: 1px solid #e5ddd3;
          border-radius: 10px;
          cursor: pointer;
          transition: background .2s, color .2s, transform .2s;
          white-space: nowrap;
        }
        .db-chip-btn:hover:not(:disabled) { background:#ede8e0; color:#1a1a2e; transform: translateY(-1px); }
        .db-chip-btn:disabled { opacity: .5; cursor: not-allowed; }

        .db-table { width: 100%; border-collapse: collapse; }
        .db-table th {
          padding: 10px 16px;
          font-size: 11px;
          font-weight: 600;
          letter-spacing: 0.10em;
          text-transform: uppercase;
          color: #9a8a7a;
          background: #faf8f5;
          border-bottom: 1px solid rgba(0,0,0,0.06);
          text-align: left;
          white-space: nowrap;
        }
        .db-table th:last-child { text-align: right; }
        .db-table td {
          padding: 13px 16px;
          font-size: 13.5px;
          color: #4a4a5a;
          border-bottom: 1px solid rgba(0,0,0,0.06);
          vertical-align: middle;
        }
        .db-table tbody tr { transition: background 0.15s; }
        .db-table tbody tr:hover { background: #faf8f5; }
        .db-table tbody tr:last-child td { border-bottom: none; }

        .db-pill {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          font-size: 12px;
          font-weight: 800;
          padding: 4px 10px;
          border-radius: 999px;
          background: #f0ebe3;
          color: #7a6a5a;
          white-space: nowrap;
        }

        .db-actions { display:inline-flex; justify-content:flex-end; gap: 8px; flex-wrap: wrap; }
        .db-action-btn {
          display:inline-flex;
          align-items:center;
          gap: 6px;
          padding: 7px 12px;
          font-size: 12.5px;
          font-weight: 800;
          border-radius: 10px;
          cursor: pointer;
          border: 1px solid rgba(0,0,0,0.10);
          background: #fff;
          transition: transform .2s, box-shadow .2s, background .2s;
          white-space: nowrap;
        }
        .db-action-btn:hover:not(:disabled) { transform: translateY(-1px); box-shadow: 0 8px 18px rgba(0,0,0,0.08); background: #faf8f5; }
        .db-action-btn:disabled { opacity: .5; cursor: not-allowed; }

        .db-action-primary { border-color: rgba(30, 64, 175, 0.25); color: #1e40af; }
        .db-action-gold    { border-color: rgba(180, 83, 9, 0.25); color: #b45309; }
        .db-action-green   { border-color: rgba(6, 95, 70, 0.25); color: #065f46; }
        .db-action-danger  { border-color: rgba(185, 28, 28, 0.25); color: #b91c1c; }

        .db-pagination {
          display:flex;
          align-items:center;
          justify-content: space-between;
          padding: 14px 16px;
          border-top: 1px solid rgba(0,0,0,0.06);
          flex-wrap: wrap;
          gap: 10px;
        }
        .db-page-info { font-size: 12px; color:#9a8a7a; }
        .db-page-btns { display:flex; align-items:center; gap: 8px; }
        .db-page-btn {
          display:inline-flex;
          align-items:center;
          gap: 6px;
          padding: 7px 12px;
          font-size: 12.5px;
          font-weight: 800;
          color: #7a6a5a;
          background: #f5f1eb;
          border: 1px solid #e5ddd3;
          border-radius: 10px;
          cursor: pointer;
          transition: background .2s, transform .2s, color .2s;
        }
        .db-page-btn:hover:not(:disabled) { background:#ede8e0; color:#1a1a2e; transform: translateY(-1px); }
        .db-page-btn:disabled { opacity: .45; cursor:not-allowed; }
        .db-page-current { font-size: 12px; color:#9a8a7a; }

        /* Modals */
        .db-modal-backdrop {
          position: fixed;
          inset: 0;
          background: rgba(0,0,0,0.55);
          backdrop-filter: blur(7px);
          z-index: 1400;
          display:flex;
          align-items:center;
          justify-content:center;
          padding: 12px;
        }
        .db-modal {
          width: min(920px, 96vw);
          max-height: 92vh;
          border-radius: 18px;
          overflow: hidden;
          background: #fff;
          box-shadow: 0 24px 70px rgba(0,0,0,0.35);
          border: 1px solid rgba(255,255,255,0.12);
        }
        .db-modal-head {
          padding: 18px 20px;
          background: linear-gradient(135deg, #0f172a 0%, #1f2937 100%);
          color: #fff;
          position: relative;
          overflow: hidden;
        }
        .db-modal-head::before {
          content:"";
          position:absolute;
          inset:0;
          background-image: radial-gradient(circle, rgba(255,255,255,0.045) 1px, transparent 1px);
          background-size: 24px 24px;
          pointer-events:none;
        }
        .db-modal-head-inner {
          position: relative;
          z-index: 1;
          display:flex;
          align-items:flex-start;
          justify-content: space-between;
          gap: 12px;
        }
        .db-modal-title {
          margin:0;
          font-family: "Lora", Georgia, serif;
          font-size: 16px;
          font-weight: 800;
        }
        .db-modal-sub {
          margin: 2px 0 0;
          color: rgba(255,255,255,0.72);
          font-size: 12.5px;
          font-weight: 300;
        }
        .db-modal-close {
          width: 36px;
          height: 36px;
          border-radius: 10px;
          border: 1px solid rgba(255,255,255,0.18);
          background: rgba(255,255,255,0.06);
          color: #fff;
          cursor: pointer;
          display:flex;
          align-items:center;
          justify-content:center;
          transition: background .2s, border-color .2s, transform .2s;
          flex-shrink: 0;
        }
        .db-modal-close:hover:not(:disabled) { background: rgba(255,255,255,0.10); border-color: rgba(255,255,255,0.26); transform: translateY(-1px); }
        .db-modal-close:disabled { opacity: .5; cursor:not-allowed; }

        .db-modal-body { background:#f5f1eb; padding: 16px; overflow:auto; max-height: calc(92vh - 130px); }
        .db-modal-card { background:#fff; border: 1px solid #ede8e0; border-radius: 16px; padding: 16px; }

        .db-form-grid { display:grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        @media (max-width: 767.98px) { .db-form-grid { grid-template-columns: 1fr; } }

        .db-field label {
          display:block;
          font-size: 12px;
          font-weight: 900;
          color: #7a6a5a;
          margin-bottom: 6px;
          letter-spacing: .02em;
        }
        .db-field input, .db-field select {
          width: 100%;
          padding: 10px 12px;
          border-radius: 12px;
          border: 1px solid #e5ddd3;
          background: #faf8f5;
          outline: none;
          font-size: 13.5px;
          color: #1a1a2e;
        }
        .db-field input:focus, .db-field select:focus {
          border-color: rgba(201,168,76,0.55);
          box-shadow: 0 0 0 4px rgba(201,168,76,0.18);
          background: #fff;
        }
        .db-help { margin-top: 6px; font-size: 11.5px; color: #9a8a7a; }

        .db-modal-foot {
          padding: 14px 16px;
          background: #fff;
          border-top: 1px solid rgba(0,0,0,0.06);
          display:flex;
          justify-content: flex-end;
          gap: 10px;
          flex-wrap: wrap;
        }

        .db-btn {
          display:inline-flex;
          align-items:center;
          gap: 7px;
          padding: 10px 14px;
          border-radius: 12px;
          font-size: 13px;
          font-weight: 900;
          cursor: pointer;
          border: 1px solid transparent;
          transition: transform .2s, box-shadow .2s, background .2s, border-color .2s;
          white-space: nowrap;
        }
        .db-btn:hover:not(:disabled) { transform: translateY(-1px); box-shadow: 0 10px 22px rgba(0,0,0,0.10); }
        .db-btn:disabled { opacity: .55; cursor:not-allowed; box-shadow:none; transform:none; }

        .db-btn-secondary { background: #f5f1eb; border-color: #e5ddd3; color: #7a6a5a; }
        .db-btn-secondary:hover:not(:disabled) { background: #ede8e0; color:#1a1a2e; }

        .db-btn-primary { background: #c9a84c; color: #0f172a; border-color: rgba(201,168,76,0.35); }
        .db-btn-primary:hover:not(:disabled) { background:#e8c97a; }

        .db-btn-green { background: #10b981; color: #062a22; border-color: rgba(16,185,129,0.35); }
        .db-btn-green:hover:not(:disabled) { background: #34d399; }

        @keyframes dbSpin { to { transform: rotate(360deg); } }
      `}),(0,c.jsx)(ee,{sidebarOpen:n,setSidebarOpen:ae}),(0,c.jsx)(r,{title:`Calendar`}),(0,c.jsx)(`div`,{className:`container-fluid`,children:(0,c.jsxs)(`div`,{className:`row`,children:[(0,c.jsx)(o,{sidebarOpen:n}),(0,c.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto db-main`,children:[le&&(0,c.jsx)(i,{message:`Loading academic calendar...`}),(0,c.jsxs)(`div`,{className:`db-hero`,children:[(0,c.jsx)(`div`,{className:`db-hero-glow`,"aria-hidden":`true`}),(0,c.jsx)(`div`,{className:`db-hero-glow2`,"aria-hidden":`true`}),(0,c.jsxs)(`div`,{className:`db-hero-inner`,children:[(0,c.jsxs)(`div`,{children:[(0,c.jsxs)(`div`,{className:`db-session-badge`,children:[(0,c.jsx)(`span`,{className:`db-session-dot`}),`Academic Calendar • Settings`]}),(0,c.jsxs)(`h1`,{className:`db-greeting`,children:[re(),`, `,(0,c.jsx)(`em`,{children:`Admin.`})]}),(0,c.jsxs)(`p`,{className:`db-hero-sub`,children:[`Manage `,(0,c.jsx)(`b`,{children:`sessions`}),` and `,(0,c.jsx)(`b`,{children:`terms`}),` in one place. Set current session and active term for results, attendance and promotions.`]}),(0,c.jsxs)(`div`,{style:{display:`flex`,gap:10,flexWrap:`wrap`,alignItems:`center`},children:[(0,c.jsxs)(`div`,{className:`db-tabs`,children:[(0,c.jsxs)(`button`,{className:`db-tab ${f===`sessions`?`db-tab-active`:``}`,onClick:()=>p(`sessions`),type:`button`,children:[(0,c.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,c.jsx)(`path`,{d:`M3.5 2.5v2M12.5 2.5v2`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`}),(0,c.jsx)(`path`,{d:`M3 6h10`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`}),(0,c.jsx)(`rect`,{x:`3`,y:`4.5`,width:`10`,height:`9`,rx:`2`,stroke:`currentColor`,strokeWidth:`1.5`})]}),`Sessions`]}),(0,c.jsxs)(`button`,{className:`db-tab ${f===`terms`?`db-tab-active`:``}`,onClick:()=>p(`terms`),type:`button`,children:[(0,c.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,c.jsx)(`path`,{d:`M4 5h8M4 8h8M4 11h8`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`}),(0,c.jsx)(`rect`,{x:`3`,y:`3.5`,width:`10`,height:`10`,rx:`2`,stroke:`currentColor`,strokeWidth:`1.5`})]}),`Terms`]})]}),(0,c.jsxs)(`span`,{className:`db-pill`,style:{background:`rgba(201,168,76,0.12)`,color:`#e8c97a`},children:[(0,c.jsxs)(`svg`,{width:`12`,height:`12`,viewBox:`0 0 12 12`,fill:`none`,children:[(0,c.jsx)(`path`,{d:`M6 2v4l2.5 1.5`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,c.jsx)(`circle`,{cx:`6`,cy:`6`,r:`4`,stroke:`currentColor`,strokeWidth:`1.2`})]}),ye?.name??`No current session`,` • `,J?.name??`No active term`]})]}),(0,c.jsx)(`div`,{className:`db-hero-btns`,style:{marginTop:14},children:f===`sessions`?(0,c.jsxs)(c.Fragment,{children:[(0,c.jsxs)(`button`,{className:`db-btn-gold`,onClick:()=>O(!0),disabled:_!==null,type:`button`,children:[(0,c.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:(0,c.jsx)(`path`,{d:`M8 3v10M3 8h10`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})}),`Add Session`]}),(0,c.jsxs)(`button`,{className:`db-btn-outline`,onClick:q,disabled:_!==null||w,type:`button`,children:[(0,c.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,style:{animation:w?`dbSpin 0.8s linear infinite`:`none`},children:[(0,c.jsx)(`path`,{d:`M12 7A5 5 0 112 7`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,c.jsx)(`path`,{d:`M12 3v4h-4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),`Refresh`]})]}):(0,c.jsxs)(c.Fragment,{children:[(0,c.jsxs)(`button`,{className:`db-btn-gold`,onClick:()=>E(!0),disabled:_!==null,type:`button`,children:[(0,c.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:(0,c.jsx)(`path`,{d:`M8 3v10M3 8h10`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})}),`Add Term`]}),(0,c.jsxs)(`button`,{className:`db-btn-outline`,onClick:K,disabled:_!==null||S,type:`button`,children:[(0,c.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,style:{animation:S?`dbSpin 0.8s linear infinite`:`none`},children:[(0,c.jsx)(`path`,{d:`M12 7A5 5 0 112 7`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,c.jsx)(`path`,{d:`M12 3v4h-4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),`Refresh`]})]})})]}),(0,c.jsxs)(`div`,{className:`db-hero-stat-card d-none d-md-block`,children:[(0,c.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,marginBottom:16},children:[(0,c.jsx)(`span`,{style:{fontSize:11,fontWeight:600,letterSpacing:`0.14em`,textTransform:`uppercase`,color:`#c9a84c`},children:`Quick summary`}),(0,c.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:(0,c.jsx)(`path`,{d:`M2 10V6M5 10V4M8 10V7M11 10V3`,stroke:`#64748b`,strokeWidth:`1.5`,strokeLinecap:`round`})})]}),(0,c.jsxs)(`div`,{className:`db-hero-stat-row`,children:[(0,c.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,c.jsx)(`span`,{className:`db-hero-stat-label`,children:`Sessions`}),(0,c.jsx)(`span`,{className:`db-hero-stat-val`,children:Se})]}),(0,c.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,c.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,c.jsx)(`span`,{className:`db-hero-stat-label`,children:`Terms`}),(0,c.jsx)(`span`,{className:`db-hero-stat-val`,children:Ce})]}),(0,c.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,c.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,c.jsx)(`span`,{className:`db-hero-stat-label`,children:`Current set`}),(0,c.jsx)(`span`,{className:`db-hero-stat-val`,children:we?`Yes`:`No`})]})]}),(0,c.jsx)(`div`,{style:{marginTop:14,paddingTop:12,borderTop:`1px solid rgba(255,255,255,0.06)`},children:(0,c.jsxs)(`div`,{style:{fontSize:12,color:`#64748b`},children:[`Active term:`,` `,(0,c.jsx)(`span`,{style:{color:`#fff`,fontWeight:700},children:J?.name??`Not set`})]})})]})]})]}),(0,c.jsx)(`div`,{className:`db-stats`,children:[{title:`Total Sessions`,value:Se,hint:`All sessions`},{title:`Total Terms`,value:Ce,hint:`All terms`},{title:`Current Session`,value:ye?.name??`-`,hint:`In use`},{title:`Active Term`,value:J?.name??`-`,hint:`In use`}].map((e,t)=>{let n=Re[t],r=[(0,c.jsxs)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 20 20`,fill:`none`,children:[(0,c.jsx)(`path`,{d:`M6 3v2M14 3v2`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`}),(0,c.jsx)(`rect`,{x:`4`,y:`5`,width:`12`,height:`12`,rx:`2`,stroke:`currentColor`,strokeWidth:`1.5`}),(0,c.jsx)(`path`,{d:`M4 8h12`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`})]},`i1`),(0,c.jsxs)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 20 20`,fill:`none`,children:[(0,c.jsx)(`path`,{d:`M6 6h8M6 10h8M6 14h8`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`}),(0,c.jsx)(`rect`,{x:`4`,y:`4`,width:`12`,height:`12`,rx:`2`,stroke:`currentColor`,strokeWidth:`1.5`})]},`i2`),(0,c.jsxs)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 20 20`,fill:`none`,children:[(0,c.jsx)(`circle`,{cx:`10`,cy:`10`,r:`7`,stroke:`currentColor`,strokeWidth:`1.5`}),(0,c.jsx)(`path`,{d:`M10 6v4l3 2`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`,strokeLinejoin:`round`})]},`i3`),(0,c.jsxs)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 20 20`,fill:`none`,children:[(0,c.jsx)(`path`,{d:`M6 10h8`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`}),(0,c.jsx)(`path`,{d:`M10 6v8`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`}),(0,c.jsx)(`rect`,{x:`4`,y:`4`,width:`12`,height:`12`,rx:`2`,stroke:`currentColor`,strokeWidth:`1.5`})]},`i4`)];return(0,c.jsxs)(`div`,{className:`db-stat`,style:{"--sc":n.color,"--si":n.bg},children:[(0,c.jsxs)(`div`,{className:`db-stat-head`,children:[(0,c.jsx)(`div`,{className:`db-stat-icon`,children:r[t]}),(0,c.jsxs)(`svg`,{className:`db-stat-more`,width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,c.jsx)(`circle`,{cx:`4`,cy:`8`,r:`1.2`,fill:`currentColor`}),(0,c.jsx)(`circle`,{cx:`8`,cy:`8`,r:`1.2`,fill:`currentColor`}),(0,c.jsx)(`circle`,{cx:`12`,cy:`8`,r:`1.2`,fill:`currentColor`})]})]}),(0,c.jsx)(`p`,{className:`db-stat-label`,children:e.title}),(0,c.jsx)(`div`,{className:`db-stat-val`,title:typeof e.value==`string`?e.value:void 0,children:e.value}),(0,c.jsxs)(`div`,{className:`db-stat-footer`,children:[(0,c.jsx)(`svg`,{width:`12`,height:`12`,viewBox:`0 0 12 12`,fill:`none`,children:(0,c.jsx)(`path`,{d:`M2 9l3-4 2 2 3-5`,stroke:`#22c55e`,strokeWidth:`1.4`,strokeLinecap:`round`,strokeLinejoin:`round`})}),(0,c.jsx)(`span`,{className:`db-stat-trend`,children:`OK`}),(0,c.jsx)(`span`,{style:{color:`#9a8a7a`},children:e.hint})]})]},e.title)})}),(0,c.jsxs)(`div`,{className:`db-panel`,children:[(0,c.jsxs)(`div`,{className:`db-panel-head`,children:[(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`p`,{className:`db-panel-title`,children:f===`sessions`?`Sessions management`:`Terms management`}),(0,c.jsx)(`p`,{className:`db-panel-sub`,children:f===`sessions`?`Create, edit and set current session.`:`Create, edit and set active term.`})]}),(0,c.jsxs)(`div`,{className:`db-toolbar`,children:[(0,c.jsxs)(`div`,{className:`db-input`,title:`Search`,children:[(0,c.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,style:{flexShrink:0},children:[(0,c.jsx)(`circle`,{cx:`7`,cy:`7`,r:`4.5`,stroke:`#9a8a7a`,strokeWidth:`1.4`}),(0,c.jsx)(`path`,{d:`M11 11l3 3`,stroke:`#9a8a7a`,strokeWidth:`1.4`,strokeLinecap:`round`})]}),(0,c.jsx)(`input`,{placeholder:f===`sessions`?`Search sessions…`:`Search terms…`,value:h,onChange:e=>g(e.target.value)}),h.trim()?(0,c.jsx)(`button`,{className:`db-chip-btn`,style:{padding:`6px 10px`,borderRadius:10},onClick:()=>g(``),type:`button`,children:`Clear`}):null]}),(0,c.jsx)(`button`,{className:`db-chip-btn`,onClick:()=>oe(e=>!e),disabled:_!==null,type:`button`,children:m?`Show Active`:`View Archived`}),f===`sessions`?(0,c.jsxs)(c.Fragment,{children:[(0,c.jsx)(`button`,{className:`db-chip-btn`,onClick:q,disabled:w||_!==null,type:`button`,children:`Refresh`}),m?null:(0,c.jsx)(`button`,{className:`db-chip-btn`,onClick:()=>O(!0),disabled:_!==null,type:`button`,children:`Add Session`})]}):(0,c.jsxs)(c.Fragment,{children:[(0,c.jsx)(`button`,{className:`db-chip-btn`,onClick:K,disabled:S||_!==null,type:`button`,children:`Refresh`}),m?null:(0,c.jsx)(`button`,{className:`db-chip-btn`,onClick:()=>E(!0),disabled:_!==null,type:`button`,children:`Add Term`})]})]})]}),(0,c.jsx)(`div`,{style:{overflowX:`auto`},children:(0,c.jsxs)(`table`,{className:`db-table`,children:[(0,c.jsx)(`thead`,{children:f===`sessions`?(0,c.jsxs)(`tr`,{children:[(0,c.jsx)(`th`,{style:{width:70},children:`#`}),(0,c.jsx)(`th`,{children:`Session`}),(0,c.jsx)(`th`,{style:{width:170},children:`Start`}),(0,c.jsx)(`th`,{style:{width:170},children:`End`}),(0,c.jsx)(`th`,{style:{width:140},children:`Current`}),(0,c.jsx)(`th`,{style:{width:260,textAlign:`right`},children:`Actions`})]}):(0,c.jsxs)(`tr`,{children:[(0,c.jsx)(`th`,{style:{width:70},children:`#`}),(0,c.jsx)(`th`,{children:`Term`}),(0,c.jsx)(`th`,{style:{width:150},children:`Start`}),(0,c.jsx)(`th`,{style:{width:150},children:`End`}),(0,c.jsx)(`th`,{style:{width:140},children:`Status`}),(0,c.jsx)(`th`,{style:{width:260,textAlign:`right`},children:`Actions`})]})}),(0,c.jsx)(`tbody`,{children:f===`sessions`?w?(0,c.jsx)(`tr`,{children:(0,c.jsxs)(`td`,{colSpan:6,style:{padding:28,textAlign:`center`,color:`#9a8a7a`},children:[(0,c.jsx)(`span`,{className:`spinner-border spinner-border-sm`}),` `,(0,c.jsx)(`span`,{style:{marginLeft:8},children:`Loading sessions…`})]})}):$.length===0?(0,c.jsx)(`tr`,{children:(0,c.jsxs)(`td`,{colSpan:6,style:{padding:34,textAlign:`center`,color:`#9a8a7a`},children:[(0,c.jsx)(`div`,{style:{fontWeight:900,color:`#1a1a2e`},children:`No sessions found`}),(0,c.jsx)(`div`,{style:{marginTop:6},children:`Click “Add session” to create one.`})]})}):$.map((e,t)=>{let n=u(e.is_current),r=G(`session:current:${e.id}`),i=G(`session:update:${e.id}`),a=G(`session:archive:${e.id}`),o=G(`session:restore:${e.id}`);return(0,c.jsxs)(`tr`,{children:[(0,c.jsx)(`td`,{children:(Q-1)*10+t+1}),(0,c.jsxs)(`td`,{children:[(0,c.jsx)(`div`,{style:{fontWeight:800,color:`#1a1a2e`},children:e.name}),(0,c.jsxs)(`div`,{style:{fontSize:12,color:`#9a8a7a`},children:[`ID: `,e.id]})]}),(0,c.jsx)(`td`,{children:d(e.start_date)}),(0,c.jsx)(`td`,{children:d(e.end_date)}),(0,c.jsx)(`td`,{children:(0,c.jsx)(`span`,{className:`db-pill`,style:{background:n?`rgba(16,185,129,0.16)`:`#f0ebe3`,color:n?`#065f46`:`#7a6a5a`},children:n?`Current`:`—`})}),(0,c.jsx)(`td`,{style:{textAlign:`right`},children:(0,c.jsxs)(`div`,{className:`db-actions`,children:[(0,c.jsx)(`button`,{className:`db-action-btn db-action-primary`,onClick:()=>Ne(e),disabled:m||_!==null,type:`button`,children:`Edit`}),(0,c.jsx)(`button`,{className:`db-action-btn db-action-green`,onClick:()=>Fe(e.id),disabled:m||n||_!==null,type:`button`,title:n?`Already current`:`Set as current`,children:r?(0,c.jsxs)(c.Fragment,{children:[(0,c.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,style:{animation:`dbSpin .9s linear infinite`},children:[(0,c.jsx)(`path`,{d:`M12 7A5 5 0 112 7`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,c.jsx)(`path`,{d:`M12 3v4h-4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),`Setting…`]}):`Set Current`}),(0,c.jsx)(`button`,{className:`db-action-btn db-action-danger`,onClick:()=>m?Le(e):Ie(e),disabled:_!==null,type:`button`,title:m?`Restore session`:`Archive session`,children:m?o?`Restoring...`:`Restore`:a?`Archiving...`:`Archive`}),i?(0,c.jsx)(`span`,{className:`db-pill`,children:`Saving…`}):null]})})]},e.id)}):S?(0,c.jsx)(`tr`,{children:(0,c.jsxs)(`td`,{colSpan:6,style:{padding:28,textAlign:`center`,color:`#9a8a7a`},children:[(0,c.jsx)(`span`,{className:`spinner-border spinner-border-sm`}),` `,(0,c.jsx)(`span`,{style:{marginLeft:8},children:`Loading terms…`})]})}):$.length===0?(0,c.jsx)(`tr`,{children:(0,c.jsxs)(`td`,{colSpan:6,style:{padding:34,textAlign:`center`,color:`#9a8a7a`},children:[(0,c.jsx)(`div`,{style:{fontWeight:900,color:`#1a1a2e`},children:`No terms found`}),(0,c.jsx)(`div`,{style:{marginTop:6},children:`Click “Add term” to create one.`})]})}):$.map((e,t)=>{let n=(e.status??``).toLowerCase()===`active`,r=G(`term:setactive:${e.id}`),i=G(`term:update:${e.id}`),a=G(`term:archive:${e.id}`),o=G(`term:restore:${e.id}`);return(0,c.jsxs)(`tr`,{children:[(0,c.jsx)(`td`,{children:(Q-1)*10+t+1}),(0,c.jsxs)(`td`,{children:[(0,c.jsx)(`div`,{style:{fontWeight:800,color:`#1a1a2e`},children:e.name}),(0,c.jsxs)(`div`,{style:{fontSize:12,color:`#9a8a7a`},children:[`ID: `,e.id]})]}),(0,c.jsx)(`td`,{children:d(e.start_date??void 0)}),(0,c.jsx)(`td`,{children:d(e.end_date??void 0)}),(0,c.jsx)(`td`,{children:(0,c.jsx)(`span`,{className:`db-pill`,style:{background:n?`rgba(16,185,129,0.16)`:`#f0ebe3`,color:n?`#065f46`:`#7a6a5a`},children:n?`Active`:`Inactive`})}),(0,c.jsx)(`td`,{style:{textAlign:`right`},children:(0,c.jsxs)(`div`,{className:`db-actions`,children:[(0,c.jsx)(`button`,{className:`db-action-btn db-action-primary`,onClick:()=>De(e),disabled:m||_!==null,type:`button`,children:`Edit`}),(0,c.jsx)(`button`,{className:`db-action-btn db-action-green`,onClick:()=>ke(e.id),disabled:m||n||_!==null,type:`button`,title:n?`Already active`:`Set as active`,children:r?(0,c.jsxs)(c.Fragment,{children:[(0,c.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,style:{animation:`dbSpin .9s linear infinite`},children:[(0,c.jsx)(`path`,{d:`M12 7A5 5 0 112 7`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,c.jsx)(`path`,{d:`M12 3v4h-4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),`Setting…`]}):`Set Active`}),(0,c.jsx)(`button`,{className:`db-action-btn db-action-danger`,onClick:()=>m?je(e):Ae(e),disabled:_!==null,type:`button`,title:m?`Restore term`:`Archive term`,children:m?o?`Restoring...`:`Restore`:a?`Archiving...`:`Archive`}),i?(0,c.jsx)(`span`,{className:`db-pill`,children:`Saving…`}):null]})})]},e.id)})})]})}),(0,c.jsxs)(`div`,{className:`db-pagination`,children:[(0,c.jsxs)(`div`,{className:`db-page-info`,children:[`Showing `,(0,c.jsx)(`b`,{children:$.length}),` of `,(0,c.jsx)(`b`,{children:X.length}),` results • Page `,(0,c.jsx)(`b`,{children:Q}),` of `,(0,c.jsx)(`b`,{children:Z})]}),(0,c.jsxs)(`div`,{className:`db-page-btns`,children:[(0,c.jsx)(`button`,{className:`db-page-btn`,onClick:()=>Y(e=>Math.max(1,e-1)),disabled:Q<=1,type:`button`,children:`Prev`}),(0,c.jsxs)(`span`,{className:`db-page-current`,children:[`Page `,Q]}),(0,c.jsx)(`button`,{className:`db-page-btn`,onClick:()=>Y(e=>Math.min(Z,e+1)),disabled:Q>=Z,type:`button`,children:`Next`})]})]})]}),(0,c.jsx)(ne,{}),fe&&(0,c.jsx)(`div`,{className:`db-modal-backdrop`,onMouseDown:()=>_?null:O(!1),children:(0,c.jsxs)(`div`,{className:`db-modal`,onMouseDown:e=>e.stopPropagation(),children:[(0,c.jsx)(`div`,{className:`db-modal-head`,children:(0,c.jsxs)(`div`,{className:`db-modal-head-inner`,children:[(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`h3`,{className:`db-modal-title`,children:`Add Session`}),(0,c.jsx)(`p`,{className:`db-modal-sub`,children:`Create a new academic session (e.g. 2025/2026).`})]}),(0,c.jsx)(`button`,{className:`db-modal-close`,onClick:()=>O(!1),disabled:_!==null,type:`button`,children:`✕`})]})}),(0,c.jsx)(`div`,{className:`db-modal-body`,children:(0,c.jsx)(`div`,{className:`db-modal-card`,children:(0,c.jsxs)(`div`,{className:`db-form-grid`,children:[(0,c.jsxs)(`div`,{className:`db-field`,style:{gridColumn:`1 / -1`},children:[(0,c.jsx)(`label`,{children:`Session name *`}),(0,c.jsx)(`input`,{placeholder:`e.g. 2025/2026`,value:B.name,onChange:e=>V(t=>({...t,name:e.target.value})),disabled:G(`session:create`)})]}),(0,c.jsxs)(`div`,{className:`db-field`,children:[(0,c.jsx)(`label`,{children:`Start date *`}),(0,c.jsx)(`input`,{type:`date`,value:B.start_date,onChange:e=>V(t=>({...t,start_date:e.target.value})),disabled:G(`session:create`)})]}),(0,c.jsxs)(`div`,{className:`db-field`,children:[(0,c.jsx)(`label`,{children:`End date *`}),(0,c.jsx)(`input`,{type:`date`,value:B.end_date,onChange:e=>V(t=>({...t,end_date:e.target.value})),disabled:G(`session:create`)})]}),(0,c.jsxs)(`div`,{className:`db-help`,style:{gridColumn:`1 / -1`},children:[`Tip: Use a consistent format like `,(0,c.jsx)(`b`,{children:`2025/2026`}),`.`]})]})})}),(0,c.jsxs)(`div`,{className:`db-modal-foot`,children:[(0,c.jsx)(`button`,{className:`db-btn db-btn-secondary`,onClick:()=>O(!1),disabled:_!==null,type:`button`,children:`Cancel`}),(0,c.jsx)(`button`,{className:`db-btn db-btn-primary`,onClick:Me,disabled:_!==null,type:`button`,children:G(`session:create`)?(0,c.jsxs)(c.Fragment,{children:[(0,c.jsx)(`span`,{className:`spinner-border spinner-border-sm`,role:`status`,style:{width:14,height:14}}),`Saving…`]}):`Save Session`})]})]})}),pe&&H&&(0,c.jsx)(`div`,{className:`db-modal-backdrop`,onMouseDown:()=>_?null:k(!1),children:(0,c.jsxs)(`div`,{className:`db-modal`,onMouseDown:e=>e.stopPropagation(),children:[(0,c.jsx)(`div`,{className:`db-modal-head`,children:(0,c.jsxs)(`div`,{className:`db-modal-head-inner`,children:[(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`h3`,{className:`db-modal-title`,children:`Edit Session`}),(0,c.jsx)(`p`,{className:`db-modal-sub`,children:`Update session details.`})]}),(0,c.jsx)(`button`,{className:`db-modal-close`,onClick:()=>k(!1),disabled:_!==null,type:`button`,children:`✕`})]})}),(0,c.jsx)(`div`,{className:`db-modal-body`,children:(0,c.jsx)(`div`,{className:`db-modal-card`,children:(0,c.jsxs)(`div`,{className:`db-form-grid`,children:[(0,c.jsxs)(`div`,{className:`db-field`,style:{gridColumn:`1 / -1`},children:[(0,c.jsx)(`label`,{children:`Session name *`}),(0,c.jsx)(`input`,{value:U.name,onChange:e=>W(t=>({...t,name:e.target.value})),disabled:G(`session:update:${H}`)})]}),(0,c.jsxs)(`div`,{className:`db-field`,children:[(0,c.jsx)(`label`,{children:`Start date *`}),(0,c.jsx)(`input`,{type:`date`,value:U.start_date,onChange:e=>W(t=>({...t,start_date:e.target.value})),disabled:G(`session:update:${H}`)})]}),(0,c.jsxs)(`div`,{className:`db-field`,children:[(0,c.jsx)(`label`,{children:`End date *`}),(0,c.jsx)(`input`,{type:`date`,value:U.end_date,onChange:e=>W(t=>({...t,end_date:e.target.value})),disabled:G(`session:update:${H}`)})]}),(0,c.jsxs)(`div`,{className:`db-field`,style:{gridColumn:`1 / -1`},children:[(0,c.jsx)(`label`,{children:`Status`}),(0,c.jsxs)(`select`,{value:U.status,onChange:e=>W(t=>({...t,status:e.target.value})),disabled:G(`session:update:${H}`),children:[(0,c.jsx)(`option`,{value:`Active`,children:`Active`}),(0,c.jsx)(`option`,{value:`Inactive`,children:`Inactive`})]})]})]})})}),(0,c.jsxs)(`div`,{className:`db-modal-foot`,children:[(0,c.jsx)(`button`,{className:`db-btn db-btn-secondary`,onClick:()=>k(!1),disabled:_!==null,type:`button`,children:`Cancel`}),(0,c.jsx)(`button`,{className:`db-btn db-btn-primary`,onClick:Pe,disabled:_!==null,type:`button`,children:G(`session:update:${H}`)?(0,c.jsxs)(c.Fragment,{children:[(0,c.jsx)(`span`,{className:`spinner-border spinner-border-sm`,role:`status`,style:{width:14,height:14}}),`Updating…`]}):`Update Session`})]})]})}),ue&&(0,c.jsx)(`div`,{className:`db-modal-backdrop`,onMouseDown:()=>_?null:E(!1),children:(0,c.jsxs)(`div`,{className:`db-modal`,onMouseDown:e=>e.stopPropagation(),children:[(0,c.jsx)(`div`,{className:`db-modal-head`,children:(0,c.jsxs)(`div`,{className:`db-modal-head-inner`,children:[(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`h3`,{className:`db-modal-title`,children:`Add Term`}),(0,c.jsx)(`p`,{className:`db-modal-sub`,children:`Create a new term for your school.`})]}),(0,c.jsx)(`button`,{className:`db-modal-close`,onClick:()=>E(!1),disabled:_!==null,type:`button`,children:`✕`})]})}),(0,c.jsx)(`div`,{className:`db-modal-body`,children:(0,c.jsx)(`div`,{className:`db-modal-card`,children:(0,c.jsxs)(`div`,{className:`db-form-grid`,children:[(0,c.jsxs)(`div`,{className:`db-field`,style:{gridColumn:`1 / -1`},children:[(0,c.jsx)(`label`,{children:`Term name *`}),(0,c.jsx)(`input`,{placeholder:`e.g. First Term`,value:me,onChange:e=>he(e.target.value),disabled:G(`term:create`)}),(0,c.jsx)(`div`,{className:`db-help`,children:`Tip: Keep naming consistent across sessions.`})]}),(0,c.jsxs)(`div`,{className:`db-field`,children:[(0,c.jsx)(`label`,{children:`Start date`}),(0,c.jsx)(`input`,{type:`date`,value:A,onChange:e=>ge(e.target.value),disabled:G(`term:create`)})]}),(0,c.jsxs)(`div`,{className:`db-field`,children:[(0,c.jsx)(`label`,{children:`End date`}),(0,c.jsx)(`input`,{type:`date`,value:j,onChange:e=>_e(e.target.value),disabled:G(`term:create`)})]})]})})}),(0,c.jsxs)(`div`,{className:`db-modal-foot`,children:[(0,c.jsx)(`button`,{className:`db-btn db-btn-secondary`,onClick:()=>E(!1),disabled:_!==null,type:`button`,children:`Cancel`}),(0,c.jsx)(`button`,{className:`db-btn db-btn-primary`,onClick:Ee,disabled:_!==null,type:`button`,children:G(`term:create`)?(0,c.jsxs)(c.Fragment,{children:[(0,c.jsx)(`span`,{className:`spinner-border spinner-border-sm`,role:`status`,style:{width:14,height:14}}),`Saving…`]}):`Save Term`})]})]})}),de&&M&&(0,c.jsx)(`div`,{className:`db-modal-backdrop`,onMouseDown:()=>_?null:D(!1),children:(0,c.jsxs)(`div`,{className:`db-modal`,onMouseDown:e=>e.stopPropagation(),children:[(0,c.jsx)(`div`,{className:`db-modal-head`,children:(0,c.jsxs)(`div`,{className:`db-modal-head-inner`,children:[(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`h3`,{className:`db-modal-title`,children:`Edit Term`}),(0,c.jsx)(`p`,{className:`db-modal-sub`,children:`Update term name.`})]}),(0,c.jsx)(`button`,{className:`db-modal-close`,onClick:()=>D(!1),disabled:_!==null,type:`button`,children:`✕`})]})}),(0,c.jsx)(`div`,{className:`db-modal-body`,children:(0,c.jsx)(`div`,{className:`db-modal-card`,children:(0,c.jsxs)(`div`,{className:`db-form-grid`,children:[(0,c.jsxs)(`div`,{className:`db-field`,style:{gridColumn:`1 / -1`},children:[(0,c.jsx)(`label`,{children:`Term name *`}),(0,c.jsx)(`input`,{value:P,onChange:e=>F(e.target.value),disabled:G(`term:update:${M}`)})]}),(0,c.jsxs)(`div`,{className:`db-field`,children:[(0,c.jsx)(`label`,{children:`Start date`}),(0,c.jsx)(`input`,{type:`date`,value:I,onChange:e=>L(e.target.value),disabled:G(`term:update:${M}`)})]}),(0,c.jsxs)(`div`,{className:`db-field`,children:[(0,c.jsx)(`label`,{children:`End date`}),(0,c.jsx)(`input`,{type:`date`,value:R,onChange:e=>z(e.target.value),disabled:G(`term:update:${M}`)})]})]})})}),(0,c.jsxs)(`div`,{className:`db-modal-foot`,children:[(0,c.jsx)(`button`,{className:`db-btn db-btn-secondary`,onClick:()=>D(!1),disabled:_!==null,type:`button`,children:`Cancel`}),(0,c.jsx)(`button`,{className:`db-btn db-btn-primary`,onClick:Oe,disabled:_!==null,type:`button`,children:G(`term:update:${M}`)?(0,c.jsxs)(c.Fragment,{children:[(0,c.jsx)(`span`,{className:`spinner-border spinner-border-sm`,role:`status`,style:{width:14,height:14}}),`Updating…`]}):`Update Term`})]})]})})]})]})})]})}export{ae as default};