import{i as e}from"./rolldown-runtime-CWU8vmCm.js";import{Ut as t}from"./vendor-misc-OZLc0tLq.js";import{h as n,p as r}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{E as i,P as a,d as o,f as s,l as c,u as l}from"./index-D6TxbaCx.js";var u=e(t(),1),d=r();function f(){let{showSuccess:e,showError:t}=c(),[r,f]=(0,u.useState)(!1),[p,m]=(0,u.useState)(!0),[h,g]=(0,u.useState)([]),[_,v]=(0,u.useState)({total:0,subscribed:0,unsubscribed:0,recent_30_days:0}),[y,b]=(0,u.useState)(``),[x,S]=(0,u.useState)(`all`),[C,w]=(0,u.useState)(1),[T,E]=(0,u.useState)(1),[D,O]=(0,u.useState)(0),[k,A]=(0,u.useState)(null),[j,M]=(0,u.useState)(null),[N,P]=(0,u.useState)(!1),F=async(e=1,n=y,r=x)=>{m(!0);try{let t=await a.get(`/superadmin/newsletter-subscribers`,{params:{page:e,search:n,status:r,per_page:15}});t.data?.status===`success`&&(g(t.data.data?.data||[]),w(t.data.data?.current_page||1),E(t.data.data?.last_page||1),O(t.data.data?.total||0),t.data.metrics&&v(t.data.metrics))}catch(e){t(e?.response?.data?.message||`Failed to load newsletter subscribers.`)}finally{m(!1)}};(0,u.useEffect)(()=>{F(1,y,x)},[x]);let I=e=>{e.preventDefault(),F(1,y,x)},L=async n=>{A(n.id);try{e((await a.patch(`/superadmin/newsletter-subscribers/${n.id}/toggle-status`)).data?.message||`Subscriber status updated successfully.`),F(C,y,x)}catch(e){t(e?.response?.data?.message||`Could not toggle subscriber status.`)}finally{A(null)}},R=async()=>{if(j){A(j.id);try{e((await a.delete(`/superadmin/newsletter-subscribers/${j.id}`)).data?.message||`Subscriber deleted successfully.`),M(null),F(C,y,x)}catch(e){t(e?.response?.data?.message||`Could not delete subscriber.`)}finally{A(null)}}},z=async()=>{P(!0);try{let t=await a.get(`/superadmin/newsletter-subscribers/export`,{responseType:`blob`}),n=window.URL.createObjectURL(new Blob([t.data])),r=document.createElement(`a`);r.href=n,r.setAttribute(`download`,`gradequest_newsletter_subscribers_${new Date().toISOString().slice(0,10)}.csv`),document.body.appendChild(r),r.click(),r.remove(),e(`Subscribers list exported to CSV successfully.`)}catch{t(`Failed to export subscribers.`)}finally{P(!1)}},B=e=>e?new Date(e).toLocaleDateString(`en-GB`,{day:`2-digit`,month:`short`,year:`numeric`,hour:`2-digit`,minute:`2-digit`}):`-`;return(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(`style`,{children:`
        .gq-ns-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 100%);
          color: #FFFFFF;
          border-radius: 16px;
          padding: 26px 30px;
          margin-bottom: 24px;
          box-shadow: 0 10px 25px -5px rgba(10, 25, 47, 0.25);
          position: relative;
          overflow: hidden;
        }
        .gq-ns-hero::after {
          content: "";
          position: absolute;
          right: -40px;
          bottom: -40px;
          width: 220px;
          height: 220px;
          background: radial-gradient(circle, rgba(251, 191, 36, 0.15) 0%, transparent 70%);
          pointer-events: none;
        }
        .gq-kpi-card {
          background: #FFFFFF;
          border-radius: 14px;
          border: 1px solid #E2E8F0;
          padding: 20px 22px;
          box-shadow: 0 4px 12px rgba(15, 39, 68, 0.04);
          transition: all 0.2s ease;
        }
        .gq-kpi-card:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 20px rgba(15, 39, 68, 0.08);
        }
        .gq-table-card {
          background: #FFFFFF;
          border-radius: 16px;
          border: 1px solid #E2E8F0;
          box-shadow: 0 6px 18px rgba(15, 39, 68, 0.05);
          overflow: hidden;
        }
        .gq-table-head {
          background: #F8FAFC;
          border-bottom: 1.5px solid #E2E8F0;
        }
        .gq-table-head th {
          font-size: 11.5px;
          font-weight: 800;
          text-transform: uppercase;
          letter-spacing: 0.06em;
          color: #475569;
          padding: 14px 18px;
        }
        .gq-table-body td {
          padding: 16px 18px;
          font-size: 13.5px;
          color: #1E293B;
          border-bottom: 1px solid #F1F5F9;
          vertical-align: middle;
        }
        .gq-status-badge {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 4px 10px;
          border-radius: 999px;
          font-size: 12px;
          font-weight: 700;
        }
        .gq-status-badge.active {
          background: #DCFCE7;
          color: #15803D;
        }
        .gq-status-badge.unsubscribed {
          background: #FEE2E2;
          color: #B91C1C;
        }
        .gq-source-pill {
          background: #F1F5F9;
          color: #475569;
          padding: 3px 8px;
          border-radius: 6px;
          font-size: 11.5px;
          font-weight: 600;
          font-family: monospace;
        }
      `}),(0,d.jsx)(s,{sidebarOpen:r,setSidebarOpen:f,title:`Newsletter Subscribers`}),(0,d.jsx)(`div`,{className:`container-fluid`,children:(0,d.jsxs)(`div`,{className:`row`,children:[(0,d.jsx)(o,{sidebarOpen:r,setSidebarOpen:f}),(0,d.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto db-main p-3 p-md-4`,children:[p&&!h.length&&(0,d.jsx)(i,{message:`Loading subscribers list...`}),(0,d.jsxs)(`div`,{className:`gq-ns-hero d-flex flex-wrap align-items-center justify-content-between gap-3`,children:[(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`span`,{className:`badge mb-2 px-2.5 py-1`,style:{background:`#FBBF24`,color:`#0F2744`,fontWeight:800},children:`Marketing Audience`}),(0,d.jsx)(`h2`,{className:`mb-1 fw-bold`,style:{fontSize:`24px`},children:`Newsletter & Platform Subscribers`}),(0,d.jsx)(`p`,{className:`mb-0 text-white-50`,style:{fontSize:`14px`,maxWidth:`600px`},children:`Manage leads and visitors who signed up for platform updates via the homepage footer and website widgets.`})]}),(0,d.jsxs)(`div`,{className:`d-flex flex-wrap gap-2`,children:[(0,d.jsxs)(`button`,{type:`button`,onClick:z,disabled:N||!h.length,className:`btn btn-light fw-bold d-inline-flex align-items-center gap-2`,style:{borderRadius:`10px`,fontSize:`13.5px`,padding:`9px 16px`},children:[(0,d.jsx)(`i`,{className:`bi bi-file-earmark-spreadsheet-fill text-success`}),N?`Exporting...`:`Export CSV`]}),(0,d.jsxs)(n,{to:`/superadmin/send-message`,className:`btn btn-warning fw-bold d-inline-flex align-items-center gap-2`,style:{borderRadius:`10px`,fontSize:`13.5px`,padding:`9px 18px`,color:`#0F2744`},children:[(0,d.jsx)(`i`,{className:`bi bi-send-fill`}),`Compose Broadcast`]})]})]}),(0,d.jsxs)(`div`,{className:`row g-3 mb-4`,children:[(0,d.jsx)(`div`,{className:`col-6 col-lg-3`,children:(0,d.jsxs)(`div`,{className:`gq-kpi-card`,children:[(0,d.jsxs)(`div`,{className:`d-flex align-items-center justify-content-between mb-2`,children:[(0,d.jsx)(`span`,{className:`text-muted fw-bold`,style:{fontSize:`12px`,textTransform:`uppercase`},children:`Total Subscribers`}),(0,d.jsx)(`span`,{className:`p-2 rounded-circle`,style:{background:`#EFF6FF`,color:`#1D4ED8`},children:(0,d.jsx)(`i`,{className:`bi bi-envelope-paper-heart`})})]}),(0,d.jsx)(`h3`,{className:`mb-0 fw-black text-dark`,children:_.total.toLocaleString()})]})}),(0,d.jsx)(`div`,{className:`col-6 col-lg-3`,children:(0,d.jsxs)(`div`,{className:`gq-kpi-card`,children:[(0,d.jsxs)(`div`,{className:`d-flex align-items-center justify-content-between mb-2`,children:[(0,d.jsx)(`span`,{className:`text-muted fw-bold`,style:{fontSize:`12px`,textTransform:`uppercase`},children:`Active Subscribed`}),(0,d.jsx)(`span`,{className:`p-2 rounded-circle`,style:{background:`#DCFCE7`,color:`#15803D`},children:(0,d.jsx)(`i`,{className:`bi bi-check-circle-fill`})})]}),(0,d.jsx)(`h3`,{className:`mb-0 fw-black text-success`,children:_.subscribed.toLocaleString()})]})}),(0,d.jsx)(`div`,{className:`col-6 col-lg-3`,children:(0,d.jsxs)(`div`,{className:`gq-kpi-card`,children:[(0,d.jsxs)(`div`,{className:`d-flex align-items-center justify-content-between mb-2`,children:[(0,d.jsx)(`span`,{className:`text-muted fw-bold`,style:{fontSize:`12px`,textTransform:`uppercase`},children:`Unsubscribed`}),(0,d.jsx)(`span`,{className:`p-2 rounded-circle`,style:{background:`#FEE2E2`,color:`#B91C1C`},children:(0,d.jsx)(`i`,{className:`bi bi-x-circle-fill`})})]}),(0,d.jsx)(`h3`,{className:`mb-0 fw-black text-danger`,children:_.unsubscribed.toLocaleString()})]})}),(0,d.jsx)(`div`,{className:`col-6 col-lg-3`,children:(0,d.jsxs)(`div`,{className:`gq-kpi-card`,children:[(0,d.jsxs)(`div`,{className:`d-flex align-items-center justify-content-between mb-2`,children:[(0,d.jsx)(`span`,{className:`text-muted fw-bold`,style:{fontSize:`12px`,textTransform:`uppercase`},children:`Last 30 Days`}),(0,d.jsx)(`span`,{className:`p-2 rounded-circle`,style:{background:`#FEF3C7`,color:`#D97706`},children:(0,d.jsx)(`i`,{className:`bi bi-graph-up-arrow`})})]}),(0,d.jsx)(`h3`,{className:`mb-0 fw-black text-warning`,children:_.recent_30_days.toLocaleString()})]})})]}),(0,d.jsxs)(`div`,{className:`gq-table-card mb-4`,children:[(0,d.jsxs)(`div`,{className:`p-3 border-bottom d-flex flex-wrap align-items-center justify-content-between gap-3 bg-white`,children:[(0,d.jsxs)(`form`,{onSubmit:I,className:`d-flex align-items-center gap-2 flex-grow-1`,style:{maxWidth:`420px`},children:[(0,d.jsxs)(`div`,{className:`input-group`,children:[(0,d.jsx)(`span`,{className:`input-group-text bg-white border-end-0`,children:(0,d.jsx)(`i`,{className:`bi bi-search text-muted`})}),(0,d.jsx)(`input`,{type:`text`,className:`form-control border-start-0 ps-0`,placeholder:`Search by subscriber email...`,value:y,onChange:e=>b(e.target.value),style:{fontSize:`13.5px`}}),y&&(0,d.jsx)(`button`,{type:`button`,className:`btn btn-outline-secondary border-start-0`,onClick:()=>{b(``),F(1,``,x)},children:(0,d.jsx)(`i`,{className:`bi bi-x`})})]}),(0,d.jsx)(`button`,{type:`submit`,className:`btn btn-primary fw-bold`,style:{fontSize:`13px`,padding:`7px 14px`},children:`Search`})]}),(0,d.jsxs)(`div`,{className:`d-flex align-items-center gap-2`,children:[(0,d.jsx)(`span`,{className:`text-muted fw-bold`,style:{fontSize:`12.5px`},children:`Status:`}),(0,d.jsxs)(`div`,{className:`btn-group`,role:`group`,children:[(0,d.jsxs)(`button`,{type:`button`,className:`btn btn-sm ${x===`all`?`btn-dark fw-bold`:`btn-outline-secondary`}`,onClick:()=>S(`all`),children:[`All (`,_.total,`)`]}),(0,d.jsxs)(`button`,{type:`button`,className:`btn btn-sm ${x===`subscribed`?`btn-success fw-bold`:`btn-outline-secondary`}`,onClick:()=>S(`subscribed`),children:[`Active (`,_.subscribed,`)`]}),(0,d.jsxs)(`button`,{type:`button`,className:`btn btn-sm ${x===`unsubscribed`?`btn-danger fw-bold`:`btn-outline-secondary`}`,onClick:()=>S(`unsubscribed`),children:[`Unsubscribed (`,_.unsubscribed,`)`]})]})]})]}),(0,d.jsx)(`div`,{className:`table-responsive`,children:(0,d.jsxs)(`table`,{className:`table mb-0`,children:[(0,d.jsx)(`thead`,{className:`gq-table-head`,children:(0,d.jsxs)(`tr`,{children:[(0,d.jsx)(`th`,{children:`#`}),(0,d.jsx)(`th`,{children:`Email Address`}),(0,d.jsx)(`th`,{children:`Status`}),(0,d.jsx)(`th`,{children:`Source`}),(0,d.jsx)(`th`,{children:`Subscribed On`}),(0,d.jsx)(`th`,{className:`text-end`,children:`Actions`})]})}),(0,d.jsx)(`tbody`,{className:`gq-table-body`,children:h.length===0?(0,d.jsx)(`tr`,{children:(0,d.jsxs)(`td`,{colSpan:6,className:`text-center py-5 text-muted`,children:[(0,d.jsx)(`i`,{className:`bi bi-inbox fs-2 d-block mb-2 text-secondary`}),`No newsletter subscribers found.`]})}):h.map((e,t)=>(0,d.jsxs)(`tr`,{children:[(0,d.jsx)(`td`,{className:`text-muted fw-bold`,style:{width:`40px`},children:(C-1)*15+t+1}),(0,d.jsx)(`td`,{children:(0,d.jsx)(`div`,{className:`d-flex align-items-center gap-2`,children:(0,d.jsx)(`span`,{className:`fw-bold`,style:{color:`#0F2744`,fontSize:`14px`},children:e.email})})}),(0,d.jsx)(`td`,{children:e.status===`subscribed`?(0,d.jsxs)(`span`,{className:`gq-status-badge active`,children:[(0,d.jsx)(`i`,{className:`bi bi-check-circle-fill`}),` Active Subscribed`]}):(0,d.jsxs)(`span`,{className:`gq-status-badge unsubscribed`,children:[(0,d.jsx)(`i`,{className:`bi bi-x-circle-fill`}),` Unsubscribed`]})}),(0,d.jsx)(`td`,{children:(0,d.jsx)(`span`,{className:`gq-source-pill`,children:e.source||`homepage_footer`})}),(0,d.jsx)(`td`,{className:`text-muted`,style:{fontSize:`13px`},children:B(e.created_at)}),(0,d.jsx)(`td`,{className:`text-end`,children:(0,d.jsxs)(`div`,{className:`d-inline-flex gap-1`,children:[(0,d.jsx)(`button`,{type:`button`,className:`btn btn-sm ${e.status===`subscribed`?`btn-outline-warning text-dark`:`btn-outline-success`}`,disabled:k===e.id,onClick:()=>L(e),title:e.status===`subscribed`?`Mark Unsubscribed`:`Reactivate Subscription`,style:{fontSize:`12px`,padding:`4px 8px`},children:k===e.id?(0,d.jsx)(`span`,{className:`spinner-border spinner-border-sm`}):e.status===`subscribed`?(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(`i`,{className:`bi bi-pause-circle`}),` Unsubscribe`]}):(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(`i`,{className:`bi bi-play-circle`}),` Reactivate`]})}),(0,d.jsx)(`button`,{type:`button`,className:`btn btn-sm btn-outline-danger`,disabled:k===e.id,onClick:()=>M(e),title:`Delete Subscriber`,style:{fontSize:`12px`,padding:`4px 8px`},children:(0,d.jsx)(`i`,{className:`bi bi-trash3`})})]})})]},e.id))})]})}),T>1&&(0,d.jsxs)(`div`,{className:`p-3 border-top d-flex align-items-center justify-content-between bg-white flex-wrap gap-2`,children:[(0,d.jsxs)(`div`,{className:`text-muted`,style:{fontSize:`13px`},children:[`Showing page `,(0,d.jsx)(`strong`,{children:C}),` of `,(0,d.jsx)(`strong`,{children:T}),` (`,D,` total)`]}),(0,d.jsxs)(`div`,{className:`btn-group`,children:[(0,d.jsxs)(`button`,{type:`button`,className:`btn btn-sm btn-outline-secondary`,disabled:C<=1,onClick:()=>F(C-1,y,x),children:[(0,d.jsx)(`i`,{className:`bi bi-chevron-left`}),` Previous`]}),(0,d.jsxs)(`button`,{type:`button`,className:`btn btn-sm btn-outline-secondary`,disabled:C>=T,onClick:()=>F(C+1,y,x),children:[`Next `,(0,d.jsx)(`i`,{className:`bi bi-chevron-right`})]})]})]})]}),j&&(0,d.jsx)(`div`,{className:`modal fade show d-block`,tabIndex:-1,style:{background:`rgba(15, 39, 68, 0.6)`,backdropFilter:`blur(4px)`},children:(0,d.jsx)(`div`,{className:`modal-dialog modal-dialog-centered`,children:(0,d.jsxs)(`div`,{className:`modal-content border-0 shadow-lg`,style:{borderRadius:`16px`},children:[(0,d.jsxs)(`div`,{className:`modal-header border-0 pb-0`,children:[(0,d.jsxs)(`h5`,{className:`modal-title fw-bold text-danger`,children:[(0,d.jsx)(`i`,{className:`bi bi-exclamation-triangle-fill me-2`}),`Delete Subscriber`]}),(0,d.jsx)(`button`,{type:`button`,className:`btn-close`,onClick:()=>M(null)})]}),(0,d.jsxs)(`div`,{className:`modal-body py-3`,children:[(0,d.jsx)(`p`,{className:`mb-1 text-secondary`,children:`Are you sure you want to permanently delete subscriber:`}),(0,d.jsx)(`p`,{className:`fw-bold text-dark fs-6 mb-0`,children:j.email})]}),(0,d.jsxs)(`div`,{className:`modal-footer border-0 pt-0`,children:[(0,d.jsx)(`button`,{type:`button`,className:`btn btn-light fw-bold`,onClick:()=>M(null),children:`Cancel`}),(0,d.jsx)(`button`,{type:`button`,className:`btn btn-danger fw-bold`,disabled:k===j.id,onClick:R,children:k===j.id?`Deleting...`:`Confirm Delete`})]})]})})}),(0,d.jsx)(l,{})]})]})})]})}export{f as default};