import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{p as t}from"./vendor-react-BhRGw7qi.js";import"./vendor-http-DXqav090.js";import{C as n,F as r}from"./index-D6TxbaCx.js";var i=e(),a=t(),o=e=>new Intl.NumberFormat(`en-NG`,{style:`currency`,currency:`NGN`}).format(Number(e||0));function s(){let e=(0,i.useMemo)(()=>new URLSearchParams(window.location.search),[]),t=e.get(`paymentReference`)||e.get(`reference`)||e.get(`trxref`)||e.get(`ref`)||``,s=e.get(`school_code`)||``,c=e.get(`student_reg_no`)||e.get(`reg_no`)||``,[l,u]=(0,i.useState)(s),[d,f]=(0,i.useState)(c),[p,m]=(0,i.useState)(``),[h,ee]=(0,i.useState)(``),[g,_]=(0,i.useState)(``),[v,te]=(0,i.useState)(``),[y,b]=(0,i.useState)(null),[x,S]=(0,i.useState)(null),[ne,C]=(0,i.useState)(!1),[w,T]=(0,i.useState)(!1),[E,D]=(0,i.useState)(!1),[O,k]=(0,i.useState)(!1),[A,j]=(0,i.useState)(null),[M,N]=(0,i.useState)(null),[P,F]=(0,i.useState)(null),[I,L]=(0,i.useState)(null),[R,z]=(0,i.useState)(``),[re,B]=(0,i.useState)(``),[V,H]=(0,i.useState)(!1),U=Number(x?.summary?.balance||0),W=Number(p||0),G=x?.installment_plan?.full_payment_discount||x?.full_payment_discount,K=!!(G?.enabled&&G.discount_amount>0&&Math.abs(W-G.discounted_payable_amount)<.01),q=x?.charge_policy,J=q?.bank_charge_bearer===`parent`,Y=q?.platform_fee_bearer===`parent`,X=J&&W>0?Number(q?.bank_charge_amount??200):0,Z=Y&&W>0?Number(q?.platform_fee_amount??500):0,Q=W+X+Z,ie=K&&G?G.discounted_payable_amount:U>0?U:1/0,$=!!y&&!!x&&W>=100&&(W<=ie||W<=U)&&!E;(0,i.useEffect)(()=>{t&&(k(!0),N(null),j(null),r.get(`/public/fee-payment/verify/${encodeURIComponent(t)}`).then(e=>{j(`Payment confirmed. Transaction Reference: ${e.data?.reference}`),e.data?.receipt&&F({...e.data.receipt,pdf_download_url:e.data.pdf_download_url})}).catch(e=>{N(e?.response?.data?.message||`Unable to verify payment transaction. Please contact school bursary if debited.`)}).finally(()=>k(!1)))},[t]),(0,i.useEffect)(()=>{let e=l.trim();if(e.length<2){b(null),S(null);return}let t=window.setTimeout(()=>{C(!0),N(null),r.get(`/public/fee-payment/school`,{params:{school_code:e}}).then(e=>{e.data?.school&&b(e.data.school)}).catch(e=>{b(null),N(e?.response?.data?.message||`School code not found. Please check your school ID/code.`)}).finally(()=>C(!1))},400);return()=>window.clearTimeout(t)},[l]),(0,i.useEffect)(()=>{let e=l.trim(),t=d.trim();if(!e||!t||t.length<2){S(null);return}let n=window.setTimeout(()=>{T(!0),N(null),r.get(`/public/fee-payment/student`,{params:{school_code:e,student_reg_no:t}}).then(e=>{if(S(e.data),e.data?.school&&b(e.data.school),!p&&Number(e.data?.summary?.balance||0)>0){let t=e.data?.installment_plan?.full_payment_discount||e.data?.full_payment_discount;t?.enabled&&t.discount_amount>0&&t.discounted_payable_amount>0?m(String(t.discounted_payable_amount)):m(String(e.data.summary.balance))}}).catch(e=>{S(null),N(e?.response?.data?.message||`Student record was not found for this school admission number.`)}).finally(()=>T(!1))},450);return()=>window.clearTimeout(n)},[l,d]);let ae=async e=>{if(!$)return;let t=typeof e==`string`?e:void 0;D(!0),N(null),j(null);try{let e=await r.post(`/public/fee-payment/initialize`,{school_code:l.trim(),student_reg_no:d.trim(),amount:Number(p),payer_email:h.trim()||void 0,payer_name:g.trim()||void 0,payer_phone:v.trim()||void 0,gateway:t});if(e.data?.virtual_account&&!t)L(e.data.virtual_account),z(e.data.reference||``),B(e.data.checkout_url||e.data.authorization_url||``),j(`Dedicated Wema Bank Virtual Account generated. You can transfer funds directly from your bank mobile app.`);else{let t=e.data?.checkout_url||e.data?.authorization_url;if(t)window.location.href=t;else throw Error(`Payment gateway checkout URL was not received.`)}}catch(e){N(e?.response?.data?.message||e?.message||`Unable to initialize secure payment. Please verify details and try again.`)}finally{D(!1)}};return(0,a.jsxs)(`main`,{className:`gq-sec-page`,children:[(0,a.jsx)(n,{title:`Pay School Fees Online | SchoolProfit`}),(0,a.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&family=Playfair+Display:ital,wght@0,600;0,800;1,600&display=swap');

        .gq-sec-page {
          min-height: 100vh;
          background: #F8FAFC;
          color: #0F172A;
          padding: 24px 16px 60px;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
        }

        .gq-sec-shell {
          max-width: 1140px;
          margin: 0 auto;
        }

        /* ── Top Bar ── */
        .gq-sec-topbar {
          display: flex;
          justify-content: space-between;
          align-items: center;
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: 16px;
          padding: 12px 24px;
          margin-bottom: 20px;
          box-shadow: 0 2px 8px rgba(15, 23, 42, 0.04);
        }

        .gq-sec-brand {
          display: flex;
          align-items: center;
          gap: 10px;
          font-weight: 800;
          font-size: 15px;
          color: #0F172A;
        }

        .gq-sec-badge-row {
          display: flex;
          align-items: center;
          gap: 16px;
          font-size: 12px;
          color: #475569;
          font-weight: 600;
        }

        .gq-sec-badge-item {
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .gq-sec-badge-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #10B981;
          box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.2);
        }

        /* ── Hero Banner ── */
        .gq-sec-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 20px;
          padding: 32px 36px;
          color: #FFFFFF;
          position: relative;
          overflow: hidden;
          border: 1px solid rgba(255, 255, 255, 0.1);
          box-shadow: 0 16px 36px rgba(15, 39, 68, 0.18);
          margin-bottom: 24px;
        }

        .gq-sec-hero::before {
          content: "";
          position: absolute;
          inset: 0;
          background-image: radial-gradient(circle, rgba(255,255,255,0.06) 1px, transparent 1px);
          background-size: 24px 24px;
          pointer-events: none;
        }

        .gq-sec-hero > * {
          position: relative;
          z-index: 1;
        }

        .gq-sec-pill {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          background: rgba(245, 158, 11, 0.16);
          border: 1px solid rgba(245, 158, 11, 0.35);
          color: #FBBF24;
          padding: 6px 14px;
          border-radius: 999px;
          font-size: 11.5px;
          font-weight: 800;
          margin-bottom: 14px;
          letter-spacing: 0.04em;
          text-transform: uppercase;
        }

        .gq-sec-title {
          font-family: 'Playfair Display', Georgia, serif;
          font-size: clamp(24px, 3.8vw, 36px);
          font-weight: 900;
          line-height: 1.15;
          margin: 0 0 10px;
          color: #FFFFFF;
        }

        .gq-sec-sub {
          max-width: 680px;
          color: #CBD5E1;
          font-size: 14px;
          line-height: 1.65;
          margin: 0;
        }

        /* ── Reassurance Pillars ── */
        .gq-sec-trust-bar {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 14px;
          margin-bottom: 24px;
        }

        .gq-sec-trust-card {
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: 14px;
          padding: 16px;
          box-shadow: 0 2px 8px rgba(15, 23, 42, 0.03);
        }

        .gq-sec-trust-icon {
          width: 36px;
          height: 36px;
          border-radius: 10px;
          background: #EFF6FF;
          color: #1D4ED8;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 16px;
          margin-bottom: 10px;
        }

        .gq-sec-trust-title {
          font-weight: 800;
          font-size: 13px;
          color: #0F172A;
          margin-bottom: 4px;
        }

        .gq-sec-trust-desc {
          font-size: 11.5px;
          color: #64748B;
          line-height: 1.5;
          margin: 0;
        }

        /* ── Main Layout ── */
        .gq-sec-grid {
          display: grid;
          grid-template-columns: minmax(0, 1.15fr) minmax(340px, 0.85fr);
          gap: 24px;
          align-items: start;
        }

        .gq-sec-card {
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: 18px;
          box-shadow: 0 6px 20px rgba(15, 23, 42, 0.04);
          overflow: hidden;
        }

        .gq-sec-card-head {
          padding: 20px 24px;
          border-bottom: 1px solid #F1F5F9;
          background: #FAFCFF;
        }

        .gq-sec-card-title {
          font-size: 17px;
          font-weight: 800;
          color: #0F172A;
          margin: 0 0 4px;
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .gq-sec-card-sub {
          font-size: 12.5px;
          color: #64748B;
          margin: 0;
        }

        .gq-sec-card-body {
          padding: 24px;
        }

        /* ── Verified School Badge ── */
        .gq-school-profile {
          background: linear-gradient(135deg, #F0FDF4 0%, #DCFCE7 100%);
          border: 1px solid #86EFAC;
          border-radius: 14px;
          padding: 16px 18px;
          margin-bottom: 20px;
          display: flex;
          align-items: center;
          gap: 14px;
        }

        .gq-school-avatar {
          width: 48px;
          height: 48px;
          border-radius: 12px;
          background: #FFFFFF;
          border: 1px solid #86EFAC;
          color: #166534;
          font-weight: 900;
          font-size: 20px;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
          box-shadow: 0 4px 10px rgba(22, 101, 52, 0.08);
        }

        .gq-school-meta-title {
          font-size: 11px;
          font-weight: 800;
          text-transform: uppercase;
          letter-spacing: 0.06em;
          color: #15803D;
          margin-bottom: 2px;
        }

        .gq-school-name {
          font-size: 16.5px;
          font-weight: 900;
          color: #064E3B;
          margin: 0 0 2px;
        }

        .gq-school-address {
          font-size: 12px;
          color: #166534;
        }

        /* ── Form Controls ── */
        .gq-form-group {
          margin-bottom: 18px;
        }

        .gq-form-label {
          display: block;
          font-size: 12.5px;
          font-weight: 800;
          color: #334155;
          margin-bottom: 6px;
        }

        .gq-input {
          width: 100%;
          min-height: 46px;
          border: 1.5px solid #CBD5E1;
          border-radius: 10px;
          padding: 10px 14px;
          font-size: 14.5px;
          font-weight: 600;
          color: #0F172A;
          background: #FFFFFF;
          outline: none;
          transition: border-color 0.15s, box-shadow 0.15s;
          box-sizing: border-box;
        }

        .gq-input:focus {
          border-color: #1D4ED8;
          box-shadow: 0 0 0 3px rgba(29, 78, 216, 0.12);
        }

        .gq-form-hint {
          font-size: 12px;
          color: #64748B;
          margin-top: 5px;
        }

        .gq-form-row {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 14px;
        }

        .gq-amount-presets {
          display: flex;
          gap: 8px;
          margin-top: 8px;
          flex-wrap: wrap;
        }

        .gq-preset-btn {
          background: #F1F5F9;
          border: 1px solid #E2E8F0;
          border-radius: 8px;
          padding: 6px 12px;
          font-size: 12px;
          font-weight: 700;
          color: #334155;
          cursor: pointer;
          transition: all 0.15s ease;
        }

        .gq-preset-btn:hover {
          background: #E2E8F0;
          color: #0F172A;
        }

        .gq-pay-btn {
          width: 100%;
          min-height: 52px;
          border: none;
          border-radius: 12px;
          background: linear-gradient(135deg, #0F2744 0%, #1E3A8A 100%);
          color: #FFFFFF;
          font-size: 15.5px;
          font-weight: 800;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 10px;
          cursor: pointer;
          transition: transform 0.15s ease, box-shadow 0.15s ease, opacity 0.15s ease;
          box-shadow: 0 8px 24px rgba(15, 39, 68, 0.2);
          margin-top: 8px;
        }

        .gq-pay-btn:hover:not(:disabled) {
          transform: translateY(-1px);
          box-shadow: 0 12px 28px rgba(15, 39, 68, 0.28);
        }

        .gq-pay-btn:disabled {
          opacity: 0.55;
          cursor: not-allowed;
          box-shadow: none;
        }

        .gq-pay-notice {
          font-size: 11.5px;
          color: #64748B;
          text-align: center;
          margin-top: 10px;
          line-height: 1.5;
        }

        /* ── Right Panel ── */
        .gq-summary-box {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 10px;
          margin-bottom: 18px;
        }

        .gq-stat-tile {
          background: #F8FAFC;
          border: 1px solid #E2E8F0;
          border-radius: 12px;
          padding: 12px;
        }

        .gq-stat-label {
          font-size: 11px;
          font-weight: 700;
          color: #64748B;
          text-transform: uppercase;
          margin-bottom: 4px;
        }

        .gq-stat-val {
          font-weight: 900;
          font-size: 16px;
          color: #0F172A;
        }

        .gq-stat-val-danger { color: #DC2626; }
        .gq-stat-val-success { color: #16A34A; }

        .gq-fee-list {
          display: grid;
          gap: 10px;
          max-height: 380px;
          overflow-y: auto;
        }

        .gq-fee-item {
          border: 1px solid #E2E8F0;
          border-radius: 12px;
          padding: 12px 14px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 12px;
          background: #FFFFFF;
        }

        .gq-fee-name {
          font-weight: 800;
          font-size: 13.5px;
          color: #0F172A;
        }

        .gq-fee-meta {
          font-size: 12px;
          color: #64748B;
          margin-top: 2px;
        }

        .gq-fee-balance {
          font-weight: 900;
          font-size: 14px;
          color: #0F172A;
          text-align: right;
          white-space: nowrap;
        }

        /* ── Official Stamped Receipt Card ── */
        .gq-receipt-card {
          background: #FFFFFF;
          border: 2px solid #10B981;
          border-radius: 20px;
          padding: 28px;
          box-shadow: 0 16px 40px rgba(16, 185, 129, 0.12);
        }

        .gq-receipt-header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          border-bottom: 2px solid #0F172A;
          padding-bottom: 18px;
          margin-bottom: 20px;
        }

        .gq-receipt-verified-pill {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          background: #ECFDF5;
          color: #047857;
          border: 1px solid #A7F3D0;
          border-radius: 999px;
          padding: 4px 14px;
          font-size: 11px;
          font-weight: 900;
          text-transform: uppercase;
          letter-spacing: 0.04em;
        }

        .gq-receipt-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 16px;
          background: #F8FAFC;
          border: 1px solid #E2E8F0;
          border-radius: 14px;
          padding: 18px;
          margin-bottom: 20px;
        }

        .gq-receipt-table {
          width: 100%;
          border-collapse: collapse;
          margin-bottom: 18px;
        }

        .gq-receipt-table th {
          background: #0F2744;
          color: #FFFFFF;
          padding: 10px 14px;
          font-size: 11.5px;
          font-weight: 800;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          text-align: left;
        }

        .gq-receipt-table td {
          padding: 11px 14px;
          border-bottom: 1px solid #E2E8F0;
          font-size: 13px;
        }

        .gq-receipt-actions {
          display: flex;
          flex-wrap: wrap;
          gap: 12px;
          margin-top: 24px;
        }

        .gq-btn-download {
          background: #047857;
          color: #FFFFFF;
          border: none;
          border-radius: 12px;
          padding: 12px 20px;
          font-weight: 800;
          font-size: 14px;
          cursor: pointer;
          display: inline-flex;
          align-items: center;
          gap: 8px;
          transition: background 0.15s ease;
        }

        .gq-btn-download:hover { background: #065F46; }

        .gq-btn-print {
          background: #FFFFFF;
          color: #0F172A;
          border: 1px solid #CBD5E1;
          border-radius: 12px;
          padding: 12px 20px;
          font-weight: 800;
          font-size: 14px;
          cursor: pointer;
          display: inline-flex;
          align-items: center;
          gap: 8px;
        }

        .gq-btn-reset {
          background: transparent;
          color: #475569;
          border: 1px dashed #CBD5E1;
          border-radius: 12px;
          padding: 12px 20px;
          font-weight: 700;
          font-size: 13.5px;
          cursor: pointer;
          display: inline-flex;
          align-items: center;
          gap: 8px;
        }

        /* ── Alert Notices ── */
        .gq-alert-warn {
          background: #FFFBEB;
          border: 1px solid #FDE68A;
          color: #92400E;
          border-radius: 12px;
          padding: 12px 16px;
          font-size: 13px;
          margin-bottom: 16px;
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .gq-alert-error {
          background: #FEF2F2;
          border: 1px solid #FECACA;
          color: #991B1B;
          border-radius: 12px;
          padding: 12px 16px;
          font-size: 13px;
          margin-bottom: 16px;
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .gq-alert-success {
          background: #F0FDF4;
          border: 1px solid #BBF7D0;
          color: #166534;
          border-radius: 12px;
          padding: 12px 16px;
          font-size: 13px;
          margin-bottom: 16px;
          display: flex;
          align-items: center;
          gap: 10px;
        }

        @media (max-width: 900px) {
          .gq-sec-grid { grid-template-columns: 1fr; }
          .gq-sec-trust-bar { grid-template-columns: 1fr 1fr; }
          .gq-form-row { grid-template-columns: 1fr; }
          .gq-sec-topbar { flex-direction: column; align-items: flex-start; gap: 10px; }
          .gq-receipt-grid { grid-template-columns: 1fr; }
        }

        @media (max-width: 600px) {
          .gq-sec-trust-bar { grid-template-columns: 1fr; }
          .gq-summary-box { grid-template-columns: 1fr; }
        }

        @media print {
          body * { visibility: hidden; }
          .gq-receipt-card, .gq-receipt-card * { visibility: visible; }
          .gq-receipt-card {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            border: none;
            box-shadow: none;
            padding: 0;
          }
          .gq-receipt-actions { display: none !important; }
        }
      `}),(0,a.jsxs)(`div`,{className:`gq-sec-shell`,children:[(0,a.jsxs)(`div`,{className:`gq-sec-topbar`,children:[(0,a.jsxs)(`div`,{className:`gq-sec-brand`,children:[(0,a.jsx)(`i`,{className:`bi bi-shield-lock-fill text-success`,style:{fontSize:20}}),(0,a.jsx)(`span`,{children:`SchoolProfit Official Electronic Payment Gateway`})]}),(0,a.jsxs)(`div`,{className:`gq-sec-badge-row`,children:[(0,a.jsxs)(`div`,{className:`gq-sec-badge-item`,children:[(0,a.jsx)(`span`,{className:`gq-sec-badge-dot`}),(0,a.jsx)(`span`,{children:`Encrypted`})]}),(0,a.jsxs)(`div`,{className:`gq-sec-badge-item d-none d-sm-flex`,children:[(0,a.jsx)(`i`,{className:`bi bi-bank`}),(0,a.jsx)(`span`,{children:`Direct Bank Settlement`})]}),(0,a.jsxs)(`div`,{className:`gq-sec-badge-item d-none d-md-flex`,children:[(0,a.jsx)(`i`,{className:`bi bi-file-earmark-check`}),(0,a.jsx)(`span`,{children:`Instant Digital Receipt`})]})]})]}),(0,a.jsx)(`section`,{className:`gq-sec-hero`,children:(0,a.jsxs)(`div`,{children:[(0,a.jsxs)(`div`,{className:`gq-sec-pill`,children:[(0,a.jsx)(`i`,{className:`bi bi-patch-check-fill`}),` Official Verified School Fee Portal`]}),(0,a.jsx)(`h1`,{className:`gq-sec-title`,children:`Pay School Fees Online`}),(0,a.jsx)(`p`,{className:`gq-sec-sub`,children:`Enter your school ID code and student admission number below to view the itemized fee schedule and make an authentic, instant, and confidential payment.`})]})}),(0,a.jsxs)(`section`,{className:`gq-sec-trust-bar`,children:[(0,a.jsxs)(`div`,{className:`gq-sec-trust-card`,children:[(0,a.jsx)(`div`,{className:`gq-sec-trust-icon`,children:(0,a.jsx)(`i`,{className:`bi bi-shield-check`})}),(0,a.jsx)(`div`,{className:`gq-sec-trust-title`,children:`Direct School Credit`}),(0,a.jsx)(`p`,{className:`gq-sec-trust-desc`,children:`All payments settle directly into the verified school bank account.`})]}),(0,a.jsxs)(`div`,{className:`gq-sec-trust-card`,children:[(0,a.jsx)(`div`,{className:`gq-sec-trust-icon`,children:(0,a.jsx)(`i`,{className:`bi bi-lock-fill`})}),(0,a.jsx)(`div`,{className:`gq-sec-trust-title`,children:`Bank-Grade Confidentiality`}),(0,a.jsx)(`p`,{className:`gq-sec-trust-desc`,children:`End-to-end encrypted direct bank transfer to verified institutional account.`})]}),(0,a.jsxs)(`div`,{className:`gq-sec-trust-card`,children:[(0,a.jsx)(`div`,{className:`gq-sec-trust-icon`,children:(0,a.jsx)(`i`,{className:`bi bi-file-earmark-pdf-fill`})}),(0,a.jsx)(`div`,{className:`gq-sec-trust-title`,children:`Official PDF Receipt`}),(0,a.jsx)(`p`,{className:`gq-sec-trust-desc`,children:`Instantly download an authenticated, stamped digital payment voucher.`})]}),(0,a.jsxs)(`div`,{className:`gq-sec-trust-card`,children:[(0,a.jsx)(`div`,{className:`gq-sec-trust-icon`,children:(0,a.jsx)(`i`,{className:`bi bi-lightning-charge-fill`})}),(0,a.jsx)(`div`,{className:`gq-sec-trust-title`,children:`Real-Time Ledger Update`}),(0,a.jsx)(`p`,{className:`gq-sec-trust-desc`,children:`Your child's fee status is cleared instantly on the school bursary records.`})]})]}),P?(0,a.jsxs)(`section`,{className:`gq-receipt-card`,children:[(0,a.jsxs)(`div`,{className:`gq-receipt-header`,children:[(0,a.jsxs)(`div`,{children:[(0,a.jsxs)(`span`,{className:`gq-receipt-verified-pill`,children:[(0,a.jsx)(`i`,{className:`bi bi-patch-check-fill`}),` Official Payment Confirmed`]}),(0,a.jsx)(`h2`,{style:{fontSize:24,fontWeight:950,margin:`10px 0 4px`,color:`#0F172A`},children:P.school?.school_name||P.school?.name||`Official Payment Receipt`}),(0,a.jsxs)(`div`,{style:{color:`#64748B`,fontSize:13},children:[`Address: `,P.school?.address||`Registered Campus`]})]}),(0,a.jsxs)(`div`,{style:{textAlign:`right`},children:[(0,a.jsx)(`div`,{style:{fontSize:18,fontWeight:900,color:`#0F172A`},children:P.receipt_no}),(0,a.jsxs)(`div`,{style:{fontSize:12,color:`#64748B`,marginTop:2},children:[`Issued: `,new Date(P.paid_at).toLocaleString(`en-NG`,{dateStyle:`medium`,timeStyle:`short`})]})]})]}),(0,a.jsxs)(`div`,{className:`gq-receipt-grid`,children:[(0,a.jsxs)(`div`,{children:[(0,a.jsx)(`div`,{style:{fontSize:11,fontWeight:800,color:`#64748B`,textTransform:`uppercase`,marginBottom:6},children:`Student Credentials`}),(0,a.jsx)(`div`,{style:{fontSize:16,fontWeight:900,color:`#0F172A`},children:P.student?.name||`${P.student?.firstname||``} ${P.student?.surname||``}`}),(0,a.jsxs)(`div`,{style:{fontSize:13,color:`#475569`,marginTop:3},children:[`Admission Number: `,(0,a.jsx)(`strong`,{children:P.student?.reg_no})]}),P.student?.class&&(0,a.jsxs)(`div`,{style:{fontSize:13,color:`#475569`},children:[`Class / Level: `,(0,a.jsx)(`strong`,{children:P.student?.class})]})]}),(0,a.jsxs)(`div`,{children:[(0,a.jsx)(`div`,{style:{fontSize:11,fontWeight:800,color:`#64748B`,textTransform:`uppercase`,marginBottom:6},children:`Settlement Details`}),(0,a.jsxs)(`div`,{style:{fontSize:13,color:`#475569`},children:[`Date & Time: `,(0,a.jsx)(`strong`,{children:new Date(P.paid_at).toLocaleString()})]}),(0,a.jsxs)(`div`,{style:{fontSize:13,color:`#475569`},children:[`Payment Channel: `,(0,a.jsx)(`strong`,{children:`Direct Bank Transfer (Wema ALAT / NIP)`})]}),P.payer_name&&(0,a.jsxs)(`div`,{style:{fontSize:13,color:`#475569`},children:[`Payer: `,(0,a.jsx)(`strong`,{children:P.payer_name})]})]})]}),(0,a.jsxs)(`table`,{className:`gq-receipt-table`,children:[(0,a.jsx)(`thead`,{children:(0,a.jsxs)(`tr`,{children:[(0,a.jsx)(`th`,{children:`Fee Description`}),(0,a.jsx)(`th`,{children:`Academic Session & Term`}),(0,a.jsx)(`th`,{style:{textAlign:`right`},children:`Amount Settled`})]})}),(0,a.jsxs)(`tbody`,{children:[Array.isArray(P.items)&&P.items.length>0?P.items.map((e,t)=>(0,a.jsxs)(`tr`,{children:[(0,a.jsx)(`td`,{style:{fontWeight:800,color:`#0F172A`},children:e.name}),(0,a.jsx)(`td`,{style:{color:`#64748B`},children:[e.session,e.term].filter(Boolean).join(` - `)||`Current Period`}),(0,a.jsx)(`td`,{style:{textAlign:`right`,fontWeight:900,color:`#0F172A`},children:o(e.amount)})]},t)):(0,a.jsxs)(`tr`,{children:[(0,a.jsx)(`td`,{style:{fontWeight:800},children:`School Fee Installment`}),(0,a.jsx)(`td`,{style:{color:`#64748B`},children:`Current Term`}),(0,a.jsx)(`td`,{style:{textAlign:`right`,fontWeight:900,color:`#0F172A`},children:o(P.amount)})]}),(0,a.jsxs)(`tr`,{style:{background:`#F8FAFC`,borderTop:`2px solid #0F172A`},children:[(0,a.jsx)(`td`,{colSpan:2,style:{fontWeight:900,fontSize:15,textTransform:`uppercase`},children:`Total Amount Paid`}),(0,a.jsx)(`td`,{style:{textAlign:`right`,fontWeight:950,fontSize:20,color:`#047857`},children:o(P.amount)})]})]})]}),P.remaining_balance!==void 0&&(0,a.jsxs)(`div`,{style:{padding:`12px 18px`,background:P.remaining_balance>0?`#FFFBEB`:`#ECFDF5`,border:`1px solid ${P.remaining_balance>0?`#FDE68A`:`#A7F3D0`}`,borderRadius:12,fontSize:13.5,display:`flex`,justifyContent:`space-between`,alignItems:`center`},children:[(0,a.jsx)(`span`,{style:{color:`#334155`,fontWeight:700},children:`Remaining Student Balance:`}),(0,a.jsx)(`strong`,{style:{fontSize:16,color:P.remaining_balance>0?`#B45309`:`#047857`},children:P.remaining_balance>0?o(P.remaining_balance):`₦0.00 (Fully Settled)`})]}),(0,a.jsxs)(`div`,{className:`gq-receipt-actions`,children:[(0,a.jsxs)(`button`,{className:`gq-btn-download`,onClick:()=>{if(!P?.reference)return;let e=P.pdf_download_url||`/api/public/fee-payment/receipt/${encodeURIComponent(P.reference)}/pdf`;window.open(e,`_blank`)},children:[(0,a.jsx)(`i`,{className:`bi bi-file-earmark-pdf-fill`}),` Download Official PDF Receipt`]}),(0,a.jsxs)(`button`,{className:`gq-btn-print`,onClick:()=>{window.print()},children:[(0,a.jsx)(`i`,{className:`bi bi-printer-fill`}),` Print Receipt`]}),(0,a.jsxs)(`button`,{className:`gq-btn-reset`,onClick:()=>{F(null),L(null),z(``),B(``),j(null),N(null),m(``);let e=new URL(window.location.href);e.searchParams.delete(`reference`),e.searchParams.delete(`trxref`),window.history.replaceState({},``,e.toString())},children:[(0,a.jsx)(`i`,{className:`bi bi-arrow-clockwise`}),` Make Another Payment`]})]})]}):(0,a.jsxs)(`div`,{className:`gq-sec-grid`,children:[(0,a.jsxs)(`section`,{className:`gq-sec-card`,children:[(0,a.jsxs)(`div`,{className:`gq-sec-card-head`,children:[(0,a.jsxs)(`h2`,{className:`gq-sec-card-title`,children:[(0,a.jsx)(`i`,{className:`bi bi-credit-card-2-front-fill`}),` Payment Details`]}),(0,a.jsx)(`p`,{className:`gq-sec-card-sub`,children:`Enter your school code and student admission number.`})]}),(0,a.jsxs)(`div`,{className:`gq-sec-card-body`,children:[O&&(0,a.jsxs)(`div`,{className:`gq-alert-warn`,children:[(0,a.jsx)(`i`,{className:`bi bi-arrow-repeat spin`}),` Verifying secure transaction status...`]}),A&&(0,a.jsxs)(`div`,{className:`gq-alert-success`,children:[(0,a.jsx)(`i`,{className:`bi bi-check-circle-fill`}),` `,A]}),M&&(0,a.jsxs)(`div`,{className:`gq-alert-error`,children:[(0,a.jsx)(`i`,{className:`bi bi-exclamation-octagon-fill`}),` `,M]}),I?(0,a.jsxs)(`div`,{style:{background:`#F0FDF4`,border:`2px solid #10B981`,borderRadius:16,padding:`20px`,marginBottom:16},children:[(0,a.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,alignItems:`center`,marginBottom:14},children:[(0,a.jsxs)(`span`,{style:{background:`#10B981`,color:`#FFFFFF`,padding:`4px 12px`,borderRadius:999,fontSize:11,fontWeight:900,textTransform:`uppercase`,letterSpacing:`0.04em`},children:[(0,a.jsx)(`i`,{className:`bi bi-bank me-1`}),` Dedicated Wema Account Generated`]}),(0,a.jsx)(`button`,{type:`button`,onClick:()=>L(null),style:{background:`transparent`,border:`none`,color:`#64748B`,fontSize:18,cursor:`pointer`,padding:0},title:`Close / Pay another way`,children:(0,a.jsx)(`i`,{className:`bi bi-x-circle-fill`})})]}),(0,a.jsxs)(`div`,{style:{textAlign:`center`,margin:`12px 0 18px`},children:[(0,a.jsx)(`div`,{style:{fontSize:12,color:`#166534`,fontWeight:800,textTransform:`uppercase`,letterSpacing:`0.04em`},children:`Transfer Exact Amount To:`}),(0,a.jsx)(`div`,{style:{fontSize:30,fontWeight:950,color:`#0F172A`,letterSpacing:`0.05em`,margin:`6px 0`,fontFamily:`monospace`},children:I.account_number}),(0,a.jsxs)(`button`,{type:`button`,onClick:()=>{navigator.clipboard.writeText(I.account_number),H(!0),setTimeout(()=>H(!1),2500)},style:{background:V?`#10B981`:`#FFFFFF`,color:V?`#FFFFFF`:`#0F172A`,border:`1.5px solid #CBD5E1`,borderRadius:8,padding:`6px 14px`,fontSize:12.5,fontWeight:800,cursor:`pointer`,transition:`all 0.15s ease`},children:[(0,a.jsx)(`i`,{className:`bi ${V?`bi-check-lg`:`bi-clipboard`} me-1`}),V?`Account Number Copied!`:`Copy Account Number`]})]}),(0,a.jsxs)(`div`,{style:{background:`#FFFFFF`,borderRadius:12,padding:`14px 16px`,border:`1px solid #E2E8F0`,marginBottom:18,fontSize:13},children:[(0,a.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,marginBottom:8},children:[(0,a.jsx)(`span`,{style:{color:`#64748B`,fontWeight:600},children:`Bank Name:`}),(0,a.jsx)(`strong`,{style:{color:`#0F172A`,fontWeight:800},children:I.bank_name||`Wema Bank / ALAT`})]}),(0,a.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,marginBottom:8},children:[(0,a.jsx)(`span`,{style:{color:`#64748B`,fontWeight:600},children:`Beneficiary Name:`}),(0,a.jsx)(`strong`,{style:{color:`#0F172A`,fontWeight:800},children:I.account_name})]}),(0,a.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,marginBottom:8},children:[(0,a.jsx)(`span`,{style:{color:`#64748B`,fontWeight:600},children:`Exact Payable Amount:`}),(0,a.jsx)(`strong`,{style:{color:`#047857`,fontWeight:950,fontSize:15},children:o(I.amount)})]}),(0,a.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`},children:[(0,a.jsx)(`span`,{style:{color:`#64748B`,fontWeight:600},children:`Payment Reference:`}),(0,a.jsx)(`strong`,{style:{color:`#334155`,fontFamily:`monospace`,fontSize:11},children:R})]})]}),(0,a.jsx)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:10},children:(0,a.jsx)(`button`,{type:`button`,className:`gq-btn-download`,style:{width:`100%`,justifyContent:`center`,minHeight:48},disabled:O,onClick:()=>{k(!0),N(null),j(null),r.get(`/public/fee-payment/verify/${encodeURIComponent(R)}`).then(e=>{e.data?.receipt?(F({...e.data.receipt,pdf_download_url:e.data.pdf_download_url}),L(null)):j(`Payment verification in progress. Interbank NIP transfers take 30-60 seconds to clear.`)}).catch(e=>{N(e?.response?.data?.message||`Transfer not detected yet. If you have sent the funds, please allow 1 minute for bank clearing.`)}).finally(()=>k(!1))},children:O?(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)(`span`,{className:`spinner-border spinner-border-sm me-1`}),`Verifying Bank Clearing…`]}):(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)(`i`,{className:`bi bi-patch-check-fill`}),`I Have Made This Transfer (Verify Payment)`]})})})]}):(0,a.jsxs)(a.Fragment,{children:[(0,a.jsxs)(`div`,{className:`gq-form-group`,children:[(0,a.jsx)(`label`,{className:`gq-form-label`,children:`School ID / Code / Reg No`}),(0,a.jsx)(`input`,{className:`gq-input`,value:l,onChange:e=>u(e.target.value),placeholder:`Enter school code e.g. SCH-001 or school ID`}),(0,a.jsx)(`div`,{className:`gq-form-hint`,children:ne?`Locating school...`:`Enter the unique identification code assigned to your school.`})]}),y&&(0,a.jsxs)(`div`,{className:`gq-school-profile`,children:[(0,a.jsx)(`div`,{className:`gq-school-avatar`,children:y.name.charAt(0)}),(0,a.jsxs)(`div`,{children:[(0,a.jsxs)(`div`,{className:`gq-school-meta-title`,children:[(0,a.jsx)(`i`,{className:`bi bi-patch-check-fill`}),` Verified Beneficiary School`]}),(0,a.jsx)(`h3`,{className:`gq-school-name`,children:y.name}),(0,a.jsx)(`div`,{className:`gq-school-address`,children:y.address||`Official School Account`})]})]}),(0,a.jsxs)(`div`,{className:`gq-form-group`,children:[(0,a.jsx)(`label`,{className:`gq-form-label`,children:`Student Admission Number / Reg No`}),(0,a.jsx)(`input`,{className:`gq-input`,value:d,onChange:e=>f(e.target.value),placeholder:`e.g. STU/2026/001`,disabled:!y}),(0,a.jsx)(`div`,{className:`gq-form-hint`,children:y?w?`Validating student admission records...`:`Enter the admission number assigned to your child.`:`Enter school code above first.`})]}),(0,a.jsxs)(`div`,{className:`gq-form-group`,children:[(0,a.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,alignItems:`center`},children:[(0,a.jsx)(`label`,{className:`gq-form-label`,style:{marginBottom:0},children:`Amount to Pay (₦)`}),x?.installment_plan?.enabled&&(0,a.jsxs)(`span`,{style:{fontSize:11,fontWeight:700,color:`#1D4ED8`,background:`#DBEAFE`,padding:`2px 8px`,borderRadius:6},children:[`Min `,x.installment_plan.min_initial_percent,`% Initial Installment`]})]}),G?.enabled&&G.discount_amount>0&&(0,a.jsxs)(`div`,{style:{background:`linear-gradient(135deg, #ECFDF5 0%, #D1FAE5 100%)`,border:`1.5px solid #6EE7B7`,borderRadius:12,padding:`12px 14px`,marginTop:10,marginBottom:10,display:`flex`,alignItems:`flex-start`,gap:12,boxShadow:`0 2px 8px rgba(5, 150, 105, 0.08)`},children:[(0,a.jsx)(`div`,{style:{width:34,height:34,borderRadius:10,background:`#059669`,color:`#FFFFFF`,display:`flex`,alignItems:`center`,justifyContent:`center`,fontSize:16,flexShrink:0},children:(0,a.jsx)(`i`,{className:`bi bi-tag-fill`})}),(0,a.jsxs)(`div`,{children:[(0,a.jsxs)(`div`,{style:{fontWeight:800,fontSize:13,color:`#065F46`,display:`flex`,alignItems:`center`,gap:6,flexWrap:`wrap`},children:[(0,a.jsx)(`span`,{children:`🎉 Full-Payment Early Incentive Active!`}),(0,a.jsxs)(`span`,{style:{background:`#047857`,color:`#FFFFFF`,fontSize:10.5,fontWeight:800,padding:`2px 8px`,borderRadius:999},children:[`Save `,G.formatted_discount,` (`,o(G.discount_amount),`)`]})]}),(0,a.jsx)(`div`,{style:{fontSize:12,color:`#047857`,marginTop:3,lineHeight:1.45},children:G.message||`Pay in full upfront for only ${o(G.discounted_payable_amount)} instead of ${o(G.original_balance)} to clear your term fees.`})]})]}),x?.installment_plan?.enabled&&(0,a.jsxs)(`div`,{style:{background:`#EFF6FF`,border:`1px solid #BFDBFE`,borderRadius:10,padding:`10px 12px`,marginTop:8,marginBottom:8,fontSize:12,color:`#1E40AF`,display:`flex`,alignItems:`flex-start`,gap:8},children:[(0,a.jsx)(`i`,{className:`bi bi-info-circle-fill text-primary`,style:{fontSize:15,marginTop:1,flexShrink:0}}),(0,a.jsx)(`span`,{children:x.installment_plan.message||`Minimum initial payment required is ${o(x.installment_plan.min_payable_now)}.`})]}),(0,a.jsx)(`input`,{className:`gq-input`,type:`number`,min:x?.installment_plan?.enabled?x.installment_plan.min_payable_now:100,max:U>0?U:void 0,value:p,onChange:e=>m(e.target.value),placeholder:`Enter amount in Naira`,disabled:!x,style:{marginTop:6}}),U>0&&(0,a.jsx)(`div`,{className:`gq-amount-presets`,children:x?.installment_plan?.presets&&x.installment_plan.presets.length>0?x.installment_plan.presets.map((e,t)=>{let n=p===String(e.amount),r=!!e.discount_applied;return(0,a.jsxs)(`button`,{type:`button`,className:`gq-preset-btn`,style:n?{background:r?`#047857`:`#0F2744`,color:`#FFFFFF`,borderColor:r?`#047857`:`#0F2744`,boxShadow:r?`0 2px 8px rgba(4, 120, 87, 0.3)`:void 0}:r?{background:`#ECFDF5`,color:`#065F46`,borderColor:`#6EE7B7`,fontWeight:800}:void 0,onClick:()=>m(String(e.amount)),children:[r&&(0,a.jsx)(`i`,{className:`bi bi-patch-check-fill me-1 text-success`}),e.label,` (`,o(e.amount),`)`]},t)}):(0,a.jsxs)(a.Fragment,{children:[(0,a.jsxs)(`button`,{type:`button`,className:`gq-preset-btn`,onClick:()=>m(String(U)),children:[`Pay Full Balance (`,o(U),`)`]}),U>=200&&(0,a.jsxs)(`button`,{type:`button`,className:`gq-preset-btn`,onClick:()=>m(String(Math.round(U/2))),children:[`Pay 50% (`,o(Math.round(U/2)),`)`]})]})})]}),(0,a.jsxs)(`div`,{className:`gq-form-row`,children:[(0,a.jsxs)(`div`,{className:`gq-form-group`,children:[(0,a.jsx)(`label`,{className:`gq-form-label`,children:`Payer Email (for PDF Receipt)`}),(0,a.jsx)(`input`,{className:`gq-input`,type:`email`,value:h,onChange:e=>ee(e.target.value),placeholder:`parent@example.com`})]}),(0,a.jsxs)(`div`,{className:`gq-form-group`,children:[(0,a.jsx)(`label`,{className:`gq-form-label`,children:`Phone Number`}),(0,a.jsx)(`input`,{className:`gq-input`,type:`tel`,value:v,onChange:e=>te(e.target.value),placeholder:`0801 234 5678`})]})]}),(0,a.jsxs)(`div`,{className:`gq-form-group`,children:[(0,a.jsx)(`label`,{className:`gq-form-label`,children:`Payer Full Name`}),(0,a.jsx)(`input`,{className:`gq-input`,value:g,onChange:e=>_(e.target.value),placeholder:`Parent / Sponsor Name`})]}),W>=100&&(0,a.jsxs)(`div`,{style:{background:`#F8FAFC`,border:`1px solid #E2E8F0`,borderRadius:12,padding:`14px 16px`,marginBottom:16},children:[(0,a.jsx)(`div`,{style:{fontSize:11.5,fontWeight:800,textTransform:`uppercase`,color:`#64748B`,marginBottom:8,letterSpacing:`0.04em`},children:`Payment Summary & Settlement Breakdown`}),K&&G&&(0,a.jsxs)(a.Fragment,{children:[(0,a.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,fontSize:13,color:`#64748B`,marginBottom:4},children:[(0,a.jsx)(`span`,{children:`Original Term Balance:`}),(0,a.jsx)(`span`,{style:{textDecoration:`line-through`},children:o(G.original_balance)})]}),(0,a.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,fontSize:13,color:`#047857`,marginBottom:4,fontWeight:700},children:[(0,a.jsxs)(`span`,{style:{display:`flex`,alignItems:`center`,gap:4},children:[(0,a.jsx)(`i`,{className:`bi bi-tag-fill`}),` Full-Payment Early Discount (`,G.formatted_discount,`):`]}),(0,a.jsxs)(`span`,{children:[`-`,o(G.discount_amount)]})]})]}),(0,a.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,fontSize:13,color:`#334155`,marginBottom:4},children:[(0,a.jsx)(`span`,{children:`Base Tuition Amount:`}),(0,a.jsx)(`span`,{style:{fontWeight:700},children:o(W)})]}),J&&(0,a.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,fontSize:13,color:`#334155`,marginBottom:4},children:[(0,a.jsxs)(`span`,{style:{display:`flex`,alignItems:`center`,gap:4},children:[(0,a.jsx)(`i`,{className:`bi bi-bank text-primary`}),` Bank Processing Charge:`]}),(0,a.jsxs)(`span`,{style:{fontWeight:700,color:`#1E40AF`},children:[`+`,o(X)]})]}),Y&&(0,a.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,fontSize:13,color:`#334155`,marginBottom:4},children:[(0,a.jsxs)(`span`,{style:{display:`flex`,alignItems:`center`,gap:4},children:[(0,a.jsx)(`i`,{className:`bi bi-cpu text-primary`}),` Platform Electronic Access Fee:`]}),(0,a.jsxs)(`span`,{style:{fontWeight:700,color:`#1E40AF`},children:[`+`,o(Z)]})]}),(0,a.jsx)(`div`,{style:{height:1,background:`#CBD5E1`,margin:`8px 0`}}),(0,a.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,fontSize:15,fontWeight:900,color:`#0F172A`},children:[(0,a.jsx)(`span`,{children:`Total Amount Payable:`}),(0,a.jsx)(`span`,{style:{color:`#047857`},children:o(Q)})]}),(0,a.jsx)(`div`,{style:{fontSize:11.5,color:K?`#065F46`:`#64748B`,marginTop:6,lineHeight:1.4,fontWeight:K?700:400},children:K&&G?`🎉 Verified Early Full-Payment: Your payment of ${o(W)} will fully clear and settle the ${o(G.original_balance)} student fee balance.`:J?`✓ Verified direct settlement. School receives 100% of your tuition payment.`:`✓ Zero additional bank surcharge. School covers gateway processing fees.`})]}),(0,a.jsx)(`button`,{className:`gq-pay-btn`,disabled:!$,onClick:()=>ae(),children:E?(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)(`span`,{className:`spinner-border spinner-border-sm`}),`Generating Payment Details…`]}):(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)(`i`,{className:`bi bi-shield-lock-fill`}),`Make Payment `,W>=100?`— ${o(Q)}`:``]})}),(0,a.jsxs)(`div`,{className:`gq-pay-notice`,children:[(0,a.jsx)(`i`,{className:`bi bi-lock me-1`}),`Your payment is securely processed through encrypted banking channels.`]})]})]})]}),(0,a.jsxs)(`aside`,{className:`gq-sec-card`,children:[(0,a.jsxs)(`div`,{className:`gq-sec-card-head`,children:[(0,a.jsxs)(`h2`,{className:`gq-sec-card-title`,children:[(0,a.jsx)(`i`,{className:`bi bi-person-lines-fill`}),` Student Fee Assessment`]}),(0,a.jsx)(`p`,{className:`gq-sec-card-sub`,children:`Current term charges and balance statement.`})]}),(0,a.jsx)(`div`,{className:`gq-sec-card-body`,children:x?(0,a.jsxs)(a.Fragment,{children:[(0,a.jsxs)(`div`,{style:{background:`#F8FAFC`,border:`1px solid #E2E8F0`,borderRadius:14,padding:`14px 16px`,marginBottom:18,display:`flex`,gap:12,alignItems:`center`},children:[(0,a.jsx)(`div`,{style:{width:44,height:44,borderRadius:12,background:`#0F2744`,color:`#FFFFFF`,display:`flex`,alignItems:`center`,justifyContent:`center`,fontWeight:900,fontSize:18},children:x.student?.name?.charAt(0)||`S`}),(0,a.jsxs)(`div`,{children:[(0,a.jsx)(`div`,{style:{fontWeight:900,fontSize:15,color:`#0F2744`},children:x.student?.name}),(0,a.jsxs)(`div`,{style:{fontSize:12.5,color:`#64748B`},children:[`Reg: `,(0,a.jsx)(`strong`,{children:x.student?.reg_no}),` • Class: `,(0,a.jsx)(`strong`,{children:[x.student?.class,x.student?.section].filter(Boolean).join(` - `)||`Class not set`})]})]})]}),(0,a.jsxs)(`div`,{className:`gq-summary-box`,children:[(0,a.jsxs)(`div`,{className:`gq-stat-tile`,children:[(0,a.jsx)(`div`,{className:`gq-stat-label`,children:`Total Fee`}),(0,a.jsx)(`div`,{className:`gq-stat-val`,children:o(x.summary?.total_amount||0)})]}),(0,a.jsxs)(`div`,{className:`gq-stat-tile`,children:[(0,a.jsx)(`div`,{className:`gq-stat-label`,children:`Paid`}),(0,a.jsx)(`div`,{className:`gq-stat-val gq-stat-val-success`,children:o(x.summary?.amount_paid||0)})]}),(0,a.jsxs)(`div`,{className:`gq-stat-tile`,children:[(0,a.jsx)(`div`,{className:`gq-stat-label`,children:`Owing`}),(0,a.jsx)(`div`,{className:`gq-stat-val gq-stat-val-danger`,children:o(x.summary?.balance||0)})]})]}),(0,a.jsx)(`div`,{style:{fontSize:12,fontWeight:800,textTransform:`uppercase`,color:`#64748B`,marginBottom:8,letterSpacing:`0.05em`},children:`Itemized Fee Breakdown`}),(0,a.jsx)(`div`,{className:`gq-fee-list`,children:!Array.isArray(x.fees)||x.fees.length===0?(0,a.jsxs)(`div`,{style:{padding:14,background:`#F0FDF4`,border:`1px solid #BBF7D0`,borderRadius:12,color:`#166534`,fontSize:13,display:`flex`,alignItems:`center`,gap:8},children:[(0,a.jsx)(`i`,{className:`bi bi-check-circle-fill`}),(0,a.jsx)(`span`,{children:`This student currently has zero outstanding balance.`})]}):x.fees.map(e=>(0,a.jsxs)(`div`,{className:`gq-fee-item`,children:[(0,a.jsxs)(`div`,{children:[(0,a.jsx)(`div`,{className:`gq-fee-name`,children:e.name}),(0,a.jsx)(`div`,{className:`gq-fee-meta`,children:[e.term,e.session].filter(Boolean).join(` - `)||`Current Term`})]}),(0,a.jsx)(`div`,{className:`gq-fee-balance`,children:o(e.balance)})]},e.id))}),(0,a.jsxs)(`div`,{style:{marginTop:18,padding:`12px 14px`,background:`#F8FAFC`,border:`1px solid #E2E8F0`,borderRadius:12,fontSize:12,color:`#475569`,lineHeight:1.5},children:[(0,a.jsx)(`i`,{className:`bi bi-shield-check text-success me-1`}),(0,a.jsx)(`strong`,{children:`Bursary Guarantee:`}),` Upon successful payment, your official receipt is issued immediately and your payment is recorded in the school bursary database.`]})]}):(0,a.jsxs)(`div`,{className:`text-center py-4 text-muted`,children:[(0,a.jsx)(`i`,{className:`bi bi-search fs-2 d-block mb-2 text-secondary`}),(0,a.jsx)(`strong`,{children:`No student selected`}),(0,a.jsx)(`div`,{style:{fontSize:13,marginTop:4},children:`Enter your school code and admission number on the left to display the student fee schedule.`})]})})]})]})]})]})}export{s as default};