import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{p as t}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as n,E as r,P as i,d as ee,f as te,l as ne,u as re}from"./index-D6TxbaCx.js";var a=e(),o=t();function ie(){let e=new Date().getHours();return e<12?`Good morning`:e<17?`Good afternoon`:`Good evening`}function s(e){let t=e?.response?.status,n=e?.response?.data;return t===409?n?.message??n?.error??`This item already exists.`:t===404?n?.message??`Not found.`:t===422?n?.message??`Validation error.`:n?.message??e?.message??`Something went wrong.`}function c(e){return Number(e??0).toLocaleString(`en-NG`,{style:`currency`,currency:`NGN`,maximumFractionDigits:0})}function l(){let{showSuccess:e,showError:t}=ne(),[l,ae]=(0,a.useState)(!1),[oe,se]=(0,a.useState)(!0),[u,d]=(0,a.useState)(!0),[f,ce]=(0,a.useState)([]),[p,le]=(0,a.useState)([]),[m,ue]=(0,a.useState)([]),[h,g]=(0,a.useState)([]),[_,de]=(0,a.useState)(1),[v,fe]=(0,a.useState)(1),[y,pe]=(0,a.useState)(0),[b,x]=(0,a.useState)(``),[S,C]=(0,a.useState)(``),[w,T]=(0,a.useState)(``),[E,D]=(0,a.useState)(``),[O,k]=(0,a.useState)(null),A=e=>O===e,[me,j]=(0,a.useState)(!1),[he,M]=(0,a.useState)(!1),[N,ge]=(0,a.useState)(``),[P,F]=(0,a.useState)(``),[I,L]=(0,a.useState)(``),[R,z]=(0,a.useState)(``),[B,V]=(0,a.useState)(``),[H,U]=(0,a.useState)(null),[W,G]=(0,a.useState)(``),[K,q]=(0,a.useState)(``),[J,Y]=(0,a.useState)(``),[X,Z]=(0,a.useState)(``),[_e,ve]=(0,a.useState)(``);(0,a.useEffect)(()=>{let e=window.setTimeout(()=>se(!1),120);return()=>window.clearTimeout(e)},[]);async function Q(e){let n=e??_;try{d(!0);let e=(await i.get(`/fee-types`,{params:{page:n,search:b.trim()||void 0,section_id:S||void 0,session_id:w||void 0,term_id:E||void 0}})).data,t=e?.feeTypes?.data??[];g(Array.isArray(t)?t:[]),ce(Array.isArray(e.sections)?e.sections:[]),le(Array.isArray(e.sessions)?e.sessions:[]),ue(Array.isArray(e.terms)?e.terms:[]),de(e?.feeTypes?.current_page??n),fe(e?.feeTypes?.last_page??1),pe(e?.feeTypes?.total??t.length??0)}catch(e){console.error(e),t(s(e)),g([])}finally{d(!1)}}(0,a.useEffect)(()=>{Q(1)},[]),(0,a.useEffect)(()=>{let e=window.setTimeout(()=>{Q(1)},250);return()=>window.clearTimeout(e)},[b,S,w,E]);let $=(0,a.useMemo)(()=>{let e=h.reduce((e,t)=>e+Number(t.amount??0),0);return{count:h.length,sum:e}},[h]),ye=e=>e.section?.name??f.find(t=>t.id===e.section_id)?.name??`-`,be=e=>e.session?.name??p.find(t=>t.id===e.session_id)?.name??`-`,xe=e=>e.term?.name??m.find(t=>t.id===e.term_id)?.name??`-`;function Se(){ge(S||``),F(w||``),L(E||``),z(``),V(``),j(!0)}async function Ce(){if(!N||!P||!I)return t(`Please select Section, Session and Term.`);let n=R.trim();if(!n)return t(`Please enter fee name.`);let r=Number(B);if(Number.isNaN(r)||r<0)return t(`Enter a valid amount.`);try{k(`fee:create`),e((await i.post(`/fee-types`,{section_id:Number(N),session_id:Number(P),term_id:Number(I),name:n,amount:r})).data?.message??`Fee type created successfully.`),j(!1),await Q(1)}catch(e){console.error(e),t(s(e))}finally{k(null)}}async function we(e){try{k(`fee:load:${e}`);let t=(await i.get(`/fee-types/${e}`)).data;U(t.id),G(t.section_id??``),q(t.session_id??``),Y(t.term_id??``),Z(t.name??``),ve(String(t.amount??0)),M(!0)}catch(e){console.error(e),t(s(e))}finally{k(null)}}async function Te(){if(!H)return;if(!W||!K||!J)return t(`Please select Section, Session and Term.`);let n=X.trim();if(!n)return t(`Please enter fee name.`);let r=Number(_e);if(Number.isNaN(r)||r<0)return t(`Enter a valid amount.`);try{k(`fee:update:${H}`),e((await i.put(`/fee-types/${H}`,{section_id:Number(W),session_id:Number(K),term_id:Number(J),name:n,amount:r})).data?.message??`Fee type updated successfully.`),M(!1),U(null),await Q(_)}catch(e){console.error(e),t(s(e))}finally{k(null)}}async function Ee(n){if(window.confirm(`Delete this fee type? This cannot be undone.`))try{k(`fee:delete:${n}`),e((await i.delete(`/fee-types/${n}`)).data?.message??`Fee type deleted successfully.`),await Q(Math.min(_,v))}catch(e){console.error(e),t(s(e))}finally{k(null)}}let De=_>1&&!u,Oe=_<v&&!u,ke=(b.trim()?1:0)+(S?1:0)+(w?1:0)+(E?1:0);return(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)(`style`,{children:`
        /* ======= FeeStructurePage - Modern SaaS style ======= */
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');
        .db-main {
          background: #F8FAFC;
          min-height: 100vh;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          padding: 24px 28px 0;
        }

        .db-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 18px;
          padding: 32px 36px;
          position: relative;
          overflow: hidden;
          margin-bottom: 24px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
        }
        .db-hero-glow {
          position: absolute;
          top: -60px;
          right: -60px;
          width: 320px;
          height: 320px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.15) 0%, transparent 65%);
          pointer-events: none;
        }
        .db-hero-glow2 {
          position: absolute;
          bottom: -40px;
          left: 30%;
          width: 200px;
          height: 200px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(37, 99, 235, 0.10) 0%, transparent 70%);
          pointer-events: none;
        }
        .db-hero-inner {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 32px;
          flex-wrap: wrap;
        }

        .db-session-badge {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.20);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius: 100px;
          padding: 4px 12px;
          margin-bottom: 12px;
        }
        .db-session-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #10B981;
          animation: dbPulse 2s ease infinite;
        }
        @keyframes dbPulse {
          0%,100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.4; transform: scale(1.5); }
        }

        .db-greeting {
          font-size: 26px;
          font-weight: 800;
          color: #fff;
          line-height: 1.1;
          margin-bottom: 8px;
        }
        .db-greeting em { font-style: normal; color: #FBBF24; }

        .db-hero-sub {
          font-size: 13.5px;
          color: #CBD5E1;
          line-height: 1.6;
          max-width: 560px;
          margin-bottom: 20px;
        }

        .db-hero-btns {
          display: flex;
          gap: 10px;
          flex-wrap: wrap;
        }

        .db-btn-gold {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 9px 18px;
          font-size: 13px;
          font-weight: 700;
          color: #FFFFFF;
          background: #D97706;
          border: none;
          border-radius: 10px;
          cursor: pointer;
          transition: all 0.2s ease;
          text-decoration: none;
          white-space: nowrap;
        }
        .db-btn-gold:hover { background: #B45309; transform: translateY(-1px); color: #FFFFFF; }
        .db-btn-gold:disabled { opacity: 0.55; cursor: not-allowed; transform: none; }

        .db-btn-outline {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 9px 18px;
          font-size: 13px;
          font-weight: 600;
          color: #FFFFFF;
          background: rgba(255, 255, 255, 0.10);
          border: 1px solid rgba(255, 255, 255, 0.20);
          border-radius: 10px;
          cursor: pointer;
          transition: all 0.2s ease;
          white-space: nowrap;
        }
        .db-btn-outline:hover { background: rgba(255, 255, 255, 0.18); color: #fff; }
        .db-btn-outline:disabled { opacity: 0.55; cursor: not-allowed; }

        .db-hero-stat-card {
          background: rgba(255, 255, 255, 0.08);
          border: 1px solid rgba(255, 255, 255, 0.15);
          backdrop-filter: blur(8px);
          border-radius: 14px;
          padding: 20px 24px;
          min-width: 260px;
        }
        .db-hero-stat-row { display: flex; flex-direction: column; gap: 10px; }
        .db-hero-stat-item { display: flex; justify-content: space-between; align-items: center; gap: 16px; }
        .db-hero-stat-label { font-size: 12px; font-weight: 400; color: #CBD5E1; }
        .db-hero-stat-val { font-size: 18px; font-weight: 800; color: #FBBF24; }
        
        .db-hero-stat-sep { height: 1px; background: rgba(255, 255, 255, 0.06); }

        .db-grid {
          display: grid;
          grid-template-columns: 1fr;
          gap: 18px;
          margin-bottom: 24px;
        }

        .db-panel {
          background: var(--bs-body-bg, #fff);
          border: 1px solid var(--bs-border-color, #ede8e0);
          border-radius: var(--bs-border-radius-lg, 14px);
          overflow: hidden;
        }

        .db-panel-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 18px 20px;
          border-bottom: 1px solid rgba(0, 0, 0, 0.06);
          gap: 12px;
          flex-wrap: wrap;
        }

        .db-panel-title-group { display: flex; align-items: center; gap: 12px; min-width: 240px; }
        .db-panel-icon {
          width: 36px;
          height: 36px;
          border-radius: 9px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: var(--pi, #fef3c7);
          color: var(--pc, #b45309);
          flex-shrink: 0;
        }
        .db-panel-title {
          font-family: "Lora", serif;
          font-size: 16px;
          font-weight: 700;
          color: #1a1a2e;
          margin: 0;
        }
        .db-panel-sub { font-size: 11.5px; font-weight: 300; color: #9a8a7a; margin: 0; }

        .db-toolbar {
          padding: 14px 20px;
          display: flex;
          flex-wrap: wrap;
          align-items: center;
          justify-content: space-between;
          gap: 10px;
        }

        .db-input, .db-select {
          height: 40px;
          border-radius: 10px;
          border: 1px solid #e5ddd3;
          background: #fff;
          font-size: 13px;
          color: #1a1a2e;
          padding: 0 12px;
          outline: none;
          transition: box-shadow 0.2s, border-color 0.2s;
        }
        .db-input:focus, .db-select:focus {
          border-color: rgba(201, 168, 76, 0.65);
          box-shadow: 0 0 0 4px rgba(201, 168, 76, 0.18);
        }

        .db-input-group {
          display: flex;
          align-items: center;
          gap: 10px;
          flex-wrap: wrap;
        }

        .db-chip {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          font-size: 11px;
          font-weight: 500;
          letter-spacing: 0.1em;
          text-transform: uppercase;
          border-radius: 999px;
          padding: 6px 10px;
          border: 1px solid rgba(0,0,0,0.08);
          background: #faf8f5;
          color: #7a6a5a;
          white-space: nowrap;
        }

        .db-table {
          width: 100%;
          border-collapse: collapse;
        }
        .db-table th {
          padding: 10px 16px;
          font-size: 11px;
          font-weight: 500;
          letter-spacing: 0.1em;
          text-transform: uppercase;
          color: #9a8a7a;
          background: #faf8f5;
          border-bottom: 1px solid rgba(0, 0, 0, 0.06);
          text-align: left;
          white-space: nowrap;
        }
        .db-table td {
          padding: 13px 16px;
          font-size: 13.5px;
          color: #4a4a5a;
          border-bottom: 1px solid rgba(0, 0, 0, 0.06);
          vertical-align: middle;
        }
        .db-table tbody tr { transition: background 0.15s; }
        .db-table tbody tr:hover { background: #faf8f5; }

        .db-pill {
          display: inline-flex;
          align-items: center;
          font-size: 12px;
          font-weight: 500;
          padding: 3px 10px;
          border-radius: 999px;
          background: rgba(30, 64, 175, 0.08);
          color: #1e40af;
          border: 1px solid rgba(30, 64, 175, 0.12);
        }

        .db-pill--gold {
          background: rgba(180, 83, 9, 0.08);
          color: #b45309;
          border-color: rgba(180, 83, 9, 0.14);
        }

        .db-actions-cell {
          display: inline-flex;
          gap: 8px;
          justify-content: flex-end;
          width: 100%;
          flex-wrap: wrap;
        }

        .db-sm-btn {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 7px 10px;
          font-size: 12.5px;
          border-radius: 10px;
          border: 1px solid #e5ddd3;
          background: #f5f1eb;
          color: #1a1a2e;
          cursor: pointer;
          transition: background 0.2s, transform 0.2s;
          white-space: nowrap;
        }
        .db-sm-btn:hover:not(:disabled) { background: #ede8e0; transform: translateY(-1px); }
        .db-sm-btn:disabled { opacity: 0.55; cursor: not-allowed; transform: none; }

        .db-sm-btn--danger {
          background: rgba(220, 38, 38, 0.08);
          border-color: rgba(220, 38, 38, 0.18);
          color: #b91c1c;
        }
        .db-sm-btn--danger:hover:not(:disabled) { background: rgba(220, 38, 38, 0.12); }

        .db-pagination {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 14px 20px;
          flex-wrap: wrap;
          gap: 10px;
          border-top: 1px solid rgba(0, 0, 0, 0.06);
        }

        .db-page-info {
          font-size: 12px;
          font-weight: 300;
          color: #9a8a7a;
        }

        .db-page-btns { display: flex; align-items: center; gap: 6px; }

        .db-page-btn {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 6px 12px;
          font-size: 12.5px;
          font-weight: 400;
          color: #7a6a5a;
          background: #f5f1eb;
          border: 1px solid #e5ddd3;
          border-radius: var(--bs-border-radius, 9px);
          cursor: pointer;
          transition: background 0.2s, color 0.2s;
          white-space: nowrap;
        }
        .db-page-btn:hover:not(:disabled) { background: #ede8e0; color: #1a1a2e; }
        .db-page-btn:disabled { opacity: 0.45; cursor: not-allowed; }
        .db-page-current { padding: 6px 10px; font-size: 12px; color: #9a8a7a; }

        .db-table-empty {
          padding: 48px 16px;
          text-align: center;
          color: #b5a090;
          font-size: 13.5px;
        }

        .db-alert {
          display: flex;
          align-items: flex-start;
          gap: 10px;
          background: #fff7ed;
          border: 1px solid #fed7aa;
          border-radius: var(--bs-border-radius, 10px);
          padding: 11px 14px;
          font-size: 13px;
          color: #9a3412;
          margin: 12px 20px 0;
        }

        /* Modal */
        .db-modal-overlay {
          position: fixed;
          inset: 0;
          display: flex;
          align-items: center;
          justify-content: center;
          background: rgba(0,0,0,0.45);
          backdrop-filter: blur(6px);
          z-index: 1100;
          padding: 12px;
        }
        .db-modal-card {
          width: 100%;
          max-width: 780px;
          border-radius: 16px;
          border: 1px solid rgba(0,0,0,0.06);
          background: #fff;
          box-shadow: 0 22px 70px rgba(0,0,0,0.25);
          overflow: hidden;
        }
        .db-modal-head {
          padding: 18px 20px;
          border-bottom: 1px solid rgba(0,0,0,0.06);
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: 12px;
        }
        .db-modal-body { padding: 18px 20px 20px; }
        .db-modal-title {
          font-family: "Lora", serif;
          font-size: 16px;
          font-weight: 700;
          color: #1a1a2e;
          margin: 0 0 4px;
        }
        .db-modal-sub { margin: 0; font-size: 12px; color: #9a8a7a; }

        .db-form-label { font-size: 12px; font-weight: 600; color: #1a1a2e; margin-bottom: 6px; display: block; }
        .db-row { display: grid; grid-template-columns: repeat(12, 1fr); gap: 12px; }
        .db-col-12 { grid-column: span 12; }
        .db-col-4 { grid-column: span 4; }
        .db-col-8 { grid-column: span 8; }
        @media (max-width: 767.98px) {
          .db-col-4, .db-col-8 { grid-column: span 12; }
          .db-main { padding: 18px 14px 0; }
          .db-hero { padding: 24px 20px; }
        }

        .db-modal-actions {
          display: flex;
          justify-content: flex-end;
          gap: 10px;
          flex-wrap: wrap;
          margin-top: 14px;
        }

        @keyframes dbSpin { to { transform: rotate(360deg); } }
      `}),(0,o.jsx)(te,{sidebarOpen:l,setSidebarOpen:ae}),(0,o.jsx)(n,{title:`Fee Structure`}),(0,o.jsx)(`div`,{className:`container-fluid`,children:(0,o.jsxs)(`div`,{className:`row`,children:[(0,o.jsx)(ee,{sidebarOpen:l}),(0,o.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto db-main`,children:[oe&&(0,o.jsx)(r,{message:`Loading fee structure...`}),(0,o.jsxs)(`div`,{className:`db-hero`,children:[(0,o.jsx)(`div`,{className:`db-hero-glow`,"aria-hidden":`true`}),(0,o.jsx)(`div`,{className:`db-hero-glow2`,"aria-hidden":`true`}),(0,o.jsxs)(`div`,{className:`db-hero-inner`,children:[(0,o.jsxs)(`div`,{children:[(0,o.jsxs)(`div`,{className:`db-session-badge`,title:`Fee Structure`,children:[(0,o.jsx)(`span`,{className:`db-session-dot`}),`Fee Structure • Manage payments`]}),(0,o.jsxs)(`h1`,{className:`db-greeting`,children:[ie(),`, `,(0,o.jsx)(`em`,{children:`Admin.`})]}),(0,o.jsxs)(`p`,{className:`db-hero-sub`,children:[`Create and manage fee types per `,(0,o.jsx)(`b`,{children:`Section`}),`, `,(0,o.jsx)(`b`,{children:`Session`}),` and `,(0,o.jsx)(`b`,{children:`Term`}),`. Use search + filters to quickly locate records and maintain accurate fee setup.`]}),(0,o.jsxs)(`div`,{className:`db-hero-btns`,children:[(0,o.jsxs)(`button`,{className:`db-btn-gold`,onClick:Se,disabled:O!==null,children:[(0,o.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:(0,o.jsx)(`path`,{d:`M8 2v12M2 8h12`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})}),`Add Fee Type`]}),(0,o.jsxs)(`button`,{className:`db-btn-outline`,onClick:()=>Q(1),disabled:O!==null||u,children:[(0,o.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,style:{animation:u?`dbSpin 0.8s linear infinite`:`none`},children:[(0,o.jsx)(`path`,{d:`M12 7A5 5 0 112 7`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,o.jsx)(`path`,{d:`M12 3v4h-4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),`Refresh`]})]})]}),(0,o.jsxs)(`div`,{className:`db-hero-stat-card d-none d-md-block`,children:[(0,o.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,marginBottom:16},children:[(0,o.jsx)(`span`,{style:{fontSize:11,fontWeight:500,letterSpacing:`0.14em`,textTransform:`uppercase`,color:`#c9a84c`},children:`Quick glance`}),(0,o.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:(0,o.jsx)(`path`,{d:`M2 10V6M5 10V4M8 10V7M11 10V3`,stroke:`#64748b`,strokeWidth:`1.5`,strokeLinecap:`round`})})]}),(0,o.jsxs)(`div`,{className:`db-hero-stat-row`,children:[(0,o.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,o.jsx)(`span`,{className:`db-hero-stat-label`,children:`On page`}),(0,o.jsx)(`span`,{className:`db-hero-stat-val`,children:$.count})]}),(0,o.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,o.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,o.jsx)(`span`,{className:`db-hero-stat-label`,children:`Page total`}),(0,o.jsx)(`span`,{className:`db-hero-stat-val`,children:c($.sum)})]}),(0,o.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,o.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,o.jsx)(`span`,{className:`db-hero-stat-label`,children:`All records`}),(0,o.jsx)(`span`,{className:`db-hero-stat-val`,children:y})]})]})]})]})]}),(0,o.jsxs)(`div`,{className:`db-grid`,children:[(0,o.jsxs)(`div`,{className:`db-panel`,children:[(0,o.jsxs)(`div`,{className:`db-panel-head`,children:[(0,o.jsxs)(`div`,{className:`db-panel-title-group`,children:[(0,o.jsx)(`div`,{className:`db-panel-icon`,style:{"--pi":`#dbeafe`,"--pc":`#1e40af`},children:(0,o.jsx)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:(0,o.jsx)(`path`,{d:`M2 4h12M4 8h8M6 12h4`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})})}),(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`p`,{className:`db-panel-title`,children:`Search & Filters`}),(0,o.jsx)(`p`,{className:`db-panel-sub`,children:ke>0?`${ke} filter(s) active`:`No filters applied`})]})]}),(0,o.jsxs)(`span`,{className:`db-chip`,children:[`Page `,(0,o.jsx)(`b`,{style:{marginLeft:6},children:_}),` / `,(0,o.jsx)(`b`,{children:v})]})]}),(0,o.jsxs)(`div`,{className:`db-toolbar`,children:[(0,o.jsxs)(`div`,{className:`db-input-group`,children:[(0,o.jsx)(`input`,{className:`db-input`,style:{width:290},placeholder:`Search fee name or amount…`,value:b,onChange:e=>x(e.target.value),disabled:O!==null}),(0,o.jsxs)(`select`,{className:`db-select`,style:{width:190},value:S,onChange:e=>C(e.target.value?Number(e.target.value):``),disabled:O!==null,children:[(0,o.jsx)(`option`,{value:``,children:`All Sections`}),f.map(e=>(0,o.jsx)(`option`,{value:e.id,children:e.name},e.id))]}),(0,o.jsxs)(`select`,{className:`db-select`,style:{width:190},value:w,onChange:e=>T(e.target.value?Number(e.target.value):``),disabled:O!==null,children:[(0,o.jsx)(`option`,{value:``,children:`All Sessions`}),p.map(e=>(0,o.jsx)(`option`,{value:e.id,children:e.name},e.id))]}),(0,o.jsxs)(`select`,{className:`db-select`,style:{width:170},value:E,onChange:e=>D(e.target.value?Number(e.target.value):``),disabled:O!==null,children:[(0,o.jsx)(`option`,{value:``,children:`All Terms`}),m.map(e=>(0,o.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]}),(0,o.jsxs)(`div`,{className:`db-input-group`,style:{justifyContent:`flex-end`},children:[(0,o.jsxs)(`button`,{className:`db-sm-btn`,onClick:()=>{x(``),C(``),T(``),D(``)},disabled:O!==null,title:`Clear search & filters`,children:[(0,o.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:(0,o.jsx)(`path`,{d:`M4 4l8 8M12 4l-8 8`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})}),`Clear`]}),(0,o.jsxs)(`button`,{className:`db-sm-btn`,onClick:()=>Q(1),disabled:O!==null||u,children:[(0,o.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,style:{animation:u?`dbSpin 0.8s linear infinite`:`none`},children:[(0,o.jsx)(`path`,{d:`M12 7A5 5 0 112 7`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,o.jsx)(`path`,{d:`M12 3v4h-4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),`Refresh`]}),(0,o.jsxs)(`button`,{className:`db-sm-btn`,style:{background:`rgba(201,168,76,0.16)`,borderColor:`rgba(201,168,76,0.22)`},onClick:Se,disabled:O!==null,children:[(0,o.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:(0,o.jsx)(`path`,{d:`M8 2v12M2 8h12`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})}),`Add Fee Type`]})]})]})]}),(0,o.jsxs)(`div`,{className:`db-panel`,children:[(0,o.jsxs)(`div`,{className:`db-panel-head`,children:[(0,o.jsxs)(`div`,{className:`db-panel-title-group`,children:[(0,o.jsx)(`div`,{className:`db-panel-icon`,style:{"--pi":`#fef3c7`,"--pc":`#b45309`},children:(0,o.jsx)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:(0,o.jsx)(`path`,{d:`M3 4h10M3 8h10M3 12h10`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})})}),(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`p`,{className:`db-panel-title`,children:`Fee Types`}),(0,o.jsxs)(`p`,{className:`db-panel-sub`,children:[`Total records: `,(0,o.jsx)(`b`,{children:y}),` • Showing page `,(0,o.jsx)(`b`,{children:_})]})]})]}),(0,o.jsxs)(`span`,{className:`db-chip`,title:`Total amount for items currently displayed`,children:[`Page total `,(0,o.jsx)(`b`,{style:{marginLeft:8},children:c($.sum)})]})]}),u?(0,o.jsxs)(`div`,{className:`db-table-empty`,children:[(0,o.jsx)(`span`,{className:`spinner-border spinner-border-sm me-2`}),`Loading fee types…`]}):h.length===0?(0,o.jsxs)(`div`,{className:`db-table-empty`,children:[(0,o.jsx)(`div`,{style:{fontWeight:700,color:`#7a6a5a`},children:`No fee types found`}),(0,o.jsx)(`div`,{style:{marginTop:6},children:`Try changing filters or click “Add Fee Type”.`})]}):(0,o.jsx)(`div`,{style:{overflowX:`auto`},children:(0,o.jsxs)(`table`,{className:`db-table`,children:[(0,o.jsx)(`thead`,{children:(0,o.jsxs)(`tr`,{children:[(0,o.jsx)(`th`,{style:{width:70},children:`#`}),(0,o.jsx)(`th`,{children:`Fee Name`}),(0,o.jsx)(`th`,{style:{width:170,textAlign:`right`},children:`Amount`}),(0,o.jsx)(`th`,{style:{width:180},children:`Section`}),(0,o.jsx)(`th`,{style:{width:180},children:`Session`}),(0,o.jsx)(`th`,{style:{width:140},children:`Term`}),(0,o.jsx)(`th`,{style:{width:280,textAlign:`right`},children:`Actions`})]})}),(0,o.jsx)(`tbody`,{children:h.map((e,t)=>{let n=A(`fee:delete:${e.id}`);return(0,o.jsxs)(`tr`,{children:[(0,o.jsx)(`td`,{style:{color:`#9a8a7a`,fontSize:12.5},children:t+1}),(0,o.jsxs)(`td`,{children:[(0,o.jsx)(`div`,{style:{fontWeight:600,color:`#1a1a2e`},children:e.name}),(0,o.jsxs)(`div`,{style:{fontSize:12,color:`#9a8a7a`},children:[`ID: `,e.id]})]}),(0,o.jsx)(`td`,{style:{textAlign:`right`,fontWeight:700,color:`#1a1a2e`},children:c(e.amount)}),(0,o.jsx)(`td`,{children:(0,o.jsx)(`span`,{className:`db-pill`,children:ye(e)})}),(0,o.jsx)(`td`,{children:(0,o.jsx)(`span`,{className:`db-pill`,style:{background:`rgba(124,58,237,0.08)`,color:`#7c3aed`,borderColor:`rgba(124,58,237,0.12)`},children:be(e)})}),(0,o.jsx)(`td`,{children:(0,o.jsx)(`span`,{className:`db-pill db-pill--gold`,children:xe(e)})}),(0,o.jsx)(`td`,{style:{textAlign:`right`},children:(0,o.jsxs)(`div`,{className:`db-actions-cell`,children:[(0,o.jsxs)(`button`,{className:`db-sm-btn`,onClick:()=>we(e.id),disabled:O!==null,title:`Edit fee type`,children:[(0,o.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,o.jsx)(`path`,{d:`M3 11.5V13h1.5L12.8 4.7 11.3 3.2 3 11.5z`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinejoin:`round`}),(0,o.jsx)(`path`,{d:`M10.8 3.7l1.5 1.5`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`})]}),`Edit`]}),(0,o.jsx)(`button`,{className:`db-sm-btn db-sm-btn--danger`,onClick:()=>Ee(e.id),disabled:O!==null,title:`Delete fee type`,children:n?(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)(`span`,{className:`spinner-border spinner-border-sm`,style:{width:14,height:14}}),`Deleting…`]}):(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:(0,o.jsx)(`path`,{d:`M3 4h10M6 4V3h4v1M6 6v7M10 6v7M5 4l.7 10.2c.04.5.45.8.95.8h2.7c.5 0 .91-.3.95-.8L11 4`,stroke:`currentColor`,strokeWidth:`1.2`,strokeLinecap:`round`,strokeLinejoin:`round`})}),`Delete`]})})]})})]},e.id)})})]})}),(0,o.jsxs)(`div`,{className:`db-pagination`,children:[(0,o.jsxs)(`span`,{className:`db-page-info`,children:[`Total: `,(0,o.jsx)(`b`,{children:y}),` • Page: `,(0,o.jsx)(`b`,{children:_}),` / `,(0,o.jsx)(`b`,{children:v})]}),(0,o.jsxs)(`div`,{className:`db-page-btns`,children:[(0,o.jsxs)(`button`,{className:`db-page-btn`,onClick:()=>Q(_-1),disabled:!De||O!==null,children:[(0,o.jsx)(`svg`,{width:`12`,height:`12`,viewBox:`0 0 12 12`,fill:`none`,children:(0,o.jsx)(`path`,{d:`M8 2L4 6l4 4`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`,strokeLinejoin:`round`})}),`Prev`]}),(0,o.jsxs)(`span`,{className:`db-page-current`,children:[`Page `,_]}),(0,o.jsxs)(`button`,{className:`db-page-btn`,onClick:()=>Q(_+1),disabled:!Oe||O!==null,children:[`Next`,(0,o.jsx)(`svg`,{width:`12`,height:`12`,viewBox:`0 0 12 12`,fill:`none`,children:(0,o.jsx)(`path`,{d:`M4 2l4 4-4 4`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`,strokeLinejoin:`round`})})]})]})]})]})]}),(0,o.jsx)(`div`,{className:`mt-auto`,children:(0,o.jsx)(re,{})}),me&&(0,o.jsx)(`div`,{className:`db-modal-overlay`,onClick:()=>O?null:j(!1),children:(0,o.jsxs)(`div`,{className:`db-modal-card`,onClick:e=>e.stopPropagation(),children:[(0,o.jsxs)(`div`,{className:`db-modal-head`,children:[(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`h5`,{className:`db-modal-title`,children:`Add Fee Type`}),(0,o.jsx)(`p`,{className:`db-modal-sub`,children:`Define a fee under Section • Session • Term.`})]}),(0,o.jsx)(`button`,{className:`btn-close`,onClick:()=>j(!1),disabled:O!==null,"aria-label":`Close`})]}),(0,o.jsxs)(`div`,{className:`db-modal-body`,children:[(0,o.jsxs)(`div`,{className:`db-row`,children:[(0,o.jsxs)(`div`,{className:`db-col-4`,children:[(0,o.jsx)(`label`,{className:`db-form-label`,children:`Section *`}),(0,o.jsxs)(`select`,{className:`db-select`,style:{width:`100%`},value:N,onChange:e=>ge(e.target.value?Number(e.target.value):``),disabled:O!==null,children:[(0,o.jsx)(`option`,{value:``,children:`Select Section`}),f.map(e=>(0,o.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]}),(0,o.jsxs)(`div`,{className:`db-col-4`,children:[(0,o.jsx)(`label`,{className:`db-form-label`,children:`Session *`}),(0,o.jsxs)(`select`,{className:`db-select`,style:{width:`100%`},value:P,onChange:e=>F(e.target.value?Number(e.target.value):``),disabled:O!==null,children:[(0,o.jsx)(`option`,{value:``,children:`Select Session`}),p.map(e=>(0,o.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]}),(0,o.jsxs)(`div`,{className:`db-col-4`,children:[(0,o.jsx)(`label`,{className:`db-form-label`,children:`Term *`}),(0,o.jsxs)(`select`,{className:`db-select`,style:{width:`100%`},value:I,onChange:e=>L(e.target.value?Number(e.target.value):``),disabled:O!==null,children:[(0,o.jsx)(`option`,{value:``,children:`Select Term`}),m.map(e=>(0,o.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]}),(0,o.jsxs)(`div`,{className:`db-col-8`,children:[(0,o.jsx)(`label`,{className:`db-form-label`,children:`Fee Name *`}),(0,o.jsx)(`input`,{className:`db-input`,style:{width:`100%`},placeholder:`e.g. Tuition Fee`,value:R,onChange:e=>z(e.target.value),disabled:O!==null})]}),(0,o.jsxs)(`div`,{className:`db-col-4`,children:[(0,o.jsx)(`label`,{className:`db-form-label`,children:`Amount (₦) *`}),(0,o.jsx)(`input`,{className:`db-input`,style:{width:`100%`},type:`number`,min:0,value:B,onChange:e=>V(e.target.value),placeholder:`e.g. 25000`,disabled:O!==null})]})]}),(0,o.jsxs)(`div`,{className:`db-modal-actions`,children:[(0,o.jsx)(`button`,{className:`db-sm-btn`,onClick:()=>j(!1),disabled:O!==null,children:`Cancel`}),(0,o.jsx)(`button`,{className:`db-sm-btn`,style:{background:`rgba(201,168,76,0.18)`,borderColor:`rgba(201,168,76,0.26)`,fontWeight:700},onClick:Ce,disabled:O!==null,children:A(`fee:create`)?(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)(`span`,{className:`spinner-border spinner-border-sm`,style:{width:14,height:14}}),`Saving…`]}):(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:(0,o.jsx)(`path`,{d:`M13.5 4.5l-7 7-3-3`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`,strokeLinejoin:`round`})}),`Save Fee Type`]})})]})]})]})}),he&&H&&(0,o.jsx)(`div`,{className:`db-modal-overlay`,onClick:()=>O?null:M(!1),children:(0,o.jsxs)(`div`,{className:`db-modal-card`,onClick:e=>e.stopPropagation(),children:[(0,o.jsxs)(`div`,{className:`db-modal-head`,children:[(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`h5`,{className:`db-modal-title`,children:`Edit Fee Type`}),(0,o.jsx)(`p`,{className:`db-modal-sub`,children:`Update the fee type and amount.`})]}),(0,o.jsx)(`button`,{className:`btn-close`,onClick:()=>M(!1),disabled:O!==null,"aria-label":`Close`})]}),(0,o.jsxs)(`div`,{className:`db-modal-body`,children:[(0,o.jsxs)(`div`,{className:`db-row`,children:[(0,o.jsxs)(`div`,{className:`db-col-4`,children:[(0,o.jsx)(`label`,{className:`db-form-label`,children:`Section *`}),(0,o.jsxs)(`select`,{className:`db-select`,style:{width:`100%`},value:W,onChange:e=>G(e.target.value?Number(e.target.value):``),disabled:O!==null,children:[(0,o.jsx)(`option`,{value:``,children:`Select Section`}),f.map(e=>(0,o.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]}),(0,o.jsxs)(`div`,{className:`db-col-4`,children:[(0,o.jsx)(`label`,{className:`db-form-label`,children:`Session *`}),(0,o.jsxs)(`select`,{className:`db-select`,style:{width:`100%`},value:K,onChange:e=>q(e.target.value?Number(e.target.value):``),disabled:O!==null,children:[(0,o.jsx)(`option`,{value:``,children:`Select Session`}),p.map(e=>(0,o.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]}),(0,o.jsxs)(`div`,{className:`db-col-4`,children:[(0,o.jsx)(`label`,{className:`db-form-label`,children:`Term *`}),(0,o.jsxs)(`select`,{className:`db-select`,style:{width:`100%`},value:J,onChange:e=>Y(e.target.value?Number(e.target.value):``),disabled:O!==null,children:[(0,o.jsx)(`option`,{value:``,children:`Select Term`}),m.map(e=>(0,o.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]}),(0,o.jsxs)(`div`,{className:`db-col-8`,children:[(0,o.jsx)(`label`,{className:`db-form-label`,children:`Fee Name *`}),(0,o.jsx)(`input`,{className:`db-input`,style:{width:`100%`},value:X,onChange:e=>Z(e.target.value),disabled:O!==null})]}),(0,o.jsxs)(`div`,{className:`db-col-4`,children:[(0,o.jsx)(`label`,{className:`db-form-label`,children:`Amount (₦) *`}),(0,o.jsx)(`input`,{className:`db-input`,style:{width:`100%`},type:`number`,min:0,value:_e,onChange:e=>ve(e.target.value),disabled:O!==null})]})]}),(0,o.jsxs)(`div`,{className:`db-modal-actions`,children:[(0,o.jsx)(`button`,{className:`db-sm-btn`,onClick:()=>M(!1),disabled:O!==null,children:`Cancel`}),(0,o.jsx)(`button`,{className:`db-sm-btn`,style:{background:`rgba(201,168,76,0.18)`,borderColor:`rgba(201,168,76,0.26)`,fontWeight:700},onClick:Te,disabled:O!==null,children:A(`fee:update:${H}`)?(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)(`span`,{className:`spinner-border spinner-border-sm`,style:{width:14,height:14}}),`Saving…`]}):(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:(0,o.jsx)(`path`,{d:`M13.5 4.5l-7 7-3-3`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`,strokeLinejoin:`round`})}),`Update Fee Type`]})})]})]})]})})]})]})})]})}export{l as default};