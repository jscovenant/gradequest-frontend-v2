import{i as e}from"./rolldown-runtime-CWU8vmCm.js";import{Ut as t}from"./vendor-misc-OZLc0tLq.js";import{p as n}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as r,E as ee,P as i,d as te,f as ne,l as re,u as ie}from"./index-D6TxbaCx.js";var a=e(t(),1),o=n(),s=e=>e?e.charAt(0).toUpperCase()+e.slice(1).toLowerCase():``,c=e=>[s(e?.firstname),s(e?.surname)].filter(Boolean).join(` `).trim(),l=({label:e,value:t,icon:n})=>(0,o.jsxs)(`div`,{className:`sp-info-row`,children:[(0,o.jsxs)(`div`,{className:`sp-info-label`,children:[n&&(0,o.jsx)(`span`,{className:`sp-info-icon`,children:n}),e]}),(0,o.jsx)(`div`,{className:`sp-info-val`,children:t&&t!==``?t:(0,o.jsx)(`span`,{style:{color:`#c8bfb5`},children:`N/A`})})]});function u(){let{showSuccess:e,showError:t}=re(),[n,s]=(0,a.useState)(!1),[u,d]=(0,a.useState)([]),[f,p]=(0,a.useState)(!1),[m,ae]=(0,a.useState)(``),[h,g]=(0,a.useState)(1),[_]=(0,a.useState)(8),[v,y]=(0,a.useState)(``),[b,x]=(0,a.useState)(!1),[S,C]=(0,a.useState)(!1),[oe,w]=(0,a.useState)(!1),[T,E]=(0,a.useState)(!1),[D,O]=(0,a.useState)({firstname:``,surname:``,email:``,phone:``,address:``}),[se,k]=(0,a.useState)(``),[A,j]=(0,a.useState)(null),[M,N]=(0,a.useState)(!1),[P,F]=(0,a.useState)(`overview`),[I,L]=(0,a.useState)(!1),[R,z]=(0,a.useState)(!1),[B,V]=(0,a.useState)(!1),[H,U]=(0,a.useState)({firstname:``,surname:``,email:``,phone:``,address:``,status:`1`,password:``}),W=async()=>{p(!0);try{d((await i.get(`/bursars`)).data?.bursars||[])}catch(e){t(e?.response?.data?.message||`Failed to load bursars`)}finally{p(!1)}};(0,a.useEffect)(()=>{W()},[]);let G=(0,a.useMemo)(()=>{let e=m.trim().toLowerCase();return e?u.filter(t=>[t.firstname,t.surname,t.email,t.phone,t.address,`${t.firstname} ${t.surname}`].filter(Boolean).some(t=>String(t).toLowerCase().includes(e))):u},[u,m]),K=Math.max(1,Math.ceil(G.length/_)),q=(0,a.useMemo)(()=>{let e=(h-1)*_;return G.slice(e,e+_)},[G,h,_]);(0,a.useEffect)(()=>{h>K&&g(1)},[h,K]);let J=(0,a.useMemo)(()=>u.filter(e=>Number(e.status)===1).length,[u]),ce=(0,a.useMemo)(()=>u.filter(e=>Number(e.status)!==1).length,[u]),le=(0,a.useMemo)(()=>u.filter(e=>!!e.phone).length,[u]),ue=(0,a.useMemo)(()=>u.filter(e=>!!e.address).length,[u]),de=()=>{let e=new Date().getHours();return e<12?`Good morning`:e<17?`Good afternoon`:`Good evening`},Y=()=>{O({firstname:``,surname:``,email:``,phone:``,address:``}),k(``)},X=()=>{Y(),w(!0)},Z=()=>{T||(w(!1),Y())},fe=async()=>{E(!0);try{let t=await i.post(`/bursars`,D),n=t.data?.bursar,r=t.data?.default_password||``;e(t.data?.message||`Bursar created successfully`),k(r),n&&d(e=>[n,...e]),O({firstname:``,surname:``,email:``,phone:``,address:``})}catch(e){t(e?.response?.data?.message||`Failed to create bursar`)}finally{E(!1)}},pe=async e=>{j(null),N(!0),F(`overview`),L(!1),x(!1),y(``);try{let t=(await i.get(`/bursars/${e.id}`)).data?.bursar;j(t),U({firstname:t?.firstname||``,surname:t?.surname||``,email:t?.email||``,phone:t?.phone||``,address:t?.address||``,status:String(t?.status??`1`),password:``})}catch(e){t(e?.response?.data?.message||`Failed to load bursar details`)}finally{N(!1)}},Q=()=>{R||B||S||(j(null),N(!1),L(!1),F(`overview`),x(!1),y(``))},me=async()=>{if(A){N(!0);try{let e=(await i.get(`/bursars/${A.id}/edit`)).data?.bursar;j(t=>({...t||{},...e})),U({firstname:e?.firstname||``,surname:e?.surname||``,email:e?.email||``,phone:e?.phone||``,address:e?.address||``,status:String(e?.status??A?.status??`1`),password:``}),L(!0),F(`edit`)}catch(e){t(e?.response?.data?.message||`Failed to load bursar for editing`)}finally{N(!1)}}},he=async()=>{if(A){z(!0);try{let t={firstname:H.firstname,surname:H.surname,email:H.email,phone:H.phone,address:H.address,status:Number(H.status)};H.password.trim()&&(t.password=H.password.trim());let n=await i.put(`/bursars/${A.id}`,t),r=n.data?.bursar;e(n.data?.message||`Bursar updated successfully`),j(e=>({...e||{},...r})),d(e=>e.map(e=>e.id===A.id?{...e,...r}:e)),U(e=>({...e,password:``})),L(!1),F(`overview`)}catch(e){t(e?.response?.data?.message||`Failed to update bursar`)}finally{z(!1)}}},ge=async()=>{if(A&&window.confirm(`Are you sure you want to delete ${c(A)}?`)){V(!0);try{e((await i.delete(`/bursars/${A.id}`)).data?.message||`Bursar deleted successfully`),d(e=>e.filter(e=>e.id!==A.id)),Q()}catch(e){t(e?.response?.data?.message||`Failed to delete bursar`)}finally{V(!1)}}},$=async n=>{let r=n||v;if(!r)return t(`No password available`);try{await navigator.clipboard.writeText(r),e(`Password copied`)}catch{t(`Failed to copy password`)}},_e=async()=>{if(A){if(b){x(!1),y(``);return}C(!0);try{let n=await i.post(`/bursars/decrypt-password`,{user_id:A.id});n.data?.success&&n.data?.decrypted_password?(y(n.data.decrypted_password),x(!0),e(n.data?.message||`Password decrypted successfully`)):t(n.data?.message||`Failed to decrypt password`)}catch(e){t(e?.response?.data?.message||`Failed to decrypt password`)}finally{C(!1)}}},ve=e=>[e?.firstname?.[0],e?.surname?.[0]].filter(Boolean).join(``).toUpperCase();return(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');

        :root {
          --sp-light:    #F8FAFC;
          --sp-dark:     #0F2744;
          --sp-accent:   #D97706;
          --sp-magenta:  #2563EB;
          --sp-success:  #10B981;
          --sp-danger:   #EF4444;
          --sp-warning:  #F59E0B;
          --sp-info:     #3B82F6;
          --sp-border:   #E2E8F0;
          --sp-radius:   14px;

          --sp-accent-dim:    rgba(217,119,6,0.15);
          --sp-accent-border: rgba(217,119,6,0.35);
          --sp-magenta-dim:   rgba(37,99,235,0.08);
        }

        .db-main {
          background: #F8FAFC;
          min-height: 100vh;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          padding: 24px 28px 0;
        }

        .db-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 18px;
          padding: 32px 36px;
          position: relative;
          overflow: hidden;
          margin-bottom: 24px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
        }
        .db-hero-glow {
          position:absolute; top:-60px; right:-60px; width:320px; height:320px; border-radius:50%;
          background:radial-gradient(circle, rgba(217,119,6,.15) 0%, transparent 65%);
          pointer-events:none;
        }
        .db-hero-glow2 {
          position:absolute; bottom:-40px; left:30%; width:200px; height:200px; border-radius:50%;
          background:radial-gradient(circle, rgba(37,99,235,.10) 0%, transparent 70%);
          pointer-events:none;
        }
        .db-hero-inner {
          position:relative; z-index:1; display:flex; align-items:center; justify-content:space-between; gap:32px; flex-wrap:wrap;
        }
        .db-session-badge {
          display:inline-flex; align-items:center; gap:7px;
          font-size:11.5px; font-weight:700; letter-spacing:.04em; text-transform:uppercase;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.20);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius:999px; padding:4px 12px; margin-bottom:12px;
        }
        .db-session-dot {
          width:6px; height:6px; border-radius:50%; background: #10B981;
          animation:dbPulse 2s ease infinite;
        }
        @keyframes dbPulse { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:.4;transform:scale(1.5)} }

        .db-greeting {
          font-size:26px; font-weight:800; color:#fff;
          line-height:1.1; margin-bottom:8px;
        }
        .db-greeting em { font-style:normal; color: #FBBF24; }
        .db-hero-sub {
          font-size:13.5px; color:#CBD5E1;
          line-height:1.6; max-width:560px; margin-bottom:20px;
        }

        .db-btn-gold {
          display:inline-flex; align-items:center; gap:8px; padding:9px 18px; font-size:13px; font-weight:700;
          color:#FFFFFF; background:#D97706; border:none; border-radius:10px; cursor:pointer;
          transition:all .2s ease; white-space:nowrap;
        }
        .db-btn-gold:hover { background:#B45309; transform:translateY(-1px); color:#FFFFFF; }

        .db-btn-outline {
          display:inline-flex; align-items:center; gap:8px; padding:9px 18px; font-size:13px; font-weight:600;
          color:#FFFFFF; background:rgba(255,255,255,.10); border:1px solid rgba(255,255,255,.20);
          border-radius:10px; cursor:pointer; transition:all .2s ease; white-space:nowrap;
        }
        .db-btn-outline:hover { background:rgba(255,255,255,.18); color:#fff; }
        .db-btn-outline:disabled { opacity:.5; cursor:not-allowed; }

        .db-hero-stat-card {
          background:rgba(255,255,255,.08); border:1px solid rgba(255,255,255,.15); backdrop-filter:blur(8px);
          border-radius:14px; padding:20px 24px; min-width:240px;
        }
        .db-hero-stat-item { display:flex; justify-content:space-between; align-items:center; gap:16px; }
        .db-hero-stat-label { font-size:12px; font-weight:400; color:#CBD5E1; }
        .db-hero-stat-val {
          font-size:18px; font-weight:800; color:#FBBF24;
        }
        .db-hero-stat-sep { height:1px; background:rgba(255,255,255,.08); }

        .db-stats { display:grid; grid-template-columns:repeat(4,1fr); gap:16px; margin-bottom:24px; }
        @media(max-width:1100px){ .db-stats{grid-template-columns:repeat(2,1fr);} }
        @media(max-width:600px) { .db-stats{grid-template-columns:1fr;} }

        .db-stat {
          background:#fff; border:1px solid var(--sp-border); border-radius:var(--sp-radius); padding:24px 22px;
          position:relative; overflow:hidden; transition:box-shadow .25s,transform .25s; animation:dbFadeUp .5s ease both;
        }
        @keyframes dbFadeUp { from{opacity:0;transform:translateY(14px)} to{opacity:1;transform:translateY(0)} }
        .db-stat:hover { box-shadow:0 8px 28px rgba(0,0,0,.08); transform:translateY(-3px); }
        .db-stat::before {
          content:''; position:absolute; top:0; left:0; right:0; height:3px; background:var(--sc);
          transform:scaleX(0); transform-origin:left; transition:transform .3s ease;
        }
        .db-stat:hover::before { transform:scaleX(1); }
        .db-stat-head { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:16px; }
        .db-stat-icon {
          width:42px; height:42px; border-radius:10px; background:var(--si); color:var(--sc);
          display:flex; align-items:center; justify-content:center;
        }
        .db-stat-label { font-size:12px; font-weight:400; color:#9a8a7a; margin-bottom:5px; letter-spacing:.03em; }
        .db-stat-val {
          font-family:'Playfair Display',serif; font-size:30px; font-weight:700; color:var(--sp-dark); line-height:1;
        }
        .db-stat-footer {
          display:flex; align-items:center; gap:6px; margin-top:14px; padding-top:12px;
          border-top:1px solid var(--sp-light); font-size:12px; color:#9a8a7a;
        }

        .db-panel {
          background:#fff; border:1px solid var(--sp-border); border-radius:var(--sp-radius); overflow:hidden; margin-bottom:24px;
        }
        .db-panel-head {
          display:flex; align-items:center; justify-content:space-between; padding:20px 24px 16px;
          border-bottom:1px solid rgba(0,0,0,0.06); gap:12px; flex-wrap:wrap;
        }
        .db-panel-icon {
          width:36px; height:36px; border-radius:9px; display:flex; align-items:center; justify-content:center;
          background:var(--pi); color:var(--pc); flex-shrink:0;
        }
        .db-panel-title {
          font-family:'Playfair Display',serif; font-size:16px; font-weight:700; color:var(--sp-dark); margin:0;
        }
        .db-panel-sub { font-size:11.5px; font-weight:300; color:#9a8a7a; margin:0; }

        .db-search-wrap { position:relative; }
        .db-search-icon {
          position:absolute; left:13px; top:50%; transform:translateY(-50%); color:#b5a090;
          pointer-events:none; display:flex; align-items:center;
        }
        .db-search {
          width:100%; min-width:280px; background:var(--sp-light); border:1.5px solid var(--sp-border);
          border-radius:9px; padding:10px 36px 10px 38px; font-family:'DM Sans',sans-serif; font-size:13.5px;
          color:var(--sp-dark); outline:none; transition:border-color .2s,box-shadow .2s;
        }
        .db-search::placeholder { color:#bdb3a8; }
        .db-search:focus {
          border-color:var(--sp-accent-border); box-shadow:0 0 0 3px var(--sp-accent-dim); background:#fff;
        }
        .db-search-clear {
          position:absolute; right:10px; top:50%; transform:translateY(-50%); background:none; border:none;
          color:#b5a090; cursor:pointer; display:flex; align-items:center; padding:4px;
        }

        .db-sm-btn {
          display:inline-flex; align-items:center; gap:6px; padding:8px 14px; font-size:12.5px; font-weight:400;
          color:#7a6a5a; background:var(--sp-light); border:1px solid var(--sp-border); border-radius:8px;
          cursor:pointer; transition:background .2s; white-space:nowrap;
        }
        .db-sm-btn:hover { background:#ede8e0; color:var(--sp-dark); }
        .db-sm-btn:disabled { opacity:.45; cursor:not-allowed; }
        .db-sm-btn-primary { background:var(--sp-dark); color:#fff; border-color:var(--sp-dark); }
        .db-sm-btn-primary:hover { background:#1a1a2e; color:#fff; }

        .db-table { width:100%; border-collapse:collapse; }
        .db-table th {
          padding:10px 16px; font-size:11px; font-weight:500; letter-spacing:.1em; text-transform:uppercase;
          color:#9a8a7a; background:var(--sp-light); border-bottom:1px solid rgba(0,0,0,0.06); text-align:left; white-space:nowrap;
        }
        .db-table td {
          padding:14px 16px; font-size:13.5px; color:#4a4a5a; border-bottom:1px solid rgba(0,0,0,0.04); vertical-align:middle;
        }
        .db-table tbody tr:last-child td { border-bottom:none; }
        .db-table tbody tr:hover { background:var(--sp-light); }
        .db-table-empty { padding:56px 16px; text-align:center; color:#b5a090; font-size:13.5px; }

        .db-avatar-initials {
          width:40px; height:40px; border-radius:50%;
          background:linear-gradient(135deg, var(--sp-accent-dim), rgba(255,200,87,0.25));
          color:rgb(180,83,9); font-family:'Playfair Display',serif; font-size:13px; font-weight:700;
          display:flex; align-items:center; justify-content:center; flex-shrink:0; border:2px solid var(--sp-accent-border);
        }
        .db-user-name { font-weight:500; color:var(--sp-dark); line-height:1.2; }
        .db-user-sub { font-size:11.5px; color:#9a8a7a; }

        .db-badge {
          display:inline-flex; align-items:center; font-size:11.5px; font-weight:500;
          padding:3px 10px; border-radius:100px; white-space:nowrap;
        }
        .db-badge--blue   { background:rgba(59,130,246,.10);  color:rgb(59,130,246); }
        .db-badge--amber  { background:var(--sp-accent-dim);  color:rgb(180,83,9); }
        .db-badge--green  { background:rgba(34,197,94,.10);   color:rgb(21,128,61); }
        .db-badge--gray   { background:rgba(100,116,139,.09); color:#64748b; }
        .db-badge--violet { background:rgba(124,58,237,.09);  color:#7c3aed; }

        .db-view-btn, .db-action-btn, .db-delete-btn {
          display:inline-flex; align-items:center; gap:5px; padding:6px 12px; font-size:12.5px; font-weight:400;
          border-radius:7px; cursor:pointer; transition:background .2s,border-color .2s; white-space:nowrap;
        }
        .db-view-btn {
          color:rgb(180,83,9); background:var(--sp-accent-dim); border:1px solid var(--sp-accent-border);
        }
        .db-view-btn:hover { background:rgba(255,200,87,0.18); border-color:rgba(255,200,87,0.4); }

        .db-icon-btn {
          display:inline-flex; align-items:center; justify-content:center;
          width:34px; height:34px; border-radius:8px; cursor:pointer;
          transition:all .2s ease; border:1px solid transparent; flex-shrink:0;
          font-size:14px; text-decoration:none;
        }
        .db-icon-btn--view {
          color:rgb(180,83,9); background:var(--sp-accent-dim); border-color:var(--sp-accent-border);
        }
        .db-icon-btn--view:hover {
          background:rgba(255,200,87,0.28); transform:translateY(-1px);
        }

        .db-action-btn {
          color:#475569; background:#f8fafc; border:1px solid #e2e8f0;
        }
        .db-action-btn:hover { background:#eef2f7; }

        .db-delete-btn {
          color:#b91c1c; background:rgba(239,68,68,.06); border:1px solid rgba(239,68,68,.18);
        }
        .db-delete-btn:hover { background:rgba(239,68,68,.12); }

        .db-pagination {
          display:flex; align-items:center; justify-content:space-between; padding:14px 20px;
          flex-wrap:wrap; gap:10px; border-top:1px solid rgba(0,0,0,0.06);
        }
        .db-page-info { font-size:12px; font-weight:300; color:#9a8a7a; }
        .db-page-btn {
          display:inline-flex; align-items:center; gap:5px; padding:6px 12px; font-size:12.5px; font-weight:400;
          color:#7a6a5a; background:var(--sp-light); border:1px solid var(--sp-border); border-radius:7px; cursor:pointer;
        }
        .db-page-btn:hover:not(:disabled) { background:#ede8e0; color:var(--sp-dark); }
        .db-page-btn:disabled { opacity:.4; cursor:not-allowed; }
        .db-page-current { padding:6px 12px; font-size:12px; color:#9a8a7a; }

        .sp-overlay {
          position:fixed; inset:0; background:rgba(10, 25, 47, 0.70); backdrop-filter:blur(8px);
          -webkit-backdrop-filter:blur(8px);
          z-index:1200; display:flex; align-items:center; justify-content:center; padding:16px;
        }
        .sp-card {
          width:min(980px,96vw); max-height:92vh; border-radius:18px; overflow:hidden; background:#FFFFFF;
          box-shadow:0 25px 60px -12px rgba(15, 39, 68, 0.35); border:1px solid rgba(15, 39, 68, 0.12);
          display:flex; flex-direction:column; font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
        }
        .sp-header {
          background:linear-gradient(135deg, #0A192F 0%, #0F2744 100%); padding:0; position:relative; overflow:hidden; flex-shrink:0;
          border-bottom: 1px solid rgba(255, 255, 255, 0.12);
        }
        .sp-header::before {
          content:''; position:absolute; inset:0;
          background-image:
            linear-gradient(rgba(255, 255, 255, 0.035) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255, 255, 255, 0.035) 1px, transparent 1px);
          background-size:24px 24px; pointer-events:none;
        }
        .sp-header-glow {
          position:absolute; top:-40px; right:-40px; width:280px; height:280px; border-radius:50%;
          background:radial-gradient(circle,rgba(217,119,6,0.20) 0%,transparent 65%);
        }
        .sp-header-top {
          position:relative; z-index:1; padding:24px 28px 0; display:flex; align-items:flex-start; justify-content:space-between;
          gap:16px; flex-wrap:wrap;
        }
        .sp-modal-avatar-initials {
          width:64px; height:64px; border-radius:50%; background:linear-gradient(135deg, #FEF3C7, #FDE68A);
          color:#92400E; font-family:'Plus Jakarta Sans',sans-serif; font-size:20px; font-weight:800;
          display:flex; align-items:center; justify-content:center; border:3px solid rgba(255,255,255,0.25);
        }
        .sp-online-dot {
          position:absolute; bottom:2px; right:2px; width:12px; height:12px; background:#10B981;
          border:2px solid #0A192F; border-radius:50%;
        }
        .sp-header-info { flex:1; min-width:0; }
        .sp-modal-name {
          font-family:'Plus Jakarta Sans',sans-serif; font-size:20px; font-weight:800; color:#fff; line-height:1.15; margin-bottom:4px;
        }
        .sp-modal-meta { display:flex; flex-wrap:wrap; gap:12px; }
        .sp-modal-meta-item {
          display:flex; align-items:center; gap:5px; font-size:12.5px; font-weight:500; color:#CBD5E1;
        }
        .sp-header-actions { display:flex; align-items:center; gap:8px; flex-wrap:wrap; }

        .sp-btn-edit, .sp-btn-save, .sp-btn-cancel, .sp-btn-close, .sp-btn-danger {
          display:inline-flex; align-items:center; gap:7px; border-radius:10px; cursor:pointer;
          transition: all 0.2s ease;
        }
        .sp-btn-edit {
          padding:8px 16px; font-size:13px; font-weight:700; color:#0F2744;
          background:#FBBF24; border:none; box-shadow: 0 2px 8px rgba(251, 191, 36, 0.3);
        }
        .sp-btn-edit:hover { background:#F59E0B; transform: translateY(-1px); }

        .sp-btn-save {
          padding:8px 16px; font-size:13px; font-weight:700; color:#fff;
          background:linear-gradient(135deg, #10B981 0%, #059669 100%); border:none;
        }
        .sp-btn-save:hover { background:rgb(21,128,61); transform: translateY(-1px); }
        .sp-btn-save:disabled { opacity:.6; cursor:not-allowed; }

        .sp-btn-cancel {
          padding:8px 14px; font-size:13px; font-weight:600; color:rgba(255,255,255,0.85);
          background:rgba(255,255,255,0.10); border:1px solid rgba(255,255,255,0.20);
        }
        .sp-btn-cancel:hover { background:rgba(255,255,255,0.18); color:#fff; }

        .sp-btn-danger {
          padding:8px 14px; font-size:13px; font-weight:700; color:#fff;
          background:#DC2626; border:none;
        }
        .sp-btn-danger:hover { background:#B91C1C; }
        .sp-btn-danger:disabled { opacity:.6; cursor:not-allowed; }

        .sp-btn-close {
          width:34px; height:34px; background:rgba(255,255,255,0.10); border:1px solid rgba(255,255,255,0.20);
          border-radius:10px; justify-content:center; color:#FFFFFF; padding:0;
        }
        .sp-btn-close:hover {
          background: rgba(239, 68, 68, 0.3); border-color: rgba(239, 68, 68, 0.5); transform: scale(1.1) rotate(90deg); color: #fff;
        }

        .sp-status {
          display:inline-flex; align-items:center; gap:5px; font-size:11px; font-weight:700;
          border-radius:100px; padding:3px 10px;
        }
        .sp-status--active {
          background:rgba(16,185,129,0.15); color:#10B981; border:1px solid rgba(16,185,129,0.3);
        }
        .sp-status--inactive {
          background:rgba(100,116,139,0.15); color:#94a3b8; border:1px solid rgba(100,116,139,0.25);
        }
        .sp-status-dot { width:6px; height:6px; border-radius:50%; background:currentColor; }

        .sp-tabs {
          position:relative; z-index:1; display:flex; gap:4px; padding:16px 28px 0; overflow-x:auto; scrollbar-width:none;
          border-bottom: 2px solid rgba(255,255,255,0.08);
        }
        .sp-tabs::-webkit-scrollbar { display:none; }
        .sp-tab {
          display:inline-flex; align-items:center; gap:7px; padding:9px 16px; font-size:13px; font-weight:600;
          color:rgba(255,255,255,0.7); background:transparent; border:none; border-radius:8px 8px 0 0; cursor:pointer;
          white-space:nowrap; transition: all 0.2s ease;
        }
        .sp-tab:hover { color:#FFFFFF; background:rgba(255,255,255,0.08); }
        .sp-tab--active {
          color:#FBBF24; background:rgba(217,119,6,0.18); border-bottom:2px solid #FBBF24; font-weight:700;
        }

        .sp-body { overflow-y:auto; flex:1; padding:24px 28px 28px; background: #F8FAFC; }
        .sp-summary-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:12px; margin-bottom:16px; }
        @media(max-width:700px){ .sp-summary-grid{grid-template-columns:1fr;} }

        .sp-summary-card {
          background:#fff; border:1px solid var(--sp-border); border-radius:12px; padding:16px;
          display:flex; align-items:center; gap:12px;
        }
        .sp-summary-icon {
          width:36px; height:36px; border-radius:9px; display:flex; align-items:center; justify-content:center; flex-shrink:0;
        }
        .sp-summary-label {
          font-size:11px; font-weight:500; text-transform:uppercase; letter-spacing:.08em; color:#9a8a7a; margin-bottom:2px;
        }
        .sp-summary-val   { font-size:13.5px; font-weight:500; color:var(--sp-dark); }
        .sp-summary-sub   { font-size:11.5px; color:#9a8a7a; }

        .sp-content-card {
          background:#fff; border:1px solid var(--sp-border); border-radius:var(--sp-radius); overflow:hidden; margin-bottom:16px;
        }
        .sp-content-card-head {
          display:flex; align-items:center; justify-content:space-between; padding:16px 20px; border-bottom:1px solid rgba(0,0,0,0.06);
          gap:8px; flex-wrap:wrap;
        }
        .sp-content-card-title {
          font-family:'Playfair Display',serif; font-size:14.5px; font-weight:700; color:var(--sp-dark);
        }
        .sp-content-card-sub { font-size:11.5px; font-weight:300; color:#9a8a7a; margin-top:1px; }
        .sp-count-badge {
          font-size:11px; font-weight:500; color:#9a8a7a; background:var(--sp-light);
          border:1px solid var(--sp-border); border-radius:100px; padding:2px 9px;
        }

        .sp-info-row {
          display:flex; align-items:baseline; justify-content:space-between; padding:11px 0; border-bottom:1px solid var(--sp-border); gap:16px;
        }
        .sp-info-row:last-child { border-bottom:none; }
        .sp-info-label {
          font-size:12px; font-weight:500; color:#9a8a7a; text-transform:uppercase; letter-spacing:.08em;
          display:flex; align-items:center; gap:5px; white-space:nowrap; flex-shrink:0;
        }
        .sp-info-icon { color:rgb(180,83,9); display:flex; align-items:center; }
        .sp-info-val { font-size:13.5px; font-weight:400; color:var(--sp-dark); text-align:right; }

        .sp-form-grid { display:grid; grid-template-columns:repeat(2,1fr); gap:12px; }
        @media(max-width:700px){ .sp-form-grid{grid-template-columns:1fr;} }
        .sp-form-full { grid-column:1/-1; }
        .sp-label { display:block; font-size:12px; font-weight:500; color:#4a4a5a; margin-bottom:6px; letter-spacing:.02em; }
        .sp-input, .sp-select {
          width:100%; background:var(--sp-light); border:1.5px solid var(--sp-border); border-radius:8px;
          padding:9px 12px; font-family:'DM Sans',sans-serif; font-size:13px; color:var(--sp-dark); outline:none;
        }
        .sp-input:focus, .sp-select:focus {
          border-color:var(--sp-accent-border); box-shadow:0 0 0 3px var(--sp-accent-dim); background:#fff;
        }

        .sp-security-warn {
          display:flex; align-items:flex-start; gap:10px; background:rgba(239,68,68,0.05);
          border:1px solid rgba(239,68,68,0.18); border-radius:9px; padding:12px 14px;
          font-size:12.5px; color:rgb(185,28,28); line-height:1.55; margin-bottom:18px;
        }
        .sp-credential-box {
          background:var(--sp-light); border:1.5px solid var(--sp-border); border-radius:10px; padding:16px 18px;
        }
        .sp-credential-label {
          font-size:11.5px; font-weight:500; color:#9a8a7a; text-transform:uppercase; letter-spacing:.1em; margin-bottom:8px; display:block;
        }
        .sp-credential-val { font-size:15px; font-weight:500; color:var(--sp-dark); font-family:monospace; }
        .sp-pw-row { display:flex; gap:8px; align-items:center; }
        .sp-pw-input {
          flex:1; background:#fff; border:1.5px solid var(--sp-border); border-radius:8px; padding:10px 14px;
          font-family:monospace; font-size:14px; color:var(--sp-dark); outline:none;
        }
        .sp-icon-btn {
          width:36px; height:36px; border-radius:8px; background:var(--sp-light); border:1.5px solid var(--sp-border);
          display:flex; align-items:center; justify-content:center; cursor:pointer; color:#7a6a5a;
        }
        .sp-icon-btn:hover { background:#ede8e0; color:var(--sp-dark); }

        .sp-empty { padding:52px 20px; text-align:center; }
        .sp-empty-title {
          font-family:'Playfair Display',serif; font-size:15px; font-weight:700; color:#4a4a5a; margin-bottom:5px;
        }
        .sp-empty-sub { font-size:13px; color:#b5a090; }

        .sp-footer {
          display:flex; align-items:center; justify-content:space-between; gap:12px; padding:14px 28px;
          border-top:1px solid var(--sp-border); background:#fff; flex-wrap:wrap; flex-shrink:0;
        }
        .sp-footer-hint { font-size:12px; color:#b5a090; font-weight:300; }
        .sp-footer-close {
          display:inline-flex; align-items:center; gap:6px; padding:8px 16px; font-size:13px; font-weight:400;
          color:#7a6a5a; background:var(--sp-light); border:1px solid var(--sp-border); border-radius:8px; cursor:pointer;
        }

        .sp-spinner {
          width:18px; height:18px; border:2px solid rgba(255,255,255,.3); border-top-color:#fff; border-radius:50%;
          animation:spSpin .7s linear infinite; flex-shrink:0;
        }
        .sp-spinner--dark { border:2px solid rgba(0,0,0,.12); border-top-color:var(--sp-dark); }
        @keyframes spSpin { to{transform:rotate(360deg)} }

        .sp-modal-form-success {
          background:rgba(34,197,94,.08); border:1px solid rgba(34,197,94,.2); border-radius:10px;
          padding:14px 16px; margin-bottom:16px;
        }
        .sp-modal-form-success-title {
          color:rgb(21,128,61); font-weight:600; margin-bottom:6px; font-size:13px;
        }
        .sp-modal-form-success-sub {
          color:#4b5563; font-size:12.5px; margin-bottom:8px;
        }
      `}),(0,o.jsx)(ne,{sidebarOpen:n,setSidebarOpen:s}),(0,o.jsx)(r,{title:`Bursars page`}),(0,o.jsx)(`div`,{className:`container-fluid`,children:(0,o.jsxs)(`div`,{className:`row`,children:[(0,o.jsx)(te,{sidebarOpen:n}),(0,o.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto db-main`,children:[f&&(0,o.jsx)(ee,{message:`Loading bursars…`}),(0,o.jsxs)(`div`,{className:`db-hero`,children:[(0,o.jsx)(`div`,{className:`db-hero-glow`,"aria-hidden":`true`}),(0,o.jsx)(`div`,{className:`db-hero-glow2`,"aria-hidden":`true`}),(0,o.jsxs)(`div`,{className:`db-hero-inner`,children:[(0,o.jsxs)(`div`,{children:[(0,o.jsxs)(`div`,{className:`db-session-badge`,children:[(0,o.jsx)(`span`,{className:`db-session-dot`}),`Bursar Management`]}),(0,o.jsxs)(`h1`,{className:`db-greeting`,children:[de(),`, `,(0,o.jsx)(`em`,{children:`Admin.`})]}),(0,o.jsx)(`p`,{className:`db-hero-sub`,children:`Register bursars, manage account access, update contact details, review credentials, and control active staff records from one clean interface.`}),(0,o.jsxs)(`div`,{className:`d-flex flex-wrap gap-2`,children:[(0,o.jsxs)(`button`,{className:`db-btn-gold`,onClick:X,children:[(0,o.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,o.jsx)(`circle`,{cx:`8`,cy:`6`,r:`3`,stroke:`currentColor`,strokeWidth:`1.4`}),(0,o.jsx)(`path`,{d:`M2 15c0-3.314 2.686-6 6-6`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,o.jsx)(`path`,{d:`M13 10v4M11 12h4`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`})]}),`Add Bursar`]}),(0,o.jsxs)(`button`,{className:`db-btn-outline`,onClick:W,disabled:f,children:[(0,o.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,style:{animation:f?`spSpin .8s linear infinite`:`none`},children:[(0,o.jsx)(`path`,{d:`M12 7A5 5 0 112 7`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,o.jsx)(`path`,{d:`M12 3v4h-4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),`Refresh`]})]})]}),(0,o.jsxs)(`div`,{className:`db-hero-stat-card d-none d-md-block`,children:[(0,o.jsx)(`div`,{className:`d-flex align-items-center justify-content-between mb-3`,children:(0,o.jsx)(`span`,{style:{fontSize:11,fontWeight:500,letterSpacing:`0.14em`,textTransform:`uppercase`,color:`var(--sp-accent)`},children:`Quick glance`})}),(0,o.jsx)(`div`,{className:`d-flex flex-column gap-3`,children:[[`Total`,u.length],[`Active`,J],[`Inactive`,ce]].map(([e,t])=>(0,o.jsxs)(a.Fragment,{children:[(0,o.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,o.jsx)(`span`,{className:`db-hero-stat-label`,children:e}),(0,o.jsx)(`span`,{className:`db-hero-stat-val`,children:t})]}),e!==`Inactive`&&(0,o.jsx)(`div`,{className:`db-hero-stat-sep`})]},String(e)))})]})]})]}),(0,o.jsx)(`div`,{className:`db-stats`,children:[{title:`Total Bursars`,value:u.length,color:`var(--bs-warning, rgb(245,158,11))`,bg:`rgba(245,158,11,0.10)`,icon:(0,o.jsxs)(`svg`,{width:`17`,height:`17`,viewBox:`0 0 18 18`,fill:`none`,children:[(0,o.jsx)(`circle`,{cx:`7`,cy:`6`,r:`3`,stroke:`currentColor`,strokeWidth:`1.4`}),(0,o.jsx)(`path`,{d:`M1 17c0-3.314 2.686-6 6-6`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,o.jsx)(`circle`,{cx:`14`,cy:`11`,r:`2.5`,stroke:`currentColor`,strokeWidth:`1.3`})]})},{title:`Active`,value:J,color:`var(--bs-success, rgb(34,197,94))`,bg:`rgba(34,197,94,0.10)`,icon:(0,o.jsxs)(`svg`,{width:`17`,height:`17`,viewBox:`0 0 18 18`,fill:`none`,children:[(0,o.jsx)(`circle`,{cx:`9`,cy:`9`,r:`7.5`,stroke:`currentColor`,strokeWidth:`1.4`}),(0,o.jsx)(`path`,{d:`M5.5 9.5l2.5 2.5 4.5-5`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`,strokeLinejoin:`round`})]})},{title:`With Phone`,value:le,color:`var(--bs-info, rgb(59,130,246))`,bg:`rgba(59,130,246,0.10)`,icon:(0,o.jsxs)(`svg`,{width:`17`,height:`17`,viewBox:`0 0 18 18`,fill:`none`,children:[(0,o.jsx)(`rect`,{x:`5`,y:`2.5`,width:`8`,height:`13`,rx:`1.6`,stroke:`currentColor`,strokeWidth:`1.4`}),(0,o.jsx)(`path`,{d:`M8 13h2`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`})]})},{title:`With Address`,value:ue,color:`var(--bs-primary, rgb(211,0,176))`,bg:`rgba(211,0,176,0.08)`,icon:(0,o.jsxs)(`svg`,{width:`17`,height:`17`,viewBox:`0 0 18 18`,fill:`none`,children:[(0,o.jsx)(`path`,{d:`M9 16s5-4.6 5-8.4A5 5 0 109 16z`,stroke:`currentColor`,strokeWidth:`1.4`}),(0,o.jsx)(`circle`,{cx:`9`,cy:`7`,r:`1.8`,stroke:`currentColor`,strokeWidth:`1.3`})]})}].map((e,t)=>(0,o.jsxs)(`div`,{className:`db-stat`,style:{"--sc":e.color,"--si":e.bg,animationDelay:`${t*.06}s`},children:[(0,o.jsxs)(`div`,{className:`db-stat-head`,children:[(0,o.jsx)(`div`,{className:`db-stat-icon`,children:e.icon}),(0,o.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,style:{color:`#c8bfb5`},children:[(0,o.jsx)(`circle`,{cx:`3`,cy:`7`,r:`1.2`,fill:`currentColor`}),(0,o.jsx)(`circle`,{cx:`7`,cy:`7`,r:`1.2`,fill:`currentColor`}),(0,o.jsx)(`circle`,{cx:`11`,cy:`7`,r:`1.2`,fill:`currentColor`})]})]}),(0,o.jsx)(`p`,{className:`db-stat-label`,children:e.title}),(0,o.jsx)(`div`,{className:`db-stat-val`,children:e.value}),(0,o.jsxs)(`div`,{className:`db-stat-footer`,children:[(0,o.jsx)(`svg`,{width:`11`,height:`11`,viewBox:`0 0 12 12`,fill:`none`,children:(0,o.jsx)(`path`,{d:`M2 9l3-4 2 2 3-5`,stroke:`var(--sp-success)`,strokeWidth:`1.4`,strokeLinecap:`round`,strokeLinejoin:`round`})}),(0,o.jsx)(`span`,{style:{color:`var(--sp-success)`,fontWeight:500},children:`Directory`}),`\xA0staff snapshot`]})]},e.title))}),(0,o.jsxs)(`div`,{className:`db-panel`,children:[(0,o.jsxs)(`div`,{className:`db-panel-head`,children:[(0,o.jsxs)(`div`,{className:`d-flex align-items-center gap-3`,children:[(0,o.jsx)(`div`,{className:`db-panel-icon`,style:{"--pi":`var(--sp-accent-dim)`,"--pc":`rgb(180,83,9)`},children:(0,o.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,o.jsx)(`circle`,{cx:`6`,cy:`6`,r:`2.5`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,o.jsx)(`path`,{d:`M2 14c0-2.76 2.24-5 4-5`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`}),(0,o.jsx)(`path`,{d:`M11 3h3M11 6h3M10 9h4`,stroke:`currentColor`,strokeWidth:`1.2`,strokeLinecap:`round`})]})}),(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`p`,{className:`db-panel-title`,children:`Bursar Directory`}),(0,o.jsx)(`p`,{className:`db-panel-sub`,children:`Search bursars by name, phone or email.`})]})]}),(0,o.jsxs)(`div`,{className:`d-flex align-items-center flex-wrap gap-2`,children:[(0,o.jsxs)(`div`,{className:`db-search-wrap`,children:[(0,o.jsx)(`span`,{className:`db-search-icon`,children:(0,o.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,o.jsx)(`circle`,{cx:`7`,cy:`7`,r:`5`,stroke:`currentColor`,strokeWidth:`1.4`}),(0,o.jsx)(`path`,{d:`M11 11l3 3`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`})]})}),(0,o.jsx)(`input`,{className:`db-search`,placeholder:`Search name, email or phone…`,value:m,onChange:e=>{ae(e.target.value),g(1)}}),m&&(0,o.jsx)(`button`,{className:`db-search-clear`,onClick:()=>{ae(``),g(1)},children:(0,o.jsx)(`svg`,{width:`12`,height:`12`,viewBox:`0 0 12 12`,fill:`none`,children:(0,o.jsx)(`path`,{d:`M1 1l10 10M11 1L1 11`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})})})]}),(0,o.jsxs)(`button`,{className:`db-sm-btn`,onClick:W,disabled:f,children:[(0,o.jsxs)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,style:{animation:f?`spSpin .8s linear infinite`:`none`},children:[(0,o.jsx)(`path`,{d:`M12 7A5 5 0 112 7`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,o.jsx)(`path`,{d:`M12 3v4h-4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),`Refresh`]}),(0,o.jsxs)(`button`,{className:`db-sm-btn db-sm-btn-primary`,onClick:X,children:[(0,o.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:(0,o.jsx)(`path`,{d:`M7 1v12M1 7h12`,stroke:`currentColor`,strokeWidth:`1.7`,strokeLinecap:`round`})}),`Add Bursar`]})]})]}),(0,o.jsx)(`div`,{className:`overflow-auto`,children:(0,o.jsxs)(`table`,{className:`db-table`,children:[(0,o.jsx)(`thead`,{children:(0,o.jsxs)(`tr`,{children:[(0,o.jsx)(`th`,{children:`Bursar`}),(0,o.jsx)(`th`,{children:`Email`}),(0,o.jsx)(`th`,{children:`Phone`}),(0,o.jsx)(`th`,{children:`Status`}),(0,o.jsx)(`th`,{style:{textAlign:`right`},children:`Action`})]})}),(0,o.jsx)(`tbody`,{children:f?Array.from({length:5}).map((e,t)=>(0,o.jsx)(`tr`,{children:(0,o.jsx)(`td`,{colSpan:5,style:{padding:`16px`},children:(0,o.jsx)(`div`,{style:{height:14,borderRadius:6,background:`linear-gradient(90deg,#ece8e0 25%,#e0dad2 50%,#ece8e0 75%)`,backgroundSize:`200% 100%`,animation:`spSpin 1.2s linear infinite`,opacity:.25}})})},t)):q.length===0?(0,o.jsx)(`tr`,{children:(0,o.jsx)(`td`,{colSpan:5,className:`db-table-empty`,children:`No bursars found.`})}):q.map(e=>{let t=Number(e.status)===1;return(0,o.jsxs)(`tr`,{children:[(0,o.jsx)(`td`,{children:(0,o.jsxs)(`div`,{className:`d-flex align-items-center gap-3`,children:[(0,o.jsx)(`div`,{className:`db-avatar-initials`,children:ve(e)}),(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`div`,{className:`db-user-name`,children:c(e)}),(0,o.jsxs)(`div`,{className:`db-user-sub`,children:[`Bursar · ID #`,e.id]})]})]})}),(0,o.jsx)(`td`,{children:(0,o.jsx)(`span`,{className:`db-badge db-badge--blue`,children:e.email})}),(0,o.jsx)(`td`,{children:(0,o.jsx)(`span`,{className:`db-badge db-badge--amber`,children:e.phone})}),(0,o.jsx)(`td`,{children:(0,o.jsx)(`span`,{className:`db-badge ${t?`db-badge--green`:`db-badge--gray`}`,children:t?`Active`:`Inactive`})}),(0,o.jsx)(`td`,{style:{textAlign:`right`},children:(0,o.jsx)(`button`,{className:`db-icon-btn db-icon-btn--view`,onClick:()=>pe(e),title:`View Profile: ${c(e)}`,"aria-label":`View Bursar Profile`,children:(0,o.jsxs)(`svg`,{width:`15`,height:`15`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,o.jsx)(`path`,{d:`M1 8s2.5-5 7-5 7 5 7 5-2.5 5-7 5-7-5-7-5z`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinejoin:`round`}),(0,o.jsx)(`circle`,{cx:`8`,cy:`8`,r:`2.5`,stroke:`currentColor`,strokeWidth:`1.4`})]})})})]},e.id)})})]})}),(0,o.jsxs)(`div`,{className:`db-pagination`,children:[(0,o.jsxs)(`span`,{className:`db-page-info`,children:[`Page `,h,` of `,K]}),(0,o.jsxs)(`div`,{className:`d-flex align-items-center gap-2`,children:[(0,o.jsxs)(`button`,{className:`db-page-btn`,onClick:()=>g(e=>e-1),disabled:h<=1,children:[(0,o.jsx)(`svg`,{width:`11`,height:`11`,viewBox:`0 0 12 12`,fill:`none`,children:(0,o.jsx)(`path`,{d:`M8 2L4 6l4 4`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`,strokeLinejoin:`round`})}),`Prev`]}),(0,o.jsxs)(`span`,{className:`db-page-current`,children:[h,` / `,K]}),(0,o.jsxs)(`button`,{className:`db-page-btn`,onClick:()=>g(e=>e+1),disabled:h>=K,children:[`Next`,(0,o.jsx)(`svg`,{width:`11`,height:`11`,viewBox:`0 0 12 12`,fill:`none`,children:(0,o.jsx)(`path`,{d:`M4 2l4 4-4 4`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`,strokeLinejoin:`round`})})]})]})]})]}),(0,o.jsx)(`div`,{style:{marginTop:`auto`},children:(0,o.jsx)(ie,{})})]})]})}),oe&&(0,o.jsx)(`div`,{className:`sp-overlay`,onMouseDown:Z,children:(0,o.jsxs)(`div`,{className:`sp-card`,onMouseDown:e=>e.stopPropagation(),children:[(0,o.jsxs)(`div`,{className:`sp-header`,children:[(0,o.jsx)(`div`,{className:`sp-header-glow`}),(0,o.jsxs)(`div`,{className:`sp-header-top`,children:[(0,o.jsxs)(`div`,{className:`d-flex align-items-center gap-3`,style:{flex:1},children:[(0,o.jsx)(`div`,{className:`sp-modal-avatar-initials`,children:[D.firstname?.[0],D.surname?.[0]].filter(Boolean).join(``).toUpperCase()||`B`}),(0,o.jsxs)(`div`,{className:`sp-header-info`,children:[(0,o.jsx)(`div`,{className:`sp-modal-name`,children:`Register New Bursar`}),(0,o.jsx)(`div`,{className:`sp-modal-meta`,children:(0,o.jsx)(`span`,{className:`sp-modal-meta-item`,children:`Create bursar account for this school`})})]})]}),(0,o.jsx)(`div`,{className:`sp-header-actions`,children:(0,o.jsx)(`button`,{className:`sp-btn-close`,onClick:Z,children:(0,o.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 12 12`,fill:`none`,children:(0,o.jsx)(`path`,{d:`M1 1l10 10M11 1L1 11`,stroke:`currentColor`,strokeWidth:`1.7`,strokeLinecap:`round`})})})})]})]}),(0,o.jsxs)(`div`,{className:`sp-body`,children:[se&&(0,o.jsxs)(`div`,{className:`sp-modal-form-success`,children:[(0,o.jsx)(`div`,{className:`sp-modal-form-success-title`,children:`Bursar created successfully`}),(0,o.jsx)(`div`,{className:`sp-modal-form-success-sub`,children:`Copy the default password now and share it securely with the bursar.`}),(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`span`,{className:`sp-credential-label`,children:`Default Password`}),(0,o.jsxs)(`div`,{className:`sp-pw-row`,children:[(0,o.jsx)(`input`,{className:`sp-pw-input`,type:b?`text`:`password`,value:b?v:`••••••••••`,readOnly:!0}),(0,o.jsx)(`button`,{className:`sp-icon-btn`,onClick:_e,disabled:S,title:b?`Hide password`:`Decrypt password`,children:S?(0,o.jsx)(`span`,{className:`sp-spinner sp-spinner--dark`}):b?(0,o.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,o.jsx)(`path`,{d:`M3 3l10 10`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`}),(0,o.jsx)(`path`,{d:`M6.2 6.2A2.5 2.5 0 009.8 9.8`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`}),(0,o.jsx)(`path`,{d:`M2 8s2.5-5 6-5c1.1 0 2.1.2 3 .7M14 8s-2.5 5-6 5c-1.1 0-2.1-.2-3-.7`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`})]}):(0,o.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,o.jsx)(`path`,{d:`M2 8s2.5-5 6-5 6 5 6 5-2.5 5-6 5-6-5-6-5z`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,o.jsx)(`circle`,{cx:`8`,cy:`8`,r:`2`,stroke:`currentColor`,strokeWidth:`1.3`})]})}),(0,o.jsx)(`button`,{className:`sp-icon-btn`,onClick:()=>$(),disabled:!b||!v,title:`Copy`,children:(0,o.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,o.jsx)(`rect`,{x:`5`,y:`5`,width:`9`,height:`9`,rx:`1.5`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,o.jsx)(`path`,{d:`M3 11V3a1 1 0 011-1h8`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`})]})})]}),b&&v&&(0,o.jsx)(`p`,{style:{fontSize:11.5,color:`var(--sp-success)`,marginTop:8,marginBottom:0},children:`Password decrypted successfully`})]})]}),(0,o.jsxs)(`div`,{className:`sp-content-card`,children:[(0,o.jsx)(`div`,{className:`sp-content-card-head`,children:(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`div`,{className:`sp-content-card-title`,children:`Bursar Details`}),(0,o.jsx)(`div`,{className:`sp-content-card-sub`,children:`Enter the bursar's personal and contact information.`})]})}),(0,o.jsx)(`div`,{style:{padding:`20px`},children:(0,o.jsxs)(`div`,{className:`sp-form-grid`,children:[(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`label`,{className:`sp-label`,children:`First Name *`}),(0,o.jsx)(`input`,{className:`sp-input`,value:D.firstname,onChange:e=>O({...D,firstname:e.target.value})})]}),(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`label`,{className:`sp-label`,children:`Surname *`}),(0,o.jsx)(`input`,{className:`sp-input`,value:D.surname,onChange:e=>O({...D,surname:e.target.value})})]}),(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`label`,{className:`sp-label`,children:`Email *`}),(0,o.jsx)(`input`,{className:`sp-input`,type:`email`,value:D.email,onChange:e=>O({...D,email:e.target.value})})]}),(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`label`,{className:`sp-label`,children:`Phone *`}),(0,o.jsx)(`input`,{className:`sp-input`,value:D.phone,onChange:e=>O({...D,phone:e.target.value})})]}),(0,o.jsxs)(`div`,{className:`sp-form-full`,children:[(0,o.jsx)(`label`,{className:`sp-label`,children:`Address`}),(0,o.jsx)(`input`,{className:`sp-input`,value:D.address,onChange:e=>O({...D,address:e.target.value})})]})]})})]})]}),(0,o.jsxs)(`div`,{className:`sp-footer`,children:[(0,o.jsx)(`span`,{className:`sp-footer-hint`,children:`A random default password will be generated automatically by the backend.`}),(0,o.jsxs)(`div`,{className:`d-flex gap-2`,children:[(0,o.jsx)(`button`,{className:`sp-footer-close`,onClick:Z,children:`Cancel`}),(0,o.jsx)(`button`,{className:`sp-btn-edit`,onClick:fe,disabled:T,children:T?(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)(`span`,{className:`sp-spinner sp-spinner--dark`,style:{borderTopColor:`var(--sp-dark)`}}),`Creating…`]}):(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:(0,o.jsx)(`path`,{d:`M7 1v12M1 7h12`,stroke:`currentColor`,strokeWidth:`1.7`,strokeLinecap:`round`})}),`Create Bursar`]})})]})]})]})}),(A||M)&&(0,o.jsx)(`div`,{className:`sp-overlay`,onMouseDown:Q,children:(0,o.jsxs)(`div`,{className:`sp-card`,onMouseDown:e=>e.stopPropagation(),children:[(0,o.jsxs)(`div`,{className:`sp-header`,children:[(0,o.jsx)(`div`,{className:`sp-header-glow`}),(0,o.jsxs)(`div`,{className:`sp-header-top`,children:[(0,o.jsxs)(`div`,{className:`d-flex align-items-center gap-3`,style:{flex:1,minWidth:0},children:[(0,o.jsxs)(`div`,{style:{position:`relative`},children:[(0,o.jsx)(`div`,{className:`sp-modal-avatar-initials`,children:ve(A)}),Number(A?.status)===1&&(0,o.jsx)(`div`,{className:`sp-online-dot`})]}),(0,o.jsxs)(`div`,{className:`sp-header-info`,children:[(0,o.jsxs)(`div`,{className:`d-flex align-items-center flex-wrap gap-2 mb-1`,children:[(0,o.jsx)(`span`,{className:`sp-modal-name`,children:c(A)||`Loading…`}),A&&(0,o.jsxs)(`span`,{className:`sp-status ${Number(A.status)===1?`sp-status--active`:`sp-status--inactive`}`,children:[(0,o.jsx)(`span`,{className:`sp-status-dot`}),Number(A.status)===1?`Active`:`Inactive`]})]}),(0,o.jsxs)(`div`,{className:`sp-modal-meta`,children:[(0,o.jsxs)(`span`,{className:`sp-modal-meta-item`,children:[(0,o.jsxs)(`svg`,{width:`11`,height:`11`,viewBox:`0 0 12 12`,fill:`none`,children:[(0,o.jsx)(`path`,{d:`M2 3.5h8v5H2z`,stroke:`currentColor`,strokeWidth:`1.1`}),(0,o.jsx)(`path`,{d:`M2 4l4 3 4-3`,stroke:`currentColor`,strokeWidth:`1.1`,strokeLinejoin:`round`})]}),A?.email||`—`]}),(0,o.jsxs)(`span`,{className:`sp-modal-meta-item`,children:[(0,o.jsx)(`svg`,{width:`11`,height:`11`,viewBox:`0 0 12 12`,fill:`none`,children:(0,o.jsx)(`path`,{d:`M3.2 1.5h1.6l.6 1.7-1 .8a7 7 0 003.6 3.6l.8-1 1.7.6v1.6c0 .4-.3.7-.7.7A8.7 8.7 0 012.5 2.2c0-.4.3-.7.7-.7z`,stroke:`currentColor`,strokeWidth:`1.1`,strokeLinejoin:`round`})}),A?.phone||`—`]}),(0,o.jsxs)(`span`,{className:`sp-modal-meta-item`,children:[(0,o.jsxs)(`svg`,{width:`11`,height:`11`,viewBox:`0 0 12 12`,fill:`none`,children:[(0,o.jsx)(`path`,{d:`M6 10s3.5-3.1 3.5-5.6A3.5 3.5 0 102.5 4.4C2.5 6.9 6 10 6 10z`,stroke:`currentColor`,strokeWidth:`1.1`}),(0,o.jsx)(`circle`,{cx:`6`,cy:`4.4`,r:`1.1`,stroke:`currentColor`,strokeWidth:`1`})]}),A?.address||`No address`]})]})]})]}),(0,o.jsxs)(`div`,{className:`sp-header-actions`,children:[!M&&A&&!I&&(0,o.jsxs)(`button`,{className:`sp-btn-edit`,onClick:me,children:[(0,o.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:(0,o.jsx)(`path`,{d:`M9.5 2.5l2 2L5 11H3V9l6.5-6.5z`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinejoin:`round`})}),`Edit`]}),I&&(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)(`button`,{className:`sp-btn-save`,onClick:he,disabled:R,children:R?(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)(`span`,{className:`sp-spinner`}),`Saving…`]}):(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:(0,o.jsx)(`path`,{d:`M2 7l3.5 3.5 6.5-6`,stroke:`currentColor`,strokeWidth:`1.8`,strokeLinecap:`round`,strokeLinejoin:`round`})}),`Save`]})}),(0,o.jsx)(`button`,{className:`sp-btn-cancel`,onClick:()=>{L(!1),F(`overview`)},disabled:R,children:`Cancel`})]}),!M&&A&&(0,o.jsx)(`button`,{className:`sp-btn-danger`,onClick:ge,disabled:B,children:B?(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)(`span`,{className:`sp-spinner`}),`Deleting…`]}):(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:(0,o.jsx)(`path`,{d:`M2.5 4h9M5.5 4V2.8c0-.4.3-.8.8-.8h1.4c.5 0 .8.4.8.8V4M4 4l.5 7.3c0 .4.3.7.7.7h3.6c.4 0 .7-.3.7-.7L10 4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})}),`Delete`]})}),(0,o.jsx)(`button`,{className:`sp-btn-close`,onClick:Q,"aria-label":`Close`,children:(0,o.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 12 12`,fill:`none`,children:(0,o.jsx)(`path`,{d:`M1 1l10 10M11 1L1 11`,stroke:`currentColor`,strokeWidth:`1.7`,strokeLinecap:`round`})})})]})]}),(0,o.jsx)(`div`,{className:`sp-tabs`,children:[{key:`overview`,label:`Overview`,icon:(0,o.jsxs)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:[(0,o.jsx)(`rect`,{x:`1`,y:`1`,width:`5`,height:`5`,rx:`1.5`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,o.jsx)(`rect`,{x:`8`,y:`1`,width:`5`,height:`5`,rx:`1.5`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,o.jsx)(`rect`,{x:`1`,y:`8`,width:`5`,height:`5`,rx:`1.5`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,o.jsx)(`rect`,{x:`8`,y:`8`,width:`5`,height:`5`,rx:`1.5`,stroke:`currentColor`,strokeWidth:`1.3`})]})},{key:`edit`,label:`Edit`,icon:(0,o.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:(0,o.jsx)(`path`,{d:`M9.5 2.5l2 2L5 11H3V9l6.5-6.5z`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinejoin:`round`})})},{key:`security`,label:`Security`,icon:(0,o.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:(0,o.jsx)(`path`,{d:`M7 1.5L2 3.5v4c0 2.9 2.2 5.6 5 6.5 2.8-.9 5-3.6 5-6.5v-4L7 1.5z`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinejoin:`round`})})}].map(e=>(0,o.jsxs)(`button`,{className:`sp-tab ${P===e.key?`sp-tab--active`:``}`,onClick:()=>F(e.key),children:[e.icon,` `,e.label]},e.key))})]}),(0,o.jsx)(`div`,{className:`sp-body`,children:M?(0,o.jsxs)(`div`,{className:`d-flex flex-column align-items-center gap-3`,style:{padding:`48px 0`},children:[(0,o.jsx)(`svg`,{width:`22`,height:`22`,viewBox:`0 0 22 22`,fill:`none`,style:{animation:`spSpin .8s linear infinite`,color:`rgb(180,83,9)`},children:(0,o.jsx)(`circle`,{cx:`11`,cy:`11`,r:`9`,stroke:`currentColor`,strokeWidth:`2`,strokeDasharray:`40`,strokeDashoffset:`10`,strokeLinecap:`round`})}),(0,o.jsx)(`span`,{style:{fontSize:13,color:`#9a8a7a`},children:`Loading bursar details…`})]}):A?(0,o.jsxs)(o.Fragment,{children:[P===`overview`&&(0,o.jsxs)(o.Fragment,{children:[(0,o.jsxs)(`div`,{className:`sp-summary-grid`,children:[(0,o.jsxs)(`div`,{className:`sp-summary-card`,children:[(0,o.jsx)(`div`,{className:`sp-summary-icon`,style:{background:`var(--sp-accent-dim)`,color:`rgb(180,83,9)`},children:(0,o.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,o.jsx)(`path`,{d:`M2 13a4 4 0 018 0`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`}),(0,o.jsx)(`circle`,{cx:`6`,cy:`6`,r:`3`,stroke:`currentColor`,strokeWidth:`1.3`})]})}),(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`div`,{className:`sp-summary-label`,children:`Role`}),(0,o.jsx)(`div`,{className:`sp-summary-val`,children:`Bursar`}),(0,o.jsx)(`div`,{className:`sp-summary-sub`,children:`Finance staff account`})]})]}),(0,o.jsxs)(`div`,{className:`sp-summary-card`,children:[(0,o.jsx)(`div`,{className:`sp-summary-icon`,style:{background:`rgba(59,130,246,0.08)`,color:`rgb(59,130,246)`},children:(0,o.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,o.jsx)(`path`,{d:`M3 3h10v10H3z`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,o.jsx)(`path`,{d:`M3 5.5h10`,stroke:`currentColor`,strokeWidth:`1.3`})]})}),(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`div`,{className:`sp-summary-label`,children:`Email`}),(0,o.jsx)(`div`,{className:`sp-summary-val`,children:A.email||`N/A`}),(0,o.jsx)(`div`,{className:`sp-summary-sub`,children:`Primary login/contact email`})]})]}),(0,o.jsxs)(`div`,{className:`sp-summary-card`,children:[(0,o.jsx)(`div`,{className:`sp-summary-icon`,style:{background:`rgba(34,197,94,0.10)`,color:`rgb(21,128,61)`},children:(0,o.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,o.jsx)(`circle`,{cx:`8`,cy:`8`,r:`6`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,o.jsx)(`path`,{d:`M5.5 8l1.5 1.5L10.5 6`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`,strokeLinejoin:`round`})]})}),(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`div`,{className:`sp-summary-label`,children:`Status`}),(0,o.jsx)(`div`,{className:`sp-summary-val`,children:Number(A.status)===1?`Active`:`Inactive`}),(0,o.jsx)(`div`,{className:`sp-summary-sub`,children:`Current account accessibility`})]})]})]}),(0,o.jsxs)(`div`,{className:`sp-content-card`,children:[(0,o.jsxs)(`div`,{className:`sp-content-card-head`,children:[(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`div`,{className:`sp-content-card-title`,children:`Bursar Details`}),(0,o.jsx)(`div`,{className:`sp-content-card-sub`,children:`Personal and contact profile information.`})]}),(0,o.jsxs)(`span`,{className:`sp-count-badge`,children:[`ID #`,A.id]})]}),(0,o.jsxs)(`div`,{style:{padding:`4px 20px 12px`,display:`grid`,gridTemplateColumns:`1fr 1fr`,gap:`0 32px`},children:[(0,o.jsxs)(`div`,{children:[(0,o.jsx)(l,{label:`First Name`,value:A.firstname}),(0,o.jsx)(l,{label:`Surname`,value:A.surname}),(0,o.jsx)(l,{label:`Email`,value:A.email})]}),(0,o.jsxs)(`div`,{children:[(0,o.jsx)(l,{label:`Phone`,value:A.phone}),(0,o.jsx)(l,{label:`Address`,value:A.address||`N/A`}),(0,o.jsx)(l,{label:`Status`,value:Number(A.status)===1?`Active`:`Inactive`})]})]})]})]}),P===`edit`&&(0,o.jsxs)(`div`,{className:`sp-content-card`,children:[(0,o.jsx)(`div`,{className:`sp-content-card-head`,children:(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`div`,{className:`sp-content-card-title`,children:`Edit Bursar`}),(0,o.jsx)(`div`,{className:`sp-content-card-sub`,children:`Update staff information and account status.`})]})}),(0,o.jsx)(`div`,{style:{padding:`20px`},children:(0,o.jsxs)(`div`,{className:`sp-form-grid`,children:[(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`label`,{className:`sp-label`,children:`First Name *`}),(0,o.jsx)(`input`,{className:`sp-input`,value:H.firstname,onChange:e=>U({...H,firstname:e.target.value})})]}),(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`label`,{className:`sp-label`,children:`Surname *`}),(0,o.jsx)(`input`,{className:`sp-input`,value:H.surname,onChange:e=>U({...H,surname:e.target.value})})]}),(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`label`,{className:`sp-label`,children:`Email *`}),(0,o.jsx)(`input`,{className:`sp-input`,type:`email`,value:H.email,onChange:e=>U({...H,email:e.target.value})})]}),(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`label`,{className:`sp-label`,children:`Phone *`}),(0,o.jsx)(`input`,{className:`sp-input`,value:H.phone,onChange:e=>U({...H,phone:e.target.value})})]}),(0,o.jsxs)(`div`,{className:`sp-form-full`,children:[(0,o.jsx)(`label`,{className:`sp-label`,children:`Address`}),(0,o.jsx)(`input`,{className:`sp-input`,value:H.address,onChange:e=>U({...H,address:e.target.value})})]}),(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`label`,{className:`sp-label`,children:`Status`}),(0,o.jsxs)(`select`,{className:`sp-select`,value:H.status,onChange:e=>U({...H,status:e.target.value}),children:[(0,o.jsx)(`option`,{value:`1`,children:`Active`}),(0,o.jsx)(`option`,{value:`0`,children:`Inactive`})]})]}),(0,o.jsxs)(`div`,{className:`sp-form-full`,children:[(0,o.jsxs)(`label`,{className:`sp-label`,children:[`New Password`,(0,o.jsx)(`span`,{style:{color:`#9a8a7a`,fontWeight:400},children:` (optional)`})]}),(0,o.jsx)(`input`,{className:`sp-input`,type:`text`,placeholder:`Leave blank to keep current password`,value:H.password,onChange:e=>U({...H,password:e.target.value})})]})]})})]}),P===`security`&&(0,o.jsxs)(`div`,{className:`sp-content-card`,children:[(0,o.jsx)(`div`,{className:`sp-content-card-head`,children:(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`div`,{className:`sp-content-card-title`,children:`Login Credentials`}),(0,o.jsx)(`div`,{className:`sp-content-card-sub`,children:`Admin-only credential visibility for secure onboarding.`})]})}),(0,o.jsxs)(`div`,{className:`d-flex flex-column gap-3`,style:{padding:`20px`},children:[(0,o.jsxs)(`div`,{className:`sp-security-warn`,children:[(0,o.jsxs)(`svg`,{width:`15`,height:`15`,viewBox:`0 0 16 16`,fill:`none`,style:{flexShrink:0,marginTop:1},children:[(0,o.jsx)(`path`,{d:`M8 2L14 14H2L8 2z`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinejoin:`round`}),(0,o.jsx)(`path`,{d:`M8 7v3M8 11.5v.5`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`})]}),`Default passwords should only be shared through secure channels. Encourage the bursar to change the password after first login.`]}),(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`span`,{className:`sp-credential-label`,children:`Account Email`}),(0,o.jsx)(`div`,{className:`sp-credential-box`,children:(0,o.jsx)(`span`,{className:`sp-credential-val`,children:A.email||`N/A`})})]}),(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`span`,{className:`sp-credential-label`,children:`Default Password`}),(0,o.jsxs)(`div`,{className:`sp-pw-row`,children:[(0,o.jsx)(`input`,{className:`sp-pw-input`,type:`text`,value:A.default_password||`N/A`,readOnly:!0}),(0,o.jsx)(`button`,{className:`sp-icon-btn`,onClick:()=>$(A.default_password),title:`Copy`,children:(0,o.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,o.jsx)(`rect`,{x:`5`,y:`5`,width:`9`,height:`9`,rx:`1.5`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,o.jsx)(`path`,{d:`M3 11V3a1 1 0 011-1h8`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`})]})})]})]})]})]})]}):(0,o.jsxs)(`div`,{className:`sp-empty`,children:[(0,o.jsx)(`div`,{className:`sp-empty-title`,children:`No details available`}),(0,o.jsx)(`div`,{className:`sp-empty-sub`,children:`Failed to load bursar data.`})]})}),(0,o.jsxs)(`div`,{className:`sp-footer`,children:[(0,o.jsx)(`span`,{className:`sp-footer-hint`,children:`Use tabs to switch between profile overview, edit form and credentials.`}),(0,o.jsx)(`button`,{className:`sp-footer-close`,onClick:Q,children:`Close`})]})]})})]})}export{u as default};