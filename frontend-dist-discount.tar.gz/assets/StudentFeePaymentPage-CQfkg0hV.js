import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{p as t}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as n,E as r,P as i,d as a,f as o,l as ee,u as s}from"./index-D6TxbaCx.js";var c=e(),l=t();function u(){let e=new Date().getHours();return e<12?`Good morning`:e<17?`Good afternoon`:`Good evening`}function d(e){let t=e?.response?.status,n=e?.response?.data;return t===422?n?.message??`Validation error.`:t===404?n?.message??`Not found.`:t===403?n?.message??`Forbidden.`:t===400?n?.message??`Bad request.`:n?.message??e?.message??`Something went wrong.`}function f(e){return Number(e??0).toLocaleString(`en-NG`,{style:`currency`,currency:`NGN`,maximumFractionDigits:0})}function p(e){let t=Number(e.balance??0),n=Number(e.total_amount??0);return t<=0?{label:`Paid`,tone:`paid`}:t<n?{label:`Partial`,tone:`partial`}:{label:`Unpaid`,tone:`unpaid`}}function m(){let{showSuccess:e,showError:t,showWarning:m}=ee(),[h,g]=(0,c.useState)(!1),[_,v]=(0,c.useState)(!0),[y,b]=(0,c.useState)(!1),[x,te]=(0,c.useState)(``),[S,ne]=(0,c.useState)(``),[C,re]=(0,c.useState)(``),[w,ie]=(0,c.useState)([]),[T,ae]=(0,c.useState)([]),[E,D]=(0,c.useState)(!1),[O,k]=(0,c.useState)(null),[A,j]=(0,c.useState)([]),[M,N]=(0,c.useState)(null),[P,F]=(0,c.useState)(null),[I,L]=(0,c.useState)(``),[R,z]=(0,c.useState)(null),B=e=>R===e,[oe,V]=(0,c.useState)(!1),[H,se]=(0,c.useState)(null),[U,ce]=(0,c.useState)(null),[W,G]=(0,c.useState)(``),[K,q]=(0,c.useState)(``),[J,Y]=(0,c.useState)(!1);(0,c.useEffect)(()=>{let e=window.setTimeout(()=>v(!1),120);return()=>window.clearTimeout(e)},[]),(0,c.useEffect)(()=>{let e=!0;async function t(){try{D(!0);let[t,n]=await Promise.all([i.get(`/facademic-sessions`),i.get(`/fterms`)]);if(!e)return;let r=t.data?.data??t.data??[];ie((Array.isArray(r)?r:[]).map(e=>({id:e.id,name:e.name??e.session??e.title??``})));let a=n.data?.data??n.data??[];ae((Array.isArray(a)?a:[]).map(e=>({id:e.id,name:e.name??e.term??``})))}catch{}finally{e&&D(!1)}}return t(),()=>{e=!1}},[]);async function X(){let n=x.trim();if(!n)return m(`Enter student registration number.`);try{b(!0);let t=await i.get(`/fees/student/details`,{params:{reg_no:n,session_id:S||void 0,term_id:C||void 0}});k(t.data?.student??null),j(Array.isArray(t.data?.fees)?t.data.fees:[]),N(t.data?.installment_plan??null),F(t.data?.full_payment_discount??t.data?.installment_plan?.full_payment_discount??null),e(`Student fee details loaded.`)}catch(e){console.error(e),k(null),j([]),N(null),F(null),t(d(e))}finally{b(!1)}}function le(e){e?.id&&(se(e),ce(e.id),G(``),Y(!1),q(String(Math.max(0,Number(e.balance??0)))),V(!0))}async function ue(){if(!U)return;let n=W.trim();if(!n)return t(`Enter payment method (e.g. bank transfer).`);let r=Number(K);if(Number.isNaN(r)||r<=0)return t(`Enter a valid amount.`);try{z(`fee:pay:${U}`),e((await i.post(`/fees/pay`,{student_fee_id:U,amount:r,payment_method:n,apply_full_discount:J})).data?.message??`Payment successful.`),V(!1),await X()}catch(e){console.error(e),t(d(e))}finally{z(null)}}let Z=(0,c.useMemo)(()=>{let e=I.trim().toLowerCase();return e?A.filter(t=>`${(t.feeType?.name??``).toLowerCase()} ${(t.term?.name??``).toLowerCase()} ${(t.session?.name??``).toLowerCase()} ${p(t).label.toLowerCase()} ${t.total_amount} ${t.amount_paid} ${t.balance}`.includes(e)):A},[A,I]),Q=(0,c.useMemo)(()=>({total:A.length,paid:A.filter(e=>Number(e.balance??0)<=0).length,outstanding:A.reduce((e,t)=>e+Number(t.balance??0),0),paidAmount:A.reduce((e,t)=>e+Number(t.amount_paid??0),0),totalAmount:A.reduce((e,t)=>e+Number(t.total_amount??0),0)}),[A]),$=!!x.trim()&&R===null&&!y;return(0,l.jsxs)(l.Fragment,{children:[(0,l.jsx)(`style`,{children:`
        /* ======= StudentFeePaymentPage - Modern SaaS style ======= */
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');
        .db-main {
          background: #F8FAFC;
          min-height: 100vh;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          padding: 24px 28px 0;
        }

        .db-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 18px;
          padding: 32px 36px;
          position: relative;
          overflow: hidden;
          margin-bottom: 24px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
        }
        .db-hero-glow {
          position: absolute;
          top: -60px;
          right: -60px;
          width: 320px;
          height: 320px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.15) 0%, transparent 65%);
          pointer-events: none;
        }
        .db-hero-glow2 {
          position: absolute;
          bottom: -40px;
          left: 30%;
          width: 200px;
          height: 200px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(37, 99, 235, 0.10) 0%, transparent 70%);
          pointer-events: none;
        }
        .db-hero-inner {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 32px;
          flex-wrap: wrap;
        }

        .db-session-badge {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.20);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius: 100px;
          padding: 4px 12px;
          margin-bottom: 12px;
        }
        .db-session-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #10B981;
          animation: dbPulse 2s ease infinite;
        }
        @keyframes dbPulse {
          0%,100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.4; transform: scale(1.5); }
        }

        .db-greeting {
          font-size: 26px;
          font-weight: 800;
          color: #fff;
          line-height: 1.1;
          margin-bottom: 8px;
        }
        .db-greeting em { font-style: normal; color: #FBBF24; }

        .db-hero-sub {
          font-size: 13.5px;
          color: #CBD5E1;
          line-height: 1.6;
          max-width: 620px;
          margin-bottom: 20px;
        }

        .db-hero-btns { display: flex; gap: 10px; flex-wrap: wrap; }

        .db-btn-gold {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 9px 18px;
          font-size: 13px;
          font-weight: 700;
          color: #FFFFFF;
          background: #D97706;
          border: none;
          border-radius: 10px;
          cursor: pointer;
          transition: all 0.2s ease;
          text-decoration: none;
          white-space: nowrap;
        }
        .db-btn-gold:hover { background: #B45309; transform: translateY(-1px); color: #FFFFFF; }
        .db-btn-gold:disabled { opacity: 0.55; cursor: not-allowed; transform: none; }

        .db-btn-outline {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 9px 18px;
          font-size: 13px;
          font-weight: 600;
          color: #FFFFFF;
          background: rgba(255, 255, 255, 0.10);
          border: 1px solid rgba(255, 255, 255, 0.20);
          border-radius: 10px;
          cursor: pointer;
          transition: all 0.2s ease;
          white-space: nowrap;
        }
        .db-btn-outline:hover { background: rgba(255, 255, 255, 0.18); color: #fff; }
        .db-btn-outline:disabled { opacity: 0.55; cursor: not-allowed; }

        .db-hero-stat-card {
          background: rgba(255, 255, 255, 0.08);
          border: 1px solid rgba(255, 255, 255, 0.15);
          backdrop-filter: blur(8px);
          border-radius: 14px;
          padding: 20px 24px;
          min-width: 320px;
        }
        .db-hero-stat-row { display: flex; flex-direction: column; gap: 10px; }
        .db-hero-stat-item { display: flex; justify-content: space-between; align-items: center; gap: 16px; }
        .db-hero-stat-label { font-size: 12px; font-weight: 400; color: #CBD5E1; }
        .db-hero-stat-val { font-size: 18px; font-weight: 800; color: #FBBF24; }
        .db-hero-stat-sep { height: 1px; background: rgba(255, 255, 255, 0.08); }

        .db-panel {
          background: #fff;
          border: 1px solid #E2E8F0;
          border-radius: 16px;
          overflow: hidden;
          box-shadow: 0 4px 16px rgba(15,39,68,0.03);
          margin-bottom: 24px;
        }
        .db-panel-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 18px 20px;
          border-bottom: 1px solid rgba(0, 0, 0, 0.06);
          gap: 12px;
          flex-wrap: wrap;
        }
        .db-panel-title-group { display: flex; align-items: center; gap: 12px; min-width: 240px; }
        .db-panel-icon {
          width: 36px;
          height: 36px;
          border-radius: 9px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: var(--pi, #fef3c7);
          color: var(--pc, #b45309);
          flex-shrink: 0;
        }
        .db-panel-title {
          font-family: "Lora", serif;
          font-size: 16px;
          font-weight: 700;
          color: #1a1a2e;
          margin: 0;
        }
        .db-panel-sub { font-size: 11.5px; font-weight: 300; color: #9a8a7a; margin: 0; }

        .db-table { width: 100%; border-collapse: collapse; }
        .db-table th {
          padding: 10px 16px;
          font-size: 11px;
          font-weight: 500;
          letter-spacing: 0.1em;
          text-transform: uppercase;
          color: #9a8a7a;
          background: #faf8f5;
          border-bottom: 1px solid rgba(0, 0, 0, 0.06);
          text-align: left;
          white-space: nowrap;
        }
        .db-table td {
          padding: 13px 16px;
          font-size: 13.5px;
          color: #4a4a5a;
          border-bottom: 1px solid rgba(0, 0, 0, 0.06);
          vertical-align: middle;
        }
        .db-table tbody tr { transition: background 0.15s; }
        .db-table tbody tr:hover { background: #faf8f5; }

        .db-skeleton {
          height: 14px;
          border-radius: 7px;
          background: linear-gradient(90deg, #f0ebe3 25%, #e8e0d5 50%, #f0ebe3 75%);
          background-size: 200% 100%;
          animation: dbSkeleton 1.4s ease infinite;
        }
        @keyframes dbSkeleton {
          from { background-position: 200% 0; }
          to { background-position: -200% 0; }
        }

        .db-pill {
          display: inline-flex;
          align-items: center;
          font-size: 12px;
          font-weight: 500;
          padding: 3px 10px;
          border-radius: 999px;
          background: rgba(30, 64, 175, 0.08);
          color: #1e40af;
          border: 1px solid rgba(30, 64, 175, 0.12);
          white-space: nowrap;
        }
        .db-pill--gold {
          background: rgba(180, 83, 9, 0.08);
          color: #b45309;
          border-color: rgba(180, 83, 9, 0.14);
        }
        .db-pill--violet {
          background: rgba(124, 58, 237, 0.08);
          color: #7c3aed;
          border-color: rgba(124, 58, 237, 0.12);
        }
        .db-pill--green {
          background: rgba(6, 95, 70, 0.08);
          color: #065f46;
          border-color: rgba(6, 95, 70, 0.12);
        }
        .db-pill--red {
          background: rgba(220, 38, 38, 0.08);
          color: #b91c1c;
          border-color: rgba(220, 38, 38, 0.14);
        }

        .db-refresh-btn {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 7px 14px;
          font-size: 12px;
          font-weight: 400;
          color: #7a6a5a;
          background: #f5f1eb;
          border: 1px solid #e5ddd3;
          border-radius: var(--bs-border-radius, 9px);
          cursor: pointer;
          transition: background 0.2s;
          white-space: nowrap;
        }
        .db-refresh-btn:hover { background: #ede8e0; }
        .db-refresh-btn:disabled { opacity: 0.5; cursor: not-allowed; }

        .db-grid2 { display: grid; grid-template-columns: 1fr 420px; gap: 18px; margin-bottom: 22px; }
        @media (max-width: 991.98px) {
          .db-grid2 { grid-template-columns: 1fr; }
          .db-main { padding: 18px 14px 0; }
          .db-hero { padding: 24px 20px; }
          .db-hero-stat-card { min-width: 0; width: 100%; }
        }
        @keyframes dbSpin { to { transform: rotate(360deg); } }
      `}),(0,l.jsx)(o,{sidebarOpen:h,setSidebarOpen:g}),(0,l.jsx)(n,{title:`Student Fee Payment`}),(0,l.jsx)(`div`,{className:`container-fluid`,children:(0,l.jsxs)(`div`,{className:`row`,children:[(0,l.jsx)(a,{sidebarOpen:h}),(0,l.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto db-main`,children:[_&&(0,l.jsx)(r,{message:`Loading fee payment...`}),(0,l.jsxs)(`div`,{className:`db-hero`,children:[(0,l.jsx)(`div`,{className:`db-hero-glow`,"aria-hidden":`true`}),(0,l.jsx)(`div`,{className:`db-hero-glow2`,"aria-hidden":`true`}),(0,l.jsxs)(`div`,{className:`db-hero-inner`,children:[(0,l.jsxs)(`div`,{children:[(0,l.jsxs)(`div`,{className:`db-session-badge`,children:[(0,l.jsx)(`span`,{className:`db-session-dot`}),`Fees • Payments`]}),(0,l.jsxs)(`h1`,{className:`db-greeting`,children:[u(),`, `,(0,l.jsx)(`em`,{children:`Admin.`})]}),(0,l.jsxs)(`p`,{className:`db-hero-sub`,children:[`Look up a student’s assigned fees by `,(0,l.jsx)(`b`,{children:`Reg No`}),`, optionally filter by `,(0,l.jsx)(`b`,{children:`Session`}),` and `,(0,l.jsx)(`b`,{children:`Term`}),`, then process payments. Payments can be restricted by your backend (e.g., receipt approval rules).`]}),(0,l.jsxs)(`div`,{className:`db-hero-btns`,children:[(0,l.jsxs)(`button`,{className:`db-btn-gold`,onClick:X,disabled:!$,title:x.trim()?``:`Enter Reg No`,children:[(0,l.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,l.jsx)(`circle`,{cx:`7`,cy:`7`,r:`5`,stroke:`currentColor`,strokeWidth:`1.5`}),(0,l.jsx)(`path`,{d:`M11 11l4 4`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`})]}),y?`Fetching...`:`Fetch Fees`]}),(0,l.jsxs)(`button`,{className:`db-btn-outline`,onClick:()=>{k(null),j([]),L(``)},disabled:R!==null||y,children:[(0,l.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,l.jsx)(`path`,{d:`M3 3l10 10`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`}),(0,l.jsx)(`path`,{d:`M13 3L3 13`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})]}),`Clear Results`]})]})]}),(0,l.jsxs)(`div`,{className:`db-hero-stat-card d-none d-md-block`,children:[(0,l.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,marginBottom:16},children:[(0,l.jsx)(`span`,{style:{fontSize:11,fontWeight:500,letterSpacing:`0.14em`,textTransform:`uppercase`,color:`#c9a84c`},children:`Quick glance`}),(0,l.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:(0,l.jsx)(`path`,{d:`M2 10V6M5 10V4M8 10V7M11 10V3`,stroke:`#64748b`,strokeWidth:`1.5`,strokeLinecap:`round`})})]}),(0,l.jsxs)(`div`,{className:`db-hero-stat-row`,children:[(0,l.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,l.jsx)(`span`,{className:`db-hero-stat-label`,children:`Fees loaded`}),(0,l.jsx)(`span`,{className:`db-hero-stat-val`,children:Q.total})]}),(0,l.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,l.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,l.jsx)(`span`,{className:`db-hero-stat-label`,children:`Fully paid`}),(0,l.jsx)(`span`,{className:`db-hero-stat-val`,children:Q.paid})]}),(0,l.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,l.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,l.jsx)(`span`,{className:`db-hero-stat-label`,children:`Outstanding`}),(0,l.jsx)(`span`,{className:`db-hero-stat-val`,children:f(Q.outstanding)})]})]})]})]})]}),(0,l.jsxs)(`div`,{className:`db-grid2`,children:[(0,l.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:18},children:[(0,l.jsxs)(`div`,{className:`db-panel`,children:[(0,l.jsxs)(`div`,{className:`db-panel-head`,children:[(0,l.jsxs)(`div`,{className:`db-panel-title-group`,children:[(0,l.jsx)(`div`,{className:`db-panel-icon`,style:{"--pi":`#dbeafe`,"--pc":`#1e40af`},children:(0,l.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,l.jsx)(`circle`,{cx:`7`,cy:`7`,r:`5`,stroke:`currentColor`,strokeWidth:`1.5`}),(0,l.jsx)(`path`,{d:`M11 11l4 4`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`})]})}),(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`p`,{className:`db-panel-title`,children:`Search Student`}),(0,l.jsx)(`p`,{className:`db-panel-sub`,children:`Reg No + optional Session/Term filters`})]})]}),(0,l.jsxs)(`button`,{className:`db-refresh-btn`,onClick:X,disabled:!$,children:[(0,l.jsxs)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,style:{animation:y?`dbSpin 0.8s linear infinite`:`none`},children:[(0,l.jsx)(`path`,{d:`M12 7A5 5 0 112 7`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,l.jsx)(`path`,{d:`M12 3v4h-4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`})]}),y?`Fetching...`:`Fetch Fees`]})]}),(0,l.jsxs)(`div`,{style:{padding:18},children:[(0,l.jsxs)(`div`,{className:`row g-3`,children:[(0,l.jsxs)(`div`,{className:`col-12 col-lg-4`,children:[(0,l.jsx)(`label`,{className:`form-label fw-semibold small mb-1`,children:`Registration Number`}),(0,l.jsx)(`input`,{className:`form-control`,placeholder:`Reg No (e.g. GQ/2026/012)`,value:x,onChange:e=>te(e.target.value),disabled:R!==null||y})]}),(0,l.jsxs)(`div`,{className:`col-12 col-lg-4`,children:[(0,l.jsx)(`label`,{className:`form-label fw-semibold small mb-1`,children:`Session (optional)`}),(0,l.jsxs)(`select`,{className:`form-select`,value:S,onChange:e=>ne(e.target.value),disabled:R!==null||E,title:w.length?``:`Optional (endpoint may not exist)`,children:[(0,l.jsx)(`option`,{value:``,children:`All Sessions`}),w.map(e=>(0,l.jsx)(`option`,{value:String(e.id),children:e.name},e.id))]})]}),(0,l.jsxs)(`div`,{className:`col-12 col-lg-4`,children:[(0,l.jsx)(`label`,{className:`form-label fw-semibold small mb-1`,children:`Term (optional)`}),(0,l.jsxs)(`select`,{className:`form-select`,value:C,onChange:e=>re(e.target.value),disabled:R!==null||E,title:T.length?``:`Optional (endpoint may not exist)`,children:[(0,l.jsx)(`option`,{value:``,children:`All Terms`}),T.map(e=>(0,l.jsx)(`option`,{value:String(e.id),children:e.name},e.id))]})]})]}),(0,l.jsx)(`hr`,{style:{opacity:.08}}),(0,l.jsxs)(`div`,{className:`row g-3`,children:[(0,l.jsxs)(`div`,{className:`col-12 col-lg-8`,children:[(0,l.jsx)(`label`,{className:`form-label fw-semibold small mb-1`,children:`Filter fees`}),(0,l.jsx)(`input`,{className:`form-control`,placeholder:`Type to filter by fee name, term, session, status…`,value:I,onChange:e=>L(e.target.value),disabled:!A.length})]}),(0,l.jsx)(`div`,{className:`col-12 col-lg-4 d-flex align-items-end gap-2`,children:(0,l.jsx)(`button`,{className:`btn btn-outline-secondary w-100`,onClick:()=>L(``),disabled:!I,style:{borderRadius:10},children:`Clear filter`})})]})]})]}),M?.enabled&&(0,l.jsxs)(`div`,{style:{background:`linear-gradient(135deg, #EFF6FF 0%, #DBEAFE 100%)`,border:`1px solid #BFDBFE`,borderRadius:14,padding:`14px 18px`,marginBottom:18,display:`flex`,alignItems:`center`,justifyContent:`space-between`,gap:14,flexWrap:`wrap`,boxShadow:`0 2px 8px rgba(30, 64, 175, 0.05)`},children:[(0,l.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:12},children:[(0,l.jsx)(`div`,{style:{width:40,height:40,borderRadius:10,background:`#2563EB`,color:`#FFFFFF`,display:`flex`,alignItems:`center`,justifyContent:`center`,fontSize:18},children:(0,l.jsx)(`i`,{className:`bi bi-pie-chart-fill`})}),(0,l.jsxs)(`div`,{children:[(0,l.jsxs)(`div`,{style:{fontWeight:800,fontSize:14,color:`#1E3A8A`},children:[`School Installment Policy (`,M.min_initial_percent,`% Initial Payment)`]}),(0,l.jsx)(`div`,{style:{fontSize:12.5,color:`#2563EB`},children:M.message||`Minimum initial payment for the term is ${f(M.min_initial_amount)}.`})]})]}),(0,l.jsxs)(`span`,{style:{background:`#1E40AF`,color:`#FFFFFF`,fontSize:11.5,fontWeight:700,padding:`5px 12px`,borderRadius:999,letterSpacing:`0.03em`},children:[(0,l.jsx)(`i`,{className:`bi bi-shield-check me-1`}),` Policy Active`]})]}),P?.enabled&&(0,l.jsxs)(`div`,{style:{background:`linear-gradient(135deg, #ECFDF5 0%, #D1FAE5 100%)`,border:`1px solid #6EE7B7`,borderRadius:14,padding:`14px 18px`,marginBottom:18,display:`flex`,alignItems:`center`,justifyContent:`space-between`,gap:14,flexWrap:`wrap`,boxShadow:`0 2px 8px rgba(5, 150, 105, 0.06)`},children:[(0,l.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:12},children:[(0,l.jsx)(`div`,{style:{width:40,height:40,borderRadius:10,background:`#059669`,color:`#FFFFFF`,display:`flex`,alignItems:`center`,justifyContent:`center`,fontSize:18},children:(0,l.jsx)(`i`,{className:`bi bi-tag-fill`})}),(0,l.jsxs)(`div`,{children:[(0,l.jsxs)(`div`,{style:{fontWeight:800,fontSize:14,color:`#065F46`},children:[`Full-Payment Early Incentive Active (`,P.formatted_discount,` Discount)`]}),(0,l.jsx)(`div`,{style:{fontSize:12.5,color:`#047857`},children:P.message||`Full upfront settlements save ${P.formatted_discount} (${f(P.discount_amount)}).`})]})]}),(0,l.jsxs)(`span`,{style:{background:`#047857`,color:`#FFFFFF`,fontSize:11.5,fontWeight:700,padding:`5px 12px`,borderRadius:999,letterSpacing:`0.03em`},children:[(0,l.jsx)(`i`,{className:`bi bi-patch-check-fill me-1`}),` Discount Active`]})]}),(0,l.jsxs)(`div`,{className:`db-panel`,children:[(0,l.jsxs)(`div`,{className:`db-panel-head`,children:[(0,l.jsxs)(`div`,{className:`db-panel-title-group`,children:[(0,l.jsx)(`div`,{className:`db-panel-icon`,style:{"--pi":`#fef3c7`,"--pc":`#b45309`},children:(0,l.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,l.jsx)(`path`,{d:`M4 2h8v12H4z`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinejoin:`round`}),(0,l.jsx)(`path`,{d:`M6 5h4M6 8h4M6 11h3`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`})]})}),(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`p`,{className:`db-panel-title`,children:`Assigned Fees`}),(0,l.jsx)(`p`,{className:`db-panel-sub`,children:`Pay selected fee items (backend may enforce receipt approval)`})]})]}),(0,l.jsxs)(`button`,{className:`db-refresh-btn`,onClick:X,disabled:!$,children:[(0,l.jsxs)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,style:{animation:y?`dbSpin 0.8s linear infinite`:`none`},children:[(0,l.jsx)(`path`,{d:`M12 7A5 5 0 112 7`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,l.jsx)(`path`,{d:`M12 3v4h-4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`})]}),`Refresh`]})]}),(0,l.jsx)(`div`,{style:{overflowX:`auto`},children:(0,l.jsxs)(`table`,{className:`db-table`,children:[(0,l.jsx)(`thead`,{children:(0,l.jsxs)(`tr`,{children:[(0,l.jsx)(`th`,{style:{width:60},children:`#`}),(0,l.jsx)(`th`,{children:`Fee`}),(0,l.jsx)(`th`,{style:{width:140,textAlign:`right`},children:`Total`}),(0,l.jsx)(`th`,{style:{width:140,textAlign:`right`},children:`Paid`}),(0,l.jsx)(`th`,{style:{width:140,textAlign:`right`},children:`Balance`}),(0,l.jsx)(`th`,{style:{width:140},children:`Term`}),(0,l.jsx)(`th`,{style:{width:180},children:`Session`}),(0,l.jsx)(`th`,{style:{width:120},children:`Status`}),(0,l.jsx)(`th`,{style:{width:160,textAlign:`right`},children:`Action`})]})}),(0,l.jsx)(`tbody`,{children:O?y?(0,l.jsx)(`tr`,{children:(0,l.jsxs)(`td`,{colSpan:9,style:{padding:18},children:[(0,l.jsx)(`div`,{className:`db-skeleton`,style:{width:`60%`,marginBottom:10}}),(0,l.jsx)(`div`,{className:`db-skeleton`,style:{width:`90%`,marginBottom:10}}),(0,l.jsx)(`div`,{className:`db-skeleton`,style:{width:`80%`}})]})}):Z.length===0?(0,l.jsx)(`tr`,{children:(0,l.jsx)(`td`,{colSpan:9,style:{padding:18,textAlign:`center`,color:`#9a8a7a`},children:`No fees found. Try adjusting filters (Session/Term) or the search keyword.`})}):Z.map((e,t)=>{let n=p(e),r=n.tone===`paid`,i=U===e.id&&B(`fee:pay:${e.id}`),a=n.tone===`paid`?`db-pill db-pill--green`:n.tone===`partial`?`db-pill db-pill--gold`:`db-pill`;return(0,l.jsxs)(`tr`,{children:[(0,l.jsx)(`td`,{children:t+1}),(0,l.jsxs)(`td`,{children:[(0,l.jsx)(`div`,{style:{fontWeight:600,color:`#1a1a2e`},children:e.feeType?.name??`Fee Type #${e.fee_type_id}`}),(0,l.jsxs)(`div`,{style:{fontSize:12,color:`#9a8a7a`},children:[`StudentFee ID: `,e.id]})]}),(0,l.jsx)(`td`,{style:{textAlign:`right`,fontWeight:700,color:`#1a1a2e`},children:f(e.total_amount)}),(0,l.jsx)(`td`,{style:{textAlign:`right`},children:f(e.amount_paid)}),(0,l.jsx)(`td`,{style:{textAlign:`right`,fontWeight:700},children:f(e.balance)}),(0,l.jsx)(`td`,{children:(0,l.jsx)(`span`,{className:`db-pill db-pill--violet`,children:e.term?.name??`#${e.term_id}`})}),(0,l.jsx)(`td`,{children:(0,l.jsx)(`span`,{className:`db-pill`,children:e.session?.name??`#${e.session_id}`})}),(0,l.jsx)(`td`,{children:(0,l.jsx)(`span`,{className:a,children:n.label})}),(0,l.jsx)(`td`,{style:{textAlign:`right`},children:(0,l.jsx)(`button`,{className:`db-refresh-btn`,onClick:()=>le(e),disabled:R!==null||r,title:r?`Already fully paid`:`Pay fee`,style:{background:r?`#f5f1eb`:`rgba(201,168,76,0.16)`,borderColor:r?`#e5ddd3`:`rgba(201,168,76,0.26)`,color:r?`#7a6a5a`:`#1a1a2e`},children:i?(0,l.jsxs)(l.Fragment,{children:[(0,l.jsx)(`span`,{className:`spinner-border spinner-border-sm`,style:{width:14,height:14}}),`Paying…`]}):(0,l.jsxs)(l.Fragment,{children:[(0,l.jsxs)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,l.jsx)(`path`,{d:`M2.5 6.5h11`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,l.jsx)(`path`,{d:`M4 10h3`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,l.jsx)(`path`,{d:`M3.5 4.5h9a1.5 1.5 0 011.5 1.5v5a1.5 1.5 0 01-1.5 1.5h-9A1.5 1.5 0 012 11V6a1.5 1.5 0 011.5-1.5z`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinejoin:`round`})]}),`Pay`]})})})]},e.id)}):(0,l.jsx)(`tr`,{children:(0,l.jsxs)(`td`,{colSpan:9,style:{padding:18,textAlign:`center`,color:`#9a8a7a`},children:[`Enter Reg No and click `,(0,l.jsx)(`b`,{children:`Fetch`}),` to load assigned fees.`]})})})]})})]})]}),(0,l.jsxs)(`div`,{className:`db-panel`,style:{height:`fit-content`,position:`sticky`,top:16},children:[(0,l.jsxs)(`div`,{className:`db-panel-head`,children:[(0,l.jsxs)(`div`,{className:`db-panel-title-group`,children:[(0,l.jsx)(`div`,{className:`db-panel-icon`,style:{"--pi":`#d1fae5`,"--pc":`#065f46`},children:(0,l.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,l.jsx)(`circle`,{cx:`8`,cy:`5.5`,r:`3`,stroke:`currentColor`,strokeWidth:`1.4`}),(0,l.jsx)(`path`,{d:`M3 14c0-3 3-5 5-5s5 2 5 5`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`})]})}),(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`p`,{className:`db-panel-title`,children:`Student Snapshot`}),(0,l.jsx)(`p`,{className:`db-panel-sub`,children:`Overview of totals and outstanding balance`})]})]}),(0,l.jsx)(`button`,{className:`db-refresh-btn`,onClick:X,disabled:!$,children:`Refresh`})]}),(0,l.jsx)(`div`,{style:{padding:18},children:O?(0,l.jsxs)(l.Fragment,{children:[(0,l.jsx)(`div`,{style:{fontWeight:700,color:`#1a1a2e`},children:O.name}),(0,l.jsxs)(`div`,{style:{marginTop:6,color:`#9a8a7a`,fontSize:12.5},children:[(0,l.jsxs)(`div`,{children:[`Reg No: `,(0,l.jsx)(`b`,{style:{color:`#1a1a2e`},children:O.reg_no})]}),(0,l.jsxs)(`div`,{style:{marginTop:6,display:`flex`,gap:8,flexWrap:`wrap`},children:[(0,l.jsx)(`span`,{className:`db-pill`,children:O.section}),(0,l.jsx)(`span`,{className:`db-pill db-pill--violet`,children:O.class})]})]}),(0,l.jsx)(`hr`,{style:{opacity:.08}}),(0,l.jsxs)(`div`,{style:{display:`grid`,gap:10},children:[(0,l.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:12},children:[(0,l.jsx)(`span`,{style:{color:`#9a8a7a`,fontSize:12},children:`Total fees`}),(0,l.jsx)(`span`,{style:{fontFamily:`Lora, serif`,fontWeight:700,color:`#1a1a2e`},children:Q.total})]}),(0,l.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:12},children:[(0,l.jsx)(`span`,{style:{color:`#9a8a7a`,fontSize:12},children:`Fully paid`}),(0,l.jsx)(`span`,{style:{fontFamily:`Lora, serif`,fontWeight:700,color:`#1a1a2e`},children:Q.paid})]}),(0,l.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:12},children:[(0,l.jsx)(`span`,{style:{color:`#9a8a7a`,fontSize:12},children:`Total amount`}),(0,l.jsx)(`span`,{style:{fontFamily:`Lora, serif`,fontWeight:700,color:`#1a1a2e`},children:f(Q.totalAmount)})]}),(0,l.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:12},children:[(0,l.jsx)(`span`,{style:{color:`#9a8a7a`,fontSize:12},children:`Paid amount`}),(0,l.jsx)(`span`,{style:{fontFamily:`Lora, serif`,fontWeight:700,color:`#1a1a2e`},children:f(Q.paidAmount)})]}),(0,l.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:12},children:[(0,l.jsx)(`span`,{style:{color:`#9a8a7a`,fontSize:12},children:`Outstanding`}),(0,l.jsx)(`span`,{style:{fontFamily:`Lora, serif`,fontWeight:700,color:`#b45309`},children:f(Q.outstanding)})]})]}),(0,l.jsx)(`div`,{style:{marginTop:14},className:`db-pill db-pill--red`,children:`Backend may reject payment if receipt is not approved.`})]}):(0,l.jsx)(`div`,{style:{color:`#9a8a7a`},children:`No student loaded yet. Use the search to load fee details.`})})]})]}),(0,l.jsx)(`div`,{className:`mt-auto`,children:(0,l.jsx)(s,{})}),oe&&U&&(0,l.jsx)(`div`,{className:`position-fixed top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center`,style:{background:`rgba(15, 23, 42, 0.55)`,backdropFilter:`blur(6px)`,zIndex:1100,padding:12},onClick:()=>R?null:V(!1),children:(0,l.jsxs)(`div`,{className:`db-panel`,style:{width:`100%`,maxWidth:720,borderRadius:16,boxShadow:`0 30px 80px rgba(0,0,0,0.35)`},onClick:e=>e.stopPropagation(),children:[(0,l.jsxs)(`div`,{className:`db-panel-head`,style:{borderBottom:`1px solid rgba(0,0,0,0.08)`},children:[(0,l.jsxs)(`div`,{className:`db-panel-title-group`,children:[(0,l.jsx)(`div`,{className:`db-panel-icon`,style:{"--pi":`#ede9fe`,"--pc":`#7c3aed`},children:(0,l.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,l.jsx)(`path`,{d:`M3.5 4.5h9a1.5 1.5 0 011.5 1.5v5a1.5 1.5 0 01-1.5 1.5h-9A1.5 1.5 0 012 11V6a1.5 1.5 0 011.5-1.5z`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinejoin:`round`}),(0,l.jsx)(`path`,{d:`M2.5 6.5h11`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,l.jsx)(`path`,{d:`M4 10h3`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`})]})}),(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`p`,{className:`db-panel-title`,children:`Pay Fee`}),(0,l.jsx)(`p`,{className:`db-panel-sub`,children:`Payment may require an approved receipt (backend enforced)`})]})]}),(0,l.jsx)(`button`,{className:`db-refresh-btn`,onClick:()=>V(!1),disabled:R!==null,style:{background:`transparent`},title:`Close`,children:`Close`})]}),(0,l.jsxs)(`div`,{style:{padding:18},children:[(0,l.jsxs)(`div`,{className:`row g-3`,children:[(0,l.jsxs)(`div`,{className:`col-12`,children:[(0,l.jsx)(`label`,{className:`form-label fw-semibold small mb-1`,children:`Payment Method *`}),(0,l.jsx)(`div`,{className:`d-flex gap-2 mb-2 flex-wrap`,children:[`Cash`,`Bank Transfer`,`POS`].map(e=>(0,l.jsx)(`button`,{type:`button`,className:`btn btn-sm ${W===e?`btn-dark`:`btn-outline-secondary`}`,style:{borderRadius:8,fontSize:12,fontWeight:600},onClick:()=>G(e),disabled:R!==null,children:e},e))}),(0,l.jsx)(`input`,{className:`form-control`,placeholder:`e.g. Bank Transfer / POS / Cash`,value:W,onChange:e=>G(e.target.value),disabled:R!==null}),(0,l.jsxs)(`div`,{className:`form-text`,children:[`Must match the method used for the uploaded receipt (backend checks `,(0,l.jsx)(`code`,{children:`payment_method`}),`).`]})]}),P?.enabled&&H&&(0,l.jsxs)(`div`,{className:`col-12`,style:{background:J?`#F0FDF4`:`#F8FAFC`,border:`1.5px solid ${J?`#86EFAC`:`#E2E8F0`}`,borderRadius:12,padding:`14px 16px`,transition:`all 0.15s ease`},children:[(0,l.jsxs)(`div`,{className:`d-flex align-items-center justify-content-between mb-0`,children:[(0,l.jsxs)(`label`,{className:`form-check-label fw-bold small text-dark d-flex align-items-center gap-2 mb-0`,htmlFor:`applyDiscountSwitch`,style:{cursor:`pointer`},children:[(0,l.jsx)(`i`,{className:`bi bi-tag-fill text-success fs-6`}),(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`div`,{children:`Apply Full-Payment Early Settlement Discount`}),(0,l.jsxs)(`div`,{className:`text-muted fw-normal`,style:{fontSize:11.5},children:[P.formatted_discount,` discount on full fee settlement`]})]})]}),(0,l.jsx)(`div`,{className:`form-check form-switch m-0`,children:(0,l.jsx)(`input`,{className:`form-check-input`,type:`checkbox`,role:`switch`,id:`applyDiscountSwitch`,style:{width:`2.4em`,height:`1.2em`,cursor:`pointer`},checked:J,disabled:R!==null,onChange:e=>{let t=e.target.checked;Y(t);let n=Number(H.balance||0),r=Number(H.total_amount||0);if(t){let e=P.discount_type===`percentage`?P.discount_value/100*(r>0?r:n):P.discount_value,t=Math.min(e,n);q(String(Math.max(0,Math.round((n-t)*100)/100)))}else q(String(n))}})})]}),J&&(0,l.jsxs)(`div`,{className:`mt-2 pt-2 border-top small text-success fw-semibold d-flex justify-content-between align-items-center`,children:[(0,l.jsx)(`span`,{children:`Settles Fee in Full at Discount:`}),(0,l.jsxs)(`span`,{className:`badge bg-success text-white`,children:[`Pay `,f(Number(K)),` (Waives `,f(Math.max(0,Number(H.balance||0)-Number(K))),`)`]})]})]}),(0,l.jsxs)(`div`,{className:`col-12`,children:[(0,l.jsxs)(`div`,{className:`d-flex justify-content-between align-items-center mb-1`,children:[(0,l.jsx)(`label`,{className:`form-label fw-semibold small mb-0`,children:`Amount (₦) *`}),M?.enabled&&(0,l.jsxs)(`span`,{className:`badge bg-primary-subtle text-primary border border-primary-subtle`,children:[`Min `,M.min_initial_percent,`% Initial`]})]}),M?.enabled&&(0,l.jsxs)(`div`,{className:`alert alert-info py-2 px-3 mb-2`,style:{fontSize:12.5,borderRadius:8},children:[(0,l.jsx)(`i`,{className:`bi bi-info-circle me-1`}),M.message||`Minimum initial payment required is ${f(M.min_payable_now)}.`]}),M?.presets&&M.presets.length>0&&(0,l.jsx)(`div`,{className:`d-flex gap-2 mb-2 flex-wrap`,children:M.presets.map((e,t)=>{let n=K===String(e.amount),r=!!e.discount_applied;return(0,l.jsxs)(`button`,{type:`button`,className:`btn btn-sm ${n?r?`btn-success`:`btn-primary`:r?`btn-outline-success`:`btn-outline-primary`}`,style:{borderRadius:8,fontSize:12,fontWeight:600},onClick:()=>{q(String(e.amount)),e.discount_applied?Y(!0):Y(!1)},disabled:R!==null,children:[r&&(0,l.jsx)(`i`,{className:`bi bi-patch-check-fill me-1`}),e.label,` (`,f(e.amount),`)`]},t)})}),(0,l.jsx)(`input`,{className:`form-control`,type:`number`,min:1,value:K,onChange:e=>q(e.target.value),disabled:R!==null}),(0,l.jsx)(`div`,{className:`form-text`,children:J?`Full payment discount applied: Settles fee in full upon payment.`:`Backend will reject if amount exceeds the remaining balance.`})]}),(0,l.jsx)(`div`,{className:`col-12`,children:(0,l.jsxs)(`div`,{className:`alert alert-warning mb-0`,children:[(0,l.jsx)(`b`,{children:`If payment fails`}),`, confirm the student has uploaded a receipt and it is `,(0,l.jsx)(`b`,{children:`approved`}),`.`]})})]}),(0,l.jsxs)(`div`,{className:`d-flex flex-wrap gap-2 justify-content-end mt-4`,children:[(0,l.jsx)(`button`,{className:`btn btn-outline-secondary`,onClick:()=>V(!1),disabled:R!==null,style:{borderRadius:10},children:`Cancel`}),(0,l.jsx)(`button`,{className:`btn`,onClick:ue,disabled:R!==null,style:{borderRadius:10,fontWeight:700,background:`#c9a84c`,border:`1px solid rgba(201,168,76,0.35)`,color:`#0f172a`},children:B(`fee:pay:${U}`)?(0,l.jsxs)(l.Fragment,{children:[(0,l.jsx)(`span`,{className:`spinner-border spinner-border-sm me-2`}),`Processing...`]}):`Confirm Payment`})]})]})]})})]})]})})]})}export{m as default};