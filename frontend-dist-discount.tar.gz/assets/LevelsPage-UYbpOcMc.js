import{i as e}from"./rolldown-runtime-CWU8vmCm.js";import{Ut as t}from"./vendor-misc-OZLc0tLq.js";import{p as n}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as r,E as i,P as a,d as o,f as s,l as ee,u as c}from"./index-D6TxbaCx.js";var l=e(t(),1),u=n();function d(e){let t=e?.response?.status,n=e?.response?.data;if(t===409)return n?.message??`This item already exists.`;if(t===422){let e=n?.errors;if(e){let t=e[Object.keys(e)[0]]?.[0];if(t)return t}return n?.message??`Validation error.`}return t===404?n?.message??`Not found.`:n?.message??e?.message??`Something went wrong.`}function f(){let e=new Date().getHours();return e<12?`Good morning`:e<17?`Good afternoon`:`Good evening`}var p=(e,t,n)=>Math.max(t,Math.min(n,e));function m(){let{showSuccess:e,showError:t}=ee(),[n,m]=(0,l.useState)(!1),[h,g]=(0,l.useState)(!0),[_,v]=(0,l.useState)(!0),[y,b]=(0,l.useState)(!0),[x,te]=(0,l.useState)([]),[S,C]=(0,l.useState)([]),[w,T]=(0,l.useState)(``),[E,D]=(0,l.useState)(!1),[O,k]=(0,l.useState)(null),[A,j]=(0,l.useState)(!1),[M,N]=(0,l.useState)(!1),[P,F]=(0,l.useState)({name:``,description:``,section_id:``}),[I,L]=(0,l.useState)(null),[R,z]=(0,l.useState)({name:``,description:``,section_id:``}),B=e=>O===e;async function V(){try{v(!0),te((await a.get(`/levels`,{params:E?{archived:1}:void 0})).data??[])}catch(e){t(d(e))}finally{v(!1)}}async function H(){try{b(!0),C((await a.get(`/all-sections`)).data??[])}catch(e){t(d(e))}finally{b(!1)}}(0,l.useEffect)(()=>{g(!0),Promise.all([V(),H()]).finally(()=>g(!1))},[E]);let U=e=>e.section?.name??S.find(t=>t.id===e.section_id)?.name??`-`,W=(0,l.useMemo)(()=>{let e=w.trim().toLowerCase();return e?x.filter(t=>{let n=U(t);return`${t.name??``} ${t.description??``} ${n}`.toLowerCase().includes(e)}):x},[x,w,S]),G=x.length,K=(0,l.useMemo)(()=>x.filter(e=>!!e.section_id).length,[x]),q=G-K,[J,Y]=(0,l.useState)(1);(0,l.useEffect)(()=>{Y(1)},[w]);let X=(0,l.useMemo)(()=>Math.max(1,Math.ceil(W.length/10)),[W.length]),Z=p(J,1,X),Q=(0,l.useMemo)(()=>{let e=(Z-1)*10;return W.slice(e,e+10)},[W,Z]);async function ne(){let n=P.name.trim();if(!n)return t(`Please enter a class name.`);if(n.length>50)return t(`Class name must not exceed 50 characters.`);try{k(`level:create`);let t={name:n,description:P.description?.trim()||null};P.section_id&&(t.section_id=Number(P.section_id)),e((await a.post(`/levels`,t)).data?.message??`Class created successfully.`),j(!1),F({name:``,description:``,section_id:``}),await V()}catch(e){t(d(e))}finally{k(null)}}function $(e){L(e.id),z({name:e.name??``,description:e.description??``,section_id:e.section_id??``}),N(!0)}async function re(){if(!I)return;let n=R.name.trim();if(!n)return t(`Please enter a class name.`);try{k(`level:update:${I}`);let t={name:n,description:R.description?.trim()||null,section_id:R.section_id?Number(R.section_id):null};e((await a.put(`/levels/${I}`,t)).data?.message??`Class updated successfully.`),N(!1),L(null),await V()}catch(e){t(d(e))}finally{k(null)}}async function ie(n){if(window.confirm(`Archive "${n.name}"?\n\nArchived classes will be hidden from future setup and result forms, but old records will remain safe.`))try{k(`level:archive:${n.id}`),e((await a.delete(`/levels/${n.id}`)).data?.message??`Class archived successfully.`),await V()}catch(e){t(d(e))}finally{k(null)}}async function ae(n){try{k(`level:restore:${n.id}`),e((await a.post(`/levels/${n.id}/restore`)).data?.message??`Class restored successfully.`),await V()}catch(e){t(d(e))}finally{k(null)}}let oe=[{color:`#b45309`,bg:`#fef3c7`,label:`total configured`},{color:`#065f46`,bg:`#d1fae5`,label:`linked to section`},{color:`#1e40af`,bg:`#dbeafe`,label:`not linked`},{color:`#7c3aed`,bg:`#ede9fe`,label:`available sections`}];return(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`style`,{children:`
        /* ======= LevelsPage - Modern SaaS style ======= */
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');

        .db-main {
          background: #F8FAFC;
          min-height: 100vh;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          padding: 24px 28px 0;
        }

        .db-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 18px;
          padding: 32px 36px;
          position: relative;
          overflow: hidden;
          margin-bottom: 24px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
        }
        .db-hero-glow {
          position: absolute;
          top: -60px;
          right: -60px;
          width: 320px;
          height: 320px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.15) 0%, transparent 65%);
          pointer-events: none;
        }
        .db-hero-glow2 {
          position: absolute;
          bottom: -40px;
          left: 30%;
          width: 200px;
          height: 200px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(37, 99, 235, 0.10) 0%, transparent 70%);
          pointer-events: none;
        }
        .db-hero-inner {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 28px;
          flex-wrap: wrap;
        }

        .db-session-badge {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.20);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius: 100px;
          padding: 4px 12px;
          margin-bottom: 12px;
        }
        .db-session-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #10B981;
          animation: dbPulse 2s ease infinite;
        }
        @keyframes dbPulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.4; transform: scale(1.5); }
        }

        .db-greeting {
          font-size: 26px;
          font-weight: 800;
          color: #fff;
          line-height: 1.1;
          margin-bottom: 8px;
        }
        .db-greeting em { font-style: normal; color: #FBBF24; }

        .db-hero-sub {
          font-size: 13.5px;
          color: #CBD5E1;
          line-height: 1.6;
          max-width: 560px;
          margin-bottom: 20px;
        }

        .db-hero-btns { display:flex; gap:10px; flex-wrap:wrap; }

        .db-btn-gold {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 9px 18px;
          font-size: 13px;
          font-weight: 700;
          color: #FFFFFF;
          background: #D97706;
          border: none;
          border-radius: 10px;
          cursor: pointer;
          transition: all 0.2s ease;
          text-decoration: none;
          white-space: nowrap;
        }
        .db-btn-gold:hover { background: #B45309; transform: translateY(-1px); color: #FFFFFF; }

        .db-btn-outline {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 9px 18px;
          font-size: 13px;
          font-weight: 600;
          color: #FFFFFF;
          background: rgba(255, 255, 255, 0.10);
          border: 1px solid rgba(255, 255, 255, 0.20);
          border-radius: 10px;
          cursor: pointer;
          transition: all 0.2s ease;
          white-space: nowrap;
        }
        .db-btn-outline:hover {
          background: rgba(255, 255, 255, 0.18);
          color: #fff;
        }

        .db-hero-stat-card {
          background: rgba(255, 255, 255, 0.08);
          border: 1px solid rgba(255, 255, 255, 0.15);
          backdrop-filter: blur(8px);
          border-radius: 14px;
          padding: 20px 24px;
          min-width: 240px;
        }
        .db-hero-stat-row { display:flex; flex-direction:column; gap:10px; }
        .db-hero-stat-item { display:flex; justify-content:space-between; align-items:center; gap:16px; }
        .db-hero-stat-label { font-size:12px; font-weight:400; color: #CBD5E1; }
        .db-hero-stat-val { font-size: 18px; font-weight: 800; color: #FBBF24; }
        .db-hero-stat-sep { height: 1px; background: rgba(255, 255, 255, 0.08); }

        .db-stats {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 16px;
          margin-bottom: 18px;
        }
        @media (max-width: 1199.98px) { .db-stats { grid-template-columns: repeat(2, 1fr);} }
        @media (max-width: 575.98px) { .db-stats { grid-template-columns: 1fr; } }

        .db-stat {
          background: #fff;
          border: 1px solid #ede8e0;
          border-radius: 14px;
          padding: 22px 20px;
          position: relative;
          overflow: hidden;
          cursor: default;
          transition: box-shadow 0.25s, transform 0.25s;
        }
        .db-stat:hover { box-shadow: 0 8px 28px rgba(0,0,0,0.08); transform: translateY(-3px); }
        .db-stat::before {
          content: "";
          position: absolute;
          top: 0; left: 0; right: 0;
          height: 3px;
          background: var(--sc, #b45309);
          transform: scaleX(0);
          transform-origin: left;
          transition: transform 0.3s ease;
        }
        .db-stat:hover::before { transform: scaleX(1); }

        .db-stat-head { display:flex; align-items:flex-start; justify-content:space-between; margin-bottom: 14px; }
        .db-stat-icon {
          width: 42px; height: 42px;
          border-radius: 10px;
          background: var(--si, #fef3c7);
          color: var(--sc, #b45309);
          display:flex; align-items:center; justify-content:center;
          transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
        }
        .db-stat:hover .db-stat-icon { transform: scale(1.1) rotate(-4deg); }
        .db-stat-more { color: #c8bfb5; padding: 2px; }

        .db-stat-label { font-size: 12px; font-weight: 500; color: #9a8a7a; margin-bottom: 6px; letter-spacing: .03em; }
        .db-stat-val { font-family: "Lora", Georgia, serif; font-size: 28px; font-weight: 700; color: #1a1a2e; line-height: 1; }
        .db-stat-footer {
          display:flex; align-items:center; gap:6px;
          margin-top: 12px; padding-top: 10px;
          border-top: 1px solid rgba(0,0,0,0.06);
          font-size: 12px; color: #9a8a7a;
        }
        .db-stat-trend { color:#22c55e; font-weight:600; }

        .db-panel {
          background: #fff;
          border: 1px solid #ede8e0;
          border-radius: 14px;
          overflow: hidden;
          margin-bottom: 24px;
        }

        .db-panel-head {
          display:flex;
          align-items:center;
          justify-content: space-between;
          padding: 18px 20px 16px;
          border-bottom: 1px solid rgba(0,0,0,0.06);
          gap: 12px;
          flex-wrap: wrap;
        }
        .db-panel-title-group { display:flex; align-items:center; gap:12px; }
        .db-panel-icon {
          width: 36px; height: 36px; border-radius: 9px;
          display:flex; align-items:center; justify-content:center;
          background: var(--pi, #fef3c7);
          color: var(--pc, #b45309);
          flex-shrink: 0;
        }
        .db-panel-title { font-family: "Lora", serif; font-size: 16px; font-weight: 700; color: #1a1a2e; margin: 0; }
        .db-panel-sub { font-size: 11.5px; font-weight: 300; color: #9a8a7a; margin: 0; }

        .db-toolbar {
          display:flex;
          align-items:center;
          gap: 10px;
          flex-wrap: wrap;
        }
        .db-input {
          display:flex;
          align-items:center;
          gap: 8px;
          padding: 10px 12px;
          background: #faf8f5;
          border: 1px solid #e5ddd3;
          border-radius: 12px;
          min-width: 280px;
        }
        .db-input input {
          border: none;
          outline: none;
          background: transparent;
          width: 100%;
          font-size: 13.5px;
          color: #1a1a2e;
        }
        .db-chip-btn {
          display:inline-flex;
          align-items:center;
          gap: 6px;
          padding: 8px 12px;
          font-size: 12.5px;
          font-weight: 500;
          color: #7a6a5a;
          background: #f5f1eb;
          border: 1px solid #e5ddd3;
          border-radius: 10px;
          cursor: pointer;
          transition: background .2s, color .2s, transform .2s;
          white-space: nowrap;
        }
        .db-chip-btn:hover:not(:disabled) { background:#ede8e0; color:#1a1a2e; transform: translateY(-1px); }
        .db-chip-btn:disabled { opacity: .5; cursor: not-allowed; }

        .db-table {
          width: 100%;
          border-collapse: collapse;
        }
        .db-table th {
          padding: 10px 16px;
          font-size: 11px;
          font-weight: 600;
          letter-spacing: 0.10em;
          text-transform: uppercase;
          color: #9a8a7a;
          background: #faf8f5;
          border-bottom: 1px solid rgba(0,0,0,0.06);
          text-align: left;
          white-space: nowrap;
        }
        .db-table th:last-child { text-align: right; }
        .db-table td {
          padding: 13px 16px;
          font-size: 13.5px;
          color: #4a4a5a;
          border-bottom: 1px solid rgba(0,0,0,0.06);
          vertical-align: middle;
        }
        .db-table tbody tr { transition: background 0.15s; }
        .db-table tbody tr:hover { background: #faf8f5; }
        .db-table tbody tr:last-child td { border-bottom: none; }

        .db-pill {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          font-size: 12.5px;
          font-weight: 600;
          padding: 4px 10px;
          border-radius: 999px;
          background: #f0ebe3;
          color: #7a6a5a;
        }

        .db-actions {
          display: inline-flex;
          justify-content: flex-end;
          gap: 8px;
          flex-wrap: wrap;
        }

        .db-action-btn {
          display:inline-flex;
          align-items:center;
          gap: 6px;
          padding: 7px 12px;
          font-size: 12.5px;
          font-weight: 600;
          border-radius: 10px;
          cursor: pointer;
          border: 1px solid rgba(0,0,0,0.10);
          background: #fff;
          transition: transform .2s, box-shadow .2s, background .2s;
          white-space: nowrap;
        }
        .db-action-btn:hover:not(:disabled) {
          transform: translateY(-1px);
          box-shadow: 0 8px 18px rgba(0,0,0,0.08);
          background: #faf8f5;
        }
        .db-action-btn:disabled { opacity: .5; cursor: not-allowed; }

        .db-action-primary { border-color: rgba(30, 64, 175, 0.25); color: #1e40af; }
        .db-action-gold    { border-color: rgba(180, 83, 9, 0.25); color: #b45309; }
        .db-action-danger  { border-color: rgba(185, 28, 28, 0.25); color: #b91c1c; }
        .db-action-green   { border-color: rgba(6, 95, 70, 0.25); color: #065f46; }

        .db-pagination {
          display:flex;
          align-items:center;
          justify-content: space-between;
          padding: 14px 16px;
          border-top: 1px solid rgba(0,0,0,0.06);
          flex-wrap: wrap;
          gap: 10px;
        }
        .db-page-info { font-size: 12px; color:#9a8a7a; }
        .db-page-btns { display:flex; align-items:center; gap: 8px; }
        .db-page-btn {
          display:inline-flex;
          align-items:center;
          gap: 6px;
          padding: 7px 12px;
          font-size: 12.5px;
          font-weight: 600;
          color: #7a6a5a;
          background: #f5f1eb;
          border: 1px solid #e5ddd3;
          border-radius: 10px;
          cursor: pointer;
          transition: background .2s, transform .2s, color .2s;
        }
        .db-page-btn:hover:not(:disabled) { background:#ede8e0; color:#1a1a2e; transform: translateY(-1px); }
        .db-page-btn:disabled { opacity: .45; cursor:not-allowed; }
        .db-page-current { font-size: 12px; color:#9a8a7a; }

        /* Modals */
        .db-modal-backdrop {
          position: fixed;
          inset: 0;
          background: rgba(0,0,0,0.55);
          backdrop-filter: blur(7px);
          z-index: 1400;
          display:flex;
          align-items:center;
          justify-content:center;
          padding: 12px;
        }
        .db-modal {
          width: min(860px, 96vw);
          max-height: 92vh;
          border-radius: 18px;
          overflow: hidden;
          background: #fff;
          box-shadow: 0 24px 70px rgba(0,0,0,0.35);
          border: 1px solid rgba(255,255,255,0.12);
        }
        .db-modal-head {
          padding: 18px 20px;
          background: linear-gradient(135deg, #0f172a 0%, #1f2937 100%);
          color: #fff;
          position: relative;
          overflow: hidden;
        }
        .db-modal-head::before {
          content:"";
          position:absolute;
          inset:0;
          background-image: radial-gradient(circle, rgba(255,255,255,0.045) 1px, transparent 1px);
          background-size: 24px 24px;
          pointer-events:none;
        }
        .db-modal-head-inner {
          position: relative;
          z-index: 1;
          display:flex;
          align-items:flex-start;
          justify-content: space-between;
          gap: 12px;
        }
        .db-modal-title {
          margin:0;
          font-family: "Lora", Georgia, serif;
          font-size: 16px;
          font-weight: 700;
        }
        .db-modal-sub {
          margin: 2px 0 0;
          color: rgba(255,255,255,0.72);
          font-size: 12.5px;
          font-weight: 300;
        }
        .db-modal-close {
          width: 36px;
          height: 36px;
          border-radius: 10px;
          border: 1px solid rgba(255,255,255,0.18);
          background: rgba(255,255,255,0.06);
          color: #fff;
          cursor: pointer;
          display:flex;
          align-items:center;
          justify-content:center;
          transition: background .2s, border-color .2s, transform .2s;
          flex-shrink: 0;
        }
        .db-modal-close:hover:not(:disabled) {
          background: rgba(255,255,255,0.10);
          border-color: rgba(255,255,255,0.26);
          transform: translateY(-1px);
        }
        .db-modal-close:disabled { opacity: .5; cursor:not-allowed; }

        .db-modal-body { background:#f5f1eb; padding: 16px; overflow:auto; max-height: calc(92vh - 130px); }
        .db-modal-card {
          background:#fff;
          border: 1px solid #ede8e0;
          border-radius: 16px;
          padding: 16px;
        }

        .db-form-grid { display:grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        @media (max-width: 767.98px) { .db-form-grid { grid-template-columns: 1fr; } }

        .db-field label {
          display:block;
          font-size: 12px;
          font-weight: 700;
          color: #7a6a5a;
          margin-bottom: 6px;
          letter-spacing: .02em;
        }
        .db-field input, .db-field select {
          width: 100%;
          padding: 10px 12px;
          border-radius: 12px;
          border: 1px solid #e5ddd3;
          background: #faf8f5;
          outline: none;
          font-size: 13.5px;
          color: #1a1a2e;
        }
        .db-field input:focus, .db-field select:focus {
          border-color: rgba(201,168,76,0.55);
          box-shadow: 0 0 0 4px rgba(201,168,76,0.18);
          background: #fff;
        }
        .db-help {
          margin-top: 6px;
          font-size: 11.5px;
          color: #9a8a7a;
        }

        .db-modal-foot {
          padding: 14px 16px;
          background: #fff;
          border-top: 1px solid rgba(0,0,0,0.06);
          display:flex;
          justify-content: flex-end;
          gap: 10px;
          flex-wrap: wrap;
        }

        .db-btn {
          display:inline-flex;
          align-items:center;
          gap: 7px;
          padding: 10px 14px;
          border-radius: 12px;
          font-size: 13px;
          font-weight: 700;
          cursor: pointer;
          border: 1px solid transparent;
          transition: transform .2s, box-shadow .2s, background .2s, border-color .2s;
          white-space: nowrap;
        }
        .db-btn:hover:not(:disabled) { transform: translateY(-1px); box-shadow: 0 10px 22px rgba(0,0,0,0.10); }
        .db-btn:disabled { opacity: .55; cursor:not-allowed; box-shadow: none; transform:none; }

        .db-btn-secondary {
          background: #f5f1eb;
          border-color: #e5ddd3;
          color: #7a6a5a;
        }
        .db-btn-secondary:hover:not(:disabled) { background: #ede8e0; color:#1a1a2e; }

        .db-btn-primary {
          background: #c9a84c;
          color: #0f172a;
          border-color: rgba(201,168,76,0.35);
        }
        .db-btn-primary:hover:not(:disabled) { background:#e8c97a; }

        @keyframes dbSpin { to { transform: rotate(360deg); } }
      `}),(0,u.jsx)(s,{sidebarOpen:n,setSidebarOpen:m}),(0,u.jsx)(r,{title:`Student Classes`}),(0,u.jsx)(`div`,{className:`container-fluid`,children:(0,u.jsxs)(`div`,{className:`row`,children:[(0,u.jsx)(o,{sidebarOpen:n}),(0,u.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto db-main`,children:[h&&(0,u.jsx)(i,{message:`Loading class levels...`}),(0,u.jsxs)(`div`,{className:`db-hero`,children:[(0,u.jsx)(`div`,{className:`db-hero-glow`,"aria-hidden":`true`}),(0,u.jsx)(`div`,{className:`db-hero-glow2`,"aria-hidden":`true`}),(0,u.jsxs)(`div`,{className:`db-hero-inner`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsxs)(`div`,{className:`db-session-badge`,children:[(0,u.jsx)(`span`,{className:`db-session-dot`}),`Academics • Classes / Levels`]}),(0,u.jsxs)(`h1`,{className:`db-greeting`,children:[f(),`, `,(0,u.jsx)(`em`,{children:`Admin.`})]}),(0,u.jsx)(`p`,{className:`db-hero-sub`,children:`Create and manage your classes (levels). You can optionally link a class to a section for better organization.`}),(0,u.jsxs)(`div`,{className:`db-hero-btns`,children:[(0,u.jsxs)(`button`,{className:`db-btn-gold`,onClick:()=>j(!0),disabled:O!==null,children:[(0,u.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:(0,u.jsx)(`path`,{d:`M8 3v10M3 8h10`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})}),`Add Class`]}),(0,u.jsxs)(`button`,{className:`db-btn-outline`,onClick:V,disabled:_||O!==null,children:[(0,u.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,style:{animation:_?`dbSpin 0.8s linear infinite`:`none`},children:[(0,u.jsx)(`path`,{d:`M12 7A5 5 0 112 7`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,u.jsx)(`path`,{d:`M12 3v4h-4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),_?`Refreshing...`:`Refresh`]})]})]}),(0,u.jsxs)(`div`,{className:`db-hero-stat-card d-none d-md-block`,children:[(0,u.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,marginBottom:16},children:[(0,u.jsx)(`span`,{style:{fontSize:11,fontWeight:600,letterSpacing:`0.14em`,textTransform:`uppercase`,color:`#c9a84c`},children:`Quick glance`}),(0,u.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:(0,u.jsx)(`path`,{d:`M2 10V6M5 10V4M8 10V7M11 10V3`,stroke:`#64748b`,strokeWidth:`1.5`,strokeLinecap:`round`})})]}),(0,u.jsxs)(`div`,{className:`db-hero-stat-row`,children:[(0,u.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,u.jsx)(`span`,{className:`db-hero-stat-label`,children:`Total classes`}),(0,u.jsx)(`span`,{className:`db-hero-stat-val`,children:G})]}),(0,u.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,u.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,u.jsx)(`span`,{className:`db-hero-stat-label`,children:`Linked to section`}),(0,u.jsx)(`span`,{className:`db-hero-stat-val`,children:K})]}),(0,u.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,u.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,u.jsx)(`span`,{className:`db-hero-stat-label`,children:`Sections`}),(0,u.jsx)(`span`,{className:`db-hero-stat-val`,children:y?`…`:S.length})]})]})]})]})]}),(0,u.jsx)(`div`,{className:`db-stats`,children:[{title:`Total Classes`,value:G,hint:`total configured`},{title:`Linked to Section`,value:K,hint:`organized by section`},{title:`No Section`,value:q,hint:`not linked yet`},{title:`Sections Loaded`,value:y?`…`:S.length,hint:`available sections`}].map((e,t)=>{let n=oe[t],r=[(0,u.jsxs)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 20 20`,fill:`none`,children:[(0,u.jsx)(`path`,{d:`M4 6l6-3 6 3-6 3-6-3z`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinejoin:`round`}),(0,u.jsx)(`path`,{d:`M4 10l6 3 6-3`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinejoin:`round`}),(0,u.jsx)(`path`,{d:`M4 14l6 3 6-3`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinejoin:`round`})]},`i1`),(0,u.jsxs)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 20 20`,fill:`none`,children:[(0,u.jsx)(`path`,{d:`M7 10h6`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`}),(0,u.jsx)(`path`,{d:`M6.5 7.5l7 5`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,u.jsx)(`path`,{d:`M6.5 12.5l7-5`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,u.jsx)(`circle`,{cx:`6`,cy:`10`,r:`2.3`,stroke:`currentColor`,strokeWidth:`1.4`}),(0,u.jsx)(`circle`,{cx:`14`,cy:`10`,r:`2.3`,stroke:`currentColor`,strokeWidth:`1.4`})]},`i2`),(0,u.jsxs)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 20 20`,fill:`none`,children:[(0,u.jsx)(`circle`,{cx:`10`,cy:`10`,r:`7`,stroke:`currentColor`,strokeWidth:`1.5`}),(0,u.jsx)(`path`,{d:`M7.5 7.5l5 5`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})]},`i3`),(0,u.jsxs)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 20 20`,fill:`none`,children:[(0,u.jsx)(`path`,{d:`M7 6a3 3 0 016 0v2`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`}),(0,u.jsx)(`rect`,{x:`5`,y:`8`,width:`10`,height:`8`,rx:`2`,stroke:`currentColor`,strokeWidth:`1.5`}),(0,u.jsx)(`path`,{d:`M10 12v2`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`})]},`i4`)];return(0,u.jsxs)(`div`,{className:`db-stat`,style:{"--sc":n.color,"--si":n.bg},children:[(0,u.jsxs)(`div`,{className:`db-stat-head`,children:[(0,u.jsx)(`div`,{className:`db-stat-icon`,children:r[t]}),(0,u.jsxs)(`svg`,{className:`db-stat-more`,width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,u.jsx)(`circle`,{cx:`4`,cy:`8`,r:`1.2`,fill:`currentColor`}),(0,u.jsx)(`circle`,{cx:`8`,cy:`8`,r:`1.2`,fill:`currentColor`}),(0,u.jsx)(`circle`,{cx:`12`,cy:`8`,r:`1.2`,fill:`currentColor`})]})]}),(0,u.jsx)(`p`,{className:`db-stat-label`,children:e.title}),(0,u.jsx)(`div`,{className:`db-stat-val`,children:e.value}),(0,u.jsxs)(`div`,{className:`db-stat-footer`,children:[(0,u.jsx)(`svg`,{width:`12`,height:`12`,viewBox:`0 0 12 12`,fill:`none`,children:(0,u.jsx)(`path`,{d:`M2 9l3-4 2 2 3-5`,stroke:`#22c55e`,strokeWidth:`1.4`,strokeLinecap:`round`,strokeLinejoin:`round`})}),(0,u.jsx)(`span`,{className:`db-stat-trend`,children:`OK`}),(0,u.jsx)(`span`,{children:n.label}),(0,u.jsx)(`span`,{style:{marginLeft:`auto`,color:`#9a8a7a`},children:e.hint})]})]},e.title)})}),(0,u.jsxs)(`div`,{className:`db-panel`,children:[(0,u.jsxs)(`div`,{className:`db-panel-head`,children:[(0,u.jsxs)(`div`,{className:`db-panel-title-group`,children:[(0,u.jsx)(`div`,{className:`db-panel-icon`,style:{"--pi":`#fef3c7`,"--pc":`#b45309`},children:(0,u.jsx)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:(0,u.jsx)(`path`,{d:`M3 4.5h10M3 8h10M3 11.5h10`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`})})}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`p`,{className:`db-panel-title`,children:`Classes / Levels`}),(0,u.jsx)(`p`,{className:`db-panel-sub`,children:`Create, edit and search class levels`})]})]}),(0,u.jsxs)(`div`,{className:`db-toolbar`,children:[(0,u.jsxs)(`div`,{className:`db-input`,title:`Search`,children:[(0,u.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,style:{flexShrink:0},children:[(0,u.jsx)(`circle`,{cx:`7`,cy:`7`,r:`4.5`,stroke:`#9a8a7a`,strokeWidth:`1.4`}),(0,u.jsx)(`path`,{d:`M11 11l3 3`,stroke:`#9a8a7a`,strokeWidth:`1.4`,strokeLinecap:`round`})]}),(0,u.jsx)(`input`,{placeholder:`Search classes…`,value:w,onChange:e=>T(e.target.value)}),w.trim()?(0,u.jsx)(`button`,{className:`db-chip-btn`,style:{padding:`6px 10px`,borderRadius:10},onClick:()=>T(``),type:`button`,children:`Clear`}):null]}),(0,u.jsxs)(`button`,{className:`db-chip-btn`,onClick:V,disabled:_||O!==null,type:`button`,children:[(0,u.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,children:[(0,u.jsx)(`path`,{d:`M12 7A5 5 0 112 7`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,u.jsx)(`path`,{d:`M12 3v4h-4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),`Refresh`]}),(0,u.jsx)(`button`,{className:`db-chip-btn`,onClick:()=>D(e=>!e),disabled:O!==null,type:`button`,children:E?`Show Active`:`View Archived`}),E?null:(0,u.jsxs)(`button`,{className:`db-chip-btn`,onClick:()=>j(!0),disabled:O!==null,type:`button`,children:[(0,u.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:(0,u.jsx)(`path`,{d:`M8 3v10M3 8h10`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})}),`Add Class`]})]})]}),(0,u.jsx)(`div`,{style:{overflowX:`auto`},children:(0,u.jsxs)(`table`,{className:`db-table`,children:[(0,u.jsx)(`thead`,{children:(0,u.jsxs)(`tr`,{children:[(0,u.jsx)(`th`,{style:{width:70},children:`#`}),(0,u.jsx)(`th`,{children:`Class`}),(0,u.jsx)(`th`,{children:`Description`}),(0,u.jsx)(`th`,{style:{width:220},children:`Section`}),(0,u.jsx)(`th`,{style:{width:220,textAlign:`right`},children:`Actions`})]})}),(0,u.jsx)(`tbody`,{children:_?(0,u.jsx)(`tr`,{children:(0,u.jsxs)(`td`,{colSpan:5,style:{padding:28,textAlign:`center`,color:`#9a8a7a`},children:[(0,u.jsx)(`span`,{className:`spinner-border spinner-border-sm`}),` `,(0,u.jsx)(`span`,{style:{marginLeft:8},children:`Loading classes…`})]})}):Q.length===0?(0,u.jsx)(`tr`,{children:(0,u.jsxs)(`td`,{colSpan:5,style:{padding:34,textAlign:`center`,color:`#9a8a7a`},children:[(0,u.jsx)(`div`,{style:{fontWeight:800,color:`#1a1a2e`},children:`No classes found`}),(0,u.jsx)(`div`,{style:{marginTop:6},children:`Try a different keyword or add a class.`})]})}):Q.map((e,t)=>{let n=B(`level:update:${e.id}`),r=B(`level:archive:${e.id}`),i=B(`level:restore:${e.id}`);return(0,u.jsxs)(`tr`,{children:[(0,u.jsx)(`td`,{style:{color:`#9a8a7a`},children:(Z-1)*10+t+1}),(0,u.jsxs)(`td`,{children:[(0,u.jsx)(`div`,{style:{fontWeight:700,color:`#1a1a2e`},children:e.name}),(0,u.jsxs)(`div`,{style:{fontSize:12,color:`#9a8a7a`},children:[`ID: `,e.id]})]}),(0,u.jsx)(`td`,{style:{color:`#4a4a5a`},children:e.description||`—`}),(0,u.jsx)(`td`,{children:(0,u.jsxs)(`span`,{className:`db-pill`,children:[(0,u.jsx)(`svg`,{width:`12`,height:`12`,viewBox:`0 0 12 12`,fill:`none`,children:(0,u.jsx)(`path`,{d:`M3 6h6`,stroke:`#7a6a5a`,strokeWidth:`1.4`,strokeLinecap:`round`})}),U(e)]})}),(0,u.jsx)(`td`,{style:{textAlign:`right`},children:(0,u.jsxs)(`div`,{className:`db-actions`,children:[(0,u.jsxs)(`button`,{className:`db-action-btn db-action-primary`,onClick:()=>$(e),disabled:E||O!==null,type:`button`,children:[(0,u.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,u.jsx)(`path`,{d:`M3 11.5V13h1.5L12.8 4.7 11.3 3.2 3 11.5z`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinejoin:`round`}),(0,u.jsx)(`path`,{d:`M10.6 3.9l1.5 1.5`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`})]}),`Edit`]}),(0,u.jsx)(`button`,{className:`db-action-btn ${E?`db-action-green`:`db-action-danger`}`,onClick:()=>E?ae(e):ie(e),disabled:O!==null,type:`button`,children:E?i?`Restoring...`:`Restore`:r?`Archiving...`:`Archive`}),n&&(0,u.jsxs)(`span`,{className:`db-pill`,style:{background:`rgba(148,163,184,0.18)`,color:`#475569`},children:[(0,u.jsxs)(`svg`,{width:`12`,height:`12`,viewBox:`0 0 14 14`,fill:`none`,style:{animation:`dbSpin .9s linear infinite`},children:[(0,u.jsx)(`path`,{d:`M12 7A5 5 0 112 7`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,u.jsx)(`path`,{d:`M12 3v4h-4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),`Saving…`]})]})})]},e.id)})})]})}),(0,u.jsxs)(`div`,{className:`db-pagination`,children:[(0,u.jsxs)(`div`,{className:`db-page-info`,children:[`Showing `,(0,u.jsx)(`b`,{children:Q.length}),` of `,(0,u.jsx)(`b`,{children:W.length}),` results • Page`,` `,(0,u.jsx)(`b`,{children:Z}),` of `,(0,u.jsx)(`b`,{children:X})]}),(0,u.jsxs)(`div`,{className:`db-page-btns`,children:[(0,u.jsxs)(`button`,{className:`db-page-btn`,onClick:()=>Y(e=>Math.max(1,e-1)),disabled:Z<=1,type:`button`,children:[(0,u.jsx)(`svg`,{width:`12`,height:`12`,viewBox:`0 0 12 12`,fill:`none`,children:(0,u.jsx)(`path`,{d:`M8 2L4 6l4 4`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`,strokeLinejoin:`round`})}),`Prev`]}),(0,u.jsxs)(`span`,{className:`db-page-current`,children:[`Page `,Z]}),(0,u.jsxs)(`button`,{className:`db-page-btn`,onClick:()=>Y(e=>Math.min(X,e+1)),disabled:Z>=X,type:`button`,children:[`Next`,(0,u.jsx)(`svg`,{width:`12`,height:`12`,viewBox:`0 0 12 12`,fill:`none`,children:(0,u.jsx)(`path`,{d:`M4 2l4 4-4 4`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`,strokeLinejoin:`round`})})]})]})]})]}),(0,u.jsx)(c,{}),A&&(0,u.jsx)(`div`,{className:`db-modal-backdrop`,onMouseDown:()=>{O||j(!1)},children:(0,u.jsxs)(`div`,{className:`db-modal`,onMouseDown:e=>e.stopPropagation(),children:[(0,u.jsx)(`div`,{className:`db-modal-head`,children:(0,u.jsxs)(`div`,{className:`db-modal-head-inner`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`h3`,{className:`db-modal-title`,children:`Add Class`}),(0,u.jsx)(`p`,{className:`db-modal-sub`,children:`Create a new class level for your school (optional: link to a section).`})]}),(0,u.jsx)(`button`,{className:`db-modal-close`,onClick:()=>j(!1),disabled:O!==null,type:`button`,"aria-label":`Close`,children:(0,u.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,children:(0,u.jsx)(`path`,{d:`M3 3l8 8M11 3L3 11`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})})})]})}),(0,u.jsx)(`div`,{className:`db-modal-body`,children:(0,u.jsx)(`div`,{className:`db-modal-card`,children:(0,u.jsxs)(`div`,{className:`db-form-grid`,children:[(0,u.jsxs)(`div`,{className:`db-field`,children:[(0,u.jsxs)(`label`,{children:[`Class Name `,(0,u.jsx)(`span`,{style:{color:`#ef4444`},children:`*`})]}),(0,u.jsx)(`input`,{placeholder:`e.g. JSS1`,value:P.name,onChange:e=>F({...P,name:e.target.value})}),(0,u.jsx)(`div`,{className:`db-help`,children:`Max 50 chars. Stored as you type (backend may enforce uppercase).`})]}),(0,u.jsxs)(`div`,{className:`db-field`,children:[(0,u.jsx)(`label`,{children:`Section (optional)`}),(0,u.jsxs)(`select`,{value:P.section_id,onChange:e=>F({...P,section_id:e.target.value}),disabled:y,children:[(0,u.jsx)(`option`,{value:``,children:`— Not Linked —`}),S.map(e=>(0,u.jsx)(`option`,{value:e.id,children:e.name},e.id))]}),(0,u.jsx)(`div`,{className:`db-help`,children:y?`Loading sections…`:`Linking helps grouping and reporting.`})]}),(0,u.jsxs)(`div`,{className:`db-field`,style:{gridColumn:`1 / -1`},children:[(0,u.jsx)(`label`,{children:`Description (optional)`}),(0,u.jsx)(`input`,{placeholder:`e.g. Junior Secondary School 1`,value:P.description,onChange:e=>F({...P,description:e.target.value})})]})]})})}),(0,u.jsxs)(`div`,{className:`db-modal-foot`,children:[(0,u.jsx)(`button`,{className:`db-btn db-btn-secondary`,onClick:()=>j(!1),disabled:O!==null,type:`button`,children:`Cancel`}),(0,u.jsx)(`button`,{className:`db-btn db-btn-primary`,onClick:ne,disabled:O!==null,type:`button`,children:B(`level:create`)?(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`span`,{className:`spinner-border spinner-border-sm`,role:`status`,style:{width:14,height:14}}),`Saving…`]}):(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:(0,u.jsx)(`path`,{d:`M3 8l3 3 7-7`,stroke:`currentColor`,strokeWidth:`1.7`,strokeLinecap:`round`,strokeLinejoin:`round`})}),`Save Class`]})})]})]})}),M&&I&&(0,u.jsx)(`div`,{className:`db-modal-backdrop`,onMouseDown:()=>{O||N(!1)},children:(0,u.jsxs)(`div`,{className:`db-modal`,onMouseDown:e=>e.stopPropagation(),children:[(0,u.jsx)(`div`,{className:`db-modal-head`,children:(0,u.jsxs)(`div`,{className:`db-modal-head-inner`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`h3`,{className:`db-modal-title`,children:`Edit Class`}),(0,u.jsx)(`p`,{className:`db-modal-sub`,children:`Update class name, description, or linked section.`})]}),(0,u.jsx)(`button`,{className:`db-modal-close`,onClick:()=>N(!1),disabled:O!==null,type:`button`,"aria-label":`Close`,children:(0,u.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,children:(0,u.jsx)(`path`,{d:`M3 3l8 8M11 3L3 11`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})})})]})}),(0,u.jsx)(`div`,{className:`db-modal-body`,children:(0,u.jsx)(`div`,{className:`db-modal-card`,children:(0,u.jsxs)(`div`,{className:`db-form-grid`,children:[(0,u.jsxs)(`div`,{className:`db-field`,children:[(0,u.jsxs)(`label`,{children:[`Class Name `,(0,u.jsx)(`span`,{style:{color:`#ef4444`},children:`*`})]}),(0,u.jsx)(`input`,{placeholder:`e.g. SS2`,value:R.name,onChange:e=>z({...R,name:e.target.value})}),(0,u.jsx)(`div`,{className:`db-help`,children:`Note: your backend update currently validates max 5 chars (as per your comment).`})]}),(0,u.jsxs)(`div`,{className:`db-field`,children:[(0,u.jsx)(`label`,{children:`Section (optional)`}),(0,u.jsxs)(`select`,{value:R.section_id,onChange:e=>z({...R,section_id:e.target.value}),disabled:y,children:[(0,u.jsx)(`option`,{value:``,children:`— Not Linked —`}),S.map(e=>(0,u.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]}),(0,u.jsxs)(`div`,{className:`db-field`,style:{gridColumn:`1 / -1`},children:[(0,u.jsx)(`label`,{children:`Description (optional)`}),(0,u.jsx)(`input`,{placeholder:`Optional description`,value:R.description,onChange:e=>z({...R,description:e.target.value})})]})]})})}),(0,u.jsxs)(`div`,{className:`db-modal-foot`,children:[(0,u.jsx)(`button`,{className:`db-btn db-btn-secondary`,onClick:()=>N(!1),disabled:O!==null,type:`button`,children:`Cancel`}),(0,u.jsx)(`button`,{className:`db-btn db-btn-primary`,onClick:re,disabled:O!==null,type:`button`,children:B(`level:update:${I}`)?(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`span`,{className:`spinner-border spinner-border-sm`,role:`status`,style:{width:14,height:14}}),`Saving…`]}):(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:(0,u.jsx)(`path`,{d:`M3 8l3 3 7-7`,stroke:`currentColor`,strokeWidth:`1.7`,strokeLinecap:`round`,strokeLinejoin:`round`})}),`Update Class`]})})]})]})})]})]})})]})}export{m as default};