import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{p as t}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as n,E as r,P as i,d as a,f as o,l as s,u as c}from"./index-D6TxbaCx.js";var l=e(),u=t(),d=(e,t,n,r)=>{let i=parseInt(String(e),10);return isNaN(i)?r:Math.max(t,Math.min(n,i))};function f(){let{showSuccess:e,showError:t}=s(),[f,p]=(0,l.useState)(!1),[m,h]=(0,l.useState)(!0),[g,_]=(0,l.useState)(!1),[v,y]=(0,l.useState)({enabled:!0,result_access_enabled:!0,result_min_payment_percent:100,result_scope:`selected_period`,cbt_access_enabled:!1,cbt_min_payment_percent:100,cbt_scope:`selected_period`,installment_enabled:!0,installment_type:`two_installments_70_30`,min_initial_installment_percent:70,full_payment_discount_enabled:!1,full_payment_discount_type:`percentage`,full_payment_discount_value:0,full_payment_discount_message:`🎉 Pay your full fee upfront and enjoy an instant :discount discount!`,message:`Result access is currently unavailable because the required school fee payment has not been completed.`,cbt_message:`Access denied. Complete the required school fee payment before starting this exam.`,installment_message:`This school requires a minimum initial payment of :percent% (:amount) for the term.`,bank_charge_bearer:`parent`,bank_charge_amount:200,platform_fee_bearer:`school`,active_payment_gateway:`wema_alat`}),b=async()=>{h(!0);try{let e=await i.get(`/settings/fee-access-policy`);if(e.data?.policy){let t=e.data.policy;y({enabled:t.enabled!==!1,result_access_enabled:t.result_access_enabled!==!1,result_min_payment_percent:d(t.result_min_payment_percent,0,100,100),result_scope:t.result_scope===`all_outstanding`?`all_outstanding`:`selected_period`,cbt_access_enabled:!!t.cbt_access_enabled,cbt_min_payment_percent:d(t.cbt_min_payment_percent,0,100,100),cbt_scope:t.cbt_scope===`all_outstanding`?`all_outstanding`:`selected_period`,installment_enabled:!!t.installment_enabled,installment_type:t.installment_type||`two_installments_70_30`,min_initial_installment_percent:d(t.min_initial_installment_percent,1,100,70),full_payment_discount_enabled:!!t.full_payment_discount_enabled,full_payment_discount_type:t.full_payment_discount_type===`fixed`?`fixed`:`percentage`,full_payment_discount_value:Number(t.full_payment_discount_value||0),full_payment_discount_message:t.full_payment_discount_message||`🎉 Pay your full fee upfront and enjoy an instant :discount discount!`,message:t.message||`Result access is currently unavailable because the required school fee payment has not been completed.`,cbt_message:t.cbt_message||`Access denied. Complete the required school fee payment before starting this exam.`,installment_message:t.installment_message||`This school requires a minimum initial payment of :percent% (:amount) for the term.`,bank_charge_bearer:t.bank_charge_bearer===`school`?`school`:`parent`,bank_charge_amount:Number(t.bank_charge_amount||200),platform_fee_bearer:t.platform_fee_bearer===`parent`?`parent`:`school`,active_edition_tier:t.active_edition_tier||`standard_cbt`,basic_tier_price:Number(t.basic_tier_price||300),standard_cbt_tier_price:Number(t.standard_cbt_tier_price||500),annual_full_session_price:Number(t.annual_full_session_price||1500),platform_fee_amount:Number(t.platform_fee_amount||500),active_payment_gateway:t.active_payment_gateway||`wema_alat`})}}catch(e){console.error(e),t(`Failed to load fee policy settings.`)}finally{h(!1)}};(0,l.useEffect)(()=>{b()},[]);let x=async()=>{_(!0);try{let t=await i.put(`/settings/fee-access-policy`,v);if(t.data?.policy){let e=t.data.policy;y({enabled:e.enabled!==!1,result_access_enabled:e.result_access_enabled!==!1,result_min_payment_percent:d(e.result_min_payment_percent,0,100,100),result_scope:e.result_scope===`all_outstanding`?`all_outstanding`:`selected_period`,cbt_access_enabled:!!e.cbt_access_enabled,cbt_min_payment_percent:d(e.cbt_min_payment_percent,0,100,100),cbt_scope:e.cbt_scope===`all_outstanding`?`all_outstanding`:`selected_period`,installment_enabled:!!e.installment_enabled,installment_type:e.installment_type||`two_installments_70_30`,min_initial_installment_percent:d(e.min_initial_installment_percent,1,100,70),full_payment_discount_enabled:!!e.full_payment_discount_enabled,full_payment_discount_type:e.full_payment_discount_type===`fixed`?`fixed`:`percentage`,full_payment_discount_value:Number(e.full_payment_discount_value||0),full_payment_discount_message:e.full_payment_discount_message||`🎉 Pay your full fee upfront and enjoy an instant :discount discount!`,message:e.message||`Result access is currently unavailable because the required school fee payment has not been completed.`,cbt_message:e.cbt_message||`Access denied. Complete the required school fee payment before starting this exam.`,installment_message:e.installment_message||`This school requires a minimum initial payment of :percent% (:amount) for the term.`,bank_charge_bearer:e.bank_charge_bearer===`school`?`school`:`parent`,bank_charge_amount:Number(e.bank_charge_amount||200),platform_fee_bearer:e.platform_fee_bearer===`parent`?`parent`:`school`,active_edition_tier:e.active_edition_tier||`standard_cbt`,basic_tier_price:Number(e.basic_tier_price||300),standard_cbt_tier_price:Number(e.standard_cbt_tier_price||500),annual_full_session_price:Number(e.annual_full_session_price||1500),platform_fee_amount:Number(e.platform_fee_amount||500),active_payment_gateway:e.active_payment_gateway||`wema_alat`})}e(t.data?.message||`Fee and installment policy saved successfully.`)}catch(e){console.error(e),t(e?.response?.data?.message||`Could not save fee policy. Please try again.`)}finally{_(!1)}},S=e=>{let t=v.min_initial_installment_percent;e===`two_installments_70_30`?t=70:e===`two_installments_50_50`?t=50:e===`three_installments_40_30_30`?t=40:e===`full_only`&&(t=100),y(n=>({...n,installment_type:e,min_initial_installment_percent:t}))},C=3e4,w=Math.round(v.min_initial_installment_percent/100*C),T=C-w;return(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(n,{title:`Fee Policy & Installments | SchoolProfit`}),(0,u.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800;900&display=swap');
        
        .fp-main {
          min-height: 100vh;
          background: #F8FAFC;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          padding: calc(var(--gq-topnav-height, 66px) + 20px) 24px 60px;
          overflow-x: hidden;
          box-sizing: border-box;
          color: #0F172A;
        }
        @media(max-width: 767.98px) {
          .fp-main { padding: calc(var(--gq-topnav-height, 66px) + 12px) 12px 36px; }
        }

        .fp-shell {
          max-width: 1100px;
          margin: 0 auto;
          width: 100%;
        }

        /* ── Hero ── */
        .fp-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 55%, #1E3A8A 100%);
          border-radius: 20px;
          padding: 32px 36px;
          position: relative;
          overflow: hidden;
          margin-bottom: 28px;
          box-shadow: 0 12px 32px -6px rgba(15, 39, 68, 0.2);
          color: #FFFFFF;
        }
        @media(max-width: 767.98px) {
          .fp-hero { padding: 22px 18px; border-radius: 14px; }
        }

        .fp-hero-glow {
          position: absolute;
          top: -80px;
          right: -80px;
          width: 340px;
          height: 340px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.2) 0%, transparent 65%);
          pointer-events: none;
        }

        .fp-hero-inner {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 24px;
          flex-wrap: wrap;
        }

        .fp-badge {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.20);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius: 100px;
          padding: 4px 14px;
          margin-bottom: 10px;
        }

        .fp-title {
          font-size: 26px;
          font-weight: 850;
          margin: 0 0 6px;
          letter-spacing: -0.02em;
        }
        @media(max-width: 767.98px) {
          .fp-title { font-size: 22px; }
        }

        .fp-sub {
          font-size: 14px;
          color: #94A3B8;
          max-width: 600px;
          margin: 0;
          line-height: 1.5;
        }

        .fp-btn-save {
          background: linear-gradient(135deg, #F59E0B 0%, #D97706 100%);
          color: #0A192F;
          border: none;
          padding: 12px 24px;
          border-radius: 12px;
          font-size: 14px;
          font-weight: 800;
          cursor: pointer;
          display: inline-flex;
          align-items: center;
          gap: 8px;
          box-shadow: 0 4px 14px rgba(217, 119, 6, 0.35);
          transition: transform 0.15s ease, box-shadow 0.15s ease;
        }

        .fp-btn-save:hover:not(:disabled) {
          transform: translateY(-1px);
          box-shadow: 0 6px 20px rgba(217, 119, 6, 0.45);
        }

        .fp-btn-save:disabled {
          opacity: 0.6;
          cursor: not-allowed;
        }

        /* ── Cards ── */
        .fp-card {
          background: #FFFFFF;
          border-radius: 18px;
          border: 1px solid #E2E8F0;
          box-shadow: 0 4px 16px -2px rgba(15, 23, 42, 0.05);
          padding: 28px;
          margin-bottom: 24px;
        }
        @media(max-width: 767.98px) {
          .fp-card { padding: 18px 16px; border-radius: 14px; }
        }

        .fp-card-header {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: 16px;
          padding-bottom: 20px;
          border-bottom: 1px solid #F1F5F9;
          margin-bottom: 24px;
        }

        .fp-card-ico {
          width: 44px;
          height: 44px;
          border-radius: 12px;
          background: #EEF2FF;
          color: #1D4ED8;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 20px;
          flex-shrink: 0;
        }

        .fp-card-title {
          font-size: 18px;
          font-weight: 800;
          color: #0F172A;
          margin: 0 0 4px;
        }

        .fp-card-desc {
          font-size: 13px;
          color: #64748B;
          margin: 0;
        }

        /* ── Schedule Presets Grid ── */
        .fp-presets-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 14px;
          margin-top: 14px;
        }

        .fp-preset-card {
          border: 2px solid #E2E8F0;
          border-radius: 14px;
          padding: 16px;
          cursor: pointer;
          transition: all 0.2s ease;
          background: #FFFFFF;
          position: relative;
        }

        .fp-preset-card:hover {
          border-color: #93C5FD;
          background: #F8FAFC;
        }

        .fp-preset-card.active {
          border-color: #1D4ED8;
          background: #EFF6FF;
          box-shadow: 0 4px 12px rgba(29, 78, 216, 0.12);
        }

        .fp-preset-title {
          font-size: 14.5px;
          font-weight: 800;
          color: #0F172A;
          margin-bottom: 4px;
        }

        .fp-preset-desc {
          font-size: 12px;
          color: #64748B;
        }

        .fp-preset-pill {
          display: inline-block;
          font-size: 10.5px;
          font-weight: 800;
          padding: 2px 8px;
          border-radius: 6px;
          background: #DBEAFE;
          color: #1E40AF;
          margin-bottom: 8px;
        }

        /* ── Live Simulation Box ── */
        .fp-sim-box {
          background: linear-gradient(135deg, #F0FDF4 0%, #DCFCE7 100%);
          border: 1px solid #BBF7D0;
          border-radius: 14px;
          padding: 18px 22px;
          margin-top: 20px;
        }

        .fp-sim-head {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 12.5px;
          font-weight: 800;
          color: #166534;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          margin-bottom: 10px;
        }

        .fp-sim-steps {
          display: flex;
          gap: 16px;
          flex-wrap: wrap;
        }

        .fp-sim-step {
          background: #FFFFFF;
          border: 1px solid #86EFAC;
          border-radius: 10px;
          padding: 10px 16px;
          flex: 1;
          min-width: 140px;
        }

        .fp-sim-step-title {
          font-size: 11px;
          font-weight: 700;
          color: #64748B;
          text-transform: uppercase;
        }

        .fp-sim-step-val {
          font-size: 17px;
          font-weight: 900;
          color: #047857;
          margin-top: 2px;
        }

        /* ── Forms ── */
        .fp-form-label {
          font-size: 13px;
          font-weight: 700;
          color: #1E293B;
          margin-bottom: 6px;
          display: block;
        }

        .fp-input, .fp-select, .fp-textarea {
          width: 100%;
          border: 1.5px solid #CBD5E1;
          border-radius: 10px;
          padding: 10px 14px;
          font-size: 14px;
          font-weight: 600;
          color: #0F172A;
          background: #FFFFFF;
          outline: none;
          transition: border-color 0.15s, box-shadow 0.15s;
        }

        .fp-input:focus, .fp-select:focus, .fp-textarea:focus {
          border-color: #1D4ED8;
          box-shadow: 0 0 0 3px rgba(29, 78, 216, 0.12);
        }

        .fp-help {
          font-size: 12px;
          color: #64748B;
          margin-top: 5px;
        }
      `}),(0,u.jsx)(o,{sidebarOpen:f,setSidebarOpen:p,title:`Fee Policy & Installments`}),(0,u.jsx)(`div`,{className:`container-fluid`,children:(0,u.jsxs)(`div`,{className:`row`,children:[(0,u.jsx)(a,{sidebarOpen:f,setSidebarOpen:p}),(0,u.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto db-main fp-main`,children:[m&&(0,u.jsx)(r,{message:`Loading Fee Policy...`}),(0,u.jsxs)(`div`,{className:`fp-shell`,children:[(0,u.jsxs)(`div`,{className:`fp-hero`,children:[(0,u.jsx)(`div`,{className:`fp-hero-glow`}),(0,u.jsxs)(`div`,{className:`fp-hero-inner`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsxs)(`div`,{className:`fp-badge`,children:[(0,u.jsx)(`i`,{className:`bi bi-shield-check`}),` Bursar & Financial Management`]}),(0,u.jsx)(`h1`,{className:`fp-title`,children:`Fee Policy & Installments`}),(0,u.jsx)(`p`,{className:`fp-sub`,children:`Control how students pay their fees. Set installment requirements (e.g. 70% 1st payment / 30% 2nd payment) to prevent debt, and enforce exam & result gates.`})]}),(0,u.jsx)(`button`,{className:`fp-btn-save`,onClick:x,disabled:g||m,children:g?(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`span`,{className:`spinner-border spinner-border-sm`}),` Saving...`]}):(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`i`,{className:`bi bi-check2-circle`,style:{fontSize:18}}),` Save Policy Settings`]})})]})]}),!m&&(0,u.jsxs)(u.Fragment,{children:[(0,u.jsxs)(`div`,{className:`fp-card`,children:[(0,u.jsxs)(`div`,{className:`fp-card-header`,children:[(0,u.jsxs)(`div`,{style:{display:`flex`,gap:14},children:[(0,u.jsx)(`div`,{className:`fp-card-ico`,style:{background:`#FEF3C7`,color:`#D97706`},children:(0,u.jsx)(`i`,{className:`bi bi-pie-chart-fill`})}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`h2`,{className:`fp-card-title`,children:`Installment Payment Schedule (Debt Control)`}),(0,u.jsx)(`p`,{className:`fp-card-desc`,children:`Enforce structured partial payments so parents cannot pay less than your approved threshold per term.`})]})]}),(0,u.jsx)(`div`,{className:`form-check form-switch m-0`,children:(0,u.jsx)(`input`,{className:`form-check-input`,type:`checkbox`,role:`switch`,style:{width:44,height:22,cursor:`pointer`},checked:v.installment_enabled,onChange:e=>y(t=>({...t,installment_enabled:e.target.checked}))})})]}),v.installment_enabled?(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`label`,{className:`fp-form-label`,children:`Select Approved Payment Schedule for Terms`}),(0,u.jsxs)(`div`,{className:`fp-presets-grid`,children:[(0,u.jsxs)(`div`,{className:`fp-preset-card ${v.installment_type===`two_installments_70_30`?`active`:``}`,onClick:()=>S(`two_installments_70_30`),children:[(0,u.jsx)(`span`,{className:`fp-preset-pill`,children:`Recommended`}),(0,u.jsx)(`div`,{className:`fp-preset-title`,children:`70% / 30% Split`}),(0,u.jsx)(`div`,{className:`fp-preset-desc`,children:`70% initial installment, 30% balance before exam.`})]}),(0,u.jsxs)(`div`,{className:`fp-preset-card ${v.installment_type===`two_installments_50_50`?`active`:``}`,onClick:()=>S(`two_installments_50_50`),children:[(0,u.jsx)(`span`,{className:`fp-preset-pill`,style:{background:`#E0E7FF`,color:`#3730A3`},children:`2 Equal Halves`}),(0,u.jsx)(`div`,{className:`fp-preset-title`,children:`50% / 50% Split`}),(0,u.jsx)(`div`,{className:`fp-preset-desc`,children:`Pay half at resumption, remaining half at mid-term.`})]}),(0,u.jsxs)(`div`,{className:`fp-preset-card ${v.installment_type===`three_installments_40_30_30`?`active`:``}`,onClick:()=>S(`three_installments_40_30_30`),children:[(0,u.jsx)(`span`,{className:`fp-preset-pill`,style:{background:`#F3E8FF`,color:`#6B21A8`},children:`3 Installments`}),(0,u.jsx)(`div`,{className:`fp-preset-title`,children:`40% / 30% / 30%`}),(0,u.jsx)(`div`,{className:`fp-preset-desc`,children:`Flexible three-part payment structure.`})]}),(0,u.jsxs)(`div`,{className:`fp-preset-card ${v.installment_type===`full_only`?`active`:``}`,onClick:()=>S(`full_only`),children:[(0,u.jsx)(`span`,{className:`fp-preset-pill`,style:{background:`#FEE2E2`,color:`#991B1B`},children:`Strict 100%`}),(0,u.jsx)(`div`,{className:`fp-preset-title`,children:`Full Payment Only`}),(0,u.jsx)(`div`,{className:`fp-preset-desc`,children:`No partial payments allowed. 100% required upfront.`})]}),(0,u.jsxs)(`div`,{className:`fp-preset-card ${v.installment_type===`custom`?`active`:``}`,onClick:()=>S(`custom`),children:[(0,u.jsx)(`span`,{className:`fp-preset-pill`,style:{background:`#FEF9C3`,color:`#854D0E`},children:`Custom`}),(0,u.jsx)(`div`,{className:`fp-preset-title`,children:`Custom Percentage`}),(0,u.jsx)(`div`,{className:`fp-preset-desc`,children:`Define your own custom initial payment minimum %.`})]})]}),v.installment_type===`custom`&&(0,u.jsxs)(`div`,{style:{marginTop:18,maxWidth:300},children:[(0,u.jsx)(`label`,{className:`fp-form-label`,children:`Custom Minimum Initial Payment (%)`}),(0,u.jsxs)(`div`,{className:`input-group`,children:[(0,u.jsx)(`input`,{type:`number`,className:`form-control`,min:1,max:100,value:v.min_initial_installment_percent,onChange:e=>y(t=>({...t,min_initial_installment_percent:d(e.target.value,1,100,70)}))}),(0,u.jsx)(`span`,{className:`input-group-text`,children:`%`})]}),(0,u.jsx)(`div`,{className:`fp-help`,children:`Enter the minimum percentage parents must pay on 1st installment.`})]}),(0,u.jsxs)(`div`,{className:`fp-sim-box`,children:[(0,u.jsxs)(`div`,{className:`fp-sim-head`,children:[(0,u.jsx)(`i`,{className:`bi bi-lightning-charge-fill`}),` Live Calculation Preview (Example on ₦30,000 School Fee)`]}),(0,u.jsxs)(`div`,{className:`fp-sim-steps`,children:[(0,u.jsxs)(`div`,{className:`fp-sim-step`,children:[(0,u.jsx)(`div`,{className:`fp-sim-step-title`,children:`Total Term Tuition`}),(0,u.jsx)(`div`,{className:`fp-sim-step-val`,style:{color:`#0F172A`},children:`₦30,000`})]}),(0,u.jsxs)(`div`,{className:`fp-sim-step`,children:[(0,u.jsxs)(`div`,{className:`fp-sim-step-title`,children:[`1st Payment Required (`,v.min_initial_installment_percent,`%)`]}),(0,u.jsxs)(`div`,{className:`fp-sim-step-val`,children:[`₦`,w.toLocaleString()]})]}),(0,u.jsxs)(`div`,{className:`fp-sim-step`,children:[(0,u.jsx)(`div`,{className:`fp-sim-step-title`,children:`Remaining Balance (2nd Installment)`}),(0,u.jsxs)(`div`,{className:`fp-sim-step-val`,style:{color:`#2563EB`},children:[`₦`,T.toLocaleString()]})]})]})]}),(0,u.jsxs)(`div`,{style:{marginTop:20},children:[(0,u.jsx)(`label`,{className:`fp-form-label`,children:`Warning Message Shown to Parents (if payment is below threshold)`}),(0,u.jsx)(`textarea`,{className:`fp-textarea`,rows:2,value:v.installment_message,onChange:e=>y(t=>({...t,installment_message:e.target.value})),placeholder:`This school requires a minimum initial payment of :percent% (:amount) for the term.`}),(0,u.jsxs)(`div`,{className:`fp-help`,children:[`Use `,(0,u.jsx)(`code`,{children:`:percent`}),` and `,(0,u.jsx)(`code`,{children:`:amount`}),` as automatic placeholders.`]})]})]}):(0,u.jsxs)(`div`,{style:{padding:`16px 20px`,background:`#F1F5F9`,borderRadius:12,fontSize:13.5,color:`#475569`},children:[(0,u.jsx)(`i`,{className:`bi bi-info-circle me-2`}),`Installment control is currently `,(0,u.jsx)(`strong`,{children:`disabled`}),`. Parents can enter and pay any random partial amount.`]})]}),(0,u.jsxs)(`div`,{className:`fp-card`,children:[(0,u.jsxs)(`div`,{className:`fp-card-header`,children:[(0,u.jsxs)(`div`,{style:{display:`flex`,gap:14},children:[(0,u.jsx)(`div`,{className:`fp-card-ico`,style:{background:`#ECFDF5`,color:`#059669`},children:(0,u.jsx)(`i`,{className:`bi bi-tag-fill`})}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`h2`,{className:`fp-card-title`,children:`Full-Payment Early Incentive / Discount`}),(0,u.jsx)(`p`,{className:`fp-card-desc`,children:`Reward parents who settle their full tuition/fees upfront with an automatic percentage or flat cash discount.`})]})]}),(0,u.jsx)(`div`,{className:`form-check form-switch m-0`,children:(0,u.jsx)(`input`,{className:`form-check-input`,type:`checkbox`,role:`switch`,style:{width:44,height:22,cursor:`pointer`},checked:v.full_payment_discount_enabled,onChange:e=>y(t=>({...t,full_payment_discount_enabled:e.target.checked}))})})]}),v.full_payment_discount_enabled?(0,u.jsxs)(`div`,{children:[(0,u.jsxs)(`div`,{className:`row g-3`,children:[(0,u.jsxs)(`div`,{className:`col-12 col-md-6`,children:[(0,u.jsx)(`label`,{className:`fp-form-label`,children:`Discount Calculation Mode`}),(0,u.jsxs)(`select`,{className:`fp-select`,value:v.full_payment_discount_type||`percentage`,onChange:e=>y(t=>({...t,full_payment_discount_type:e.target.value===`fixed`?`fixed`:`percentage`})),children:[(0,u.jsx)(`option`,{value:`percentage`,children:`Percentage Discount (%)`}),(0,u.jsx)(`option`,{value:`fixed`,children:`Fixed Amount Discount (₦)`})]}),(0,u.jsx)(`div`,{className:`fp-help`,children:`Choose whether to deduct a percentage of tuition or a flat cash amount.`})]}),(0,u.jsxs)(`div`,{className:`col-12 col-md-6`,children:[(0,u.jsxs)(`label`,{className:`fp-form-label`,children:[`Discount Value `,v.full_payment_discount_type===`percentage`?`(Percentage %)`:`(Naira ₦)`]}),(0,u.jsxs)(`div`,{className:`input-group`,children:[(0,u.jsx)(`input`,{type:`number`,className:`form-control`,min:0,max:v.full_payment_discount_type===`percentage`?100:1e6,value:v.full_payment_discount_value??0,onChange:e=>y(t=>({...t,full_payment_discount_value:Math.max(0,parseFloat(e.target.value)||0)}))}),(0,u.jsx)(`span`,{className:`input-group-text`,children:v.full_payment_discount_type===`percentage`?`%`:`₦`})]}),(0,u.jsx)(`div`,{className:`fp-help`,children:v.full_payment_discount_type===`percentage`?`e.g., enter 5 for a 5% discount on full fee payments.`:`e.g., enter 2000 for a ₦2,000 flat discount.`})]}),(0,u.jsxs)(`div`,{className:`col-12`,children:[(0,u.jsx)(`label`,{className:`fp-form-label`,children:`Promotional Note / Message Shown to Parents`}),(0,u.jsx)(`textarea`,{className:`fp-textarea`,rows:2,value:v.full_payment_discount_message||``,onChange:e=>y(t=>({...t,full_payment_discount_message:e.target.value})),placeholder:`🎉 Pay your full fee upfront and enjoy an instant :discount discount!`}),(0,u.jsxs)(`div`,{className:`fp-help`,children:[`Use `,(0,u.jsx)(`code`,{children:`:discount`}),`, `,(0,u.jsx)(`code`,{children:`:amount`}),`, or `,(0,u.jsx)(`code`,{children:`:percent`}),` as automatic placeholders in the message.`]})]})]}),(0,u.jsxs)(`div`,{style:{marginTop:18,background:`linear-gradient(135deg, #F0FDF4 0%, #DCFCE7 100%)`,border:`1px solid #86EFAC`,borderRadius:14,padding:`16px 20px`},children:[(0,u.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:8,marginBottom:8,color:`#166534`,fontWeight:700,fontSize:13.5},children:[(0,u.jsx)(`i`,{className:`bi bi-calculator-fill`}),` Live Calculation Demonstration (Sample ₦100,000 Fee)`]}),(0,u.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,flexWrap:`wrap`,gap:12,fontSize:13,color:`#14532D`},children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`span`,{className:`text-muted d-block`,children:`Original Total Fee`}),(0,u.jsx)(`strong`,{children:`₦100,000`})]}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`span`,{className:`text-muted d-block`,children:`Discount Deducted`}),(0,u.jsxs)(`strong`,{style:{color:`#059669`},children:[`-`,v.full_payment_discount_type===`percentage`?`₦${(1e5*(v.full_payment_discount_value||0)/100).toLocaleString()} (${v.full_payment_discount_value||0}%)`:`₦${Number(v.full_payment_discount_value||0).toLocaleString()}`]})]}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`span`,{className:`text-muted d-block`,children:`Amount Paid by Parent`}),(0,u.jsxs)(`strong`,{style:{color:`#1E3A8A`,fontSize:14},children:[`₦`,Math.max(0,1e5-(v.full_payment_discount_type===`percentage`?1e5*(v.full_payment_discount_value||0)/100:Number(v.full_payment_discount_value||0))).toLocaleString()]})]}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`span`,{className:`text-muted d-block`,children:`Student Ledger Status`}),(0,u.jsx)(`span`,{className:`badge bg-success`,style:{padding:`6px 10px`,fontSize:12},children:`₦0 Balance (Fully Cleared)`})]})]})]})]}):(0,u.jsxs)(`div`,{style:{padding:`16px 20px`,background:`#F1F5F9`,borderRadius:12,fontSize:13.5,color:`#475569`},children:[(0,u.jsx)(`i`,{className:`bi bi-info-circle me-2`}),`Full payment early incentive is currently `,(0,u.jsx)(`strong`,{children:`disabled`}),`. No automatic discount is applied when parents pay in full.`]})]}),(0,u.jsxs)(`div`,{className:`fp-card`,children:[(0,u.jsxs)(`div`,{className:`fp-card-header`,children:[(0,u.jsxs)(`div`,{style:{display:`flex`,gap:14},children:[(0,u.jsx)(`div`,{className:`fp-card-ico`,style:{background:`#DCFCE7`,color:`#166534`},children:(0,u.jsx)(`i`,{className:`bi bi-file-earmark-bar-graph-fill`})}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`h2`,{className:`fp-card-title`,children:`Student Result & Report Card Gate`}),(0,u.jsx)(`p`,{className:`fp-card-desc`,children:`Block parents and students from viewing or downloading terminal report cards until fee requirements are satisfied.`})]})]}),(0,u.jsx)(`div`,{className:`form-check form-switch m-0`,children:(0,u.jsx)(`input`,{className:`form-check-input`,type:`checkbox`,role:`switch`,style:{width:44,height:22,cursor:`pointer`},checked:v.result_access_enabled,onChange:e=>y(t=>({...t,result_access_enabled:e.target.checked}))})})]}),v.result_access_enabled&&(0,u.jsxs)(`div`,{className:`row g-3`,children:[(0,u.jsxs)(`div`,{className:`col-12 col-md-6`,children:[(0,u.jsx)(`label`,{className:`fp-form-label`,children:`Minimum Payment Required to View Results`}),(0,u.jsxs)(`div`,{className:`input-group`,children:[(0,u.jsx)(`input`,{type:`number`,className:`form-control`,min:0,max:100,value:v.result_min_payment_percent,onChange:e=>y(t=>({...t,result_min_payment_percent:d(e.target.value,0,100,100)}))}),(0,u.jsx)(`span`,{className:`input-group-text`,children:`%`})]}),(0,u.jsx)(`div`,{className:`fp-help`,children:`Set to 100% to demand complete settlement before result viewing.`})]}),(0,u.jsxs)(`div`,{className:`col-12 col-md-6`,children:[(0,u.jsx)(`label`,{className:`fp-form-label`,children:`Fees Scope to Check`}),(0,u.jsxs)(`select`,{className:`fp-select`,value:v.result_scope,onChange:e=>y(t=>({...t,result_scope:e.target.value===`all_outstanding`?`all_outstanding`:`selected_period`})),children:[(0,u.jsx)(`option`,{value:`selected_period`,children:`Only Current Term Fees`}),(0,u.jsx)(`option`,{value:`all_outstanding`,children:`All Outstanding Historical Arrears`})]}),(0,u.jsx)(`div`,{className:`fp-help`,children:`Choose whether older session arrears also block result viewing.`})]}),(0,u.jsxs)(`div`,{className:`col-12`,children:[(0,u.jsx)(`label`,{className:`fp-form-label`,children:`Result Lock Message Shown to Parents`}),(0,u.jsx)(`textarea`,{className:`fp-textarea`,rows:2,value:v.message,onChange:e=>y(t=>({...t,message:e.target.value}))})]})]})]}),(0,u.jsxs)(`div`,{className:`fp-card`,children:[(0,u.jsxs)(`div`,{className:`fp-card-header`,children:[(0,u.jsxs)(`div`,{style:{display:`flex`,gap:14},children:[(0,u.jsx)(`div`,{className:`fp-card-ico`,style:{background:`#EDE9FE`,color:`#6D28D9`},children:(0,u.jsx)(`i`,{className:`bi bi-laptop-fill`})}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`h2`,{className:`fp-card-title`,children:`CBT Exam Room Gatekeeper`}),(0,u.jsx)(`p`,{className:`fp-card-desc`,children:`Prevent students with unpaid school fees from launching and taking online CBT examinations.`})]})]}),(0,u.jsx)(`div`,{className:`form-check form-switch m-0`,children:(0,u.jsx)(`input`,{className:`form-check-input`,type:`checkbox`,role:`switch`,style:{width:44,height:22,cursor:`pointer`},checked:v.cbt_access_enabled,onChange:e=>y(t=>({...t,cbt_access_enabled:e.target.checked}))})})]}),v.cbt_access_enabled&&(0,u.jsxs)(`div`,{className:`row g-3`,children:[(0,u.jsxs)(`div`,{className:`col-12 col-md-6`,children:[(0,u.jsx)(`label`,{className:`fp-form-label`,children:`Minimum Payment Required for CBT`}),(0,u.jsxs)(`div`,{className:`input-group`,children:[(0,u.jsx)(`input`,{type:`number`,className:`form-control`,min:0,max:100,value:v.cbt_min_payment_percent,onChange:e=>y(t=>({...t,cbt_min_payment_percent:d(e.target.value,0,100,100)}))}),(0,u.jsx)(`span`,{className:`input-group-text`,children:`%`})]})]}),(0,u.jsxs)(`div`,{className:`col-12 col-md-6`,children:[(0,u.jsx)(`label`,{className:`fp-form-label`,children:`CBT Fees Scope to Check`}),(0,u.jsxs)(`select`,{className:`fp-select`,value:v.cbt_scope,onChange:e=>y(t=>({...t,cbt_scope:e.target.value===`all_outstanding`?`all_outstanding`:`selected_period`})),children:[(0,u.jsx)(`option`,{value:`selected_period`,children:`Only Current Term Fees`}),(0,u.jsx)(`option`,{value:`all_outstanding`,children:`All Outstanding Historical Arrears`})]})]}),(0,u.jsxs)(`div`,{className:`col-12`,children:[(0,u.jsx)(`label`,{className:`fp-form-label`,children:`CBT Block Message Shown on Exam Screen`}),(0,u.jsx)(`textarea`,{className:`fp-textarea`,rows:2,value:v.cbt_message,onChange:e=>y(t=>({...t,cbt_message:e.target.value}))})]})]})]}),(0,u.jsxs)(`div`,{className:`fp-card`,children:[(0,u.jsx)(`div`,{className:`fp-card-header`,children:(0,u.jsxs)(`div`,{style:{display:`flex`,gap:14},children:[(0,u.jsx)(`div`,{className:`fp-card-ico`,style:{background:`#EFF6FF`,color:`#1D4ED8`},children:(0,u.jsx)(`i`,{className:`bi bi-bank2`})}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`h2`,{className:`fp-card-title`,children:`School Edition Tier, Bank Charge & Platform Fee Policy`}),(0,u.jsx)(`p`,{className:`fp-card-desc`,children:`Select your school's active platform edition and control who pays bank charges and the SchoolProfit portal fee (Parent vs. School).`})]})]})}),(0,u.jsxs)(`div`,{className:`mb-4`,children:[(0,u.jsxs)(`label`,{className:`fp-form-label`,children:[(0,u.jsx)(`i`,{className:`bi bi-stars me-1 text-warning`}),` Select Active School Edition / Tier`]}),(0,u.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`repeat(auto-fit, minmax(280px, 1fr))`,gap:12},children:[(0,u.jsxs)(`div`,{className:`fp-preset-card ${v.active_edition_tier===`basic_result`?`active`:``}`,style:{padding:`16px`,cursor:`pointer`},onClick:()=>y(e=>({...e,active_edition_tier:`basic_result`})),children:[(0,u.jsxs)(`span`,{className:`fp-preset-pill`,style:{background:`#E0F2FE`,color:`#0369A1`},children:[`₦`,(v.basic_tier_price??300).toLocaleString(),` / Student / Term`]}),(0,u.jsx)(`div`,{className:`fp-preset-title`,style:{fontSize:15},children:`Basic Result Edition`}),(0,u.jsx)(`div`,{className:`fp-preset-desc`,style:{fontSize:12},children:`Result entry, terminal broadsheets, report card downloads, student ID cards, and bursar payment records.`})]}),(0,u.jsxs)(`div`,{className:`fp-preset-card ${v.active_edition_tier===`basic_result`?``:`active`}`,style:{padding:`16px`,cursor:`pointer`},onClick:()=>y(e=>({...e,active_edition_tier:`standard_cbt`})),children:[(0,u.jsxs)(`span`,{className:`fp-preset-pill`,style:{background:`#DCFCE7`,color:`#15803D`},children:[`₦`,(v.standard_cbt_tier_price??500).toLocaleString(),` / Student / Term (Complete)`]}),(0,u.jsx)(`div`,{className:`fp-preset-title`,style:{fontSize:15},children:`Full CBT & AI Edition`}),(0,u.jsx)(`div`,{className:`fp-preset-desc`,style:{fontSize:12},children:`Everything in Basic + Online/Offline CBT Exam Room, AI Lesson Planning, AI Auto-Comments, and WhatsApp Broadcasts.`})]})]})]}),(0,u.jsxs)(`div`,{className:`row g-4`,children:[(0,u.jsxs)(`div`,{className:`col-12 col-md-6`,children:[(0,u.jsxs)(`label`,{className:`fp-form-label`,children:[(0,u.jsx)(`i`,{className:`bi bi-bank me-1 text-primary`}),` Bank Processing Charge Bearer`]}),(0,u.jsxs)(`div`,{style:{display:`flex`,gap:10,marginBottom:12},children:[(0,u.jsxs)(`button`,{type:`button`,className:`fp-preset-card ${v.bank_charge_bearer===`parent`?`active`:``}`,style:{flex:1,padding:`12px 14px`,cursor:`pointer`,textAlign:`left`},onClick:()=>y(e=>({...e,bank_charge_bearer:`parent`})),children:[(0,u.jsx)(`span`,{className:`fp-preset-pill`,children:`Recommended`}),(0,u.jsx)(`div`,{className:`fp-preset-title`,style:{fontSize:13},children:`Parent Pays (Surcharge)`}),(0,u.jsx)(`div`,{className:`fp-preset-desc`,style:{fontSize:11.5},children:`Bank fee added to parent checkout. School receives 100% tuition.`})]}),(0,u.jsxs)(`button`,{type:`button`,className:`fp-preset-card ${v.bank_charge_bearer===`school`?`active`:``}`,style:{flex:1,padding:`12px 14px`,cursor:`pointer`,textAlign:`left`},onClick:()=>y(e=>({...e,bank_charge_bearer:`school`})),children:[(0,u.jsx)(`span`,{className:`fp-preset-pill`,style:{background:`#F1F5F9`,color:`#475569`},children:`Absorbed`}),(0,u.jsx)(`div`,{className:`fp-preset-title`,style:{fontSize:13},children:`School Pays (Absorbed)`}),(0,u.jsx)(`div`,{className:`fp-preset-desc`,style:{fontSize:11.5},children:`School absorbs the bank fee. Parent pays only exact tuition.`})]})]}),(0,u.jsxs)(`label`,{className:`fp-form-label d-flex justify-content-between align-items-center`,children:[(0,u.jsx)(`span`,{children:`Bank Processing Charge`}),(0,u.jsx)(`span`,{className:`badge bg-light text-dark border`,children:`Universal Platform Standard`})]}),(0,u.jsxs)(`div`,{className:`input-group`,children:[(0,u.jsx)(`span`,{className:`input-group-text bg-light text-muted fw-bold`,children:`₦`}),(0,u.jsx)(`input`,{type:`text`,className:`form-control bg-light text-muted fw-bold`,value:(v.bank_charge_amount??200).toLocaleString()+`.00 / transaction`,disabled:!0,readOnly:!0})]}),(0,u.jsxs)(`div`,{className:`fp-help`,children:[(0,u.jsx)(`i`,{className:`bi bi-shield-lock-fill text-warning me-1`}),`Set universally by SchoolProfit Gateway Policy for Wema Bank / AlatPay & Monnify virtual account settlements.`]})]}),(0,u.jsxs)(`div`,{className:`col-12 col-md-6`,children:[(0,u.jsxs)(`label`,{className:`fp-form-label`,children:[(0,u.jsx)(`i`,{className:`bi bi-cpu me-1 text-primary`}),` SchoolProfit Platform Fee Bearer (₦`,(v.active_edition_tier===`basic_result`?v.basic_tier_price??300:v.standard_cbt_tier_price??500).toLocaleString(),` / term)`]}),(0,u.jsxs)(`div`,{style:{display:`flex`,gap:10,marginBottom:12},children:[(0,u.jsxs)(`button`,{type:`button`,className:`fp-preset-card ${v.platform_fee_bearer===`school`?`active`:``}`,style:{flex:1,padding:`12px 14px`,cursor:`pointer`,textAlign:`left`},onClick:()=>y(e=>({...e,platform_fee_bearer:`school`})),children:[(0,u.jsx)(`span`,{className:`fp-preset-pill`,children:`Standard`}),(0,u.jsx)(`div`,{className:`fp-preset-title`,style:{fontSize:13},children:`School Pays (Deducted)`}),(0,u.jsxs)(`div`,{className:`fp-preset-desc`,style:{fontSize:11.5},children:[`₦`,(v.active_edition_tier===`basic_result`?v.basic_tier_price??300:v.standard_cbt_tier_price??500).toLocaleString(),` is deducted from tuition settlement. Parents pay zero extra.`]})]}),(0,u.jsxs)(`button`,{type:`button`,className:`fp-preset-card ${v.platform_fee_bearer===`parent`?`active`:``}`,style:{flex:1,padding:`12px 14px`,cursor:`pointer`,textAlign:`left`},onClick:()=>y(e=>({...e,platform_fee_bearer:`parent`})),children:[(0,u.jsx)(`span`,{className:`fp-preset-pill`,style:{background:`#DBEAFE`,color:`#1D4ED8`},children:`Surcharge`}),(0,u.jsx)(`div`,{className:`fp-preset-title`,style:{fontSize:13},children:`Parent Pays (Added)`}),(0,u.jsxs)(`div`,{className:`fp-preset-desc`,style:{fontSize:11.5},children:[`₦`,(v.active_edition_tier===`basic_result`?v.basic_tier_price??300:v.standard_cbt_tier_price??500).toLocaleString(),` is added to parent checkout as electronic portal access fee.`]})]})]}),(0,u.jsxs)(`div`,{style:{padding:`12px 16px`,background:`#F8FAFC`,borderRadius:10,border:`1px solid #E2E8F0`,fontSize:12.5,color:`#475569`},children:[(0,u.jsx)(`i`,{className:`bi bi-info-circle me-1 text-primary`}),`Platform access fee is only charged once per student per academic term.`]})]})]}),(()=>{let e=v.active_edition_tier===`basic_result`?v.basic_tier_price??300:v.standard_cbt_tier_price??500,t=v.bank_charge_bearer===`parent`?v.bank_charge_amount||200:0,n=v.platform_fee_bearer===`parent`?e:0,r=(v.bank_charge_bearer===`school`?v.bank_charge_amount||200:0)+(v.platform_fee_bearer===`school`?e:0);return(0,u.jsxs)(`div`,{className:`fp-sim-box`,style:{marginTop:22},children:[(0,u.jsxs)(`div`,{className:`fp-sim-head`,children:[(0,u.jsx)(`i`,{className:`bi bi-calculator-fill`}),` Live Settlement Simulation (Example on ₦30,000 School Fee — `,v.active_edition_tier===`basic_result`?`Basic Edition`:`Full CBT Edition`,`)`]}),(0,u.jsxs)(`div`,{className:`fp-sim-steps`,children:[(0,u.jsxs)(`div`,{className:`fp-sim-step`,children:[(0,u.jsx)(`div`,{className:`fp-sim-step-title`,children:`School Fee (Tuition)`}),(0,u.jsx)(`div`,{className:`fp-sim-step-val`,style:{color:`#0F172A`},children:`₦30,000`})]}),(0,u.jsxs)(`div`,{className:`fp-sim-step`,children:[(0,u.jsx)(`div`,{className:`fp-sim-step-title`,children:`Parent Checkout Total`}),(0,u.jsxs)(`div`,{className:`fp-sim-step-val`,style:{color:`#047857`},children:[`₦`,(3e4+t+n).toLocaleString()]})]}),(0,u.jsxs)(`div`,{className:`fp-sim-step`,children:[(0,u.jsx)(`div`,{className:`fp-sim-step-title`,children:`School Net Bank Payout`}),(0,u.jsxs)(`div`,{className:`fp-sim-step-val`,style:{color:`#2563EB`},children:[`₦`,(3e4-r).toLocaleString()]})]})]})]})})()]}),(0,u.jsx)(`div`,{style:{display:`flex`,justifyContent:`flex-end`,marginTop:24},children:(0,u.jsx)(`button`,{className:`fp-btn-save`,onClick:x,disabled:g,style:{padding:`14px 32px`,fontSize:15},children:g?(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`span`,{className:`spinner-border spinner-border-sm`}),` Saving Policy...`]}):(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`i`,{className:`bi bi-check2-circle`,style:{fontSize:20}}),` Save All Policy Changes`]})})})]})]})]})]})}),(0,u.jsx)(c,{})]})}export{f as default};