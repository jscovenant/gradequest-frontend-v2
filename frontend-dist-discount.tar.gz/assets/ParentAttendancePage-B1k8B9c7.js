import{i as e}from"./rolldown-runtime-CWU8vmCm.js";import{Ut as t}from"./vendor-misc-OZLc0tLq.js";import{p as n}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as r,E as i,P as a,d as o,f as s,u as c}from"./index-D6TxbaCx.js";var l=e(t(),1),u=n(),d=()=>{let e=new Date().getHours();return e<12?`Good morning`:e<17?`Good afternoon`:`Good evening`};function f(){let[e,t]=(0,l.useState)(!1),[n,f]=(0,l.useState)(!0),[p,m]=(0,l.useState)([]),[h,g]=(0,l.useState)(null),[_,v]=(0,l.useState)({total_days:0,present_days:0,late_days:0,absent_days:0,excused_days:0,attendance_rate:0}),[y,b]=(0,l.useState)([]),[x,S]=(0,l.useState)([]),[C,w]=(0,l.useState)(`all`),[T,E]=(0,l.useState)(``),D=async e=>{try{f(!0);let t=e?`/parent/attendance?child_id=${e}`:`/parent/attendance`,n=(await a.get(t)).data;m(n.children||[]),n.selected_child?g(n.selected_child.id):n.children&&n.children.length>0&&!h&&g(n.children[0].id),v(n.stats||{total_days:0,present_days:0,late_days:0,absent_days:0,excused_days:0,attendance_rate:0}),b(n.records||[]),S(n.monthly_breakdown||[])}catch(e){console.error(`Failed to load attendance records`,e)}finally{f(!1)}};(0,l.useEffect)(()=>{D()},[]);let O=e=>{g(e),D(e)},k=p.find(e=>e.id===h),A=y.filter(e=>{if(C===`absent`&&e.status!==`absent`&&e.status!==`excused`||C===`late`&&e.status!==`late`)return!1;if(T){let t=T.toLowerCase();return e.date.toLowerCase().includes(t)||e.day.toLowerCase().includes(t)||e.status.toLowerCase().includes(t)||e.remarks&&e.remarks.toLowerCase().includes(t)}return!0}),j=e=>{switch(e){case`present`:return(0,u.jsxs)(`span`,{className:`badge bg-success-subtle text-success fw-bold px-2 py-1`,children:[(0,u.jsx)(`i`,{className:`bi bi-check-circle-fill me-1`}),`Present`]});case`late`:return(0,u.jsxs)(`span`,{className:`badge bg-warning-subtle text-warning fw-bold px-2 py-1`,children:[(0,u.jsx)(`i`,{className:`bi bi-clock-history me-1`}),`Late`]});case`absent`:return(0,u.jsxs)(`span`,{className:`badge bg-danger-subtle text-danger fw-bold px-2 py-1`,children:[(0,u.jsx)(`i`,{className:`bi bi-x-circle-fill me-1`}),`Absent`]});case`excused`:return(0,u.jsxs)(`span`,{className:`badge bg-info-subtle text-info fw-bold px-2 py-1`,children:[(0,u.jsx)(`i`,{className:`bi bi-info-circle-fill me-1`}),`Excused`]});default:return(0,u.jsx)(`span`,{className:`badge bg-secondary-subtle text-secondary fw-bold px-2 py-1`,children:e})}};return(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');

        .p-att-main {
          background: #F8FAFC;
          min-height: 100vh;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          padding: calc(66px + 24px) 28px 40px !important;
        }

        @media (max-width: 767.98px) {
          .p-att-main {
            padding: calc(66px + 16px) 14px 36px !important;
          }
        }

        .p-att-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 18px;
          padding: 32px 36px;
          color: #FFFFFF;
          margin-bottom: 24px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
          position: relative;
          overflow: hidden;
        }

        @media (max-width: 767.98px) {
          .p-att-hero {
            padding: 20px 18px !important;
            border-radius: 14px !important;
            margin-bottom: 16px !important;
          }
        }

        .p-att-hero::before {
          content: '';
          position: absolute;
          inset: 0;
          background-image:
            linear-gradient(rgba(255, 255, 255, 0.035) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255, 255, 255, 0.035) 1px, transparent 1px);
          background-size: 32px 32px;
          pointer-events: none;
        }

        .p-att-hero-glow {
          position: absolute;
          top: -40px;
          right: -40px;
          width: 320px;
          height: 320px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.2) 0%, transparent 65%);
          pointer-events: none;
        }

        .p-att-hero-inner {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          flex-wrap: wrap;
          gap: 20px;
        }

        .p-att-badge {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.20);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius: 100px;
          padding: 4px 12px;
          margin-bottom: 12px;
        }

        .p-att-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #10B981;
          box-shadow: 0 0 6px #10B981;
        }

        .p-att-title {
          font-size: 26px;
          font-weight: 800;
          color: #FFFFFF;
          line-height: 1.1;
          margin-bottom: 8px;
        }

        .p-att-title em {
          font-style: normal;
          color: #FBBF24;
        }

        .p-att-sub {
          font-size: 13.5px;
          color: #CBD5E1;
          line-height: 1.6;
          max-width: 620px;
          margin-bottom: 0;
        }

        @media (max-width: 767.98px) {
          .p-att-title {
            font-size: 20px !important;
          }
          .p-att-sub {
            font-size: 12.5px !important;
          }
        }

        /* Child Selector Pills */
        .p-child-pill {
          display: inline-flex;
          align-items: center;
          gap: 10px;
          padding: 8px 16px;
          border-radius: 12px;
          background: #FFFFFF;
          border: 1.5px solid #E2E8F0;
          color: #475569;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .p-child-pill:hover {
          background: #F1F5F9;
          border-color: #CBD5E1;
          transform: translateY(-1px);
        }

        .p-child-pill.active {
          background: #0A192F;
          border-color: #0A192F;
          color: #FFFFFF;
          box-shadow: 0 4px 14px rgba(10, 25, 47, 0.25);
        }

        .p-child-pill.active .p-child-sub {
          color: #FBBF24;
        }

        .p-child-avatar {
          width: 30px;
          height: 30px;
          border-radius: 50%;
          background: #E2E8F0;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: 700;
          font-size: 12px;
          color: #0F2744;
        }

        /* KPI Cards */
        .p-stat-card {
          background: #FFFFFF;
          border: 1px solid rgba(15, 39, 68, 0.08);
          border-radius: 16px;
          padding: 20px;
          box-shadow: 0 2px 8px rgba(15, 39, 68, 0.04);
          transition: all 0.2s ease;
          position: relative;
          overflow: hidden;
        }

        .p-stat-card:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 24px rgba(15, 39, 68, 0.08);
        }

        .p-stat-card::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          height: 3px;
          background: var(--stat-color, #2563EB);
        }

        /* Panels */
        .p-panel {
          background: #FFFFFF;
          border: 1px solid rgba(15, 39, 68, 0.08);
          border-radius: 18px;
          box-shadow: 0 4px 20px rgba(15, 39, 68, 0.06);
          overflow: hidden;
          margin-bottom: 24px;
        }

        .p-panel-head {
          padding: 18px 22px;
          border-bottom: 1px solid #E2E8F0;
          display: flex;
          align-items: center;
          justify-content: space-between;
          flex-wrap: wrap;
          gap: 12px;
        }

        .p-table {
          width: 100%;
          border-collapse: collapse;
        }

        .p-table th {
          background: #F8FAFC;
          color: #64748B;
          font-size: 11.5px;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.04em;
          padding: 12px 18px;
          border-bottom: 1px solid #E2E8F0;
        }

        .p-table td {
          padding: 14px 18px;
          border-bottom: 1px solid #F1F5F9;
          font-size: 13.5px;
          color: #1E293B;
          vertical-align: middle;
        }

        .p-table tr:hover td {
          background: #F8FAFC;
        }
      `}),(0,u.jsx)(s,{sidebarOpen:e,setSidebarOpen:t}),(0,u.jsx)(r,{title:`Child Attendance - SchoolProfit`}),(0,u.jsx)(`div`,{className:`container-fluid`,children:(0,u.jsxs)(`div`,{className:`row`,children:[(0,u.jsx)(o,{sidebarOpen:e,setSidebarOpen:t}),(0,u.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto gq-app-main parent-db-main d-flex flex-column min-vh-100`,children:[n&&(0,u.jsx)(i,{message:`Loading attendance records...`}),(0,u.jsxs)(`div`,{className:`p-att-hero`,children:[(0,u.jsx)(`div`,{className:`p-att-hero-glow`}),(0,u.jsx)(`div`,{className:`p-att-hero-inner`,children:(0,u.jsxs)(`div`,{children:[(0,u.jsxs)(`div`,{className:`p-att-badge`,children:[(0,u.jsx)(`span`,{className:`p-att-dot`}),`Parent Portal · Attendance Tracker`]}),(0,u.jsxs)(`h1`,{className:`p-att-title`,children:[d(),`, `,(0,u.jsx)(`em`,{children:`Parent.`})]}),(0,u.jsx)(`p`,{className:`p-att-sub`,children:`Monitor your child's daily class presence, arrival punctuality, excused absence logs, and cumulative attendance ratings in real-time.`})]})})]}),p.length>0&&(0,u.jsxs)(`div`,{className:`mb-4`,children:[(0,u.jsxs)(`div`,{className:`d-flex align-items-center justify-content-between mb-2`,children:[(0,u.jsx)(`span`,{className:`fw-bold small text-uppercase text-muted`,style:{letterSpacing:`0.05em`},children:`Select Ward / Child`}),(0,u.jsxs)(`span`,{className:`badge bg-primary-subtle text-primary fw-bold`,children:[p.length,` `,p.length===1?`Child Linked`:`Children Linked`]})]}),(0,u.jsx)(`div`,{className:`d-flex flex-wrap gap-2`,children:p.map(e=>{let t=e.id===h,n=`${e.surname?.[0]||``}${e.firstname?.[0]||``}`.toUpperCase();return(0,u.jsxs)(`button`,{type:`button`,className:`p-child-pill ${t?`active`:``}`,onClick:()=>O(e.id),children:[(0,u.jsx)(`div`,{className:`p-child-avatar`,children:e.photo?(0,u.jsx)(`img`,{src:e.photo,alt:e.firstname,className:`w-100 h-100 rounded-circle object-fit-cover`}):n}),(0,u.jsxs)(`div`,{className:`text-start`,children:[(0,u.jsxs)(`div`,{className:`fw-bold`,children:[e.surname,` `,e.firstname]}),(0,u.jsxs)(`div`,{className:`p-child-sub small`,style:{fontSize:`11.5px`},children:[e.class_name||`Assigned Class`,` · `,e.reg_no]})]})]},e.id)})})]}),(0,u.jsxs)(`div`,{className:`row g-3 mb-4`,children:[(0,u.jsx)(`div`,{className:`col-sm-6 col-xl-3`,children:(0,u.jsxs)(`div`,{className:`p-stat-card`,style:{"--stat-color":`#2563EB`},children:[(0,u.jsxs)(`div`,{className:`d-flex justify-content-between align-items-start mb-2`,children:[(0,u.jsx)(`span`,{className:`small fw-bold text-uppercase text-muted`,children:`Attendance Rate`}),(0,u.jsx)(`span`,{className:`badge bg-primary-subtle text-primary fw-bold`,children:_.attendance_rate>=80?`Excellent`:_.attendance_rate>=60?`Average`:`Warning`})]}),(0,u.jsxs)(`div`,{className:`fs-3 fw-bold text-dark`,children:[_.attendance_rate,`%`]}),(0,u.jsx)(`div`,{className:`progress mt-2`,style:{height:6},children:(0,u.jsx)(`div`,{className:`progress-bar ${_.attendance_rate>=75?`bg-success`:_.attendance_rate>=50?`bg-warning`:`bg-danger`}`,style:{width:`${Math.min(100,_.attendance_rate)}%`}})})]})}),(0,u.jsx)(`div`,{className:`col-sm-6 col-xl-3`,children:(0,u.jsxs)(`div`,{className:`p-stat-card`,style:{"--stat-color":`#10B981`},children:[(0,u.jsxs)(`div`,{className:`d-flex justify-content-between align-items-start mb-2`,children:[(0,u.jsx)(`span`,{className:`small fw-bold text-uppercase text-muted`,children:`Days Present`}),(0,u.jsx)(`i`,{className:`bi bi-calendar-check text-success fs-5`})]}),(0,u.jsxs)(`div`,{className:`fs-3 fw-bold text-dark`,children:[_.present_days,` `,(0,u.jsxs)(`span`,{className:`fs-6 fw-normal text-muted`,children:[`/ `,_.total_days]})]}),(0,u.jsx)(`div`,{className:`small text-muted mt-1`,children:`Total school days recorded`})]})}),(0,u.jsx)(`div`,{className:`col-sm-6 col-xl-3`,children:(0,u.jsxs)(`div`,{className:`p-stat-card`,style:{"--stat-color":`#F59E0B`},children:[(0,u.jsxs)(`div`,{className:`d-flex justify-content-between align-items-start mb-2`,children:[(0,u.jsx)(`span`,{className:`small fw-bold text-uppercase text-muted`,children:`Late Arrivals`}),(0,u.jsx)(`i`,{className:`bi bi-clock-history text-warning fs-5`})]}),(0,u.jsx)(`div`,{className:`fs-3 fw-bold text-dark`,children:_.late_days}),(0,u.jsx)(`div`,{className:`small text-muted mt-1`,children:`Recorded after morning assembly`})]})}),(0,u.jsx)(`div`,{className:`col-sm-6 col-xl-3`,children:(0,u.jsxs)(`div`,{className:`p-stat-card`,style:{"--stat-color":`#EF4444`},children:[(0,u.jsxs)(`div`,{className:`d-flex justify-content-between align-items-start mb-2`,children:[(0,u.jsx)(`span`,{className:`small fw-bold text-uppercase text-muted`,children:`Absences & Excuses`}),(0,u.jsx)(`i`,{className:`bi bi-exclamation-octagon text-danger fs-5`})]}),(0,u.jsxs)(`div`,{className:`fs-3 fw-bold text-dark`,children:[_.absent_days,` `,(0,u.jsxs)(`span`,{className:`fs-6 fw-normal text-muted`,children:[`(`,_.excused_days,` excused)`]})]}),(0,u.jsx)(`div`,{className:`small text-muted mt-1`,children:`Missed school sessions`})]})})]}),(0,u.jsxs)(`div`,{className:`row g-4 mb-4`,children:[x.length>0&&(0,u.jsx)(`div`,{className:`col-12`,children:(0,u.jsxs)(`div`,{className:`p-panel mb-0`,children:[(0,u.jsxs)(`div`,{className:`p-panel-head`,children:[(0,u.jsxs)(`div`,{className:`fw-bold`,style:{color:`#0F2744`,fontSize:`15px`},children:[(0,u.jsx)(`i`,{className:`bi bi-bar-chart-steps me-2 text-primary`}),`Monthly Attendance Trend`]}),(0,u.jsx)(`small`,{className:`text-muted`,children:`Presence consistency by month`})]}),(0,u.jsx)(`div`,{className:`p-4`,children:(0,u.jsx)(`div`,{className:`row g-3`,children:x.map((e,t)=>(0,u.jsx)(`div`,{className:`col-sm-6 col-md-4 col-lg-2`,children:(0,u.jsxs)(`div`,{className:`border rounded-3 p-3 text-center bg-light`,children:[(0,u.jsx)(`div`,{className:`small fw-bold text-muted mb-1`,children:e.month}),(0,u.jsxs)(`div`,{className:`fs-5 fw-bold text-dark`,children:[e.rate,`%`]}),(0,u.jsxs)(`div`,{className:`small text-muted`,children:[e.present,` / `,e.total,` days`]})]})},t))})})]})}),(0,u.jsx)(`div`,{className:`col-12`,children:(0,u.jsxs)(`div`,{className:`p-panel`,children:[(0,u.jsxs)(`div`,{className:`p-panel-head`,children:[(0,u.jsxs)(`div`,{className:`d-flex align-items-center gap-3 flex-wrap`,children:[(0,u.jsxs)(`h2`,{className:`mb-0 fw-bold fs-6`,style:{color:`#0F2744`},children:[(0,u.jsx)(`i`,{className:`bi bi-calendar2-week me-2 text-primary`}),`Attendance History for `,k?`${k.surname} ${k.firstname}`:`Child`]}),(0,u.jsxs)(`div`,{className:`btn-group btn-group-sm`,children:[(0,u.jsxs)(`button`,{type:`button`,className:`btn ${C===`all`?`btn-dark`:`btn-outline-secondary`}`,onClick:()=>w(`all`),children:[`All Logs (`,y.length,`)`]}),(0,u.jsxs)(`button`,{type:`button`,className:`btn ${C===`absent`?`btn-dark`:`btn-outline-secondary`}`,onClick:()=>w(`absent`),children:[`Absences (`,_.absent_days+_.excused_days,`)`]}),(0,u.jsxs)(`button`,{type:`button`,className:`btn ${C===`late`?`btn-dark`:`btn-outline-secondary`}`,onClick:()=>w(`late`),children:[`Late Arrivals (`,_.late_days,`)`]})]})]}),(0,u.jsxs)(`div`,{className:`d-flex gap-2 align-items-center`,children:[(0,u.jsx)(`input`,{type:`text`,className:`form-control form-control-sm`,style:{maxWidth:220,borderRadius:8},placeholder:`Search date, remark...`,value:T,onChange:e=>E(e.target.value)}),(0,u.jsxs)(`button`,{type:`button`,className:`btn btn-sm btn-outline-secondary d-flex align-items-center gap-1`,onClick:()=>D(h||void 0),children:[(0,u.jsx)(`i`,{className:`bi bi-arrow-clockwise`}),`Refresh`]})]})]}),(0,u.jsx)(`div`,{className:`table-responsive`,children:(0,u.jsxs)(`table`,{className:`p-table`,children:[(0,u.jsx)(`thead`,{children:(0,u.jsxs)(`tr`,{children:[(0,u.jsx)(`th`,{children:`Date`}),(0,u.jsx)(`th`,{children:`Day`}),(0,u.jsx)(`th`,{children:`Week`}),(0,u.jsx)(`th`,{children:`Status`}),(0,u.jsx)(`th`,{children:`Teacher Note / Remark`}),(0,u.jsx)(`th`,{children:`Logged By`})]})}),(0,u.jsx)(`tbody`,{children:A.length===0?(0,u.jsx)(`tr`,{children:(0,u.jsxs)(`td`,{colSpan:6,className:`text-center py-5 text-muted`,children:[(0,u.jsx)(`i`,{className:`bi bi-calendar-x fs-2 d-block mb-2 text-secondary`}),`No attendance entries found for this filter.`]})}):A.map(e=>(0,u.jsxs)(`tr`,{children:[(0,u.jsx)(`td`,{className:`fw-bold`,children:e.date}),(0,u.jsx)(`td`,{children:e.day}),(0,u.jsx)(`td`,{children:(0,u.jsxs)(`span`,{className:`badge bg-light text-dark border`,children:[`Week `,e.week_number]})}),(0,u.jsx)(`td`,{children:j(e.status)}),(0,u.jsx)(`td`,{children:(0,u.jsx)(`span`,{className:`text-muted small`,children:e.remarks})}),(0,u.jsx)(`td`,{className:`small text-muted`,children:e.marked_by})]},e.id))})]})})]})})]}),(0,u.jsx)(c,{})]})]})})]})}export{f as default};