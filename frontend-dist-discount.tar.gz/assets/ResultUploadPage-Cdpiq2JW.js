import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{b as t,p as n,x as r}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as i,E as a,P as o,d as s,f as c,l as ee,u as l}from"./index-D6TxbaCx.js";var u=e(),d=n();function f(){let{search:e}=t();return(0,u.useMemo)(()=>new URLSearchParams(e),[e])}function p(){let e=new Date().getHours();return e<12?`Good morning`:e<17?`Good afternoon`:`Good evening`}function m(){let e=f(),t=r(),{showSuccess:n,showError:m,showWarning:h}=ee(),g=Number(e.get(`batchId`)||0),[_,v]=(0,u.useState)(!1),[y,te]=(0,u.useState)(!0),[b,x]=(0,u.useState)(!0),[S,C]=(0,u.useState)(!0),[w,T]=(0,u.useState)(null),[E,D]=(0,u.useState)([]),[O,k]=(0,u.useState)([]),[A,j]=(0,u.useState)(``),[M,N]=(0,u.useState)(null),[P,F]=(0,u.useState)(null),[I,L]=(0,u.useState)(!1),[R,z]=(0,u.useState)(!1),[B,V]=(0,u.useState)(`ca_exam`),[H,U]=(0,u.useState)(``),W=(0,u.useRef)(null);(0,u.useEffect)(()=>{let e=window.setTimeout(()=>te(!1),120);return()=>window.clearTimeout(e)},[]),(0,u.useEffect)(()=>{let e=!0;async function t(){if(!g||Number.isNaN(g)){h?.(`Missing batchId in URL. Go back to Batch Setup.`),x(!1),C(!1);return}x(!0),C(!0);try{let[t,n,r]=await Promise.all([o.get(`/result-batches/${g}`),o.get(`/result-batches/${g}/students`),o.get(`/fdepartments`).catch(()=>({data:[]}))]);if(!e)return;T(t.data?.batch??t.data);let i=n.data?.data??n.data??[];D(Array.isArray(i)?i:[]);let a=r.data?.data??r.data??[];k(Array.isArray(a)?a:[])}catch(e){console.error(e),m?.(e?.response?.data?.message||`Failed to load batch upload data.`),T(null),D([])}finally{e&&(x(!1),C(!1))}}return t(),()=>{e=!1}},[g,m,h]);let G=(0,u.useMemo)(()=>{let e=A.trim().toLowerCase();return e?E.filter(t=>{let n=`${t.firstname} ${t.surname}`.toLowerCase(),r=(t.reg_no||``).toLowerCase();return n.includes(e)||r.includes(e)}):E},[E,A]),K=(0,u.useMemo)(()=>{let e=E.length,t=E.filter(e=>e.status===`completed`).length;return{total:e,done:t,pending:Math.max(0,e-t),pct:e?Math.round(t/e*100):0}},[E]),q=e=>{t(`/students/results/add?batchId=${g}&studentId=${e}`)},J=async()=>{if(!g)return;let e=await o.get(`/result-batches/${g}/students`),t=e.data?.data??e.data??[];D(Array.isArray(t)?t:[])},Y=async e=>{if(g)try{let t=await o.get(`/result-batches/${g}/result-import/template`,{params:{format:e,assessment_format:B,...H?{department_id:H}:{}},responseType:`blob`}),n=window.URL.createObjectURL(new Blob([t.data])),r=document.createElement(`a`);r.href=n,r.download=`result_upload_template_batch_${g}.${e}`,document.body.appendChild(r),r.click(),r.remove(),window.URL.revokeObjectURL(n)}catch(e){console.error(e),m?.(e?.response?.data?.message||`Unable to download result template.`)}},X=async()=>{if(!g||!M){h?.(`Choose an Excel or CSV file first.`);return}let e=new FormData;e.append(`file`,M),H&&e.append(`department_id`,String(H)),L(!0);try{let t=await o.post(`/result-batches/${g}/result-import/preview`,e,{headers:{"Content-Type":`multipart/form-data`}});F(t.data),t.data?.summary?.can_import?n?.(`File looks good. You can now import the results.`):h?.(`Please correct the highlighted issues before importing.`)}catch(e){console.error(e);let t=e?.response?.data,n=t?.message||t?.errors?.file?.[0]||`Unable to preview result file.`;m?.(n)}finally{L(!1)}},Z=e=>{N(e??null),F(null),e&&(n?.(`${e.name} selected. You can preview it now.`),window.setTimeout(()=>window.focus(),100))},ne=()=>{W.current?.click()},re=async()=>{if(!g||!M||!P?.summary?.can_import)return;let e=new FormData;e.append(`file`,M),H&&e.append(`department_id`,String(H)),z(!0);try{let t=await o.post(`/result-batches/${g}/result-import/import`,e,{headers:{"Content-Type":`multipart/form-data`}});n?.(t.data?.message||`Results imported successfully.`),N(null),F(null),await J()}catch(e){console.error(e);let t=e?.response?.data,n=t?.message||t?.errors?.file?.[0]||`Unable to import result file.`;m?.(n)}finally{z(!1)}},Q=async()=>{if(g)try{await o.post(`/result-batches/${g}/compute`),n?.(`Batch compute started ✅`)}catch(e){console.error(e),m?.(e?.response?.data?.message||`Failed to compute batch.`)}},ie=e=>{w&&t(`/students/results/show?${new URLSearchParams({student_id:String(e),class_id:String(w.class_id),term:String(w.term),session:String(w.session),school_id:String(w.school_id)}).toString()}`,{state:{studentId:e,classId:w.class_id,term:w.term,session:w.session,schoolId:w.school_id}})},$=(0,u.useMemo)(()=>{let e=String(w?.status||``).toLowerCase();return e===`published`?{bg:`rgba(34,197,94,0.16)`,fg:`#22c55e`,text:`PUBLISHED`}:e===`computed`?{bg:`rgba(59,130,246,0.16)`,fg:`#60a5fa`,text:`COMPUTED`}:{bg:`rgba(245,158,11,0.16)`,fg:`#fbbf24`,text:(w?.status||`DRAFT`).toUpperCase()}},[w]);return(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(`style`,{children:`
        /* ======= ResultUploadPage - Modern SaaS style ======= */
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');
        .db-main {
          background: #F8FAFC;
          min-height: 100vh;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          padding: 24px 28px 0;
        }

        .db-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 18px;
          padding: 32px 36px;
          position: relative;
          overflow: hidden;
          margin-bottom: 24px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
        }

        .db-hero-glow {
          position: absolute;
          top: -60px;
          right: -60px;
          width: 320px;
          height: 320px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.15) 0%, transparent 65%);
          pointer-events: none;
        }

        .db-hero-glow2 {
          position: absolute;
          bottom: -40px;
          left: 30%;
          width: 200px;
          height: 200px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(37, 99, 235, 0.10) 0%, transparent 70%);
          pointer-events: none;
        }

        .db-hero-inner {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 32px;
          flex-wrap: wrap;
        }

        @media (min-width: 768px) {
          .db-hero-inner { flex-wrap: nowrap; }
        }

        .db-session-badge {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.20);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius: 100px;
          padding: 4px 12px;
          margin-bottom: 12px;
        }

        .db-session-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #10B981;
          animation: dbPulse 2s ease infinite;
        }

        @keyframes dbPulse {
          0%,100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.4; transform: scale(1.5); }
        }

        .db-greeting {
          font-size: 26px;
          font-weight: 800;
          color: #fff;
          line-height: 1.1;
          margin-bottom: 8px;
        }
        .db-greeting em { font-style: normal; color: #FBBF24; }

        .db-hero-sub {
          font-size: 13.5px;
          color: #CBD5E1;
          line-height: 1.6;
          max-width: 440px;
          margin-bottom: 20px;
        }

        .db-hero-btns { display: flex; gap: 10px; flex-wrap: wrap; }

        .db-btn-gold {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 9px 18px;
          font-size: 13px;
          font-weight: 700;
          color: #FFFFFF;
          background: #D97706;
          border: none;
          border-radius: 10px;
          cursor: pointer;
          transition: all 0.2s ease;
          white-space: nowrap;
        }
        .db-btn-gold:hover { background: #B45309; transform: translateY(-1px); color: #FFFFFF; }
        .db-btn-gold:disabled { opacity: 0.55; cursor: not-allowed; transform: none; }

        .db-btn-outline {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 9px 18px;
          font-size: 13px;
          font-weight: 600;
          color: #FFFFFF;
          background: rgba(255, 255, 255, 0.10);
          border: 1px solid rgba(255, 255, 255, 0.20);
          border-radius: 10px;
          cursor: pointer;
          transition: all 0.2s ease;
          white-space: nowrap;
        }
        .db-btn-outline:hover {
          background: rgba(255, 255, 255, 0.18);
          color: #fff;
        }
        .db-btn-outline:disabled { opacity: 0.55; cursor: not-allowed; }

        .db-hero-stat-card {
          background: rgba(255, 255, 255, 0.08);
          border: 1px solid rgba(255, 255, 255, 0.15);
          backdrop-filter: blur(8px);
          border-radius: 14px;
          padding: 18px 20px;
          min-width: 240px;
          margin-left: auto;
          align-self: flex-end;
        }

        .db-hero-stat-row {
          display: flex;
          flex-direction: column;
          gap: 10px;
        }

        .db-hero-stat-item {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 16px;
        }

        .db-hero-stat-label {
          font-size: 12px;
          font-weight: 400;
          color: #CBD5E1;
        }

        .db-hero-stat-val {
          font-size: 18px;
          font-weight: 800;
          color: #FBBF24;
        }

        .db-hero-stat-sep {
          height: 1px;
          background: rgba(255, 255, 255, 0.08);
        }

        .db-panel {
          background: #fff;
          border: 1px solid #E2E8F0;
          border-radius: 16px;
          overflow: hidden;
          box-shadow: 0 4px 16px rgba(15, 39, 68, 0.03);
          margin-bottom: 20px;
        }

        .db-panel-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 18px 20px;
          border-bottom: 1px solid #E2E8F0;
          gap: 12px;
          flex-wrap: wrap;
        }

        .db-panel-title {
          font-size: 16px;
          font-weight: 700;
          color: #0F2744;
          margin: 0;
        }

        .db-panel-sub {
          font-size: 12px;
          color: #64748B;
          margin: 0;
        }

        .db-refresh-btn {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 8px 14px;
          font-size: 12.5px;
          font-weight: 600;
          color: #0F2744;
          background: #F1F5F9;
          border: 1px solid #E2E8F0;
          border-radius: 8px;
          cursor: pointer;
          transition: all 0.2s;
          white-space: nowrap;
        }
        .db-refresh-btn:hover { background: #E2E8F0; }
        .db-refresh-btn:disabled { opacity: 0.55; cursor: not-allowed; }

        .db-grid {
          display: grid;
          grid-template-columns: 1fr 360px;
          gap: 20px;
          margin-bottom: 24px;
        }
        @media (max-width: 991.98px) { .db-grid { grid-template-columns: 1fr; } }

        .db-table { width: 100%; border-collapse: separate; border-spacing: 0; }
        .db-table th {
          padding: 12px 16px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #64748B;
          background: #F8FAFC;
          border-bottom: 1px solid #E2E8F0;
          text-align: left;
          white-space: nowrap;
        }
        .db-table th:last-child { text-align: right; }
        .db-table td {
          padding: 14px 16px;
          font-size: 13px;
          color: #334155;
          border-bottom: 1px solid #E2E8F0;
          vertical-align: middle;
        }
        .db-table tbody tr:last-child td { border-bottom: none; }
        .db-table tbody tr:hover { background: #F8FAFC; }

        .db-muted { color: #64748B; }
        .db-strong { font-weight: 700; color: #0F2744; }

        .db-pill {
          display: inline-flex;
          align-items: center;
          font-size: 11.5px;
          font-weight: 700;
          padding: 5px 10px;
          border-radius: 999px;
          white-space: nowrap;
          border: 1px solid rgba(0,0,0,0.06);
        }

        .db-skeleton {
          height: 14px;
          border-radius: 7px;
          background: linear-gradient(90deg, #F1F5F9 25%, #E2E8F0 50%, #F1F5F9 75%);
          background-size: 200% 100%;
          animation: dbSkeleton 1.4s ease infinite;
        }
        @keyframes dbSkeleton { from { background-position: 200% 0; } to { background-position: -200% 0; } }

        .db-search {
          display: flex;
          align-items: center;
          gap: 10px;
          background: #fff;
          border: 1px solid #E2E8F0;
          border-radius: 10px;
          padding: 10px 14px;
          min-width: 260px;
        }
        .db-search input { border: none; outline: none; width: 100%; font-size: 13px; color: #0F2744; }

        .db-progress-wrap { min-width: 280px; }
        .db-progress-bar {
          height: 8px;
          border-radius: 999px;
          background: #E2E8F0;
          overflow: hidden;
        }
        .db-progress-fill {
          height: 100%;
          width: var(--w, 0%);
          background: linear-gradient(90deg, #D97706, #FBBF24);
        }

        .db-badge {
          display:inline-flex;
          align-items:center;
          gap:6px;
          padding:4px 10px;
          border-radius:999px;
          font-size:11.5px;
          font-weight:700;
        }
      `}),(0,d.jsx)(c,{sidebarOpen:_,setSidebarOpen:v}),(0,d.jsx)(i,{title:`Input Result`}),(0,d.jsx)(`div`,{className:`container-fluid`,children:(0,d.jsxs)(`div`,{className:`row`,children:[(0,d.jsx)(s,{sidebarOpen:_}),(0,d.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto db-main`,children:[y&&(0,d.jsx)(a,{message:`Preparing Results Upload...`}),(0,d.jsxs)(`div`,{className:`db-hero`,children:[(0,d.jsx)(`div`,{className:`db-hero-glow`,"aria-hidden":`true`}),(0,d.jsx)(`div`,{className:`db-hero-glow2`,"aria-hidden":`true`}),(0,d.jsxs)(`div`,{className:`db-hero-inner`,children:[(0,d.jsxs)(`div`,{children:[(0,d.jsxs)(`div`,{className:`db-session-badge`,children:[(0,d.jsx)(`span`,{className:`db-session-dot`}),`Results — Upload`]}),(0,d.jsxs)(`h1`,{className:`db-greeting`,children:[p(),`, `,(0,d.jsx)(`em`,{children:`Staff.`})]}),(0,d.jsx)(`p`,{className:`db-hero-sub`,children:`Upload results student-by-student for this batch. When everyone is done, compute positions and averages once.`}),(0,d.jsxs)(`div`,{className:`db-hero-btns`,children:[(0,d.jsxs)(`button`,{className:`db-btn-gold`,onClick:Q,disabled:!g,children:[(0,d.jsx)(`i`,{className:`bi bi-calculator-fill`}),`Compute Batch`]}),(0,d.jsxs)(`button`,{className:`db-btn-outline`,onClick:()=>t(`/results/broadsheet/${g}`),disabled:!g,children:[(0,d.jsx)(`i`,{className:`bi bi-table`}),`Broadsheet`]}),(0,d.jsxs)(`button`,{className:`db-btn-outline`,onClick:()=>t(`/students/results/batch`),children:[(0,d.jsx)(`i`,{className:`bi bi-arrow-left-circle`}),`Change Batch`]})]})]}),(0,d.jsxs)(`div`,{className:`db-hero-stat-card d-none d-md-block`,children:[(0,d.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,marginBottom:16},children:[(0,d.jsx)(`span`,{style:{fontSize:11,fontWeight:500,letterSpacing:`0.14em`,textTransform:`uppercase`,color:`#c9a84c`},children:`Quick glance`}),(0,d.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:(0,d.jsx)(`path`,{d:`M2 10V6M5 10V4M8 10V7M11 10V3`,stroke:`#64748b`,strokeWidth:`1.5`,strokeLinecap:`round`})})]}),(0,d.jsxs)(`div`,{className:`db-hero-stat-row`,children:[(0,d.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,d.jsx)(`span`,{className:`db-hero-stat-label`,children:`Completed`}),(0,d.jsx)(`span`,{className:`db-hero-stat-val`,children:b?`…`:K.done})]}),(0,d.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,d.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,d.jsx)(`span`,{className:`db-hero-stat-label`,children:`Pending`}),(0,d.jsx)(`span`,{className:`db-hero-stat-val`,children:b?`…`:K.pending})]}),(0,d.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,d.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,d.jsx)(`span`,{className:`db-hero-stat-label`,children:`Total`}),(0,d.jsx)(`span`,{className:`db-hero-stat-val`,children:b?`…`:K.total})]}),(0,d.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,d.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,d.jsx)(`span`,{className:`db-hero-stat-label`,children:`Progress`}),(0,d.jsx)(`span`,{className:`db-hero-stat-val`,children:b?`…`:`${K.pct}%`})]})]})]})]})]}),b?(0,d.jsxs)(`div`,{className:`db-panel`,children:[(0,d.jsx)(`div`,{className:`db-panel-head`,children:(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`p`,{className:`db-panel-title`,children:`Loading batch…`}),(0,d.jsxs)(`p`,{className:`db-panel-sub`,children:[`Fetching Batch #`,g]})]})}),(0,d.jsxs)(`div`,{style:{padding:16,display:`flex`,alignItems:`center`,gap:10},children:[(0,d.jsx)(`span`,{className:`spinner-border spinner-border-sm`,role:`status`}),(0,d.jsx)(`span`,{className:`db-muted`,children:`Please wait…`})]})]}):w?(0,d.jsxs)(`div`,{className:`db-grid`,children:[(0,d.jsxs)(`div`,{className:`db-panel`,children:[(0,d.jsxs)(`div`,{className:`db-panel-head`,children:[(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`p`,{className:`db-panel-title`,children:`Students in this batch`}),(0,d.jsx)(`p`,{className:`db-panel-sub`,children:`Search by name or admission number, then enter/edit results.`})]}),(0,d.jsxs)(`div`,{style:{display:`flex`,gap:10,flexWrap:`wrap`,alignItems:`center`},children:[(0,d.jsxs)(`div`,{className:`db-search`,children:[(0,d.jsx)(`i`,{className:`bi bi-search`,style:{color:`#9a8a7a`}}),(0,d.jsx)(`input`,{placeholder:`Search name or reg no…`,value:A,onChange:e=>j(e.target.value)})]}),(0,d.jsxs)(`button`,{className:`db-refresh-btn`,onClick:()=>j(``),disabled:!A,children:[(0,d.jsx)(`i`,{className:`bi bi-x-circle`}),`Clear`]})]})]}),(0,d.jsxs)(`div`,{style:{padding:16,display:`grid`,gap:12},children:[(0,d.jsxs)(`div`,{style:{border:`1px solid rgba(0,0,0,0.06)`,background:`#faf8f5`,borderRadius:14,padding:14,display:`flex`,alignItems:`center`,justifyContent:`space-between`,gap:16,flexWrap:`wrap`},children:[(0,d.jsxs)(`div`,{children:[(0,d.jsxs)(`div`,{className:`db-strong`,style:{fontSize:13.5},children:[`Batch #`,w.id,` • Class ID `,w.class_id]}),(0,d.jsxs)(`div`,{className:`db-muted`,style:{fontSize:12,marginTop:2},children:[w.term,` • `,w.session,` •`,` `,(0,d.jsx)(`span`,{className:`db-pill`,style:{background:$.bg,color:$.fg},children:$.text})]})]}),(0,d.jsxs)(`div`,{className:`db-progress-wrap`,children:[(0,d.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,fontSize:12,marginBottom:6},children:[(0,d.jsx)(`span`,{className:`db-muted`,children:`Progress`}),(0,d.jsxs)(`span`,{className:`db-strong`,children:[K.done,`/`,K.total,` (`,K.pct,`%)`]})]}),(0,d.jsx)(`div`,{className:`db-progress-bar`,children:(0,d.jsx)(`div`,{className:`db-progress-fill`,style:{"--w":`${K.pct}%`}})}),(0,d.jsxs)(`div`,{className:`db-muted`,style:{fontSize:12,marginTop:6},children:[`Pending: `,(0,d.jsx)(`span`,{className:`db-strong`,children:K.pending})]})]})]}),(0,d.jsxs)(`div`,{style:{border:`1px solid rgba(201,168,76,0.28)`,background:`#fffdf8`,borderRadius:14,padding:16,display:`grid`,gap:14},children:[(0,d.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:14,flexWrap:`wrap`},children:[(0,d.jsxs)(`div`,{children:[(0,d.jsxs)(`div`,{className:`db-strong`,style:{fontSize:15,display:`flex`,alignItems:`center`,gap:8},children:[(0,d.jsx)(`i`,{className:`bi bi-file-earmark-spreadsheet`,style:{color:`#c9a84c`}}),`Upload results with Excel or CSV`]}),(0,d.jsx)(`div`,{className:`db-muted`,style:{fontSize:12.5,marginTop:4},children:`Choose the score format, download the template, fill scores, preview the file, then import.`})]}),(0,d.jsxs)(`div`,{style:{display:`flex`,gap:8,flexWrap:`wrap`},children:[(0,d.jsxs)(`select`,{value:H,onChange:e=>{U(e.target.value?Number(e.target.value):``),F(null)},style:{border:`1px solid #e5ddd3`,borderRadius:10,padding:`8px 10px`,background:`#fff`,fontSize:12,fontWeight:700,color:`#4a4a5a`,minWidth:190},"aria-label":`Select department for result upload template`,children:[(0,d.jsx)(`option`,{value:``,children:`All departments`}),O.map(e=>(0,d.jsx)(`option`,{value:e.id,children:e.name},e.id))]}),(0,d.jsxs)(`select`,{value:B,onChange:e=>{V(e.target.value),F(null)},style:{border:`1px solid #e5ddd3`,borderRadius:10,padding:`8px 10px`,background:`#fff`,fontSize:12,fontWeight:700,color:`#4a4a5a`},"aria-label":`Select result upload score format`,children:[(0,d.jsx)(`option`,{value:`ca_exam`,children:`CA + Exam`}),(0,d.jsx)(`option`,{value:`ca_ca_exam`,children:`CA 1 + CA 2 + Exam`}),(0,d.jsx)(`option`,{value:`ca_ca_ca_ca_exam`,children:`CA 1 + CA 2 + CA 3 + CA 4 + Exam`})]}),(0,d.jsxs)(`button`,{className:`db-refresh-btn`,onClick:()=>Y(`xlsx`),disabled:!g,children:[(0,d.jsx)(`i`,{className:`bi bi-download`}),`Excel template`]}),(0,d.jsxs)(`button`,{className:`db-refresh-btn`,onClick:()=>Y(`csv`),disabled:!g,children:[(0,d.jsx)(`i`,{className:`bi bi-filetype-csv`}),`CSV template`]})]})]}),(0,d.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`repeat(auto-fit, minmax(190px, 1fr))`,gap:10,alignItems:`center`},children:[(0,d.jsx)(`input`,{ref:W,type:`file`,accept:`.xlsx,.xls,.csv`,onClick:e=>{e.currentTarget.value=``},onChange:e=>{Z(e.target.files?.[0]??null)},style:{display:`none`}}),(0,d.jsxs)(`div`,{style:{gridColumn:`span 2`,border:`1px dashed rgba(201,168,76,0.7)`,borderRadius:12,background:`#fff`,padding:12,display:`flex`,alignItems:`center`,justifyContent:`space-between`,gap:12,flexWrap:`wrap`},children:[(0,d.jsxs)(`div`,{style:{minWidth:0},children:[(0,d.jsx)(`div`,{className:`db-strong`,style:{fontSize:13.5},children:M?M.name:`No file selected`}),(0,d.jsx)(`div`,{className:`db-muted`,style:{fontSize:12,marginTop:3},children:`Save and close the Excel file before previewing, then return here if Windows opens Excel.`})]}),(0,d.jsxs)(`button`,{className:`db-refresh-btn`,onClick:ne,disabled:I||R,type:`button`,children:[(0,d.jsx)(`i`,{className:`bi bi-folder2-open`}),`Choose file`]})]}),(0,d.jsxs)(`button`,{className:`db-refresh-btn`,onClick:X,disabled:!M||I,type:`button`,children:[I?(0,d.jsx)(`span`,{className:`spinner-border spinner-border-sm`,role:`status`}):(0,d.jsx)(`i`,{className:`bi bi-eye`}),`Preview`]}),(0,d.jsxs)(`button`,{className:`db-btn-gold`,onClick:re,disabled:!P?.summary?.can_import||R,type:`button`,children:[R?(0,d.jsx)(`span`,{className:`spinner-border spinner-border-sm`,role:`status`}):(0,d.jsx)(`i`,{className:`bi bi-cloud-upload-fill`}),`Import`]})]}),P&&(0,d.jsxs)(`div`,{style:{display:`grid`,gap:12},children:[(0,d.jsxs)(`div`,{style:{display:`flex`,gap:8,flexWrap:`wrap`},children:[(0,d.jsxs)(`span`,{className:`db-badge`,style:{background:`#f5f1eb`,color:`#1a1a2e`},children:[P.summary.ready_rows,` ready row(s)`]}),(0,d.jsxs)(`span`,{className:`db-badge`,style:{background:`#f5f1eb`,color:`#1a1a2e`},children:[P.summary.subjects_found,` subject(s)`]}),(0,d.jsxs)(`span`,{className:`db-badge`,style:{background:P.summary.errors_count?`rgba(239,68,68,0.1)`:`rgba(34,197,94,0.1)`,color:P.summary.errors_count?`#b91c1c`:`#15803d`},children:[P.summary.errors_count,` error(s)`]}),(0,d.jsxs)(`span`,{className:`db-badge`,style:{background:`rgba(245,158,11,0.12)`,color:`#92400e`},children:[P.summary.warnings_count,` warning(s)`]})]}),(P.errors.length>0||P.warnings.length>0)&&(0,d.jsxs)(`div`,{style:{display:`grid`,gap:8,maxHeight:180,overflow:`auto`,background:`#fff`,border:`1px solid #ede8e0`,borderRadius:12,padding:12},children:[P.errors.slice(0,8).map((e,t)=>(0,d.jsxs)(`div`,{style:{color:`#b91c1c`,fontSize:12.5,fontWeight:700},children:[(0,d.jsx)(`i`,{className:`bi bi-exclamation-circle`}),` `,e]},`err-${t}`)),P.warnings.slice(0,6).map((e,t)=>(0,d.jsxs)(`div`,{style:{color:`#92400e`,fontSize:12.5,fontWeight:700},children:[(0,d.jsx)(`i`,{className:`bi bi-info-circle`}),` `,e]},`warn-${t}`))]}),P.rows.length>0&&(0,d.jsx)(`div`,{style:{overflowX:`auto`,border:`1px solid #ede8e0`,borderRadius:12},children:(0,d.jsxs)(`table`,{className:`db-table`,children:[(0,d.jsx)(`thead`,{children:(0,d.jsxs)(`tr`,{children:[(0,d.jsx)(`th`,{children:`Row`}),(0,d.jsx)(`th`,{children:`Student`}),(0,d.jsx)(`th`,{children:`Adm No`}),(0,d.jsx)(`th`,{children:`Subjects with scores`}),(0,d.jsx)(`th`,{children:`Status`})]})}),(0,d.jsx)(`tbody`,{children:P.rows.slice(0,5).map(e=>(0,d.jsxs)(`tr`,{children:[(0,d.jsx)(`td`,{children:e.row}),(0,d.jsx)(`td`,{className:`db-strong`,children:e.student_name||`Unknown`}),(0,d.jsx)(`td`,{children:e.admission_no}),(0,d.jsx)(`td`,{children:e.subjects.length}),(0,d.jsx)(`td`,{children:(0,d.jsx)(`span`,{className:`db-pill`,style:{background:e.status===`ready`?`rgba(34,197,94,0.1)`:`rgba(245,158,11,0.12)`,color:e.status===`ready`?`#15803d`:`#92400e`},children:e.status===`ready`?`Ready`:`No scores`})})]},`${e.row}-${e.admission_no}`))})]})})]})]}),(0,d.jsx)(`div`,{style:{overflowX:`auto`},children:(0,d.jsxs)(`table`,{className:`db-table`,children:[(0,d.jsx)(`thead`,{children:(0,d.jsxs)(`tr`,{children:[(0,d.jsx)(`th`,{style:{width:60},children:`#`}),(0,d.jsx)(`th`,{children:`Student`}),(0,d.jsx)(`th`,{style:{width:180},children:`Adm No`}),(0,d.jsx)(`th`,{style:{width:140},children:`Status`}),(0,d.jsx)(`th`,{style:{width:240,textAlign:`right`},children:`Actions`})]})}),(0,d.jsx)(`tbody`,{children:S?Array.from({length:6}).map((e,t)=>(0,d.jsxs)(`tr`,{children:[(0,d.jsx)(`td`,{children:(0,d.jsx)(`div`,{className:`db-skeleton`,style:{width:24}})}),(0,d.jsx)(`td`,{children:(0,d.jsx)(`div`,{className:`db-skeleton`,style:{width:160}})}),(0,d.jsx)(`td`,{children:(0,d.jsx)(`div`,{className:`db-skeleton`,style:{width:120}})}),(0,d.jsx)(`td`,{children:(0,d.jsx)(`div`,{className:`db-skeleton`,style:{width:90}})}),(0,d.jsx)(`td`,{style:{textAlign:`right`},children:(0,d.jsx)(`div`,{className:`db-skeleton`,style:{width:180,marginLeft:`auto`}})})]},t)):E.length===0?(0,d.jsx)(`tr`,{children:(0,d.jsx)(`td`,{colSpan:5,style:{padding:28,textAlign:`center`,color:`#b5a090`},children:`No students returned for this batch.`})}):G.length===0?(0,d.jsx)(`tr`,{children:(0,d.jsxs)(`td`,{colSpan:5,style:{padding:28,textAlign:`center`,color:`#b5a090`},children:[`No matches for “`,A,`”.`]})}):G.map((e,t)=>{let n=e.status===`completed`;return(0,d.jsxs)(`tr`,{children:[(0,d.jsx)(`td`,{children:t+1}),(0,d.jsxs)(`td`,{children:[(0,d.jsxs)(`div`,{className:`db-strong`,style:{fontSize:13.5},children:[e.firstname,` `,e.surname]}),(0,d.jsxs)(`div`,{className:`db-muted`,style:{fontSize:12},children:[`ID: `,e.id,e.saved_at?` • Saved: ${e.saved_at}`:``]})]}),(0,d.jsx)(`td`,{style:{color:`#9a8a7a`,fontSize:12.5},children:e.reg_no}),(0,d.jsx)(`td`,{children:(0,d.jsxs)(`span`,{className:`db-badge`,style:{background:n?`rgba(34,197,94,0.12)`:`rgba(245,158,11,0.12)`,color:n?`#16a34a`:`#92400e`},children:[(0,d.jsx)(`span`,{style:{width:7,height:7,borderRadius:999,background:n?`#22c55e`:`#f59e0b`}}),n?`Completed`:`Pending`]})}),(0,d.jsx)(`td`,{style:{textAlign:`right`},children:(0,d.jsxs)(`div`,{style:{display:`inline-flex`,gap:8,flexWrap:`wrap`,justifyContent:`flex-end`},children:[(0,d.jsxs)(`button`,{className:`db-refresh-btn`,style:{background:n?`rgba(59,130,246,0.08)`:`rgba(201,168,76,0.14)`,borderColor:`rgba(0,0,0,0.06)`,color:`#1a1a2e`},onClick:()=>q(e.id),children:[(0,d.jsx)(`i`,{className:`bi ${n?`bi-pencil-square`:`bi-plus-circle`}`}),n?`Edit`:`Enter`]}),n?(0,d.jsxs)(`button`,{className:`db-refresh-btn`,style:{background:`rgba(34,197,94,0.12)`,borderColor:`rgba(0,0,0,0.06)`,color:`#14532d`},onClick:()=>ie(e.id),title:`View Result Sheet`,children:[(0,d.jsx)(`i`,{className:`bi bi-file-earmark-text-fill`}),`View`]}):null]})})]},e.id)})})]})})]})]}),(0,d.jsxs)(`div`,{className:`db-panel`,style:{alignSelf:`start`},children:[(0,d.jsxs)(`div`,{className:`db-panel-head`,children:[(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`p`,{className:`db-panel-title`,children:`Batch actions`}),(0,d.jsx)(`p`,{className:`db-panel-sub`,children:`Compute + navigation shortcuts`})]}),(0,d.jsxs)(`button`,{className:`db-refresh-btn`,onClick:()=>t(`/students/results/batch`),disabled:S,children:[(0,d.jsx)(`i`,{className:`bi bi-arrow-left-circle`}),`Change`]})]}),(0,d.jsxs)(`div`,{style:{padding:16,display:`grid`,gap:12},children:[(0,d.jsxs)(`div`,{style:{display:`grid`,gap:10},children:[(0,d.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`},children:[(0,d.jsx)(`span`,{className:`db-muted`,children:`Batch`}),(0,d.jsxs)(`span`,{className:`db-strong`,children:[`#`,w.id]})]}),(0,d.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`},children:[(0,d.jsx)(`span`,{className:`db-muted`,children:`Term`}),(0,d.jsx)(`span`,{className:`db-strong`,children:w.term})]}),(0,d.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`},children:[(0,d.jsx)(`span`,{className:`db-muted`,children:`Session`}),(0,d.jsx)(`span`,{className:`db-strong`,children:w.session})]}),(0,d.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`},children:[(0,d.jsx)(`span`,{className:`db-muted`,children:`Status`}),(0,d.jsx)(`span`,{className:`db-pill`,style:{background:$.bg,color:$.fg},children:$.text})]})]}),(0,d.jsx)(`div`,{style:{height:1,background:`rgba(0,0,0,0.06)`}}),(0,d.jsxs)(`div`,{style:{display:`grid`,gap:10},children:[(0,d.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`},children:[(0,d.jsx)(`span`,{className:`db-muted`,children:`Completed`}),(0,d.jsx)(`span`,{className:`db-pill`,style:{background:`rgba(34,197,94,0.12)`,color:`#16a34a`},children:K.done})]}),(0,d.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`},children:[(0,d.jsx)(`span`,{className:`db-muted`,children:`Pending`}),(0,d.jsx)(`span`,{className:`db-pill`,style:{background:`rgba(245,158,11,0.12)`,color:`#92400e`},children:K.pending})]}),(0,d.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`},children:[(0,d.jsx)(`span`,{className:`db-muted`,children:`Total`}),(0,d.jsx)(`span`,{className:`db-pill`,style:{background:`rgba(59,130,246,0.12)`,color:`#1e40af`},children:K.total})]})]}),(0,d.jsxs)(`div`,{children:[(0,d.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,fontSize:12,marginBottom:6},children:[(0,d.jsx)(`span`,{className:`db-muted`,children:`Progress`}),(0,d.jsxs)(`span`,{className:`db-strong`,children:[K.pct,`%`]})]}),(0,d.jsx)(`div`,{className:`db-progress-bar`,children:(0,d.jsx)(`div`,{className:`db-progress-fill`,style:{"--w":`${K.pct}%`}})})]}),(0,d.jsxs)(`div`,{style:{borderRadius:14,border:`1px solid rgba(245,158,11,0.25)`,background:`rgba(245,158,11,0.10)`,padding:12,color:`#92400e`,display:`flex`,gap:10,alignItems:`flex-start`},children:[(0,d.jsx)(`i`,{className:`bi bi-exclamation-triangle-fill`}),(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`div`,{style:{fontWeight:900,marginBottom:2},children:`Reminder`}),(0,d.jsx)(`div`,{style:{opacity:.85,fontSize:12.5,lineHeight:1.55},children:`Compute once after all students are entered to generate averages & positions.`})]})]}),(0,d.jsxs)(`div`,{style:{display:`grid`,gap:10},children:[(0,d.jsxs)(`button`,{className:`db-btn-gold`,onClick:Q,disabled:!g,children:[(0,d.jsx)(`i`,{className:`bi bi-calculator-fill`}),`Compute batch`]}),(0,d.jsxs)(`button`,{className:`db-refresh-btn`,onClick:()=>t(`/results/broadsheet/${w.id}`),disabled:!g,children:[(0,d.jsx)(`i`,{className:`bi bi-table`}),`Open broadsheet`]}),(0,d.jsxs)(`button`,{className:`db-refresh-btn`,onClick:()=>t(`/students/results/batch`),children:[(0,d.jsx)(`i`,{className:`bi bi-arrow-left-circle`}),`Change batch`]})]})]})]})]}):(0,d.jsxs)(`div`,{className:`db-panel`,children:[(0,d.jsxs)(`div`,{className:`db-panel-head`,children:[(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`p`,{className:`db-panel-title`,children:`Batch not found`}),(0,d.jsx)(`p`,{className:`db-panel-sub`,children:`You may not have access, or the batch does not exist.`})]}),(0,d.jsxs)(`button`,{className:`db-refresh-btn`,onClick:()=>t(`/students/results/batch`),children:[(0,d.jsx)(`i`,{className:`bi bi-arrow-left-circle`}),`Back to Batch Setup`]})]}),(0,d.jsxs)(`div`,{style:{padding:16},children:[(0,d.jsx)(`div`,{style:{color:`#b91c1c`,fontWeight:800},children:`Batch not found or you don’t have access.`}),(0,d.jsx)(`div`,{className:`db-muted`,style:{marginTop:6},children:`Go back to Batch Setup and resolve a new batch.`})]})]}),(0,d.jsx)(`div`,{className:`mt-auto`,children:(0,d.jsx)(l,{})})]})]})})]})}export{m as default};