import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{b as t,p as n,x as r}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as i,E as a,P as o,d as s,f as ee,l as c,u as te}from"./index-D6TxbaCx.js";var l=e(),u=n();function d(e){try{return new Intl.NumberFormat(`en-NG`,{style:`currency`,currency:`NGN`}).format(e)}catch{return`₦${Number(e||0).toLocaleString()}`}}function f(e){if(!e)return`—`;let t=new Date(e);return Number.isNaN(t.getTime())?e:t.toLocaleDateString(`en-GB`,{day:`2-digit`,month:`short`,year:`numeric`})}function p(e){let t=(e||``).toLowerCase();return t?t.includes(`active`)?{bg:`rgba(34,197,94,0.16)`,fg:`#22c55e`,text:`ACTIVE`}:t.includes(`pending`)?{bg:`rgba(245,158,11,0.16)`,fg:`#fbbf24`,text:`PENDING`}:t.includes(`expired`)||t.includes(`inactive`)?{bg:`rgba(148,163,184,0.14)`,fg:`#94a3b8`,text:`INACTIVE`}:{bg:`rgba(0,0,0,0.04)`,fg:`#7a6a5a`,text:e||`UNKNOWN`}:{bg:`rgba(245,158,11,0.16)`,fg:`#fbbf24`,text:`NO SUBSCRIPTION`}}function m(e){let t=(e||``).toLowerCase();return t?t===`wallet`?`Wallet`:t===`paystack`?`Card / Online`:t===`card`?`Card`:e||`—`:`—`}function h(){let{showSuccess:e,showError:n}=c(),h=r(),g=t(),[_,ne]=(0,l.useState)(!1),[v,y]=(0,l.useState)(!0),[b,x]=(0,l.useState)(!1),[S,re]=(0,l.useState)([]),[C,w]=(0,l.useState)(``),[T,E]=(0,l.useState)(``),[D,ie]=(0,l.useState)(null),[O,k]=(0,l.useState)(`card`),[A,j]=(0,l.useState)(!1),[M,N]=(0,l.useState)(!1),P=(0,l.useMemo)(()=>{let e=Number(C);return S.find(t=>t.id===e)||null},[S,C]),F=!!P&&P.duration_in_days>0&&P.duration_in_days<365,I=(0,l.useMemo)(()=>!P||!P.duration_in_days?1:Math.max(1,Math.floor(365/P.duration_in_days)),[P]),L=M&&F?I:1,R=(0,l.useMemo)(()=>P?Number(P.current_amount??P.price??0)*L:0,[P,L]),z=(0,l.useMemo)(()=>!M||!F?0:R*.1,[R,M,F]),B=(0,l.useMemo)(()=>R-z,[R,z]),V=Number(P?.upgrade_credit_amount||0),H=(0,l.useMemo)(()=>Math.max(0,B-V),[B,V]),U=P?.promo,W=!!U?.enabled&&!!U?.is_target_plan&&(M||(P?.duration_in_days||0)>=300),G=W&&!!U?.has_min_students,K=G?Number(U?.bonus_days)||365:0,q=(0,l.useMemo)(()=>P?P.duration_in_days*L+Number(P.carried_days||0)+K:0,[P,L,K]),J=(0,l.useMemo)(()=>{if(!q)return null;let e=new Date;return e.setDate(e.getDate()+q),e},[q]),Y=(0,l.useMemo)(()=>{let e=new URLSearchParams(g.search);return e.get(`reference`)||e.get(`trxref`)},[g.search]),X=(0,l.useMemo)(()=>new URLSearchParams(g.search).get(`plan`),[g.search]),Z=(0,l.useMemo)(()=>p(D?.status),[D?.status]);(0,l.useEffect)(()=>{(async()=>{y(!0);let[e,t,n]=await Promise.allSettled([o.get(`/subscription/user`),o.get(`/user/subscription/details`),o.get(`/subscription/plans`)]),r=e.status===`fulfilled`?e.value:null,i=t.status===`fulfilled`?t.value:null,a=n.status===`fulfilled`?n.value:null,s=(Array.isArray(a?.data)?a.data:[]).filter(e=>e.is_active===void 0||e.is_active===!0||Number(e.is_active)===1);re(s);try{if(E(r?.data?.email||``),i?.data&&(ie(i.data),(i.data?.auto_renew_source||``).toLowerCase()===`wallet`?(k(`wallet`),j(!!i.data?.auto_renew)):(k(`card`),j(!1))),X&&s.length){let e=X.toLowerCase().replace(/[^a-z0-9]+/g,``),t=s.find(t=>t.name.toLowerCase().replace(/[^a-z0-9]+/g,``)===e);if(t?.can_select!==!1){w(String(t.id));return}}let e=i?.data?.subscription_type;if(e&&s.length){let t=s.find(t=>t.name===e);if(t?.can_select!==!1){w(String(t.id));return}}let t=s.find(e=>e.can_select!==!1&&!e.limit_exceeded);t&&w(String(t.id))}catch(e){console.error(e)}finally{y(!1)}})()},[]),(0,l.useEffect)(()=>{Y&&(x(!0),o.get(`/subscription/verify/${Y}`).then(()=>{e?.(`Payment verified successfully.`),h(`/billing`,{replace:!0})}).catch(e=>{console.error(e),n?.(e?.response?.data?.message||`Verification failed.`)}).finally(()=>{x(!1)}))},[Y]),(0,l.useEffect)(()=>{O===`card`&&A&&j(!1)},[O,A]),(0,l.useEffect)(()=>{N(!1)},[C]);let Q=async e=>{try{await o.post(`/subscription/renewal-source`,{source:e})}catch(e){throw console.error(e),Error(e?.response?.data?.message||`Failed to update renewal source.`)}},$=async()=>{if(!P){n?.(`Please select a plan.`);return}if(!T){n?.(`User email not found.`);return}if(P.can_select===!1){n?.(P.disabled_reason||`This package cannot be selected while your current subscription is active.`);return}x(!0);try{if(O===`wallet`){await Q(`wallet`);let t=await o.post(`/payment/wallet-charge`,{subscription_plan_id:P.id,cycles:L,auto_renew:A,auto_renew_source:`wallet`});if(t.data?.success||t.data?.status===`success`){e?.(t.data?.message||`Subscription successful via wallet.`),h(`/billing`,{replace:!0});return}n?.(t.data?.message||`Wallet charge failed.`);return}await Q(`paystack`);let t=(await o.post(`/subscription/initialize`,{plan_id:P.id,cycles:L,email:T})).data?.authorization_url;if(!t){n?.(`Paystack authorization URL not returned.`);return}window.location.href=t}catch(e){console.error(e),n?.(e?.response?.data?.message||e?.message||`Checkout failed.`)}finally{x(!1)}};return(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`style`,{children:`
        .db-main {
          background: var(--bs-body-bg, #f5f1eb);
          min-height: 100vh;
          font-family: "DM Sans", system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
          padding: 28px 28px 0;
        }

        .db-hero {
          background: #0f172a;
          border-radius: var(--bs-border-radius-lg, 16px);
          padding: 32px 36px;
          position: relative;
          overflow: hidden;
          margin: 10px 0 18px;
          border: 1px solid rgba(255,255,255,0.06);
        }
        .db-hero::before {
          content: "";
          position: absolute;
          inset: 0;
          background-image: radial-gradient(circle, rgba(255,255,255,0.045) 1px, transparent 1px);
          background-size: 24px 24px;
          pointer-events: none;
        }
        .db-hero-glow {
          position: absolute;
          top: -60px;
          right: -60px;
          width: 320px;
          height: 320px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(201,168,76,0.10) 0%, transparent 65%);
          pointer-events: none;
        }
        .db-hero-glow2 {
          position: absolute;
          bottom: -40px;
          left: 25%;
          width: 220px;
          height: 220px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(99,102,241,0.07) 0%, transparent 70%);
          pointer-events: none;
        }
        .db-hero-inner {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 32px;
          flex-wrap: wrap;
        }
        @media (min-width: 768px) {
          .db-hero-inner {
            flex-wrap: nowrap;
          }
        }

        .db-session-badge {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          font-size: 11px;
          font-weight: 500;
          letter-spacing: 0.12em;
          text-transform: uppercase;
          color: #e8c97a;
          background: rgba(201,168,76,0.10);
          border: 1px solid rgba(201,168,76,0.22);
          border-radius: 100px;
          padding: 4px 12px;
          margin-bottom: 14px;
        }
        .db-session-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #22c55e;
          animation: dbPulse 2s ease infinite;
        }
        @keyframes dbPulse {
          0%,100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.4; transform: scale(1.5); }
        }

        .db-greeting {
          font-family: "Lora", Georgia, serif;
          font-size: clamp(22px, 2.5vw, 32px);
          font-weight: 700;
          color: #fff;
          line-height: 1.1;
          margin-bottom: 8px;
        }
        .db-greeting em {
          font-style: italic;
          color: #e8c97a;
        }

        .db-hero-sub {
          font-size: 13.5px;
          font-weight: 300;
          color: #94a3b8;
          line-height: 1.65;
          max-width: 560px;
          margin-bottom: 18px;
        }

        .db-hero-btns {
          display: flex;
          gap: 10px;
          flex-wrap: wrap;
        }

        .db-btn-gold {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 10px 20px;
          font-family: "DM Sans", sans-serif;
          font-size: 13px;
          font-weight: 600;
          color: #0f172a;
          background: #c9a84c;
          border: none;
          border-radius: var(--bs-border-radius, 8px);
          cursor: pointer;
          transition: background 0.2s, transform 0.2s;
          white-space: nowrap;
        }
        .db-btn-gold:hover {
          background: #e8c97a;
          transform: translateY(-1px);
        }
        .db-btn-gold:disabled {
          opacity: 0.55;
          cursor: not-allowed;
          transform: none;
        }

        .db-btn-outline {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 10px 20px;
          font-family: "DM Sans", sans-serif;
          font-size: 13px;
          font-weight: 400;
          color: rgba(255,255,255,0.7);
          background: transparent;
          border: 1px solid rgba(255,255,255,0.14);
          border-radius: var(--bs-border-radius, 8px);
          cursor: pointer;
          transition: background 0.2s, border-color 0.2s, color 0.2s;
          white-space: nowrap;
        }
        .db-btn-outline:hover {
          background: rgba(255,255,255,0.06);
          color: #fff;
          border-color: rgba(255,255,255,0.28);
        }
        .db-btn-outline:disabled {
          opacity: 0.55;
          cursor: not-allowed;
        }

        .db-hero-stat-card {
          background: rgba(255,255,255,0.05);
          border: 1px solid rgba(255,255,255,0.09);
          backdrop-filter: blur(8px);
          border-radius: var(--bs-border-radius, 12px);
          padding: 20px 24px;
          min-width: 270px;
          margin-left: auto;
          align-self: flex-end;
        }
        .db-hero-stat-row {
          display: flex;
          flex-direction: column;
          gap: 10px;
        }
        .db-hero-stat-item {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 16px;
        }
        .db-hero-stat-label {
          font-size: 12px;
          font-weight: 300;
          color: #94a3b8;
        }
        .db-hero-stat-val {
          font-family: "Lora", serif;
          font-size: 18px;
          font-weight: 700;
          color: #fff;
        }
        .db-hero-stat-sep {
          height: 1px;
          background: rgba(255,255,255,0.06);
        }

        .db-panel {
          background: var(--bs-body-bg, #fff);
          border: 1px solid var(--bs-border-color, #ede8e0);
          border-radius: var(--bs-border-radius-lg, 14px);
          overflow: hidden;
          box-shadow: 0 2px 10px rgba(15,23,42,0.04);
          margin-bottom: 18px;
        }

        .db-panel-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 18px 18px;
          border-bottom: 1px solid rgba(0,0,0,0.06);
          gap: 12px;
          flex-wrap: wrap;
        }

        .db-panel-title {
          font-family: "Lora", serif;
          font-size: 16px;
          font-weight: 700;
          color: #1a1a2e;
          margin: 0;
        }

        .db-panel-sub {
          font-size: 11.5px;
          font-weight: 300;
          color: #9a8a7a;
          margin: 0;
        }

        .db-pill {
          display: inline-flex;
          align-items: center;
          font-size: 12px;
          font-weight: 800;
          padding: 6px 10px;
          border-radius: 999px;
          white-space: nowrap;
          border: 1px solid rgba(0,0,0,0.06);
        }

        .db-muted {
          color: #9a8a7a;
        }

        .db-strong {
          font-weight: 900;
          color: #1a1a2e;
        }

        .db-tile {
          background: #faf8f5;
          border: 1px solid rgba(0,0,0,0.06);
          border-radius: 14px;
          padding: 14px;
          height: 100%;
        }

        .db-radio {
          background: #fff;
          border: 1px solid #e5ddd3;
          border-radius: 12px;
          padding: 12px;
          cursor: pointer;
          transition: transform 0.15s ease, border-color 0.15s ease, background 0.15s ease;
          height: 100%;
        }
        .db-radio:hover {
          transform: translateY(-1px);
        }
        .db-radio.active {
          border-color: rgba(201,168,76,0.55);
          box-shadow: 0 10px 22px rgba(201,168,76,0.18);
          background: rgba(201,168,76,0.06);
        }

        .db-method-btn {
          width: 100%;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          padding: 10px 12px;
          border-radius: 12px;
          border: 1px solid #e5ddd3;
          background: #fff;
          color: #1a1a2e;
          font-weight: 600;
          transition: all 0.18s ease;
          cursor: pointer;
        }
        .db-method-btn:hover {
          transform: translateY(-1px);
        }
        .db-method-btn.active {
          background: rgba(201,168,76,0.14);
          border-color: rgba(201,168,76,0.35);
          color: #6b4f00;
          box-shadow: 0 8px 18px rgba(201,168,76,0.12);
        }
        .db-method-btn:disabled {
          opacity: 0.6;
          cursor: not-allowed;
        }

        .db-pay-btn {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          width: 100%;
          padding: 12px 14px;
          border-radius: 12px;
          font-weight: 900;
        }

        .db-note {
          padding: 12px 14px;
          border-radius: 12px;
          border: 1px solid rgba(59,130,246,0.16);
          background: rgba(59,130,246,0.06);
          color: #334155;
          font-size: 12.5px;
          line-height: 1.6;
        }

        @media (max-width: 991.98px) {
          .db-main {
            padding: 18px 14px 0;
          }
        }
      `}),(0,u.jsx)(ee,{sidebarOpen:_,setSidebarOpen:ne}),(0,u.jsx)(i,{title:`Checkout`}),(0,u.jsx)(`div`,{className:`container-fluid`,children:(0,u.jsxs)(`div`,{className:`row`,children:[(0,u.jsx)(s,{sidebarOpen:_}),(0,u.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto db-main`,children:[v&&(0,u.jsx)(a,{message:`Loading checkout...`}),(0,u.jsxs)(`div`,{className:`db-hero`,children:[(0,u.jsx)(`div`,{className:`db-hero-glow`,"aria-hidden":`true`}),(0,u.jsx)(`div`,{className:`db-hero-glow2`,"aria-hidden":`true`}),(0,u.jsxs)(`div`,{className:`db-hero-inner`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsxs)(`div`,{className:`db-session-badge`,children:[(0,u.jsx)(`span`,{className:`db-session-dot`}),`Subscriptions — Checkout`]}),(0,u.jsxs)(`h1`,{className:`db-greeting`,children:[`Renew `,(0,u.jsx)(`em`,{children:`Subscription`})]}),(0,u.jsx)(`p`,{className:`db-hero-sub`,children:`Choose a plan and complete checkout securely. Online card and transfer payments are processed through our 256-bit encrypted gateway, while wallet payments can optionally auto-renew.`}),(0,u.jsxs)(`div`,{className:`db-hero-btns`,children:[(0,u.jsx)(`button`,{className:`db-btn-gold`,onClick:$,disabled:b||v,children:b?(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`span`,{className:`spinner-border spinner-border-sm`}),`Processing…`]}):(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`i`,{className:`bi bi-lock-fill`}),`Make Payment`]})}),(0,u.jsxs)(`button`,{className:`db-btn-outline`,onClick:()=>h(`/subscriptions/billing`),disabled:b,children:[(0,u.jsx)(`i`,{className:`bi bi-receipt-cutoff`}),`Billing`]}),(0,u.jsxs)(`button`,{className:`db-btn-outline`,onClick:()=>h(`/billing`),disabled:b,children:[(0,u.jsx)(`i`,{className:`bi bi-arrow-left`}),`Back`]})]})]}),(0,u.jsxs)(`div`,{className:`db-hero-stat-card d-none d-md-block`,children:[(0,u.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,marginBottom:16},children:[(0,u.jsx)(`span`,{style:{fontSize:11,fontWeight:500,letterSpacing:`0.14em`,textTransform:`uppercase`,color:`#c9a84c`},children:`Current subscription`}),(0,u.jsx)(`i`,{className:`bi bi-shield-check`,style:{color:`#64748b`}})]}),(0,u.jsxs)(`div`,{className:`db-hero-stat-row`,children:[(0,u.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,u.jsx)(`span`,{className:`db-hero-stat-label`,children:`Plan`}),(0,u.jsx)(`span`,{className:`db-hero-stat-val`,style:{fontSize:14,fontFamily:`DM Sans`},children:D?.subscription_type||`—`})]}),(0,u.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,u.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,u.jsx)(`span`,{className:`db-hero-stat-label`,children:`Status`}),(0,u.jsx)(`span`,{className:`db-pill`,style:{background:Z.bg,color:Z.fg},children:Z.text})]}),(0,u.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,u.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,u.jsx)(`span`,{className:`db-hero-stat-label`,children:`Ends`}),(0,u.jsx)(`span`,{className:`db-hero-stat-val`,style:{fontSize:14,fontFamily:`DM Sans`},children:f(D?.end_date)})]})]})]})]})]}),(0,u.jsxs)(`div`,{className:`row g-3`,children:[(0,u.jsx)(`div`,{className:`col-12 col-lg-7`,children:(0,u.jsxs)(`div`,{className:`db-panel`,children:[(0,u.jsxs)(`div`,{className:`db-panel-head`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`p`,{className:`db-panel-title`,children:`Select plan`}),(0,u.jsx)(`p`,{className:`db-panel-sub`,children:`Pick a plan and proceed to payment.`})]}),(0,u.jsx)(`span`,{className:`db-pill`,style:{background:`rgba(0,0,0,0.04)`,color:`#7a6a5a`},children:S.length?`${S.length} plans`:`No plans`})]}),(0,u.jsx)(`div`,{style:{padding:16},children:(0,u.jsxs)(`div`,{className:`row g-3`,children:[S.map(e=>{let t=String(e.id)===C,n=e.can_select===!1||!!e.limit_exceeded;return(0,u.jsx)(`div`,{className:`col-12 col-md-6`,children:(0,u.jsxs)(`div`,{className:`db-radio ${t?`active`:``}`,role:`button`,onClick:()=>!n&&w(String(e.id)),"aria-pressed":t,"aria-disabled":n,title:n?e.disabled_reason||`This plan cannot support the school's current students.`:``,style:{userSelect:`none`,opacity:n?.55:1,cursor:n?`not-allowed`:`pointer`,filter:n?`grayscale(0.35)`:`none`},children:[(0,u.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,alignItems:`flex-start`,gap:10},children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`db-strong`,style:{fontWeight:800},children:e.name}),(0,u.jsxs)(`div`,{className:`db-muted`,style:{fontSize:12,marginTop:2},children:[e.duration_in_days,` days access`]}),e.promo?.enabled&&e.promo?.is_target_plan&&(0,u.jsxs)(`span`,{className:`db-pill mt-1 d-inline-block`,style:{background:`rgba(245,158,11,0.15)`,color:`#b45309`,border:`1px solid rgba(245,158,11,0.3)`,fontSize:10},children:[(0,u.jsx)(`i`,{className:`bi bi-gift-fill me-1`}),` 2-for-1 Promo`]})]}),n?(0,u.jsxs)(`span`,{className:`db-pill`,style:{background:`rgba(239,68,68,0.10)`,color:`#dc2626`},children:[(0,u.jsx)(`i`,{className:`bi bi-lock-fill me-1`}),` Unavailable`]}):t?(0,u.jsx)(`span`,{className:`db-pill`,style:{background:`rgba(201,168,76,0.16)`,color:`#c9a84c`},children:`Selected`}):(0,u.jsx)(`span`,{className:`db-pill`,style:{background:`rgba(0,0,0,0.04)`,color:`#7a6a5a`},children:`Choose`})]}),(0,u.jsxs)(`div`,{style:{marginTop:12,display:`flex`,alignItems:`baseline`,gap:8},children:[(0,u.jsx)(`div`,{style:{fontFamily:`Lora, serif`,fontSize:22,fontWeight:900,color:`#1a1a2e`},children:d(Number(e.price_per_student??e.price??0))}),(0,u.jsxs)(`div`,{className:`db-muted`,style:{fontSize:12},children:[`per student / `,e.billing_interval||`${e.duration_in_days} days`]})]}),(0,u.jsxs)(`div`,{className:`db-muted`,style:{fontSize:12,marginTop:4},children:[Number(e.billable_students??e.active_students??0).toLocaleString(),` billable students = `,d(Number(e.current_amount??0))]}),n&&(0,u.jsx)(`div`,{style:{marginTop:10,padding:`9px 10px`,borderRadius:9,background:`rgba(239,68,68,0.07)`,color:`#b91c1c`,fontSize:11.5},children:e.disabled_reason||`Your active student count exceeds this package limit.`}),!n&&e.subscription_action===`upgrade`&&(0,u.jsxs)(`div`,{style:{marginTop:10,padding:`9px 10px`,borderRadius:9,background:`rgba(34,197,94,0.08)`,color:`#166534`,fontSize:11.5},children:[`Upgrade available: `,Number(e.carried_days||0),` remaining days and `,d(Number(e.upgrade_credit_amount||0)),` unused value will be carried forward.`]}),(0,u.jsxs)(`div`,{style:{marginTop:12,paddingTop:10,borderTop:`1px solid rgba(0,0,0,0.06)`,display:`flex`,alignItems:`center`,justifyContent:`space-between`,flexWrap:`wrap`,gap:6},children:[(0,u.jsxs)(`span`,{className:`db-muted`,style:{fontSize:12},children:[(0,u.jsx)(`i`,{className:`bi bi-shield-lock-fill me-1`}),`Secure renewal`]}),Number(e.max_students??0)>0?(0,u.jsxs)(`span`,{className:`db-pill`,style:{background:e.limit_exceeded?`rgba(239,68,68,0.12)`:`rgba(15,23,42,0.05)`,color:e.limit_exceeded?`#dc2626`:`#1a1a2e`},children:[(0,u.jsx)(`i`,{className:`bi bi-people-fill me-1`}),`Up to `,e.max_students.toLocaleString(),` students`]}):(0,u.jsxs)(`span`,{className:`db-pill`,style:{background:`rgba(15,23,42,0.05)`,color:`#1a1a2e`},children:[(0,u.jsx)(`i`,{className:`bi bi-infinity me-1`}),`Unlimited students`]})]})]})},e.id)}),!S.length&&!v&&(0,u.jsx)(`div`,{className:`col-12`,children:(0,u.jsxs)(`div`,{style:{padding:18,borderRadius:14,background:`#faf8f5`,border:`1px solid rgba(0,0,0,0.06)`},children:[(0,u.jsx)(`div`,{className:`db-strong`,children:`No plans available`}),(0,u.jsx)(`div`,{className:`db-muted`,style:{fontSize:12.5,marginTop:4},children:`There are currently no active subscription plans. Please check again later or contact SchoolProfit Support.`})]})})]})})]})}),(0,u.jsx)(`div`,{className:`col-12 col-lg-5`,children:(0,u.jsxs)(`div`,{className:`db-panel`,children:[(0,u.jsxs)(`div`,{className:`db-panel-head`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`p`,{className:`db-panel-title`,children:`Checkout summary`}),(0,u.jsx)(`p`,{className:`db-panel-sub`,children:`Review and pay securely.`})]}),(0,u.jsx)(`span`,{className:`db-pill`,style:{background:Z.bg,color:Z.fg},children:Z.text})]}),(0,u.jsxs)(`div`,{style:{padding:16},children:[(0,u.jsxs)(`div`,{className:`db-tile`,children:[(0,u.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:10},children:[(0,u.jsx)(`span`,{className:`db-muted`,style:{fontSize:12},children:`Email`}),(0,u.jsx)(`span`,{className:`db-strong`,style:{fontWeight:800},children:T||`—`})]}),(0,u.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:10,marginTop:10},children:[(0,u.jsx)(`span`,{className:`db-muted`,style:{fontSize:12},children:`Plan`}),(0,u.jsx)(`span`,{className:`db-strong`,style:{fontWeight:800},children:P?.name||`Select a plan`})]}),(0,u.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:10,marginTop:10},children:[(0,u.jsx)(`span`,{className:`db-muted`,style:{fontSize:12},children:`Duration`}),(0,u.jsx)(`span`,{className:`db-strong`,style:{fontWeight:800},children:P?`${q} days${K>0?` (${P.duration_in_days*L} paid + ${K} Promo Bonus Free)`:Number(P.carried_days||0)>0?` (${P.duration_in_days*L} new + ${P.carried_days} carried)`:M&&F?` (${L} cycles)`:``}`:`—`})]}),(0,u.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:10,marginTop:10},children:[(0,u.jsx)(`span`,{className:`db-muted`,style:{fontSize:12},children:`Max students`}),(0,u.jsx)(`span`,{className:`db-strong`,style:{fontWeight:800},children:P?.max_students?P.max_students.toLocaleString():`—`})]}),(0,u.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:10,marginTop:10},children:[(0,u.jsx)(`span`,{className:`db-muted`,style:{fontSize:12},children:`Billable students`}),(0,u.jsx)(`span`,{className:`db-strong`,style:{fontWeight:800},children:Number(P?.billable_students??P?.active_students??0).toLocaleString()})]}),(0,u.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:10,marginTop:10},children:[(0,u.jsx)(`span`,{className:`db-muted`,style:{fontSize:12},children:`Price per student`}),(0,u.jsx)(`span`,{className:`db-strong`,style:{fontWeight:800},children:P?d(Number(P.price_per_student??P.price??0)):`—`})]}),(0,u.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:10,marginTop:10},children:[(0,u.jsx)(`span`,{className:`db-muted`,style:{fontSize:12},children:`Expires on`}),(0,u.jsx)(`span`,{className:`db-strong`,style:{fontWeight:800},children:J?f(J.toISOString()):`—`})]}),(0,u.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:10,marginTop:10,paddingTop:10,borderTop:`1px solid rgba(0,0,0,0.06)`},children:[(0,u.jsx)(`span`,{className:`db-muted`,style:{fontSize:12},children:`Amount`}),(0,u.jsxs)(`span`,{style:{textAlign:`right`},children:[(z>0||V>0)&&(0,u.jsx)(`div`,{className:`db-muted`,style:{fontSize:11.5,textDecoration:`line-through`},children:d(B)}),(0,u.jsx)(`span`,{className:`db-strong`,style:{fontFamily:`Lora, serif`,fontSize:18},children:P?d(H):`—`})]})]}),z>0&&(0,u.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:10,marginTop:6},children:[(0,u.jsx)(`span`,{className:`db-muted`,style:{fontSize:12},children:`Yearly discount (10%)`}),(0,u.jsxs)(`span`,{style:{fontWeight:800,color:`#16a34a`,fontSize:12.5},children:[`− `,d(z)]})]}),V>0&&(0,u.jsxs)(u.Fragment,{children:[(0,u.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:10,marginTop:6},children:[(0,u.jsx)(`span`,{className:`db-muted`,style:{fontSize:12},children:`Unused current-plan value`}),(0,u.jsxs)(`span`,{style:{fontWeight:800,color:`#16a34a`,fontSize:12.5},children:[`− `,d(V)]})]}),(0,u.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:10,marginTop:6},children:[(0,u.jsx)(`span`,{className:`db-muted`,style:{fontSize:12},children:`Remaining days carried forward`}),(0,u.jsxs)(`span`,{className:`db-strong`,style:{fontSize:12.5},children:[`+ `,Number(P?.carried_days||0),` days`]})]}),(0,u.jsxs)(`div`,{className:`db-note`,style:{marginTop:10},children:[`Current package used: `,Number(D?.days_used||0),` days (`,d(Number(P?.used_value_amount??D?.used_value??0)),`). Remaining: `,Number(D?.days_remaining||0),` days (`,d(V),`). You pay the higher package price minus the unused value; your remaining days are added to its duration.`]})]}),G&&(0,u.jsxs)(`div`,{style:{marginTop:12,padding:`12px 14px`,borderRadius:12,background:`linear-gradient(135deg, rgba(255,200,87,0.18) 0%, rgba(245,158,11,0.08) 100%)`,border:`1px solid rgba(245,158,11,0.3)`},children:[(0,u.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:8,color:`#92400e`,fontWeight:800,fontSize:13},children:[(0,u.jsx)(`i`,{className:`bi bi-gift-fill`}),` `,U?.title||`🎉 2-for-1 Launch Promo Applied!`]}),(0,u.jsxs)(`div`,{style:{fontSize:12,color:`#78350f`,marginTop:4,lineHeight:1.5},children:[`You are paying for 1 Year and receiving `,(0,u.jsxs)(`strong`,{children:[`+`,K,` Bonus Days FREE`]}),` (2 Full Years Total Access).`]}),(0,u.jsxs)(`div`,{style:{fontSize:11.5,color:`#16a34a`,marginTop:6,fontWeight:700,display:`flex`,alignItems:`center`,gap:5},children:[(0,u.jsx)(`i`,{className:`bi bi-shield-check`}),` ₦0 Platform Software Fee on School Fees for 2 Full Years`]})]}),W&&!G&&(0,u.jsxs)(`div`,{style:{marginTop:12,padding:`12px 14px`,borderRadius:12,background:`rgba(99,102,241,0.06)`,border:`1px solid rgba(99,102,241,0.2)`},children:[(0,u.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:8,color:`#4338ca`,fontWeight:800,fontSize:12.5},children:[(0,u.jsx)(`i`,{className:`bi bi-stars`}),` `,U?.title||`Buy 1 Year, Get +1 Year Free Promo`]}),(0,u.jsxs)(`div`,{style:{fontSize:12,color:`#3730a3`,marginTop:4,lineHeight:1.5},children:[`This promo requires at least `,(0,u.jsxs)(`strong`,{children:[U?.min_students,` active students`]}),`. Your school currently has `,(0,u.jsxs)(`strong`,{children:[U?.current_students||0,` active students`]}),`. Enroll `,Math.max(1,(U?.min_students||100)-(U?.current_students||0)),` more students to unlock 1 Year Free!`]})]})]}),P&&F&&(0,u.jsxs)(`div`,{style:{marginTop:12,padding:14,borderRadius:14,border:`1px solid rgba(0,0,0,0.06)`,background:`#fff`},children:[(0,u.jsxs)(`div`,{className:`form-check form-switch`,style:{marginBottom:0},children:[(0,u.jsx)(`input`,{className:`form-check-input`,type:`checkbox`,checked:M,onChange:e=>N(e.target.checked),id:`yearlyBillingSwitch`,disabled:b}),(0,u.jsxs)(`label`,{className:`form-check-label fw-semibold`,htmlFor:`yearlyBillingSwitch`,children:[`Pay for a full year `,(0,u.jsx)(`span`,{style:{color:`#16a34a`},children:`(save 10%)`})]})]}),(0,u.jsx)(`div`,{className:`db-muted`,style:{fontSize:12,marginTop:6},children:M?`Covers ${I} × ${P.duration_in_days}-day cycles (${q} days). ${d(R)} − 10% (${d(z)}) = ${d(H)}.`:`Switch on to cover ${I} cycles upfront (${P.duration_in_days*I} days) and get 10% off, instead of renewing every ${P.duration_in_days} days.`})]}),(0,u.jsxs)(`div`,{style:{marginTop:14},children:[(0,u.jsx)(`label`,{className:`form-label fw-semibold small mb-2`,children:`Payment method`}),(0,u.jsxs)(`div`,{className:`row g-2`,children:[(0,u.jsx)(`div`,{className:`col-6`,children:(0,u.jsxs)(`button`,{type:`button`,className:`db-method-btn ${O===`card`?`active`:``}`,onClick:()=>k(`card`),disabled:b,children:[(0,u.jsx)(`i`,{className:`bi bi-credit-card`}),`Card / Bank`]})}),(0,u.jsx)(`div`,{className:`col-6`,children:(0,u.jsxs)(`button`,{type:`button`,className:`db-method-btn ${O===`wallet`?`active`:``}`,onClick:()=>k(`wallet`),disabled:b,children:[(0,u.jsx)(`i`,{className:`bi bi-wallet2`}),`Wallet`]})})]})]}),(0,u.jsxs)(`div`,{style:{marginTop:12,padding:14,borderRadius:14,border:`1px solid rgba(0,0,0,0.06)`,background:`#fff`},children:[(0,u.jsxs)(`div`,{className:`form-check form-switch`,style:{marginBottom:0},children:[(0,u.jsx)(`input`,{className:`form-check-input`,type:`checkbox`,checked:O===`wallet`?A:!1,onChange:e=>j(e.target.checked),id:`autoRenewSwitch`,disabled:b||O!==`wallet`}),(0,u.jsx)(`label`,{className:`form-check-label fw-semibold`,htmlFor:`autoRenewSwitch`,children:`Enable auto-renew`})]}),(0,u.jsx)(`div`,{className:`db-muted`,style:{fontSize:12,marginTop:6},children:O===`card`?`Online card and bank payments are one-time only. Auto-renew is not available for card payments.`:`When enabled, wallet renewal will attempt to renew automatically from your wallet balance.`})]}),(0,u.jsx)(`div`,{style:{marginTop:12},children:O===`card`?(0,u.jsxs)(`div`,{className:`db-note`,children:[(0,u.jsx)(`i`,{className:`bi bi-info-circle me-1`}),`You will be redirected to the secure 256-bit encrypted checkout to complete this payment.`]}):(0,u.jsxs)(`div`,{className:`db-note`,children:[(0,u.jsx)(`i`,{className:`bi bi-info-circle me-1`}),`Wallet payment is processed inside your account. Auto-renew only applies when wallet is selected.`]})}),(0,u.jsxs)(`div`,{style:{marginTop:14},children:[(0,u.jsx)(`button`,{className:`db-btn-gold db-pay-btn`,onClick:$,disabled:b||!P||P.can_select===!1||!!P.limit_exceeded,title:P?``:`Select a plan first`,children:b?(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`span`,{className:`spinner-border spinner-border-sm`}),`Processing…`]}):(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`i`,{className:`bi bi-lock-fill`}),O===`wallet`?`Pay ${P?d(H):``} with Wallet`:`Make Payment ${P?d(H):``}`]})}),(0,u.jsxs)(`div`,{className:`db-muted`,style:{fontSize:12,marginTop:10},children:[(0,u.jsx)(`i`,{className:`bi bi-shield-check me-1`}),O===`card`?`After completing payment, you will be redirected back for instant verification.`:`Wallet payment updates your subscription immediately after successful debit.`]})]}),(0,u.jsxs)(`div`,{style:{marginTop:16,paddingTop:14,borderTop:`1px solid rgba(0,0,0,0.06)`},children:[(0,u.jsx)(`div`,{className:`db-strong`,style:{fontFamily:`Lora, serif`,fontSize:14,marginBottom:10},children:`Current subscription`}),(0,u.jsx)(`div`,{className:`row g-3`,children:[{k:`Plan`,v:D?.subscription_type||`—`},{k:`Status`,v:D?.status||`—`},{k:`End Date`,v:f(D?.end_date)},{k:`Auto Renew`,v:D?.auto_renew?`Enabled`:`Disabled`},{k:`Renewal Source`,v:m(D?.auto_renew_source)}].map(e=>(0,u.jsx)(`div`,{className:`col-12 col-md-6`,children:(0,u.jsxs)(`div`,{className:`db-tile`,children:[(0,u.jsx)(`div`,{className:`db-muted`,style:{fontSize:12},children:e.k}),(0,u.jsx)(`div`,{className:`db-strong`,style:{marginTop:6},children:e.v})]})},e.k))})]})]})]})})]}),(0,u.jsx)(`div`,{className:`mt-auto`,children:(0,u.jsx)(te,{})})]})]})})]})}export{h as default};