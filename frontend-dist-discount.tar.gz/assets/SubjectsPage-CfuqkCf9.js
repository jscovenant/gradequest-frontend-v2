import{i as e}from"./rolldown-runtime-CWU8vmCm.js";import{Ut as t}from"./vendor-misc-OZLc0tLq.js";import{p as n}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as r,E as i,P as a,d as ee,f as te,l as ne,u as re}from"./index-D6TxbaCx.js";var o=e(t(),1),s=n(),c=`general`;function l(e){let t=e?.response?.status,n=e?.response?.data;if(t===409)return n?.message??`This item already exists.`;if(t===404)return n?.message??`Not found.`;if(t===422){let e=n?.errors;if(e){let t=e[Object.keys(e)[0]]?.[0];if(t)return t}return n?.message??`Validation error.`}return n?.message??e?.message??`Something went wrong.`}function ie(){let e=new Date().getHours();return e<12?`Good morning`:e<17?`Good afternoon`:`Good evening`}var ae=(e,t,n)=>Math.max(t,Math.min(n,e));function oe(){let{showSuccess:e,showError:t}=ne(),[n,oe]=(0,o.useState)(!1),[se,ce]=(0,o.useState)(!0),[u,le]=(0,o.useState)(!0),[d,ue]=(0,o.useState)(!0),[f,de]=(0,o.useState)(!1),[p,fe]=(0,o.useState)([]),[m,pe]=(0,o.useState)([]),[me,he]=(0,o.useState)([]),[h,g]=(0,o.useState)([]),[_,ge]=(0,o.useState)(``),[v,y]=(0,o.useState)(``),[b,_e]=(0,o.useState)(!1),[x,S]=(0,o.useState)(null),[ve,C]=(0,o.useState)(!1),[ye,w]=(0,o.useState)(!1),[be,T]=(0,o.useState)(!1),[xe,Se]=(0,o.useState)(``),[E,D]=(0,o.useState)(!1),[O,k]=(0,o.useState)(null),[A,j]=(0,o.useState)(``),[M,N]=(0,o.useState)(!1),[P,F]=(0,o.useState)({}),[I,Ce]=(0,o.useState)(``),[L,we]=(0,o.useState)(``),[R,Te]=(0,o.useState)(``),[z,Ee]=(0,o.useState)(``),[B,De]=(0,o.useState)({}),V=e=>x===e;async function H(){try{le(!0);let e=await a.get(`/student-department`);fe(Array.isArray(e.data)?e.data:[])}catch(e){t(l(e))}finally{le(!1)}}async function Oe(){try{ue(!0);let e=await a.get(`/sections`);pe(Array.isArray(e.data)?e.data:[])}catch(e){t(l(e))}finally{ue(!1)}}async function ke(){try{let e=await a.get(`/levels`);he(Array.isArray(e.data)?e.data:e.data?.data||[])}catch(e){t(l(e))}}async function U(e){if(!e){g([]),F({});return}try{de(!0);let t=b?{archived:1}:{include_general:1},n=await a.get(`/departments/${e}/subjects`,{params:t}),r=Array.isArray(n.data)?n.data:[];g(r);let i={};r.forEach(e=>{i[e.id]=e.section_id!=null}),F(i)}catch(e){t(l(e)),g([]),F({})}finally{de(!1)}}(0,o.useEffect)(()=>{ce(!0),Promise.all([H(),Oe(),ke()]).finally(()=>ce(!1))},[]),(0,o.useEffect)(()=>{_?U(_):(g([]),F({}),y(``))},[_,b]);let W=(0,o.useMemo)(()=>_===c?{id:0,name:`General Department`}:p.find(e=>String(e.id)===String(_)),[p,_]),Ae=e=>e.section?.name??m.find(t=>t.id===e.section_id)?.name??`-`,G=(0,o.useMemo)(()=>{let e=v.trim().toLowerCase();return e?h.filter(t=>{let n=Ae(t);return`${t.name??``} ${t.subject_id??`-`} ${n}`.toLowerCase().includes(e)}):h},[h,v,m]),K=h.length,q=(0,o.useMemo)(()=>Object.values(P).filter(Boolean).length,[P]),je=!!_&&G.length>0&&G.every(e=>!!P[e.id]),[Me,J]=(0,o.useState)(1);(0,o.useEffect)(()=>J(1),[v,_]);let Y=(0,o.useMemo)(()=>Math.max(1,Math.ceil(G.length/10)),[G.length]),X=ae(Me,1,Y),Z=(0,o.useMemo)(()=>{let e=(X-1)*10;return G.slice(e,e+10)},[G,X]);async function Ne(){if(!_)return t(`Please select General Department or a department first.`);let n=E||_===c,r=xe.trim();if(!r)return t(`Please enter a subject name.`);try{S(`subject:create`);let t=n?c:_,i=await a.post(`/departments/${t}/subjects`,{name:r,is_general:n}),ee=i.data?.subject_code?` (${i.data.subject_code})`:``;e((i.data?.message??`Subject added successfully`)+ee),Se(``),D(_===c),C(!1),await U(_)}catch(e){t(l(e))}finally{S(null)}}function Pe(e){k(e.id),j(e.name??``),N(e.department_id==null),w(!0)}async function Fe(){if(!O)return;let n=A.trim();if(!n)return t(`Please enter a subject name.`);try{S(`subject:update:${O}`),e((await a.put(`/subjects/${O}`,{name:n,is_general:M})).data?.message??`Subject updated successfully.`),w(!1),k(null),j(``),N(!1),_&&await U(_)}catch(e){t(l(e))}finally{S(null)}}async function Ie(n){if(window.confirm(`Archive "${n.name}"?\n\nArchived subjects will be hidden from future result entry and template downloads, but old student results will remain safe.`))try{S(`subject:archive:${n.id}`),e((await a.delete(`/subjects/${n.id}`)).data?.message??`Subject archived successfully.`),_&&await U(_)}catch(e){t(l(e))}finally{S(null)}}async function Le(n){try{S(`subject:restore:${n.id}`),e((await a.post(`/subjects/${n.id}/restore`)).data?.message??`Subject restored successfully.`),_&&await U(_)}catch(e){t(l(e))}finally{S(null)}}function Re(e){F(t=>({...t,[e]:!t[e]}))}let ze=(0,o.useMemo)(()=>Object.values(B).filter(Boolean).length,[B]);async function Be(){try{S(`offerings:load`);let e={};L&&(e.level_id=Number(L)),R&&(e.section_id=Number(R)),z&&(e.department_id=Number(z));let t=await a.get(`/subject-offerings`,{params:e}),n=new Set((t.data?.subject_ids||[]).map(e=>Number(e))),r={};h.forEach(e=>{r[e.id]=n.has(e.id)}),De(r)}catch(e){t(l(e))}finally{S(null)}}async function Ve(){let n=Object.entries(B).filter(([,e])=>e).map(([e])=>Number(e));try{S(`offerings:save`);let t={subject_ids:n};L&&(t.level_id=Number(L)),R&&(t.section_id=Number(R)),z&&(t.department_id=Number(z)),e((await a.post(`/subject-offerings`,t)).data?.message||`Subject offerings saved.`)}catch(e){t(l(e))}finally{S(null)}}function He(e){De(t=>({...t,[e]:!t[e]}))}function Q(){let e={...P};G.forEach(t=>e[t.id]=!0),F(e)}function $(){F({})}async function Ue(){if(!I)return t(`Please select a section.`);let n=Object.entries(P).filter(([e,t])=>t).map(([e])=>Number(e));if(n.length===0)return t(`Please select at least one subject.`);try{S(`subject:assign`),e((await a.post(`/subjects/assign-section`,{section_id:Number(I),subject_ids:n})).data?.message??`Subjects successfully assigned to section.`),T(!1),Ce(``),F({}),_&&await U(_)}catch(e){t(l(e))}finally{S(null)}}let We=[{color:`#b45309`,bg:`#fef3c7`,label:_===c?`general subjects`:`department + general`},{color:`#065f46`,bg:`#d1fae5`,label:`selected for bulk`},{color:`#1e40af`,bg:`#dbeafe`,label:`departments loaded`},{color:`#7c3aed`,bg:`#ede9fe`,label:`sections loaded`}];return(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)(`style`,{children:`
        /* ======= SubjectsPage - Modern SaaS style ======= */
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');
        .db-main {
          background: #F8FAFC;
          min-height: 100vh;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          padding: 24px 28px 0;
        }

        .db-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 18px;
          padding: 32px 36px;
          position: relative;
          overflow: hidden;
          margin-bottom: 24px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
        }
        .db-hero-glow {
          position: absolute;
          top: -60px;
          right: -60px;
          width: 320px;
          height: 320px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.15) 0%, transparent 65%);
          pointer-events: none;
        }
        .db-hero-glow2 {
          position: absolute;
          bottom: -40px;
          left: 30%;
          width: 200px;
          height: 200px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(37, 99, 235, 0.10) 0%, transparent 70%);
          pointer-events: none;
        }
        .db-hero-inner {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 28px;
          flex-wrap: wrap;
        }

        .db-session-badge {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.20);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius: 100px;
          padding: 4px 12px;
          margin-bottom: 12px;
        }
        .db-session-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #10B981;
          animation: dbPulse 2s ease infinite;
        }
        @keyframes dbPulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.4; transform: scale(1.5); }
        }

        .db-greeting {
          font-size: 26px;
          font-weight: 800;
          color: #fff;
          line-height: 1.1;
          margin-bottom: 8px;
        }
        .db-greeting em { font-style: normal; color: #FBBF24; }

        .db-hero-sub {
          font-size: 13.5px;
          color: #CBD5E1;
          line-height: 1.6;
          max-width: 560px;
          margin-bottom: 20px;
        }

        .db-hero-btns { display:flex; gap:10px; flex-wrap:wrap; }

        .db-btn-gold {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 9px 18px;
          font-size: 13px;
          font-weight: 700;
          color: #FFFFFF;
          background: #D97706;
          border: none;
          border-radius: 10px;
          cursor: pointer;
          transition: all 0.2s ease;
          text-decoration: none;
          white-space: nowrap;
        }
        .db-btn-gold:hover { background: #B45309; transform: translateY(-1px); color: #FFFFFF; }

        .db-btn-outline {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 9px 18px;
          font-size: 13px;
          font-weight: 600;
          color: #FFFFFF;
          background: rgba(255, 255, 255, 0.10);
          border: 1px solid rgba(255, 255, 255, 0.20);
          border-radius: 10px;
          cursor: pointer;
          transition: all 0.2s ease;
          white-space: nowrap;
        }
        .db-btn-outline:hover {
          background: rgba(255, 255, 255, 0.18);
          color: #fff;
        }

        .db-hero-stat-card {
          background: rgba(255, 255, 255, 0.08);
          border: 1px solid rgba(255, 255, 255, 0.15);
          backdrop-filter: blur(8px);
          border-radius: 14px;
          padding: 20px 24px;
          min-width: 240px;
        }
        .db-hero-stat-row { display:flex; flex-direction:column; gap:10px; }
        .db-hero-stat-item { display:flex; justify-content:space-between; align-items:center; gap:16px; }
        .db-hero-stat-label { font-size: 12px; font-weight: 400; color: #CBD5E1; }
        .db-hero-stat-val { font-size: 18px; font-weight: 800; color: #FBBF24; }
        .db-hero-stat-sep { height: 1px; background: rgba(255, 255, 255, 0.08); }

        .db-stats {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 16px;
          margin-bottom: 18px;
        }
        @media (max-width: 1199.98px) { .db-stats { grid-template-columns: repeat(2, 1fr);} }
        @media (max-width: 575.98px) { .db-stats { grid-template-columns: 1fr; } }

        .db-stat {
          background: #fff;
          border: 1px solid #ede8e0;
          border-radius: 14px;
          padding: 22px 20px;
          position: relative;
          overflow: hidden;
          cursor: default;
          transition: box-shadow 0.25s, transform 0.25s;
        }
        .db-stat:hover { box-shadow: 0 8px 28px rgba(0,0,0,0.08); transform: translateY(-3px); }
        .db-stat::before {
          content: "";
          position: absolute;
          top: 0; left: 0; right: 0;
          height: 3px;
          background: var(--sc, #b45309);
          transform: scaleX(0);
          transform-origin: left;
          transition: transform 0.3s ease;
        }
        .db-stat:hover::before { transform: scaleX(1); }

        .db-stat-head { display:flex; align-items:flex-start; justify-content:space-between; margin-bottom: 14px; }
        .db-stat-icon {
          width: 42px; height: 42px;
          border-radius: 10px;
          background: var(--si, #fef3c7);
          color: var(--sc, #b45309);
          display:flex; align-items:center; justify-content:center;
          transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
        }
        .db-stat:hover .db-stat-icon { transform: scale(1.1) rotate(-4deg); }
        .db-stat-more { color: #c8bfb5; padding: 2px; }

        .db-stat-label { font-size: 12px; font-weight: 500; color: #9a8a7a; margin-bottom: 6px; letter-spacing: .03em; }
        .db-stat-val { font-family: "Lora", Georgia, serif; font-size: 28px; font-weight: 700; color: #1a1a2e; line-height: 1; }
        .db-stat-footer {
          display:flex; align-items:center; gap:6px;
          margin-top: 12px; padding-top: 10px;
          border-top: 1px solid rgba(0,0,0,0.06);
          font-size: 12px; color: #9a8a7a;
        }
        .db-stat-trend { color:#22c55e; font-weight:600; }

        .db-panel {
          background: #fff;
          border: 1px solid #ede8e0;
          border-radius: 14px;
          overflow: hidden;
          margin-bottom: 24px;
        }

        .db-panel-head {
          display:flex;
          align-items:center;
          justify-content: space-between;
          padding: 18px 20px 16px;
          border-bottom: 1px solid rgba(0,0,0,0.06);
          gap: 12px;
          flex-wrap: wrap;
        }
        .db-panel-title-group { display:flex; align-items:center; gap:12px; }
        .db-panel-icon {
          width: 36px; height: 36px; border-radius: 9px;
          display:flex; align-items:center; justify-content:center;
          background: var(--pi, #fef3c7);
          color: var(--pc, #b45309);
          flex-shrink: 0;
        }
        .db-panel-title { font-family: "Lora", serif; font-size: 16px; font-weight: 700; color: #1a1a2e; margin: 0; }
        .db-panel-sub { font-size: 11.5px; font-weight: 300; color: #9a8a7a; margin: 0; }

        .db-toolbar { display:flex; align-items:center; gap: 10px; flex-wrap: wrap; }
        .db-input {
          display:flex;
          align-items:center;
          gap: 8px;
          padding: 10px 12px;
          background: #faf8f5;
          border: 1px solid #e5ddd3;
          border-radius: 12px;
          min-width: 280px;
        }
        .db-input input {
          border: none;
          outline: none;
          background: transparent;
          width: 100%;
          font-size: 13.5px;
          color: #1a1a2e;
        }
        .db-chip-btn {
          display:inline-flex;
          align-items:center;
          gap: 6px;
          padding: 8px 12px;
          font-size: 12.5px;
          font-weight: 600;
          color: #7a6a5a;
          background: #f5f1eb;
          border: 1px solid #e5ddd3;
          border-radius: 10px;
          cursor: pointer;
          transition: background .2s, color .2s, transform .2s;
          white-space: nowrap;
        }
        .db-chip-btn:hover:not(:disabled) { background:#ede8e0; color:#1a1a2e; transform: translateY(-1px); }
        .db-chip-btn:disabled { opacity: .5; cursor: not-allowed; }

        .db-select {
          padding: 10px 12px;
          border-radius: 12px;
          border: 1px solid #e5ddd3;
          background: #faf8f5;
          outline: none;
          font-size: 13.5px;
          color: #1a1a2e;
          min-width: 260px;
        }
        .db-select:focus {
          border-color: rgba(201,168,76,0.55);
          box-shadow: 0 0 0 4px rgba(201,168,76,0.18);
          background: #fff;
        }

        .db-table { width: 100%; border-collapse: collapse; }
        .db-table th {
          padding: 10px 16px;
          font-size: 11px;
          font-weight: 600;
          letter-spacing: 0.10em;
          text-transform: uppercase;
          color: #9a8a7a;
          background: #faf8f5;
          border-bottom: 1px solid rgba(0,0,0,0.06);
          text-align: left;
          white-space: nowrap;
        }
        .db-table th:last-child { text-align: right; }
        .db-table td {
          padding: 13px 16px;
          font-size: 13.5px;
          color: #4a4a5a;
          border-bottom: 1px solid rgba(0,0,0,0.06);
          vertical-align: middle;
        }
        .db-table tbody tr { transition: background 0.15s; }
        .db-table tbody tr:hover { background: #faf8f5; }
        .db-table tbody tr:last-child td { border-bottom: none; }

        .db-pill {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          font-size: 12.5px;
          font-weight: 700;
          padding: 4px 10px;
          border-radius: 999px;
          background: #f0ebe3;
          color: #7a6a5a;
          white-space: nowrap;
        }

        .db-actions { display:inline-flex; justify-content:flex-end; gap: 8px; flex-wrap: wrap; }
        .db-action-btn {
          display:inline-flex;
          align-items:center;
          gap: 6px;
          padding: 7px 12px;
          font-size: 12.5px;
          font-weight: 700;
          border-radius: 10px;
          cursor: pointer;
          border: 1px solid rgba(0,0,0,0.10);
          background: #fff;
          transition: transform .2s, box-shadow .2s, background .2s;
          white-space: nowrap;
        }
        .db-action-btn:hover:not(:disabled) { transform: translateY(-1px); box-shadow: 0 8px 18px rgba(0,0,0,0.08); background: #faf8f5; }
        .db-action-btn:disabled { opacity: .5; cursor: not-allowed; }

        .db-action-primary { border-color: rgba(30, 64, 175, 0.25); color: #1e40af; }
        .db-action-gold    { border-color: rgba(180, 83, 9, 0.25); color: #b45309; }
        .db-action-green   { border-color: rgba(6, 95, 70, 0.25); color: #065f46; }
        .db-action-danger  { border-color: rgba(185, 28, 28, 0.25); color: #b91c1c; }

        .db-helper-row {
          display:flex;
          align-items:center;
          justify-content: space-between;
          gap: 10px;
          flex-wrap: wrap;
          padding: 12px 14px;
          margin: 12px 0 18px;
          background: rgba(201,168,76,0.08);
          border: 1px solid rgba(201,168,76,0.20);
          border-radius: 14px;
        }
        .db-helper-left { display:flex; align-items:center; gap: 10px; flex-wrap: wrap; color:#7a6a5a; font-size: 12.5px; }
        .db-helper-right { display:flex; align-items:center; gap: 8px; flex-wrap: wrap; }

        .db-pagination {
          display:flex;
          align-items:center;
          justify-content: space-between;
          padding: 14px 16px;
          border-top: 1px solid rgba(0,0,0,0.06);
          flex-wrap: wrap;
          gap: 10px;
        }
        .db-page-info { font-size: 12px; color:#9a8a7a; }
        .db-page-btns { display:flex; align-items:center; gap: 8px; }
        .db-page-btn {
          display:inline-flex;
          align-items:center;
          gap: 6px;
          padding: 7px 12px;
          font-size: 12.5px;
          font-weight: 700;
          color: #7a6a5a;
          background: #f5f1eb;
          border: 1px solid #e5ddd3;
          border-radius: 10px;
          cursor: pointer;
          transition: background .2s, transform .2s, color .2s;
        }
        .db-page-btn:hover:not(:disabled) { background:#ede8e0; color:#1a1a2e; transform: translateY(-1px); }
        .db-page-btn:disabled { opacity: .45; cursor:not-allowed; }
        .db-page-current { font-size: 12px; color:#9a8a7a; }

        /* Modals */
        .db-modal-backdrop {
          position: fixed;
          inset: 0;
          background: rgba(10, 25, 47, 0.70);
          backdrop-filter: blur(8px);
          -webkit-backdrop-filter: blur(8px);
          z-index: 1400;
          display:flex;
          align-items:center;
          justify-content:center;
          padding: 16px;
        }
        .db-modal {
          width: min(900px, 96vw);
          max-height: 92vh;
          border-radius: 18px;
          overflow: hidden;
          background: #fff;
          box-shadow: 0 25px 60px -12px rgba(15, 39, 68, 0.35);
          border: 1px solid rgba(15, 39, 68, 0.12);
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
        }
        .db-modal-head {
          padding: 22px 28px 16px;
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 100%);
          color: #fff;
          position: relative;
          overflow: hidden;
          border-bottom: 1px solid rgba(255, 255, 255, 0.12);
        }
        .db-modal-head::before {
          content:"";
          position:absolute;
          inset:0;
          background-image:
            linear-gradient(rgba(255, 255, 255, 0.035) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255, 255, 255, 0.035) 1px, transparent 1px);
          background-size: 24px 24px;
          pointer-events:none;
        }
        .db-modal-head-inner {
          position: relative;
          z-index: 1;
          display:flex;
          align-items:flex-start;
          justify-content: space-between;
          gap: 16px;
        }
        .db-modal-title {
          margin:0;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          font-size: 18px;
          font-weight: 800;
          color: #FFFFFF;
        }
        .db-modal-sub {
          margin: 4px 0 0;
          color: #CBD5E1;
          font-size: 12.5px;
        }
        .db-modal-close {
          width: 34px;
          height: 34px;
          border-radius: 10px;
          border: 1px solid rgba(255, 255, 255, 0.20);
          background: rgba(255, 255, 255, 0.10);
          color: #fff;
          cursor: pointer;
          display:flex;
          align-items:center;
          justify-content:center;
          transition: all 0.2s ease;
          flex-shrink: 0;
        }
        .db-modal-close:hover:not(:disabled) {
          background: rgba(239, 68, 68, 0.3);
          border-color: rgba(239, 68, 68, 0.5);
          transform: scale(1.1) rotate(90deg);
        }
        .db-modal-close:disabled { opacity: .5; cursor:not-allowed; }

        .db-modal-body { background:#F8FAFC; padding: 24px; overflow:auto; max-height: calc(92vh - 130px); }
        .db-modal-card { background:#fff; border: 1px solid #E2E8F0; border-radius: 14px; padding: 20px; box-shadow: 0 2px 10px rgba(15, 39, 68, 0.04); }

        .db-form-grid { display:grid; grid-template-columns: 1fr 1fr; gap: 16px; }
        @media (max-width: 767.98px) { .db-form-grid { grid-template-columns: 1fr; } }

        .db-field label {
          display:block;
          font-size: 12px;
          font-weight: 700;
          color: #0F2744;
          margin-bottom: 6px;
        }
        .db-field input, .db-field select {
          width: 100%;
          padding: 10px 14px;
          border-radius: 10px;
          border: 1.5px solid #CBD5E1;
          background: #fff;
          outline: none;
          font-size: 13.5px;
          color: #0F2744;
          transition: all 0.2s ease;
        }
        .db-field input:focus, .db-field select:focus {
          border-color: #D97706;
          box-shadow: 0 0 0 3px rgba(217, 119, 6, 0.15);
          background: #fff;
        }
        .db-help { margin-top: 6px; font-size: 12px; color: #64748B; }

        .db-modal-foot {
          padding: 16px 24px;
          background: #fff;
          border-top: 1px solid #E2E8F0;
          display:flex;
          justify-content: flex-end;
          gap: 12px;
          flex-wrap: wrap;
        }

        .db-btn {
          display:inline-flex;
          align-items:center;
          gap: 7px;
          padding: 9px 18px;
          border-radius: 10px;
          font-size: 13px;
          font-weight: 700;
          cursor: pointer;
          border: 1px solid transparent;
          transition: all 0.2s ease;
          white-space: nowrap;
        }
        .db-btn:hover:not(:disabled) { transform: translateY(-1px); }
        .db-btn:disabled { opacity: .55; cursor:not-allowed; box-shadow:none; transform:none; }

        .db-btn-secondary { background: #FFFFFF; border: 1px solid #CBD5E1; color: #475569; }
        .db-btn-secondary:hover:not(:disabled) { background: #F1F5F9; color:#0F2744; }

        .db-btn-primary { background: #FBBF24; color: #0F2744; border: none; box-shadow: 0 2px 8px rgba(251, 191, 36, 0.3); }
        .db-btn-primary:hover:not(:disabled) { background:#F59E0B; }

        .db-btn-green { background: linear-gradient(135deg, #10B981 0%, #059669 100%); color: #fff; border: none; }
        .db-btn-green:hover:not(:disabled) { background: #059669; }

        @keyframes dbSpin { to { transform: rotate(360deg); } }

        .db-muted { color: #9a8a7a; }
        .db-checkbox { width: 16px; height: 16px; cursor: pointer; accent-color: #c9a84c; }
        .db-option-card {
          margin-top: 14px;
          display: flex;
          align-items: flex-start;
          gap: 12px;
          padding: 14px;
          border: 1px solid #e5ddd3;
          border-radius: 14px;
          background: #faf8f5;
          cursor: pointer;
        }
        .db-check-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
          gap: 10px;
        }
        .db-option-card:hover { border-color: rgba(201,168,76,0.55); background: #fffaf0; }
        .db-option-card input { width: 18px; height: 18px; margin-top: 2px; accent-color: #c9a84c; cursor: pointer; flex-shrink: 0; }
        .db-option-title { display:block; font-size: 13px; font-weight: 900; color: #1a1a2e; line-height: 1.25; }
        .db-option-help { display:block; margin-top: 4px; font-size: 12px; color: #7a6a5a; line-height: 1.35; }
        .db-badge-code {
          display:inline-flex;
          align-items:center;
          gap: 6px;
          padding: 4px 10px;
          border-radius: 999px;
          background: #ede8e0;
          color: #1a1a2e;
          font-size: 12px;
          font-weight: 800;
          white-space: nowrap;
        }
      `}),(0,s.jsx)(te,{sidebarOpen:n,setSidebarOpen:oe}),(0,s.jsx)(r,{title:`Subjects`}),(0,s.jsx)(`div`,{className:`container-fluid`,children:(0,s.jsxs)(`div`,{className:`row`,children:[(0,s.jsx)(ee,{sidebarOpen:n}),(0,s.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto db-main`,children:[se&&(0,s.jsx)(i,{message:`Loading subjects...`}),(0,s.jsxs)(`div`,{className:`db-hero`,children:[(0,s.jsx)(`div`,{className:`db-hero-glow`,"aria-hidden":`true`}),(0,s.jsx)(`div`,{className:`db-hero-glow2`,"aria-hidden":`true`}),(0,s.jsxs)(`div`,{className:`db-hero-inner`,children:[(0,s.jsxs)(`div`,{children:[(0,s.jsxs)(`div`,{className:`db-session-badge`,children:[(0,s.jsx)(`span`,{className:`db-session-dot`}),`Academics - Subjects`]}),(0,s.jsxs)(`h1`,{className:`db-greeting`,children:[ie(),`, `,(0,s.jsx)(`em`,{children:`Admin.`})]}),(0,s.jsx)(`p`,{className:`db-hero-sub`,children:`Pick a department, manage subjects, and bulk-assign subjects to a section. Subjects already assigned are pre-checked.`}),(0,s.jsxs)(`div`,{className:`db-hero-btns`,children:[(0,s.jsxs)(`button`,{className:`db-btn-gold`,onClick:()=>{D(_===c),C(!0)},disabled:b||!_||x!==null,title:_?``:`Select a department first`,type:`button`,children:[(0,s.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:(0,s.jsx)(`path`,{d:`M8 3v10M3 8h10`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})}),`Add Subject`]}),(0,s.jsxs)(`button`,{className:`db-btn-outline`,onClick:()=>_?U(_):H(),disabled:x!==null||(_?f:u),type:`button`,children:[(0,s.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,style:{animation:f||u?`dbSpin 0.8s linear infinite`:`none`},children:[(0,s.jsx)(`path`,{d:`M12 7A5 5 0 112 7`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,s.jsx)(`path`,{d:`M12 3v4h-4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),`Refresh`]}),(0,s.jsxs)(`button`,{className:`db-btn-outline`,onClick:()=>T(!0),disabled:!_||q===0||x!==null,title:q===0?`Select subjects first`:``,type:`button`,children:[(0,s.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,s.jsx)(`path`,{d:`M7 8h6`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`}),(0,s.jsx)(`path`,{d:`M6.5 6.3l7 5`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,s.jsx)(`path`,{d:`M6.5 9.7l7-5`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,s.jsx)(`circle`,{cx:`6`,cy:`8`,r:`2.1`,stroke:`currentColor`,strokeWidth:`1.4`}),(0,s.jsx)(`circle`,{cx:`14`,cy:`8`,r:`2.1`,stroke:`currentColor`,strokeWidth:`1.4`})]}),`Assign Section (`,q,`)`]})]})]}),(0,s.jsxs)(`div`,{className:`db-hero-stat-card d-none d-md-block`,children:[(0,s.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,marginBottom:16},children:[(0,s.jsx)(`span`,{style:{fontSize:11,fontWeight:600,letterSpacing:`0.14em`,textTransform:`uppercase`,color:`#c9a84c`},children:`Quick summary`}),(0,s.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:(0,s.jsx)(`path`,{d:`M2 10V6M5 10V4M8 10V7M11 10V3`,stroke:`#64748b`,strokeWidth:`1.5`,strokeLinecap:`round`})})]}),(0,s.jsxs)(`div`,{className:`db-hero-stat-row`,children:[(0,s.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,s.jsx)(`span`,{className:`db-hero-stat-label`,children:`Departments`}),(0,s.jsx)(`span`,{className:`db-hero-stat-val`,children:u?`...`:p.length})]}),(0,s.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,s.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,s.jsx)(`span`,{className:`db-hero-stat-label`,children:`Sections`}),(0,s.jsx)(`span`,{className:`db-hero-stat-val`,children:d?`...`:m.length})]}),(0,s.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,s.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,s.jsx)(`span`,{className:`db-hero-stat-label`,children:`Subjects`}),(0,s.jsx)(`span`,{className:`db-hero-stat-val`,children:_?K:`-`})]})]}),(0,s.jsx)(`div`,{style:{marginTop:14,paddingTop:12,borderTop:`1px solid rgba(255,255,255,0.06)`},children:(0,s.jsxs)(`div`,{style:{fontSize:12,color:`#64748b`},children:[`Department:`,` `,(0,s.jsx)(`span`,{style:{color:`#fff`,fontWeight:700},children:W?.name??`Not selected`})]})})]})]})]}),(0,s.jsx)(`div`,{className:`db-stats`,children:[{title:`Total Subjects`,value:_?K:`-`,hint:_===c?`general subjects`:`department + general`},{title:`Selected`,value:q,hint:`marked for bulk`},{title:`Departments`,value:u?`...`:p.length,hint:`loaded`},{title:`Sections`,value:d?`...`:m.length,hint:`loaded`}].map((e,t)=>{let n=We[t],r=[(0,s.jsxs)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 20 20`,fill:`none`,children:[(0,s.jsx)(`path`,{d:`M4 6l6-3 6 3-6 3-6-3z`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinejoin:`round`}),(0,s.jsx)(`path`,{d:`M4 10l6 3 6-3`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinejoin:`round`}),(0,s.jsx)(`path`,{d:`M4 14l6 3 6-3`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinejoin:`round`})]},`i1`),(0,s.jsxs)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 20 20`,fill:`none`,children:[(0,s.jsx)(`circle`,{cx:`10`,cy:`10`,r:`7`,stroke:`currentColor`,strokeWidth:`1.5`}),(0,s.jsx)(`path`,{d:`M6 10l2.5 2.5L14 7`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`,strokeLinejoin:`round`})]},`i2`),(0,s.jsxs)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 20 20`,fill:`none`,children:[(0,s.jsx)(`path`,{d:`M7 6a3 3 0 016 0v2`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`}),(0,s.jsx)(`rect`,{x:`5`,y:`8`,width:`10`,height:`8`,rx:`2`,stroke:`currentColor`,strokeWidth:`1.5`}),(0,s.jsx)(`path`,{d:`M10 12v2`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`})]},`i3`),(0,s.jsxs)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 20 20`,fill:`none`,children:[(0,s.jsx)(`path`,{d:`M7 10h6`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`}),(0,s.jsx)(`path`,{d:`M6.5 7.5l7 5`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,s.jsx)(`path`,{d:`M6.5 12.5l7-5`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,s.jsx)(`circle`,{cx:`6`,cy:`10`,r:`2.3`,stroke:`currentColor`,strokeWidth:`1.4`}),(0,s.jsx)(`circle`,{cx:`14`,cy:`10`,r:`2.3`,stroke:`currentColor`,strokeWidth:`1.4`})]},`i4`)];return(0,s.jsxs)(`div`,{className:`db-stat`,style:{"--sc":n.color,"--si":n.bg},children:[(0,s.jsxs)(`div`,{className:`db-stat-head`,children:[(0,s.jsx)(`div`,{className:`db-stat-icon`,children:r[t]}),(0,s.jsxs)(`svg`,{className:`db-stat-more`,width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,s.jsx)(`circle`,{cx:`4`,cy:`8`,r:`1.2`,fill:`currentColor`}),(0,s.jsx)(`circle`,{cx:`8`,cy:`8`,r:`1.2`,fill:`currentColor`}),(0,s.jsx)(`circle`,{cx:`12`,cy:`8`,r:`1.2`,fill:`currentColor`})]})]}),(0,s.jsx)(`p`,{className:`db-stat-label`,children:e.title}),(0,s.jsx)(`div`,{className:`db-stat-val`,children:e.value}),(0,s.jsxs)(`div`,{className:`db-stat-footer`,children:[(0,s.jsx)(`svg`,{width:`12`,height:`12`,viewBox:`0 0 12 12`,fill:`none`,children:(0,s.jsx)(`path`,{d:`M2 9l3-4 2 2 3-5`,stroke:`#22c55e`,strokeWidth:`1.4`,strokeLinecap:`round`,strokeLinejoin:`round`})}),(0,s.jsx)(`span`,{className:`db-stat-trend`,children:`OK`}),(0,s.jsx)(`span`,{className:`db-muted`,children:e.hint})]})]},e.title)})}),(0,s.jsxs)(`div`,{className:`db-panel`,children:[(0,s.jsxs)(`div`,{className:`db-panel-head`,children:[(0,s.jsxs)(`div`,{className:`db-panel-title-group`,children:[(0,s.jsx)(`div`,{className:`db-panel-icon`,style:{"--pi":`#fef3c7`,"--pc":`#b45309`},children:(0,s.jsx)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:(0,s.jsx)(`path`,{d:`M3 4.5h10M3 8h10M3 11.5h10`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`})})}),(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`p`,{className:`db-panel-title`,children:`Subjects`}),(0,s.jsx)(`p`,{className:`db-panel-sub`,children:`Filter by department - Search - Bulk assign`})]})]}),(0,s.jsxs)(`div`,{className:`db-toolbar`,children:[(0,s.jsxs)(`select`,{className:`db-select`,value:_,onChange:e=>{ge(e.target.value),y(``)},disabled:u||x!==null,title:`Select department`,children:[(0,s.jsx)(`option`,{value:``,children:`Select Department`}),(0,s.jsx)(`option`,{value:c,children:`General Department`}),p.map(e=>(0,s.jsx)(`option`,{value:e.id,children:e.name},e.id))]}),(0,s.jsxs)(`div`,{className:`db-input`,title:`Search subjects`,children:[(0,s.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,style:{flexShrink:0},children:[(0,s.jsx)(`circle`,{cx:`7`,cy:`7`,r:`4.5`,stroke:`#9a8a7a`,strokeWidth:`1.4`}),(0,s.jsx)(`path`,{d:`M11 11l3 3`,stroke:`#9a8a7a`,strokeWidth:`1.4`,strokeLinecap:`round`})]}),(0,s.jsx)(`input`,{placeholder:`Search subjects...`,value:v,onChange:e=>y(e.target.value),disabled:!_}),v.trim()?(0,s.jsx)(`button`,{className:`db-chip-btn`,style:{padding:`6px 10px`,borderRadius:10},onClick:()=>y(``),type:`button`,children:`Clear`}):null]}),(0,s.jsxs)(`button`,{className:`db-chip-btn`,onClick:()=>_?U(_):H(),disabled:x!==null||(_?f:u),type:`button`,children:[(0,s.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,children:[(0,s.jsx)(`path`,{d:`M12 7A5 5 0 112 7`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,s.jsx)(`path`,{d:`M12 3v4h-4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),`Refresh`]}),(0,s.jsx)(`button`,{className:`db-chip-btn`,onClick:()=>_e(e=>!e),disabled:x!==null,type:`button`,children:b?`Show Active`:`View Archived`}),b?null:(0,s.jsxs)(s.Fragment,{children:[(0,s.jsxs)(`button`,{className:`db-chip-btn`,onClick:()=>{D(_===c),C(!0)},disabled:!_||x!==null,title:_?``:`Select a department first`,type:`button`,children:[(0,s.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:(0,s.jsx)(`path`,{d:`M8 3v10M3 8h10`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})}),`Add`]}),(0,s.jsxs)(`button`,{className:`db-chip-btn`,onClick:()=>T(!0),disabled:!_||q===0||x!==null,title:q===0?`Select subjects first`:``,type:`button`,children:[(0,s.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,s.jsx)(`path`,{d:`M7 8h6`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`}),(0,s.jsx)(`path`,{d:`M6.5 6.3l7 5`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,s.jsx)(`path`,{d:`M6.5 9.7l7-5`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,s.jsx)(`circle`,{cx:`6`,cy:`8`,r:`2.1`,stroke:`currentColor`,strokeWidth:`1.4`}),(0,s.jsx)(`circle`,{cx:`14`,cy:`8`,r:`2.1`,stroke:`currentColor`,strokeWidth:`1.4`})]}),`Assign (`,q,`)`]})]})]})]}),_?(0,s.jsxs)(`div`,{className:`db-helper-row`,children:[(0,s.jsxs)(`div`,{className:`db-helper-left`,children:[(0,s.jsxs)(`span`,{children:[`Department: `,(0,s.jsx)(`b`,{style:{color:`#1a1a2e`},children:W?.name??`-`})]}),(0,s.jsx)(`span`,{style:{opacity:.6},children:`-`}),(0,s.jsxs)(`span`,{children:[`Selected: `,(0,s.jsx)(`b`,{style:{color:`#1a1a2e`},children:q})]}),(0,s.jsx)(`span`,{style:{opacity:.6},children:`-`}),(0,s.jsxs)(`span`,{children:[`Total: `,(0,s.jsx)(`b`,{style:{color:`#1a1a2e`},children:K})]})]}),(0,s.jsxs)(`div`,{className:`db-helper-right`,children:[(0,s.jsx)(`button`,{className:`db-chip-btn`,onClick:Q,disabled:x!==null||G.length===0,type:`button`,children:`Select All (Filtered)`}),(0,s.jsx)(`button`,{className:`db-chip-btn`,onClick:$,disabled:x!==null||q===0,type:`button`,children:`Clear`})]})]}):null,(0,s.jsx)(`div`,{style:{overflowX:`auto`},children:(0,s.jsxs)(`table`,{className:`db-table`,children:[(0,s.jsx)(`thead`,{children:(0,s.jsxs)(`tr`,{children:[(0,s.jsx)(`th`,{style:{width:56},children:(0,s.jsx)(`input`,{type:`checkbox`,className:`db-checkbox`,checked:je,disabled:b||!_||G.length===0,onChange:e=>{_&&(e.target.checked?Q():$())},title:`Select all filtered`})}),(0,s.jsx)(`th`,{children:`Subject`}),(0,s.jsx)(`th`,{style:{width:160},children:`Code`}),(0,s.jsx)(`th`,{style:{width:170},children:`Department`}),(0,s.jsx)(`th`,{style:{width:220},children:`Section`}),(0,s.jsx)(`th`,{style:{width:210,textAlign:`right`},children:`Actions`})]})}),(0,s.jsx)(`tbody`,{children:_?f?(0,s.jsx)(`tr`,{children:(0,s.jsxs)(`td`,{colSpan:6,style:{padding:28,textAlign:`center`,color:`#9a8a7a`},children:[(0,s.jsx)(`span`,{className:`spinner-border spinner-border-sm`}),` `,(0,s.jsx)(`span`,{style:{marginLeft:8},children:`Loading subjects...`})]})}):Z.length===0?(0,s.jsx)(`tr`,{children:(0,s.jsxs)(`td`,{colSpan:6,style:{padding:34,textAlign:`center`,color:`#9a8a7a`},children:[(0,s.jsx)(`div`,{style:{fontWeight:900,color:`#1a1a2e`},children:`No subjects found`}),(0,s.jsx)(`div`,{style:{marginTop:6},children:`Click "Add" to create one.`})]})}):Z.map(e=>{let t=V(`subject:update:${e.id}`),n=V(`subject:archive:${e.id}`),r=V(`subject:restore:${e.id}`);return(0,s.jsxs)(`tr`,{children:[(0,s.jsx)(`td`,{children:(0,s.jsx)(`input`,{type:`checkbox`,className:`db-checkbox`,checked:!!P[e.id],onChange:()=>Re(e.id),disabled:b,title:b?`Archived subjects cannot be assigned`:`Select subject`})}),(0,s.jsxs)(`td`,{children:[(0,s.jsx)(`div`,{style:{fontWeight:800,color:`#1a1a2e`},children:e.name}),(0,s.jsxs)(`div`,{style:{fontSize:12,color:`#9a8a7a`},children:[`ID: `,e.id]})]}),(0,s.jsx)(`td`,{children:(0,s.jsx)(`span`,{className:`db-badge-code`,children:e.subject_id??`-`})}),(0,s.jsx)(`td`,{children:(0,s.jsx)(`span`,{className:`db-pill`,style:e.department_id==null?{background:`#ecfdf5`,color:`#047857`}:void 0,children:e.department_id==null?`General`:W?.name??`-`})}),(0,s.jsx)(`td`,{children:(0,s.jsxs)(`span`,{className:`db-pill`,children:[(0,s.jsx)(`svg`,{width:`12`,height:`12`,viewBox:`0 0 12 12`,fill:`none`,children:(0,s.jsx)(`path`,{d:`M3 6h6`,stroke:`#7a6a5a`,strokeWidth:`1.4`,strokeLinecap:`round`})}),Ae(e)]})}),(0,s.jsx)(`td`,{style:{textAlign:`right`},children:(0,s.jsxs)(`div`,{className:`db-actions`,children:[(0,s.jsxs)(`button`,{className:`db-action-btn db-action-primary`,onClick:()=>Pe(e),disabled:b||x!==null,type:`button`,children:[(0,s.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,s.jsx)(`path`,{d:`M3 11.5V13h1.5L12.8 4.7 11.3 3.2 3 11.5z`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinejoin:`round`}),(0,s.jsx)(`path`,{d:`M10.6 3.9l1.5 1.5`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`})]}),`Edit`]}),(0,s.jsx)(`button`,{className:`db-action-btn ${b?`db-action-green`:`db-action-danger`}`,onClick:()=>b?Le(e):Ie(e),disabled:x!==null,type:`button`,title:b?`Restore subject`:`Archive subject`,children:b?r?`Restoring...`:`Restore`:n?(0,s.jsxs)(s.Fragment,{children:[(0,s.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,style:{animation:`dbSpin .9s linear infinite`},children:[(0,s.jsx)(`path`,{d:`M12 7A5 5 0 112 7`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,s.jsx)(`path`,{d:`M12 3v4h-4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),`Archiving...`]}):`Archive`}),t&&(0,s.jsxs)(`span`,{className:`db-pill`,style:{background:`rgba(148,163,184,0.18)`,color:`#475569`},children:[(0,s.jsxs)(`svg`,{width:`12`,height:`12`,viewBox:`0 0 14 14`,fill:`none`,style:{animation:`dbSpin .9s linear infinite`},children:[(0,s.jsx)(`path`,{d:`M12 7A5 5 0 112 7`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,s.jsx)(`path`,{d:`M12 3v4h-4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),`Saving...`]})]})})]},e.id)}):(0,s.jsx)(`tr`,{children:(0,s.jsxs)(`td`,{colSpan:6,style:{padding:34,textAlign:`center`,color:`#9a8a7a`},children:[(0,s.jsx)(`div`,{style:{fontWeight:900,color:`#1a1a2e`},children:`Select a department`}),(0,s.jsx)(`div`,{style:{marginTop:6},children:`Choose a department to load its subjects.`})]})})})]})}),_?(0,s.jsxs)(`div`,{className:`db-pagination`,children:[(0,s.jsxs)(`div`,{className:`db-page-info`,children:[`Showing `,(0,s.jsx)(`b`,{children:Z.length}),` of `,(0,s.jsx)(`b`,{children:G.length}),` results - Page `,(0,s.jsx)(`b`,{children:X}),` of`,` `,(0,s.jsx)(`b`,{children:Y})]}),(0,s.jsxs)(`div`,{className:`db-page-btns`,children:[(0,s.jsxs)(`button`,{className:`db-page-btn`,onClick:()=>J(e=>Math.max(1,e-1)),disabled:X<=1,type:`button`,children:[(0,s.jsx)(`svg`,{width:`12`,height:`12`,viewBox:`0 0 12 12`,fill:`none`,children:(0,s.jsx)(`path`,{d:`M8 2L4 6l4 4`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`,strokeLinejoin:`round`})}),`Prev`]}),(0,s.jsxs)(`span`,{className:`db-page-current`,children:[`Page `,X]}),(0,s.jsxs)(`button`,{className:`db-page-btn`,onClick:()=>J(e=>Math.min(Y,e+1)),disabled:X>=Y,type:`button`,children:[`Next`,(0,s.jsx)(`svg`,{width:`12`,height:`12`,viewBox:`0 0 12 12`,fill:`none`,children:(0,s.jsx)(`path`,{d:`M4 2l4 4-4 4`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`,strokeLinejoin:`round`})})]})]})]}):null]}),(0,s.jsxs)(`div`,{className:`db-panel`,style:{marginTop:18},children:[(0,s.jsxs)(`div`,{className:`db-panel-head`,children:[(0,s.jsxs)(`div`,{className:`db-panel-title-group`,children:[(0,s.jsx)(`div`,{className:`db-panel-icon`,style:{"--pi":`#e0f2fe`,"--pc":`#0369a1`},children:(0,s.jsx)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:(0,s.jsx)(`path`,{d:`M3 4h10M3 8h10M3 12h6`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`})})}),(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`h3`,{className:`db-panel-title`,children:`Control Who Offers These Subjects`}),(0,s.jsx)(`p`,{className:`db-panel-sub`,children:`Decide the exact class, section, or department that should see and use the subjects currently listed above.`})]})]}),(0,s.jsx)(`div`,{className:`db-panel-actions`,children:(0,s.jsxs)(`span`,{className:`db-pill`,children:[ze,` selected`]})})]}),(0,s.jsxs)(`div`,{className:`db-toolbar`,style:{alignItems:`end`},children:[(0,s.jsxs)(`div`,{className:`db-field`,style:{minWidth:180},children:[(0,s.jsx)(`label`,{children:`Class`}),(0,s.jsxs)(`select`,{value:L,onChange:e=>we(e.target.value),children:[(0,s.jsx)(`option`,{value:``,children:`All classes`}),me.map(e=>(0,s.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]}),(0,s.jsxs)(`div`,{className:`db-field`,style:{minWidth:180},children:[(0,s.jsx)(`label`,{children:`Section`}),(0,s.jsxs)(`select`,{value:R,onChange:e=>Te(e.target.value),children:[(0,s.jsx)(`option`,{value:``,children:`All sections`}),m.map(e=>(0,s.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]}),(0,s.jsxs)(`div`,{className:`db-field`,style:{minWidth:200},children:[(0,s.jsx)(`label`,{children:`Department`}),(0,s.jsxs)(`select`,{value:z,onChange:e=>Ee(e.target.value),children:[(0,s.jsx)(`option`,{value:``,children:`All departments`}),p.map(e=>(0,s.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]}),(0,s.jsx)(`button`,{className:`db-btn-outline`,type:`button`,onClick:Be,disabled:!_||x!==null,children:V(`offerings:load`)?`Loading...`:`Load current setup`}),(0,s.jsx)(`button`,{className:`db-btn-primary`,type:`button`,onClick:Ve,disabled:!_||x!==null,children:V(`offerings:save`)?`Saving...`:`Save setup`})]}),(0,s.jsx)(`div`,{style:{marginTop:12,color:`#7a6a5a`,fontSize:13,lineHeight:1.6},children:`First select a department above so the subject list loads. Leave Class, Section, and Department as "All" to edit the school default. To restrict a general subject like Civic Education, remove it from the default, then add it only to the correct class, section, or department.`}),_?h.length===0?(0,s.jsx)(`div`,{className:`db-empty`,style:{marginTop:14},children:`No subjects are loaded for the selected department.`}):(0,s.jsx)(`div`,{className:`db-check-grid`,style:{marginTop:16},children:h.map(e=>(0,s.jsxs)(`label`,{className:`db-option-card`,style:{alignItems:`center`},children:[(0,s.jsx)(`input`,{type:`checkbox`,checked:!!B[e.id],onChange:()=>He(e.id)}),(0,s.jsxs)(`span`,{children:[(0,s.jsx)(`b`,{children:e.name}),(0,s.jsxs)(`small`,{style:{display:`block`,color:`#9a8a7a`,marginTop:2},children:[`ID: `,e.id]})]})]},e.id))}):(0,s.jsx)(`div`,{className:`db-empty`,style:{marginTop:14},children:`Select General Department or another department above to load subjects first.`})]}),(0,s.jsx)(re,{}),ve&&(0,s.jsx)(`div`,{className:`db-modal-backdrop`,onMouseDown:()=>{x||C(!1)},children:(0,s.jsxs)(`div`,{className:`db-modal`,onMouseDown:e=>e.stopPropagation(),children:[(0,s.jsx)(`div`,{className:`db-modal-head`,children:(0,s.jsxs)(`div`,{className:`db-modal-head-inner`,children:[(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`h3`,{className:`db-modal-title`,children:`Add Subject`}),(0,s.jsxs)(`p`,{className:`db-modal-sub`,children:[`Department: `,(0,s.jsx)(`b`,{children:E?`General Department`:W?.name??`-`})]})]}),(0,s.jsx)(`button`,{className:`db-modal-close`,onClick:()=>C(!1),disabled:x!==null,type:`button`,"aria-label":`Close`,children:(0,s.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,children:(0,s.jsx)(`path`,{d:`M3 3l8 8M11 3L3 11`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})})})]})}),(0,s.jsx)(`div`,{className:`db-modal-body`,children:(0,s.jsx)(`div`,{className:`db-modal-card`,children:(0,s.jsx)(`div`,{className:`db-form-grid`,children:(0,s.jsxs)(`div`,{className:`db-field`,style:{gridColumn:`1 / -1`},children:[(0,s.jsxs)(`label`,{children:[`Subject Name `,(0,s.jsx)(`span`,{style:{color:`#ef4444`},children:`*`})]}),(0,s.jsx)(`input`,{placeholder:`e.g. Mathematics`,value:xe,onChange:e=>Se(e.target.value)}),(0,s.jsxs)(`label`,{className:`db-option-card`,children:[(0,s.jsx)(`input`,{type:`checkbox`,checked:E||_===c,onChange:e=>D(e.target.checked),disabled:_===c}),(0,s.jsxs)(`span`,{children:[(0,s.jsx)(`span`,{className:`db-option-title`,children:`General subject`}),(0,s.jsx)(`span`,{className:`db-option-help`,children:`Use this for common subjects like Mathematics or English that should appear for all departments.`})]})]}),(0,s.jsx)(`div`,{className:`db-help`,children:`A code will be generated automatically (e.g. SCI001).`})]})})})}),(0,s.jsxs)(`div`,{className:`db-modal-foot`,children:[(0,s.jsx)(`button`,{className:`db-btn db-btn-secondary`,onClick:()=>C(!1),disabled:x!==null,type:`button`,children:`Cancel`}),(0,s.jsx)(`button`,{className:`db-btn db-btn-primary`,onClick:Ne,disabled:x!==null,type:`button`,children:V(`subject:create`)?(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)(`span`,{className:`spinner-border spinner-border-sm`,role:`status`,style:{width:14,height:14}}),`Saving...`]}):(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:(0,s.jsx)(`path`,{d:`M3 8l3 3 7-7`,stroke:`currentColor`,strokeWidth:`1.7`,strokeLinecap:`round`,strokeLinejoin:`round`})}),`Save Subject`]})})]})]})}),ye&&O&&(0,s.jsx)(`div`,{className:`db-modal-backdrop`,onMouseDown:()=>{x||w(!1)},children:(0,s.jsxs)(`div`,{className:`db-modal`,onMouseDown:e=>e.stopPropagation(),children:[(0,s.jsx)(`div`,{className:`db-modal-head`,children:(0,s.jsxs)(`div`,{className:`db-modal-head-inner`,children:[(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`h3`,{className:`db-modal-title`,children:`Edit Subject`}),(0,s.jsx)(`p`,{className:`db-modal-sub`,children:`Update subject name and department availability.`})]}),(0,s.jsx)(`button`,{className:`db-modal-close`,onClick:()=>w(!1),disabled:x!==null,type:`button`,"aria-label":`Close`,children:(0,s.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,children:(0,s.jsx)(`path`,{d:`M3 3l8 8M11 3L3 11`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})})})]})}),(0,s.jsx)(`div`,{className:`db-modal-body`,children:(0,s.jsx)(`div`,{className:`db-modal-card`,children:(0,s.jsx)(`div`,{className:`db-form-grid`,children:(0,s.jsxs)(`div`,{className:`db-field`,style:{gridColumn:`1 / -1`},children:[(0,s.jsxs)(`label`,{children:[`Subject Name `,(0,s.jsx)(`span`,{style:{color:`#ef4444`},children:`*`})]}),(0,s.jsx)(`input`,{value:A,onChange:e=>j(e.target.value)}),(0,s.jsxs)(`label`,{className:`db-option-card`,children:[(0,s.jsx)(`input`,{type:`checkbox`,checked:M,onChange:e=>N(e.target.checked)}),(0,s.jsxs)(`span`,{children:[(0,s.jsx)(`span`,{className:`db-option-title`,children:`General subject`}),(0,s.jsx)(`span`,{className:`db-option-help`,children:`When enabled, this subject will be available to all departments.`})]})]})]})})})}),(0,s.jsxs)(`div`,{className:`db-modal-foot`,children:[(0,s.jsx)(`button`,{className:`db-btn db-btn-secondary`,onClick:()=>w(!1),disabled:x!==null,type:`button`,children:`Cancel`}),(0,s.jsx)(`button`,{className:`db-btn db-btn-primary`,onClick:Fe,disabled:x!==null,type:`button`,children:V(`subject:update:${O}`)?(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)(`span`,{className:`spinner-border spinner-border-sm`,role:`status`,style:{width:14,height:14}}),`Saving...`]}):(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:(0,s.jsx)(`path`,{d:`M3 8l3 3 7-7`,stroke:`currentColor`,strokeWidth:`1.7`,strokeLinecap:`round`,strokeLinejoin:`round`})}),`Update`]})})]})]})}),be&&(0,s.jsx)(`div`,{className:`db-modal-backdrop`,onMouseDown:()=>{x||T(!1)},children:(0,s.jsxs)(`div`,{className:`db-modal`,onMouseDown:e=>e.stopPropagation(),children:[(0,s.jsx)(`div`,{className:`db-modal-head`,children:(0,s.jsxs)(`div`,{className:`db-modal-head-inner`,children:[(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`h3`,{className:`db-modal-title`,children:`Assign Section`}),(0,s.jsxs)(`p`,{className:`db-modal-sub`,children:[`Assign `,(0,s.jsx)(`b`,{children:q}),` subject(s) to a section.`]})]}),(0,s.jsx)(`button`,{className:`db-modal-close`,onClick:()=>T(!1),disabled:x!==null,type:`button`,"aria-label":`Close`,children:(0,s.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,children:(0,s.jsx)(`path`,{d:`M3 3l8 8M11 3L3 11`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})})})]})}),(0,s.jsx)(`div`,{className:`db-modal-body`,children:(0,s.jsx)(`div`,{className:`db-modal-card`,children:(0,s.jsxs)(`div`,{className:`db-form-grid`,children:[(0,s.jsxs)(`div`,{className:`db-field`,children:[(0,s.jsxs)(`label`,{children:[`Select Section `,(0,s.jsx)(`span`,{style:{color:`#ef4444`},children:`*`})]}),(0,s.jsxs)(`select`,{value:I,onChange:e=>Ce(e.target.value),disabled:d,children:[(0,s.jsx)(`option`,{value:``,children:`Select Section`}),m.map(e=>(0,s.jsx)(`option`,{value:e.id,children:e.name},e.id))]}),(0,s.jsx)(`div`,{className:`db-help`,children:`This will update section_id for all selected subjects.`})]}),(0,s.jsxs)(`div`,{className:`db-modal-card`,style:{background:`#faf8f5`,borderRadius:14},children:[(0,s.jsx)(`div`,{style:{fontSize:12,fontWeight:900,color:`#1a1a2e`,marginBottom:10},children:`Quick actions`}),(0,s.jsxs)(`div`,{style:{display:`grid`,gap:10},children:[(0,s.jsx)(`button`,{className:`db-btn db-btn-secondary`,onClick:Q,disabled:x!==null||G.length===0,type:`button`,children:`Select All (Filtered)`}),(0,s.jsx)(`button`,{className:`db-btn db-btn-secondary`,onClick:$,disabled:x!==null||q===0,type:`button`,children:`Clear Selection`})]})]})]})})}),(0,s.jsxs)(`div`,{className:`db-modal-foot`,children:[(0,s.jsx)(`button`,{className:`db-btn db-btn-secondary`,onClick:()=>T(!1),disabled:x!==null,type:`button`,children:`Cancel`}),(0,s.jsx)(`button`,{className:`db-btn db-btn-green`,onClick:Ue,disabled:x!==null,type:`button`,children:V(`subject:assign`)?(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)(`span`,{className:`spinner-border spinner-border-sm`,role:`status`,style:{width:14,height:14}}),`Assigning...`]}):(0,s.jsxs)(s.Fragment,{children:[(0,s.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,s.jsx)(`path`,{d:`M7 8h6`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`}),(0,s.jsx)(`path`,{d:`M6.5 6.3l7 5`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,s.jsx)(`path`,{d:`M6.5 9.7l7-5`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,s.jsx)(`circle`,{cx:`6`,cy:`8`,r:`2.1`,stroke:`currentColor`,strokeWidth:`1.4`}),(0,s.jsx)(`circle`,{cx:`14`,cy:`8`,r:`2.1`,stroke:`currentColor`,strokeWidth:`1.4`})]}),`Assign Section`]})})]})]})})]})]})})]})}export{oe as default};