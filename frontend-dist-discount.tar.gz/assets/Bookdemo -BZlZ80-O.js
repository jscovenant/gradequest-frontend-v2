import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{p as t}from"./vendor-react-BhRGw7qi.js";import"./vendor-http-DXqav090.js";import{F as n}from"./index-D6TxbaCx.js";var r=e(),i=t(),a=[`School Proprietor / Owner`,`School Principal`,`Head of Academics`,`School Administrator`,`IT / Tech Coordinator`,`Other`],o=[`Primary School`,`Secondary School`,`Primary & Secondary (Combined)`,`International School`,`Tertiary Institution`],s=[`Under 200`,`200 – 500`,`500 – 1,000`,`1,000 – 2,500`,`2,500+`],c=[`9:00 AM`,`10:00 AM`,`11:00 AM`,`12:00 PM`,`2:00 PM`,`3:00 PM`,`4:00 PM`],l=[{n:1,label:`Your details`},{n:2,label:`Your school`},{n:3,label:`Pick a time`}],u=[{val:`500+`,label:`Schools onboarded`},{val:`4.9★`,label:`Avg rating`},{val:`30 min`,label:`Demo length`},{val:`Free`,label:`No commitment`}];function d(e,t=0){(0,r.useEffect)(()=>{let n=e.current;if(!n)return;let r=new IntersectionObserver(([e])=>{e.isIntersecting&&(setTimeout(()=>n.classList.add(`bd-visible`),t),r.disconnect())},{threshold:.05});return r.observe(n),()=>r.disconnect()},[e,t])}function f(){let[e,t]=(0,r.useState)(1),[f,p]=(0,r.useState)(!1),[m,h]=(0,r.useState)({}),[g,_]=(0,r.useState)(!1),[v,y]=(0,r.useState)(``),[b,x]=(0,r.useState)({firstName:``,lastName:``,email:``,phone:``,role:``,schoolName:``,schoolType:``,studentCount:``,date:``,time:``,message:``}),S=(0,r.useRef)(null),C=(0,r.useRef)(null);d(S,0),d(C,120);let w=e=>t=>x(n=>({...n,[e]:t.target.value})),T=()=>{let t={};return e===1&&(b.firstName.trim()||(t.firstName=`Required`),b.lastName.trim()||(t.lastName=`Required`),(!b.email.trim()||!b.email.includes(`@`))&&(t.email=`Valid email required`),b.phone.trim()||(t.phone=`Required`)),e===2&&(b.role||(t.role=`Select a role`),b.schoolName.trim()||(t.schoolName=`Required`),b.schoolType||(t.schoolType=`Select a type`),b.studentCount||(t.studentCount=`Select a range`)),e===3&&(b.date||(t.date=`Pick a date`),b.time||(t.time=`Pick a time`)),h(t),Object.keys(t).length===0},E=()=>{y(``),T()&&t(e=>Math.min(e+1,3))},D=()=>{h({}),y(``),t(e=>Math.max(e-1,1))},O=async()=>{if(T())try{_(!0),y(``),await n.post(`/demo-bookings`,{firstName:b.firstName,lastName:b.lastName,email:b.email,phone:b.phone,role:b.role,schoolName:b.schoolName,schoolType:b.schoolType,studentCount:b.studentCount,date:b.date,time:b.time,message:b.message}),p(!0)}catch(e){let t=e?.response?.data;if(t?.errors){let e={};t.errors.firstName&&(e.firstName=t.errors.firstName[0]),t.errors.lastName&&(e.lastName=t.errors.lastName[0]),t.errors.email&&(e.email=t.errors.email[0]),t.errors.phone&&(e.phone=t.errors.phone[0]),t.errors.role&&(e.role=t.errors.role[0]),t.errors.schoolName&&(e.schoolName=t.errors.schoolName[0]),t.errors.schoolType&&(e.schoolType=t.errors.schoolType[0]),t.errors.studentCount&&(e.studentCount=t.errors.studentCount[0]),t.errors.date&&(e.date=t.errors.date[0]),t.errors.time&&(e.time=t.errors.time[0]),t.errors.message&&(e.message=t.errors.message[0]),h(e)}else y(t?.message||`Unable to submit booking. Please try again.`)}finally{_(!1)}},k=new Date;k.setDate(k.getDate()+1);let A=k.toISOString().split(`T`)[0];return(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;0,900;1,700&family=DM+Sans:wght@300;400;500&display=swap');

        :root {
          --bd-dark:     var(--bs-dark,      #050008);
          --bd-accent:   var(--bs-secondary, rgb(255,200,87));
          --bd-magenta:  var(--bs-primary,   rgb(211,0,176));
          --bd-success:  var(--bs-success,   rgb(34,197,94));
          --bd-danger:   var(--bs-danger,    rgb(239,68,68));

          --bd-border:   rgba(255,255,255,0.08);
          --bd-surface:  rgba(255,255,255,0.04);
          --bd-muted:    rgba(255,255,255,0.35);

          --bd-accent-dim:    rgba(255,200,87,0.10);
          --bd-accent-border: rgba(255,200,87,0.28);
          --bd-accent-glow:   rgba(255,200,87,0.22);
          --bd-magenta-dim:   rgba(211,0,176,0.08);
        }

        .bd-page {
          min-height: 100vh;
          background: var(--bd-dark);
          font-family: 'DM Sans', sans-serif;
          position: relative;
          overflow: hidden;
          display: flex;
          align-items: stretch;
        }

        .bd-page::before {
          content: '';
          position: absolute; inset: 0;
          background-image: radial-gradient(circle, rgba(255,255,255,0.04) 1px, transparent 1px);
          background-size: 28px 28px;
          pointer-events: none;
          z-index: 0;
        }

        .bd-page::after {
          content: '';
          position: absolute;
          top: -120px; left: 10%;
          width: 700px; height: 400px;
          border-radius: 50%;
          background: radial-gradient(ellipse, rgba(255,200,87,0.07) 0%, transparent 70%);
          pointer-events: none;
          z-index: 0;
        }

        .bd-magenta-glow {
          position: absolute;
          bottom: -100px; right: -80px;
          width: 500px; height: 500px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(211,0,176,0.05) 0%, transparent 70%);
          pointer-events: none;
          z-index: 0;
        }

        .bd-z { position: relative; z-index: 1; width: 100%; }

        .bd-split {
          display: grid;
          grid-template-columns: 420px 1fr;
          min-height: 100vh;
        }

        @media (max-width: 960px) {
          .bd-split { grid-template-columns: 1fr; }
        }

        .bd-panel {
          background: rgba(255,255,255,0.025);
          border-right: 1px solid var(--bd-border);
          padding: 64px 48px;
          display: flex;
          flex-direction: column;
          gap: 0;
          opacity: 0;
          transform: translateX(-24px);
          transition: opacity .7s ease, transform .7s ease;
        }

        .bd-panel.bd-visible { opacity: 1; transform: translateX(0); }

        @media (max-width: 960px) {
          .bd-panel {
            border-right: none;
            border-bottom: 1px solid var(--bd-border);
            padding: 48px 32px 40px;
          }
        }

        .bd-back {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          font-size: 13px;
          font-weight: 400;
          color: var(--bd-muted);
          text-decoration: none;
          margin-bottom: 52px;
          transition: color .2s;
        }

        .bd-back:hover { color: rgba(255,255,255,0.7); }

        .bd-panel-logo {
          display: inline-flex;
          align-items: center;
          gap: 10px;
          text-decoration: none;
          margin-bottom: 36px;
        }

        .bd-panel-logo-mark {
          width: 34px; height: 34px;
          border-radius: 9px;
          background: linear-gradient(135deg, var(--bd-accent), #ffe0a0);
          display: flex; align-items: center; justify-content: center;
        }

        .bd-panel-logo-name {
          font-family: 'Playfair Display', serif;
          font-size: 18px; font-weight: 700;
          color: #fff; letter-spacing: -0.01em;
        }

        .bd-panel-eyebrow {
          font-size: 11px;
          font-weight: 500;
          letter-spacing: 0.2em;
          text-transform: uppercase;
          color: var(--bd-muted);
          margin-bottom: 12px;
        }

        .bd-panel-title {
          font-family: 'Playfair Display', serif;
          font-size: clamp(28px, 3vw, 40px);
          font-weight: 900;
          color: #fff;
          line-height: 1.1;
          margin-bottom: 16px;
        }

        .bd-panel-title em {
          font-style: italic;
          color: var(--bd-magenta);
        }

        .bd-panel-desc {
          font-size: 14.5px;
          font-weight: 300;
          color: var(--bd-muted);
          line-height: 1.8;
          margin-bottom: 48px;
        }

        .bd-steps {
          display: flex;
          flex-direction: column;
          gap: 0;
          margin-bottom: 48px;
        }

        .bd-step-row {
          display: flex;
          align-items: center;
          gap: 14px;
          padding: 10px 0;
          position: relative;
        }

        .bd-step-row:not(:last-child)::after {
          content: '';
          position: absolute;
          left: 15px; top: 44px;
          width: 1px; height: calc(100% - 14px);
          background: var(--bd-border);
        }

        .bd-step-num {
          width: 30px; height: 30px;
          border-radius: 50%;
          display: flex; align-items: center; justify-content: center;
          font-size: 12px; font-weight: 500;
          flex-shrink: 0;
          transition: background .3s, border-color .3s, color .3s;
          border: 1px solid var(--bd-border);
          color: var(--bd-muted);
          background: transparent;
        }

        .bd-step-row--active .bd-step-num {
          background: var(--bd-accent);
          border-color: var(--bd-accent);
          color: var(--bd-dark);
          box-shadow: 0 0 16px var(--bd-accent-glow);
        }

        .bd-step-row--done .bd-step-num {
          background: var(--bd-magenta-dim);
          border-color: var(--bd-magenta);
          color: var(--bd-magenta);
        }

        .bd-step-label {
          font-size: 13.5px; font-weight: 400;
          color: var(--bd-muted);
          transition: color .3s;
        }

        .bd-step-row--active .bd-step-label {
          color: rgba(255,255,255,0.9);
          font-weight: 500;
        }

        .bd-step-row--done .bd-step-label {
          color: rgba(255,255,255,0.45);
        }

        .bd-trust {
          margin-top: auto;
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 12px;
        }

        .bd-trust-item {
          background: var(--bd-surface);
          border: 1px solid var(--bd-border);
          border-radius: 10px;
          padding: 14px 16px;
        }

        .bd-trust-val {
          font-family: 'Playfair Display', serif;
          font-size: 20px; font-weight: 700;
          color: var(--bd-accent);
          line-height: 1;
          display: block;
          margin-bottom: 3px;
        }

        .bd-trust-label {
          font-size: 11px; font-weight: 300;
          color: var(--bd-muted);
          text-transform: uppercase;
          letter-spacing: 0.08em;
        }

        .bd-form-area {
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 64px 48px;
          opacity: 0;
          transform: translateY(24px);
          transition: opacity .7s ease .1s, transform .7s ease .1s;
        }

        .bd-form-area.bd-visible { opacity: 1; transform: translateY(0); }

        @media (max-width: 640px) {
          .bd-form-area { padding: 40px 24px; }
        }

        .bd-form-wrap { width: 100%; max-width: 520px; }

        .bd-form-step-label {
          font-size: 11px; font-weight: 500;
          letter-spacing: 0.18em; text-transform: uppercase;
          color: var(--bd-accent);
          margin-bottom: 8px;
          display: block;
        }

        .bd-form-title {
          font-family: 'Playfair Display', serif;
          font-size: clamp(22px, 3vw, 32px);
          font-weight: 700; color: #fff;
          line-height: 1.15;
          margin-bottom: 32px;
        }

        .bd-field { display: flex; flex-direction: column; gap: 6px; }

        .bd-label {
          font-size: 12px; font-weight: 500;
          letter-spacing: 0.08em; text-transform: uppercase;
          color: rgba(255,255,255,0.45);
        }

        .bd-input, .bd-select, .bd-textarea {
          background: rgba(255,255,255,0.04);
          border: 1px solid var(--bd-border);
          border-radius: 8px;
          padding: 12px 16px;
          font-family: 'DM Sans', sans-serif;
          font-size: 14px; font-weight: 300;
          color: rgba(255,255,255,0.88);
          outline: none;
          width: 100%;
          transition: border-color .2s, background .2s, box-shadow .2s;
          -webkit-appearance: none;
        }

        .bd-input::placeholder, .bd-textarea::placeholder {
          color: rgba(255,255,255,0.2);
        }

        .bd-input:focus, .bd-select:focus, .bd-textarea:focus {
          border-color: var(--bd-accent-border);
          background: rgba(255,200,87,0.03);
          box-shadow: 0 0 0 3px rgba(255,200,87,0.08);
        }

        .bd-input--error, .bd-select--error, .bd-textarea--error {
          border-color: rgba(239,68,68,0.5) !important;
        }

        .bd-error-msg {
          font-size: 11.5px;
          color: var(--bd-danger);
          margin-top: 2px;
        }

        .bd-select-wrap { position: relative; }

        .bd-select-wrap::after {
          content: '';
          position: absolute;
          right: 14px; top: 50%;
          transform: translateY(-50%);
          width: 0; height: 0;
          border-left: 5px solid transparent;
          border-right: 5px solid transparent;
          border-top: 5px solid rgba(255,255,255,0.3);
          pointer-events: none;
        }

        .bd-select { cursor: pointer; padding-right: 36px; }
        .bd-select option { background: #1a1a2e; color: #fff; }

        .bd-time-grid {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
        }

        .bd-time-pill {
          padding: 8px 16px;
          border: 1px solid var(--bd-border);
          border-radius: 7px;
          font-size: 13px; font-weight: 400;
          color: var(--bd-muted);
          cursor: pointer;
          background: transparent;
          transition: border-color .2s, color .2s, background .2s;
        }

        .bd-time-pill:hover {
          border-color: rgba(255,200,87,0.3);
          color: rgba(255,255,255,0.8);
        }

        .bd-time-pill--selected {
          border-color: var(--bd-accent) !important;
          background: var(--bd-accent-dim) !important;
          color: var(--bd-accent) !important;
        }

        .bd-progress-bar {
          height: 3px;
          background: var(--bd-border);
          border-radius: 2px;
          overflow: hidden;
          margin-bottom: 32px;
        }

        .bd-progress-fill {
          height: 100%;
          background: linear-gradient(90deg, var(--bd-accent), #ffe0a0);
          border-radius: 2px;
          transition: width .4s cubic-bezier(.4,0,.2,1);
        }

        .bd-btn-primary {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          padding: 14px 32px;
          background: var(--bd-accent);
          color: var(--bd-dark);
          font-family: 'DM Sans', sans-serif;
          font-size: 14.5px; font-weight: 500;
          border: none; border-radius: 8px;
          cursor: pointer;
          transition: background .2s, transform .2s, box-shadow .2s, opacity .2s;
          width: 100%;
        }

        .bd-btn-primary:hover:not(:disabled) {
          background: #ffe0a0;
          transform: translateY(-2px);
          box-shadow: 0 8px 24px var(--bd-accent-glow);
        }

        .bd-btn-primary:disabled {
          opacity: 0.7;
          cursor: not-allowed;
        }

        .bd-btn-ghost {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          padding: 14px 24px;
          background: transparent;
          color: var(--bd-muted);
          font-family: 'DM Sans', sans-serif;
          font-size: 14px; font-weight: 400;
          border: 1px solid var(--bd-border);
          border-radius: 8px;
          cursor: pointer;
          transition: background .2s, color .2s, border-color .2s;
          flex: 1;
        }

        .bd-btn-ghost:hover {
          background: var(--bd-surface);
          color: rgba(255,255,255,0.8);
          border-color: rgba(255,255,255,0.16);
        }

        .bd-success {
          text-align: center;
          padding: 40px 0;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 20px;
        }

        .bd-success-icon {
          width: 72px; height: 72px;
          border-radius: 50%;
          background: rgba(34,197,94,0.1);
          border: 1px solid rgba(34,197,94,0.25);
          display: flex; align-items: center; justify-content: center;
          color: var(--bd-success);
          animation: bd-pop .5s cubic-bezier(.34,1.56,.64,1);
        }

        @keyframes bd-pop {
          from { transform: scale(0.5); opacity: 0; }
          to   { transform: scale(1); opacity: 1; }
        }

        .bd-success-title {
          font-family: 'Playfair Display', serif;
          font-size: 28px; font-weight: 700;
          color: #fff; line-height: 1.2;
        }

        .bd-success-title em {
          font-style: italic;
          color: var(--bd-accent);
        }

        .bd-success-desc {
          font-size: 15px; font-weight: 300;
          color: var(--bd-muted); line-height: 1.8;
          max-width: 380px;
        }

        .bd-success-detail {
          background: var(--bd-surface);
          border: 1px solid var(--bd-border);
          border-radius: 12px;
          padding: 20px 24px;
          width: 100%;
          display: flex; flex-direction: column; gap: 10px;
        }

        .bd-success-row {
          display: flex; align-items: center;
          justify-content: space-between;
          font-size: 13.5px;
          gap: 12px;
        }

        .bd-success-row-label {
          color: var(--bd-muted);
          font-weight: 300;
        }

        .bd-success-row-val {
          color: rgba(255,255,255,.8);
          font-weight: 400;
          text-align: right;
        }

        .bd-server-error {
          color: var(--bd-danger);
          font-size: 12px;
          margin: 0;
          text-align: center;
        }

        /* Hover effect */
.ft-logo:hover .ft-logo-wrap {
  transform: scale(1.05);
  transition: 0.25s ease;
}/* Logo image */
.ft-logo-img {
  width: 10%;
  height: 10%;
  object-fit: contain;
  border-radius: 8px;
}



/* Hover effect */
.ft-logo:hover .ft-logo-wrap {
  transform: scale(1.05);
  transition: 0.25s ease;
}
      `}),(0,i.jsxs)(`div`,{className:`bd-page`,children:[(0,i.jsx)(`span`,{className:`bd-magenta-glow`,"aria-hidden":`true`}),(0,i.jsx)(`div`,{className:`bd-z`,children:(0,i.jsxs)(`div`,{className:`bd-split`,children:[(0,i.jsxs)(`div`,{ref:S,className:`bd-panel`,children:[(0,i.jsxs)(`a`,{href:`/`,className:`bd-back`,children:[(0,i.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:(0,i.jsx)(`path`,{d:`M13 7H1M7 1L1 7l6 6`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`,strokeLinejoin:`round`})}),`Back to site`]}),(0,i.jsx)(`a`,{href:`/`,className:`ft-logo`,"aria-label":`SchoolProfit home`,children:(0,i.jsx)(`div`,{className:`ft-logo-wrap`,children:(0,i.jsx)(`img`,{src:`/media/logo/schoolprofit-icon.svg`,alt:`SchoolProfit logo`,className:`ft-logo-img`})})}),(0,i.jsx)(`p`,{className:`bd-panel-eyebrow`,children:`Book your session`}),(0,i.jsxs)(`h1`,{className:`bd-panel-title`,children:[`See it in action.`,(0,i.jsx)(`br`,{}),(0,i.jsx)(`em`,{children:`30 minutes.`}),(0,i.jsx)(`br`,{}),`No pressure.`]}),(0,i.jsx)(`p`,{className:`bd-panel-desc`,children:`A SchoolProfit specialist will walk you through the platform live — results, fees, AI monitoring, and analytics — tailored to your school's size and needs.`}),(0,i.jsx)(`div`,{className:`bd-steps`,children:l.map(t=>(0,i.jsxs)(`div`,{className:`bd-step-row ${f||e>t.n?`bd-step-row--done`:e===t.n?`bd-step-row--active`:``}`,children:[(0,i.jsx)(`span`,{className:`bd-step-num`,children:f||e>t.n?(0,i.jsx)(`svg`,{width:`12`,height:`12`,viewBox:`0 0 12 12`,fill:`none`,children:(0,i.jsx)(`path`,{d:`M2 6l3 3 5-5`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`,strokeLinejoin:`round`})}):t.n}),(0,i.jsx)(`span`,{className:`bd-step-label`,children:t.label})]},t.n))}),(0,i.jsx)(`div`,{className:`bd-trust`,children:u.map(e=>(0,i.jsxs)(`div`,{className:`bd-trust-item`,children:[(0,i.jsx)(`span`,{className:`bd-trust-val`,children:e.val}),(0,i.jsx)(`span`,{className:`bd-trust-label`,children:e.label})]},e.label))})]}),(0,i.jsx)(`div`,{ref:C,className:`bd-form-area`,children:(0,i.jsx)(`div`,{className:`bd-form-wrap`,children:f?(0,i.jsxs)(`div`,{className:`bd-success`,children:[(0,i.jsx)(`div`,{className:`bd-success-icon`,children:(0,i.jsx)(`svg`,{width:`32`,height:`32`,viewBox:`0 0 32 32`,fill:`none`,children:(0,i.jsx)(`path`,{d:`M6 16l7 7 13-13`,stroke:`currentColor`,strokeWidth:`2.5`,strokeLinecap:`round`,strokeLinejoin:`round`})})}),(0,i.jsxs)(`h2`,{className:`bd-success-title`,children:[`You're `,(0,i.jsx)(`em`,{children:`booked in.`})]}),(0,i.jsxs)(`p`,{className:`bd-success-desc`,children:[`We've sent a confirmation to`,` `,(0,i.jsx)(`strong`,{style:{color:`rgba(255,255,255,.7)`},children:b.email}),`. A specialist will reach out within 1 business hour to confirm the slot.`]}),(0,i.jsxs)(`div`,{className:`bd-success-detail w-100`,children:[(0,i.jsxs)(`div`,{className:`bd-success-row`,children:[(0,i.jsx)(`span`,{className:`bd-success-row-label`,children:`Name`}),(0,i.jsxs)(`span`,{className:`bd-success-row-val`,children:[b.firstName,` `,b.lastName]})]}),(0,i.jsxs)(`div`,{className:`bd-success-row`,children:[(0,i.jsx)(`span`,{className:`bd-success-row-label`,children:`School`}),(0,i.jsx)(`span`,{className:`bd-success-row-val`,children:b.schoolName})]}),(0,i.jsxs)(`div`,{className:`bd-success-row`,children:[(0,i.jsx)(`span`,{className:`bd-success-row-label`,children:`Date`}),(0,i.jsx)(`span`,{className:`bd-success-row-val`,children:b.date})]}),(0,i.jsxs)(`div`,{className:`bd-success-row`,children:[(0,i.jsx)(`span`,{className:`bd-success-row-label`,children:`Time`}),(0,i.jsxs)(`span`,{className:`bd-success-row-val`,children:[b.time,` (WAT)`]})]})]}),(0,i.jsx)(`a`,{href:`/`,className:`bd-btn-primary`,style:{textDecoration:`none`},children:`Back to SchoolProfit`})]}):(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(`div`,{className:`bd-progress-bar`,children:(0,i.jsx)(`div`,{className:`bd-progress-fill`,style:{width:`${e/3*100}%`}})}),e===1&&(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(`span`,{className:`bd-form-step-label`,children:`Step 1 of 3`}),(0,i.jsx)(`h2`,{className:`bd-form-title`,children:`Tell us about yourself`}),(0,i.jsxs)(`div`,{className:`d-flex flex-column gap-4`,children:[(0,i.jsxs)(`div`,{className:`row g-3`,children:[(0,i.jsx)(`div`,{className:`col-6`,children:(0,i.jsxs)(`div`,{className:`bd-field`,children:[(0,i.jsx)(`label`,{className:`bd-label`,children:`First name`}),(0,i.jsx)(`input`,{className:`bd-input ${m.firstName?`bd-input--error`:``}`,type:`text`,placeholder:`Adaeze`,value:b.firstName,onChange:w(`firstName`)}),m.firstName&&(0,i.jsx)(`span`,{className:`bd-error-msg`,children:m.firstName})]})}),(0,i.jsx)(`div`,{className:`col-6`,children:(0,i.jsxs)(`div`,{className:`bd-field`,children:[(0,i.jsx)(`label`,{className:`bd-label`,children:`Last name`}),(0,i.jsx)(`input`,{className:`bd-input ${m.lastName?`bd-input--error`:``}`,type:`text`,placeholder:`Okonkwo`,value:b.lastName,onChange:w(`lastName`)}),m.lastName&&(0,i.jsx)(`span`,{className:`bd-error-msg`,children:m.lastName})]})})]}),(0,i.jsxs)(`div`,{className:`bd-field`,children:[(0,i.jsx)(`label`,{className:`bd-label`,children:`Work email`}),(0,i.jsx)(`input`,{className:`bd-input ${m.email?`bd-input--error`:``}`,type:`email`,placeholder:`you@yourschool.edu.ng`,value:b.email,onChange:w(`email`)}),m.email&&(0,i.jsx)(`span`,{className:`bd-error-msg`,children:m.email})]}),(0,i.jsxs)(`div`,{className:`bd-field`,children:[(0,i.jsx)(`label`,{className:`bd-label`,children:`Phone / WhatsApp`}),(0,i.jsx)(`input`,{className:`bd-input ${m.phone?`bd-input--error`:``}`,type:`tel`,placeholder:`+234 800 000 0000`,value:b.phone,onChange:w(`phone`)}),m.phone&&(0,i.jsx)(`span`,{className:`bd-error-msg`,children:m.phone})]}),(0,i.jsxs)(`button`,{className:`bd-btn-primary`,onClick:E,type:`button`,children:[`Continue`,(0,i.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:(0,i.jsx)(`path`,{d:`M1 7h12M7 1l6 6-6 6`,stroke:`currentColor`,strokeWidth:`1.7`,strokeLinecap:`round`,strokeLinejoin:`round`})})]})]})]}),e===2&&(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(`span`,{className:`bd-form-step-label`,children:`Step 2 of 3`}),(0,i.jsx)(`h2`,{className:`bd-form-title`,children:`About your school`}),(0,i.jsxs)(`div`,{className:`d-flex flex-column gap-4`,children:[(0,i.jsxs)(`div`,{className:`bd-field`,children:[(0,i.jsx)(`label`,{className:`bd-label`,children:`Your role`}),(0,i.jsx)(`div`,{className:`bd-select-wrap`,children:(0,i.jsxs)(`select`,{className:`bd-select ${m.role?`bd-select--error`:``}`,value:b.role,onChange:w(`role`),children:[(0,i.jsx)(`option`,{value:``,children:`Select your role…`}),a.map(e=>(0,i.jsx)(`option`,{value:e,children:e},e))]})}),m.role&&(0,i.jsx)(`span`,{className:`bd-error-msg`,children:m.role})]}),(0,i.jsxs)(`div`,{className:`bd-field`,children:[(0,i.jsx)(`label`,{className:`bd-label`,children:`School name`}),(0,i.jsx)(`input`,{className:`bd-input ${m.schoolName?`bd-input--error`:``}`,type:`text`,placeholder:`Greenfield Model School`,value:b.schoolName,onChange:w(`schoolName`)}),m.schoolName&&(0,i.jsx)(`span`,{className:`bd-error-msg`,children:m.schoolName})]}),(0,i.jsxs)(`div`,{className:`bd-field`,children:[(0,i.jsx)(`label`,{className:`bd-label`,children:`School type`}),(0,i.jsx)(`div`,{className:`bd-select-wrap`,children:(0,i.jsxs)(`select`,{className:`bd-select ${m.schoolType?`bd-select--error`:``}`,value:b.schoolType,onChange:w(`schoolType`),children:[(0,i.jsx)(`option`,{value:``,children:`Select type…`}),o.map(e=>(0,i.jsx)(`option`,{value:e,children:e},e))]})}),m.schoolType&&(0,i.jsx)(`span`,{className:`bd-error-msg`,children:m.schoolType})]}),(0,i.jsxs)(`div`,{className:`bd-field`,children:[(0,i.jsx)(`label`,{className:`bd-label`,children:`Number of students`}),(0,i.jsx)(`div`,{className:`bd-select-wrap`,children:(0,i.jsxs)(`select`,{className:`bd-select ${m.studentCount?`bd-select--error`:``}`,value:b.studentCount,onChange:w(`studentCount`),children:[(0,i.jsx)(`option`,{value:``,children:`Select range…`}),s.map(e=>(0,i.jsx)(`option`,{value:e,children:e},e))]})}),m.studentCount&&(0,i.jsx)(`span`,{className:`bd-error-msg`,children:m.studentCount})]}),(0,i.jsxs)(`div`,{className:`d-flex gap-3`,children:[(0,i.jsxs)(`button`,{className:`bd-btn-ghost`,onClick:D,type:`button`,children:[(0,i.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:(0,i.jsx)(`path`,{d:`M13 7H1M7 1L1 7l6 6`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`,strokeLinejoin:`round`})}),`Back`]}),(0,i.jsxs)(`button`,{className:`bd-btn-primary`,onClick:E,type:`button`,children:[`Continue`,(0,i.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:(0,i.jsx)(`path`,{d:`M1 7h12M7 1l6 6-6 6`,stroke:`currentColor`,strokeWidth:`1.7`,strokeLinecap:`round`,strokeLinejoin:`round`})})]})]})]})]}),e===3&&(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(`span`,{className:`bd-form-step-label`,children:`Step 3 of 3`}),(0,i.jsx)(`h2`,{className:`bd-form-title`,children:`Pick a date & time`}),(0,i.jsxs)(`div`,{className:`d-flex flex-column gap-4`,children:[(0,i.jsxs)(`div`,{className:`bd-field`,children:[(0,i.jsx)(`label`,{className:`bd-label`,children:`Preferred date`}),(0,i.jsx)(`input`,{className:`bd-input ${m.date?`bd-input--error`:``}`,type:`date`,min:A,value:b.date,onChange:w(`date`),style:{colorScheme:`dark`}}),m.date&&(0,i.jsx)(`span`,{className:`bd-error-msg`,children:m.date})]}),(0,i.jsxs)(`div`,{className:`bd-field`,children:[(0,i.jsx)(`label`,{className:`bd-label`,children:`Preferred time (WAT)`}),(0,i.jsx)(`div`,{className:`bd-time-grid`,children:c.map(e=>(0,i.jsx)(`button`,{type:`button`,className:`bd-time-pill ${b.time===e?`bd-time-pill--selected`:``}`,onClick:()=>{x(t=>({...t,time:e})),h(e=>({...e,time:void 0}))},children:e},e))}),m.time&&(0,i.jsx)(`span`,{className:`bd-error-msg`,children:m.time})]}),(0,i.jsxs)(`div`,{className:`bd-field`,children:[(0,i.jsxs)(`label`,{className:`bd-label`,children:[`Anything we should know?`,` `,(0,i.jsx)(`span`,{style:{opacity:.4},children:`(optional)`})]}),(0,i.jsx)(`textarea`,{className:`bd-textarea`,rows:3,placeholder:`e.g. We currently use Excel for results and want to see how migration works…`,value:b.message,onChange:w(`message`),style:{resize:`vertical`}}),m.message&&(0,i.jsx)(`span`,{className:`bd-error-msg`,children:m.message})]}),v&&(0,i.jsx)(`p`,{className:`bd-server-error`,children:v}),(0,i.jsxs)(`div`,{className:`d-flex gap-3`,children:[(0,i.jsxs)(`button`,{className:`bd-btn-ghost`,onClick:D,type:`button`,children:[(0,i.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:(0,i.jsx)(`path`,{d:`M13 7H1M7 1L1 7l6 6`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`,strokeLinejoin:`round`})}),`Back`]}),(0,i.jsxs)(`button`,{className:`bd-btn-primary`,onClick:O,disabled:g,type:`button`,children:[g?`Submitting...`:`Book my demo`,!g&&(0,i.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:(0,i.jsx)(`path`,{d:`M1 7h12M7 1l6 6-6 6`,stroke:`currentColor`,strokeWidth:`1.7`,strokeLinecap:`round`,strokeLinejoin:`round`})})]})]}),(0,i.jsx)(`p`,{style:{fontSize:12,color:`var(--bd-muted)`,textAlign:`center`,fontWeight:300},children:`No credit card. No commitment. Cancel any time.`})]})]})]})})})]})})]})]})}export{f as default};