import{i as e}from"./rolldown-runtime-CWU8vmCm.js";import{Ut as t}from"./vendor-misc-OZLc0tLq.js";import{p as n}from"./vendor-react-BhRGw7qi.js";import{i as r,r as i}from"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as a,E as o,P as s,d as c,f as l,l as u,u as d}from"./index-D6TxbaCx.js";var f=e(t(),1),p=e(r(),1),m=n(),h=e=>{if(!e)return`—`;let t=new Date(e);return Number.isNaN(t.getTime())?e:t.toLocaleString()},g=e=>{if(!e)return`—`;let t=new Date(e);return Number.isNaN(t.getTime())?`—`:`${t.getFullYear()}-${String(t.getMonth()+1).padStart(2,`0`)}-${String(t.getDate()).padStart(2,`0`)}`},_=e=>e&&e.trim().split(/\s+/).slice(0,2).map(e=>e[0]?.toUpperCase()).join(``)||`SC`;function v(){let e=new Date().getHours();return e<12?`Good morning`:e<17?`Good afternoon`:`Good evening`}function y(e){if(!e)return null;try{return encodeURI(e)}catch{return e}}function b(e){return e?/^https?:\/\//i.test(e)?y(e):y(`${(s.defaults.baseURL||``).replace(/\/+$/,``)}/${e.replace(/^\/+/,``)}`):null}async function x(){let e={name:`Your School`,logoUrl:null};try{let t=(await s.get(`/get-settings`))?.data;return{name:t?.school_settings?.schoolName||t?.school_settings?.school_name||t?.school_settings?.name||e.name,logoUrl:b(t?.school_settings?.logo_url||t?.school_settings?.logoUrl||t?.school_settings?.logo||null)}}catch{return e}}function S(){let{showSuccess:e,showError:t}=u(),[n,r]=(0,f.useState)(!1),[y,b]=(0,f.useState)(!0),[S,C]=(0,f.useState)(!1),[w,T]=(0,f.useState)(!1),[E,D]=(0,f.useState)({name:`Your School`,logoUrl:null}),[O,k]=(0,f.useState)([]),[ee,te]=(0,f.useState)([]),[A,j]=(0,f.useState)([]),[M,N]=(0,f.useState)(``),[P,F]=(0,f.useState)(``),[I,L]=(0,f.useState)(1),[R,z]=(0,f.useState)(``),[B,V]=(0,f.useState)(1),[H,U]=(0,f.useState)([]),[W,G]=(0,f.useState)(!1),[K,q]=(0,f.useState)(null),J=(0,f.useRef)(null),ne=e=>({msg:e?.response?.data?.message||e?.message||`Something went wrong. Please try again.`,errors:e?.response?.data?.errors}),Y=async n=>{try{await navigator.clipboard.writeText(n),e(`Copied to clipboard.`)}catch{t(`Copy failed. Please copy manually.`)}},X=e=>{q(e),G(!0)},Z=()=>{G(!1),q(null)},re=async()=>{b(!0);try{let[e,t,n,r]=await Promise.all([s.get(`/all-result-pins`),s.get(`/get-terms`),s.get(`/get-academic-sessions`),x()]);k(Array.isArray(e.data)?e.data:[]),te(Array.isArray(t.data)?t.data:[]),j(Array.isArray(n.data)?n.data:[]),D(r);let i=t.data?.[0]?.name,a=n.data?.[0]?.name;N(e=>e||i||``),F(e=>e||a||``)}catch(e){console.error(e),t(`Failed to load Result PIN data. Please refresh.`)}finally{b(!1)}};(0,f.useEffect)(()=>{re()},[]);let Q=async()=>{T(!0);try{let t=await s.get(`/all-result-pins`);k(Array.isArray(t.data)?t.data:[]),e(`PIN list refreshed.`)}catch(e){console.error(e),t(`Failed to refresh PIN list.`)}finally{T(!1)}},ie=async n=>{n.preventDefault(),C(!0),U([]);try{let t={term:M,session:P,max_uses:Number(I),expires_at:R||null,quantity:Number(B)},n=await s.post(`/result-pins`,t);e(n?.data?.message||`PIN(s) generated successfully.`),U(Array.isArray(n?.data?.pins)?n.data.pins:[]),await Q()}catch(e){console.error(e);let{msg:n,errors:r}=ne(e);if(r&&typeof r==`object`){let e=r[Object.keys(r)[0]];t((Array.isArray(e)?e[0]:String(e))||n)}else t(n)}finally{C(!1)}},$=(0,f.useMemo)(()=>O,[O]),ae=()=>{if(!H.length)return;let e=H.join(`
`),t=new Blob([e],{type:`text/plain;charset=utf-8`}),n=URL.createObjectURL(t),r=document.createElement(`a`);r.href=n,r.download=`result-pins_${M}_${P}.txt`.replace(/\s+/g,`_`),r.click(),URL.revokeObjectURL(n)},oe=async()=>{if(!(!J.current||!K))try{let t=await(0,p.default)(J.current,{scale:3,useCORS:!0,backgroundColor:null}),n=t.toDataURL(`image/png`),r=new i({orientation:`landscape`,unit:`pt`,format:`a4`}),a=r.internal.pageSize.getWidth(),o=r.internal.pageSize.getHeight(),s=a-56,c=o-56,l=t.width,u=t.height,d=Math.min(s/l,c/u),f=l*d,m=u*d,h=(a-f)/2,g=(o-m)/2;r.addImage(n,`PNG`,h,g,f,m);let _=(E?.name||`school`).replace(/[^\w]+/g,`_`),v=(K.term||`term`).replace(/[^\w]+/g,`_`),y=(K.session||`session`).replace(/[^\w]+/g,`_`);r.save(`WAEC_style_PIN_${_}_${v}_${y}_${K.pin}.pdf`),e(`Card downloaded as PDF.`)}catch(e){console.error(e),t(`Failed to download card. If logo is missing, enable CORS on the backend for images.`)}};return(0,m.jsxs)(m.Fragment,{children:[(0,m.jsx)(`style`,{children:`
        /* ===== Result Pins (Modern SaaS template) ===== */
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');
        .rp-main{
          background: #F8FAFC;
          min-height: 100vh;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          padding: 24px 28px 0;
        }

        .rp-hero{
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 18px;
          padding: 32px 36px;
          position: relative;
          overflow: hidden;
          margin-bottom: 24px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
        }
        .rp-glow{ position:absolute; top:-60px; right:-60px; width:320px; height:320px; border-radius:50%;
          background: radial-gradient(circle, rgba(217,119,6,0.15) 0%, transparent 65%); pointer-events:none; }
        .rp-glow2{ position:absolute; bottom:-50px; left:25%; width:220px; height:220px; border-radius:50%;
          background: radial-gradient(circle, rgba(37,99,235,0.10) 0%, transparent 70%); pointer-events:none; }

        .rp-hero-inner{ position:relative; z-index:1; display:flex; align-items:flex-start; justify-content:space-between; gap:18px; flex-wrap:wrap; }

        .rp-badge{
          display:inline-flex; align-items:center; gap:7px;
          font-size:11.5px; font-weight:700; letter-spacing:0.04em; text-transform:uppercase;
          color:#FBBF24;
          background: rgba(217,119,6,0.20);
          border:1px solid rgba(217,119,6,0.35);
          border-radius:100px;
          padding: 4px 12px;
          margin-bottom: 12px;
        }
        .rp-dot{ width:6px; height:6px; border-radius:50%; background:#10B981; animation: rpPulse 2s ease infinite; }
        @keyframes rpPulse { 0%,100%{ opacity:1; transform:scale(1);} 50%{ opacity:.4; transform:scale(1.5);} }

        .rp-title{
          font-size: 26px;
          font-weight: 800;
          color: #fff;
          margin: 0 0 8px;
          line-height:1.1;
        }
        .rp-title em{ font-style: normal; color:#FBBF24; }
        .rp-sub{
          color:#CBD5E1; font-size: 13.5px; line-height:1.6;
          margin:0;
          max-width: 620px;
        }

        .rp-hero-card{
          background: rgba(255,255,255,0.08);
          border: 1px solid rgba(255,255,255,0.15);
          backdrop-filter: blur(8px);
          border-radius: 14px;
          padding: 18px 20px;
          min-width: 240px;
        }
        .rp-mini-row{ display:flex; align-items:center; justify-content:space-between; gap:12px; }
        .rp-mini-label{ font-size:12px; color:#CBD5E1; font-weight:400; }
        .rp-mini-val{ font-size:18px; color:#FBBF24; font-weight:800; }

        .rp-grid{
          display:grid;
          grid-template-columns: 420px 1fr;
          gap: 20px;
          margin-bottom: 24px;
        }
        @media (max-width: 991.98px){
          .rp-grid{ grid-template-columns: 1fr; }
        }

        .rp-panel{
          background: #fff;
          border: 1px solid #E2E8F0;
          border-radius: 16px;
          overflow: hidden;
          box-shadow: 0 4px 16px rgba(15,39,68,0.03);
        }
        .rp-panel-head{
          display:flex; align-items:center; justify-content:space-between;
          padding: 18px 20px;
          border-bottom: 1px solid #E2E8F0;
          gap: 10px;
          flex-wrap: wrap;
        }
        .rp-panel-title{
          font-size:16px; font-weight:800; color:#0F2744; margin:0;
        }
        .rp-panel-sub{ font-size:12px; color:#64748B; margin:0; }

        .rp-icon{
          width: 38px; height: 38px; border-radius: 10px;
          display:flex; align-items:center; justify-content:center;
          background: rgba(217,119,6,0.12);
          color: #D97706;
          flex-shrink:0;
        }

        .rp-body{ padding: 20px; }

        .rp-btn{
          display:inline-flex; align-items:center; gap:8px;
          padding: 9px 16px;
          font-size: 13px;
          font-weight: 700;
          border-radius: 10px;
          border: 1px solid #E2E8F0;
          background: #F1F5F9;
          color: #0F2744;
          cursor: pointer;
          transition: all .2s ease;
          text-decoration:none;
          user-select:none;
          white-space:nowrap;
        }
        .rp-btn:hover{ background:#E2E8F0; transform: translateY(-1px); }
        .rp-btn:disabled{ opacity:.55; cursor:not-allowed; transform:none; }

        .rp-btn-primary{
          background:#0F2744; color:#fff; border: none;
        }
        .rp-btn-primary:hover{ background:#1E3A8A; color:#fff; }
        .rp-btn-gold{
          background:#D97706; color:#FFFFFF; border: none;
        }
        .rp-btn-gold:hover{ background:#B45309; color:#FFFFFF; }

        .rp-field label{ font-size:12px; font-weight:700; color:#0F2744; margin-bottom:6px; }
        .rp-field .form-control, .rp-field .form-select{
          border-radius: 10px;
          border: 1px solid #E2E8F0;
          padding: 10px 14px;
          font-size: 13px;
          color: #0F2744;
          font-weight: 600;
        }
        .rp-field .form-control:focus, .rp-field .form-select:focus{
          border-color: #D97706;
          box-shadow: 0 0 0 3px rgba(217,119,6,0.12);
        }
        .rp-help{ font-size: 12px; color:#64748B; margin-top: 6px; }

        .rp-table{
          width:100%;
          border-collapse: separate;
          border-spacing: 0;
        }
        .rp-table th{
          padding: 12px 16px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color:#64748B;
          background:#F8FAFC;
          border-bottom: 1px solid #E2E8F0;
          text-align:left;
          white-space:nowrap;
        }
        .rp-table td{
          padding: 12px 14px;
          font-size: 13.5px;
          color:#4a4a5a;
          border-bottom: 1px solid rgba(0,0,0,0.06);
          vertical-align: middle;
        }
        .rp-mono{ font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; }
        .rp-pill{
          display:inline-flex; align-items:center; gap:6px;
          padding: 4px 10px;
          border-radius: 999px;
          font-size: 12px;
          border: 1px solid rgba(0,0,0,0.06);
          background: #f8fafc;
          color:#1a1a2e;
        }
        .rp-actions{ display:flex; justify-content:flex-end; gap:8px; flex-wrap:wrap; }

        .rp-empty{
          padding: 40px 16px;
          text-align: center;
          color: #b5a090;
          font-size: 13.5px;
        }

        /* ===== PIN Card Modal ===== */
        .rp-modal-backdrop{
          position: fixed;
          inset: 0;
          background: rgba(15,23,42,0.55);
          display:flex;
          align-items:center;
          justify-content:center;
          padding: 18px;
          z-index: 2000;
        }
        .rp-modal{
          width: min(760px, 100%);
          background: #fff;
          border-radius: 16px;
          border: 1px solid rgba(0,0,0,0.08);
          overflow: hidden;
          box-shadow: 0 18px 60px rgba(0,0,0,0.25);
        }
        .rp-modal-head{
          display:flex;
          align-items:center;
          justify-content:space-between;
          gap: 12px;
          padding: 14px 16px;
          border-bottom: 1px solid rgba(0,0,0,0.06);
          background: #faf8f5;
        }
        .rp-modal-title{
          font-family:"Lora", serif;
          font-weight:700;
          color:#1a1a2e;
          margin:0;
          font-size: 15px;
        }
        .rp-x{
          width: 36px; height: 36px;
          border-radius: 10px;
          border: 1px solid rgba(0,0,0,0.10);
          background: #fff;
          cursor:pointer;
          display:flex; align-items:center; justify-content:center;
        }

        .rp-card{
          padding: 18px;
          background: #f5f1eb;
        }

        /* ===== WAEC-like scratch card styling (inspired) ===== */
        .rp-card-inner{
          border-radius: 16px;
          overflow:hidden;
          position:relative;
          padding: 18px;
          color:#fff;
        }

        .rp-waec{
          background: linear-gradient(135deg, #0b3b2e 0%, #0f172a 55%, #0b3b2e 100%);
          border: 1px solid rgba(255,255,255,0.14);
          box-shadow: 0 16px 50px rgba(0,0,0,0.24);
        }

        .rp-waec::before{
          content:"";
          position:absolute; inset:0;
          background-image:
            radial-gradient(circle at 20% 30%, rgba(201,168,76,0.14) 0%, transparent 55%),
            radial-gradient(circle at 80% 60%, rgba(201,168,76,0.10) 0%, transparent 60%),
            repeating-linear-gradient(45deg,
              rgba(255,255,255,0.04) 0px,
              rgba(255,255,255,0.04) 2px,
              transparent 2px,
              transparent 8px
            );
          mix-blend-mode: overlay;
          opacity: .75;
          pointer-events:none;
        }

        .rp-card-top{
          position:relative;
          z-index:1;
          display:flex; align-items:center; justify-content:space-between; gap: 12px; flex-wrap:wrap;
          padding-bottom: 10px;
          border-bottom: 1px dashed rgba(232,201,122,0.35);
          margin-bottom: 14px;
        }

        .rp-school{
          display:flex; align-items:center; gap: 10px; min-width: 240px;
        }
        .rp-logo{
          width: 46px; height: 46px;
          border-radius: 14px;
          background: rgba(255,255,255,0.10);
          border: 1px solid rgba(255,255,255,0.16);
          display:flex; align-items:center; justify-content:center;
          overflow:hidden;
          flex-shrink:0;
        }
        .rp-logo img{ width:100%; height:100%; object-fit: cover; }
        .rp-school-name{
          font-weight: 700;
          font-family: "Lora", serif;
          line-height: 1.1;
          margin:0;
          font-size: 16px;
        }
        .rp-card-meta{
          color: rgba(255,255,255,0.65);
          font-size: 12px;
          font-weight: 300;
          margin: 2px 0 0;
        }

        .rp-card-badge{
          display:inline-flex; align-items:center; gap:6px;
          padding: 6px 12px;
          border-radius: 999px;
          background: rgba(232,201,122,0.14);
          border: 1px solid rgba(232,201,122,0.28);
          color: #ffd98a;
          font-size: 11px;
          letter-spacing: .10em;
          text-transform: uppercase;
          white-space: nowrap;
        }

        .rp-pin-box{
          position:relative; z-index:1;
          margin-top: 6px;
          background: rgba(0,0,0,0.22);
          border: 1px solid rgba(255,255,255,0.12);
          border-radius: 14px;
          padding: 14px;
          display:flex;
          align-items:flex-start;
          justify-content:space-between;
          gap: 12px;
          flex-wrap: wrap;
        }
        .rp-pin-label{
          font-size: 11px;
          color: rgba(255,255,255,0.70);
          letter-spacing: .12em;
          text-transform: uppercase;
          margin-bottom: 6px;
        }
        .rp-pin{
          font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
          font-size: 24px;
          font-weight: 900;
          letter-spacing: 0.18em;
          margin: 0;
          color: #fff;
          user-select: text;
        }
        .rp-pin-sub{
          font-size: 12px;
          color: rgba(255,255,255,0.70);
          font-weight: 300;
          margin-top: 6px;
        }

        .rp-scratch{
          margin-top: 10px;
          position: relative;
          z-index: 1;
          background: linear-gradient(135deg, rgba(255,255,255,0.16), rgba(255,255,255,0.06));
          border: 1px solid rgba(255,255,255,0.14);
          border-radius: 14px;
          padding: 12px 14px;
          display:flex;
          align-items:center;
          justify-content:space-between;
          gap: 12px;
          flex-wrap:wrap;
        }
        .rp-scratch-title{
          font-size: 11px;
          letter-spacing: .14em;
          text-transform: uppercase;
          color: rgba(255,255,255,0.78);
        }
        .rp-scratch-sub{
          font-size: 12px;
          color: rgba(232,201,122,0.92);
          font-weight: 600;
          margin-top: 2px;
        }

        .rp-card-btns{ display:flex; gap:8px; align-items:center; flex-wrap:wrap; }

        .rp-card-btn{
          display:inline-flex; align-items:center; gap:7px;
          padding: 10px 14px;
          border-radius: 12px;
          border: 1px solid rgba(255,255,255,0.16);
          background: rgba(255,255,255,0.08);
          color:#fff;
          cursor:pointer;
          transition: transform .2s, background .2s;
          user-select:none;
          white-space: nowrap;
        }
        .rp-card-btn:hover{ background: rgba(255,255,255,0.12); transform: translateY(-1px); }

        .rp-card-btn--gold{
          background: #c9a84c;
          color: #0f172a;
          border: none;
        }
        .rp-card-btn--gold:hover{ background: #e8c97a; }

        /* Make modal footer buttons consistent */
        .rp-modal-footer{
          margin-top: 12px;
          display:flex;
          justify-content: space-between;
          align-items:center;
          gap: 10px;
          flex-wrap: wrap;
        }

        @media (max-width: 575.98px){
          .rp-main{ padding: 18px 14px 0; }
        }
      `}),(0,m.jsx)(l,{sidebarOpen:n,setSidebarOpen:r}),(0,m.jsx)(a,{title:`Generate PINs`}),(0,m.jsx)(`div`,{className:`container-fluid`,children:(0,m.jsxs)(`div`,{className:`row`,children:[(0,m.jsx)(c,{sidebarOpen:n,setSidebarOpen:r}),(0,m.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto db-main rp-main`,children:[y&&(0,m.jsx)(o,{message:`Loading result PINs...`}),(0,m.jsxs)(`div`,{className:`rp-hero`,children:[(0,m.jsx)(`div`,{className:`rp-glow`,"aria-hidden":`true`}),(0,m.jsx)(`div`,{className:`rp-glow2`,"aria-hidden":`true`}),(0,m.jsxs)(`div`,{className:`rp-hero-inner`,children:[(0,m.jsxs)(`div`,{children:[(0,m.jsxs)(`div`,{className:`rp-badge`,children:[(0,m.jsx)(`span`,{className:`rp-dot`}),`Result PINs — `,E?.name||`School`]}),(0,m.jsxs)(`h1`,{className:`rp-title`,children:[v(),`, `,(0,m.jsx)(`em`,{children:`Admin.`})]}),(0,m.jsxs)(`p`,{className:`rp-sub`,children:[`Generate secure result access PINs by `,(0,m.jsx)(`b`,{children:`Term`}),` and `,(0,m.jsx)(`b`,{children:`Session`}),`, set usage limits, and export a WAEC-style PIN card as PDF.`]})]}),(0,m.jsxs)(`div`,{className:`rp-hero-card d-none d-md-block`,children:[(0,m.jsxs)(`div`,{className:`rp-mini-row`,children:[(0,m.jsx)(`span`,{className:`rp-mini-label`,children:`Current PINs`}),(0,m.jsx)(`span`,{className:`rp-mini-val`,children:O.length})]}),(0,m.jsx)(`div`,{style:{height:10}}),(0,m.jsxs)(`div`,{className:`rp-mini-row`,children:[(0,m.jsx)(`span`,{className:`rp-mini-label`,children:`Default max uses`}),(0,m.jsx)(`span`,{className:`rp-mini-val`,children:I})]}),(0,m.jsx)(`div`,{style:{height:12}}),(0,m.jsxs)(`button`,{type:`button`,className:`rp-btn rp-btn-gold`,onClick:Q,disabled:w||y,title:`Refresh list`,children:[(0,m.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,children:[(0,m.jsx)(`path`,{d:`M12 7A5 5 0 112 7`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,m.jsx)(`path`,{d:`M12 3v4h-4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),w?`Refreshing…`:`Refresh`]})]})]})]}),(0,m.jsxs)(`div`,{className:`rp-grid`,children:[(0,m.jsxs)(`div`,{className:`rp-panel`,children:[(0,m.jsx)(`div`,{className:`rp-panel-head`,children:(0,m.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:10},children:[(0,m.jsx)(`div`,{className:`rp-icon`,style:{"--pi":`#fef3c7`,"--pc":`#b45309`},children:(0,m.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,m.jsx)(`path`,{d:`M8 1.8a3.2 3.2 0 013.2 3.2v1.4h.8a2.2 2.2 0 012.2 2.2v3.8a2.2 2.2 0 01-2.2 2.2H4a2.2 2.2 0 01-2.2-2.2V8.6A2.2 2.2 0 014 6.4h.8V5A3.2 3.2 0 018 1.8Z`,stroke:`currentColor`,strokeWidth:`1.25`,strokeLinejoin:`round`}),(0,m.jsx)(`path`,{d:`M6.2 6.4V5a1.8 1.8 0 113.6 0v1.4`,stroke:`currentColor`,strokeWidth:`1.25`,strokeLinecap:`round`})]})}),(0,m.jsxs)(`div`,{children:[(0,m.jsx)(`p`,{className:`rp-panel-title`,children:`Generate PINs`}),(0,m.jsx)(`p`,{className:`rp-panel-sub`,children:`Choose Term & Session, set Max Uses, optional Expiry`})]})]})}),(0,m.jsxs)(`div`,{className:`rp-body`,children:[(0,m.jsxs)(`form`,{onSubmit:ie,children:[(0,m.jsxs)(`div`,{className:`rp-field mb-3`,children:[(0,m.jsx)(`label`,{className:`form-label`,children:`Term`}),(0,m.jsxs)(`select`,{className:`form-select`,value:M,onChange:e=>N(e.target.value),required:!0,children:[(0,m.jsx)(`option`,{value:``,disabled:!0,children:`Select term`}),ee.map(e=>(0,m.jsx)(`option`,{value:e.name,children:e.name},e.id))]})]}),(0,m.jsxs)(`div`,{className:`rp-field mb-3`,children:[(0,m.jsx)(`label`,{className:`form-label`,children:`Academic Session`}),(0,m.jsxs)(`select`,{className:`form-select`,value:P,onChange:e=>F(e.target.value),required:!0,children:[(0,m.jsx)(`option`,{value:``,disabled:!0,children:`Select session`}),A.map(e=>(0,m.jsx)(`option`,{value:e.name,children:e.name},e.id))]}),(0,m.jsx)(`div`,{className:`rp-help`,children:`Backend returns only current session(s) (is_current = 1).`})]}),(0,m.jsxs)(`div`,{className:`row g-3`,children:[(0,m.jsxs)(`div`,{className:`col-md-6 rp-field`,children:[(0,m.jsx)(`label`,{className:`form-label`,children:`Max Uses`}),(0,m.jsx)(`input`,{type:`number`,min:1,max:10,className:`form-control`,value:I,onChange:e=>L(Number(e.target.value)),required:!0}),(0,m.jsx)(`div`,{className:`rp-help`,children:`Allowed range: 1–10`})]}),(0,m.jsxs)(`div`,{className:`col-md-6 rp-field`,children:[(0,m.jsx)(`label`,{className:`form-label`,children:`Quantity`}),(0,m.jsx)(`input`,{type:`number`,min:1,max:100,className:`form-control`,value:B,onChange:e=>V(Number(e.target.value)),required:!0}),(0,m.jsx)(`div`,{className:`rp-help`,children:`Max 100 at a time`})]})]}),(0,m.jsxs)(`div`,{className:`rp-field mt-3`,children:[(0,m.jsx)(`label`,{className:`form-label`,children:`Expiry Date (optional)`}),(0,m.jsx)(`input`,{type:`date`,className:`form-control`,value:R,onChange:e=>z(e.target.value)}),(0,m.jsxs)(`div`,{className:`rp-help`,children:[`Must be a future date (backend validates `,(0,m.jsx)(`code`,{children:`after:today`}),`).`]})]}),(0,m.jsxs)(`div`,{className:`d-flex gap-2 mt-4 flex-wrap`,children:[(0,m.jsx)(`button`,{type:`submit`,className:`rp-btn rp-btn-primary`,disabled:S||y,children:S?(0,m.jsxs)(m.Fragment,{children:[(0,m.jsx)(`span`,{className:`spinner-border spinner-border-sm`}),`Generating…`]}):(0,m.jsxs)(m.Fragment,{children:[(0,m.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,m.jsx)(`path`,{d:`M6.2 7.2a2.6 2.6 0 115.2 0v2.1`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,m.jsx)(`path`,{d:`M3.2 9.3h9.6a1.8 1.8 0 011.8 1.8v1.9a1.8 1.8 0 01-1.8 1.8H3.2a1.8 1.8 0 01-1.8-1.8v-1.9a1.8 1.8 0 011.8-1.8Z`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinejoin:`round`}),(0,m.jsx)(`circle`,{cx:`8`,cy:`12`,r:`1`,fill:`currentColor`})]}),`Generate PINs`]})}),(0,m.jsxs)(`button`,{type:`button`,className:`rp-btn`,disabled:S||y,onClick:()=>{U([]),L(1),V(1),z(``)},children:[(0,m.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:(0,m.jsx)(`path`,{d:`M3 4h10M6 4V2.8h4V4M5 6v7m3-7v7m3-7v7M4.5 4l.8 10.2A1.2 1.2 0 006.5 15h3a1.2 1.2 0 001.2-1.1L11.5 4`,stroke:`currentColor`,strokeWidth:`1.2`,strokeLinecap:`round`})}),`Clear`]}),(0,m.jsxs)(`button`,{type:`button`,className:`rp-btn rp-btn-gold`,onClick:Q,disabled:w||y,children:[(0,m.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,children:[(0,m.jsx)(`path`,{d:`M12 7A5 5 0 112 7`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,m.jsx)(`path`,{d:`M12 3v4h-4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),`Refresh list`]})]}),(0,m.jsx)(`div`,{className:`mt-3`,style:{fontSize:12.5,color:`#9a8a7a`},children:(0,m.jsxs)(`span`,{className:`rp-pill`,children:[(0,m.jsx)(`b`,{style:{color:`#1a1a2e`},children:`Note:`}),` Old pins are deleted automatically if session changes (backend logic).`]})})]}),(0,m.jsxs)(`div`,{style:{marginTop:16},children:[(0,m.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,gap:10},children:[(0,m.jsxs)(`div`,{children:[(0,m.jsx)(`div`,{className:`rp-panel-title`,style:{fontSize:14},children:`Newly Generated PINs`}),(0,m.jsx)(`div`,{className:`rp-panel-sub`,children:`Copy, download TXT, or open a WAEC-style card.`})]}),(0,m.jsxs)(`div`,{style:{display:`flex`,gap:8,flexWrap:`wrap`},children:[(0,m.jsxs)(`button`,{type:`button`,className:`rp-btn`,disabled:!H.length,onClick:()=>Y(H.join(`
`)),title:`Copy all`,children:[(0,m.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,m.jsx)(`rect`,{x:`5`,y:`5`,width:`9`,height:`9`,rx:`2`,stroke:`currentColor`,strokeWidth:`1.2`}),(0,m.jsx)(`rect`,{x:`2`,y:`2`,width:`9`,height:`9`,rx:`2`,stroke:`currentColor`,strokeWidth:`1.2`,opacity:`.6`})]}),`Copy all`]}),(0,m.jsxs)(`button`,{type:`button`,className:`rp-btn`,disabled:!H.length,onClick:ae,title:`Download .txt`,children:[(0,m.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,m.jsx)(`path`,{d:`M8 2v7`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,m.jsx)(`path`,{d:`M5 7l3 3 3-3`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`,strokeLinejoin:`round`}),(0,m.jsx)(`path`,{d:`M3 12v2a1 1 0 001 1h8a1 1 0 001-1v-2`,stroke:`currentColor`,strokeWidth:`1.2`,strokeLinecap:`round`})]}),`TXT`]})]})]}),H.length?(0,m.jsx)(`div`,{style:{marginTop:10},children:H.map(e=>(0,m.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,gap:10,padding:`10px 12px`,border:`1px solid rgba(0,0,0,0.06)`,borderRadius:12,background:`#faf8f5`,marginBottom:8},children:[(0,m.jsxs)(`div`,{style:{minWidth:0},children:[(0,m.jsx)(`div`,{className:`rp-mono`,style:{fontWeight:800,letterSpacing:`.08em`,color:`#1a1a2e`},children:e}),(0,m.jsxs)(`div`,{style:{fontSize:12,color:`#9a8a7a`,marginTop:2},children:[M,` · `,P,` · Max uses `,I]})]}),(0,m.jsxs)(`div`,{className:`rp-actions`,children:[(0,m.jsx)(`button`,{type:`button`,className:`rp-btn`,onClick:()=>Y(e),children:`Copy`}),(0,m.jsx)(`button`,{type:`button`,className:`rp-btn rp-btn-gold`,onClick:()=>X({pin:e,term:M,session:P,max_uses:I,uses:0,expires_at:R||null,created_at:null}),children:`View card`})]})]},e))}):(0,m.jsx)(`div`,{className:`rp-empty`,style:{padding:`18px 12px`},children:`No newly generated PINs yet. Generate above to display them here.`})]})]})]}),(0,m.jsxs)(`div`,{className:`rp-panel`,children:[(0,m.jsxs)(`div`,{className:`rp-panel-head`,children:[(0,m.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:10},children:[(0,m.jsx)(`div`,{className:`rp-icon`,style:{"--pi":`#dbeafe`,"--pc":`#1e40af`},children:(0,m.jsx)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:(0,m.jsx)(`path`,{d:`M3 4h10M3 8h10M3 12h10`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`})})}),(0,m.jsxs)(`div`,{children:[(0,m.jsx)(`p`,{className:`rp-panel-title`,children:`All Result PINs`}),(0,m.jsx)(`p`,{className:`rp-panel-sub`,children:`Includes Term & Session each PIN was created for`})]})]}),(0,m.jsx)(`button`,{type:`button`,className:`rp-btn`,onClick:Q,disabled:w||y,children:w?(0,m.jsxs)(m.Fragment,{children:[(0,m.jsx)(`span`,{className:`spinner-border spinner-border-sm`}),`Refreshing…`]}):(0,m.jsxs)(m.Fragment,{children:[(0,m.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,children:[(0,m.jsx)(`path`,{d:`M12 7A5 5 0 112 7`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,m.jsx)(`path`,{d:`M12 3v4h-4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),`Refresh`]})})]}),(0,m.jsx)(`div`,{style:{overflowX:`auto`},children:$.length===0?(0,m.jsx)(`div`,{className:`rp-empty`,children:`No PINs found for this school yet. Generate a batch to begin.`}):(0,m.jsxs)(`table`,{className:`rp-table`,children:[(0,m.jsx)(`thead`,{children:(0,m.jsxs)(`tr`,{children:[(0,m.jsx)(`th`,{children:`PIN`}),(0,m.jsx)(`th`,{children:`Term`}),(0,m.jsx)(`th`,{children:`Session`}),(0,m.jsx)(`th`,{children:`Uses`}),(0,m.jsx)(`th`,{children:`Expires`}),(0,m.jsx)(`th`,{children:`Created`}),(0,m.jsx)(`th`,{style:{textAlign:`right`},children:`Action`})]})}),(0,m.jsx)(`tbody`,{children:$.map(e=>{let t=e.uses??0;return(0,m.jsxs)(`tr`,{children:[(0,m.jsx)(`td`,{className:`rp-mono`,style:{fontWeight:800,letterSpacing:`.06em`},children:e.pin}),(0,m.jsx)(`td`,{children:e.term}),(0,m.jsx)(`td`,{children:e.session}),(0,m.jsx)(`td`,{children:(0,m.jsxs)(`span`,{className:`rp-pill`,children:[t,`/`,e.max_uses]})}),(0,m.jsx)(`td`,{children:e.expires_at?g(e.expires_at):`—`}),(0,m.jsx)(`td`,{children:h(e.created_at)}),(0,m.jsx)(`td`,{children:(0,m.jsxs)(`div`,{className:`rp-actions`,children:[(0,m.jsx)(`button`,{type:`button`,className:`rp-btn`,onClick:()=>Y(e.pin),children:`Copy`}),(0,m.jsx)(`button`,{type:`button`,className:`rp-btn rp-btn-gold`,onClick:()=>X({pin:e.pin,term:e.term,session:e.session,max_uses:e.max_uses,uses:e.uses??0,expires_at:e.expires_at??null,created_at:e.created_at??null}),children:`View card`})]})})]},e.id)})})]})}),(0,m.jsx)(`div`,{className:`rp-body`,style:{paddingTop:12},children:(0,m.jsxs)(`div`,{style:{fontSize:12.5,color:`#9a8a7a`},children:[(0,m.jsx)(`b`,{style:{color:`#1a1a2e`},children:`Backend rules:`}),` Quantity 1–100 · Max uses 1–10 · Expiry must be after today · Term & Session stored as strings.`]})})]})]}),(0,m.jsx)(d,{})]})]})}),W&&K&&(0,m.jsx)(`div`,{className:`rp-modal-backdrop`,role:`dialog`,"aria-modal":`true`,onClick:e=>{e.target===e.currentTarget&&Z()},children:(0,m.jsxs)(`div`,{className:`rp-modal`,children:[(0,m.jsxs)(`div`,{className:`rp-modal-head`,children:[(0,m.jsx)(`p`,{className:`rp-modal-title`,children:`Result PIN Card`}),(0,m.jsx)(`button`,{className:`rp-x`,onClick:Z,"aria-label":`Close`,children:(0,m.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,children:(0,m.jsx)(`path`,{d:`M3 3l8 8M11 3L3 11`,stroke:`#1a1a2e`,strokeWidth:`1.6`,strokeLinecap:`round`})})})]}),(0,m.jsxs)(`div`,{className:`rp-card`,children:[(0,m.jsxs)(`div`,{className:`rp-card-inner rp-waec`,ref:J,children:[(0,m.jsxs)(`div`,{className:`rp-card-top`,children:[(0,m.jsxs)(`div`,{className:`rp-school`,children:[(0,m.jsxs)(`div`,{className:`rp-logo`,"aria-label":`School logo`,children:[E.logoUrl?(0,m.jsx)(`img`,{src:E.logoUrl,alt:`${E.name} logo`,onError:e=>{e.currentTarget.style.display=`none`}}):null,!E.logoUrl&&(0,m.jsx)(`span`,{style:{fontWeight:900,color:`#ffd98a`},children:_(E.name)})]}),(0,m.jsxs)(`div`,{children:[(0,m.jsx)(`p`,{className:`rp-school-name`,children:E.name}),(0,m.jsxs)(`p`,{className:`rp-card-meta`,children:[K.term,` · `,K.session,K.expires_at?` · Expires ${g(K.expires_at)}`:``]})]})]}),(0,m.jsxs)(`div`,{className:`rp-card-badge`,children:[(0,m.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,m.jsx)(`path`,{d:`M8 1.8a3.2 3.2 0 013.2 3.2v1.4h.8a2.2 2.2 0 012.2 2.2v3.8a2.2 2.2 0 01-2.2 2.2H4a2.2 2.2 0 01-2.2-2.2V8.6A2.2 2.2 0 014 6.4h.8V5A3.2 3.2 0 018 1.8Z`,stroke:`currentColor`,strokeWidth:`1.15`,strokeLinejoin:`round`}),(0,m.jsx)(`path`,{d:`M6.2 6.4V5a1.8 1.8 0 113.6 0v1.4`,stroke:`currentColor`,strokeWidth:`1.15`,strokeLinecap:`round`})]}),`Result access card`]})]}),(0,m.jsxs)(`div`,{className:`rp-pin-box`,children:[(0,m.jsxs)(`div`,{children:[(0,m.jsx)(`div`,{className:`rp-pin-label`,children:`PIN`}),(0,m.jsx)(`p`,{className:`rp-pin`,children:K.pin}),(0,m.jsxs)(`div`,{className:`rp-pin-sub`,children:[`Term/Session: `,(0,m.jsx)(`b`,{style:{color:`#ffd98a`},children:K.term}),` ·`,` `,(0,m.jsx)(`b`,{style:{color:`#ffd98a`},children:K.session}),(0,m.jsx)(`br`,{}),`Uses:`,` `,(0,m.jsx)(`b`,{style:{color:`#ffd98a`},children:K.uses??0}),` /`,` `,(0,m.jsx)(`b`,{style:{color:`#ffd98a`},children:K.max_uses}),K.created_at?` · Created ${h(K.created_at)}`:``]})]}),(0,m.jsxs)(`div`,{className:`rp-card-btns`,children:[(0,m.jsxs)(`button`,{type:`button`,className:`rp-card-btn rp-card-btn--gold`,onClick:()=>Y(K.pin),children:[(0,m.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,m.jsx)(`rect`,{x:`5`,y:`5`,width:`9`,height:`9`,rx:`2`,stroke:`currentColor`,strokeWidth:`1.2`}),(0,m.jsx)(`rect`,{x:`2`,y:`2`,width:`9`,height:`9`,rx:`2`,stroke:`currentColor`,strokeWidth:`1.2`,opacity:`.7`})]}),`Copy PIN`]}),(0,m.jsxs)(`button`,{type:`button`,className:`rp-card-btn`,onClick:()=>Y(`${E.name}\nPIN: ${K.pin}\n${K.term} · ${K.session}\nMax uses: ${K.max_uses}`),title:`Copy card details`,children:[(0,m.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,m.jsx)(`path`,{d:`M3 3h7a2 2 0 012 2v8H5a2 2 0 01-2-2V3Z`,stroke:`currentColor`,strokeWidth:`1.2`}),(0,m.jsx)(`path`,{d:`M12 6h1a2 2 0 012 2v5a1 1 0 01-1 1h-3`,stroke:`currentColor`,strokeWidth:`1.2`,strokeLinecap:`round`})]}),`Copy details`]}),(0,m.jsxs)(`button`,{type:`button`,className:`rp-card-btn`,onClick:oe,title:`Download card as PDF`,children:[(0,m.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,m.jsx)(`path`,{d:`M8 2v7`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,m.jsx)(`path`,{d:`M5 7l3 3 3-3`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`,strokeLinejoin:`round`}),(0,m.jsx)(`path`,{d:`M3 12v2a1 1 0 001 1h8a1 1 0 001-1v-2`,stroke:`currentColor`,strokeWidth:`1.2`,strokeLinecap:`round`})]}),`Download PDF`]})]})]}),(0,m.jsxs)(`div`,{className:`rp-scratch`,children:[(0,m.jsxs)(`div`,{children:[(0,m.jsx)(`div`,{className:`rp-scratch-title`,children:`Scratch panel`}),(0,m.jsx)(`div`,{className:`rp-scratch-sub`,children:`Keep this PIN confidential`})]}),(0,m.jsxs)(`div`,{style:{fontSize:12,color:`rgba(255,255,255,0.78)`},children:[`Max uses: `,(0,m.jsx)(`b`,{style:{color:`#ffd98a`},children:K.max_uses}),K.expires_at?` · Expires: ${g(K.expires_at)}`:``]})]})]}),(0,m.jsx)(`div`,{className:`rp-modal-footer`,children:(0,m.jsx)(`button`,{className:`rp-btn`,onClick:Z,children:`Close`})})]})]})})]})}export{S as default};