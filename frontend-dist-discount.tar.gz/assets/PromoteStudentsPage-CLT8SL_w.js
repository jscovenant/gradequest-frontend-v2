import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{p as t}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as n,E as r,P as i,d as a,f as o,l as s,u as c}from"./index-D6TxbaCx.js";var l=e(),u=t();function d(){let e=new Date().getHours();return e<12?`Good morning`:e<17?`Good afternoon`:`Good evening`}function f(){let{showSuccess:e,showError:t}=s(),[f,m]=(0,l.useState)(!1),[h,g]=(0,l.useState)(!0),[_,v]=(0,l.useState)(!1),[y,b]=(0,l.useState)(!1),[x,S]=(0,l.useState)(``),[C,w]=(0,l.useState)([]),[T,E]=(0,l.useState)([]),[D,O]=(0,l.useState)(``),[k,A]=(0,l.useState)(``),[j,M]=(0,l.useState)([]),[N,P]=(0,l.useState)([]),[F,I]=(0,l.useState)(``),L=String(x).toLowerCase()===`teacher`,R=(0,l.useMemo)(()=>!!D,[D]),z=(0,l.useMemo)(()=>{let e=Number(D),t=Number(k);return!!D&&!!k&&e>0&&t>0&&e!==t&&N.length>0&&!y},[D,k,N,y]),B=(0,l.useMemo)(()=>{let e=F.trim().toLowerCase();return e?j.filter(t=>`${t.surname} ${t.firstname}`.toLowerCase().includes(e)||(t.reg_no||``).toLowerCase().includes(e)||(t.class_name||``).toLowerCase().includes(e)):j},[j,F]),V=(0,l.useMemo)(()=>{if(B.length===0)return!1;let e=new Set(N);return B.every(t=>e.has(t.id))},[B,N]),H=(0,l.useMemo)(()=>{let e=j.length,t=B.length,n=N.length;return{totalLoaded:e,totalVisible:t,selected:n,selectable:t,completion:e>0?Math.round(n/Math.max(1,e)*100):0}},[j.length,B.length,N.length]);(0,l.useEffect)(()=>{g(!0),i.get(`/getclasses`).then(e=>{S((e.data?.user_role||``).toString());let t=e.data?.from_classes||[],n=e.data?.all_classes||[];w(t),E(n),!D&&t.length===1&&O(String(t[0].id))}).catch(e=>{console.error(e),t(`Failed to load classes.`)}).finally(()=>g(!1))},[]),(0,l.useEffect)(()=>{D&&k&&D===k&&A(``)},[D,k]),(0,l.useEffect)(()=>{if(!D){M([]),P([]);return}(async()=>{v(!0);try{M((await i.get(`/students-by-class`,{params:{class_id:Number(D)}})).data||[]),P([])}catch(e){console.error(e),t(e?.response?.data?.message||`Failed to load students for that class.`),M([]),P([])}finally{v(!1)}})()},[D]);let U=e=>{P(t=>t.includes(e)?t.filter(t=>t!==e):[...t,e])},W=()=>{let e=B.map(e=>e.id),t=new Set(N);V?P(N.filter(t=>!e.includes(t))):(e.forEach(e=>t.add(e)),P(Array.from(t)))},G=()=>P([]),K=async()=>{if(!z)return;let n=Number(D),r=Number(k);b(!0);try{e((await i.post(`/promote-students`,{from_class:n,to_class:r,student_ids:N}))?.data?.message||`Students promoted successfully.`),M((await i.get(`/students-by-class`,{params:{class_id:n}})).data||[]),P([])}catch(e){console.error(e),t(e?.response?.data?.message||`Failed to promote students.`)}finally{b(!1)}};return(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`style`,{children:`
/* ===== Uses the same template language as AdminDashboard ===== */
.db-main{
  background: var(--bs-body-bg, #f5f1eb);
  min-height: 100vh;
  font-family: "DM Sans", system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
  padding: 28px 28px 0;
}
.db-hero{
  background:#0f172a;
  border-radius:16px;
  padding:32px 36px;
  position:relative;
  overflow:hidden;
  margin-bottom:22px;
  border:1px solid rgba(255,255,255,0.06);
}
.db-hero::before{
  content:"";
  position:absolute; inset:0;
  background-image: radial-gradient(circle, rgba(255,255,255,0.045) 1px, transparent 1px);
  background-size:24px 24px;
  pointer-events:none;
}
.db-hero-glow{
  position:absolute; top:-60px; right:-60px;
  width:320px; height:320px; border-radius:50%;
  background: radial-gradient(circle, rgba(201,168,76,0.12) 0%, transparent 65%);
  pointer-events:none;
}
.db-hero-glow2{
  position:absolute; bottom:-40px; left:25%;
  width:220px; height:220px; border-radius:50%;
  background: radial-gradient(circle, rgba(99,102,241,0.10) 0%, transparent 70%);
  pointer-events:none;
}
.db-hero-inner{ position:relative; z-index:1; display:flex; align-items:center; justify-content:space-between; gap:28px; flex-wrap:wrap; }

.db-session-badge{
  display:inline-flex; align-items:center; gap:7px;
  font-size:11px; font-weight:500; letter-spacing:0.12em; text-transform:uppercase;
  color:#e8c97a; background: rgba(201,168,76,0.10);
  border:1px solid rgba(201,168,76,0.22);
  border-radius:999px; padding:4px 12px; margin-bottom:12px;
}
.db-session-dot{ width:6px; height:6px; border-radius:50%; background:#22c55e; animation:dbPulse 2s ease infinite; }
@keyframes dbPulse{ 0%,100%{opacity:1; transform:scale(1);} 50%{opacity:.4; transform:scale(1.5);} }

.db-greeting{
  font-family:"Lora", Georgia, serif;
  font-size: clamp(22px, 2.5vw, 32px);
  font-weight:700; color:#fff; line-height:1.1; margin-bottom:8px;
}
.db-greeting em{ font-style:italic; color:#e8c97a; }
.db-hero-sub{ font-size:13.5px; font-weight:300; color:#94a3b8; line-height:1.7; max-width:560px; margin-bottom:18px; }

.db-hero-btns{ display:flex; gap:10px; flex-wrap:wrap; }
.db-btn-gold{
  display:inline-flex; align-items:center; gap:7px;
  padding:10px 18px;
  font-size:13px; font-weight:600;
  color:#0f172a; background:#c9a84c; border:none;
  border-radius:10px; cursor:pointer;
  transition: background .2s, transform .2s;
  text-decoration:none; white-space:nowrap;
}
.db-btn-gold:hover{ background:#e8c97a; transform: translateY(-1px); }
.db-btn-outline{
  display:inline-flex; align-items:center; gap:7px;
  padding:10px 18px;
  font-size:13px; font-weight:500;
  color: rgba(255,255,255,0.78);
  background:transparent;
  border:1px solid rgba(255,255,255,0.16);
  border-radius:10px; cursor:pointer;
  transition: background .2s, border-color .2s, color .2s;
}
.db-btn-outline:hover{ background: rgba(255,255,255,0.06); border-color: rgba(255,255,255,0.28); color:#fff; }

.db-hero-stat-card{
  background: rgba(255,255,255,0.05);
  border:1px solid rgba(255,255,255,0.09);
  backdrop-filter: blur(8px);
  border-radius:12px;
  padding:18px 20px;
  min-width: 240px;
}
.db-hero-stat-item{ display:flex; align-items:center; justify-content:space-between; gap:14px; }
.db-hero-stat-label{ font-size:12px; font-weight:300; color:#94a3b8; }
.db-hero-stat-val{ font-family:"Lora", serif; font-size:18px; font-weight:700; color:#fff; }
.db-hero-stat-sep{ height:1px; background: rgba(255,255,255,0.06); margin:10px 0; }

.db-stats{
  display:grid;
  grid-template-columns: repeat(4, 1fr);
  gap:16px;
  margin-bottom: 18px;
}
@media (max-width: 1199.98px){ .db-stats{ grid-template-columns: repeat(2, 1fr);} }
@media (max-width: 575.98px){ .db-stats{ grid-template-columns: 1fr;} }

.db-stat{
  background:#fff;
  border:1px solid #ede8e0;
  border-radius:14px;
  padding:22px 20px;
  position:relative;
  overflow:hidden;
  transition: box-shadow .25s, transform .25s;
}
.db-stat:hover{ box-shadow: 0 8px 28px rgba(0,0,0,0.08); transform: translateY(-3px); }
.db-stat::before{
  content:""; position:absolute; top:0; left:0; right:0; height:3px;
  background: var(--sc, #b45309);
  transform: scaleX(0); transform-origin:left;
  transition: transform .3s ease;
}
.db-stat:hover::before{ transform: scaleX(1); }
.db-stat-head{ display:flex; align-items:flex-start; justify-content:space-between; margin-bottom:14px; }
.db-stat-icon{
  width:42px; height:42px; border-radius:10px;
  background: var(--si, #fef3c7);
  color: var(--sc, #b45309);
  display:flex; align-items:center; justify-content:center;
}
.db-stat-label{ font-size:12px; font-weight:400; color:#9a8a7a; margin-bottom:5px; letter-spacing:.03em; }
.db-stat-val{ font-family:"Lora", Georgia, serif; font-size:28px; font-weight:700; color:#1a1a2e; line-height:1; }
.db-stat-footer{
  display:flex; align-items:center; gap:6px;
  margin-top:12px; padding-top:12px;
  border-top:1px solid rgba(0,0,0,0.06);
  font-size:12px; color:#9a8a7a;
}
.db-stat-trend{ color:#22c55e; font-weight:600; }

.db-panel{
  background:#fff;
  border:1px solid #ede8e0;
  border-radius:14px;
  overflow:hidden;
  margin-bottom: 22px;
}
.db-panel-head{
  display:flex; align-items:center; justify-content:space-between;
  padding:18px 20px;
  border-bottom:1px solid rgba(0,0,0,0.06);
  gap:12px;
}
.db-panel-title-group{ display:flex; align-items:center; gap:12px; }
.db-panel-icon{
  width:36px; height:36px; border-radius:9px;
  display:flex; align-items:center; justify-content:center;
  background: var(--pi, #fef3c7);
  color: var(--pc, #b45309);
  flex-shrink:0;
}
.db-panel-title{
  font-family:"Lora", serif;
  font-size:16px; font-weight:700;
  color:#1a1a2e; margin:0;
}
.db-panel-sub{ font-size:11.5px; font-weight:300; color:#9a8a7a; margin:0; }

.db-refresh-btn{
  display:inline-flex; align-items:center; gap:6px;
  padding:7px 14px;
  font-size:12px; font-weight:500;
  color:#7a6a5a;
  background:#f5f1eb;
  border:1px solid #e5ddd3;
  border-radius:7px;
  cursor:pointer;
  transition: background .2s;
}
.db-refresh-btn:hover{ background:#ede8e0; }
.db-refresh-btn:disabled{ opacity:.55; cursor:not-allowed; }

.db-toolbar{
  padding: 14px 20px;
  display:flex; align-items:flex-end; justify-content:space-between;
  flex-wrap:wrap; gap:12px;
}
.db-fields{
  display:grid;
  grid-template-columns: repeat(3, minmax(220px, 1fr));
  gap:12px;
  width:100%;
}
@media (max-width: 991.98px){ .db-fields{ grid-template-columns: 1fr; } }
.db-field-label{ font-size:12px; font-weight:700; color:#1a1a2e; margin-bottom:6px; }
.db-help{ font-size:12px; color:#9a8a7a; margin-top:6px; }
.db-select, .db-input{
  border:1px solid #e5ddd3;
  background:#fff;
  border-radius:10px;
  padding:10px 12px;
  font-size:13px;
  color:#1a1a2e;
  outline:none;
  min-height: 40px;
  width:100%;
}
.db-input:focus, .db-select:focus{
  border-color: rgba(201,168,76,0.7);
  box-shadow: 0 0 0 3px rgba(201,168,76,0.15);
}

.db-actions{
  display:flex; gap:10px; flex-wrap:wrap; align-items:center;
}
.db-mini-btn{
  display:inline-flex; align-items:center; justify-content:center;
  gap:6px;
  border-radius:10px;
  padding:10px 14px;
  font-size:12.5px;
  font-weight:700;
  border:1px solid #e5ddd3;
  background:#f5f1eb;
  color:#7a6a5a;
  cursor:pointer;
  transition: background .2s, transform .2s;
  min-height: 40px;
  white-space: nowrap;
}
.db-mini-btn:hover{ background:#ede8e0; transform: translateY(-1px); }
.db-mini-btn:disabled{ opacity:.55; cursor:not-allowed; transform:none; }

.db-mini-btn--g{ background: rgba(34,197,94,0.12); border-color: rgba(34,197,94,0.25); color:#15803d; }
.db-mini-btn--r{ background: rgba(244,63,94,0.10); border-color: rgba(244,63,94,0.22); color:#be123c; }
.db-mini-btn--p{ background: rgba(99,102,241,0.12); border-color: rgba(99,102,241,0.22); color:#4338ca; }

.db-table{
  width:100%;
  border-collapse:collapse;
}
.db-table th{
  padding:10px 16px;
  font-size:11px;
  font-weight:600;
  letter-spacing:0.1em;
  text-transform:uppercase;
  color:#9a8a7a;
  background:#faf8f5;
  border-bottom:1px solid rgba(0,0,0,0.06);
  text-align:left;
  white-space:nowrap;
}
.db-table td{
  padding:13px 16px;
  font-size:13.5px;
  color:#4a4a5a;
  border-bottom:1px solid rgba(0,0,0,0.06);
  vertical-align:middle;
}
.db-table tbody tr{ transition: background .15s; }
.db-table tbody tr:hover{ background:#faf8f5; }

.db-pill{
  display:inline-flex;
  align-items:center;
  gap:6px;
  padding:4px 10px;
  border-radius:999px;
  font-size:12.5px;
  font-weight:700;
}
.db-pill--info{ background: rgba(30,64,175,0.10); color:#1e40af; }
.db-pill--gold{ background: rgba(180,83,9,0.10); color:#b45309; }
.db-pill--muted{ background: rgba(148,163,184,0.18); color:#64748b; }

.db-empty{
  padding:46px 16px;
  text-align:center;
  color:#b5a090;
  font-size:13.5px;
}
.db-skeleton{
  height: 14px;
  border-radius: 7px;
  background: linear-gradient(90deg, #f0ebe3 25%, #e8e0d5 50%, #f0ebe3 75%);
  background-size: 200% 100%;
  animation: dbSkeleton 1.4s ease infinite;
}
@keyframes dbSkeleton { from { background-position: 200% 0; } to { background-position: -200% 0; } }
@keyframes dbSpin { to { transform: rotate(360deg); } }
      `}),(0,u.jsx)(o,{sidebarOpen:f,setSidebarOpen:m}),(0,u.jsx)(n,{title:`Promote Student`}),(0,u.jsx)(`div`,{className:`container-fluid`,children:(0,u.jsxs)(`div`,{className:`row`,children:[(0,u.jsx)(a,{sidebarOpen:f}),(0,u.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto db-main`,children:[h&&(0,u.jsx)(r,{message:`Loading promotion tool...`}),(0,u.jsxs)(`div`,{className:`db-hero`,children:[(0,u.jsx)(`div`,{className:`db-hero-glow`,"aria-hidden":`true`}),(0,u.jsx)(`div`,{className:`db-hero-glow2`,"aria-hidden":`true`}),(0,u.jsxs)(`div`,{className:`db-hero-inner`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsxs)(`div`,{className:`db-session-badge`,children:[(0,u.jsx)(`span`,{className:`db-session-dot`}),`Promotion ·`,` `,(0,u.jsx)(`span`,{style:{color:`#94a3b8`},children:D?`From class selected`:`Pick a class`}),` `,`·`,` `,(0,u.jsx)(`span`,{style:{color:`#94a3b8`},children:N.length>0?`${N.length} selected`:`No selection`})]}),(0,u.jsxs)(`h1`,{className:`db-greeting`,children:[d(),`, `,(0,u.jsxs)(`em`,{children:[L?`Teacher`:`Admin`,`.`]})]}),(0,u.jsx)(`p`,{className:`db-hero-sub`,children:`Promote students from one class to another in bulk. From and To classes must be different. Use search + “Select Visible” for fast selection.`}),(0,u.jsxs)(`div`,{className:`db-hero-btns`,children:[(0,u.jsx)(`button`,{className:`db-btn-gold`,onClick:K,disabled:!z,title:D?k?D===k?`To Class must be different`:N.length===0?`Select at least one student`:`Promote selected students`:`Select To Class`:`Select From Class`,children:y?(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`span`,{style:{width:14,height:14,borderRadius:`50%`,border:`2px solid rgba(15,23,42,0.35)`,borderTopColor:`#0f172a`,display:`inline-block`,animation:`dbSpin 0.8s linear infinite`}}),`Promoting…`]}):(0,u.jsxs)(u.Fragment,{children:[(0,u.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,u.jsx)(`path`,{d:`M6 10l4-4`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`}),(0,u.jsx)(`path`,{d:`M8.5 5H11v2.5`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`,strokeLinejoin:`round`}),(0,u.jsx)(`path`,{d:`M3.5 12.5V4.5a2 2 0 012-2h7`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`})]}),`Promote Selected`]})}),(0,u.jsxs)(`button`,{className:`db-btn-outline`,onClick:W,disabled:!R||_||B.length===0,children:[(0,u.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:(0,u.jsx)(`path`,{d:`M3 8l3 3 7-7`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`,strokeLinejoin:`round`})}),V?`Unselect Visible`:`Select Visible`]}),(0,u.jsxs)(`button`,{className:`db-btn-outline`,onClick:G,disabled:N.length===0,children:[(0,u.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:(0,u.jsx)(`path`,{d:`M5 5l6 6M11 5L5 11`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})}),`Clear`]})]})]}),(0,u.jsxs)(`div`,{className:`db-hero-stat-card d-none d-md-block`,children:[(0,u.jsx)(`div`,{style:{fontSize:11,fontWeight:700,letterSpacing:`0.14em`,textTransform:`uppercase`,color:`#c9a84c`,marginBottom:10},children:`Quick glance`}),(0,u.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,u.jsx)(`span`,{className:`db-hero-stat-label`,children:`Loaded`}),(0,u.jsx)(`span`,{className:`db-hero-stat-val`,children:H.totalLoaded})]}),(0,u.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,u.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,u.jsx)(`span`,{className:`db-hero-stat-label`,children:`Visible`}),(0,u.jsx)(`span`,{className:`db-hero-stat-val`,children:H.totalVisible})]}),(0,u.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,u.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,u.jsx)(`span`,{className:`db-hero-stat-label`,children:`Selected`}),(0,u.jsx)(`span`,{className:`db-hero-stat-val`,children:H.selected})]}),(0,u.jsxs)(`div`,{style:{marginTop:12,paddingTop:12,borderTop:`1px solid rgba(255,255,255,0.06)`},children:[(0,u.jsxs)(`div`,{style:{fontSize:12,color:`#94a3b8`},children:[`Completion: `,(0,u.jsxs)(`b`,{style:{color:`#fff`},children:[H.completion,`%`]})]}),(0,u.jsxs)(`div`,{style:{fontSize:12,color:`#94a3b8`},children:[`Role: `,(0,u.jsx)(`b`,{style:{color:`#fff`},children:L?`Teacher`:`Admin`})]})]})]})]})]}),(0,u.jsx)(`div`,{className:`db-stats`,children:[{title:`Students Loaded`,value:H.totalLoaded,color:`#1e40af`,bg:`#dbeafe`,hint:`current from-class list`},{title:`Visible`,value:H.totalVisible,color:`#065f46`,bg:`#d1fae5`,hint:`after search filter`},{title:`Selected`,value:H.selected,color:`#b45309`,bg:`#fef3c7`,hint:`ready to promote`},{title:`Completion`,value:`${H.completion}%`,color:`#7c3aed`,bg:`#ede9fe`,hint:`selection ratio`}].map((e,t)=>{let n=[(0,u.jsxs)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 20 20`,fill:`none`,children:[(0,u.jsx)(`circle`,{cx:`8`,cy:`6`,r:`3`,stroke:`currentColor`,strokeWidth:`1.5`}),(0,u.jsx)(`path`,{d:`M2 18c0-3.314 2.686-6 6-6`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`}),(0,u.jsx)(`circle`,{cx:`15`,cy:`10`,r:`2.5`,stroke:`currentColor`,strokeWidth:`1.4`})]},`i1`),(0,u.jsxs)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 20 20`,fill:`none`,children:[(0,u.jsx)(`path`,{d:`M3 10h14`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`}),(0,u.jsx)(`path`,{d:`M6 6h8`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`}),(0,u.jsx)(`path`,{d:`M6 14h8`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})]},`i2`),(0,u.jsxs)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 20 20`,fill:`none`,children:[(0,u.jsx)(`path`,{d:`M16 6l-7 9-3-3`,stroke:`currentColor`,strokeWidth:`1.7`,strokeLinecap:`round`,strokeLinejoin:`round`}),(0,u.jsx)(`circle`,{cx:`10`,cy:`10`,r:`8`,stroke:`currentColor`,strokeWidth:`1.2`,opacity:`0.35`})]},`i3`),(0,u.jsx)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 20 20`,fill:`none`,children:(0,u.jsx)(`path`,{d:`M3 12V7M7 12V4M11 12V8M15 12V3`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})},`i4`)];return(0,u.jsxs)(`div`,{className:`db-stat`,style:{"--sc":e.color,"--si":e.bg},children:[(0,u.jsxs)(`div`,{className:`db-stat-head`,children:[(0,u.jsx)(`div`,{className:`db-stat-icon`,children:n[t]}),(0,u.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,style:{color:`#c8bfb5`},children:[(0,u.jsx)(`circle`,{cx:`4`,cy:`8`,r:`1.2`,fill:`currentColor`}),(0,u.jsx)(`circle`,{cx:`8`,cy:`8`,r:`1.2`,fill:`currentColor`}),(0,u.jsx)(`circle`,{cx:`12`,cy:`8`,r:`1.2`,fill:`currentColor`})]})]}),(0,u.jsx)(`p`,{className:`db-stat-label`,children:e.title}),(0,u.jsx)(`div`,{className:`db-stat-val`,children:e.value}),(0,u.jsxs)(`div`,{className:`db-stat-footer`,children:[(0,u.jsx)(`svg`,{width:`12`,height:`12`,viewBox:`0 0 12 12`,fill:`none`,children:(0,u.jsx)(`path`,{d:`M2 9l3-4 2 2 3-5`,stroke:`#22c55e`,strokeWidth:`1.4`,strokeLinecap:`round`,strokeLinejoin:`round`})}),(0,u.jsxs)(`span`,{className:`db-stat-trend`,children:[H.completion,`%`]}),(0,u.jsx)(`span`,{children:e.hint})]})]},e.title)})}),(0,u.jsxs)(`div`,{className:`db-panel`,children:[(0,u.jsxs)(`div`,{className:`db-panel-head`,children:[(0,u.jsxs)(`div`,{className:`db-panel-title-group`,children:[(0,u.jsx)(`div`,{className:`db-panel-icon`,style:{"--pi":`#fef3c7`,"--pc":`#b45309`},children:(0,u.jsx)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:(0,u.jsx)(`path`,{d:`M4 3h8M5 7h6M6 11h4`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})})}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`p`,{className:`db-panel-title`,children:`Promotion Tool`}),(0,u.jsx)(`p`,{className:`db-panel-sub`,children:`Pick From Class → choose To Class → select students → promote.`})]})]}),(0,u.jsxs)(`button`,{className:`db-refresh-btn`,onClick:()=>{D&&(async()=>{v(!0);try{M((await i.get(`/students-by-class`,{params:{class_id:Number(D)}})).data||[]),P([])}catch(e){console.error(e),t(e?.response?.data?.message||`Failed to refresh students.`)}finally{v(!1)}})()},disabled:!D||_,title:D?`Refresh list`:`Select From Class first`,children:[(0,u.jsxs)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,style:{animation:_?`dbSpin 0.8s linear infinite`:`none`},children:[(0,u.jsx)(`path`,{d:`M12 7A5 5 0 112 7`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,u.jsx)(`path`,{d:`M12 3v4h-4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),_?`Loading…`:`Refresh`]})]}),(0,u.jsx)(`div`,{className:`db-toolbar`,children:(0,u.jsxs)(`div`,{style:{width:`100%`},children:[(0,u.jsxs)(`div`,{className:`db-fields`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`db-field-label`,children:`From Class`}),(0,u.jsxs)(`select`,{className:`db-select`,value:D,onChange:e=>O(e.target.value),disabled:C.length===0,title:C.length===0?`No available class to promote from`:`Select from class`,children:[(0,u.jsx)(`option`,{value:``,children:C.length===0?`No assigned class`:`Select class`}),C.map(e=>(0,u.jsx)(`option`,{value:e.id,children:e.name},e.id))]}),(0,u.jsx)(`div`,{className:`db-help`,children:L?`Teachers can only promote from assigned class.`:`Loads students in this class.`})]}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`db-field-label`,children:`To Class`}),(0,u.jsxs)(`select`,{className:`db-select`,value:k,onChange:e=>A(e.target.value),disabled:!D,title:D?`Select destination class`:`Select From Class first`,children:[(0,u.jsx)(`option`,{value:``,children:`Select class`}),T.map(e=>(0,u.jsx)(`option`,{value:e.id,disabled:String(e.id)===D,children:e.name},e.id))]}),(0,u.jsx)(`div`,{className:`db-help`,children:`Students will be moved to this class.`})]}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`db-field-label`,children:`Search Students`}),(0,u.jsx)(`input`,{className:`db-input`,placeholder:`Search by name / reg no / class...`,value:F,onChange:e=>I(e.target.value),disabled:!R}),(0,u.jsx)(`div`,{className:`db-help`,children:`Search applies to loaded list only.`})]})]}),(0,u.jsxs)(`div`,{style:{marginTop:12},className:`db-actions`,children:[(0,u.jsxs)(`button`,{type:`button`,className:`db-mini-btn`,onClick:W,disabled:!R||_||B.length===0,children:[(0,u.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:(0,u.jsx)(`path`,{d:`M3 8l3 3 7-7`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`,strokeLinejoin:`round`})}),V?`Unselect Visible`:`Select Visible`]}),(0,u.jsxs)(`button`,{type:`button`,className:`db-mini-btn db-mini-btn--r`,onClick:G,disabled:N.length===0,children:[(0,u.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:(0,u.jsx)(`path`,{d:`M5 5l6 6M11 5L5 11`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})}),`Clear`]}),(0,u.jsx)(`button`,{type:`button`,className:`db-mini-btn db-mini-btn--p`,onClick:K,disabled:!z,children:y?(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`span`,{style:{width:14,height:14,borderRadius:`50%`,border:`2px solid rgba(67,56,202,0.25)`,borderTopColor:`#4338ca`,display:`inline-block`,animation:`dbSpin 0.8s linear infinite`}}),`Promoting…`]}):(0,u.jsxs)(u.Fragment,{children:[(0,u.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,u.jsx)(`path`,{d:`M6 10l4-4`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`}),(0,u.jsx)(`path`,{d:`M8.5 5H11v2.5`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),`Promote Selected`]})}),(0,u.jsxs)(`span`,{className:`db-pill db-pill--muted`,style:{marginLeft:`auto`},children:[`Selected: `,N.length]}),(0,u.jsxs)(`span`,{className:`db-pill db-pill--gold`,children:[`From: `,D?p(C,D):`—`]}),(0,u.jsxs)(`span`,{className:`db-pill db-pill--info`,children:[`To: `,k?p(T,k):`—`]})]})]})}),(0,u.jsx)(`div`,{style:{overflowX:`auto`},children:(0,u.jsxs)(`table`,{className:`db-table`,children:[(0,u.jsx)(`thead`,{children:(0,u.jsxs)(`tr`,{children:[(0,u.jsx)(`th`,{style:{width:60},children:(0,u.jsx)(`input`,{type:`checkbox`,checked:V,onChange:W,"aria-label":`Select all visible`,disabled:!R||_||B.length===0})}),(0,u.jsx)(`th`,{children:`Student`}),(0,u.jsx)(`th`,{style:{width:180},children:`Admission No`}),(0,u.jsx)(`th`,{style:{width:240},children:`Current Class`})]})}),(0,u.jsx)(`tbody`,{children:_?Array.from({length:8}).map((e,t)=>(0,u.jsxs)(`tr`,{children:[(0,u.jsx)(`td`,{children:(0,u.jsx)(`div`,{className:`db-skeleton`,style:{width:16}})}),(0,u.jsx)(`td`,{children:(0,u.jsx)(`div`,{className:`db-skeleton`,style:{width:220}})}),(0,u.jsx)(`td`,{children:(0,u.jsx)(`div`,{className:`db-skeleton`,style:{width:120}})}),(0,u.jsx)(`td`,{children:(0,u.jsx)(`div`,{className:`db-skeleton`,style:{width:160}})})]},t)):D?B.length===0?(0,u.jsx)(`tr`,{children:(0,u.jsxs)(`td`,{colSpan:4,className:`db-empty`,children:[(0,u.jsx)(`div`,{style:{fontWeight:800,color:`#1a1a2e`},children:`No students found`}),(0,u.jsx)(`div`,{style:{marginTop:6},children:`Try clearing search or check the selected class.`})]})}):B.map(e=>(0,u.jsxs)(`tr`,{children:[(0,u.jsx)(`td`,{children:(0,u.jsx)(`input`,{type:`checkbox`,checked:N.includes(e.id),onChange:()=>U(e.id),"aria-label":`Select ${e.surname} ${e.firstname}`})}),(0,u.jsxs)(`td`,{children:[(0,u.jsxs)(`div`,{style:{fontWeight:700,color:`#1a1a2e`},children:[e.surname,` `,e.firstname]}),(0,u.jsxs)(`div`,{className:`db-muted`,children:[`ID: `,e.id]})]}),(0,u.jsx)(`td`,{children:(0,u.jsx)(`span`,{className:`db-pill db-pill--info`,children:e.reg_no||`—`})}),(0,u.jsx)(`td`,{children:e.class_name||`—`})]},e.id)):(0,u.jsx)(`tr`,{children:(0,u.jsxs)(`td`,{colSpan:4,className:`db-empty`,children:[(0,u.jsx)(`div`,{style:{fontWeight:800,color:`#1a1a2e`},children:`Select a From Class`}),(0,u.jsx)(`div`,{style:{marginTop:6},children:`Students will appear here after choosing a class.`})]})})})]})}),(0,u.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,gap:12,flexWrap:`wrap`,padding:`14px 20px`,borderTop:`1px solid rgba(0,0,0,0.06)`},children:[(0,u.jsx)(`div`,{style:{fontSize:12.5,color:`#9a8a7a`},children:`Tip: “Select Visible” respects your search filter. From Class and To Class must be different.`}),(0,u.jsx)(`button`,{type:`button`,className:`db-mini-btn db-mini-btn--p`,onClick:K,disabled:!z,children:`Promote Selected`})]})]}),(0,u.jsx)(`div`,{className:`mt-auto`,style:{paddingTop:18},children:(0,u.jsx)(c,{})})]})]})})]})}function p(e,t){return e.find(e=>String(e.id)===String(t))?.name||`—`}export{f as default};