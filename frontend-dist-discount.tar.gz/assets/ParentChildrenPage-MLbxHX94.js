import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{p as t,x as n}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as r,E as i,P as a,R as o,d as s,f as c,u as l}from"./index-D6TxbaCx.js";var u=e(),d=t(),f=e=>new Intl.NumberFormat(`en-NG`,{style:`currency`,currency:`NGN`}).format(e||0);function p(){let e=n(),[t,p]=(0,u.useState)(!1),[m,h]=(0,u.useState)(!0),[g,_]=(0,u.useState)(null),[v,y]=(0,u.useState)(``),[b,x]=(0,u.useState)([{title:`My Children`,value:0,icon:`people`},{title:`Total Balance`,value:f(0),icon:`wallet2`},{title:`Avg Attendance (30d)`,value:`0%`,icon:`clipboard-check`},{title:`Total Results`,value:0,icon:`bar-chart`}]),S=g?.children??[],C=(0,u.useMemo)(()=>{let e=v.trim().toLowerCase();return e?S.filter(t=>{let n=(t.name||``).toLowerCase(),r=(t.reg_no||``).toLowerCase(),i=(t.class||``).toLowerCase();return n.includes(e)||r.includes(e)||i.includes(e)}):S},[S,v]),w=e=>{let t=e.reduce((e,t)=>e+Number(t.fee_balance||0),0),n=e.reduce((e,t)=>e+Number(t.results_count||0),0),r=e.length>0?Math.round(e.reduce((e,t)=>e+Number(t.attendance_rate_30d||0),0)/e.length):0;x([{title:`My Children`,value:e.length,icon:`people`},{title:`Total Balance`,value:f(t),icon:`wallet2`},{title:`Avg Attendance (30d)`,value:`${r}%`,icon:`clipboard-check`},{title:`Total Results`,value:n,icon:`bar-chart`}])},T=()=>{h(!0),a.get(`/parent/children`).then(e=>{let t=e.data;_(t),w(t.children||[])}).catch(e=>{console.error(e)}).finally(()=>h(!1))};(0,u.useEffect)(()=>{T()},[]);let E=()=>{let e=new Date().getHours();return e<12?`Good Morning`:e<17?`Good Afternoon`:`Good Evening`},D=g?.parent?.name??`Parent`;return(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');

        .parent-ch-main {
          background: #F8FAFC;
          min-height: 100vh;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          padding: calc(66px + 24px) 28px 40px !important;
        }

        @media (max-width: 767.98px) {
          .parent-ch-main {
            padding: calc(66px + 16px) 14px 36px !important;
          }
          .parent-hero {
            padding: 20px 18px !important;
            border-radius: 14px !important;
            margin-bottom: 16px !important;
          }
          .parent-greeting {
            font-size: 20px !important;
          }
          .parent-hero-sub {
            font-size: 12.5px !important;
          }
        }

        .parent-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 18px;
          padding: 32px 36px;
          color: #FFFFFF;
          margin-bottom: 24px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
          position: relative;
          overflow: hidden;
        }

        .parent-hero::before {
          content: '';
          position: absolute;
          inset: 0;
          background-image:
            linear-gradient(rgba(255, 255, 255, 0.035) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255, 255, 255, 0.035) 1px, transparent 1px);
          background-size: 32px 32px;
          pointer-events: none;
        }

        .parent-hero-glow {
          position: absolute;
          top: -40px;
          right: -40px;
          width: 320px;
          height: 320px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.18) 0%, transparent 65%);
          pointer-events: none;
        }

        .parent-hero-inner {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: center;
          justify-content: space-between;
          flex-wrap: wrap;
          gap: 24px;
        }

        .parent-session-badge {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.2);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius: 100px;
          padding: 4px 12px;
          margin-bottom: 12px;
        }

        .parent-session-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #10B981;
          box-shadow: 0 0 6px #10B981;
        }

        .parent-greeting {
          font-size: 26px;
          font-weight: 800;
          color: #FFFFFF;
          line-height: 1.1;
          margin-bottom: 8px;
        }

        .parent-greeting em {
          font-style: normal;
          color: #FBBF24;
        }

        .parent-hero-sub {
          font-size: 13.5px;
          color: #CBD5E1;
          line-height: 1.6;
          max-width: 520px;
          margin-bottom: 0;
        }

        .parent-stat-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 16px;
          margin-bottom: 24px;
        }

        @media (max-width: 1100px) {
          .parent-stat-grid {
            grid-template-columns: repeat(2, 1fr);
          }
        }

        @media (max-width: 600px) {
          .parent-stat-grid {
            grid-template-columns: 1fr;
          }
        }

        .parent-stat-card {
          background: #FFFFFF;
          border: 1px solid rgba(15, 39, 68, 0.08);
          border-radius: 16px;
          padding: 20px 24px;
          box-shadow: 0 2px 10px rgba(15, 39, 68, 0.04);
          transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1);
        }

        .parent-stat-card:hover {
          transform: translateY(-3px);
          box-shadow: 0 8px 24px rgba(15, 39, 68, 0.08);
          border-color: rgba(217, 119, 6, 0.25);
        }

        .parent-stat-icon-wrap {
          width: 44px;
          height: 44px;
          border-radius: 12px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 20px;
          margin-bottom: 14px;
        }

        .parent-stat-title {
          font-size: 12px;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.04em;
          color: #64748B;
          margin-bottom: 6px;
        }

        .parent-stat-val {
          font-size: 24px;
          font-weight: 800;
          color: #0F2744;
          line-height: 1.1;
        }

        .parent-panel {
          background: #FFFFFF;
          border: 1px solid rgba(15, 39, 68, 0.08);
          border-radius: 16px;
          box-shadow: 0 2px 10px rgba(15, 39, 68, 0.04);
          overflow: hidden;
          margin-bottom: 24px;
        }

        .parent-panel-head {
          padding: 18px 24px;
          border-bottom: 1px solid #E2E8F0;
          display: flex;
          align-items: center;
          justify-content: space-between;
          flex-wrap: wrap;
          gap: 12px;
        }

        .parent-table {
          width: 100%;
          border-collapse: collapse;
          font-size: 13px;
        }

        .parent-table th {
          background: #F8FAFC;
          padding: 12px 16px;
          font-weight: 700;
          color: #475569;
          font-size: 11.5px;
          text-transform: uppercase;
          letter-spacing: 0.04em;
          border-bottom: 1px solid #E2E8F0;
        }

        .parent-table td {
          padding: 14px 16px;
          border-bottom: 1px solid #F1F5F9;
          color: #1E293B;
          vertical-align: middle;
        }

        .parent-table tr:hover td {
          background: #F8FAFC;
        }
      `}),(0,d.jsx)(c,{sidebarOpen:t,setSidebarOpen:p}),(0,d.jsx)(r,{title:`My Children`}),(0,d.jsx)(`div`,{className:`container-fluid`,children:(0,d.jsxs)(`div`,{className:`row`,children:[(0,d.jsx)(s,{sidebarOpen:t,setSidebarOpen:p}),(0,d.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto gq-app-main parent-ch-main d-flex flex-column min-vh-100`,children:[m&&(0,d.jsx)(i,{message:`Loading children directory...`}),(0,d.jsxs)(`div`,{className:`parent-hero`,children:[(0,d.jsx)(`div`,{className:`parent-hero-glow`}),(0,d.jsxs)(`div`,{className:`parent-hero-inner`,children:[(0,d.jsxs)(`div`,{children:[(0,d.jsxs)(`div`,{className:`parent-session-badge`,children:[(0,d.jsx)(`span`,{className:`parent-session-dot`}),`Family Directory`]}),(0,d.jsxs)(`h1`,{className:`parent-greeting`,children:[E(),`, `,(0,d.jsxs)(`em`,{children:[D,`!`]}),` 👋`]}),(0,d.jsx)(`p`,{className:`parent-hero-sub`,children:`Direct access to each child’s attendance, continuous assessment reports, term broadsheets, and fee breakdown.`})]}),(0,d.jsxs)(`div`,{className:`d-flex gap-2`,children:[(0,d.jsxs)(`button`,{className:`btn btn-outline-light px-4 py-2`,style:{borderRadius:10,fontWeight:700,backdropFilter:`blur(8px)`},onClick:()=>T(),children:[(0,d.jsx)(`i`,{className:`bi bi-arrow-clockwise me-2`}),`Refresh`]}),(0,d.jsxs)(`button`,{className:`btn btn-warning px-4 py-2`,style:{borderRadius:10,fontWeight:700,color:`#0F2744`,background:`#FBBF24`},onClick:()=>e(`/dashboard`),children:[(0,d.jsx)(`i`,{className:`bi bi-speedometer2 me-2`}),`Dashboard`]})]})]})]}),(0,d.jsx)(`div`,{className:`parent-stat-grid`,children:b.map(({title:e,value:t,icon:n},r)=>{let i=[{color:`#10B981`,bg:`rgba(16, 185, 129, 0.12)`},{color:`#2563EB`,bg:`rgba(37, 99, 235, 0.12)`},{color:`#059669`,bg:`rgba(5, 150, 105, 0.12)`},{color:`#D97706`,bg:`rgba(217, 119, 6, 0.12)`}][r%4];return(0,d.jsx)(`div`,{className:`parent-stat-card`,children:(0,d.jsxs)(`div`,{className:`d-flex align-items-start justify-content-between`,children:[(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`div`,{className:`parent-stat-title`,children:e}),(0,d.jsx)(`div`,{className:`parent-stat-val`,children:t})]}),(0,d.jsx)(`div`,{className:`parent-stat-icon-wrap`,style:{backgroundColor:i.bg,color:i.color},children:(0,d.jsx)(`i`,{className:`bi bi-${n}`})})]})},e)})}),(0,d.jsxs)(`div`,{className:`parent-panel mb-5`,children:[(0,d.jsxs)(`div`,{className:`parent-panel-head`,children:[(0,d.jsxs)(`div`,{children:[(0,d.jsxs)(`h2`,{style:{fontSize:`16px`,fontWeight:800,color:`#0F2744`,margin:0},children:[(0,d.jsx)(`i`,{className:`bi bi-people-fill text-primary me-2`}),`All Enrolled Children (`,C.length,`)`]}),(0,d.jsx)(`div`,{style:{fontSize:`12px`,color:`#64748B`,marginTop:`2px`},children:`Select a student to view academic records or clear fees`})]}),(0,d.jsx)(`div`,{style:{minWidth:260},children:(0,d.jsx)(`input`,{className:`form-control`,placeholder:`Search by name, reg no, class...`,value:v,onChange:e=>y(e.target.value),style:{borderRadius:10,fontSize:`13px`}})})]}),(0,d.jsx)(`div`,{className:`table-responsive`,children:(0,d.jsxs)(`table`,{className:`parent-table`,children:[(0,d.jsx)(`thead`,{children:(0,d.jsxs)(`tr`,{children:[(0,d.jsx)(`th`,{children:`Student`}),(0,d.jsx)(`th`,{children:`Class`}),(0,d.jsx)(`th`,{children:`Attendance (30d)`}),(0,d.jsx)(`th`,{children:`Fee Balance`}),(0,d.jsx)(`th`,{children:`Results Available`}),(0,d.jsx)(`th`,{className:`text-end`,children:`Actions`})]})}),(0,d.jsxs)(`tbody`,{children:[C.map(t=>{let n=Number(t.fee_balance||0)<=0,r=(t.name||`Student`).split(` `).map(e=>e[0]).slice(0,2).join(``).toUpperCase();return(0,d.jsxs)(`tr`,{children:[(0,d.jsx)(`td`,{children:(0,d.jsxs)(`div`,{className:`d-flex align-items-center gap-3`,children:[(0,d.jsxs)(`div`,{style:{width:44,height:44,borderRadius:12,background:`#0A192F`,color:`#FBBF24`,display:`flex`,alignItems:`center`,justifyContent:`center`,fontWeight:800,fontSize:14,overflow:`hidden`,flexShrink:0,border:`1.5px solid rgba(15, 39, 68, 0.12)`},children:[t.photo?(0,d.jsx)(`img`,{src:o(t.photo,`/media/profile.jpg`),alt:t.name,style:{width:`100%`,height:`100%`,objectFit:`cover`},onError:e=>{e.target.style.display=`none`}}):null,(0,d.jsx)(`span`,{children:r})]}),(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`div`,{style:{fontWeight:700,color:`#0F2744`,fontSize:14},children:t.name}),(0,d.jsxs)(`small`,{className:`text-muted`,children:[`Reg No: `,(0,d.jsx)(`strong`,{children:t.reg_no||`N/A`})]})]})]})}),(0,d.jsx)(`td`,{children:(0,d.jsx)(`span`,{className:`badge bg-light text-dark border px-2 py-1 fw-bold`,children:t.class||`—`})}),(0,d.jsx)(`td`,{children:(0,d.jsxs)(`div`,{className:`d-flex align-items-center gap-2`,children:[(0,d.jsx)(`div`,{className:`progress flex-grow-1`,style:{height:6,width:60,borderRadius:999},children:(0,d.jsx)(`div`,{className:`progress-bar ${t.attendance_rate_30d>=75?`bg-success`:t.attendance_rate_30d>=50?`bg-warning`:`bg-danger`}`,style:{width:`${Math.min(100,t.attendance_rate_30d||0)}%`}})}),(0,d.jsxs)(`span`,{style:{fontWeight:700,fontSize:`12px`},children:[t.attendance_rate_30d,`%`]})]})}),(0,d.jsx)(`td`,{style:{fontWeight:700,color:n?`#15803D`:`#B91C1C`,fontSize:13.5},children:f(t.fee_balance)}),(0,d.jsx)(`td`,{children:(0,d.jsxs)(`span`,{className:`badge bg-primary-subtle text-primary border border-primary-subtle fw-bold px-2 py-1`,children:[(0,d.jsx)(`i`,{className:`bi bi-award me-1`}),t.results_count,` term result`,t.results_count===1?``:`s`]})}),(0,d.jsx)(`td`,{className:`text-end`,children:(0,d.jsxs)(`div`,{className:`d-flex justify-content-end gap-2`,children:[(0,d.jsxs)(`button`,{className:`btn btn-sm btn-outline-dark`,style:{borderRadius:8,fontWeight:700,fontSize:`12px`},onClick:()=>e(`/parent/results?student_id=${t.id}`),title:`View Academic Results and Broadsheet`,children:[(0,d.jsx)(`i`,{className:`bi bi-file-earmark-bar-graph me-1 text-primary`}),`Broadsheet`]}),(0,d.jsxs)(`button`,{className:`btn btn-sm btn-primary`,style:{borderRadius:8,fontWeight:700,fontSize:`12px`},onClick:()=>e(`/parent/students/${t.id}/fees`),title:`View Fee Breakdown & Payment Details`,children:[(0,d.jsx)(`i`,{className:`bi bi-receipt me-1`}),`Fees`]})]})})]},t.id)}),!m&&C.length===0&&(0,d.jsx)(`tr`,{children:(0,d.jsxs)(`td`,{colSpan:6,className:`text-center text-muted py-5`,children:[(0,d.jsx)(`i`,{className:`bi bi-search fs-2 d-block mb-2 text-secondary`}),`No children found matching your search.`]})})]})]})})]}),(0,d.jsx)(l,{})]})]})})]})}export{p as default};