const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/Unauthorized-71bQLUxl.js","assets/vendor-pdf-B04jN_ph.js","assets/vendor-misc-OZLc0tLq.js","assets/rolldown-runtime-CWU8vmCm.js","assets/vendor-react-BhRGw7qi.js","assets/vendor-chart-J6aekJfr.js","assets/vendor-editor-AFNBk_uL.js","assets/ForbiddenPage-CddrRcA5.js","assets/NotFoundPage-Cg54fdsg.js","assets/ForbiddenPage-DlxQ3X-p.js","assets/ServerErrorPage-yUo7LvSf.js","assets/MaintenancePage-Be-ZbrZB.js","assets/vendor-http-DXqav090.js","assets/SubscriptionRequiredPage-wbLwNw2M.js","assets/SuperAdminDashboard-BBFoMycN.js","assets/StudentsPage-CVyqFl_y.js","assets/AttendancePage-abzPSGEE.js","assets/StudentReportPage-SH9J0usc.js","assets/StudentRegisterPage-h2A-r3xV.js","assets/FinancialRecord-BueHR8Su.js","assets/AddResultV2Page-DzelA7Am.js","assets/AdminStudentResultLookupPage-wof5gnc3.js","assets/vendor-qr-Xjq4Czgo.js","assets/ResultBatchSetupPage-Bn6Rd24P.js","assets/ResultUploadPage-Cdpiq2JW.js","assets/AdminResultReviewPage-CEA9yi6u.js","assets/ResultTemplateSettingsPage-D8cWAy-P.js","assets/ShowResult-Pa3awKRe.js","assets/AcademicCalendarPage-BksqYwwx.js","assets/LegalPage-D5RVfbop.js","assets/LegalPage-BR1iSy5N.css","assets/BroadsheetPage-DGfx8Hq1.js","assets/LevelsPage-UYbpOcMc.js","assets/SubjectsPage-CfuqkCf9.js","assets/DepartmentPage-B8qJLIlq.js","assets/SectionsPage-DgPoAbEb.js","assets/FeeMethodsPage-Co6ovFfa.js","assets/FeeStructurePage-BZHBRyNm.js","assets/StudentFeePaymentPage-CQfkg0hV.js","assets/ReceiptApprovalPage-BUNX1QKw.js","assets/FeesReport-Xgbh03gR.js","assets/SettingsPage-BBuQoO0t.js","assets/PromoteStudentsPage-CLT8SL_w.js","assets/BillingPage-DIU5GBZA.js","assets/CheckoutPage-4MQZaXPn.js","assets/SchoolProfitInvoicePaymentPage-CHKyDlbU.js","assets/WalletPage-BGlO3qRE.js","assets/AdminUserDetailsPage-C5m2ndvR.js","assets/SubscribersManagementPage-cp14OsD4.js","assets/MarketingEmailPage-DltFZsK4.js","assets/SalesRepresentativesPage-BolDB-xm.js","assets/SalesLeadsPage-O2OA5FJ9.js","assets/SalesPayoutsPage-mQazvdgU.js","assets/PlatformStaffPage-8OcTxCR9.js","assets/SubscriptionPlansPage-CZh3leJ-.js","assets/BillingPolicyPage-3h4Vtg4N.js","assets/TwilioWhatsappPage-BbUl9VBa.js","assets/BlogsPage-BoRk-819.js","assets/TestimonialsPage-BVfFrrpQ.js","assets/StaffQrAttendancePage-v2bM17lt.js","assets/StaffAttendanceLogsPage--Wf-l2HG.js","assets/AttendanceSettingsPage-Cbdw6CxG.js","assets/TeachersPage-Croer2R3.js","assets/PeopleImportPanel-CHz9v6Iy.js","assets/TeacherSubjectsPage-J2tAh5Dr.js","assets/ParentsPage-CJOJqggY.js","assets/StudentMyFeesPage-erw9pAz7.js","assets/StudentMySubjectsPage-BHN5xHbJ.js","assets/ParentChildrenPage-MLbxHX94.js","assets/SchoolBankAccountsPage-BRrAr5QI.js","assets/SchoolOperatorsPage-OdW2Vfx1.js","assets/ChildFeeDetailsPage-VABlBNnv.js","assets/ParentAttendancePage-B1k8B9c7.js","assets/ParentCommunicationPage-DrvyANxq.js","assets/ParentSchoolInfoPage-Dm-Jgj5-.js","assets/ParentResultsPage-C2GV75rV.js","assets/ReceiptUploadPage-BE8ZfWUe.js","assets/ParentPaymentSummaryPage-Dlxu-buj.js","assets/ResultPinsPage-B0N_pPhY.js","assets/CheckResultPage-Ck18bkFr.js","assets/VerifyResultPage-C2WT-Qxv.js","assets/OnboardingPage-CwGkZRSo.js","assets/ProfileSettingsPage-Lx-3JkmX.js","assets/NotificationsPage-BxyJ42EV.js","assets/InvoiceNotificationsPage-BbT9a9VJ.js","assets/InvoiceNotificationDetailsPage-DVWFunbx.js","assets/PaymentInstructionsPage-DlsjLY6j.js","assets/Bookdemo -BZlZ80-O.js","assets/DemoBookingsPage-CLXj5qZ1.js","assets/BursarsPage-ClCj-KUL.js","assets/Forgotpasswordpage-CTH0qRv3.js","assets/Resetpasswordpage-DbzfAtkw.js","assets/ResultSubmissionDeadlinePage-Bvq19kx9.js","assets/Resultmonitoringpage-C5bERTqW.js","assets/CbtExamsPage-DfkaDg1Q.js","assets/CbtHtml-c3aEDZay.js","assets/StudentCbtExamsPage-DxYCJs56.js","assets/StudentLessonNotesPage-BSC83hlk.js","assets/WhatsAppSettingsPage-CLKLiMjk.js","assets/AiCreditsPage-C_H1RwUt.js","assets/AiLessonPlanPage-8LYTUgTV.js","assets/AiFeeCollectionAssistantPage-BkLNIEUY.js","assets/FeePolicyPage-DswmNVZl.js","assets/OnlinePayFeesPage-C5B7H6bG.js","assets/PublicFeePaymentPage-CyRDBX8Q.js","assets/PublicCbtAccessPage-kzOks-nd.js","assets/OfflineCbtRunnerPage-DzhHU9iW.js","assets/SalesLeadsPage-DQBcp4bD.js","assets/SalesCommissionsPage-BggmffsM.js","assets/SalesPayoutSettingsPage-CmEyxl19.js","assets/SalesMarketingKitPage-DYwtnreK.js","assets/SalesMarketingMaterialsPage-ECkb_RHY.js","assets/PublicRepresentativeSalesPage-pCl3tQ70.js","assets/PublicRepresentativeRegisterPage-DAG1Qjh-.js","assets/ChangeInitialPasswordPage-uwTprrAj.js","assets/SupportTicketsPage-C5oq-0NO.js","assets/HostelManagementPage-CcBdZUum.js","assets/TransportManagementPage-CsNkn2LI.js","assets/WithdrawnStudentResultsPage-DhV_54tL.js","assets/AcademicRecordsLayoutFix-BwgfXyhB.css","assets/TranscriptsPage-Dbo5QDbr.js","assets/NewsletterSubscribersPage-CWnGtPey.js","assets/PublicBlogDetailPage-9CpT9Sdv.js"])))=>i.map(i=>d[i]);
import{i as e}from"./rolldown-runtime-CWU8vmCm.js";import{Ut as t}from"./vendor-misc-OZLc0tLq.js";import{C as n,_ as r,b as i,g as a,h as o,m as s,p as c,v as l,w as u,x as d,y as f}from"./vendor-react-BhRGw7qi.js";import{a as p}from"./vendor-pdf-B04jN_ph.js";/* empty css                  */import{t as m}from"./vendor-http-DXqav090.js";import{t as h}from"./vendor-chart-J6aekJfr.js";(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var g=u(),_=e(t(),1);const v=()=>{if(typeof window>`u`)return!1;let e=window.location.hostname.toLowerCase();return/^\d+\.\d+\.\d+\.\d+$/.test(e)||e===`localhost`||e===`127.0.0.1`||e===`schoolprofit.ng`||e===`www.schoolprofit.ng`||e===`gradequest.com.ng`||e===`www.gradequest.com.ng`?!1:e===`app.schoolprofit.ng`||e===`portal.schoolprofit.ng`||e===`app.gradequest.com.ng`||e===`portal.gradequest.com.ng`||!e.endsWith(`.schoolprofit.ng`)&&e!==`schoolprofit.ng`&&!e.endsWith(`.gradequest.com.ng`)&&e!==`gradequest.com.ng`},y=(e=window.location.origin)=>`${e.replace(/\/+$/,``)}/login`;var b=`gradequest_token`,x=`gradequest_user`,S={admin:`Admin`,bursar:`Bursar`,parent:`Parent`,student:`Student`,teacher:`Teacher`,"super-admin":`Super-Admin`,"platform-staff":`Platform-Staff`,"platform staff":`Platform-Staff`,platformstaff:`Platform-Staff`,superadmin:`Super-Admin`,"sales-representative":`Sales-Representative`,"sales representative":`Sales-Representative`,salesrepresentative:`Sales-Representative`,salesrep:`Sales-Representative`,"sales-rep":`Sales-Representative`,sales_rep:`Sales-Representative`},C=[`dashboard`,`billing`,`finance`,`support`,`sales`,`marketing`,`content`,`settings`,`audit`,`staff`],w={operations:[`dashboard`,`support`,`billing`,`audit`],finance:[`dashboard`,`billing`,`finance`,`audit`],support:[`dashboard`,`support`,`audit`],sales_manager:[`dashboard`,`sales`,`marketing`,`audit`]},T=e=>{if(!e?.role)return e;let t=S[String(e.role).trim().toLowerCase()]||e.role,n=t===`Super-Admin`,r=Array.isArray(e.super_admin_permissions)?e.super_admin_permissions:[],i=e.super_admin_type||(n?`owner`:null),a=n?C:t===`Platform-Staff`&&i&&w[i]||[];return{...e,role:t,super_admin_type:i,super_admin_type_label:e.super_admin_type_label||(n?`Super Admin Owner`:null),super_admin_permissions:r.length===0?a:r}};const E=e=>{localStorage.setItem(b,e)},D=()=>localStorage.getItem(b),O=()=>{localStorage.removeItem(b)},k=e=>{localStorage.setItem(x,JSON.stringify(T(e)))},A=()=>{let e=localStorage.getItem(x);return e?T(JSON.parse(e)):null},j=()=>{localStorage.removeItem(x)},M=()=>{O(),j(),window.location.assign(y())};var N=c();function P({children:e,roles:t=[],permissions:n=[]}){let a=D(),o=A(),s=i();if(!a)return(0,N.jsx)(r,{to:`/login`,replace:!0});if(o?.must_change_password&&s.pathname!==`/change-password`)return(0,N.jsx)(r,{to:`/change-password`,replace:!0});if(t.length){let e=(o?.role||``).toLowerCase().trim();if(!(e===`superadmin`||e===`super-admin`)){let n=[`admin`,`owner`,`proprietor`,`school-admin`,`principal`,`headteacher`].includes(e),i=e===`operator`,a=e===`teacher`,o=e===`student`,c=e===`parent`,l=e===`bursar`,u=[`sales-representative`,`sales_representative`,`salesrep`].includes(e),d=[`platform-staff`,`platform_staff`,`staff`].includes(e),f=t.map(e=>e.toLowerCase().trim()),p=f.includes(e);!p&&n&&f.includes(`admin`)&&(p=!0),!p&&a&&f.includes(`teacher`)&&(p=!0),!p&&o&&f.includes(`student`)&&(p=!0),!p&&c&&f.includes(`parent`)&&(p=!0),!p&&l&&f.includes(`bursar`)&&(p=!0),!p&&u&&(f.includes(`sales-representative`)||f.includes(`salesrep`))&&(p=!0),!p&&d&&(f.includes(`platform-staff`)||f.includes(`staff`))&&(p=!0);let m=s.pathname.startsWith(`/school/bank-account`)||s.pathname.startsWith(`/billing`)||s.pathname.startsWith(`/wallet`)||s.pathname.startsWith(`/school/settings`)||s.pathname.startsWith(`/school/operators`)||s.pathname.startsWith(`/admin/school/operators`),h=i&&f.includes(`admin`)&&!m;if(!p&&!h)return(0,N.jsx)(r,{to:`/unauthorized`,replace:!0})}}if(n.length){let e=(o?.role||``).toLowerCase().trim();if(!(e===`superadmin`||e===`super-admin`)){let e=Array.isArray(o?.super_admin_permissions)?o.super_admin_permissions:[];if(!(e.includes(`all`)||n.some(t=>e.includes(t))))return(0,N.jsx)(r,{to:`/unauthorized`,replace:!0})}}return(0,N.jsx)(N.Fragment,{children:e})}const F=()=>{if(v())return window.location.origin;let e=`/api`;return e!==`/api`&&e!==``&&!e.includes(`laravel.cloud`)?`/api`.replace(/\/+$/,``).replace(/\/api$/,``):typeof window<`u`&&window.location?.origin?window.location.origin:`http://18.133.82.13`},I=()=>`${F()}/api`,L=()=>{let e=typeof window<`u`?window.location.origin:``;return String(e).replace(/\/+$/,``)},R=(e,t=`/media/profile.jpg`,n)=>{if(!e||typeof e!=`string`||!e.trim())return t;let r=e.trim();if(r.startsWith(`http://`)||r.startsWith(`https://`)||r.startsWith(`data:`)||r.startsWith(`blob:`))return r;let i=F();return r.startsWith(`/`)?`${i}${r}`:r.startsWith(`uploads/`)?`${i}/${r}`:n?`${i}/${n.replace(/^\/+|\/+$/g,``)}/${r}`:`${i}/uploads/users/${r}`};I();const z=m.create({headers:{"Content-Type":`application/json`,Accept:`application/json`}});z.interceptors.request.use(e=>((!e.baseURL||e.baseURL.includes(`laravel.cloud`))&&(e.baseURL=I()),e));const B=m.create({headers:{"Content-Type":`application/json`,Accept:`application/json`},withCredentials:!0});B.interceptors.request.use(e=>{(!e.baseURL||e.baseURL.includes(`laravel.cloud`))&&(e.baseURL=I());let t=D();return t&&(e.headers.Authorization=`Bearer ${t}`),e.data instanceof FormData&&(delete e.headers[`Content-Type`],delete e.headers[`content-type`]),e}),B.interceptors.response.use(e=>e,e=>(e.response?.status===401&&M(),Promise.reject(e)));var V=(0,_.createContext)(null),ee=new Set([`/`,`/login`,`/register`,`/check-result`,`/unauthorized`,`/sales-representative/register`,`/become-a-partner`,`/forgot-password`,`/reset-password`,`/privacy-policy`,`/terms-and-conditions`,`/book-demo`,`/pay-school-fee`]);function te({children:e}){let t=i(),[n,r]=(0,_.useState)(!1),[a,o]=(0,_.useState)([]),s=async()=>{let e=D?.(),n=ee.has(t.pathname);if(!e||n){r(!1),o([]);return}r(!0);try{let e=await B.get(`/user/features`);o((Array.isArray(e.data?.features)?e.data.features:[]).map(e=>String(e).trim()).filter(Boolean))}catch{o([])}finally{r(!1)}};(0,_.useEffect)(()=>{s()},[t.pathname]);let c=(0,_.useMemo)(()=>new Set(a),[a]),l=(0,_.useMemo)(()=>({loading:n,features:a,refresh:s,can:e=>e?n?!1:c.has(e):!0}),[n,a,c]);return(0,N.jsx)(V.Provider,{value:l,children:e})}function ne(){let e=(0,_.useContext)(V);if(!e)throw Error(`useFeatures must be used inside <FeatureProvider />`);return e}async function re(){return(await B.get(`/user/onboarding-status`)).data}async function ie(e){return(await B.post(`/verify-email-code`,{code:e})).data}async function H(){return(await B.post(`/resend-email-code`)).data}async function ae(e){return(await B.post(`/set-current-session`,e)).data}async function oe(e={}){return(await B.post(`/create-all-terms`,e)).data}async function U(){return(await B.post(`/activate-bonus`)).data}async function W(){return(await B.post(`/accept-terms`,{accepted:!0})).data}function G({message:e=`Loading…`,eyebrow:t=`SchoolProfit`}){return(0,N.jsxs)(`div`,{className:`gq-loader-backdrop`,role:`status`,"aria-live":`polite`,"aria-label":e,children:[(0,N.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@500;600;700;800&display=swap');

        .gq-loader-backdrop {
          position: fixed;
          inset: 0;
          z-index: 99999;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 20px;
          background: rgba(15, 39, 68, 0.55);
          backdrop-filter: blur(10px);
          -webkit-backdrop-filter: blur(10px);
          font-family: 'Plus Jakarta Sans', sans-serif;
          animation: gqFadeIn 0.2s ease-out both;
        }

        .gq-loader-box {
          width: 100%;
          max-width: 320px;
          background: #FFFFFF;
          border-radius: 20px;
          padding: 32px 24px 28px;
          text-align: center;
          box-shadow: 0 20px 40px -10px rgba(15, 39, 68, 0.3), 0 0 0 1px rgba(226, 232, 240, 0.8);
          animation: gqScaleUp 0.25s cubic-bezier(0.16, 1, 0.3, 1) both;
          position: relative;
        }

        .gq-loader-icon-wrap {
          position: relative;
          width: 68px;
          height: 68px;
          margin: 0 auto 20px;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .gq-loader-spinner-ring {
          position: absolute;
          inset: 0;
          border-radius: 50%;
          border: 3px solid #E2E8F0;
          border-top-color: #D97706;
          border-right-color: #0F2744;
          animation: gqSpin 0.9s cubic-bezier(0.4, 0, 0.2, 1) infinite;
        }

        .gq-loader-logo {
          width: 34px;
          height: 34px;
          object-fit: contain;
          border-radius: 8px;
          animation: gqPulse 2s ease-in-out infinite;
        }

        .gq-loader-eyebrow {
          font-size: 11px;
          font-weight: 800;
          text-transform: uppercase;
          letter-spacing: 0.08em;
          color: #D97706;
          margin-bottom: 6px;
        }

        .gq-loader-message {
          font-size: 14.5px;
          font-weight: 700;
          color: #0F2744;
          margin: 0;
          line-height: 1.4;
        }

        .gq-loader-bar {
          height: 3px;
          background: #F1F5F9;
          border-radius: 999px;
          margin-top: 20px;
          overflow: hidden;
          position: relative;
        }

        .gq-loader-bar::after {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          height: 100%;
          width: 40%;
          background: linear-gradient(90deg, #D97706, #0F2744);
          border-radius: 999px;
          animation: gqSlide 1.2s ease-in-out infinite;
        }

        @keyframes gqFadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }

        @keyframes gqScaleUp {
          from { opacity: 0; transform: translateY(8px) scale(0.95); }
          to { opacity: 1; transform: translateY(0) scale(1); }
        }

        @keyframes gqSpin {
          to { transform: rotate(360deg); }
        }

        @keyframes gqPulse {
          0%, 100% { transform: scale(1); opacity: 1; }
          50% { transform: scale(0.92); opacity: 0.85; }
        }

        @keyframes gqSlide {
          0% { left: -40%; }
          100% { left: 100%; }
        }
      `}),(0,N.jsxs)(`div`,{className:`gq-loader-box`,children:[(0,N.jsxs)(`div`,{className:`gq-loader-icon-wrap`,children:[(0,N.jsx)(`div`,{className:`gq-loader-spinner-ring`}),(0,N.jsx)(`img`,{src:`/media/logo/schoolprofit-logo.svg`,alt:`SchoolProfit`,className:`gq-loader-logo`,onError:e=>{e.target.style.display=`none`}})]}),(0,N.jsx)(`div`,{className:`gq-loader-eyebrow`,children:t}),(0,N.jsx)(`p`,{className:`gq-loader-message`,children:e}),(0,N.jsx)(`div`,{className:`gq-loader-bar`})]})]})}function K({role:e}){return(0,N.jsx)(G,{eyebrow:e&&e!==`User`?`${e} workspace`:`Secure workspace`,message:`Preparing your dashboard…`})}function q({children:e}){let t=i(),[n,a]=(0,_.useState)(!0),[o,s]=(0,_.useState)(!1),[c,l]=(0,_.useState)(!1),[u,d]=(0,_.useState)(`User`);return(0,_.useEffect)(()=>{let e=!0;return(async()=>{try{let t=(await B.get(`/user-profile`)).data.role||`User`,n=t===`Admin`;if(!e)return;if(d(t),l(n),!n){s(!1),a(!1);return}let r=!!(await re()).bonus_given;e&&s(!r)}catch{e&&s(!1)}finally{e&&a(!1)}})(),()=>{e=!1}},[]),n?(0,N.jsx)(K,{role:u}):c&&o&&t.pathname!==`/onboarding`?(0,N.jsx)(r,{to:`/onboarding`,replace:!0}):(0,N.jsx)(N.Fragment,{children:e})}function se({error:e}){let t=e=>{window.location.href=e};try{let e=d();t=t=>{try{e(t)}catch{window.location.href=t}}}catch{}return(0,N.jsxs)(`main`,{className:`gq-status-page`,children:[(0,N.jsx)(`style`,{children:`
        .gq-status-page {
          min-height: 100vh;
          background: radial-gradient(circle at 50% 20%, rgba(245, 158, 11, 0.08) 0%, transparent 60%), #f8fafc;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 32px 16px;
          font-family: 'DM Sans', system-ui, -apple-system, sans-serif;
          color: #0f172a;
        }
        .gq-status-card {
          width: 100%;
          max-width: 580px;
          background: #ffffff;
          border: 1px solid #e2e8f0;
          border-radius: 24px;
          padding: 44px 36px;
          text-align: center;
          box-shadow: 0 20px 45px rgba(15, 23, 42, 0.06);
          position: relative;
          overflow: hidden;
        }
        .gq-status-card::before {
          content: "";
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          height: 5px;
          background: linear-gradient(90deg, #f59e0b 0%, #d97706 100%);
        }
        .gq-status-code {
          font-size: clamp(72px, 12vw, 108px);
          font-weight: 950;
          line-height: 0.9;
          letter-spacing: -3px;
          background: linear-gradient(135deg, #d97706 30%, #b45309 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          margin-bottom: 12px;
        }
        .gq-status-badge {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          background: #fffbeb;
          color: #b45309;
          border: 1px solid #fde68a;
          padding: 5px 14px;
          border-radius: 999px;
          font-size: 12px;
          font-weight: 800;
          text-transform: uppercase;
          letter-spacing: 0.06em;
          margin-bottom: 16px;
        }
        .gq-status-title {
          font-size: 24px;
          font-weight: 900;
          color: #0f172a;
          margin: 0 0 10px;
        }
        .gq-status-desc {
          color: #64748b;
          font-size: 14.5px;
          line-height: 1.6;
          max-width: 440px;
          margin: 0 auto 28px;
        }
        .gq-status-actions {
          display: flex;
          justify-content: center;
          gap: 12px;
          flex-wrap: wrap;
        }
        .gq-status-btn-primary {
          background: #0f172a;
          color: #ffffff;
          border: none;
          border-radius: 12px;
          padding: 12px 24px;
          font-weight: 800;
          font-size: 14px;
          cursor: pointer;
          display: inline-flex;
          align-items: center;
          gap: 8px;
          transition: transform 0.15s ease, background 0.15s ease;
        }
        .gq-status-btn-primary:hover {
          background: #1e293b;
          transform: translateY(-1px);
        }
        .gq-status-btn-secondary {
          background: #ffffff;
          color: #334155;
          border: 1px solid #cbd5e1;
          border-radius: 12px;
          padding: 12px 20px;
          font-weight: 700;
          font-size: 14px;
          cursor: pointer;
          display: inline-flex;
          align-items: center;
          gap: 8px;
        }
        .gq-status-btn-secondary:hover {
          background: #f8fafc;
          border-color: #94a3b8;
        }
        .gq-status-footer {
          margin-top: 32px;
          padding-top: 20px;
          border-top: 1px solid #f1f5f9;
          display: flex;
          justify-content: center;
          gap: 20px;
          font-size: 12.5px;
          color: #94a3b8;
        }
        .gq-status-footer a {
          color: #64748b;
          text-decoration: none;
          font-weight: 600;
        }
      `}),(0,N.jsxs)(`div`,{className:`gq-status-card`,children:[(0,N.jsx)(`div`,{className:`gq-status-code`,children:`500`}),(0,N.jsxs)(`div`,{className:`gq-status-badge`,children:[(0,N.jsx)(`i`,{className:`bi bi-exclamation-triangle-fill`}),` Internal Server Error`]}),(0,N.jsx)(`h1`,{className:`gq-status-title`,children:`Something Went Wrong`}),(0,N.jsx)(`p`,{className:`gq-status-desc`,children:`Our servers encountered an unexpected issue while processing your request. Our engineering team has been notified automatically.`}),e&&(0,N.jsxs)(`div`,{style:{background:`#FEF2F2`,border:`1px solid #FCA5A5`,borderRadius:`10px`,padding:`12px 14px`,color:`#991B1B`,fontSize:`12.5px`,textAlign:`left`,marginBottom:`20px`,wordBreak:`break-word`},children:[(0,N.jsx)(`strong`,{children:`Client Error Details:`}),` `,e.message||String(e)]}),(0,N.jsxs)(`div`,{className:`gq-status-actions`,children:[(0,N.jsxs)(`button`,{className:`gq-status-btn-primary`,onClick:()=>window.location.reload(),children:[(0,N.jsx)(`i`,{className:`bi bi-arrow-clockwise`}),` Reload Page`]}),(0,N.jsxs)(`button`,{className:`gq-status-btn-secondary`,onClick:()=>t(`/dashboard`),children:[(0,N.jsx)(`i`,{className:`bi bi-speedometer2`}),` Back to Dashboard`]})]}),(0,N.jsxs)(`div`,{className:`gq-status-footer`,children:[(0,N.jsx)(`a`,{href:`/dashboard`,children:`Dashboard`}),(0,N.jsx)(`span`,{children:`•`}),(0,N.jsx)(`a`,{href:`/contact`,children:`Report Issue`})]})]})]})}var ce=class extends _.Component{constructor(...e){super(...e),this.state={hasError:!1}}static getDerivedStateFromError(e){return{hasError:!0,error:e}}componentDidCatch(e,t){console.error(`SchoolProfit Uncaught Runtime Error:`,e,t)}render(){return this.state.hasError?(0,N.jsx)(se,{error:this.state.error}):this.props.children}};const J=m.create({headers:{"Content-Type":`application/json`,Accept:`application/json`}});J.interceptors.request.use(e=>((!e.baseURL||e.baseURL.includes(`laravel.cloud`))&&(e.baseURL=I()),e));function Y({title:e,suffix:t=`SchoolProfit`}){return(0,_.useEffect)(()=>(document.title=e?`${e} | ${t}`:t,()=>{document.title=t}),[e,t]),null}function X(){let[e,t]=(0,_.useState)(!1),[n,r]=(0,_.useState)(`school`),[i,a]=(0,_.useState)(``),[s,c]=(0,_.useState)(``),[l,u]=(0,_.useState)(!1),[f,p]=(0,_.useState)(``),m=d(),h=async e=>{e.preventDefault(),p(``),t(!0);try{let{access_token:e,user:t}=(await J.post(`/login`,{identifier:i,password:s})).data;switch(E(e),k(t),t.role){case`Admin`:case`Operator`:case`Super-Admin`:case`Platform-Staff`:case`Teacher`:case`Student`:case`Parent`:case`Bursar`:case`Sales-Representative`:m(`/dashboard`);break;default:m(`/unauthorized`)}}catch(e){p(e?.response?.data?.message||`Invalid credentials. Please verify your username and password.`)}finally{t(!1)}},g={school:{badge:`School Community`,eyebrow:`School Academic & Admin Access`,title:`Sign in to your School`,subtitle:`Use your school email, Staff ID, or Student Registration Number.`,inputLabel:`Email, Staff ID, or Student Reg Number`,placeholder:`e.g. admin@school.com or SCH/2026/041`},parent:{badge:`Parents & Guardians`,eyebrow:`Family Portal Access`,title:`Sign in as a Parent`,subtitle:`View your ward's verified term results, fee invoices, and attendance.`,inputLabel:`Registered Email or Phone Number`,placeholder:`e.g. parent@email.com or 08012345678`},platform:{badge:`Central Operations`,eyebrow:`Operations & HQ Console`,title:`Sign in to HQ Console`,subtitle:`Secure access for platform administrators, support engineers, and managers.`,inputLabel:`SchoolProfit Staff Email`,placeholder:`e.g. staff@schoolprofit.ng`}}[n];return(0,N.jsxs)(N.Fragment,{children:[(0,N.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Playfair+Display:ital,wght@0,600;0,800;1,600&display=swap');

        :root {
          --gq-auth-navy: #0F2744;
          --gq-auth-gold: #D97706;
          --gq-auth-border: #E2E8F0;
          --gq-auth-bg: #F8FAFC;
        }

        .gq-auth-wrapper {
          min-height: 100vh;
          display: flex;
          background: var(--gq-auth-bg);
          font-family: 'Plus Jakarta Sans', sans-serif;
        }

        /* ── Left Visual Panel ── */
        .gq-auth-left {
          flex: 1;
          background: linear-gradient(145deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          padding: 48px;
          position: relative;
          overflow: hidden;
          color: #FFFFFF;
        }

        @media (max-width: 991px) {
          .gq-auth-left {
            display: none;
          }
        }

        .gq-auth-left-bg-art {
          position: absolute;
          inset: 0;
          background-image:
            radial-gradient(circle at 10% 20%, rgba(217, 119, 6, 0.15) 0%, transparent 40%),
            radial-gradient(circle at 90% 80%, rgba(29, 78, 216, 0.2) 0%, transparent 45%);
          pointer-events: none;
        }

        .gq-auth-brand-link {
          display: inline-flex;
          align-items: center;
          gap: 12px;
          text-decoration: none;
          z-index: 2;
        }

        .gq-auth-brand-logo {
          width: 40px;
          height: 40px;
          object-fit: contain;
          border-radius: 10px;
        }

        .gq-auth-brand-text {
          font-size: 22px;
          font-weight: 800;
          color: #FFFFFF;
          letter-spacing: -0.02em;
        }

        .gq-auth-left-content {
          position: relative;
          z-index: 2;
          max-width: 500px;
          margin: 40px 0;
        }

        .gq-auth-left-kicker {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 5px 14px;
          border-radius: 999px;
          background: rgba(217, 119, 6, 0.2);
          border: 1px solid rgba(217, 119, 6, 0.4);
          color: #FBBF24;
          font-size: 11.5px;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.06em;
          margin-bottom: 20px;
        }

        .gq-auth-left-title {
          font-family: 'Playfair Display', Georgia, serif;
          font-size: clamp(28px, 3vw, 40px);
          font-weight: 800;
          line-height: 1.2;
          color: #FFFFFF;
          margin-bottom: 16px;
        }

        .gq-auth-left-title em {
          font-style: italic;
          color: #F59E0B;
        }

        .gq-auth-left-desc {
          font-size: 15px;
          color: #CBD5E1;
          line-height: 1.65;
          margin-bottom: 32px;
        }

        /* Testimonial snippet on login page */
        .gq-auth-quote-card {
          background: rgba(255, 255, 255, 0.08);
          backdrop-filter: blur(12px);
          -webkit-backdrop-filter: blur(12px);
          border: 1px solid rgba(255, 255, 255, 0.15);
          border-radius: 16px;
          padding: 20px;
          display: flex;
          align-items: center;
          gap: 16px;
        }

        .gq-quote-avatar {
          width: 52px;
          height: 52px;
          border-radius: 50%;
          object-fit: cover;
          border: 2px solid #F59E0B;
          flex-shrink: 0;
        }

        .gq-quote-text {
          font-size: 13px;
          color: #F1F5F9;
          line-height: 1.5;
          margin-bottom: 6px;
          font-style: italic;
        }

        .gq-quote-author {
          font-size: 12px;
          font-weight: 700;
          color: #FBBF24;
        }

        .gq-auth-left-footer {
          position: relative;
          z-index: 2;
          display: flex;
          align-items: center;
          gap: 20px;
          font-size: 12px;
          color: #94A3B8;
        }

        /* ── Right Form Panel ── */
        .gq-auth-right {
          flex: 1;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 40px 24px;
        }

        .gq-auth-card {
          width: 100%;
          max-width: 440px;
          background: #FFFFFF;
          border: 1px solid var(--gq-auth-border);
          border-radius: 20px;
          padding: 36px 32px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.06);
        }

        .gq-auth-mobile-logo {
          display: none;
          align-items: center;
          gap: 10px;
          text-decoration: none;
          margin-bottom: 24px;
        }

        @media (max-width: 991px) {
          .gq-auth-mobile-logo {
            display: inline-flex;
          }
        }

        /* Portal Tabs */
        .gq-portal-tabs {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          background: #F1F5F9;
          border-radius: 12px;
          padding: 4px;
          gap: 4px;
          margin-bottom: 24px;
        }

        .gq-portal-tab {
          border: none;
          background: transparent;
          font-family: inherit;
          font-size: 12px;
          font-weight: 700;
          color: #64748B;
          padding: 8px 4px;
          border-radius: 8px;
          cursor: pointer;
          transition: all 0.2s ease;
          text-align: center;
        }

        .gq-portal-tab.active {
          background: #FFFFFF;
          color: #0F2744;
          box-shadow: 0 2px 6px rgba(15, 39, 68, 0.08);
        }

        .gq-form-title {
          font-size: 22px;
          font-weight: 800;
          color: #0F2744;
          margin-bottom: 6px;
        }

        .gq-form-subtitle {
          font-size: 13px;
          color: #64748B;
          line-height: 1.5;
          margin-bottom: 24px;
        }

        .gq-form-group {
          margin-bottom: 18px;
        }

        .gq-form-label {
          display: block;
          font-size: 12.5px;
          font-weight: 700;
          color: #1E293B;
          margin-bottom: 6px;
        }

        .gq-input-wrap {
          position: relative;
          display: flex;
          align-items: center;
        }

        .gq-input-icon {
          position: absolute;
          left: 14px;
          color: #94A3B8;
          font-size: 16px;
          pointer-events: none;
        }

        .gq-auth-input {
          width: 100%;
          height: 46px;
          background: #FFFFFF;
          border: 1.5px solid #E2E8F0;
          border-radius: 10px;
          padding: 0 14px 0 42px;
          font-family: inherit;
          font-size: 14px;
          color: #0F172A;
          outline: none;
          transition: all 0.2s ease;
        }

        .gq-auth-input:focus {
          border-color: #D97706;
          box-shadow: 0 0 0 3.5px rgba(217, 119, 6, 0.15);
        }

        .gq-auth-input::placeholder {
          color: #94A3B8;
          font-size: 13px;
        }

        .gq-btn-eye {
          position: absolute;
          right: 12px;
          background: none;
          border: none;
          color: #94A3B8;
          cursor: pointer;
          padding: 4px;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .gq-btn-eye:hover {
          color: #0F2744;
        }

        .gq-auth-options {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 20px;
          font-size: 12.5px;
        }

        .gq-auth-btn-submit {
          width: 100%;
          height: 48px;
          background: #0F2744;
          color: #FFFFFF;
          font-family: inherit;
          font-size: 14px;
          font-weight: 700;
          border: none;
          border-radius: 10px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          transition: all 0.2s ease;
          box-shadow: 0 4px 14px rgba(15, 39, 68, 0.2);
        }

        .gq-auth-btn-submit:hover:not(:disabled) {
          background: #1E3A8A;
          transform: translateY(-1px);
          box-shadow: 0 6px 18px rgba(30, 58, 138, 0.3);
        }

        .gq-auth-btn-submit:disabled {
          opacity: 0.7;
          cursor: not-allowed;
        }

        .gq-auth-error {
          background: #FEF2F2;
          border: 1px solid #FEE2E2;
          color: #B91C1C;
          border-radius: 8px;
          padding: 10px 14px;
          font-size: 12.5px;
          margin-bottom: 18px;
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .gq-auth-footer-links {
          margin-top: 24px;
          padding-top: 20px;
          border-top: 1px solid #F1F5F9;
          text-align: center;
          font-size: 13px;
          color: #64748B;
        }

        .gq-auth-footer-links a {
          color: #D97706;
          font-weight: 700;
          text-decoration: none;
        }

        .gq-auth-footer-links a:hover {
          text-decoration: underline;
        }

        /* Quick shortcuts */
        .gq-quick-links {
          display: flex;
          justify-content: center;
          gap: 8px;
          margin-top: 14px;
          flex-wrap: wrap;
        }

        .gq-quick-btn {
          font-size: 11.5px;
          font-weight: 600;
          color: #475569;
          background: #F8FAFC;
          border: 1px solid #E2E8F0;
          padding: 4px 10px;
          border-radius: 6px;
          text-decoration: none;
          transition: all 0.2s;
        }

        .gq-quick-btn:hover {
          background: #EFF6FF;
          border-color: #BFDBFE;
          color: #1D4ED8;
        }
      `}),(0,N.jsx)(Y,{title:`Sign In | SchoolProfit Portal`}),(0,N.jsxs)(`div`,{className:`gq-auth-wrapper`,children:[(0,N.jsxs)(`div`,{className:`gq-auth-left`,children:[(0,N.jsx)(`div`,{className:`gq-auth-left-bg-art`}),(0,N.jsxs)(o,{to:`/`,className:`gq-auth-brand-link`,children:[(0,N.jsx)(`img`,{src:`/media/logo/schoolprofit-logo.svg`,alt:`SchoolProfit`,className:`gq-auth-brand-logo`,style:{width:`auto`,height:38}}),(0,N.jsxs)(`span`,{className:`gq-auth-brand-text`,children:[`School`,(0,N.jsx)(`span`,{style:{color:`#059669`},children:`Profit`})]})]}),(0,N.jsxs)(`div`,{className:`gq-auth-left-content`,children:[(0,N.jsxs)(`div`,{className:`gq-auth-left-kicker`,children:[(0,N.jsx)(`span`,{children:`⚡`}),` School Growth & Profit OS`]}),(0,N.jsxs)(`h1`,{className:`gq-auth-left-title`,children:[`Stop Fee Defaults & Grow Your School with `,(0,N.jsx)(`em`,{children:`Total Financial Control.`})]}),(0,N.jsx)(`p`,{className:`gq-auth-left-desc`,children:`From automated fee debt recovery and instant multi-bank settlements to 1-click broadsheets and offline CBT exams — SchoolProfit keeps your entire school institution thriving.`}),(0,N.jsxs)(`div`,{className:`gq-auth-quote-card`,children:[(0,N.jsx)(`img`,{src:`/images/testimonials/funmi-bello.jpg`,alt:`Principal`,className:`gq-quote-avatar`}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`p`,{className:`gq-quote-text`,children:`"SchoolProfit eliminated our fee debt defaults and cut result compilation from two weeks down to minutes."`}),(0,N.jsx)(`div`,{className:`gq-quote-author`,children:`Mrs. Deborah Afolabi · Power of Success Int'l School, Lagos`})]})]})]}),(0,N.jsxs)(`div`,{className:`gq-auth-left-footer`,children:[(0,N.jsx)(`span`,{children:`🛡️ 256-Bit SSL Encrypted`}),(0,N.jsx)(`span`,{children:`● 99.9% Uptime`}),(0,N.jsx)(`span`,{children:`● Role-Based Security`})]})]}),(0,N.jsx)(`div`,{className:`gq-auth-right`,children:(0,N.jsxs)(`div`,{className:`gq-auth-card`,children:[(0,N.jsxs)(o,{to:`/`,className:`gq-auth-mobile-logo`,children:[(0,N.jsx)(`img`,{src:`/media/logo/schoolprofit-icon.svg`,alt:`SchoolProfit`,style:{width:32,height:32}}),(0,N.jsxs)(`span`,{style:{fontSize:19,fontWeight:800,color:`#0F2744`},children:[`School`,(0,N.jsx)(`span`,{style:{color:`#059669`},children:`Profit`})]})]}),(0,N.jsxs)(`div`,{className:`gq-portal-tabs`,role:`tablist`,children:[(0,N.jsx)(`button`,{type:`button`,className:`gq-portal-tab ${n===`school`?`active`:``}`,onClick:()=>{r(`school`),p(``)},children:`School Staff`}),(0,N.jsx)(`button`,{type:`button`,className:`gq-portal-tab ${n===`parent`?`active`:``}`,onClick:()=>{r(`parent`),p(``)},children:`Parents`}),(0,N.jsx)(`button`,{type:`button`,className:`gq-portal-tab ${n===`platform`?`active`:``}`,onClick:()=>{r(`platform`),p(``)},children:`HQ & Ops`})]}),(0,N.jsx)(`h2`,{className:`gq-form-title`,children:g.title}),(0,N.jsx)(`p`,{className:`gq-form-subtitle`,children:g.subtitle}),f&&(0,N.jsxs)(`div`,{className:`gq-auth-error`,role:`alert`,children:[(0,N.jsx)(`i`,{className:`bi bi-exclamation-circle-fill`}),(0,N.jsx)(`span`,{children:f})]}),(0,N.jsxs)(`form`,{onSubmit:h,noValidate:!0,children:[(0,N.jsxs)(`div`,{className:`gq-form-group`,children:[(0,N.jsx)(`label`,{className:`gq-form-label`,htmlFor:`identifier`,children:g.inputLabel}),(0,N.jsxs)(`div`,{className:`gq-input-wrap`,children:[(0,N.jsx)(`span`,{className:`gq-input-icon`,children:(0,N.jsx)(`i`,{className:n===`parent`?`bi bi-phone`:n===`platform`?`bi bi-shield-lock`:`bi bi-person`})}),(0,N.jsx)(`input`,{id:`identifier`,type:`text`,className:`gq-auth-input`,placeholder:g.placeholder,value:i,onChange:e=>a(e.target.value),autoComplete:`username`,required:!0})]})]}),(0,N.jsxs)(`div`,{className:`gq-form-group`,children:[(0,N.jsx)(`label`,{className:`gq-form-label`,htmlFor:`password`,children:`Password`}),(0,N.jsxs)(`div`,{className:`gq-input-wrap`,children:[(0,N.jsx)(`span`,{className:`gq-input-icon`,children:(0,N.jsx)(`i`,{className:`bi bi-lock`})}),(0,N.jsx)(`input`,{id:`password`,type:l?`text`:`password`,className:`gq-auth-input`,placeholder:`Enter your password`,value:s,onChange:e=>c(e.target.value),autoComplete:`current-password`,style:{paddingRight:40},required:!0}),(0,N.jsx)(`button`,{type:`button`,className:`gq-btn-eye`,onClick:()=>u(!l),"aria-label":l?`Hide password`:`Show password`,children:(0,N.jsx)(`i`,{className:l?`bi bi-eye-slash`:`bi bi-eye`})})]})]}),(0,N.jsxs)(`div`,{className:`gq-auth-options`,children:[(0,N.jsxs)(`label`,{className:`d-flex align-items-center gap-2`,style:{color:`#475569`,cursor:`pointer`},children:[(0,N.jsx)(`input`,{type:`checkbox`,style:{accentColor:`#D97706`}}),(0,N.jsx)(`span`,{children:`Remember me`})]}),(0,N.jsx)(o,{to:`/forgot-password`,style:{color:`#D97706`,fontWeight:600,textDecoration:`none`},children:`Forgot password?`})]}),(0,N.jsx)(`button`,{type:`submit`,className:`gq-auth-btn-submit`,disabled:e||!i||!s,children:e?(0,N.jsxs)(N.Fragment,{children:[(0,N.jsx)(`span`,{className:`spinner-border spinner-border-sm`,role:`status`,"aria-hidden":`true`}),`Signing in...`]}):(0,N.jsxs)(N.Fragment,{children:[`Sign In to `,g.badge,(0,N.jsx)(`svg`,{width:`15`,height:`15`,viewBox:`0 0 14 14`,fill:`none`,children:(0,N.jsx)(`path`,{d:`M1 7h12M7 1l6 6-6 6`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`})})]})})]}),(0,N.jsxs)(`div`,{className:`gq-quick-links`,children:[(0,N.jsx)(o,{to:`/check-result`,className:`gq-quick-btn`,children:`📜 Check Result (PIN)`}),(0,N.jsx)(o,{to:`/cbt/access`,className:`gq-quick-btn`,children:`💻 CBT Exam Room`})]}),(0,N.jsxs)(`div`,{className:`gq-auth-footer-links`,children:[`New school proprietor or principal?`,` `,(0,N.jsx)(o,{to:`/book-demo`,children:`Request School Demo & Setup`}),(0,N.jsxs)(`div`,{style:{marginTop:6,fontSize:`12px`},children:[`Interested in earning commissions?`,` `,(0,N.jsx)(o,{to:`/sales-representative/register`,children:`Join Sales Partner Program`})]})]})]})})]})]})}var le={support_whatsapp:`2348165748374`,support_whatsapp_raw:`08165748374`,support_email:`support@schoolprofit.ng`,platform_fee_per_student:1e3,formatted_platform_fee:`₦1,000`,sales_partner_term_1_commission:30,sales_partner_retention_commission:12,promo:null},ue=null,de=null;function fe(e,t){return`https://wa.me/${(e||ue?.support_whatsapp||`2348165748374`).replace(/[^0-9]/g,``)}?text=${encodeURIComponent(t||`Hello SchoolProfit, I would like to learn more about the school growth and profit management platform.`)}`}function Z(){let[e,t]=(0,_.useState)(de||[]),[n,r]=(0,_.useState)(ue||le),[i,a]=(0,_.useState)(!de),[o,s]=(0,_.useState)(!1);return(0,_.useEffect)(()=>{let e=!0;async function n(){try{let n=await z.get(`/frontend/subscription-plans`);if(!e)return;let i=Array.isArray(n.data?.data)?n.data.data:[],a=n.data?.platform||le;de=i,ue=a,t(i),r(a)}catch{if(!e)return;s(!0)}finally{e&&a(!1)}}return n(),()=>{e=!1}},[]),{plans:e,platform:n,loading:i,error:o,whatsappLink:e=>fe(n.support_whatsapp,e),whatsappNumber:n.support_whatsapp,formattedPlatformFee:n.formatted_platform_fee||`₦1,000`}}var pe=[{tag:`Security`,q:`How secure is our school's academic and financial data on SchoolProfit?`,a:`Bank-grade. All data is encrypted both at rest (AES-256) and in transit (SSL/TLS). Every account uses strict role-based access control — meaning teachers only access their assigned classes, bursars manage finance ledgers, and proprietors maintain overarching branch oversight. We perform automated daily backups and maintain detailed audit logs.`},{tag:`Results`,q:`How does automated result computation and broadsheet compilation work?`,a:`Teachers upload Continuous Assessment (CA) and examination scores through their authenticated portal. SchoolProfit automatically computes totals, weighted averages, class positions, and cumulative GPAs adhering to NERDC standards — generating print-ready master broadsheets and transcripts in seconds.`},{tag:`CBT Exams`,q:`Can we conduct computer-based assessments in our lab without full-time internet?`,a:`Yes. SchoolProfit features a hybrid LAN offline testing engine. Computer laboratories can administer continuous assessments, mock exams, and timed tests on a local network. Student answers are auto-saved locally in real-time and synchronize seamlessly to academic records when connected.`},{tag:`Bursary`,q:`How does the fee management module track tuition and receipts?`,a:`The bursary module provides a clear, real-time ledger for every enrolled student — detailing billed amounts, payment history, and outstanding balances. You can record payments, generate electronic receipts with cryptographic verification seals, and automate statements for parents.`},{tag:`AI Tools`,q:`How does the AI Assistant support teaching staff?`,a:`The AI Assistant helps teachers structure curriculum-compliant schemes of work, generate weekly lesson notes, and compose personalized student evaluations. It also alerts academic coordinators to incomplete score submissions before publishing deadlines.`},{tag:`Parent Access`,q:`How do parents receive report cards and school updates?`,a:`Parents access authenticated result links, daily attendance logs, and school notices directly on their mobile phones via direct WhatsApp and SMS notifications, eliminating the friction of unread portal emails or lost physical reports.`},{tag:`Migration`,q:`We have years of existing student records in Excel. How difficult is migration?`,a:`Effortless. Our onboarding team provides standard Excel/CSV templates. Once uploaded, we validate and import all historical student and academic records within 24 hours with zero operational downtime.`}],me={Security:{color:`#1D4ED8`,bg:`rgba(29, 78, 216, 0.1)`},Results:{color:`#059669`,bg:`rgba(5, 150, 105, 0.1)`},"CBT Exams":{color:`#1D4ED8`,bg:`rgba(29, 78, 216, 0.12)`},Bursary:{color:`#D97706`,bg:`rgba(217, 119, 6, 0.12)`},"AI Tools":{color:`#DB2777`,bg:`rgba(219, 39, 119, 0.12)`},"Parent Access":{color:`#059669`,bg:`rgba(5, 150, 105, 0.12)`},Migration:{color:`#7C3AED`,bg:`rgba(124, 58, 237, 0.12)`},Support:{color:`#D97706`,bg:`rgba(217, 119, 6, 0.12)`}};function he({faq:e,index:t,open:n,onToggle:r}){let i=(0,_.useRef)(null),a=me[e.tag]??me.Support;return(0,_.useEffect)(()=>{let e=i.current;e&&(n?(e.style.maxHeight=e.scrollHeight+`px`,e.style.opacity=`1`):(e.style.maxHeight=`0px`,e.style.opacity=`0`))},[n]),(0,N.jsxs)(`div`,{className:`fq-item ${n?`fq-item--open`:``}`,style:{"--c":a.color,"--c-bg":a.bg},children:[(0,N.jsxs)(`button`,{className:`fq-question w-100`,onClick:r,"aria-expanded":n,children:[(0,N.jsxs)(`span`,{className:`fq-question-left d-flex flex-column gap-2 flex-grow-1`,children:[(0,N.jsx)(`span`,{className:`fq-tag`,children:e.tag}),(0,N.jsx)(`span`,{className:`fq-q-text`,children:e.q})]}),(0,N.jsx)(`span`,{className:`fq-icon flex-shrink-0`,"aria-hidden":`true`,children:(0,N.jsx)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:(0,N.jsx)(`path`,{d:`M4 6l4 4 4-4`,stroke:`currentColor`,strokeWidth:`1.7`,strokeLinecap:`round`,strokeLinejoin:`round`})})})]}),(0,N.jsx)(`div`,{ref:i,className:`fq-body`,style:{maxHeight:0,opacity:0},children:(0,N.jsx)(`p`,{className:`fq-answer`,children:e.a})})]})}function ge(e,t=0){(0,_.useEffect)(()=>{let n=e.current;if(!n)return;let r=new IntersectionObserver(([e])=>{e.isIntersecting&&(setTimeout(()=>n.classList.add(`fq-visible`),t),r.disconnect())},{threshold:.08});return r.observe(n),()=>r.disconnect()},[e,t])}function _e(){let{whatsappLink:e}=Z(),[t,n]=(0,_.useState)(0),r=(0,_.useRef)(null),i=(0,_.useRef)(null);ge(r,0),ge(i,300);let a=pe.filter((e,t)=>t%2==0),o=pe.filter((e,t)=>t%2!=0),s=e=>n(t=>t===e?null:e);return(0,N.jsxs)(N.Fragment,{children:[(0,N.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;0,900;1,700&family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');

        :root {
          --fq-bg: #F8FAFC;
          --fq-source: #FFFFFF;
          --fq-dark: #0F2744;
          --fq-accent: #D97706;
          --fq-gold-light: #F59E0B;
          --fq-muted: #64748B;
          --fq-border: #E2E8F0;
          --fq-card-bg: #FFFFFF;

          --fq-accent-glow: rgba(217, 119, 6, 0.07);
          --fq-accent-border: rgba(217, 119, 6, 0.22);
          --fq-accent-ring: rgba(217, 119, 6, 0.10);
        }

        .fq-wave {
          display: block;
          width: 100%;
          overflow: hidden;
          line-height: 0;
          background: var(--fq-source);
        }
        .fq-wave svg {
          display: block;
          width: 100%;
          height: 56px;
        }

        .fq-section {
          background: var(--fq-bg);
          padding: 108px 0 128px;
          position: relative;
          overflow: hidden;
          font-family: 'Plus Jakarta Sans', sans-serif;
          border-top: 1px solid #E2E8F0;
        }

        .fq-inner {
          position: relative;
          z-index: 1;
        }

        @media (max-width: 640px) {
          .fq-section {
            padding: 72px 0 88px;
          }
        }

        .fq-header {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 48px;
          align-items: end;
          margin-bottom: 72px;
        }
        @media (max-width: 800px) {
          .fq-header {
            grid-template-columns: 1fr;
            gap: 20px;
          }
        }

        .fq-kicker {
          display: inline-flex;
          align-items: center;
          gap: 10px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.16em;
          text-transform: uppercase;
          color: #B45309;
          background: #FFFFFF;
          border: 1px solid rgba(217, 119, 6, 0.25);
          padding: 5px 14px;
          border-radius: 999px;
        }

        .fq-kicker__line {
          display: block;
          width: 20px;
          height: 2px;
          background: #D97706;
          border-radius: 99px;
        }

        .fq-title {
          font-family: 'Playfair Display', Georgia, serif;
          font-size: clamp(30px, 3.8vw, 50px);
          font-weight: 900;
          color: var(--fq-dark);
          line-height: 1.15;
        }

        .fq-title em {
          font-style: italic;
          color: #D97706;
          background: linear-gradient(135deg, #D97706 0%, #B45309 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
        }

        .fq-desc {
          font-size: 15.5px;
          font-weight: 400;
          color: var(--fq-muted);
          max-width: 380px;
          line-height: 1.7;
        }

        .fq-filter-pill {
          font-size: 12px;
          font-weight: 600;
          color: #475569;
          background: var(--fq-card-bg);
          border: 1px solid var(--fq-border);
          border-radius: 100px;
          padding: 6px 16px;
          cursor: default;
          transition: background .2s, border-color .2s, color .2s;
        }
        .fq-filter-pill:hover {
          background: rgba(217, 119, 6, 0.1);
          border-color: rgba(217, 119, 6, 0.35);
          color: #0F2744;
        }

        .fq-col {
          display: flex;
          flex-direction: column;
        }

        .fq-item {
          border-bottom: 1px solid var(--fq-border);
          transition: background .2s;
        }
        .fq-item:first-child {
          border-top: 1px solid var(--fq-border);
        }
        .fq-item--open {
          background: var(--fq-card-bg);
          border-radius: 12px;
          padding: 0 16px;
          border: 1px solid #E2E8F0;
          margin-bottom: 10px;
          box-shadow: 0 4px 16px rgba(15, 39, 68, 0.04);
        }

        .fq-question {
          background: none;
          border: none;
          padding: 22px 20px 18px 0;
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: 16px;
          cursor: pointer;
          text-align: left;
        }

        .fq-tag {
          display: inline-block;
          width: fit-content;
          font-size: 10.5px;
          font-weight: 700;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          color: var(--c);
          background: var(--c-bg);
          border-radius: 100px;
          padding: 3px 10px;
          transition: opacity .2s;
        }
        .fq-item:not(.fq-item--open) .fq-tag {
          opacity: 0.85;
        }

        .fq-q-text {
          font-family: 'Playfair Display', Georgia, serif;
          font-size: 16.5px;
          font-weight: 700;
          color: var(--fq-dark);
          line-height: 1.35;
          transition: color .2s;
        }

        .fq-question:hover .fq-q-text,
        .fq-item--open .fq-q-text {
          color: #0F2744;
        }

        .fq-icon {
          width: 30px;
          height: 30px;
          border-radius: 50%;
          background: #F1F5F9;
          border: 1px solid #E2E8F0;
          display: flex;
          align-items: center;
          justify-content: center;
          margin-top: 4px;
          color: #64748B;
          transition: background .25s, color .25s, transform .3s;
        }
        .fq-item--open .fq-icon {
          background: var(--c-bg);
          color: var(--c);
          transform: rotate(180deg);
        }

        .fq-body {
          overflow: hidden;
          transition: max-height .4s cubic-bezier(.4,0,.2,1), opacity .35s ease;
        }

        .fq-item--open .fq-body {
          margin-top: -2px;
        }

        .fq-answer {
          font-size: 14.5px;
          font-weight: 400;
          line-height: 1.8;
          color: #475569;
          margin: 0;
          padding: 2px 8px 26px 0;
          max-width: 520px;
        }

        .fq-cta {
          border-radius: 20px;
          padding: 44px 52px;
          background: #0F2744;
          border: 1px solid rgba(255, 255, 255, 0.1);
          box-shadow: 0 16px 40px rgba(15, 39, 68, 0.15);
          position: relative;
          overflow: hidden;
          opacity: 0;
          transform: translateY(18px);
          transition: opacity .65s ease, transform .65s ease;
        }
        .fq-cta.fq-visible {
          opacity: 1;
          transform: translateY(0);
        }

        .fq-cta-eyebrow {
          display: block;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.18em;
          text-transform: uppercase;
          color: #FBBF24;
        }

        .fq-cta-heading {
          font-family: 'Playfair Display', serif;
          font-size: clamp(20px, 2.4vw, 28px);
          font-weight: 800;
          color: #FFFFFF;
          line-height: 1.3;
          max-width: 400px;
        }

        .btn-fq-primary {
          background: linear-gradient(135deg, #D97706 0%, #B45309 100%);
          color: #FFFFFF;
          border: none;
          font-family: 'Plus Jakarta Sans', sans-serif;
          font-size: 14px;
          font-weight: 700;
          border-radius: 10px;
          transition: all .2s ease;
          white-space: nowrap;
          box-shadow: 0 4px 14px rgba(217, 119, 6, 0.3);
        }
        .btn-fq-primary:hover {
          background: linear-gradient(135deg, #F59E0B 0%, #D97706 100%);
          color: #FFFFFF;
          transform: translateY(-2px);
          box-shadow: 0 8px 24px rgba(217, 119, 6, 0.45);
        }

        .btn-fq-ghost {
          background: rgba(255, 255, 255, 0.08);
          color: #FFFFFF;
          border: 1px solid rgba(255, 255, 255, 0.2);
          font-family: 'Plus Jakarta Sans', sans-serif;
          font-size: 14px;
          font-weight: 600;
          border-radius: 10px;
          transition: all .2s ease;
          white-space: nowrap;
        }
        .btn-fq-ghost:hover {
          background: rgba(255, 255, 255, 0.16);
          color: #FFFFFF;
          border-color: rgba(255, 255, 255, 0.4);
          transform: translateY(-2px);
        }

        [data-fq-reveal] {
          opacity: 0;
          transform: translateY(18px);
          transition: opacity .65s ease, transform .65s ease;
        }
        [data-fq-reveal].fq-visible {
          opacity: 1;
          transform: translateY(0);
        }

        @media (max-width: 640px) {
          .fq-cta {
            padding: 32px 24px;
          }
        }
      `}),(0,N.jsx)(`div`,{className:`fq-wave`,children:(0,N.jsx)(`svg`,{viewBox:`0 0 1440 56`,preserveAspectRatio:`none`,xmlns:`http://www.w3.org/2000/svg`,children:(0,N.jsx)(`path`,{d:`M0,12 C360,56 720,0 1080,32 C1260,48 1380,18 1440,8 L1440,56 L0,56 Z`,fill:`#F8FAFC`})})}),(0,N.jsx)(`section`,{className:`fq-section`,id:`faq`,children:(0,N.jsxs)(`div`,{className:`fq-inner container-xl`,children:[(0,N.jsxs)(`div`,{ref:r,"data-fq-reveal":``,className:`fq-header`,children:[(0,N.jsxs)(`div`,{children:[(0,N.jsxs)(`div`,{className:`fq-kicker mb-3`,children:[(0,N.jsx)(`span`,{className:`fq-kicker__line`}),`Common questions`]}),(0,N.jsxs)(`h2`,{className:`fq-title mb-3`,children:[`Everything you`,(0,N.jsx)(`br`,{}),(0,N.jsx)(`em`,{children:`wanted to ask.`})]}),(0,N.jsx)(`p`,{className:`fq-desc mb-0`,children:`Straight answers about security, results, fees, onboarding, and pricing — no fluff, no sales spin.`})]}),(0,N.jsx)(`div`,{className:`d-flex flex-wrap gap-2 align-self-end`,children:Object.keys(me).map(e=>(0,N.jsx)(`span`,{className:`fq-filter-pill`,children:e},e))})]}),(0,N.jsxs)(`div`,{className:`row g-4`,children:[(0,N.jsx)(`div`,{className:`col-12 col-md-6`,children:(0,N.jsx)(`div`,{className:`fq-col`,children:a.map(e=>{let n=pe.indexOf(e);return(0,N.jsx)(he,{faq:e,index:n,open:t===n,onToggle:()=>s(n)},e.q)})})}),(0,N.jsx)(`div`,{className:`col-12 col-md-6`,children:(0,N.jsx)(`div`,{className:`fq-col`,children:o.map(e=>{let n=pe.indexOf(e);return(0,N.jsx)(he,{faq:e,index:n,open:t===n,onToggle:()=>s(n)},e.q)})})})]}),(0,N.jsxs)(`div`,{ref:i,className:`fq-cta d-flex align-items-center justify-content-between flex-wrap gap-4 mt-5`,children:[(0,N.jsxs)(`div`,{className:`position-relative`,style:{zIndex:1},children:[(0,N.jsx)(`span`,{className:`fq-cta-eyebrow mb-2`,children:`Still have questions?`}),(0,N.jsx)(`h3`,{className:`fq-cta-heading mb-0`,children:`Talk to a school operations specialist.`})]}),(0,N.jsxs)(`div`,{className:`d-flex flex-wrap gap-3 position-relative`,style:{zIndex:1},children:[(0,N.jsxs)(`a`,{href:`/book-demo`,className:`btn btn-fq-primary d-inline-flex align-items-center gap-2 px-4 py-3`,children:[`Book a Live Demo`,(0,N.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:(0,N.jsx)(`path`,{d:`M1 7h12M7 1l6 6-6 6`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`,strokeLinejoin:`round`})})]}),(0,N.jsxs)(`a`,{href:e(`Hello SchoolProfit, I have a few questions regarding the platform for our school.`),target:`_blank`,rel:`noopener noreferrer`,className:`btn btn-fq-ghost d-inline-flex align-items-center gap-2 px-4 py-3`,children:[`Chat on WhatsApp`,(0,N.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 24 24`,fill:`none`,children:(0,N.jsx)(`path`,{d:`M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`,strokeLinejoin:`round`})})]})]})]})]})})]})}var ve=[{id:`results`,badge:`Academic Leadership`,badgeColor:`#059669`,badgeBg:`rgba(5, 150, 105, 0.1)`,icon:`📊`,title:`Instant Master Broadsheets & Report Cards`,subtitle:`Automated Standard & Cumulative Grading`,text:`Upload Continuous Assessment (CA) and exam scores in bulk. SchoolProfit automatically calculates totals, grades, positions, subject rankings, and generates print-ready master broadsheets in seconds.`,highlights:[`Auto-calculates standardized grades, cumulative GPAs, and class positions`,`One-click broadsheet download in publication-ready Excel and PDF`,`Pre-filled teacher remarks & psychomotor domain evaluations`],span:`col-lg-7`},{id:`fees`,badge:`Bursary Governance`,badgeColor:`#D97706`,badgeBg:`rgba(217, 119, 6, 0.1)`,icon:`💳`,title:`Comprehensive Student Fees Ledger`,subtitle:`Real-Time Tracking & Digital Receipts`,text:`Maintain complete financial clarity over tuition and termly levies. Track student payment statuses, record direct bank settlements, and issue automated electronic receipts with zero reconciliation gaps.`,highlights:[`Term-by-term financial collection and balance breakdown`,`Instant electronic receipts delivered automatically to parents`,`Automated financial reports for school administration`],span:`col-lg-5`},{id:`cbt`,badge:`Assessment Engine`,badgeColor:`#1D4ED8`,badgeBg:`rgba(29, 78, 216, 0.1)`,icon:`💻`,title:`Online & Offline LAN CBT Exam Center`,subtitle:`Dual Infrastructure for School Computer Labs`,text:`Administer timed continuous assessment tests and mock examinations in school computer laboratories. Our local synchronization engine ensures exams proceed smoothly even during network disruptions.`,highlights:[`Offline local network (LAN) sync engine with local state recovery`,`Instant student auto-grading & direct score export into broadsheets`,`Supports complex mathematical equations, diagrams, and timed test sessions`],span:`col-lg-6`},{id:`verification`,badge:`Credential Protection`,badgeColor:`#7C3AED`,badgeBg:`rgba(124, 58, 237, 0.1)`,icon:`🛡️`,title:`Cryptographic QR Academic Verification`,subtitle:`Tamper-Proof Result & Transcript Security`,text:`Every generated report card and academic transcript carries a cryptographic QR verification seal that tertiary institutions, embassies, and parents can verify with any mobile camera.`,highlights:[`Instant real-time verification portal on your institution's profile`,`Protects institutional credibility against forged credentials`,`Encrypted digital certificate issuance and archival`],span:`col-lg-6`},{id:`whatsapp`,badge:`Mobile Connectivity`,badgeColor:`#059669`,badgeBg:`rgba(5, 150, 105, 0.1)`,icon:`💬`,title:`Direct WhatsApp & SMS Parent Dispatches`,subtitle:`Delivered Directly to Parents' Phones`,text:`Deliver digital report cards, daily student attendance clock-ins, fee invoices, and urgent administrative announcements directly to parents' WhatsApp with one single click.`,highlights:[`1-click broadcast result link dispatch with secure access PINs`,`Automated daily student clock-in and attendance notifications`,`Broadcast PTA meeting and term resumption notices`],span:`col-lg-6`},{id:`ai`,badge:`Faculty Assistant`,badgeColor:`#DB2777`,badgeBg:`rgba(219, 39, 119, 0.1)`,icon:`🤖`,title:`AI Lesson Planner & Academic Assistant`,subtitle:`Intelligent Curricular Support for Teachers`,text:`Empower your teaching staff with intelligent tools to structure curriculum-aligned schemes of work, generate weekly lesson notes, and compose personalized student evaluations without fatigue.`,highlights:[`Curriculum-compliant schemes of work and lesson notes generation`,`Intelligent score outlier alerts and academic trend diagnostics`,`Automated personalized remarks based on student performance`],span:`col-lg-6`}];function ye(){let e=(0,_.useRef)(null);return(0,_.useEffect)(()=>{let t=new IntersectionObserver(e=>{e.forEach(e=>{e.isIntersecting&&e.target.classList.add(`gq-revealed`)})},{threshold:.1});return(e.current?.querySelectorAll(`.gq-feature-card`))?.forEach(e=>t.observe(e)),()=>t.disconnect()},[]),(0,N.jsxs)(N.Fragment,{children:[(0,N.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Playfair+Display:ital,wght@0,600;0,800;1,600&display=swap');

        .gq-features-section {
          background-color: #F8FAFC;
          position: relative;
          padding: 104px 0;
          color: #0F172A;
          font-family: 'Plus Jakarta Sans', sans-serif;
          overflow: hidden;
          border-top: 1px solid #E2E8F0;
        }

        .gq-feat-kicker {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 6px 16px;
          border-radius: 999px;
          background: #FFFFFF;
          border: 1px solid rgba(217, 119, 6, 0.3);
          color: #B45309;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.06em;
          text-transform: uppercase;
          margin-bottom: 18px;
          box-shadow: 0 2px 8px rgba(15, 39, 68, 0.04);
        }

        .gq-feat-heading {
          font-family: 'Playfair Display', Georgia, serif;
          font-size: clamp(30px, 3.8vw, 48px);
          font-weight: 800;
          color: #0F2744;
          line-height: 1.18;
          margin-bottom: 18px;
          letter-spacing: -0.01em;
        }

        .gq-feat-heading em {
          font-style: italic;
          color: #D97706;
          background: linear-gradient(135deg, #D97706 0%, #B45309 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
        }

        .gq-feat-subtitle {
          font-size: 16px;
          color: #475569;
          max-width: 620px;
          margin: 0 auto 56px auto;
          line-height: 1.7;
        }

        /* ── Bento Grid Feature Card ── */
        .gq-feature-card {
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: 20px;
          padding: 36px 32px;
          height: 100%;
          display: flex;
          flex-direction: column;
          position: relative;
          transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
          box-shadow: 0 4px 20px rgba(15, 39, 68, 0.04);
          opacity: 0;
          transform: translateY(24px);
        }

        .gq-feature-card.gq-revealed {
          opacity: 1;
          transform: translateY(0);
        }

        .gq-feature-card:hover {
          border-color: rgba(217, 119, 6, 0.45);
          transform: translateY(-6px);
          box-shadow: 0 16px 40px rgba(15, 39, 68, 0.09);
        }

        .gq-feat-top {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 22px;
        }

        .gq-feat-icon-wrap {
          width: 52px;
          height: 52px;
          border-radius: 14px;
          background: #F8FAFC;
          border: 1px solid #E2E8F0;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 26px;
        }

        .gq-feat-pill {
          font-size: 11.5px;
          font-weight: 700;
          padding: 4px 12px;
          border-radius: 999px;
          letter-spacing: 0.03em;
        }

        .gq-feat-title {
          font-size: 20px;
          font-weight: 700;
          color: #0F2744;
          margin-bottom: 6px;
          line-height: 1.3;
        }

        .gq-feat-sub {
          font-size: 12px;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          color: #D97706;
          margin-bottom: 14px;
        }

        .gq-feat-desc {
          font-size: 14.5px;
          color: #475569;
          line-height: 1.68;
          margin-bottom: 24px;
          flex-grow: 1;
        }

        .gq-feat-list {
          list-style: none;
          padding: 0;
          margin: 0;
          display: flex;
          flex-direction: column;
          gap: 10px;
          border-top: 1px solid #F1F5F9;
          padding-top: 20px;
        }

        .gq-feat-list-item {
          display: flex;
          align-items: center;
          gap: 10px;
          font-size: 13.5px;
          color: #334155;
          font-weight: 500;
        }

        .gq-feat-check {
          width: 20px;
          height: 20px;
          border-radius: 50%;
          background: #ECFDF5;
          color: #059669;
          border: 1px solid #A7F3D0;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 11px;
          font-weight: 800;
          flex-shrink: 0;
        }

        /* ── Bottom Banner CTA ── */
        .gq-feat-banner {
          margin-top: 72px;
          background: linear-gradient(135deg, #0F2744 0%, #1E3A8A 100%);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 24px;
          padding: 48px 40px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          flex-wrap: wrap;
          gap: 28px;
          box-shadow: 0 20px 50px rgba(15, 39, 68, 0.15);
        }

        .gq-banner-title {
          font-family: 'Playfair Display', serif;
          font-size: clamp(22px, 2.5vw, 32px);
          font-weight: 800;
          color: #FFFFFF;
          margin-bottom: 8px;
        }

        .gq-banner-desc {
          font-size: 14.5px;
          color: #E2E8F0;
          max-width: 580px;
          margin: 0;
          line-height: 1.6;
        }

        .gq-btn-cta-main {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 10px;
          padding: 14px 28px;
          font-size: 15px;
          font-weight: 700;
          color: #0F2744;
          background: #FFFFFF;
          border-radius: 10px;
          text-decoration: none;
          box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
          transition: all 0.25s ease;
        }

        .gq-btn-cta-main:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 24px rgba(255, 255, 255, 0.25);
          color: #1D4ED8;
          background: #FFFFFF;
        }

        .gq-btn-cta-secondary {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 10px;
          padding: 14px 24px;
          font-size: 15px;
          font-weight: 600;
          color: #FFFFFF;
          background: rgba(255, 255, 255, 0.1);
          border: 1px solid rgba(255, 255, 255, 0.25);
          border-radius: 10px;
          text-decoration: none;
          transition: all 0.25s ease;
        }

        .gq-btn-cta-secondary:hover {
          background: rgba(255, 255, 255, 0.18);
          border-color: rgba(255, 255, 255, 0.4);
          color: #FFFFFF;
          transform: translateY(-2px);
        }
      `}),(0,N.jsx)(`section`,{id:`features`,ref:e,className:`gq-features-section gq-scroll-reveal`,children:(0,N.jsxs)(`div`,{className:`container-xl`,children:[(0,N.jsxs)(`div`,{className:`text-center`,children:[(0,N.jsxs)(`div`,{className:`gq-feat-kicker`,children:[(0,N.jsx)(`span`,{children:`⚡`}),` Purpose-Built Architecture`]}),(0,N.jsxs)(`h2`,{className:`gq-feat-heading`,children:[`Everything Your School Needs to Run `,(0,N.jsx)(`em`,{children:`Flawlessly`})]}),(0,N.jsx)(`p`,{className:`gq-feat-subtitle`,children:`We studied the biggest operational hurdles in primary and secondary schools — from delayed score submissions to fee collection deficits — and engineered a unified operating system to solve them permanently.`})]}),(0,N.jsx)(`div`,{className:`row g-4`,children:ve.map(e=>(0,N.jsx)(`div`,{className:e.span,children:(0,N.jsxs)(`div`,{className:`gq-feature-card`,children:[(0,N.jsxs)(`div`,{className:`gq-feat-top`,children:[(0,N.jsx)(`div`,{className:`gq-feat-icon-wrap`,children:e.icon}),(0,N.jsx)(`span`,{className:`gq-feat-pill`,style:{color:e.badgeColor,backgroundColor:e.badgeBg,border:`1px solid ${e.badgeColor}40`},children:e.badge})]}),(0,N.jsx)(`h3`,{className:`gq-feat-title`,children:e.title}),(0,N.jsx)(`div`,{className:`gq-feat-sub`,children:e.subtitle}),(0,N.jsx)(`p`,{className:`gq-feat-desc`,children:e.text}),(0,N.jsx)(`ul`,{className:`gq-feat-list`,children:e.highlights.map((e,t)=>(0,N.jsxs)(`li`,{className:`gq-feat-list-item`,children:[(0,N.jsx)(`span`,{className:`gq-feat-check`,children:`✓`}),(0,N.jsx)(`span`,{children:e})]},t))})]})},e.id))}),(0,N.jsxs)(`div`,{className:`gq-feat-banner`,children:[(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`h3`,{className:`gq-banner-title`,children:`Ready to modernize your school operations?`}),(0,N.jsx)(`p`,{className:`gq-banner-desc`,children:`Join leading private schools that rely on SchoolProfit every term to stop fee defaults, scale admissions, and deliver error-free broadsheets.`})]}),(0,N.jsxs)(`div`,{className:`d-flex flex-wrap gap-3`,children:[(0,N.jsxs)(o,{to:`/book-demo`,className:`gq-btn-cta-main`,style:{padding:`13px 26px`},children:[`Book a Live Demo / Request Setup`,(0,N.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,children:(0,N.jsx)(`path`,{d:`M1 7h12M7 1l6 6-6 6`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`})})]}),(0,N.jsx)(`a`,{href:`https://wa.me/2348165748374?text=Hello%20SchoolProfit%2C%20I%20want%20to%20request%20a%20demo%20for%20my%20school`,target:`_blank`,rel:`noreferrer`,className:`gq-btn-cta-secondary`,style:{padding:`13px 22px`},children:`Chat on WhatsApp`})]})]})]})})]})}function be(){let{whatsappLink:e,platform:t}=Z(),n=new Date().getFullYear(),r=t.sales_partner_term_1_commission||30,i=t.sales_partner_retention_commission||12,[a,o]=(0,_.useState)(``),[s,c]=(0,_.useState)(!1),[l,u]=(0,_.useState)(!1),[d,f]=(0,_.useState)(``),[p,m]=(0,_.useState)(``),h=async e=>{e.preventDefault(),m(``);let t=a.trim();if(!t){m(`Please enter your email.`);return}c(!0);try{let e=await J.post(`/frontend/newsletter-subscribe`,{email:t,source:`homepage_footer`});u(!0),f(e.data?.message||`Subscribed successfully! Thank you for staying connected.`),o(``),setTimeout(()=>{u(!1),f(``)},7e3)}catch(e){m(e?.response?.data?.message||`Subscription failed. Please check your email and try again.`)}finally{c(!1)}},g={Product:[{label:`Student Management`,href:`#features`},{label:`Why SchoolProfit`,href:`#why-schoolprofit`},{label:`Results & PIN System`,href:`#features`},{label:`Fee Collections & Debt Control`,href:`#features`},{label:`AI Teacher Assistant`,href:`#features`},{label:`Parent Portal`,href:`#features`}],Partners:[{label:`Become a Sales Partner`,href:`/sales-representative/register`},{label:`Earn ${r}% Commission`,href:`/sales-representative/register`},{label:`Partner Login Portal`,href:`/login`},{label:`Marketing Kit & Tools`,href:`/login`}],Company:[{label:`About Us`,href:`#`},{label:`Our Schools`,href:`#schools`},{label:`Educational Blog`,href:`#blog`},{label:`Pricing`,href:`#pricing`},{label:`Facebook Page`,href:`https://web.facebook.com/profile.php?id=61585446674333`},{label:`Testimonials`,href:`#testimonials`},{label:`Book a Demo`,href:`/book-demo`}],Support:[{label:`Help Centre`,href:`#`},{label:`WhatsApp Support`,href:e(`Hello SchoolProfit, I would like support regarding my school portal.`)},{label:`Facebook Community`,href:`https://web.facebook.com/profile.php?id=61585446674333`},{label:`Privacy Policy`,href:`/privacy-policy`},{label:`Terms of Service`,href:`/terms-and-conditions`}]},v=[{label:`Facebook`,href:`https://web.facebook.com/profile.php?id=61585446674333`,icon:(0,N.jsx)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 24 24`,fill:`none`,"aria-hidden":`true`,children:(0,N.jsx)(`path`,{d:`M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3V2z`,stroke:`currentColor`,strokeWidth:`1.8`,strokeLinecap:`round`,strokeLinejoin:`round`})})},{label:`WhatsApp`,href:e(`Hello SchoolProfit, I want to connect with your team.`),icon:(0,N.jsx)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 24 24`,fill:`none`,"aria-hidden":`true`,children:(0,N.jsx)(`path`,{d:`M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`,strokeLinejoin:`round`})})},{label:`Twitter / X`,href:`#`,icon:(0,N.jsx)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 24 24`,fill:`none`,"aria-hidden":`true`,children:(0,N.jsx)(`path`,{d:`M4 4l16 16M4 20L20 4`,stroke:`currentColor`,strokeWidth:`1.8`,strokeLinecap:`round`})})},{label:`LinkedIn`,href:`#`,icon:(0,N.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 24 24`,fill:`none`,"aria-hidden":`true`,children:[(0,N.jsx)(`rect`,{x:`2`,y:`2`,width:`20`,height:`20`,rx:`4`,stroke:`currentColor`,strokeWidth:`1.6`}),(0,N.jsx)(`path`,{d:`M7 10v7M7 7v.5`,stroke:`currentColor`,strokeWidth:`1.8`,strokeLinecap:`round`}),(0,N.jsx)(`path`,{d:`M12 17v-4a2 2 0 014 0v4M12 10v7`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`,strokeLinejoin:`round`})]})},{label:`Instagram`,href:`#`,icon:(0,N.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 24 24`,fill:`none`,"aria-hidden":`true`,children:[(0,N.jsx)(`rect`,{x:`2`,y:`2`,width:`20`,height:`20`,rx:`5`,stroke:`currentColor`,strokeWidth:`1.6`}),(0,N.jsx)(`circle`,{cx:`12`,cy:`12`,r:`4`,stroke:`currentColor`,strokeWidth:`1.5`}),(0,N.jsx)(`circle`,{cx:`17.5`,cy:`6.5`,r:`1`,fill:`currentColor`})]})}],y=[{label:`99.9% uptime SLA`,icon:(0,N.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:(0,N.jsx)(`path`,{d:`M8 2l2 4h4l-3 2.6 1.2 4L8 10.3 3.8 12.6 5 8.6 2 6h4z`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinejoin:`round`})})},{label:`End-to-end encrypted`,icon:(0,N.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,N.jsx)(`path`,{d:`M8 2l5 2v4c0 3.5-2.5 6-5 7C5.5 14 3 11.5 3 8V4l5-2z`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinejoin:`round`}),(0,N.jsx)(`path`,{d:`M5.5 8l2 2 3-3`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})]})},{label:`Daily automated backups`,icon:(0,N.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,N.jsx)(`path`,{d:`M13 8A5 5 0 113 8`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,N.jsx)(`path`,{d:`M13 4v4h-4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})]})},{label:`Verified data compliance`,icon:(0,N.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,N.jsx)(`rect`,{x:`2`,y:`2`,width:`12`,height:`12`,rx:`2.5`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,N.jsx)(`path`,{d:`M5 8l2 2 4-4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})]})}];return(0,N.jsxs)(N.Fragment,{children:[(0,N.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;0,900;1,700&family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');

        :root {
          --ft-dark: #0A192F;
          --ft-dark-navy: #0F2744;
          --ft-accent: #FBBF24;
          --ft-gold: #D97706;
          --ft-slate: rgba(255,255,255,0.32);
          --ft-muted: #94A3B8;
          --ft-border: rgba(255,255,255,0.08);
          --ft-surface: rgba(255,255,255,0.05);
        }

        .ft-footer {
          background-color: var(--ft-dark);
          color: #CBD5E1;
          font-family: 'Plus Jakarta Sans', -apple-system, sans-serif;
          position: relative;
          overflow: hidden;
        }

        .ft-footer::before {
          content: '';
          position: absolute;
          inset: 0;
          background: radial-gradient(circle at 10% 20%, rgba(29, 78, 216, 0.07) 0%, transparent 50%),
                      radial-gradient(circle at 90% 80%, rgba(217, 119, 6, 0.05) 0%, transparent 50%);
          pointer-events: none;
        }

        .ft-z {
          position: relative;
          z-index: 2;
        }

        .ft-wave {
          display: block;
          width: 100%;
          line-height: 0;
          background: #F8FAFC;
        }
        .ft-wave svg {
          display: block;
          width: 100%;
          height: 38px;
        }

        .ft-logo {
          display: inline-flex;
          align-items: center;
          gap: 12px;
          text-decoration: none;
        }

        .ft-logo-wrap {
          width: 40px;
          height: 40px;
          border-radius: 10px;
          background: linear-gradient(135deg, #0F2744 0%, #1D4ED8 100%);
          border: 1px solid rgba(251, 191, 36, 0.3);
          display: flex;
          align-items: center;
          justify-content: center;
          box-shadow: 0 4px 14px rgba(0,0,0,0.3);
        }

        .ft-logo-img {
          width: 26px;
          height: 26px;
          object-fit: contain;
        }

        .ft-logo-text {
          font-family: 'Plus Jakarta Sans', sans-serif;
          font-size: 20px;
          font-weight: 800;
          color: #FFFFFF;
          letter-spacing: -0.02em;
        }
        .ft-logo-text span {
          color: #FBBF24;
        }

        .ft-tagline {
          font-size: 13.5px;
          line-height: 1.7;
          color: var(--ft-muted);
          max-width: 300px;
        }

        .ft-social-btn {
          width: 38px;
          height: 38px;
          border-radius: 10px;
          background: var(--ft-surface);
          border: 1px solid var(--ft-border);
          display: flex;
          align-items: center;
          justify-content: center;
          color: rgba(255,255,255,0.7);
          text-decoration: none;
          transition: all 0.2s ease;
        }
        .ft-social-btn:hover {
          background: #D97706;
          color: #FFFFFF;
          border-color: #D97706;
          transform: translateY(-2px);
        }

        .ft-partner-cta-box {
          background: linear-gradient(135deg, rgba(217, 119, 6, 0.15) 0%, rgba(29, 78, 216, 0.12) 100%);
          border: 1px solid rgba(251, 191, 36, 0.3);
          border-radius: 14px;
          padding: 18px 22px;
          margin-bottom: 24px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 16px;
          flex-wrap: wrap;
        }

        .ft-partner-cta-btn {
          background: linear-gradient(135deg, #FBBF24 0%, #D97706 100%);
          color: #0F2744;
          font-weight: 800;
          font-size: 13.5px;
          padding: 10px 20px;
          border-radius: 999px;
          text-decoration: none;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          box-shadow: 0 4px 12px rgba(217, 119, 6, 0.25);
          transition: all 0.2s ease;
        }

        .ft-partner-cta-btn:hover {
          transform: translateY(-2px);
          box-shadow: 0 6px 16px rgba(217, 119, 6, 0.35);
          color: #0A192F;
        }

        .ft-nav-heading {
          font-size: 11.5px;
          font-weight: 800;
          letter-spacing: 0.16em;
          text-transform: uppercase;
          color: #FBBF24;
          display: block;
          margin-bottom: 16px;
        }

        .ft-nav-list {
          list-style: none;
          padding: 0;
          margin: 0;
          display: flex;
          flex-direction: column;
          gap: 10px;
        }

        .ft-nav-list a {
          font-size: 13.5px;
          color: #CBD5E1;
          text-decoration: none;
          transition: color 0.2s ease;
        }
        .ft-nav-list a:hover {
          color: #FFFFFF;
        }

        .ft-trust {
          border-top: 1px solid var(--ft-border);
          border-bottom: 1px solid var(--ft-border);
        }

        .ft-badge {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          font-size: 12.5px;
          color: #CBD5E1;
        }
        .ft-badge-icon {
          color: #FBBF24;
          display: flex;
        }

        .ft-newsletter-wrap {
          display: flex;
          align-items: center;
          gap: 10px;
        }
        .ft-newsletter-label {
          font-size: 12.5px;
          color: #CBD5E1;
        }
        .ft-newsletter-input {
          background: rgba(255,255,255,0.06);
          border: 1px solid var(--ft-border);
          border-radius: 8px 0 0 8px;
          padding: 9px 14px;
          font-size: 13px;
          color: #fff;
          outline: none;
        }
        .ft-newsletter-input:focus {
          border-color: #FBBF24;
        }
        .ft-newsletter-btn {
          background: linear-gradient(135deg, #D97706 0%, #B45309 100%);
          border: none;
          color: #FFFFFF;
          font-weight: 700;
          font-size: 13px;
          padding: 9px 18px;
          border-radius: 0 8px 8px 0;
          cursor: pointer;
        }

        .ft-bottom {
          padding: 24px 0;
          display: flex;
          align-items: center;
          justify-content: space-between;
          flex-wrap: wrap;
          gap: 16px;
          font-size: 12.5px;
          color: var(--ft-muted);
        }
        .ft-bottom-links {
          display: flex;
          gap: 18px;
          flex-wrap: wrap;
        }
        .ft-bottom-links a {
          color: var(--ft-muted);
          text-decoration: none;
          transition: color 0.2s;
        }
        .ft-bottom-links a:hover {
          color: #FFFFFF;
        }
      `}),(0,N.jsx)(`div`,{className:`ft-wave`,children:(0,N.jsx)(`svg`,{viewBox:`0 0 1440 56`,preserveAspectRatio:`none`,xmlns:`http://www.w3.org/2000/svg`,children:(0,N.jsx)(`path`,{d:`M0,8 C240,56 480,0 720,24 C960,48 1200,12 1440,28 L1440,56 L0,56 Z`,fill:`#0A192F`})})}),(0,N.jsx)(`footer`,{className:`ft-footer`,"aria-label":`Site footer`,children:(0,N.jsxs)(`div`,{className:`ft-z container-xl`,children:[(0,N.jsx)(`div`,{className:`pt-5`,children:(0,N.jsxs)(`div`,{className:`ft-partner-cta-box`,children:[(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`span`,{style:{fontSize:`11px`,fontWeight:800,textTransform:`uppercase`,letterSpacing:`0.1em`,color:`#FBBF24`},children:`Partner Network`}),(0,N.jsxs)(`h4`,{style:{margin:`4px 0 2px 0`,color:`#FFFFFF`,fontSize:`17px`,fontWeight:800},children:[`Earn up to `,r,`% First-Term Commission + `,i,`% Recurring Retention`]}),(0,N.jsx)(`p`,{style:{margin:0,fontSize:`13px`,color:`#CBD5E1`},children:`Register schools in your region as an authorized SchoolProfit Sales Partner.`})]}),(0,N.jsx)(`a`,{href:`/sales-representative/register`,className:`ft-partner-cta-btn`,children:`Apply as a Sales Partner →`})]})}),(0,N.jsx)(`div`,{className:`py-4`,children:(0,N.jsxs)(`div`,{className:`row g-5`,children:[(0,N.jsx)(`div`,{className:`col-12 col-lg-3`,children:(0,N.jsxs)(`div`,{className:`d-flex flex-column h-100`,children:[(0,N.jsxs)(`a`,{href:`/`,className:`ft-logo mb-4`,"aria-label":`SchoolProfit home`,children:[(0,N.jsx)(`div`,{className:`ft-logo-wrap`,style:{background:`transparent`,border:`none`},children:(0,N.jsx)(`img`,{src:`/media/logo/schoolprofit-logo.svg`,alt:`SchoolProfit logo`,className:`ft-logo-img`,style:{width:`auto`,height:`36px`}})}),(0,N.jsxs)(`span`,{className:`ft-logo-text`,children:[`School`,(0,N.jsx)(`span`,{style:{color:`#10B981`},children:`Profit`})]})]}),(0,N.jsx)(`p`,{className:`ft-tagline mb-4`,children:`The School Growth & Profit Operating System — stop fee defaults, scale student admissions, and deliver error-free academic results.`}),(0,N.jsx)(`div`,{className:`d-flex gap-2 mt-auto`,children:v.map(e=>(0,N.jsx)(`a`,{href:e.href,target:`_blank`,rel:`noopener noreferrer`,className:`ft-social-btn`,"aria-label":e.label,children:e.icon},e.label))})]})}),(0,N.jsx)(`div`,{className:`col-12 col-lg-9`,children:(0,N.jsx)(`nav`,{"aria-label":`Footer navigation`,children:(0,N.jsx)(`div`,{className:`row g-4`,children:Object.entries(g).map(([e,t])=>(0,N.jsxs)(`div`,{className:`col-6 col-md-3`,children:[(0,N.jsx)(`span`,{className:`ft-nav-heading`,children:e}),(0,N.jsx)(`ul`,{className:`ft-nav-list`,children:t.map(e=>(0,N.jsx)(`li`,{children:(0,N.jsx)(`a`,{href:e.href,target:e.href.startsWith(`http`)?`_blank`:void 0,rel:e.href.startsWith(`http`)?`noopener noreferrer`:void 0,children:e.label})},e.label))})]},e))})})})]})}),(0,N.jsxs)(`div`,{className:`ft-trust py-4 d-flex align-items-center justify-content-between flex-wrap gap-4`,children:[(0,N.jsx)(`div`,{className:`d-flex flex-wrap gap-4`,children:y.map(e=>(0,N.jsxs)(`span`,{className:`ft-badge`,children:[(0,N.jsx)(`span`,{className:`ft-badge-icon`,children:e.icon}),e.label]},e.label))}),(0,N.jsxs)(`div`,{id:`footer-subscribe`,className:`ft-newsletter-wrap`,children:[(0,N.jsx)(`span`,{className:`ft-newsletter-label`,children:`Platform updates:`}),l?(0,N.jsxs)(`div`,{className:`d-flex align-items-center gap-2 px-3 py-1.5 rounded`,style:{background:`rgba(34, 197, 94, 0.2)`,border:`1px solid rgba(34, 197, 94, 0.4)`,color:`#4ADE80`,fontSize:`13px`,fontWeight:700},children:[(0,N.jsx)(`i`,{className:`bi bi-check-circle-fill`}),` `,d||`Subscribed! Thank you.`]}):(0,N.jsxs)(`form`,{onSubmit:h,className:`d-flex flex-column gap-1`,children:[(0,N.jsxs)(`div`,{className:`d-flex`,children:[(0,N.jsx)(`input`,{type:`email`,required:!0,value:a,onChange:e=>{o(e.target.value),m(``)},className:`ft-newsletter-input`,placeholder:`Your email address`,"aria-label":`Subscribe to updates`,disabled:s}),(0,N.jsx)(`button`,{type:`submit`,disabled:s,className:`ft-newsletter-btn`,children:s?(0,N.jsx)(`span`,{className:`spinner-border spinner-border-sm`,role:`status`,"aria-hidden":`true`}):`Subscribe`})]}),p&&(0,N.jsx)(`span`,{style:{fontSize:`11.5px`,color:`#F87171`,marginTop:`2px`},children:p})]})]})]}),(0,N.jsxs)(`div`,{className:`ft-bottom`,children:[(0,N.jsxs)(`div`,{children:[`© `,n,` SchoolProfit (schoolprofit.ng). All rights reserved.`]}),(0,N.jsxs)(`div`,{className:`ft-bottom-links`,children:[(0,N.jsxs)(`a`,{href:`/sales-representative/register`,style:{color:`#FBBF24`,fontWeight:700},children:[`★ Partner Program (Earn `,r,`%)`]}),(0,N.jsx)(`a`,{href:`/privacy-policy`,children:`Privacy Policy`}),(0,N.jsx)(`a`,{href:`/terms-and-conditions`,children:`Terms of Service`}),(0,N.jsx)(`a`,{href:`/book-demo`,children:`Book Demo`})]})]})]})})]})}function Q(){let[e,t]=(0,_.useState)(`experience`),[n,r]=(0,_.useState)(`broadsheet`),[i,a]=(0,_.useState)(null);return(0,N.jsxs)(N.Fragment,{children:[(0,N.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Playfair+Display:ital,wght@0,600;0,800;1,600;1,700&display=swap');

        :root {
          --gq-hero-bg: #F8FAFC;
          --gq-hero-surface: #FFFFFF;
          --gq-hero-surface-active: #F1F5F9;
          --gq-hero-border: rgba(15, 39, 68, 0.08);
          --gq-hero-navy: #0F2744;
          --gq-hero-navy-dark: #0A192F;
          --gq-hero-gold: #D97706;
          --gq-hero-gold-light: #F59E0B;
          --gq-hero-emerald: #059669;
          --gq-hero-blue: #1D4ED8;
          --gq-hero-text: #0F172A;
          --gq-hero-muted: #475569;
        }

        .gq-hero-section {
          background-color: var(--gq-hero-bg);
          position: relative;
          overflow: hidden;
          font-family: 'Plus Jakarta Sans', sans-serif;
          padding-top: max(130px, calc(100px + env(safe-area-inset-top)));
          padding-bottom: 84px;
          min-height: 100vh;
          display: flex;
          align-items: center;
          opacity: 1 !important;
          transform: none !important;
          visibility: visible !important;
        }

        /* Subtle grid background */
        .gq-hero-section::before {
          content: '';
          position: absolute;
          inset: 0;
          background-image:
            linear-gradient(rgba(15, 39, 68, 0.035) 1px, transparent 1px),
            linear-gradient(90deg, rgba(15, 39, 68, 0.035) 1px, transparent 1px);
          background-size: 56px 56px;
          pointer-events: none;
          z-index: 0;
        }

        /* Ambient Glow Spheres */
        .gq-glow-tl {
          position: absolute;
          top: -15%;
          left: -10%;
          width: 580px;
          height: 580px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.09) 0%, transparent 65%);
          pointer-events: none;
          z-index: 0;
        }

        .gq-glow-br {
          position: absolute;
          bottom: -15%;
          right: -10%;
          width: 640px;
          height: 640px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(29, 78, 216, 0.08) 0%, transparent 65%);
          pointer-events: none;
          z-index: 0;
        }

        .gq-hero-inner {
          position: relative;
          z-index: 1;
          width: 100%;
        }

        /* ── Badge / Kicker ── */
        .gq-hero-kicker {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 7px 18px;
          border-radius: 999px;
          background: #FEF3C7;
          border: 1px solid #F59E0B;
          color: #92400E !important;
          font-size: 12px;
          font-weight: 800;
          letter-spacing: 0.05em;
          text-transform: uppercase;
          margin-bottom: 18px;
          box-shadow: 0 2px 10px rgba(217, 119, 6, 0.15);
        }

        .gq-kicker-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #059669;
          box-shadow: 0 0 8px #059669;
          animation: pulseDot 2s infinite ease-in-out;
        }

        @keyframes pulseDot {
          0%, 100% { transform: scale(1); opacity: 1; }
          50% { transform: scale(1.4); opacity: 0.6; }
        }

        /* ── Trust Avatars ── */
        .gq-trust-avatars {
          display: flex;
          align-items: center;
          gap: 12px;
          margin-bottom: 22px;
        }

        .gq-avatar-stack {
          display: flex;
          align-items: center;
        }

        .gq-avatar-img {
          width: 38px;
          height: 38px;
          border-radius: 50%;
          border: 2.5px solid #FFFFFF;
          object-fit: cover;
          margin-left: -10px;
          box-shadow: 0 2px 6px rgba(15, 39, 68, 0.15);
          transition: transform 0.2s ease;
        }

        .gq-avatar-img:first-child {
          margin-left: 0;
        }

        .gq-avatar-img:hover {
          transform: translateY(-3px) scale(1.1);
          z-index: 10;
        }

        /* ── Headline ── */
        .gq-hero-title {
          font-family: 'Playfair Display', Georgia, serif;
          font-size: clamp(34px, 4.5vw, 56px);
          font-weight: 800;
          line-height: 1.18;
          color: #0A192F !important;
          letter-spacing: -0.02em;
          margin-bottom: 20px;
          display: block;
          opacity: 1 !important;
          visibility: visible !important;
        }

        .gq-hero-title-main {
          color: #0A192F !important;
          display: inline;
        }

        .gq-hero-title-highlight {
          font-style: italic;
          font-family: 'Playfair Display', serif;
          color: #D97706 !important;
          display: inline;
        }

        @supports (-webkit-background-clip: text) {
          .gq-hero-title-highlight {
            background: linear-gradient(135deg, #D97706 0%, #B45309 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
          }
        }

        .gq-hero-desc {
          font-size: clamp(15px, 1.2vw, 17px);
          font-weight: 400;
          line-height: 1.75;
          color: #334155 !important;
          max-width: 540px;
          margin-bottom: 32px;
        }

        .gq-hero-desc strong {
          color: #0A192F !important;
          font-weight: 700;
        }

        /* ── Action Buttons ── */
        .gq-hero-actions {
          display: flex;
          flex-wrap: wrap;
          align-items: center;
          gap: 14px;
          margin-bottom: 36px;
        }

        .gq-btn-cta-main {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 10px;
          padding: 14px 28px;
          font-size: 15px;
          font-weight: 700;
          color: #FFFFFF;
          background: linear-gradient(135deg, #0F2744 0%, #1E3A8A 100%);
          border-radius: 10px;
          text-decoration: none;
          box-shadow: 0 6px 20px rgba(15, 39, 68, 0.22);
          transition: all 0.25s ease;
          border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .gq-btn-cta-main:hover {
          transform: translateY(-2px);
          box-shadow: 0 10px 28px rgba(30, 58, 138, 0.35);
          color: #FFFFFF;
          background: linear-gradient(135deg, #1E3A8A 0%, #2563EB 100%);
        }

        .gq-btn-cta-secondary {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 10px;
          padding: 14px 24px;
          font-size: 15px;
          font-weight: 600;
          color: #0F2744;
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: 10px;
          text-decoration: none;
          transition: all 0.25s ease;
          box-shadow: 0 2px 8px rgba(15, 39, 68, 0.05);
        }

        .gq-btn-cta-secondary:hover {
          background: #F8FAFC;
          border-color: #CBD5E1;
          color: #1D4ED8;
          transform: translateY(-2px);
        }

        /* ── Statistics Bar ── */
        .gq-stats-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 14px;
          padding-top: 24px;
          border-top: 1px solid #E2E8F0;
          max-width: 580px;
        }

        @media (max-width: 600px) {
          .gq-stats-grid {
            grid-template-columns: repeat(2, 1fr);
            gap: 14px;
          }
        }

        .gq-stat-item {
          display: flex;
          flex-direction: column;
        }

        .gq-stat-num {
          font-family: 'Plus Jakarta Sans', sans-serif;
          font-size: 21px;
          font-weight: 800;
          color: #0F2744;
          line-height: 1.1;
        }

        .gq-stat-num span {
          color: var(--gq-hero-gold);
        }

        .gq-stat-lbl {
          font-size: 11.5px;
          font-weight: 500;
          color: #64748B;
          margin-top: 3px;
        }

        /* ── Showcase Card & Switcher ── */
        .gq-showcase-mode-bar {
          display: inline-flex;
          background: #E2E8F0;
          padding: 4px;
          border-radius: 12px;
          margin-bottom: 16px;
          gap: 4px;
        }

        .gq-mode-btn {
          padding: 8px 16px;
          font-size: 13px;
          font-weight: 700;
          border-radius: 8px;
          border: none;
          background: transparent;
          color: #475569;
          cursor: pointer;
          transition: all 0.2s ease;
          display: inline-flex;
          align-items: center;
          gap: 6px;
        }

        .gq-mode-btn.active {
          background: #0F2744;
          color: #FFFFFF;
          box-shadow: 0 2px 8px rgba(15, 39, 68, 0.2);
        }

        .gq-preview-card {
          background: #FFFFFF;
          border: 1px solid rgba(15, 39, 68, 0.1);
          border-radius: 20px;
          box-shadow: 0 20px 50px -10px rgba(15, 39, 68, 0.14);
          overflow: hidden;
          position: relative;
        }

        /* ── Human Experience Showcase ── */
        .gq-human-showcase-wrap {
          position: relative;
          border-radius: 16px;
          overflow: hidden;
          height: 440px;
          background: #0F2744;
        }

        .gq-hero-main-img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          object-position: center 25%;
          transition: transform 0.6s cubic-bezier(0.16, 1, 0.3, 1);
        }

        .gq-human-showcase-wrap:hover .gq-hero-main-img {
          transform: scale(1.03);
        }

        .gq-hero-img-gradient {
          position: absolute;
          inset: 0;
          background: linear-gradient(180deg, rgba(15, 39, 68, 0.15) 0%, rgba(15, 39, 68, 0.4) 60%, rgba(15, 39, 68, 0.85) 100%);
          pointer-events: none;
        }

        /* ── Floating Badges with Human Avatars ── */
        .gq-floating-card {
          position: absolute;
          background: rgba(255, 255, 255, 0.94);
          backdrop-filter: blur(12px);
          -webkit-backdrop-filter: blur(12px);
          border: 1px solid rgba(255, 255, 255, 0.8);
          border-radius: 14px;
          padding: 10px 14px;
          box-shadow: 0 12px 30px rgba(10, 25, 47, 0.25);
          display: flex;
          align-items: center;
          gap: 10px;
          z-index: 5;
          animation: gqFloat 4s ease-in-out infinite alternate;
          transition: transform 0.2s ease;
        }

        .gq-floating-card:hover {
          transform: scale(1.04);
        }

        .gq-card-top-left {
          top: 18px;
          left: 18px;
          animation-delay: 0s;
        }

        .gq-card-bottom-right {
          bottom: 22px;
          right: 18px;
          animation-delay: 1.5s;
        }

        .gq-card-bottom-left {
          bottom: 22px;
          left: 18px;
          animation-delay: 2.5s;
        }

        @keyframes gqFloat {
          0% { transform: translateY(0px); }
          100% { transform: translateY(-8px); }
        }

        .gq-float-avatar {
          width: 42px;
          height: 42px;
          border-radius: 50%;
          object-fit: cover;
          border: 2px solid #D97706;
          flex-shrink: 0;
        }

        /* Hotspot Pins on Hero */
        .gq-hotspot-pin {
          position: absolute;
          width: 28px;
          height: 28px;
          border-radius: 50%;
          background: #F59E0B;
          color: #0F2744;
          font-weight: 800;
          font-size: 13px;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          box-shadow: 0 0 0 0 rgba(245, 158, 11, 0.7);
          animation: hotspotPulse 2s infinite;
          z-index: 6;
        }

        @keyframes hotspotPulse {
          0% { box-shadow: 0 0 0 0 rgba(245, 158, 11, 0.8); }
          70% { box-shadow: 0 0 0 14px rgba(245, 158, 11, 0); }
          100% { box-shadow: 0 0 0 0 rgba(245, 158, 11, 0); }
        }

        .gq-hotspot-1 { top: 38%; right: 28%; }
        .gq-hotspot-2 { top: 58%; left: 32%; }

        /* ── Software Mode Header & Tabs ── */
        .gq-preview-header {
          padding: 16px 20px;
          background: #F8FAFC;
          border-bottom: 1px solid #E2E8F0;
        }

        .gq-preview-title {
          display: flex;
          align-items: center;
          gap: 10px;
          margin-bottom: 12px;
        }

        .gq-preview-dots {
          display: flex;
          gap: 6px;
        }

        .gq-p-dot {
          width: 10px;
          height: 10px;
          border-radius: 50%;
        }

        .gq-p-dot--red { background: #EF4444; }
        .gq-p-dot--yellow { background: #F59E0B; }
        .gq-p-dot--green { background: #10B981; }

        .gq-preview-school-name {
          font-size: 12.5px;
          font-weight: 700;
          color: #0F2744;
        }

        .gq-showcase-tabs {
          display: flex;
          gap: 6px;
        }

        .gq-tab-btn {
          padding: 6px 12px;
          font-size: 11.5px;
          font-weight: 700;
          border: 1px solid transparent;
          border-radius: 8px;
          background: #FFFFFF;
          color: #475569;
          cursor: pointer;
          transition: all 0.2s;
          white-space: nowrap;
        }

        .gq-tab-btn.active {
          background: #0F2744;
          color: #FFFFFF;
          border-color: #0F2744;
        }

        .gq-preview-body {
          padding: 24px;
          min-height: 340px;
        }

        /* ── Tab Views Styles ── */
        .gq-bs-table-wrap {
          overflow-x: auto;
          border-radius: 8px;
          border: 1px solid #E2E8F0;
        }

        .gq-bs-table {
          width: 100%;
          border-collapse: collapse;
          font-size: 12.5px;
        }

        .gq-bs-table th {
          background: #F1F5F9;
          padding: 8px 10px;
          text-align: left;
          font-weight: 700;
          color: #475569;
          border-bottom: 1px solid #E2E8F0;
        }

        .gq-bs-table td {
          padding: 10px;
          border-bottom: 1px solid #F1F5F9;
          color: #1E293B;
        }

        .gq-rank-badge {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          width: 22px;
          height: 22px;
          border-radius: 50%;
          font-size: 11px;
          font-weight: 800;
        }

        .gq-rank-1 { background: #FEF3C7; color: #B45309; }
        .gq-rank-2 { background: #E2E8F0; color: #475569; }
        .gq-rank-3 { background: #FFEDD5; color: #C2410C; }

        .gq-rc-card {
          border: 1px solid #E2E8F0;
          border-radius: 12px;
          padding: 16px;
          background: #FFFFFF;
        }

        .gq-rc-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          border-bottom: 1.5px solid #0F2744;
          padding-bottom: 10px;
          margin-bottom: 14px;
        }

        .gq-rc-school {
          font-weight: 800;
          font-size: 13px;
          color: #0F2744;
          letter-spacing: 0.04em;
        }

        .gq-rc-meta {
          font-size: 11px;
          color: #64748B;
        }

        .gq-rc-qr-box {
          width: 48px;
          height: 48px;
          background: #0F2744;
          border-radius: 8px;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          color: #FBBF24;
          font-weight: 800;
          font-size: 9px;
        }

        .gq-fee-card {
          background: #ECFDF5;
          border: 1px solid #A7F3D0;
          border-radius: 14px;
          padding: 18px;
        }

        .gq-fee-amount {
          font-size: 26px;
          font-weight: 800;
          color: #047857;
          margin: 6px 0;
        }

        .gq-wa-bubble {
          background: #DCF8C6;
          border-radius: 12px 12px 0 12px;
          padding: 14px 16px;
          font-size: 12.5px;
          color: #111827;
          border: 1px solid #B7E4C7;
          position: relative;
        }

        .gq-wa-sender {
          font-size: 11px;
          font-weight: 700;
          color: #059669;
          margin-bottom: 4px;
        }

        .gq-wa-link-btn {
          display: block;
          margin-top: 8px;
          font-weight: 700;
          color: #1E40AF;
          text-decoration: underline;
        }
      `}),(0,N.jsxs)(`section`,{className:`gq-hero-section`,children:[(0,N.jsx)(`div`,{className:`gq-glow-tl`}),(0,N.jsx)(`div`,{className:`gq-glow-br`}),(0,N.jsx)(`div`,{className:`container-xl gq-hero-inner`,children:(0,N.jsxs)(`div`,{className:`row align-items-center g-5`,children:[(0,N.jsxs)(`div`,{className:`col-lg-6`,children:[(0,N.jsxs)(`div`,{className:`gq-hero-kicker`,children:[(0,N.jsx)(`span`,{className:`gq-kicker-dot`}),`The School Growth & Profit Operating System`]}),(0,N.jsxs)(`h1`,{className:`gq-hero-title`,style:{color:`#0A192F`},children:[(0,N.jsxs)(`span`,{className:`gq-hero-title-main`,style:{color:`#0A192F`},children:[`Stop Fee Debts. Scale Admissions.`,` `]}),(0,N.jsx)(`em`,{className:`gq-hero-title-highlight`,style:{color:`#059669`},children:`Make Your School Profitable.`})]}),(0,N.jsxs)(`p`,{className:`gq-hero-desc`,children:[`SchoolProfit combines `,(0,N.jsx)(`strong`,{children:`automated fee debt recovery and instant multi-bank settlements`}),` with`,` `,(0,N.jsx)(`strong`,{children:`1-click error-free broadsheets`}),`, `,(0,N.jsx)(`strong`,{children:`offline hybrid CBT exams`}),`, and `,(0,N.jsx)(`strong`,{children:`AI lesson planning`}),`. Cut running costs, eliminate payment defaults, and give your school the financial strength to grow.`]}),(0,N.jsxs)(`div`,{className:`gq-trust-avatars`,children:[(0,N.jsxs)(`div`,{className:`gq-avatar-stack`,children:[(0,N.jsx)(`img`,{src:`/images/testimonials/adaeze-okonkwo.jpg`,alt:`Principal`,className:`gq-avatar-img`}),(0,N.jsx)(`img`,{src:`/images/testimonials/tunde-adeyemi.jpg`,alt:`Administrator`,className:`gq-avatar-img`}),(0,N.jsx)(`img`,{src:`/images/testimonials/funmi-bello.jpg`,alt:`Proprietress`,className:`gq-avatar-img`}),(0,N.jsx)(`img`,{src:`/images/testimonials/emeka-nwosu.jpg`,alt:`Director`,className:`gq-avatar-img`})]}),(0,N.jsxs)(`div`,{children:[(0,N.jsxs)(`div`,{className:`d-flex align-items-center gap-1`,style:{color:`#D97706`,fontSize:`13px`},children:[(0,N.jsx)(`span`,{children:`★★★★★`}),(0,N.jsx)(`strong`,{style:{color:`#0F2744`,fontSize:`12px`,marginLeft:`4px`},children:`4.9/5 Rating`})]}),(0,N.jsxs)(`div`,{style:{fontSize:`12px`,color:`#64748B`,fontWeight:600},children:[`Trusted by `,(0,N.jsx)(`strong`,{children:`500+ School Proprietors & Principals`})]})]})]}),(0,N.jsxs)(`div`,{className:`gq-hero-actions`,children:[(0,N.jsxs)(o,{to:`/book-demo`,className:`gq-btn-cta-main`,style:{background:`linear-gradient(135deg, #059669 0%, #047857 100%)`},children:[`Book a Live Demo / Request Setup`,(0,N.jsx)(`svg`,{width:`15`,height:`15`,viewBox:`0 0 14 14`,fill:`none`,children:(0,N.jsx)(`path`,{d:`M1 7h12M7 1l6 6-6 6`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`})})]}),(0,N.jsxs)(`a`,{href:`#why-schoolprofit`,className:`gq-btn-cta-secondary`,children:[(0,N.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,children:[(0,N.jsx)(`circle`,{cx:`12`,cy:`12`,r:`10`}),(0,N.jsx)(`polyline`,{points:`12 16 16 12 12 8`}),(0,N.jsx)(`line`,{x1:`8`,y1:`12`,x2:`16`,y2:`12`})]}),`Why SchoolProfit`]})]}),(0,N.jsxs)(`div`,{className:`gq-stats-grid`,children:[(0,N.jsxs)(`div`,{className:`gq-stat-item`,children:[(0,N.jsxs)(`span`,{className:`gq-stat-num`,children:[`500`,(0,N.jsx)(`span`,{children:`+`})]}),(0,N.jsx)(`span`,{className:`gq-stat-lbl`,children:`Institutions Powered`})]}),(0,N.jsxs)(`div`,{className:`gq-stat-item`,children:[(0,N.jsxs)(`span`,{className:`gq-stat-num`,children:[`2.4M`,(0,N.jsx)(`span`,{children:`+`})]}),(0,N.jsx)(`span`,{className:`gq-stat-lbl`,children:`Results Delivered`})]}),(0,N.jsxs)(`div`,{className:`gq-stat-item`,children:[(0,N.jsxs)(`span`,{className:`gq-stat-num`,children:[`99.9`,(0,N.jsx)(`span`,{children:`%`})]}),(0,N.jsx)(`span`,{className:`gq-stat-lbl`,children:`System Reliability`})]}),(0,N.jsxs)(`div`,{className:`gq-stat-item`,children:[(0,N.jsxs)(`span`,{className:`gq-stat-num`,children:[`100`,(0,N.jsx)(`span`,{children:`%`})]}),(0,N.jsx)(`span`,{className:`gq-stat-lbl`,children:`Audit Compliance`})]})]})]}),(0,N.jsxs)(`div`,{className:`col-lg-6`,children:[(0,N.jsxs)(`div`,{className:`d-flex justify-content-between align-items-center mb-2 flex-wrap gap-2`,children:[(0,N.jsxs)(`div`,{className:`gq-showcase-mode-bar`,children:[(0,N.jsx)(`button`,{type:`button`,className:`gq-mode-btn ${e===`experience`?`active`:``}`,onClick:()=>t(`experience`),children:`🎓 School Experience`}),(0,N.jsx)(`button`,{type:`button`,className:`gq-mode-btn ${e===`software`?`active`:``}`,onClick:()=>t(`software`),children:`⚡ Software Simulator`})]}),(0,N.jsx)(`span`,{className:`badge bg-light text-dark fw-bold px-2.5 py-1.5`,style:{fontSize:`11px`,border:`1px solid #E2E8F0`},children:e===`experience`?`Live School Impact`:`Interactive Prototype`})]}),e===`experience`?(0,N.jsx)(`div`,{className:`gq-preview-card p-2`,children:(0,N.jsxs)(`div`,{className:`gq-human-showcase-wrap`,children:[(0,N.jsx)(`img`,{src:`/images/hero/hero-nigerian-students.jpg`,alt:`Nigerian secondary school students in modern classroom`,className:`gq-hero-main-img`}),(0,N.jsx)(`div`,{className:`gq-hero-img-gradient`}),(0,N.jsxs)(`div`,{className:`gq-floating-card gq-card-top-left`,children:[(0,N.jsx)(`img`,{src:`/images/hero/hero-principal-portrait.jpg`,alt:`School Principal`,className:`gq-float-avatar`}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`div`,{style:{fontSize:`10.5px`,fontWeight:800,color:`#D97706`,textTransform:`uppercase`},children:`VERIFIED PRINCIPAL`}),(0,N.jsx)(`div`,{style:{fontSize:`12.5px`,fontWeight:800,color:`#0F2744`},children:`Broadsheets ready in 30 seconds`})]})]}),(0,N.jsx)(`div`,{className:`gq-hotspot-pin gq-hotspot-1`,onClick:()=>a(i===1?null:1),title:`Click to view CBT exam info`,children:(0,N.jsx)(`i`,{className:`bi bi-laptop`})}),i===1&&(0,N.jsxs)(`div`,{className:`p-3 bg-white rounded shadow-lg position-absolute`,style:{top:`45%`,right:`10%`,zIndex:20,width:`240px`,fontSize:`12px`,border:`1.5px solid #F59E0B`},children:[(0,N.jsx)(`strong`,{className:`d-block text-dark mb-1`,children:`💻 Offline CBT Exam Engine`}),(0,N.jsx)(`span`,{className:`text-muted`,children:`65 systems synchronized simultaneously with zero internet bandwidth requirement.`})]}),(0,N.jsxs)(`div`,{className:`gq-floating-card gq-card-bottom-right`,children:[(0,N.jsx)(`img`,{src:`/images/hero/hero-student-achiever.jpg`,alt:`Academic Achiever`,className:`gq-float-avatar`,style:{borderColor:`#059669`}}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`div`,{style:{fontSize:`10.5px`,fontWeight:800,color:`#059669`,textTransform:`uppercase`},children:`ACADEMIC DISTINCTION`}),(0,N.jsx)(`div`,{style:{fontSize:`12.5px`,fontWeight:800,color:`#0F2744`},children:`96.4% GPA · PIN #GQ-9821`})]})]}),(0,N.jsxs)(`div`,{className:`position-absolute bottom-0 start-0 end-0 p-3 d-flex justify-content-between align-items-center text-white`,style:{background:`rgba(15, 39, 68, 0.88)`,backdropFilter:`blur(8px)`},children:[(0,N.jsxs)(`div`,{className:`d-flex align-items-center gap-2`,children:[(0,N.jsx)(`span`,{className:`p-1.5 rounded-circle bg-success text-white`,style:{fontSize:`10px`},children:(0,N.jsx)(`i`,{className:`bi bi-check-lg`})}),(0,N.jsx)(`span`,{style:{fontSize:`12px`,fontWeight:700},children:`DIKOR Comprehensive College, Lagos · Active Database`})]}),(0,N.jsx)(`span`,{className:`badge bg-warning text-dark fw-bold`,style:{fontSize:`10.5px`},children:`Active Term`})]})]})}):(0,N.jsxs)(`div`,{className:`gq-preview-card`,children:[(0,N.jsxs)(`div`,{className:`gq-preview-header`,children:[(0,N.jsxs)(`div`,{className:`gq-preview-title`,children:[(0,N.jsxs)(`div`,{className:`gq-preview-dots`,children:[(0,N.jsx)(`span`,{className:`gq-p-dot gq-p-dot--red`}),(0,N.jsx)(`span`,{className:`gq-p-dot gq-p-dot--yellow`}),(0,N.jsx)(`span`,{className:`gq-p-dot gq-p-dot--green`})]}),(0,N.jsx)(`span`,{className:`gq-preview-school-name`,children:`DIKOR Comprehensive College · Active Portal`})]}),(0,N.jsxs)(`div`,{className:`gq-showcase-tabs`,style:{overflowX:`auto`,maxWidth:`100%`},children:[(0,N.jsx)(`button`,{className:`gq-tab-btn ${n===`broadsheet`?`active`:``}`,onClick:()=>r(`broadsheet`),children:`📊 Broadsheet`}),(0,N.jsx)(`button`,{className:`gq-tab-btn ${n===`reportcard`?`active`:``}`,onClick:()=>r(`reportcard`),children:`📜 Report Card`}),(0,N.jsx)(`button`,{className:`gq-tab-btn ${n===`fees`?`active`:``}`,onClick:()=>r(`fees`),children:`💳 School Fees`}),(0,N.jsx)(`button`,{className:`gq-tab-btn ${n===`cbt`?`active`:``}`,onClick:()=>r(`cbt`),children:`💻 CBT Exams`}),(0,N.jsx)(`button`,{className:`gq-tab-btn ${n===`whatsapp`?`active`:``}`,onClick:()=>r(`whatsapp`),children:`💬 WhatsApp`})]})]}),(0,N.jsxs)(`div`,{className:`gq-preview-body`,children:[n===`broadsheet`&&(0,N.jsxs)(`div`,{children:[(0,N.jsxs)(`div`,{className:`d-flex align-items-center justify-content-between mb-3`,children:[(0,N.jsx)(`span`,{style:{fontSize:13,fontWeight:700,color:`#0F2744`},children:`SS 2 First Term Academic Broadsheet`}),(0,N.jsx)(`span`,{style:{fontSize:11,color:`#059669`,fontWeight:700},children:`✅ NERDC & WAEC Standard`})]}),(0,N.jsx)(`div`,{className:`gq-bs-table-wrap`,children:(0,N.jsxs)(`table`,{className:`gq-bs-table`,children:[(0,N.jsx)(`thead`,{children:(0,N.jsxs)(`tr`,{children:[(0,N.jsx)(`th`,{children:`Pos`}),(0,N.jsx)(`th`,{children:`Student Name`}),(0,N.jsx)(`th`,{children:`Math`}),(0,N.jsx)(`th`,{children:`Eng`}),(0,N.jsx)(`th`,{children:`Sci`}),(0,N.jsx)(`th`,{children:`Avg`})]})}),(0,N.jsxs)(`tbody`,{children:[(0,N.jsxs)(`tr`,{children:[(0,N.jsx)(`td`,{children:(0,N.jsx)(`span`,{className:`gq-rank-badge gq-rank-1`,children:`1`})}),(0,N.jsx)(`td`,{children:(0,N.jsx)(`strong`,{style:{color:`#0F2744`},children:`Chukwudi Okafor`})}),(0,N.jsx)(`td`,{children:`94`}),(0,N.jsx)(`td`,{children:`88`}),(0,N.jsx)(`td`,{children:`92`}),(0,N.jsx)(`td`,{style:{color:`#059669`,fontWeight:700},children:`91.3%`})]}),(0,N.jsxs)(`tr`,{children:[(0,N.jsx)(`td`,{children:(0,N.jsx)(`span`,{className:`gq-rank-badge gq-rank-2`,children:`2`})}),(0,N.jsx)(`td`,{children:(0,N.jsx)(`strong`,{style:{color:`#0F2744`},children:`Amina Bello`})}),(0,N.jsx)(`td`,{children:`88`}),(0,N.jsx)(`td`,{children:`92`}),(0,N.jsx)(`td`,{children:`86`}),(0,N.jsx)(`td`,{style:{color:`#059669`,fontWeight:700},children:`88.6%`})]}),(0,N.jsxs)(`tr`,{children:[(0,N.jsx)(`td`,{children:(0,N.jsx)(`span`,{className:`gq-rank-badge gq-rank-3`,children:`3`})}),(0,N.jsx)(`td`,{children:(0,N.jsx)(`strong`,{style:{color:`#0F2744`},children:`Oluwaseun Adeyemi`})}),(0,N.jsx)(`td`,{children:`85`}),(0,N.jsx)(`td`,{children:`86`}),(0,N.jsx)(`td`,{children:`89`}),(0,N.jsx)(`td`,{style:{color:`#059669`,fontWeight:700},children:`86.6%`})]})]})]})}),(0,N.jsxs)(`div`,{className:`d-flex justify-content-between align-items-center mt-3 pt-2`,style:{borderTop:`1px solid #E2E8F0`},children:[(0,N.jsxs)(`span`,{style:{fontSize:`11.5px`,color:`#64748B`},children:[`Class Weighted Average: `,(0,N.jsx)(`strong`,{style:{color:`#0F2744`},children:`76.4%`})]}),(0,N.jsx)(`span`,{style:{fontSize:`11.5px`,color:`#D97706`,fontWeight:700},children:`Export Master Broadsheets (PDF & Excel)`})]})]}),n===`reportcard`&&(0,N.jsxs)(`div`,{className:`gq-rc-card`,children:[(0,N.jsxs)(`div`,{className:`gq-rc-header`,children:[(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`div`,{className:`gq-rc-school`,children:`DIKOR COMPREHENSIVE COLLEGE`}),(0,N.jsx)(`div`,{className:`gq-rc-meta`,children:`First Term Continuous Assessment & Exam Report`})]}),(0,N.jsxs)(`div`,{className:`gq-rc-qr-box`,children:[(0,N.jsx)(`span`,{children:`VERIFIED`}),(0,N.jsx)(`span`,{style:{fontSize:6},children:`QR AUTH`})]})]}),(0,N.jsxs)(`div`,{className:`d-flex justify-content-between mb-2`,style:{fontSize:12.5},children:[(0,N.jsxs)(`span`,{children:[`Student: `,(0,N.jsx)(`strong`,{style:{color:`#0F2744`},children:`David Adesina`})]}),(0,N.jsxs)(`span`,{children:[`Class: `,(0,N.jsx)(`strong`,{children:`SS 2 Science`})]}),(0,N.jsxs)(`span`,{children:[`Position: `,(0,N.jsx)(`strong`,{style:{color:`#B45309`},children:`1st of 58`})]})]}),(0,N.jsx)(`div`,{style:{background:`#F8FAFC`,padding:`10px 14px`,borderRadius:8,fontSize:12,color:`#334155`,fontStyle:`italic`,borderLeft:`3px solid #D97706`,marginBottom:8},children:`"Principal's Remark: Outstanding academic result. Demonstrates exceptional problem-solving and discipline across all STEM subjects."`}),(0,N.jsxs)(`div`,{className:`d-flex justify-content-between align-items-center mt-3 pt-2`,style:{borderTop:`1px solid #E2E8F0`,fontSize:11.5},children:[(0,N.jsx)(`span`,{style:{color:`#64748B`},children:`Official Digital Stamp: Approved by Head of Academics`}),(0,N.jsx)(`span`,{style:{color:`#047857`,fontWeight:700},children:`Grade: A+ (Distinction)`})]})]}),n===`fees`&&(0,N.jsxs)(`div`,{className:`gq-fee-card`,children:[(0,N.jsxs)(`div`,{className:`d-flex justify-content-between align-items-center mb-2`,children:[(0,N.jsx)(`span`,{style:{fontSize:12,fontWeight:700,color:`#047857`},children:`TERM 1 SCHOOL FEE COLLECTION`}),(0,N.jsx)(`span`,{style:{fontSize:11,background:`rgba(5, 150, 105, 0.15)`,color:`#047857`,padding:`3px 9px`,borderRadius:6,fontWeight:700},children:`96.8% Collected`})]}),(0,N.jsx)(`div`,{className:`gq-fee-amount`,children:`₦14,850,000`}),(0,N.jsx)(`div`,{style:{fontSize:12.5,color:`#065F46`,marginBottom:14},children:`Direct Digital & Bank Settlements · Automated Verified Receipts`}),(0,N.jsxs)(`div`,{style:{background:`rgba(255, 255, 255, 0.75)`,padding:`12px 14px`,borderRadius:8,fontSize:12.5,color:`#1E293B`,border:`1px solid rgba(5, 150, 105, 0.2)`},children:[(0,N.jsxs)(`div`,{className:`d-flex justify-content-between mb-1`,children:[(0,N.jsx)(`span`,{children:`Total Students Billed:`}),(0,N.jsx)(`strong`,{style:{color:`#0F2744`},children:`300 Enrolled`})]}),(0,N.jsxs)(`div`,{className:`d-flex justify-content-between`,style:{color:`#047857`},children:[(0,N.jsx)(`span`,{children:`Settled Accounts:`}),(0,N.jsx)(`strong`,{children:`291 Students`})]})]})]}),n===`cbt`&&(0,N.jsxs)(`div`,{children:[(0,N.jsxs)(`div`,{className:`d-flex justify-content-between align-items-center mb-3`,children:[(0,N.jsx)(`span`,{style:{fontSize:13,fontWeight:700,color:`#1D4ED8`},children:`💻 COMPUTER LAB & ONLINE CBT HUB`}),(0,N.jsx)(`span`,{style:{fontSize:11,background:`rgba(29, 78, 216, 0.1)`,color:`#1D4ED8`,padding:`3px 9px`,borderRadius:6,fontWeight:700},children:`Offline & Cloud Hybrid`})]}),(0,N.jsxs)(`div`,{style:{background:`#F8FAFC`,border:`1px solid #E2E8F0`,borderRadius:12,padding:`16px`,marginBottom:14},children:[(0,N.jsxs)(`div`,{className:`d-flex justify-content-between align-items-center mb-2`,style:{fontSize:12.5},children:[(0,N.jsx)(`span`,{style:{color:`#64748B`},children:`Scheduled Assessment:`}),(0,N.jsx)(`strong`,{style:{color:`#0F2744`},children:`Mock BECE / Senior Secondary Exam`})]}),(0,N.jsxs)(`div`,{className:`d-flex justify-content-between align-items-center`,style:{fontSize:12.5},children:[(0,N.jsx)(`span`,{style:{color:`#64748B`},children:`Active Terminals:`}),(0,N.jsx)(`span`,{style:{color:`#059669`,fontWeight:700},children:`● 65 Lab Systems Synchronized`})]})]}),(0,N.jsxs)(`div`,{style:{background:`#F1F5F9`,padding:`12px 14px`,borderRadius:8,fontSize:12,color:`#1E293B`,border:`1px solid #E2E8F0`},children:[(0,N.jsxs)(`div`,{className:`d-flex justify-content-between mb-1`,children:[(0,N.jsx)(`span`,{children:`Continuous Local Caching:`}),(0,N.jsx)(`strong`,{style:{color:`#059669`},children:`Zero Data Loss Protection`})]}),(0,N.jsxs)(`div`,{className:`d-flex justify-content-between`,children:[(0,N.jsx)(`span`,{children:`Grading Architecture:`}),(0,N.jsx)(`strong`,{style:{color:`#1D4ED8`},children:`Direct Sync into Term Broadsheets`})]})]})]}),n===`whatsapp`&&(0,N.jsxs)(`div`,{children:[(0,N.jsxs)(`div`,{className:`gq-wa-bubble`,children:[(0,N.jsx)(`div`,{className:`gq-wa-sender`,children:`DIKOR Comprehensive College Official`}),`Dear `,(0,N.jsx)(`strong`,{children:`Mrs. Adesina`}),`, David's `,(0,N.jsx)(`strong`,{children:`First Term Report Card`}),` is now verified and published!`,(0,N.jsx)(`br`,{}),(0,N.jsx)(`br`,{}),`📈 `,(0,N.jsx)(`strong`,{children:`Position:`}),` 1st of 58 students (Average: 89.6%)`,(0,N.jsx)(`br`,{}),`💳 `,(0,N.jsx)(`strong`,{children:`Tuition Status:`}),` Cleared (Receipt #GQ-4491)`,(0,N.jsx)(`br`,{}),`📅 `,(0,N.jsx)(`strong`,{children:`Resumption Date:`}),` 12th January`,(0,N.jsx)(`br`,{}),(0,N.jsx)(`span`,{className:`gq-wa-link-btn`,children:`👉 Click to View David's Verified Result`})]}),(0,N.jsx)(`div`,{className:`text-center mt-3`,style:{fontSize:11.5,color:`#64748B`},children:`Delivered directly to parents with zero app installation required.`})]})]})]})]})]})})]})]})}var xe=[{label:`Features`,href:`#features`},{label:`Why SchoolProfit`,href:`#why-schoolprofit`},{label:`Our Schools`,href:`#schools`},{label:`Pricing`,href:`#pricing`},{label:`Testimonials`,href:`#testimonials`},{label:`Blog`,href:`#blog`},{label:`FAQ`,href:`#faq`}];function Se(){let{whatsappLink:e}=Z(),[t,n]=(0,_.useState)(!1),[r,i]=(0,_.useState)(!1),[a,s]=(0,_.useState)(``),c=(0,_.useRef)(null);return(0,_.useEffect)(()=>{let e=()=>n(window.scrollY>15);return e(),window.addEventListener(`scroll`,e,{passive:!0}),()=>window.removeEventListener(`scroll`,e)},[]),(0,_.useEffect)(()=>{let e=xe.map(e=>e.href.slice(1)).filter(Boolean).map(e=>document.getElementById(e)).filter(Boolean);if(!e.length)return;let t=new IntersectionObserver(e=>{let t=e.filter(e=>e.isIntersecting);t.length&&s(t[0].target.id)},{threshold:.25});return e.forEach(e=>t.observe(e)),()=>t.disconnect()},[]),(0,_.useEffect)(()=>{let e=e=>{r&&c.current&&!c.current.contains(e.target)&&i(!1)};return document.addEventListener(`mousedown`,e),()=>document.removeEventListener(`mousedown`,e)},[r]),(0,_.useEffect)(()=>(document.body.style.overflow=r?`hidden`:``,()=>{document.body.style.overflow=``}),[r]),(0,N.jsxs)(N.Fragment,{children:[(0,N.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Playfair+Display:ital,wght@0,600;0,800;1,600&display=swap');

        :root {
          --gq-nav-bg-scrolled: rgba(255, 255, 255, 0.96);
          --gq-nav-bg-top: rgba(255, 255, 255, 0.92);
          --gq-nav-navy: #0F2744;
          --gq-nav-gold: #D97706;
          --gq-nav-gold-light: #F59E0B;
          --gq-nav-cobalt: #1D4ED8;
          --gq-nav-text: #0F172A;
          --gq-nav-muted: #64748B;
          --gq-nav-border: rgba(15, 39, 68, 0.08);
        }

        /* ── Base Navigation Bar ── */
        .gq-navbar {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          z-index: 1100;
          font-family: 'Plus Jakarta Sans', -apple-system, sans-serif;
          transition: background 0.3s cubic-bezier(0.4, 0, 0.2, 1),
                      box-shadow 0.3s cubic-bezier(0.4, 0, 0.2, 1),
                      padding 0.3s ease;
          padding-top: max(12px, env(safe-area-inset-top));
          padding-bottom: 12px;
        }

        .gq-navbar--top {
          background: var(--gq-nav-bg-top);
          backdrop-filter: blur(16px);
          -webkit-backdrop-filter: blur(16px);
          border-bottom: 1px solid var(--gq-nav-border);
        }

        .gq-navbar--scrolled {
          background: var(--gq-nav-bg-scrolled);
          backdrop-filter: blur(20px);
          -webkit-backdrop-filter: blur(20px);
          border-bottom: 1px solid rgba(15, 39, 68, 0.12);
          box-shadow: 0 4px 24px rgba(15, 39, 68, 0.07);
          padding-top: max(10px, env(safe-area-inset-top));
          padding-bottom: 10px;
        }

        .gq-nav-container {
          max-width: 1280px;
          margin: 0 auto;
          padding: 0 24px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 16px;
          flex-wrap: nowrap;
          width: 100%;
          box-sizing: border-box;
        }

        @media (max-width: 640px) {
          .gq-nav-container {
            padding: 0 16px;
          }
        }

        /* ── Logo ── */
        .gq-logo-link {
          display: flex;
          align-items: center;
          gap: 10px;
          text-decoration: none;
          user-select: none;
          flex-shrink: 0;
        }

        .gq-logo-badge {
          width: 40px;
          height: 40px;
          border-radius: 10px;
          background: linear-gradient(135deg, #0F2744 0%, #1E3A8A 100%);
          border: 1px solid rgba(217, 119, 6, 0.35);
          display: flex;
          align-items: center;
          justify-content: center;
          box-shadow: 0 4px 14px rgba(15, 39, 68, 0.18);
          position: relative;
          overflow: hidden;
          flex-shrink: 0;
          transition: transform 0.25s ease, border-color 0.25s ease;
        }

        .gq-logo-badge::after {
          content: '';
          position: absolute;
          inset: 0;
          background: radial-gradient(circle at 30% 20%, rgba(217, 119, 6, 0.25), transparent 70%);
        }

        .gq-logo-link:hover .gq-logo-badge {
          transform: scale(1.05);
          border-color: var(--gq-nav-gold);
        }

        .gq-logo-img {
          width: 26px;
          height: 26px;
          object-fit: contain;
          position: relative;
          z-index: 1;
          display: block;
        }

        .gq-logo-text-block {
          display: flex;
          flex-direction: column;
        }

        .gq-brand-name {
          font-family: 'Plus Jakarta Sans', sans-serif;
          font-size: 19px;
          font-weight: 800;
          color: #0F2744;
          letter-spacing: -0.02em;
          line-height: 1.1;
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .gq-brand-name span {
          color: #D97706;
          background: linear-gradient(135deg, #D97706, #B45309);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
        }

        .gq-brand-tagline {
          font-size: 10px;
          font-weight: 700;
          letter-spacing: 0.06em;
          text-transform: uppercase;
          color: #64748B;
        }

        /* ── Desktop Links ── */
        .gq-nav-links {
          display: flex;
          align-items: center;
          gap: 2px;
          list-style: none;
          padding: 0;
          margin: 0;
          flex-shrink: 1;
        }

        @media (max-width: 1040px) {
          .gq-nav-links,
          .gq-nav-actions-desktop {
            display: none !important;
          }
          .gq-nav-hamburger {
            display: flex !important;
          }
        }

        .gq-nav-item {
          display: inline-block;
        }

        .gq-nav-item a {
          display: inline-block;
          padding: 7px 12px;
          font-size: 13.5px;
          font-weight: 600;
          color: #475569;
          text-decoration: none;
          border-radius: 8px;
          transition: all 0.2s ease;
          white-space: nowrap;
        }

        .gq-nav-item a:hover {
          color: #0F2744;
          background: rgba(15, 39, 68, 0.05);
        }

        .gq-nav-item a.active {
          color: #1D4ED8;
          background: rgba(29, 78, 216, 0.07);
          font-weight: 700;
        }

        /* ── Actions Desktop ── */
        .gq-nav-actions-desktop {
          display: flex;
          align-items: center;
          gap: 10px;
          flex-shrink: 0;
        }

        .gq-btn-ghost {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 8px 15px;
          font-size: 13px;
          font-weight: 600;
          color: #0F2744;
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: 9px;
          text-decoration: none;
          transition: all 0.2s ease;
          box-shadow: 0 1px 3px rgba(15, 39, 68, 0.05);
          white-space: nowrap;
        }

        .gq-btn-ghost:hover {
          color: #1D4ED8;
          border-color: #CBD5E1;
          background: #F8FAFC;
          transform: translateY(-1px);
        }

        .gq-btn-primary {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 8px 18px;
          font-size: 13.5px;
          font-weight: 700;
          color: #FFFFFF;
          background: linear-gradient(135deg, #0F2744 0%, #1E3A8A 100%);
          border-radius: 9px;
          text-decoration: none;
          box-shadow: 0 4px 14px rgba(15, 39, 68, 0.2);
          transition: all 0.25s ease;
          border: 1px solid rgba(255, 255, 255, 0.1);
          white-space: nowrap;
        }

        .gq-btn-primary:hover {
          color: #FFFFFF;
          background: linear-gradient(135deg, #1E3A8A 0%, #2563EB 100%);
          box-shadow: 0 6px 20px rgba(37, 99, 235, 0.3);
          transform: translateY(-1px);
        }

        /* ── Hamburger ── */
        .gq-nav-hamburger {
          display: none;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          gap: 5px;
          width: 40px;
          height: 40px;
          padding: 0;
          border-radius: 10px;
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          cursor: pointer;
          transition: all 0.2s ease;
          flex-shrink: 0;
        }

        .gq-hamburger-line {
          width: 20px;
          height: 2px;
          background: #0F2744;
          border-radius: 99px;
          transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .gq-nav-hamburger--open .gq-hamburger-line:nth-child(1) {
          transform: translateY(7px) rotate(45deg);
        }
        .gq-nav-hamburger--open .gq-hamburger-line:nth-child(2) {
          opacity: 0;
          transform: scaleX(0);
        }
        .gq-nav-hamburger--open .gq-hamburger-line:nth-child(3) {
          transform: translateY(-7px) rotate(-45deg);
        }

        /* ── Mobile Drawer ── */
        .gq-drawer-backdrop {
          position: fixed;
          inset: 0;
          background: rgba(15, 23, 42, 0.45);
          backdrop-filter: blur(4px);
          z-index: 1200;
          opacity: 0;
          pointer-events: none;
          transition: opacity 0.3s ease;
        }

        .gq-drawer-backdrop--open {
          opacity: 1;
          pointer-events: auto;
        }

        .gq-mobile-drawer {
          position: fixed;
          top: 0;
          right: 0;
          bottom: 0;
          width: min(340px, 85vw);
          background: #FFFFFF;
          border-left: 1px solid #E2E8F0;
          z-index: 1250;
          display: flex;
          flex-direction: column;
          transform: translateX(100%);
          transition: transform 0.35s cubic-bezier(0.16, 1, 0.3, 1);
          box-shadow: -10px 0 35px rgba(15, 39, 68, 0.15);
        }

        .gq-mobile-drawer--open {
          transform: translateX(0);
        }

        .gq-drawer-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 20px 22px;
          border-bottom: 1px solid #F1F5F9;
        }

        .gq-drawer-close {
          width: 34px;
          height: 34px;
          border-radius: 8px;
          background: #F8FAFC;
          border: 1px solid #E2E8F0;
          color: #475569;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
        }

        .gq-drawer-body {
          flex: 1;
          padding: 18px 20px;
          overflow-y: auto;
          display: flex;
          flex-direction: column;
          gap: 6px;
        }

        .gq-drawer-nav-label {
          font-size: 11px;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.08em;
          color: #94A3B8;
          margin-bottom: 6px;
        }

        .gq-drawer-link {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 10px 14px;
          font-size: 14px;
          font-weight: 600;
          color: #1E293B;
          text-decoration: none;
          border-radius: 8px;
          transition: all 0.15s ease;
        }

        .gq-drawer-link:hover,
        .gq-drawer-link.active {
          background: #F1F5F9;
          color: #1D4ED8;
        }

        .gq-drawer-footer {
          padding: 18px 20px;
          border-top: 1px solid #F1F5F9;
          display: flex;
          flex-direction: column;
          gap: 10px;
        }

        .gq-drawer-btn {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          padding: 12px;
          font-size: 14px;
          font-weight: 700;
          border-radius: 10px;
          text-decoration: none;
          transition: all 0.2s ease;
        }

        .gq-drawer-btn--primary {
          background: linear-gradient(135deg, #0F2744 0%, #1E3A8A 100%);
          color: #FFFFFF;
          box-shadow: 0 4px 14px rgba(15, 39, 68, 0.15);
        }

        .gq-drawer-btn--secondary {
          background: #F8FAFC;
          color: #0F2744;
          border: 1px solid #E2E8F0;
        }

        .gq-drawer-whatsapp {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          font-size: 12.5px;
          font-weight: 600;
          color: #059669;
          text-decoration: none;
          margin-top: 4px;
        }
      `}),(0,N.jsx)(`nav`,{className:`gq-navbar ${t?`gq-navbar--scrolled`:`gq-navbar--top`}`,"aria-label":`Main SchoolProfit navigation`,children:(0,N.jsxs)(`div`,{className:`gq-nav-container`,children:[(0,N.jsxs)(o,{to:`/`,className:`gq-logo-link`,"aria-label":`SchoolProfit Homepage`,children:[(0,N.jsx)(`div`,{className:`gq-logo-badge`,style:{background:`transparent`,border:`none`,boxShadow:`none`},children:(0,N.jsx)(`img`,{src:`/media/logo/schoolprofit-logo.svg`,alt:`SchoolProfit Logo`,className:`gq-logo-img`,style:{width:`auto`,height:`38px`,objectFit:`contain`},onError:e=>{let t=e.currentTarget;t.style.display=`none`}})}),(0,N.jsxs)(`div`,{className:`gq-logo-text-block`,children:[(0,N.jsxs)(`div`,{className:`gq-brand-name`,children:[`School`,(0,N.jsx)(`span`,{style:{color:`#059669`},children:`Profit`})]}),(0,N.jsx)(`span`,{className:`gq-brand-tagline`,children:`Growth & Profit OS`})]})]}),(0,N.jsx)(`ul`,{className:`gq-nav-links`,role:`list`,children:xe.map(e=>(0,N.jsx)(`li`,{className:`gq-nav-item`,children:(0,N.jsx)(`a`,{href:e.href,className:a===e.href.slice(1)?`active`:``,children:e.label})},e.href))}),(0,N.jsxs)(`div`,{className:`gq-nav-actions-desktop`,children:[(0,N.jsx)(`a`,{href:`https://web.facebook.com/profile.php?id=61585446674333`,target:`_blank`,rel:`noopener noreferrer`,className:`gq-btn-ghost`,style:{padding:`8px 12px`,color:`#1877F2`},"aria-label":`SchoolProfit Facebook Page`,title:`Follow SchoolProfit on Facebook`,children:(0,N.jsx)(`svg`,{width:`15`,height:`15`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2.2`,strokeLinecap:`round`,strokeLinejoin:`round`,children:(0,N.jsx)(`path`,{d:`M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3V2z`})})}),(0,N.jsxs)(o,{to:`/check-result`,className:`gq-btn-ghost`,children:[(0,N.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 24 24`,fill:`none`,stroke:`#D97706`,strokeWidth:`2.2`,children:[(0,N.jsx)(`path`,{d:`M9 11l3 3L22 4`,strokeLinecap:`round`,strokeLinejoin:`round`}),(0,N.jsx)(`path`,{d:`M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),`Check Result`]}),(0,N.jsxs)(o,{to:`/login`,className:`gq-btn-primary`,children:[`Portal Sign In`,(0,N.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:(0,N.jsx)(`path`,{d:`M1 7h12M7 1l6 6-6 6`,stroke:`currentColor`,strokeWidth:`1.8`,strokeLinecap:`round`,strokeLinejoin:`round`})})]})]}),(0,N.jsxs)(`button`,{className:`gq-nav-hamburger ${r?`gq-nav-hamburger--open`:``}`,onClick:()=>i(e=>!e),"aria-expanded":r,"aria-label":r?`Close menu`:`Open menu`,children:[(0,N.jsx)(`span`,{className:`gq-hamburger-line`}),(0,N.jsx)(`span`,{className:`gq-hamburger-line`}),(0,N.jsx)(`span`,{className:`gq-hamburger-line`})]})]})}),(0,N.jsx)(`div`,{className:`gq-drawer-backdrop ${r?`gq-drawer-backdrop--open`:``}`,onClick:()=>i(!1),"aria-hidden":`true`}),(0,N.jsxs)(`div`,{ref:c,className:`gq-mobile-drawer ${r?`gq-mobile-drawer--open`:``}`,role:`dialog`,"aria-modal":`true`,"aria-label":`Mobile Navigation Menu`,children:[(0,N.jsxs)(`div`,{className:`gq-drawer-header`,children:[(0,N.jsxs)(`div`,{className:`gq-brand-name`,style:{fontSize:18},children:[`School`,(0,N.jsx)(`span`,{style:{color:`#059669`},children:`Profit`})]}),(0,N.jsx)(`button`,{className:`gq-drawer-close`,onClick:()=>i(!1),"aria-label":`Close menu`,children:(0,N.jsxs)(`svg`,{width:`15`,height:`15`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,children:[(0,N.jsx)(`line`,{x1:`18`,y1:`6`,x2:`6`,y2:`18`,strokeLinecap:`round`}),(0,N.jsx)(`line`,{x1:`6`,y1:`6`,x2:`18`,y2:`18`,strokeLinecap:`round`})]})})]}),(0,N.jsxs)(`div`,{className:`gq-drawer-body`,children:[(0,N.jsx)(`div`,{className:`gq-drawer-nav-label`,children:`Explore System`}),xe.map(e=>(0,N.jsxs)(`a`,{href:e.href,className:`gq-drawer-link ${a===e.href.slice(1)?`active`:``}`,onClick:()=>i(!1),children:[(0,N.jsx)(`span`,{children:e.label}),(0,N.jsx)(`span`,{className:`gq-drawer-link-arrow`,children:(0,N.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,children:(0,N.jsx)(`polyline`,{points:`9 18 15 12 9 6`,strokeLinecap:`round`,strokeLinejoin:`round`})})})]},e.href)),(0,N.jsx)(`div`,{className:`gq-drawer-nav-label`,style:{marginTop:16},children:`Partnership`}),(0,N.jsxs)(o,{to:`/sales-representative/register`,className:`gq-drawer-link`,onClick:()=>i(!1),children:[(0,N.jsx)(`span`,{style:{color:`#D97706`,fontWeight:700},children:`💼 Become a Sales Partner (30%)`}),(0,N.jsx)(`span`,{className:`gq-drawer-link-arrow`,children:`→`})]}),(0,N.jsx)(`div`,{className:`gq-drawer-nav-label`,style:{marginTop:16},children:`Student & Parent Portals`}),(0,N.jsxs)(o,{to:`/check-result`,className:`gq-drawer-link`,onClick:()=>i(!1),children:[(0,N.jsx)(`span`,{children:`📜 Check Term Result / PIN`}),(0,N.jsx)(`span`,{className:`gq-drawer-link-arrow`,children:`→`})]})]}),(0,N.jsxs)(`div`,{className:`gq-drawer-footer`,children:[(0,N.jsxs)(o,{to:`/login`,className:`gq-drawer-btn gq-drawer-btn--primary`,onClick:()=>i(!1),children:[`School Portal Sign In`,(0,N.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,children:(0,N.jsx)(`path`,{d:`M1 7h12M7 1l6 6-6 6`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`})})]}),(0,N.jsx)(o,{to:`/book-demo`,className:`gq-drawer-btn gq-drawer-btn--secondary`,onClick:()=>i(!1),children:`Book a Free Demo`}),(0,N.jsx)(`a`,{href:e(`Hello SchoolProfit, I want to learn more about your school software`),target:`_blank`,rel:`noopener noreferrer`,className:`gq-drawer-whatsapp`,children:(0,N.jsx)(`span`,{children:`💬 Chat on WhatsApp with an Expert`})}),(0,N.jsxs)(`a`,{href:`https://web.facebook.com/profile.php?id=61585446674333`,target:`_blank`,rel:`noopener noreferrer`,className:`gq-drawer-facebook`,style:{display:`flex`,alignItems:`center`,justifyContent:`center`,gap:`8px`,padding:`11px 16px`,background:`#1877F2`,color:`#FFFFFF`,borderRadius:`10px`,fontWeight:700,fontSize:`13.5px`,textDecoration:`none`,marginTop:`8px`,boxShadow:`0 2px 8px rgba(24, 119, 242, 0.25)`},children:[(0,N.jsx)(`svg`,{width:`17`,height:`17`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2.2`,strokeLinecap:`round`,strokeLinejoin:`round`,children:(0,N.jsx)(`path`,{d:`M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3V2z`})}),(0,N.jsx)(`span`,{children:`Follow Us on Facebook`})]})]})]})]})}function Ce(){let{platform:e,whatsappLink:t,formattedPlatformFee:n}=Z();return(0,N.jsxs)(N.Fragment,{children:[(0,N.jsx)(`style`,{children:`
        :root {
          --pr-ink: #0F2744;
          --pr-dark: #0A192F;
          --pr-gold: #D97706;
          --pr-gold-light: #F59E0B;
          --pr-cream: #FFFFFF;
          --pr-muted: #64748B;
          --pr-line: #E2E8F0;
          --pr-green: #059669;
          --pr-bg: #F8FAFC;
        }

        .pr-wave {
          display: block;
          background: #FFFFFF;
          line-height: 0;
          overflow: hidden;
        }
        .pr-wave svg {
          display: block;
          width: 100%;
          height: 54px;
        }

        .pr-section {
          position: relative;
          overflow: hidden;
          background: #F8FAFC;
          padding: 96px 0 112px;
          color: var(--pr-ink);
          border-top: 1px solid #E2E8F0;
        }
        .pr-section:before {
          content: "";
          position: absolute;
          width: 620px;
          height: 620px;
          border-radius: 50%;
          right: -230px;
          top: -280px;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.08), transparent 68%);
          pointer-events: none;
        }
        .pr-section:after {
          content: "";
          position: absolute;
          width: 540px;
          height: 540px;
          border-radius: 50%;
          left: -260px;
          bottom: -300px;
          background: radial-gradient(circle, rgba(29, 78, 216, 0.06), transparent 68%);
          pointer-events: none;
        }

        .pr-shell {
          position: relative;
          z-index: 1;
          max-width: 1200px;
        }

        .pr-kicker {
          display: inline-flex;
          align-items: center;
          gap: 9px;
          color: #B45309;
          font-size: 12px;
          font-weight: 800;
          letter-spacing: .16em;
          text-transform: uppercase;
          background: #FEF3C7;
          padding: 7px 18px;
          border-radius: 999px;
          border: 1px solid #FDE68A;
          box-shadow: 0 2px 8px rgba(217, 119, 6, 0.08);
        }

        .pr-title {
          font-family: 'Playfair Display', Georgia, serif;
          font-size: clamp(34px, 4.8vw, 54px);
          font-weight: 900;
          line-height: 1.15;
          letter-spacing: -.02em;
          max-width: 900px;
          margin: 18px auto 0;
          color: #0F2744;
        }
        .pr-title em {
          font-style: italic;
          color: #D97706;
          background: linear-gradient(135deg, #D97706 0%, #B45309 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
        }

        .pr-subtitle {
          max-width: 760px;
          margin: 20px auto 0;
          color: var(--pr-muted);
          font-size: 16.5px;
          line-height: 1.7;
        }

        .pr-badges-row {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 16px;
          flex-wrap: wrap;
          margin-top: 26px;
        }
        .pr-badge-item {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 8px 16px;
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: 999px;
          font-size: 13px;
          font-weight: 700;
          color: #334155;
          box-shadow: 0 2px 6px rgba(15, 39, 68, 0.04);
        }
        .pr-badge-item i {
          color: #059669;
          font-size: 15px;
        }

        /* ── 3-Card Grid ── */
        .pr-grid-3 {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 24px;
          align-items: stretch;
          margin-top: 48px;
        }

        .pr-card-main {
          position: relative;
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: 24px;
          padding: 34px 28px;
          box-shadow: 0 10px 30px rgba(15, 39, 68, 0.05);
          display: flex;
          flex-direction: column;
          transition: all 0.25s ease;
        }
        .pr-card-main:hover {
          transform: translateY(-4px);
          box-shadow: 0 16px 40px rgba(15, 39, 68, 0.09);
        }

        .pr-card-featured {
          border: 2.5px solid #D97706;
          box-shadow: 0 18px 48px rgba(217, 119, 6, 0.16);
          background: linear-gradient(180deg, #FFFFFF 0%, #FFFDF9 100%);
        }

        .pr-pop-tag {
          position: absolute;
          top: -14px;
          left: 50%;
          transform: translateX(-50%);
          background: linear-gradient(135deg, #D97706 0%, #B45309 100%);
          color: #FFFFFF;
          font-size: 11px;
          font-weight: 900;
          letter-spacing: .14em;
          text-transform: uppercase;
          padding: 5px 18px;
          border-radius: 999px;
          box-shadow: 0 4px 12px rgba(217, 119, 6, 0.4);
          white-space: nowrap;
        }

        .pr-card-head {
          margin-bottom: 20px;
        }
        .pr-plan-label {
          font-size: 11.5px;
          font-weight: 900;
          letter-spacing: .14em;
          text-transform: uppercase;
          color: #B45309;
          margin-bottom: 8px;
        }
        .pr-plan-name {
          font-family: 'Playfair Display', Georgia, serif;
          font-size: 26px;
          font-weight: 900;
          color: #0F2744;
          margin: 0;
        }
        .pr-plan-desc {
          font-size: 13.5px;
          color: #64748B;
          margin-top: 8px;
          line-height: 1.55;
          min-height: 42px;
        }

        .pr-price-box {
          padding: 16px;
          background: #F8FAFC;
          border-radius: 14px;
          border: 1px solid #E2E8F0;
          margin-bottom: 24px;
        }
        .pr-card-featured .pr-price-box {
          background: #FFFBEB;
          border-color: #FDE68A;
        }
        .pr-price-val {
          font-family: 'Playfair Display', Georgia, serif;
          font-size: 36px;
          font-weight: 900;
          color: #0F2744;
          line-height: 1;
        }
        .pr-card-featured .pr-price-val {
          color: #B45309;
        }
        .pr-price-sub {
          font-size: 12px;
          font-weight: 700;
          color: #64748B;
          margin-top: 4px;
        }

        .pr-feature-list {
          list-style: none;
          padding: 0;
          margin: 0 0 28px;
          display: flex;
          flex-direction: column;
          gap: 12px;
          flex: 1;
        }
        .pr-feature-list li {
          display: flex;
          align-items: flex-start;
          gap: 10px;
          font-size: 13.5px;
          color: #334155;
          line-height: 1.45;
          font-weight: 600;
        }
        .pr-icon-check {
          width: 18px;
          height: 18px;
          flex: 0 0 18px;
          border-radius: 50%;
          background: #ECFDF5;
          color: #059669;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          font-size: 11px;
          margin-top: 2px;
          border: 1px solid #A7F3D0;
        }

        .pr-btn-primary {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          width: 100%;
          padding: 13px 20px;
          border-radius: 12px;
          font-size: 14px;
          font-weight: 800;
          text-decoration: none;
          transition: all 0.2s ease;
          background: #0F2744;
          color: #FFFFFF;
          border: none;
        }
        .pr-btn-primary:hover {
          background: #1E3A8A;
          color: #FFFFFF;
          transform: translateY(-2px);
        }

        .pr-btn-gold {
          background: linear-gradient(135deg, #D97706 0%, #B45309 100%);
          color: #FFFFFF;
          box-shadow: 0 6px 18px rgba(217, 119, 6, 0.35);
        }
        .pr-btn-gold:hover {
          background: linear-gradient(135deg, #F59E0B 0%, #D97706 100%);
          color: #FFFFFF;
          box-shadow: 0 8px 24px rgba(217, 119, 6, 0.45);
        }

        .pr-btn-outline {
          background: #FFFFFF;
          color: #0F2744;
          border: 1.5px solid #CBD5E1;
        }
        .pr-btn-outline:hover {
          background: #F1F5F9;
          border-color: #0F2744;
          color: #0F2744;
        }

        /* ── Add-On & Session Banner ── */
        .pr-session-banner {
          margin-top: 36px;
          background: linear-gradient(135deg, #0F2744 0%, #1E3A8A 100%);
          border-radius: 20px;
          padding: 28px 34px;
          color: #FFFFFF;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 24px;
          flex-wrap: wrap;
          box-shadow: 0 10px 30px rgba(15, 39, 68, 0.12);
        }

        .pr-addon-box {
          margin-top: 24px;
          background: #FFFFFF;
          border: 1.5px dashed #D97706;
          border-radius: 20px;
          padding: 24px 30px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 20px;
          flex-wrap: wrap;
        }

        /* ── Comparison Banner ── */
        .pr-compare-box {
          margin-top: 48px;
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: 20px;
          padding: 32px;
          box-shadow: 0 8px 28px rgba(15, 39, 68, 0.05);
        }
        .pr-compare-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 24px;
        }
        .pr-compare-col {
          padding: 20px;
          border-radius: 14px;
        }
        .pr-compare-old {
          background: #FFF1F2;
          border: 1px solid #FFE4E6;
        }
        .pr-compare-gq {
          background: #F0FDF4;
          border: 1.5px solid #BBF7D0;
        }

        /* ── WhatsApp Banner ── */
        .pr-wa-strip {
          margin-top: 36px;
          background: #0F2744;
          border-radius: 18px;
          padding: 26px 32px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 20px;
          flex-wrap: wrap;
          color: #FFFFFF;
        }

        @media(max-width: 960px) {
          .pr-grid-3 { grid-template-columns: 1fr; max-width: 520px; margin: 40px auto 0; }
          .pr-compare-grid { grid-template-columns: 1fr; }
        }
      `}),(0,N.jsx)(`div`,{className:`pr-wave`,"aria-hidden":`true`,children:(0,N.jsx)(`svg`,{viewBox:`0 0 1440 54`,preserveAspectRatio:`none`,children:(0,N.jsx)(`path`,{d:`M0 15C260 55 470 0 720 28c250 28 455-15 720 0v26H0z`,fill:`#F8FAFC`})})}),(0,N.jsx)(`section`,{className:`pr-section gq-scroll-reveal`,id:`pricing`,children:(0,N.jsxs)(`div`,{className:`container-xl pr-shell`,children:[(0,N.jsxs)(`header`,{className:`text-center`,children:[(0,N.jsx)(`span`,{className:`pr-kicker`,children:`100% Free Core OS • Pay When Tuition is Cleared`}),(0,N.jsxs)(`h2`,{className:`pr-title`,children:[`Complete School Management is `,(0,N.jsx)(`em`,{children:`100% Free.`}),(0,N.jsx)(`br`,{}),`Transparent Pay-As-You-Go Fee Clearance.`]}),(0,N.jsx)(`p`,{className:`pr-subtitle`,children:`Say goodbye to expensive yearly software licenses and mid-term student lockouts. SchoolProfit provides full day-to-day administrative tools completely free, earning only a tiny platform fee when school tuition is cleared.`}),(0,N.jsxs)(`div`,{className:`pr-badges-row`,children:[(0,N.jsxs)(`span`,{className:`pr-badge-item`,children:[(0,N.jsx)(`i`,{className:`bi bi-shield-check`}),` ₦0 Upfront Setup Fee`]}),(0,N.jsxs)(`span`,{className:`pr-badge-item`,children:[(0,N.jsx)(`i`,{className:`bi bi-infinity`}),` Unlimited Students & Staff`]}),(0,N.jsxs)(`span`,{className:`pr-badge-item`,children:[(0,N.jsx)(`i`,{className:`bi bi-file-earmark-check`}),` Free Result Checking for Parents`]}),(0,N.jsxs)(`span`,{className:`pr-badge-item`,children:[(0,N.jsx)(`i`,{className:`bi bi-arrow-repeat`}),` No Annual Expirations`]})]})]}),(0,N.jsxs)(`div`,{className:`pr-grid-3`,children:[(0,N.jsxs)(`article`,{className:`pr-card-main`,children:[(0,N.jsxs)(`div`,{className:`pr-card-head`,children:[(0,N.jsx)(`div`,{className:`pr-plan-label`,children:`Core School Operating System`}),(0,N.jsx)(`h3`,{className:`pr-plan-name`,children:`SchoolProfit Free Core`}),(0,N.jsx)(`p`,{className:`pr-plan-desc`,children:`Everything your school needs for everyday management with zero subscription charges forever.`})]}),(0,N.jsxs)(`div`,{className:`pr-price-box`,children:[(0,N.jsx)(`div`,{className:`pr-price-val`,children:`₦0`}),(0,N.jsx)(`div`,{className:`pr-price-sub`,children:`Free Forever • No Monthly Fees`})]}),(0,N.jsxs)(`ul`,{className:`pr-feature-list`,children:[(0,N.jsxs)(`li`,{children:[(0,N.jsx)(`span`,{className:`pr-icon-check`,children:(0,N.jsx)(`i`,{className:`bi bi-check`})}),(0,N.jsx)(`span`,{children:`Unlimited Student, Teacher & Parent Profiles`})]}),(0,N.jsxs)(`li`,{children:[(0,N.jsx)(`span`,{className:`pr-icon-check`,children:(0,N.jsx)(`i`,{className:`bi bi-check`})}),(0,N.jsx)(`span`,{children:`Continuous Assessment & Broadsheet Compilation`})]}),(0,N.jsxs)(`li`,{children:[(0,N.jsx)(`span`,{className:`pr-icon-check`,children:(0,N.jsx)(`i`,{className:`bi bi-check`})}),(0,N.jsx)(`span`,{children:`Digital School Fee Ledger & Bank Account Integration`})]}),(0,N.jsxs)(`li`,{children:[(0,N.jsx)(`span`,{className:`pr-icon-check`,children:(0,N.jsx)(`i`,{className:`bi bi-check`})}),(0,N.jsx)(`span`,{children:`Attendance Tracking & Staff QR Clock-in`})]}),(0,N.jsxs)(`li`,{children:[(0,N.jsx)(`span`,{className:`pr-icon-check`,children:(0,N.jsx)(`i`,{className:`bi bi-check`})}),(0,N.jsx)(`span`,{children:`Offline Local CBT Examination Engine`})]}),(0,N.jsxs)(`li`,{children:[(0,N.jsx)(`span`,{className:`pr-icon-check`,children:(0,N.jsx)(`i`,{className:`bi bi-check`})}),(0,N.jsx)(`span`,{children:`Dedicated Bursar, Teacher & Parent Portals`})]})]}),(0,N.jsxs)(o,{to:`/book-demo`,className:`pr-btn-primary pr-btn-outline`,children:[`Book a Free Demo `,(0,N.jsx)(`i`,{className:`bi bi-arrow-right`})]})]}),(0,N.jsxs)(`article`,{className:`pr-card-main`,children:[(0,N.jsxs)(`div`,{className:`pr-card-head`,children:[(0,N.jsx)(`div`,{className:`pr-plan-label`,children:`Result Management Edition`}),(0,N.jsx)(`h3`,{className:`pr-plan-name`,children:`Basic Result Tier`}),(0,N.jsx)(`p`,{className:`pr-plan-desc`,children:`Pay only when students settle tuition. Unlocks digital report cards, CA broadsheets, and parent access.`})]}),(0,N.jsxs)(`div`,{className:`pr-price-box`,children:[(0,N.jsx)(`div`,{className:`pr-price-val`,children:`₦300`}),(0,N.jsx)(`div`,{className:`pr-price-sub`,children:`per active student / term`})]}),(0,N.jsxs)(`ul`,{className:`pr-feature-list`,children:[(0,N.jsxs)(`li`,{children:[(0,N.jsx)(`span`,{className:`pr-icon-check`,children:(0,N.jsx)(`i`,{className:`bi bi-check`})}),(0,N.jsx)(`span`,{children:(0,N.jsx)(`strong`,{children:`Everything in Free Core OS`})})]}),(0,N.jsxs)(`li`,{children:[(0,N.jsx)(`span`,{className:`pr-icon-check`,children:(0,N.jsx)(`i`,{className:`bi bi-check`})}),(0,N.jsxs)(`span`,{children:[(0,N.jsx)(`strong`,{children:`Official Digital Report Cards:`}),` Publish termly report sheets`]})]}),(0,N.jsxs)(`li`,{children:[(0,N.jsx)(`span`,{className:`pr-icon-check`,children:(0,N.jsx)(`i`,{className:`bi bi-check`})}),(0,N.jsxs)(`span`,{children:[(0,N.jsx)(`strong`,{children:`₦0 Scratch Card Fees:`}),` Parents view & download results free`]})]}),(0,N.jsxs)(`li`,{children:[(0,N.jsx)(`span`,{className:`pr-icon-check`,children:(0,N.jsx)(`i`,{className:`bi bi-check`})}),(0,N.jsxs)(`span`,{children:[(0,N.jsx)(`strong`,{children:`Anti-Tamper QR Verification:`}),` Scannable validation on all results`]})]}),(0,N.jsxs)(`li`,{children:[(0,N.jsx)(`span`,{className:`pr-icon-check`,children:(0,N.jsx)(`i`,{className:`bi bi-check`})}),(0,N.jsxs)(`span`,{children:[(0,N.jsx)(`strong`,{children:`Student Promotion Engine:`}),` Automated carry-over & class advancement`]})]}),(0,N.jsxs)(`li`,{children:[(0,N.jsx)(`span`,{className:`pr-icon-check`,children:(0,N.jsx)(`i`,{className:`bi bi-check`})}),(0,N.jsxs)(`span`,{children:[(0,N.jsx)(`strong`,{children:`Flexible Clearance:`}),` Automated Paystack split or 1-click wallet clearance`]})]})]}),(0,N.jsxs)(o,{to:`/book-demo`,className:`pr-btn-primary pr-btn-outline`,children:[`Explore Basic Tier `,(0,N.jsx)(`i`,{className:`bi bi-arrow-right`})]})]}),(0,N.jsxs)(`article`,{className:`pr-card-main pr-card-featured`,children:[(0,N.jsx)(`div`,{className:`pr-pop-tag`,children:`MOST POPULAR • ALL-INCLUSIVE`}),(0,N.jsxs)(`div`,{className:`pr-card-head`,children:[(0,N.jsx)(`div`,{className:`pr-plan-label`,children:`Cloud CBT & All-Inclusive Edition`}),(0,N.jsx)(`h3`,{className:`pr-plan-name`,children:`Standard CBT Tier`}),(0,N.jsx)(`p`,{className:`pr-plan-desc`,children:`The complete power package. Combines full digital results with multi-school cloud CBT examination.`})]}),(0,N.jsxs)(`div`,{className:`pr-price-box`,children:[(0,N.jsx)(`div`,{className:`pr-price-val`,children:`₦500`}),(0,N.jsx)(`div`,{className:`pr-price-sub`,children:`per active student / term`})]}),(0,N.jsxs)(`ul`,{className:`pr-feature-list`,children:[(0,N.jsxs)(`li`,{children:[(0,N.jsx)(`span`,{className:`pr-icon-check`,children:(0,N.jsx)(`i`,{className:`bi bi-check`})}),(0,N.jsx)(`span`,{children:(0,N.jsx)(`strong`,{children:`Everything in Basic Result Tier (₦300)`})})]}),(0,N.jsxs)(`li`,{children:[(0,N.jsx)(`span`,{className:`pr-icon-check`,children:(0,N.jsx)(`i`,{className:`bi bi-check`})}),(0,N.jsxs)(`span`,{children:[(0,N.jsx)(`strong`,{children:`Online Cloud CBT Portal:`}),` 3,000+ simultaneous student concurrency`]})]}),(0,N.jsxs)(`li`,{children:[(0,N.jsx)(`span`,{className:`pr-icon-check`,children:(0,N.jsx)(`i`,{className:`bi bi-check`})}),(0,N.jsxs)(`span`,{children:[(0,N.jsx)(`strong`,{children:`Instant Auto-Grading:`}),` Direct computation into term broadsheets`]})]}),(0,N.jsxs)(`li`,{children:[(0,N.jsx)(`span`,{className:`pr-icon-check`,children:(0,N.jsx)(`i`,{className:`bi bi-check`})}),(0,N.jsxs)(`span`,{children:[(0,N.jsx)(`strong`,{children:`Anti-Cheating Security:`}),` Fullscreen lockdown & tab-switch logging`]})]}),(0,N.jsxs)(`li`,{children:[(0,N.jsx)(`span`,{className:`pr-icon-check`,children:(0,N.jsx)(`i`,{className:`bi bi-check`})}),(0,N.jsxs)(`span`,{children:[(0,N.jsx)(`strong`,{children:`Comprehension & Math Engines:`}),` Passages, formulas & scientific calculator`]})]}),(0,N.jsxs)(`li`,{children:[(0,N.jsx)(`span`,{className:`pr-icon-check`,children:(0,N.jsx)(`i`,{className:`bi bi-check`})}),(0,N.jsxs)(`span`,{children:[(0,N.jsx)(`strong`,{children:`Offline-First Resilience:`}),` Never lose answers even during network flickers`]})]})]}),(0,N.jsxs)(o,{to:`/book-demo`,className:`pr-btn-primary pr-btn-gold`,children:[`Book a Live Demo with SchoolProfit `,(0,N.jsx)(`i`,{className:`bi bi-lightning-charge-fill`})]})]})]}),(0,N.jsxs)(`div`,{className:`pr-session-banner`,children:[(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`div`,{style:{fontSize:`12px`,textTransform:`uppercase`,letterSpacing:`.14em`,color:`#FDE68A`,fontWeight:900},children:`FULL SESSION BUNDLE`}),(0,N.jsx)(`h3`,{style:{fontSize:`22px`,fontWeight:900,margin:`6px 0`,color:`#FFFFFF`},children:`Pay 3 Terms Upfront for the Entire Academic Year`}),(0,N.jsx)(`p`,{style:{margin:0,fontSize:`14px`,color:`rgba(255,255,255,0.85)`,maxWidth:`700px`,lineHeight:1.6},children:`Proprietors can clear their entire student body for all 3 terms upfront in a single click with zero termly renewal stress.`})]}),(0,N.jsxs)(o,{to:`/book-demo`,className:`pr-btn-primary pr-btn-gold`,style:{width:`auto`,padding:`12px 26px`,whiteSpace:`nowrap`},children:[`Inquire Full Session `,(0,N.jsx)(`i`,{className:`bi bi-arrow-right`})]})]}),(0,N.jsxs)(`div`,{className:`pr-addon-box`,children:[(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`div`,{style:{fontSize:`12px`,textTransform:`uppercase`,letterSpacing:`.14em`,color:`#D97706`,fontWeight:900},children:`OPTIONAL ON-DEMAND ADD-ONS`}),(0,N.jsx)(`h4`,{style:{fontSize:`18px`,fontWeight:900,margin:`4px 0`,color:`#0F2744`},children:`AI Curriculum Tools & WhatsApp Parent Dispatch`}),(0,N.jsx)(`p`,{style:{margin:0,fontSize:`13.5px`,color:`#64748B`,maxWidth:`720px`,lineHeight:1.55},children:`Top up your wallet only when you need credits: Instant WhatsApp fee receipts, attendance alerts, report cards, AI lesson note generation, and WAEC-standard CBT question creators.`})]}),(0,N.jsxs)(o,{to:`/book-demo`,className:`pr-btn-primary pr-btn-outline`,style:{width:`auto`,padding:`11px 22px`,whiteSpace:`nowrap`},children:[`Explore Add-Ons `,(0,N.jsx)(`i`,{className:`bi bi-stars`})]})]}),(0,N.jsxs)(`div`,{className:`pr-compare-box`,children:[(0,N.jsx)(`h3`,{style:{fontFamily:`Playfair Display, Georgia, serif`,fontSize:`22px`,fontWeight:900,color:`#0F2744`,textAlign:`center`,marginBottom:`20px`},children:`Why School Proprietors Choose SchoolProfit Over Traditional Portals`}),(0,N.jsxs)(`div`,{className:`pr-compare-grid`,children:[(0,N.jsxs)(`div`,{className:`pr-compare-col pr-compare-old`,children:[(0,N.jsxs)(`div`,{style:{fontWeight:800,color:`#BE123C`,fontSize:`15px`,marginBottom:`12px`,display:`flex`,alignItems:`center`,gap:`8px`},children:[(0,N.jsx)(`i`,{className:`bi bi-x-circle-fill`}),` Traditional School Software`]}),(0,N.jsxs)(`ul`,{style:{listStyle:`none`,padding:0,margin:0,display:`flex`,flexDirection:`column`,gap:`10px`,fontSize:`13px`,color:`#881337`},children:[(0,N.jsx)(`li`,{children:`❌ Expensive upfront setup fees (₦150,000 – ₦500,000/yr).`}),(0,N.jsx)(`li`,{children:`❌ Strict termly subscription renewals or software is locked.`}),(0,N.jsx)(`li`,{children:`❌ Charges parents ₦1,500 – ₦3,000 for result checker scratch cards.`}),(0,N.jsx)(`li`,{children:`❌ School pays for students who haven't paid fees or dropped out.`}),(0,N.jsx)(`li`,{children:`❌ Slow manual bank reconciliation.`})]})]}),(0,N.jsxs)(`div`,{className:`pr-compare-col pr-compare-gq`,children:[(0,N.jsxs)(`div`,{style:{fontWeight:800,color:`#15803D`,fontSize:`15px`,marginBottom:`12px`,display:`flex`,alignItems:`center`,gap:`8px`},children:[(0,N.jsx)(`i`,{className:`bi bi-check-circle-fill`}),` SchoolProfit Intelligent Cloud`]}),(0,N.jsxs)(`ul`,{style:{listStyle:`none`,padding:0,margin:0,display:`flex`,flexDirection:`column`,gap:`10px`,fontSize:`13px`,color:`#14532D`},children:[(0,N.jsxs)(`li`,{children:[`✅ `,(0,N.jsx)(`strong`,{children:`₦0 setup fees & ₦0 yearly subscriptions forever.`})]}),(0,N.jsx)(`li`,{children:`✅ Complete core school management is 100% free with unlimited access.`}),(0,N.jsxs)(`li`,{children:[`✅ `,(0,N.jsx)(`strong`,{children:`₦0 scratch card fee for parents`}),` — Instant digital report cards.`]}),(0,N.jsxs)(`li`,{children:[`✅ Choose `,(0,N.jsx)(`strong`,{children:`Basic (₦300)`}),` or `,(0,N.jsx)(`strong`,{children:`Standard CBT (₦500)`}),` only when tuition is settled.`]}),(0,N.jsx)(`li`,{children:`✅ Instant automated Paystack split direct to your school bank account.`})]})]})]})]}),(0,N.jsxs)(`div`,{className:`pr-wa-strip`,children:[(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`div`,{style:{fontSize:`17px`,fontWeight:800},children:`Need a Personalized Onboarding Demo for Your School?`}),(0,N.jsx)(`div`,{style:{fontSize:`13.5px`,color:`#94A3B8`,marginTop:`4px`},children:`Our education consultants are available 24/7 to help set up your classes, staff, and student records.`})]}),(0,N.jsxs)(`a`,{href:t(`Hello SchoolProfit Team! I am a school proprietor/principal and I would like to onboard my school on the Free Core model.`),target:`_blank`,rel:`noopener noreferrer`,className:`pr-btn-primary pr-btn-gold`,style:{width:`auto`,padding:`12px 24px`,whiteSpace:`nowrap`},children:[(0,N.jsx)(`i`,{className:`bi bi-whatsapp`}),` Chat on WhatsApp`]})]})]})})]})}var we=[{name:`DIKOR Comprehensive College`,tag:`Comprehensive College`,location:`Badagry, Lagos`},{name:`Samjane Arise & Shine Schools`,tag:`Nursery, Primary & College`,location:`Badagry, Lagos`},{name:`Sam Favour Schools`,tag:`Creche, Primary & College`,location:`Ikorodu, Lagos`},{name:`Jacktem Academic Excellence`,tag:`Primary & Secondary`,location:`Sango Ota, Ogun`},{name:`Power of Success Int'l School`,tag:`Basic & Senior Secondary`,location:`Lagos`},{name:`Gibraltar College`,tag:`Comprehensive College`,location:`Lagos`},{name:`Heart International School`,tag:`Nursery, Primary & Secondary`,location:`Sagamu, Ogun`},{name:`Anas Best Way to Success Academy`,tag:`Model Academy`,location:`Oka Akoko, Ondo`},{name:`Legacy Institute of Health Technology`,tag:`Higher Institute & College`,location:`Kaduna`},{name:`Christine Primary School`,tag:`Nursery & Primary`,location:`Badagry, Lagos`},{name:`Learning Hills School`,tag:`Early Years & Secondary`,location:`Abeokuta, Ogun`},{name:`Dr. Raphael Arinze Memorial College`,tag:`Comprehensive College`,location:`Ukpor, Anambra`},{name:`Borgu School of Excellence`,tag:`Model Academy & College`,location:`New Bussa, Niger`},{name:`Abec College`,tag:`Secondary College`,location:`Lagos`},{name:`LCC College`,tag:`Comprehensive College`,location:`Lagos`},{name:`Emmanuel International School`,tag:`Basic & Secondary`,location:`Lagos`},{name:`DRAMTEC Academy`,tag:`Technical & Secondary`,location:`Anambra`}];function Te(e){let t=e.trim().split(/\s+/);return t.length===1?t[0].slice(0,2).toUpperCase():(t[0][0]+t[1][0]).toUpperCase()}var Ee=[{bg:`rgba(217, 119, 6, 0.12)`,fg:`#B45309`,border:`rgba(217, 119, 6, 0.25)`},{bg:`rgba(5, 150, 105, 0.12)`,fg:`#047857`,border:`rgba(5, 150, 105, 0.25)`},{bg:`rgba(29, 78, 216, 0.12)`,fg:`#1E40AF`,border:`rgba(29, 78, 216, 0.25)`},{bg:`rgba(124, 58, 237, 0.12)`,fg:`#6D28D9`,border:`rgba(124, 58, 237, 0.25)`},{bg:`rgba(219, 39, 119, 0.12)`,fg:`#BE185D`,border:`rgba(219, 39, 119, 0.25)`}];function De({school:e,index:t}){let n=Ee[t%Ee.length];return(0,N.jsxs)(`div`,{className:`gq-school-pill`,children:[(0,N.jsx)(`span`,{className:`gq-sp-mono`,style:{background:n.bg,color:n.fg,border:`1px solid ${n.border}`},children:Te(e.name)}),(0,N.jsxs)(`div`,{className:`gq-sp-content`,children:[(0,N.jsx)(`span`,{className:`gq-sp-name`,children:e.name}),(0,N.jsx)(`span`,{className:`gq-sp-tag`,children:e.tag})]}),(0,N.jsxs)(`span`,{className:`gq-sp-loc`,children:[(0,N.jsxs)(`svg`,{width:`10`,height:`10`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2.5`,children:[(0,N.jsx)(`path`,{d:`M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z`}),(0,N.jsx)(`circle`,{cx:`12`,cy:`10`,r:`3`})]}),e.location]})]})}function Oe(){let[e,t]=(0,_.useState)(we);(0,_.useEffect)(()=>{(async()=>{try{let e=await J.get(`/frontend/active-schools`);e.data?.status&&Array.isArray(e.data?.data)&&e.data.data.length>0&&t(e.data.data)}catch{}})()},[]);let n=Math.ceil(e.length/2),r=e.slice(0,n),i=e.slice(n),a=(0,_.useMemo)(()=>[...r,...r,...r,...r],[r]),o=(0,_.useMemo)(()=>[...i,...i,...i,...i],[i]);return(0,N.jsxs)(N.Fragment,{children:[(0,N.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Playfair+Display:ital,wght@0,600;0,800;1,600&display=swap');

        .gq-schools-section {
          background-color: #FFFFFF;
          padding: 88px 0 96px;
          position: relative;
          overflow: hidden;
          font-family: 'Plus Jakarta Sans', sans-serif;
          border-top: 1px solid #E2E8F0;
        }

        .gq-schools-kicker {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          color: #B45309;
          background: #FEF3C7;
          border: 1px solid #FDE68A;
          border-radius: 100px;
          padding: 5px 16px;
          margin-bottom: 20px;
        }

        .gq-schools-title {
          font-family: 'Playfair Display', Georgia, serif;
          font-size: clamp(28px, 3.4vw, 44px);
          font-weight: 800;
          color: #0F2744;
          line-height: 1.2;
          margin-bottom: 20px;
        }

        .gq-schools-title em {
          font-style: italic;
          color: #D97706;
          background: linear-gradient(135deg, #D97706 0%, #B45309 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
        }

        .gq-schools-subtitle {
          font-size: 15.5px;
          color: #475569;
          max-width: 540px;
          margin: 0 auto 36px;
        }

        .gq-schools-meta-bar {
          display: inline-flex;
          align-items: center;
          gap: 24px;
          background: #F8FAFC;
          border: 1px solid #E2E8F0;
          border-radius: 999px;
          padding: 12px 28px;
          margin-bottom: 60px;
          box-shadow: 0 2px 10px rgba(15, 39, 68, 0.04);
        }

        @media (max-width: 768px) {
          .gq-schools-meta-bar {
            display: flex;
            flex-direction: column;
            border-radius: 16px;
            gap: 10px;
          }
        }

        .gq-meta-item {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 13px;
          color: #1E293B;
          font-weight: 600;
        }

        .gq-meta-dot {
          color: #059669;
        }

        /* ── Marquee Track ── */
        .gq-marquee-track {
          display: flex;
          gap: 16px;
          width: max-content;
          will-change: transform;
        }

        .gq-marquee-left {
          animation: gqMarqueeLeft 40s linear infinite;
        }

        .gq-marquee-right {
          animation: gqMarqueeRight 44s linear infinite;
        }

        .gq-marquee-wrapper:hover .gq-marquee-track {
          animation-play-state: paused;
        }

        @keyframes gqMarqueeLeft {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }

        @keyframes gqMarqueeRight {
          0% { transform: translateX(-50%); }
          100% { transform: translateX(0); }
        }

        .gq-marquee-fade {
          position: relative;
          overflow: hidden;
          padding: 8px 0;
        }

        .gq-marquee-fade::before,
        .gq-marquee-fade::after {
          content: '';
          position: absolute;
          top: 0;
          bottom: 0;
          width: 120px;
          z-index: 2;
          pointer-events: none;
        }

        .gq-marquee-fade::before {
          left: 0;
          background: linear-gradient(90deg, #FFFFFF 0%, transparent 100%);
        }

        .gq-marquee-fade::after {
          right: 0;
          background: linear-gradient(270deg, #FFFFFF 0%, transparent 100%);
        }

        /* ── Pill Card ── */
        .gq-school-pill {
          display: flex;
          align-items: center;
          gap: 14px;
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: 14px;
          padding: 12px 18px;
          transition: all 0.25s ease;
          user-select: none;
          white-space: nowrap;
          box-shadow: 0 2px 8px rgba(15, 39, 68, 0.04);
        }

        .gq-school-pill:hover {
          background: #F8FAFC;
          border-color: rgba(217, 119, 6, 0.45);
          transform: translateY(-2px);
          box-shadow: 0 8px 24px rgba(15, 39, 68, 0.08);
        }

        .gq-sp-mono {
          width: 36px;
          height: 36px;
          border-radius: 10px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 13px;
          font-weight: 800;
          flex-shrink: 0;
        }

        .gq-sp-content {
          display: flex;
          flex-direction: column;
        }

        .gq-sp-name {
          font-size: 14px;
          font-weight: 700;
          color: #0F2744;
        }

        .gq-sp-tag {
          font-size: 11px;
          color: #64748B;
          font-weight: 500;
        }

        .gq-sp-loc {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          padding: 3px 8px;
          border-radius: 6px;
          background: #F1F5F9;
          font-size: 11px;
          font-weight: 600;
          color: #1D4ED8;
          margin-left: 8px;
        }
      `}),(0,N.jsxs)(`section`,{id:`schools`,className:`gq-schools-section gq-scroll-reveal`,children:[(0,N.jsxs)(`div`,{className:`container-xl text-center`,children:[(0,N.jsxs)(`div`,{className:`gq-schools-kicker`,children:[(0,N.jsx)(`span`,{children:`🏫`}),` Active Partner Institutions`]}),(0,N.jsxs)(`h2`,{className:`gq-schools-title`,children:[`Powering Leading `,(0,N.jsx)(`em`,{children:`Academies, Colleges & International School Groups`})]}),(0,N.jsx)(`p`,{className:`gq-schools-subtitle`,children:`Progressive private and international institutions operating their academic broadsheets, fees collection, and CBT assessments on SchoolProfit.`}),(0,N.jsxs)(`div`,{className:`gq-schools-meta-bar`,children:[(0,N.jsxs)(`div`,{className:`gq-meta-item`,children:[(0,N.jsx)(`span`,{className:`gq-meta-dot`,children:`●`}),` Verified Active Schools`]}),(0,N.jsxs)(`div`,{className:`gq-meta-item`,children:[(0,N.jsx)(`span`,{className:`gq-meta-dot`,children:`●`}),` Multi-Campus & Regional Deployments`]}),(0,N.jsxs)(`div`,{className:`gq-meta-item`,children:[(0,N.jsx)(`span`,{className:`gq-meta-dot`,children:`●`}),` Early Years to Senior Secondary`]}),(0,N.jsxs)(`div`,{className:`gq-meta-item`,children:[(0,N.jsx)(`span`,{className:`gq-meta-dot`,children:`●`}),` 100% Data Protection`]})]})]}),(0,N.jsx)(`div`,{className:`gq-marquee-wrapper gq-marquee-fade mb-3`,children:(0,N.jsx)(`div`,{className:`gq-marquee-track gq-marquee-left`,children:a.map((e,t)=>(0,N.jsx)(De,{school:e,index:t},`a-${t}`))})}),(0,N.jsx)(`div`,{className:`gq-marquee-wrapper gq-marquee-fade`,children:(0,N.jsx)(`div`,{className:`gq-marquee-track gq-marquee-right`,children:o.map((e,t)=>(0,N.jsx)(De,{school:e,index:t+7},`b-${t}`))})})]})]})}var ke=[{quote:`Before SchoolProfit, computing results for 600 students took our staff nearly two weeks. Now it's done in a single afternoon — and the master broadsheet is ready before we even leave the office.`,name:`Mrs. Janet Avoseh`,role:`Head of Administration`,school:`Samjane Arise & Shine Schools`,location:`Badagry, Lagos`,initials:`JA`,avatar:`/images/testimonials/adaeze-okonkwo.jpg`,color:`#059669`,colorBg:`rgba(5, 150, 105, 0.1)`,rating:5,tag:`Results & Broadsheets`},{quote:`The AI monitoring flagged three teachers who hadn't submitted scores three days before our term deadline. No chasing, no embarrassing last-minute scrambles. It handled the accountability automatically.`,name:`Mr. Silvanus Segun`,role:`School Administrator`,school:`Jacktem Academic Excellence`,location:`Sango Ota, Ogun`,initials:`SS`,avatar:`/images/testimonials/tunde-adeyemi.jpg`,color:`#1D4ED8`,colorBg:`rgba(29, 78, 216, 0.1)`,rating:5,tag:`AI Monitoring`},{quote:`Parents were calling the office constantly asking for report cards. Since we launched the PIN portal and WhatsApp dispatches, those calls stopped completely. Parents check results securely on their phones.`,name:`Mrs. Deborah Afolabi`,role:`School Principal`,school:`Power of Success Int'l School`,location:`Lagos State`,initials:`DA`,avatar:`/images/testimonials/funmi-bello.jpg`,color:`#D97706`,colorBg:`rgba(217, 119, 6, 0.12)`,rating:5,tag:`Parent Portal & WhatsApp`},{quote:`Tracking fee payments used to be a nightmare of paper bank tellers and reconciliations. SchoolProfit gave us a clear digital ledger and instant receipts — term one collections improved significantly.`,name:`Dr. Leonard John`,role:`Proprietor & Director`,school:`Dr. Raphael Arinze Memorial College`,location:`Ukpor, Anambra`,initials:`LJ`,avatar:`/images/testimonials/emeka-nwosu.jpg`,color:`#7C3AED`,colorBg:`rgba(124, 58, 237, 0.1)`,rating:5,tag:`Fees Tracking & Bursary`},{quote:`The analytics dashboard helped us identify class areas that needed academic reinforcement in Mathematics. We took immediate action, and by the next term our students' subject average rose by 18 points.`,name:`Mr. Benjamin John`,role:`Academic Director`,school:`Heart International School`,location:`Sagamu, Ogun`,initials:`BJ`,avatar:`/images/testimonials/ngozi-eze.jpg`,color:`#0284C7`,colorBg:`rgba(2, 132, 199, 0.1)`,rating:5,tag:`Academic Analytics`},{quote:`I was impressed by how smooth the onboarding was. The SchoolProfit team migrated our multi-year student records in one day and trained our teachers personally. Zero classroom disruption.`,name:`Alh. Kabir Banuso`,role:`Director of Education`,school:`Borgu School of Excellence`,location:`New Bussa, Niger`,initials:`KB`,avatar:`/images/testimonials/seun-fashola.jpg`,color:`#E11D48`,colorBg:`rgba(225, 29, 72, 0.1)`,rating:5,tag:`Seamless Onboarding`}];function Ae({count:e}){return(0,N.jsx)(`span`,{className:`tm-stars d-inline-flex gap-1`,"aria-label":`${e} out of 5 stars`,children:Array.from({length:5}).map((t,n)=>(0,N.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 12 12`,fill:n<e?`#D97706`:`none`,"aria-hidden":`true`,children:(0,N.jsx)(`path`,{d:`M6 1l1.4 3.4H11L8.2 6.7l1.1 3.3L6 8.3 2.7 10l1.1-3.3L1 4.4h3.6z`,stroke:`#D97706`,strokeWidth:`0.6`})},n))})}function je(e,t=0){(0,_.useEffect)(()=>{let n=e.current;if(!n)return;let r=new IntersectionObserver(([e])=>{e.isIntersecting&&(setTimeout(()=>n.classList.add(`tm-visible`),t),r.unobserve(n))},{threshold:.08});return r.observe(n),()=>r.disconnect()},[e,t])}function Me({t:e,index:t}){let n=(0,_.useRef)(null);return je(n,100+t%2*110),(0,N.jsxs)(`div`,{ref:n,className:`tm-card`,style:{"--c":e.color,"--c-bg":e.colorBg},children:[(0,N.jsxs)(`div`,{className:`d-flex justify-content-between align-items-center mb-2`,children:[(0,N.jsx)(`span`,{className:`tm-tag`,children:e.tag}),(0,N.jsx)(`span`,{className:`badge bg-light text-dark fw-bold`,style:{fontSize:`10.5px`,border:`1px solid #E2E8F0`},children:`Verified School`})]}),(0,N.jsx)(`div`,{className:`mb-3`,children:(0,N.jsx)(Ae,{count:e.rating})}),(0,N.jsxs)(`blockquote`,{className:`tm-quote mb-4`,children:[(0,N.jsx)(`span`,{className:`tm-open-quote`,"aria-hidden":`true`,children:`"`}),e.quote]}),(0,N.jsxs)(`div`,{className:`tm-author d-flex align-items-center gap-3 pt-3`,children:[(0,N.jsxs)(`div`,{className:`position-relative flex-shrink-0`,children:[(0,N.jsx)(`img`,{src:e.avatar,alt:e.name,className:`tm-avatar-img`,loading:`lazy`,onError:e=>{e.target.style.display=`none`}}),(0,N.jsx)(`span`,{className:`position-absolute bottom-0 end-0 p-1 bg-success rounded-circle border border-white`,style:{width:`10px`,height:`10px`},title:`Verified Administrator`})]}),(0,N.jsxs)(`div`,{className:`d-flex flex-column gap-0.5`,children:[(0,N.jsx)(`span`,{className:`tm-name`,children:e.name}),(0,N.jsxs)(`span`,{className:`tm-role`,children:[e.role,` · `,(0,N.jsx)(`strong`,{children:e.school})]}),(0,N.jsxs)(`span`,{className:`tm-location d-inline-flex align-items-center gap-1`,children:[(0,N.jsxs)(`svg`,{width:`10`,height:`10`,viewBox:`0 0 12 12`,fill:`none`,"aria-hidden":`true`,children:[(0,N.jsx)(`path`,{d:`M6 1C4.067 1 2.5 2.567 2.5 4.5c0 3 3.5 6.5 3.5 6.5s3.5-3.5 3.5-6.5C9.5 2.567 7.933 1 6 1z`,stroke:`currentColor`,strokeWidth:`1.2`}),(0,N.jsx)(`circle`,{cx:`6`,cy:`4.5`,r:`1.2`,fill:`currentColor`})]}),e.location]})]})]})]})}function Ne(){let e=(0,_.useRef)(null),t=(0,_.useRef)(null);je(e,0),je(t,350);let n=ke.filter((e,t)=>t%2==0),r=ke.filter((e,t)=>t%2!=0);return(0,N.jsxs)(N.Fragment,{children:[(0,N.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;0,900;1,700&family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');

        :root {
          --tm-dark:   #0F2744;
          --tm-navy:   #0A192F;
          --tm-gold:   #D97706;
          --tm-muted:  #475569;
          --tm-border: rgba(15, 39, 68, 0.08);
          --tm-bg:     #F8FAFC;
        }

        .tm-section {
          background: var(--tm-bg);
          padding: 100px 0 110px;
          position: relative;
          overflow: hidden;
          font-family: 'Plus Jakarta Sans', sans-serif;
        }

        .tm-inner { position: relative; z-index: 1; }

        .tm-header {
          display: flex;
          align-items: flex-end;
          justify-content: space-between;
          flex-wrap: wrap;
          gap: 24px;
          margin-bottom: 56px;
        }

        .tm-kicker {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.1em;
          text-transform: uppercase;
          color: var(--tm-gold);
          background: #FEF3C7;
          border: 1px solid #FDE68A;
          border-radius: 100px;
          padding: 5px 16px;
        }

        .tm-title {
          font-family: 'Playfair Display', Georgia, serif;
          font-size: clamp(30px, 3.8vw, 48px);
          font-weight: 800;
          line-height: 1.18;
          color: var(--tm-dark);
          letter-spacing: -0.02em;
        }
        .tm-title em {
          font-style: italic;
          color: var(--tm-gold);
          background: linear-gradient(135deg, #D97706 0%, #B45309 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
        }

        .tm-desc {
          font-size: 15px;
          color: var(--tm-muted);
          max-width: 520px;
          line-height: 1.65;
        }

        .tm-rating-pill {
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: 16px;
          padding: 14px 22px;
          display: flex;
          align-items: center;
          gap: 12px;
          box-shadow: 0 4px 16px rgba(15, 39, 68, 0.06);
        }
        .tm-rating-val {
          font-size: 26px;
          font-weight: 800;
          color: var(--tm-dark);
          line-height: 1;
        }
        .tm-rating-label {
          font-size: 12px;
          color: var(--tm-muted);
          font-weight: 600;
        }

        .tm-col {
          display: flex;
          flex-direction: column;
          gap: 24px;
        }

        .tm-card {
          background: #FFFFFF;
          border: 1px solid var(--tm-border);
          border-radius: 20px;
          padding: 28px;
          box-shadow: 0 4px 20px -4px rgba(15, 39, 68, 0.05);
          position: relative;
          overflow: hidden;
          transition: all .35s cubic-bezier(0.16, 1, 0.3, 1);
          opacity: 0;
          transform: translateY(20px);
        }
        .tm-card.tm-visible {
          opacity: 1;
          transform: translateY(0);
        }
        .tm-card:hover {
          box-shadow: 0 16px 40px rgba(15, 39, 68, 0.12);
          border-color: rgba(217, 119, 6, 0.35);
          transform: translateY(-4px);
        }

        .tm-tag {
          display: inline-block;
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.06em;
          text-transform: uppercase;
          color: var(--c);
          background: var(--c-bg);
          border-radius: 100px;
          padding: 4px 12px;
        }

        .tm-quote {
          font-family: 'Playfair Display', Georgia, serif;
          font-size: 15.5px;
          font-weight: 400;
          font-style: italic;
          line-height: 1.75;
          color: #1E293B;
          margin: 0;
          border: none;
          padding: 0;
        }

        .tm-open-quote {
          font-family: 'Playfair Display', serif;
          font-size: 52px;
          line-height: 0;
          vertical-align: -20px;
          color: #D97706;
          opacity: 0.35;
          margin-right: 4px;
          font-style: normal;
        }

        .tm-author {
          border-top: 1px solid var(--tm-border);
        }

        .tm-avatar-img {
          width: 48px;
          height: 48px;
          border-radius: 50%;
          object-fit: cover;
          border: 2px solid #D97706;
          box-shadow: 0 4px 10px rgba(15, 39, 68, 0.12);
        }

        .tm-name {
          font-size: 14.5px;
          font-weight: 800;
          color: var(--tm-dark);
          line-height: 1.2;
        }
        .tm-role {
          font-size: 12.5px;
          font-weight: 500;
          color: var(--tm-muted);
          line-height: 1.3;
        }
        .tm-location {
          font-size: 11.5px;
          color: #64748B;
          font-weight: 600;
        }

        .tm-summary {
          border-radius: 20px;
          padding: 36px 40px;
          background: #0F2744;
          border: 1px solid rgba(255, 255, 255, 0.1);
          box-shadow: 0 16px 40px rgba(15, 39, 68, 0.15);
          opacity: 0;
          transform: translateY(18px);
          transition: opacity .65s ease, transform .65s ease;
        }
        .tm-summary.tm-visible {
          opacity: 1;
          transform: translateY(0);
        }

        .tm-summary-val {
          font-family: 'Playfair Display', serif;
          font-size: 32px;
          font-weight: 800;
          color: #FBBF24;
          line-height: 1;
        }
        .tm-summary-label {
          font-size: 11.5px;
          font-weight: 600;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          color: #E2E8F0;
        }
        .tm-summary-sep {
          width: 1px; height: 44px;
          background: rgba(255,255,255,0.15);
          flex-shrink: 0;
        }
      `}),(0,N.jsx)(`section`,{className:`tm-section gq-scroll-reveal`,id:`testimonials`,children:(0,N.jsxs)(`div`,{className:`tm-inner container-xl`,children:[(0,N.jsxs)(`div`,{ref:e,className:`tm-header`,children:[(0,N.jsxs)(`div`,{children:[(0,N.jsxs)(`div`,{className:`tm-kicker mb-3`,children:[(0,N.jsx)(`span`,{children:`💬`}),` Real Voices From Partner Schools`]}),(0,N.jsxs)(`h2`,{className:`tm-title mb-3`,children:[`Proven impact from`,(0,N.jsx)(`br`,{}),(0,N.jsx)(`em`,{children:`distinguished school leaders.`})]}),(0,N.jsx)(`p`,{className:`tm-desc mb-0`,children:`Authentic experiences from school proprietors, principals, and exam officers operating SchoolProfit Worldwide.`})]}),(0,N.jsx)(`div`,{className:`tm-header-right`,children:(0,N.jsxs)(`div`,{className:`tm-rating-pill`,children:[(0,N.jsx)(`span`,{className:`tm-rating-val`,children:`4.9`}),(0,N.jsx)(`span`,{className:`d-flex gap-1`,children:Array.from({length:5}).map((e,t)=>(0,N.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 12 12`,fill:`#D97706`,"aria-hidden":`true`,children:(0,N.jsx)(`path`,{d:`M6 1l1.4 3.4H11L8.2 6.7l1.1 3.3L6 8.3 2.7 10l1.1-3.3L1 4.4h3.6z`})},t))}),(0,N.jsx)(`span`,{className:`tm-rating-label`,children:`from 500+ schools`})]})})]}),(0,N.jsxs)(`div`,{className:`row g-4`,children:[(0,N.jsx)(`div`,{className:`col-12 col-md-6`,children:(0,N.jsx)(`div`,{className:`tm-col`,children:n.map((e,t)=>(0,N.jsx)(Me,{t:e,index:t*2},e.name))})}),(0,N.jsx)(`div`,{className:`col-12 col-md-6`,children:(0,N.jsx)(`div`,{className:`tm-col`,children:r.map((e,t)=>(0,N.jsx)(Me,{t:e,index:t*2+1},e.name))})})]}),(0,N.jsx)(`div`,{ref:t,className:`tm-summary d-flex align-items-center justify-content-center flex-wrap gap-5 mt-5`,children:[{val:`500+`,label:`Schools onboarded`},{val:`4.9★`,label:`Average rating`},{val:`2.4M+`,label:`Results processed`},{val:`99.2%`,label:`Term renewal rate`}].map((e,t,n)=>(0,N.jsxs)(`div`,{className:`d-flex align-items-center gap-5`,children:[(0,N.jsxs)(`div`,{className:`d-flex flex-column align-items-center gap-1`,children:[(0,N.jsx)(`span`,{className:`tm-summary-val`,children:e.val}),(0,N.jsx)(`span`,{className:`tm-summary-label`,children:e.label})]}),t<n.length-1&&(0,N.jsx)(`span`,{className:`tm-summary-sep d-none d-sm-block`})]},e.label))})]})})]})}var Pe=[{number:`01`,title:`Zero-Debt Bursary & Instant Multi-Bank Settlement`,tagline:`Stop Fee Defaults & Eliminate Cash Leakage`,description:`Collect fees via Monnify, Wema, and Paystack with instant bank credit. Gate report cards and CBT exams automatically so students cannot view results until fees are settled.`,metrics:`95% On-Time Fee Recovery`,badge:`Revenue & Profit`,image:`/images/features/feature-bursary-pos.jpg`,icon:(0,N.jsxs)(`svg`,{width:`22`,height:`22`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,children:[(0,N.jsx)(`rect`,{x:`2`,y:`5`,width:`20`,height:`14`,rx:`2`}),(0,N.jsx)(`line`,{x1:`2`,y1:`10`,x2:`22`,y2:`10`}),(0,N.jsx)(`circle`,{cx:`12`,cy:`15`,r:`2`})]})},{number:`02`,title:`Student Admissions & Enrollment Growth`,tagline:`Fill Your Classrooms with Scalable Marketing`,description:`Capture prospective parent leads directly through public sales pages. Power your admission campaigns with automated 30% sales representative partner tracking.`,metrics:`3x Faster Student Growth`,badge:`Admissions Engine`,image:`/images/features/feature-parent-portal.jpg`,icon:(0,N.jsxs)(`svg`,{width:`22`,height:`22`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,children:[(0,N.jsx)(`path`,{d:`M16 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2`}),(0,N.jsx)(`circle`,{cx:`8.5`,cy:`7`,r:`4`}),(0,N.jsx)(`polyline`,{points:`17 11 19 13 23 9`})]})},{number:`03`,title:`Instant Master Broadsheets & Report Cards`,tagline:`From Weeks of Stress to 30 Seconds`,description:`Automate continuous assessment calculations, cumulative GPAs, and class rankings without spreadsheet errors. Generate publication-ready master broadsheets and transcripts in single clicks.`,metrics:`95% Faster Termly Computation`,badge:`Academic Operations`,image:`/images/features/feature-broadsheet-mastery.jpg`,icon:(0,N.jsxs)(`svg`,{width:`22`,height:`22`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,children:[(0,N.jsx)(`path`,{d:`M13 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V9z`}),(0,N.jsx)(`polyline`,{points:`13 2 13 9 20 9`}),(0,N.jsx)(`path`,{d:`M9 13h6M9 17h4`})]})},{number:`04`,title:`Hybrid CBT Examination Engine`,tagline:`Uninterrupted Computer Lab Assessments`,description:`Conduct timed continuous assessment tests and mock exams with dual online and offline LAN resilience. Student progress is auto-saved continuously, ensuring zero data loss during power or network shifts.`,metrics:`100% Exam Lab Uptime`,badge:`Testing Hub`,image:`/images/features/feature-cbt-lab.jpg`,icon:(0,N.jsxs)(`svg`,{width:`22`,height:`22`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,children:[(0,N.jsx)(`rect`,{x:`2`,y:`3`,width:`20`,height:`14`,rx:`2`}),(0,N.jsx)(`line`,{x1:`8`,y1:`21`,x2:`16`,y2:`21`}),(0,N.jsx)(`line`,{x1:`12`,y1:`17`,x2:`12`,y2:`21`})]})},{number:`05`,title:`AI Teacher Assistant & Lesson Planning`,tagline:`Curricular Precision in Seconds`,description:`Empower your teaching faculty with intelligent assistants for outlining standardized curriculum schemes of work, generating structured lesson notes, and composing thoughtful student evaluations.`,metrics:`10+ Hours Saved Per Teacher/Week`,badge:`Faculty Superpowers`,image:`/images/features/feature-ai-lesson-notes.jpg`,icon:(0,N.jsxs)(`svg`,{width:`22`,height:`22`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,children:[(0,N.jsx)(`path`,{d:`M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2`}),(0,N.jsx)(`circle`,{cx:`9`,cy:`7`,r:`4`}),(0,N.jsx)(`path`,{d:`M23 21v-2a4 4 0 00-3-3.87`}),(0,N.jsx)(`path`,{d:`M16 3.13a4 4 0 010 7.75`})]})},{number:`06`,title:`Direct WhatsApp Dispatches & QR Seals`,tagline:`Instant Alerts & Tamper-Evident Security`,description:`Deliver digital report cards and payment receipts straight to parents' phones on WhatsApp. Every transcript carries an encrypted QR authentication seal for instant verification.`,metrics:`100% Tamper-Evident Security`,badge:`Parent & Trust`,image:`/images/features/feature-qr-transcript.jpg`,icon:(0,N.jsxs)(`svg`,{width:`22`,height:`22`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,children:[(0,N.jsx)(`rect`,{x:`3`,y:`3`,width:`7`,height:`7`}),(0,N.jsx)(`rect`,{x:`14`,y:`3`,width:`7`,height:`7`}),(0,N.jsx)(`rect`,{x:`14`,y:`14`,width:`7`,height:`7`}),(0,N.jsx)(`rect`,{x:`3`,y:`14`,width:`7`,height:`7`})]})}],Fe=[{feature:`Fee Collection & Debt Recovery`,generic:`Manual bank teller tracking & high parent fee debts`,schoolprofit:`Multi-bank instant settlement + result & CBT gatekeepers`},{feature:`Broadsheet & Report Compilation`,generic:`Manual calculations prone to arithmetic errors (2-3 weeks)`,schoolprofit:`Automated cumulative GPA & rankings compiled in seconds`},{feature:`Student Admission & Enrollment`,generic:`Paper flyers with zero lead tracking`,schoolprofit:`Public landing pages + automated sales partner tracking`},{feature:`CBT Examination Infrastructure`,generic:`Requires constant high-speed internet; crashes on power cuts`,schoolprofit:`Dual hybrid architecture: Offline LAN + Cloud sync`},{feature:`Teacher Lesson Planning`,generic:`Hours of manual handwritten scheme formatting`,schoolprofit:`AI-assisted standardized curriculum & lesson notes`},{feature:`Parent Communication & Trust`,generic:`Delayed termly physical newsletters & paper cards`,schoolprofit:`Direct WhatsApp alerts + QR verifiable digital transcripts`}];function Ie(){let e=(0,_.useRef)(null);return(0,_.useEffect)(()=>{let e=new IntersectionObserver(e=>{e.forEach(e=>{e.isIntersecting&&e.target.classList.add(`gq-revealed`)})},{threshold:.1});return document.querySelectorAll(`.gq-why-card, .gq-compare-box`).forEach(t=>e.observe(t)),()=>e.disconnect()},[]),(0,N.jsxs)(N.Fragment,{children:[(0,N.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Playfair+Display:ital,wght@0,600;0,800;1,600&display=swap');

        .gq-why-section {
          background-color: #FFFFFF;
          padding: 100px 0 110px;
          position: relative;
          font-family: 'Plus Jakarta Sans', sans-serif;
          overflow: hidden;
        }

        .gq-why-kicker {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          color: #B45309;
          background: #FEF3C7;
          border: 1px solid #FDE68A;
          border-radius: 999px;
          padding: 5px 16px;
          margin-bottom: 16px;
        }

        .gq-why-title {
          font-family: 'Playfair Display', Georgia, serif;
          font-size: clamp(30px, 3.8vw, 48px);
          font-weight: 800;
          color: #0F2744;
          letter-spacing: -0.02em;
          margin-bottom: 16px;
          line-height: 1.2;
        }

        .gq-why-title em {
          font-style: italic;
          color: #D97706;
          background: linear-gradient(135deg, #D97706 0%, #B45309 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
        }

        .gq-why-subtitle {
          font-size: 16px;
          color: #64748B;
          max-width: 680px;
          margin: 0 auto 60px;
          line-height: 1.7;
        }

        .gq-why-card {
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: 20px;
          padding: 0;
          height: 100%;
          display: flex;
          flex-direction: column;
          box-shadow: 0 4px 20px -4px rgba(15, 39, 68, 0.06);
          transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
          opacity: 0;
          transform: translateY(24px);
          overflow: hidden;
        }

        .gq-why-card.gq-revealed {
          opacity: 1;
          transform: translateY(0);
        }

        .gq-why-card:hover {
          transform: translateY(-8px);
          box-shadow: 0 20px 40px -10px rgba(15, 39, 68, 0.14);
          border-color: #CBD5E1;
        }

        .gq-why-img-container {
          position: relative;
          height: 180px;
          width: 100%;
          overflow: hidden;
          background: #0F2744;
        }

        .gq-why-img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          transition: transform 0.5s ease;
        }

        .gq-why-card:hover .gq-why-img {
          transform: scale(1.06);
        }

        .gq-why-img-overlay {
          position: absolute;
          inset: 0;
          background: linear-gradient(180deg, transparent 40%, rgba(15, 39, 68, 0.7) 100%);
        }

        .gq-why-card-content {
          padding: 24px 26px;
          display: flex;
          flex-direction: column;
          flex-grow: 1;
        }

        .gq-why-card-top {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 14px;
        }

        .gq-why-icon-wrap {
          width: 40px;
          height: 40px;
          border-radius: 10px;
          background: #EFF6FF;
          border: 1px solid #DBEAFE;
          color: #1D4ED8;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .gq-why-badge-pill {
          font-size: 11px;
          font-weight: 800;
          color: #B45309;
          background: #FEF3C7;
          border: 1px solid #FDE68A;
          padding: 4px 10px;
          border-radius: 999px;
          text-transform: uppercase;
          letter-spacing: 0.04em;
        }

        .gq-why-card-title {
          font-size: 18px;
          font-weight: 800;
          color: #0F2744;
          margin-bottom: 6px;
          line-height: 1.35;
        }

        .gq-why-card-tagline {
          font-size: 11.5px;
          font-weight: 800;
          color: #D97706;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          margin-bottom: 12px;
        }

        .gq-why-card-desc {
          font-size: 13.5px;
          color: #475569;
          line-height: 1.65;
          margin-bottom: 20px;
          flex-grow: 1;
        }

        .gq-why-metric-pill {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 6px 12px;
          border-radius: 8px;
          background: #F8FAFC;
          border: 1px solid #E2E8F0;
          font-size: 12px;
          font-weight: 700;
          color: #1E293B;
        }

        .gq-why-metric-pill span {
          color: #059669;
        }

        /* ── Comparison Matrix Box ── */
        .gq-compare-box {
          margin-top: 72px;
          background: #F8FAFC;
          border: 1px solid #E2E8F0;
          border-radius: 24px;
          padding: 44px 36px;
          box-shadow: 0 16px 40px rgba(15, 39, 68, 0.05);
          opacity: 0;
          transform: translateY(24px);
          transition: all 0.5s ease;
        }

        .gq-compare-box.gq-revealed {
          opacity: 1;
          transform: translateY(0);
        }

        .gq-compare-table {
          width: 100%;
          border-collapse: collapse;
          margin-top: 24px;
          background: #FFFFFF;
          border-radius: 14px;
          overflow: hidden;
          border: 1px solid #E2E8F0;
          box-shadow: 0 4px 16px rgba(15, 39, 68, 0.03);
        }

        .gq-compare-table th {
          padding: 16px 18px;
          font-size: 13px;
          font-weight: 800;
          text-transform: uppercase;
          letter-spacing: 0.06em;
          border-bottom: 1px solid #E2E8F0;
        }

        .gq-compare-table td {
          padding: 16px 18px;
          font-size: 13.5px;
          border-bottom: 1px solid #F1F5F9;
          vertical-align: middle;
        }

        .gq-compare-table tr:hover td {
          background: #F8FAFC;
        }
      `}),(0,N.jsx)(`section`,{id:`why-schoolprofit`,ref:e,className:`gq-why-section gq-scroll-reveal`,children:(0,N.jsxs)(`div`,{className:`container-xl`,children:[(0,N.jsxs)(`div`,{className:`text-center`,children:[(0,N.jsxs)(`div`,{className:`gq-why-kicker`,style:{background:`#DCFCE7`,color:`#065F46`,borderColor:`#86EFAC`},children:[(0,N.jsx)(`span`,{children:`🚀`}),` School Growth & Profit Engine`]}),(0,N.jsxs)(`h2`,{className:`gq-why-title`,children:[`Engineered for `,(0,N.jsx)(`em`,{children:`Profitable & High-Standard Private Schools`})]}),(0,N.jsx)(`p`,{className:`gq-why-subtitle`,children:`SchoolProfit delivers the complete financial and academic operating system that eliminates fee defaults, expands student enrollment, and automates teacher workflows.`})]}),(0,N.jsx)(`div`,{className:`row g-4`,children:Pe.map(e=>(0,N.jsx)(`div`,{className:`col-12 col-md-6 col-lg-4`,children:(0,N.jsxs)(`div`,{className:`gq-why-card`,children:[(0,N.jsxs)(`div`,{className:`gq-why-img-container`,children:[(0,N.jsx)(`img`,{src:e.image,alt:e.title,className:`gq-why-img`,loading:`lazy`}),(0,N.jsx)(`div`,{className:`gq-why-img-overlay`}),(0,N.jsx)(`div`,{className:`position-absolute bottom-0 start-0 p-3 text-white`,children:(0,N.jsxs)(`span`,{className:`badge bg-warning text-dark fw-bold px-2 py-1`,style:{fontSize:`10.5px`},children:[`Pillar `,e.number]})})]}),(0,N.jsxs)(`div`,{className:`gq-why-card-content`,children:[(0,N.jsxs)(`div`,{className:`gq-why-card-top`,children:[(0,N.jsx)(`div`,{className:`gq-why-icon-wrap`,children:e.icon}),(0,N.jsx)(`span`,{className:`gq-why-badge-pill`,children:e.badge})]}),(0,N.jsx)(`h3`,{className:`gq-why-card-title`,children:e.title}),(0,N.jsx)(`div`,{className:`gq-why-card-tagline`,children:e.tagline}),(0,N.jsx)(`p`,{className:`gq-why-card-desc`,children:e.description}),(0,N.jsx)(`div`,{children:(0,N.jsxs)(`span`,{className:`gq-why-metric-pill`,children:[(0,N.jsx)(`span`,{children:`●`}),` `,e.metrics]})})]})]})},e.number))}),(0,N.jsxs)(`div`,{className:`gq-compare-box`,children:[(0,N.jsxs)(`div`,{className:`text-center`,children:[(0,N.jsx)(`span`,{className:`gq-why-kicker`,style:{background:`#F0FDF4`,color:`#047857`,borderColor:`#BBF7D0`},children:`Operational Advantage`}),(0,N.jsx)(`h3`,{style:{fontFamily:`'Playfair Display', serif`,fontSize:28,fontWeight:800,color:`#0F2744`,marginTop:8,marginBottom:8},children:`SchoolProfit Platform vs. Traditional Portals`}),(0,N.jsx)(`p`,{style:{fontSize:14.5,color:`#64748B`,maxWidth:600,margin:`0 auto 20px`},children:`Experience the profit acceleration, automated fee recovery, and academic speed of an all-in-one operating platform.`})]}),(0,N.jsx)(`div`,{className:`table-responsive`,children:(0,N.jsxs)(`table`,{className:`gq-compare-table`,children:[(0,N.jsx)(`thead`,{children:(0,N.jsxs)(`tr`,{children:[(0,N.jsx)(`th`,{style:{color:`#475569`,width:`28%`,background:`#F8FAFC`},children:`Operational Dimension`}),(0,N.jsx)(`th`,{style:{color:`#DC2626`,width:`36%`,background:`#FEF2F2`},children:`Traditional Manual / Legacy Portals`}),(0,N.jsx)(`th`,{style:{color:`#047857`,width:`36%`,background:`#ECFDF5`},children:`SchoolProfit Operating System`})]})}),(0,N.jsx)(`tbody`,{children:Fe.map((e,t)=>(0,N.jsxs)(`tr`,{children:[(0,N.jsx)(`td`,{style:{fontWeight:700,color:`#0F2744`},children:e.feature}),(0,N.jsx)(`td`,{style:{color:`#64748B`},children:e.generic}),(0,N.jsx)(`td`,{style:{color:`#047857`,fontWeight:700,background:`rgba(220, 252, 231, 0.4)`},children:e.schoolprofit})]},t))})]})}),(0,N.jsx)(`div`,{className:`text-center mt-4 pt-2`,children:(0,N.jsxs)(o,{to:`/book-demo`,className:`gq-btn-cta-main`,style:{display:`inline-flex`,background:`linear-gradient(135deg, #059669 0%, #047857 100%)`},children:[`Book a Live Demo with SchoolProfit`,(0,N.jsx)(`svg`,{width:`15`,height:`15`,viewBox:`0 0 14 14`,fill:`none`,style:{marginLeft:8},children:(0,N.jsx)(`path`,{d:`M1 7h12M7 1l6 6-6 6`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`})})]})})]})]})})]})}var Le=[{id:991,title:`5 Proven Strategies to Achieve 95%+ School Fees Collection On Time`,slug:`proven-strategies-school-fees-collection`,category:`Fee Management`,excerpt:`Discover how automated WhatsApp billing reminders, installment plans, and instant Monnify/Paystack reconciliation help school owners recover unpaid term fees effortlessly.`,created_at:new Date(Date.now()-3*864e5).toISOString(),thumbnail_url:`/images/blog/blog-fees-collection.jpg`},{id:992,title:`How Offline CBT Exams Eliminate Paper Waste and Protect Academic Integrity`,slug:`offline-cbt-exams-school-management`,category:`CBT & Exams`,excerpt:`Transition your termly examinations to computer-based testing without needing expensive campus internet bandwidth or subscription downtime.`,created_at:new Date(Date.now()-7*864e5).toISOString(),thumbnail_url:`/images/blog/blog-cbt-exams.jpg`},{id:993,title:`Why High-Performing Schools Are Switching to Digital Report Cards & Scratch PINs`,slug:`digital-report-cards-scratch-pins-schools`,category:`Academic Operations`,excerpt:`Eliminate manual transcript errors and provide parents 24/7 online portal access with customizable, tamper-proof SchoolProfit result templates.`,created_at:new Date(Date.now()-12*864e5).toISOString(),thumbnail_url:`/images/blog/blog-digital-report-cards.jpg`}];function Re(){let[e,t]=(0,_.useState)([]),[n,r]=(0,_.useState)(!0);(0,_.useEffect)(()=>{(async()=>{try{let e=await J.get(`/frontend-blogs`);e.data?.status&&Array.isArray(e.data?.data)&&e.data.data.length>0?t(e.data.data.slice(0,3)):t(Le)}catch{t(Le)}finally{r(!1)}})()},[]);let i=e=>{if(!e)return`Recent`;let t=new Date(e);return Number.isNaN(t.getTime())?`Recent`:t.toLocaleDateString(`en-GB`,{day:`2-digit`,month:`short`,year:`numeric`})},a=e=>{let t=(e||``).toLowerCase();return t.includes(`fee`)?{bg:`#FEF3C7`,text:`#92400E`,border:`#FDE68A`}:t.includes(`cbt`)||t.includes(`exam`)?{bg:`#EFF6FF`,text:`#1E40AF`,border:`#BFDBFE`}:t.includes(`operat`)||t.includes(`acad`)?{bg:`#ECFDF5`,text:`#065F46`,border:`#A7F3D0`}:{bg:`#F3F4F6`,text:`#374151`,border:`#E5E7EB`}};return(0,N.jsxs)(N.Fragment,{children:[(0,N.jsx)(`style`,{children:`
        .gq-blog-sec {
          background: #FFFFFF;
          padding: 90px 20px;
          position: relative;
          overflow: hidden;
        }

        .gq-blog-sec::before {
          content: "";
          position: absolute;
          top: 0;
          left: 50%;
          transform: translateX(-50%);
          width: 80%;
          height: 1px;
          background: linear-gradient(90deg, transparent, #E2E8F0 20%, #E2E8F0 80%, transparent);
        }

        .gq-blog-kicker {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          background: #FEF3C7;
          border: 1px solid #FDE68A;
          color: #B45309;
          font-size: 11.5px;
          font-weight: 800;
          text-transform: uppercase;
          letter-spacing: 0.1em;
          padding: 5px 14px;
          border-radius: 999px;
          margin-bottom: 14px;
        }

        .gq-blog-title {
          font-family: 'Playfair Display', 'Lora', serif;
          font-size: 36px;
          font-weight: 800;
          color: #0F2744;
          letter-spacing: -0.02em;
          margin-bottom: 14px;
        }

        @media (max-width: 768px) {
          .gq-blog-title {
            font-size: 28px;
          }
        }

        .gq-blog-sub {
          font-size: 15.5px;
          color: #64748B;
          max-width: 650px;
          margin: 0 auto 50px auto;
          line-height: 1.6;
        }

        .gq-blog-card {
          background: #FFFFFF;
          border-radius: 18px;
          border: 1px solid #E2E8F0;
          box-shadow: 0 4px 20px -4px rgba(15, 39, 68, 0.05);
          display: flex;
          flex-direction: column;
          height: 100%;
          transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
          overflow: hidden;
          text-decoration: none;
        }

        .gq-blog-card:hover {
          transform: translateY(-6px);
          box-shadow: 0 16px 36px -8px rgba(15, 39, 68, 0.12);
          border-color: #CBD5E1;
        }

        .gq-blog-thumb-wrap {
          height: 200px;
          width: 100%;
          position: relative;
          background: linear-gradient(135deg, #0F2744 0%, #1E3A8A 100%);
          overflow: hidden;
        }

        .gq-blog-thumb-img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          transition: transform 0.4s ease;
        }

        .gq-blog-card:hover .gq-blog-thumb-img {
          transform: scale(1.05);
        }

        .gq-blog-thumb-fallback {
          width: 100%;
          height: 100%;
          display: flex;
          align-items: center;
          justify-content: center;
          color: #FBBF24;
          background: radial-gradient(circle at center, #1E3A8A 0%, #0F2744 100%);
        }

        .gq-blog-body {
          padding: 24px 24px 20px 24px;
          display: flex;
          flex-direction: column;
          flex-grow: 1;
        }

        .gq-blog-meta {
          display: flex;
          align-items: center;
          gap: 10px;
          margin-bottom: 12px;
          font-size: 12.5px;
          color: #94A3B8;
        }

        .gq-blog-cat-pill {
          font-size: 11px;
          font-weight: 800;
          text-transform: uppercase;
          letter-spacing: 0.04em;
          padding: 3px 10px;
          border-radius: 999px;
          border-width: 1px;
          border-style: solid;
        }

        .gq-blog-card-title {
          font-size: 18px;
          font-weight: 800;
          color: #0F2744;
          line-height: 1.4;
          margin-bottom: 12px;
          transition: color 0.2s ease;
        }

        .gq-blog-card:hover .gq-blog-card-title {
          color: #D97706;
        }

        .gq-blog-excerpt {
          font-size: 13.5px;
          line-height: 1.6;
          color: #64748B;
          flex-grow: 1;
          margin-bottom: 20px;
        }

        .gq-blog-footer {
          border-top: 1px solid #F1F5F9;
          padding-top: 14px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          font-size: 13px;
          font-weight: 700;
          color: #D97706;
        }

        .gq-blog-explore-box {
          background: linear-gradient(135deg, rgba(248, 250, 252, 0.9) 0%, rgba(241, 245, 249, 0.9) 100%);
          border: 1px dashed #CBD5E1;
          border-radius: 16px;
          padding: 22px 28px;
          margin-top: 48px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          flex-wrap: wrap;
          gap: 16px;
        }
      `}),(0,N.jsx)(`section`,{id:`blog`,className:`gq-blog-sec`,children:(0,N.jsxs)(`div`,{className:`container`,style:{maxWidth:`1140px`},children:[(0,N.jsxs)(`div`,{className:`text-center`,children:[(0,N.jsxs)(`div`,{className:`gq-blog-kicker`,children:[(0,N.jsx)(`i`,{className:`bi bi-journal-bookmark-fill`}),` Educational Insights & Updates`]}),(0,N.jsxs)(`h2`,{className:`gq-blog-title`,children:[`From Our Blog: `,(0,N.jsx)(`span`,{children:`Modern School Leadership`})]}),(0,N.jsx)(`p`,{className:`gq-blog-sub`,children:`Actionable insights, fee collection strategies, computerized examination techniques, and administrative best practices from the SchoolProfit team.`})]}),(0,N.jsx)(`div`,{className:`row g-4`,children:e.map(e=>{let t=a(e.category);return(0,N.jsx)(`div`,{className:`col-12 col-md-6 col-lg-4`,children:(0,N.jsxs)(o,{to:`/blog/${e.slug}`,className:`gq-blog-card`,children:[(0,N.jsx)(`div`,{className:`gq-blog-thumb-wrap`,children:e.thumbnail?(0,N.jsx)(`img`,{src:e.thumbnail_url||`/${e.thumbnail}`,alt:e.title,className:`gq-blog-thumb-img`,loading:`lazy`}):(0,N.jsx)(`div`,{className:`gq-blog-thumb-fallback`,children:(0,N.jsx)(`i`,{className:`bi bi-mortarboard fs-1 opacity-75`})})}),(0,N.jsxs)(`div`,{className:`gq-blog-body`,children:[(0,N.jsxs)(`div`,{className:`gq-blog-meta`,children:[(0,N.jsx)(`span`,{className:`gq-blog-cat-pill`,style:{background:t.bg,color:t.text,borderColor:t.border},children:e.category||`Insight`}),(0,N.jsx)(`span`,{children:`•`}),(0,N.jsx)(`span`,{children:i(e.created_at)})]}),(0,N.jsx)(`h3`,{className:`gq-blog-card-title`,children:e.title}),(0,N.jsx)(`p`,{className:`gq-blog-excerpt`,children:e.excerpt?e.excerpt.length>140?`${e.excerpt.slice(0,140)}…`:e.excerpt:`Explore key school management techniques and educational leadership strategies.`}),(0,N.jsxs)(`div`,{className:`gq-blog-footer`,children:[(0,N.jsx)(`span`,{children:`Read Full Article`}),(0,N.jsx)(`i`,{className:`bi bi-arrow-right`})]})]})]})},e.id)})}),(0,N.jsxs)(`div`,{className:`gq-blog-explore-box`,children:[(0,N.jsxs)(`div`,{className:`d-flex align-items-center gap-3`,children:[(0,N.jsx)(`div`,{style:{width:`44px`,height:`44px`,borderRadius:`10px`,background:`#0F2744`,color:`#FBBF24`,display:`flex`,alignItems:`center`,justifyContent:`center`,fontSize:`20px`,flexShrink:0},children:(0,N.jsx)(`i`,{className:`bi bi-envelope-check`})}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`h5`,{className:`mb-0 fw-bold text-dark`,style:{fontSize:`15px`},children:`Want new school management strategies delivered to your inbox?`}),(0,N.jsx)(`p`,{className:`mb-0 text-muted`,style:{fontSize:`13px`},children:`Subscribe in the footer below for monthly product updates and administrator toolkits.`})]})]}),(0,N.jsx)(`a`,{href:`#footer-subscribe`,className:`btn btn-dark fw-bold px-3.5 py-2 d-inline-flex align-items-center gap-2`,style:{borderRadius:`8px`,fontSize:`13px`},children:`Subscribe Below ↓`})]})]})})]})}function ze(){let{whatsappLink:e,platform:t}=Z(),[n,r]=(0,_.useState)({name:``,school_name:``,phone:``,email:``,location:``,message:``}),[i,a]=(0,_.useState)(!1),[o,s]=(0,_.useState)(!1),[c,l]=(0,_.useState)(``);return(0,N.jsxs)(N.Fragment,{children:[(0,N.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;0,900;1,700&family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap');

        .gq-contact-section {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #172554 100%);
          padding: 100px 0 110px;
          position: relative;
          overflow: hidden;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          color: #FFFFFF;
          border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        .gq-contact-section::before {
          content: '';
          position: absolute;
          inset: 0;
          background: radial-gradient(circle at 80% 20%, rgba(217, 119, 6, 0.12) 0%, transparent 60%),
                      radial-gradient(circle at 10% 90%, rgba(29, 78, 216, 0.15) 0%, transparent 60%);
          pointer-events: none;
        }

        .gq-contact-kicker {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          font-size: 12px;
          font-weight: 800;
          letter-spacing: 0.14em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(251, 191, 36, 0.15);
          border: 1px solid rgba(251, 191, 36, 0.35);
          border-radius: 999px;
          padding: 6px 18px;
          margin-bottom: 18px;
        }

        .gq-contact-title {
          font-family: 'Playfair Display', Georgia, serif;
          font-size: clamp(32px, 4vw, 50px);
          font-weight: 800;
          color: #FFFFFF;
          line-height: 1.2;
          margin-bottom: 18px;
        }

        .gq-contact-title em {
          font-style: italic;
          color: #FBBF24;
          background: linear-gradient(135deg, #FDE68A 0%, #F59E0B 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
        }

        .gq-contact-subtitle {
          font-size: 16px;
          line-height: 1.7;
          color: #E2E8F0;
          max-width: 580px;
          margin-bottom: 40px;
        }

        .gq-contact-card {
          background: rgba(255, 255, 255, 0.07);
          border: 1px solid rgba(255, 255, 255, 0.16);
          border-radius: 18px;
          padding: 24px;
          backdrop-filter: blur(12px);
          transition: all 0.25s ease;
          display: flex;
          align-items: flex-start;
          gap: 16px;
          margin-bottom: 18px;
          text-decoration: none;
          color: #FFFFFF;
        }

        .gq-contact-card:hover {
          background: rgba(255, 255, 255, 0.12);
          border-color: #FBBF24;
          transform: translateY(-3px);
          color: #FFFFFF;
        }

        .gq-contact-icon {
          width: 48px;
          height: 48px;
          border-radius: 12px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 22px;
          flex-shrink: 0;
        }

        .gq-contact-label {
          font-size: 12px;
          font-weight: 800;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          color: #FBBF24;
          margin-bottom: 4px;
        }

        .gq-contact-value {
          font-size: 16px;
          font-weight: 700;
          color: #FFFFFF;
          margin-bottom: 2px;
        }

        .gq-contact-desc {
          font-size: 13px;
          color: #CBD5E1;
          margin: 0;
        }

        /* ── Form Card ── */
        .gq-contact-form-box {
          background: #FFFFFF;
          border-radius: 24px;
          padding: 38px 34px;
          box-shadow: 0 20px 50px rgba(0, 0, 0, 0.35);
          color: #0F172A;
        }

        .gq-form-heading {
          font-size: 22px;
          font-weight: 800;
          color: #0F2744;
          margin-bottom: 6px;
        }

        .gq-form-subheading {
          font-size: 14px;
          color: #64748B;
          margin-bottom: 24px;
        }

        .gq-form-label {
          display: block;
          font-size: 13px;
          font-weight: 700;
          color: #1E293B;
          margin-bottom: 6px;
        }

        .gq-form-label span.req {
          color: #DC2626;
        }

        .gq-form-control {
          width: 100%;
          padding: 12px 16px;
          border: 1.5px solid #CBD5E1;
          border-radius: 10px;
          font-size: 14.5px;
          color: #0F172A;
          background: #F8FAFC;
          transition: all 0.2s ease;
          box-sizing: border-box;
        }

        .gq-form-control:focus {
          outline: none;
          background: #FFFFFF;
          border-color: #1D4ED8;
          box-shadow: 0 0 0 3.5px rgba(29, 78, 216, 0.14);
        }

        .gq-btn-contact-submit {
          width: 100%;
          background: linear-gradient(135deg, #0F2744 0%, #1E3A8A 100%);
          color: #FFFFFF;
          font-size: 15px;
          font-weight: 800;
          padding: 14px 20px;
          border-radius: 10px;
          border: none;
          cursor: pointer;
          transition: all 0.2s ease;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          box-shadow: 0 6px 18px rgba(15, 39, 68, 0.25);
        }

        .gq-btn-contact-submit:hover {
          background: linear-gradient(135deg, #1E3A8A 0%, #2563EB 100%);
          transform: translateY(-2px);
          box-shadow: 0 10px 24px rgba(30, 58, 138, 0.35);
          color: #FFFFFF;
        }

        .gq-contact-success {
          background: #ECFDF5;
          border: 1.5px solid #A7F3D0;
          border-radius: 14px;
          padding: 24px;
          text-align: center;
          color: #065F46;
        }
      `}),(0,N.jsx)(`section`,{id:`contact`,className:`gq-contact-section gq-scroll-reveal`,children:(0,N.jsx)(`div`,{className:`container-xl position-relative`,style:{zIndex:1},children:(0,N.jsxs)(`div`,{className:`row g-5 align-items-center`,children:[(0,N.jsxs)(`div`,{className:`col-12 col-lg-6`,children:[(0,N.jsxs)(`div`,{className:`gq-contact-kicker`,children:[(0,N.jsx)(`span`,{children:`📞`}),` Get In Touch With SchoolProfit`]}),(0,N.jsxs)(`h2`,{className:`gq-contact-title`,children:[`Ready to make your school profitable? `,(0,N.jsx)(`br`,{}),(0,N.jsx)(`em`,{children:`Let's talk today.`})]}),(0,N.jsx)(`p`,{className:`gq-contact-subtitle`,children:`Our school growth advisory team is available to guide school proprietors, principals, bursars, and ICT directors on smooth onboarding, fee debt elimination, and live system deployment.`}),(0,N.jsxs)(`div`,{className:`gq-contact-cards-wrap`,children:[(0,N.jsxs)(`a`,{href:e(`Hello SchoolProfit Team, I want to learn more about setting up our school on the platform.`),target:`_blank`,rel:`noopener noreferrer`,className:`gq-contact-card`,children:[(0,N.jsx)(`div`,{className:`gq-contact-icon`,style:{background:`rgba(34, 197, 94, 0.2)`,color:`#4ADE80`,border:`1px solid rgba(34, 197, 94, 0.4)`},children:(0,N.jsx)(`i`,{className:`bi bi-whatsapp`})}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`div`,{className:`gq-contact-label`,children:`Instant WhatsApp Hotline`}),(0,N.jsx)(`div`,{className:`gq-contact-value`,children:`Click to Chat on WhatsApp`}),(0,N.jsx)(`p`,{className:`gq-contact-desc`,children:`Immediate live response from dedicated school specialists.`})]})]}),(0,N.jsxs)(`a`,{href:`mailto:support@schoolprofit.ng`,className:`gq-contact-card`,children:[(0,N.jsx)(`div`,{className:`gq-contact-icon`,style:{background:`rgba(59, 130, 246, 0.2)`,color:`#60A5FA`,border:`1px solid rgba(59, 130, 246, 0.4)`},children:(0,N.jsx)(`i`,{className:`bi bi-envelope-fill`})}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`div`,{className:`gq-contact-label`,children:`Official Support Desk`}),(0,N.jsx)(`div`,{className:`gq-contact-value`,children:`support@schoolprofit.ng`}),(0,N.jsx)(`p`,{className:`gq-contact-desc`,children:`Official inquiries, security audits, and institutional contracts.`})]})]}),(0,N.jsxs)(`div`,{className:`gq-contact-card`,style:{cursor:`default`},children:[(0,N.jsx)(`div`,{className:`gq-contact-icon`,style:{background:`rgba(245, 158, 11, 0.2)`,color:`#FBBF24`,border:`1px solid rgba(245, 158, 11, 0.4)`},children:(0,N.jsx)(`i`,{className:`bi bi-clock-history`})}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`div`,{className:`gq-contact-label`,children:`Operational Hours`}),(0,N.jsx)(`div`,{className:`gq-contact-value`,children:`Monday – Saturday (8:00 AM – 7:00 PM)`}),(0,N.jsx)(`p`,{className:`gq-contact-desc`,children:`24/7 Automated Exam Server and Results Verification monitoring.`})]})]})]})]}),(0,N.jsx)(`div`,{className:`col-12 col-lg-6`,children:(0,N.jsx)(`div`,{className:`gq-contact-form-box`,children:o?(0,N.jsxs)(`div`,{className:`gq-contact-success`,children:[(0,N.jsx)(`div`,{style:{fontSize:`36px`,marginBottom:`10px`},children:`🎉`}),(0,N.jsx)(`h4`,{style:{fontWeight:800,color:`#065F46`,marginBottom:`8px`},children:`Enquiry Received Successfully!`}),(0,N.jsx)(`p`,{style:{fontSize:`14px`,color:`#047857`,marginBottom:`18px`},children:`Thank you for contacting SchoolProfit. A School Growth Consultant has received your request and will reach out to you within the hour.`}),(0,N.jsx)(`button`,{type:`button`,onClick:()=>s(!1),className:`btn btn-sm btn-outline-success fw-bold px-4 py-2`,style:{borderRadius:`8px`},children:`Send Another Message`})]}):(0,N.jsxs)(`form`,{onSubmit:async e=>{e.preventDefault(),l(``),a(!0);try{await J.post(`/frontend/demo-booking`,{contact_name:n.name,prospect_school_name:n.school_name,contact_phone:n.phone,contact_email:n.email,location:n.location,additional_notes:n.message,source:`homepage_contact_section`}),s(!0),r({name:``,school_name:``,phone:``,email:``,location:``,message:``})}catch(e){l(e?.response?.data?.message||`Unable to send message right now. Please message us directly on WhatsApp or call our support lines.`)}finally{a(!1)}},children:[(0,N.jsx)(`h3`,{className:`gq-form-heading`,children:`Send Us a Direct Message`}),(0,N.jsx)(`p`,{className:`gq-form-subheading`,children:`Fill out your institution details and we'll configure a tailored setup plan for you.`}),c&&(0,N.jsx)(`div`,{className:`alert alert-danger py-2 px-3 mb-3 fw-semibold`,style:{fontSize:`13px`},children:c}),(0,N.jsxs)(`div`,{className:`row g-3`,children:[(0,N.jsxs)(`div`,{className:`col-md-6`,children:[(0,N.jsxs)(`label`,{className:`gq-form-label`,children:[`Your Name `,(0,N.jsx)(`span`,{className:`req`,children:`*`})]}),(0,N.jsx)(`input`,{type:`text`,required:!0,value:n.name,onChange:e=>r({...n,name:e.target.value}),className:`gq-form-control`,placeholder:`e.g. Dr. Adesola Adeleke`})]}),(0,N.jsxs)(`div`,{className:`col-md-6`,children:[(0,N.jsxs)(`label`,{className:`gq-form-label`,children:[`School / Institution `,(0,N.jsx)(`span`,{className:`req`,children:`*`})]}),(0,N.jsx)(`input`,{type:`text`,required:!0,value:n.school_name,onChange:e=>r({...n,school_name:e.target.value}),className:`gq-form-control`,placeholder:`e.g. Kingsway College`})]}),(0,N.jsxs)(`div`,{className:`col-md-6`,children:[(0,N.jsxs)(`label`,{className:`gq-form-label`,children:[`Phone / WhatsApp Number `,(0,N.jsx)(`span`,{className:`req`,children:`*`})]}),(0,N.jsx)(`input`,{type:`tel`,required:!0,value:n.phone,onChange:e=>r({...n,phone:e.target.value}),className:`gq-form-control`,placeholder:`e.g. +234 812 000 0000`})]}),(0,N.jsxs)(`div`,{className:`col-md-6`,children:[(0,N.jsxs)(`label`,{className:`gq-form-label`,children:[`Email Address `,(0,N.jsx)(`span`,{className:`req`,children:`*`})]}),(0,N.jsx)(`input`,{type:`email`,required:!0,value:n.email,onChange:e=>r({...n,email:e.target.value}),className:`gq-form-control`,placeholder:`e.g. admin@school.com`})]}),(0,N.jsxs)(`div`,{className:`col-12`,children:[(0,N.jsx)(`label`,{className:`gq-form-label`,children:`City, State / Region`}),(0,N.jsx)(`input`,{type:`text`,value:n.location,onChange:e=>r({...n,location:e.target.value}),className:`gq-form-control`,placeholder:`e.g. Lagos, Abuja, Port Harcourt, Accra, Nairobi`})]}),(0,N.jsxs)(`div`,{className:`col-12`,children:[(0,N.jsx)(`label`,{className:`gq-form-label`,children:`How Can We Assist Your School?`}),(0,N.jsx)(`textarea`,{rows:3,value:n.message,onChange:e=>r({...n,message:e.target.value}),className:`gq-form-control`,placeholder:`Tell us about your student population, grading requirements, CBT exam lab, or fee collection needs...`})]}),(0,N.jsx)(`div`,{className:`col-12 mt-4`,children:(0,N.jsx)(`button`,{type:`submit`,disabled:i,className:`gq-btn-contact-submit`,children:i?(0,N.jsxs)(N.Fragment,{children:[(0,N.jsx)(`span`,{className:`spinner-border spinner-border-sm`,role:`status`,"aria-hidden":`true`}),`Submitting Enquiry...`]}):(0,N.jsxs)(N.Fragment,{children:[`Submit School Request`,(0,N.jsx)(`svg`,{width:`15`,height:`15`,viewBox:`0 0 14 14`,fill:`none`,children:(0,N.jsx)(`path`,{d:`M1 7h12M7 1l6 6-6 6`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`})})]})})})]})]})})})]})})})]})}function Be(){let[e,t]=(0,_.useState)(0),[n,r]=(0,_.useState)(!1),[i,a]=(0,_.useState)(null);(0,_.useEffect)(()=>{let e=()=>{let e=window.scrollY||document.documentElement.scrollTop,n=document.documentElement.scrollHeight-document.documentElement.clientHeight;n>0&&t(Math.min(100,Math.max(0,e/n*100))),r(e>320)};return window.addEventListener(`scroll`,e,{passive:!0}),e(),()=>window.removeEventListener(`scroll`,e)},[]);let o=()=>{window.scrollTo({top:0,behavior:`smooth`})},s=e=>{a(e.touches[0].clientY)},c=e=>{i!==null&&(i-e.changedTouches[0].clientY>40&&o(),a(null))},l=2*Math.PI*22,u=l-e/100*l;return(0,N.jsxs)(N.Fragment,{children:[(0,N.jsx)(`style`,{children:`
        .gq-swipe-up-container {
          position: fixed;
          bottom: 28px;
          right: 28px;
          z-index: 999;
          display: flex;
          align-items: center;
          gap: 10px;
          opacity: 0;
          visibility: hidden;
          transform: translateY(20px) scale(0.9);
          transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
        }

        .gq-swipe-up-container.visible {
          opacity: 1;
          visibility: visible;
          transform: translateY(0) scale(1);
        }

        .gq-swipe-up-btn {
          position: relative;
          width: 52px;
          height: 52px;
          border-radius: 50%;
          background: #0F2744;
          border: none;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          color: #FFFFFF;
          box-shadow: 0 10px 30px rgba(15, 39, 68, 0.35), 0 0 0 1px rgba(255, 255, 255, 0.15);
          transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1);
          user-select: none;
          outline: none;
        }

        .gq-swipe-up-btn:hover {
          transform: translateY(-4px) scale(1.06);
          box-shadow: 0 14px 36px rgba(15, 39, 68, 0.45), 0 0 20px rgba(217, 119, 6, 0.4);
          background: linear-gradient(135deg, #0F2744 0%, #1D4ED8 100%);
        }

        .gq-swipe-up-btn:active {
          transform: translateY(-1px) scale(0.96);
        }

        .gq-progress-svg {
          position: absolute;
          top: 0;
          left: 0;
          width: 52px;
          height: 52px;
          transform: rotate(-90deg);
          pointer-events: none;
        }

        .gq-progress-bg {
          fill: none;
          stroke: rgba(255, 255, 255, 0.12);
          stroke-width: 3.5;
        }

        .gq-progress-bar {
          fill: none;
          stroke: #F59E0B;
          stroke-width: 3.5;
          stroke-linecap: round;
          transition: stroke-dashoffset 0.15s ease;
        }

        .gq-arrow-icon {
          animation: gqArrowBounce 1.8s infinite ease-in-out;
          color: #FFFFFF;
          z-index: 2;
        }

        @keyframes gqArrowBounce {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-4px); }
        }

        /* Tooltip Pill */
        .gq-swipe-pill-label {
          background: rgba(15, 39, 68, 0.94);
          backdrop-filter: blur(8px);
          -webkit-backdrop-filter: blur(8px);
          color: #FFFFFF;
          font-family: 'Plus Jakarta Sans', sans-serif;
          font-size: 12px;
          font-weight: 700;
          padding: 6px 14px;
          border-radius: 999px;
          border: 1px solid rgba(255, 255, 255, 0.15);
          box-shadow: 0 4px 16px rgba(15, 39, 68, 0.2);
          display: flex;
          align-items: center;
          gap: 6px;
          cursor: pointer;
          transition: all 0.2s ease;
          letter-spacing: 0.02em;
        }

        .gq-swipe-pill-label:hover {
          background: #0F2744;
          border-color: #F59E0B;
          color: #FBBF24;
          transform: translateX(-2px);
        }

        @media (max-width: 576px) {
          .gq-swipe-up-container {
            bottom: 20px;
            right: 20px;
          }
          .gq-swipe-pill-label {
            display: none;
          }
        }
      `}),(0,N.jsxs)(`div`,{className:`gq-swipe-up-container ${n?`visible`:``}`,onTouchStart:s,onTouchEnd:c,children:[(0,N.jsxs)(`div`,{className:`gq-swipe-pill-label`,onClick:o,children:[(0,N.jsx)(`span`,{children:`⚡ Swipe Up`}),(0,N.jsxs)(`span`,{style:{color:`#F59E0B`,fontSize:`11px`},children:[Math.round(e),`%`]})]}),(0,N.jsxs)(`button`,{type:`button`,className:`gq-swipe-up-btn`,onClick:o,title:`Swipe up to top`,"aria-label":`Swipe up to top`,children:[(0,N.jsxs)(`svg`,{className:`gq-progress-svg`,viewBox:`0 0 52 52`,children:[(0,N.jsx)(`circle`,{className:`gq-progress-bg`,cx:`26`,cy:`26`,r:22}),(0,N.jsx)(`circle`,{className:`gq-progress-bar`,cx:`26`,cy:`26`,r:22,strokeDasharray:l,strokeDashoffset:u})]}),(0,N.jsx)(`svg`,{className:`gq-arrow-icon`,width:`18`,height:`18`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2.5`,strokeLinecap:`round`,strokeLinejoin:`round`,children:(0,N.jsx)(`polyline`,{points:`18 15 12 9 6 15`})})]})]})]})}var Ve=[`Opening SchoolProfit…`,`Preparing your experience…`,`Almost ready…`];function He(){let[e,t]=(0,_.useState)(0);return(0,_.useEffect)(()=>{let e=window.setInterval(()=>{t(e=>Math.min(e+1,Ve.length-1))},650);return()=>window.clearInterval(e)},[]),(0,N.jsx)(G,{eyebrow:`SchoolProfit platform`,message:Ve[e]})}function Ue(){let[e,t]=(0,_.useState)(!0);return(0,_.useEffect)(()=>{let e=setTimeout(()=>{t(!1)},1200);return()=>clearTimeout(e)},[]),(0,_.useEffect)(()=>{if(e)return;let t=new IntersectionObserver(e=>{e.forEach(e=>{e.isIntersecting?(e.target.classList.add(`gq-fade-in-active`),e.target.classList.remove(`gq-fade-out-active`)):e.boundingClientRect.top<0&&e.target.classList.add(`gq-fade-out-active`)})},{root:null,rootMargin:`0px 0px -60px 0px`,threshold:[.05,.2]});return document.querySelectorAll(`.gq-section-wrap, .gq-scroll-reveal`).forEach(e=>t.observe(e)),()=>t.disconnect()},[e]),e?(0,N.jsx)(He,{}):(0,N.jsxs)(N.Fragment,{children:[(0,N.jsx)(`style`,{children:`
        /* Global Fade-In / Fade-Out Animation Architecture */
        .gq-section-wrap,
        .gq-scroll-reveal {
          opacity: 0;
          transform: translateY(28px);
          transition: opacity 0.8s cubic-bezier(0.16, 1, 0.3, 1), transform 0.8s cubic-bezier(0.16, 1, 0.3, 1);
          will-change: opacity, transform;
        }

        .gq-section-wrap.gq-fade-in-active,
        .gq-scroll-reveal.gq-fade-in-active {
          opacity: 1;
          transform: translateY(0);
        }

        .gq-section-wrap.gq-fade-out-active,
        .gq-scroll-reveal.gq-fade-out-active {
          opacity: 0.92;
          transform: translateY(0);
        }

        /* Initial Hero Presentation */
        .gq-hero-wrap {
          opacity: 1 !important;
          transform: none !important;
          visibility: visible !important;
          display: block;
          position: relative;
          z-index: 1;
        }

        html {
          scroll-behavior: smooth;
        }
      `}),(0,N.jsx)(Se,{}),(0,N.jsx)(`div`,{className:`gq-hero-wrap`,children:(0,N.jsx)(Q,{})}),(0,N.jsx)(`div`,{className:`gq-section-wrap`,children:(0,N.jsx)(Ie,{})}),(0,N.jsx)(`div`,{className:`gq-section-wrap`,children:(0,N.jsx)(ye,{})}),(0,N.jsx)(`div`,{className:`gq-section-wrap`,children:(0,N.jsx)(Oe,{})}),(0,N.jsx)(`div`,{className:`gq-section-wrap`,children:(0,N.jsx)(Ce,{})}),(0,N.jsx)(`div`,{className:`gq-section-wrap`,children:(0,N.jsx)(Ne,{})}),(0,N.jsx)(`div`,{className:`gq-section-wrap`,children:(0,N.jsx)(Re,{})}),(0,N.jsx)(`div`,{className:`gq-section-wrap`,children:(0,N.jsx)(_e,{})}),(0,N.jsx)(`div`,{className:`gq-section-wrap`,children:(0,N.jsx)(ze,{})}),(0,N.jsx)(be,{}),(0,N.jsx)(Be,{})]})}function We(e){if(!e)return{score:0,label:``,color:`transparent`};let t=0;return e.length>=8&&t++,/[A-Z]/.test(e)&&t++,/[0-9]/.test(e)&&t++,/[^A-Za-z0-9]/.test(e)&&t++,{score:t,...[{label:`Too short`,color:`#EF4444`},{label:`Weak`,color:`#F97316`},{label:`Fair`,color:`#F59E0B`},{label:`Good`,color:`#10B981`},{label:`Strong`,color:`#059669`}][t]}}function Ge(){let e=d(),[t]=n(),r=(t.get(`ref`)||t.get(`code`)||t.get(`partner`)||t.get(`invitation`)||``).trim().toUpperCase(),[i,a]=(0,_.useState)(!0),[s,c]=(0,_.useState)(!1),[l,u]=(0,_.useState)(!1),[f,p]=(0,_.useState)(!1),[m,h]=(0,_.useState)(1),[g,v]=(0,_.useState)(r),[y,b]=(0,_.useState)(!!r),[x,S]=(0,_.useState)(``),[C,w]=(0,_.useState)(``),[T,D]=(0,_.useState)(!1),[O,A]=(0,_.useState)({school_name:``,firstname:``,surname:``,email:``,phone:``,address:``,password:``,password_confirmation:``,referral_code:r||null,invitation:t.get(`invitation`)||null}),[j,M]=(0,_.useState)({});(0,_.useEffect)(()=>{let e=window.setTimeout(()=>a(!1),600);return()=>window.clearTimeout(e)},[]);let P=We(O.password),F=!!(O.school_name.trim()&&O.address.trim()),I=!!(O.firstname.trim()&&O.surname.trim()&&O.phone.trim()),L=(0,_.useMemo)(()=>!!(F&&I&&O.password.length>=8&&O.password===O.password_confirmation),[F,I,O.password,O.password_confirmation]);function R(e,t){A(n=>({...n,[e]:t})),M(t=>({...t,[e]:void 0,general:void 0}))}function B(e){e.preventDefault();let t=x.trim().toUpperCase();if(!t){w(`Please enter a valid Referral or Invitation Code.`);return}v(t),R(`referral_code`,t),b(!0),w(``)}function V(e){let t={},n=e?.errors||{};return Object.keys(n).forEach(e=>{t[e]=Array.isArray(n[e])?n[e][0]:String(n[e])}),e?.message&&!Object.keys(t).length&&(t.general=e.message),t}async function ee(n){if(n.preventDefault(),!(!L||s)){c(!0),M({});try{let n={firstname:O.firstname.trim(),surname:O.surname.trim(),email:O.email?.trim()||null,phone:O.phone.trim(),school_name:O.school_name.trim(),address:O.address.trim(),password:O.password,password_confirmation:O.password_confirmation,referral_code:g||null,invitation:t.get(`invitation`)||null},r=await z.post(`/register`,n);E(r.data.token),k(r.data.user),e(`/dashboard`)}catch(e){let t=V(e?.response?.data);M(t),[`school_name`,`address`].some(e=>t[e])&&h(1)}finally{c(!1)}}}return i?(0,N.jsx)(He,{}):(0,N.jsxs)(N.Fragment,{children:[(0,N.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Playfair+Display:ital,wght@0,600;0,800;1,600&display=swap');

        :root {
          --gq-auth-navy: #0F2744;
          --gq-auth-gold: #D97706;
          --gq-auth-border: #E2E8F0;
          --gq-auth-bg: #F8FAFC;
        }

        .gq-auth-wrapper {
          min-height: 100vh;
          display: flex;
          background: var(--gq-auth-bg);
          font-family: 'Plus Jakarta Sans', sans-serif;
        }

        /* ── Left Visual Panel ── */
        .gq-auth-left {
          flex: 1;
          background: linear-gradient(145deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          padding: 48px;
          position: relative;
          overflow: hidden;
          color: #FFFFFF;
        }

        @media (max-width: 991px) {
          .gq-auth-left {
            display: none;
          }
        }

        .gq-auth-left-bg-art {
          position: absolute;
          inset: 0;
          background-image:
            radial-gradient(circle at 10% 20%, rgba(217, 119, 6, 0.15) 0%, transparent 40%),
            radial-gradient(circle at 90% 80%, rgba(29, 78, 216, 0.2) 0%, transparent 45%);
          pointer-events: none;
        }

        .gq-auth-brand-link {
          display: inline-flex;
          align-items: center;
          gap: 12px;
          text-decoration: none;
          z-index: 2;
        }

        .gq-auth-brand-logo {
          width: 40px;
          height: 40px;
          object-fit: contain;
          border-radius: 10px;
        }

        .gq-auth-brand-text {
          font-size: 22px;
          font-weight: 800;
          color: #FFFFFF;
          letter-spacing: -0.02em;
        }

        .gq-auth-left-content {
          position: relative;
          z-index: 2;
          max-width: 500px;
          margin: 40px 0;
        }

        .gq-auth-left-kicker {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 5px 14px;
          border-radius: 999px;
          background: rgba(217, 119, 6, 0.2);
          border: 1px solid rgba(217, 119, 6, 0.4);
          color: #FBBF24;
          font-size: 11.5px;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.06em;
          margin-bottom: 20px;
        }

        .gq-auth-left-title {
          font-family: 'Playfair Display', Georgia, serif;
          font-size: clamp(28px, 3vw, 40px);
          font-weight: 800;
          line-height: 1.2;
          color: #FFFFFF;
          margin-bottom: 16px;
        }

        .gq-auth-left-title em {
          font-style: italic;
          color: #F59E0B;
        }

        .gq-benefits-list {
          list-style: none;
          padding: 0;
          margin: 24px 0 0 0;
          display: flex;
          flex-direction: column;
          gap: 14px;
        }

        .gq-benefit-item {
          display: flex;
          align-items: center;
          gap: 12px;
          font-size: 14px;
          color: #E2E8F0;
        }

        .gq-benefit-icon {
          width: 28px;
          height: 28px;
          border-radius: 50%;
          background: rgba(16, 185, 129, 0.2);
          border: 1px solid rgba(16, 185, 129, 0.4);
          color: #34D399;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 13px;
          flex-shrink: 0;
        }

        .gq-auth-left-footer {
          position: relative;
          z-index: 2;
          display: flex;
          align-items: center;
          gap: 20px;
          font-size: 12px;
          color: #94A3B8;
        }

        /* ── Right Form Panel ── */
        .gq-auth-right {
          flex: 1;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 40px 24px;
        }

        .gq-auth-card {
          width: 100%;
          max-width: 500px;
          background: #FFFFFF;
          border: 1px solid var(--gq-auth-border);
          border-radius: 20px;
          padding: 36px 32px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.06);
        }

        .gq-auth-mobile-logo {
          display: none;
          align-items: center;
          gap: 10px;
          text-decoration: none;
          margin-bottom: 24px;
        }

        @media (max-width: 991px) {
          .gq-auth-mobile-logo {
            display: inline-flex;
          }
        }

        /* Step Progress Header */
        .gq-step-progress {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 24px;
          padding-bottom: 16px;
          border-bottom: 1px solid #F1F5F9;
        }

        .gq-step-item {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 13px;
          font-weight: 700;
          color: #94A3B8;
          cursor: pointer;
        }

        .gq-step-item.active {
          color: #0F2744;
        }

        .gq-step-num {
          width: 24px;
          height: 24px;
          border-radius: 50%;
          background: #F1F5F9;
          color: #64748B;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 12px;
          font-weight: 800;
        }

        .gq-step-item.active .gq-step-num {
          background: #0F2744;
          color: #FFFFFF;
        }

        .gq-form-title {
          font-size: 22px;
          font-weight: 800;
          color: #0F2744;
          margin-bottom: 6px;
        }

        .gq-form-subtitle {
          font-size: 13px;
          color: #64748B;
          line-height: 1.5;
          margin-bottom: 24px;
        }

        .gq-form-group {
          margin-bottom: 16px;
        }

        .gq-form-label {
          display: block;
          font-size: 12.5px;
          font-weight: 700;
          color: #1E293B;
          margin-bottom: 6px;
        }

        .gq-input-wrap {
          position: relative;
          display: flex;
          align-items: center;
        }

        .gq-input-icon {
          position: absolute;
          left: 14px;
          color: #94A3B8;
          font-size: 16px;
          pointer-events: none;
        }

        .gq-auth-input {
          width: 100%;
          height: 46px;
          background: #FFFFFF;
          border: 1.5px solid #E2E8F0;
          border-radius: 10px;
          padding: 0 14px 0 42px;
          font-family: inherit;
          font-size: 14px;
          color: #0F172A;
          outline: none;
          transition: all 0.2s ease;
        }

        .gq-auth-input:focus {
          border-color: #D97706;
          box-shadow: 0 0 0 3.5px rgba(217, 119, 6, 0.15);
        }

        .gq-auth-input::placeholder {
          color: #94A3B8;
          font-size: 13px;
        }

        .gq-btn-eye {
          position: absolute;
          right: 12px;
          background: none;
          border: none;
          color: #94A3B8;
          cursor: pointer;
          padding: 4px;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .gq-btn-eye:hover {
          color: #0F2744;
        }

        .gq-field-err {
          font-size: 11.5px;
          color: #EF4444;
          margin-top: 4px;
          display: flex;
          align-items: center;
          gap: 4px;
        }

        /* Password strength bar */
        .gq-strength-bar-wrap {
          margin-top: 6px;
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .gq-strength-track {
          flex: 1;
          height: 4px;
          background: #E2E8F0;
          border-radius: 999px;
          overflow: hidden;
        }

        .gq-strength-fill {
          height: 100%;
          transition: all 0.3s ease;
        }

        .gq-strength-label {
          font-size: 11px;
          font-weight: 700;
        }

        .gq-auth-btn-submit {
          width: 100%;
          height: 48px;
          background: #0F2744;
          color: #FFFFFF;
          font-family: inherit;
          font-size: 14px;
          font-weight: 700;
          border: none;
          border-radius: 10px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          transition: all 0.2s ease;
          box-shadow: 0 4px 14px rgba(15, 39, 68, 0.2);
          margin-top: 10px;
        }

        .gq-auth-btn-submit:hover:not(:disabled) {
          background: #1E3A8A;
          transform: translateY(-1px);
          box-shadow: 0 6px 18px rgba(30, 58, 138, 0.3);
        }

        .gq-auth-btn-submit:disabled {
          opacity: 0.7;
          cursor: not-allowed;
        }

        .gq-auth-error {
          background: #FEF2F2;
          border: 1px solid #FEE2E2;
          color: #B91C1C;
          border-radius: 8px;
          padding: 10px 14px;
          font-size: 12.5px;
          margin-bottom: 18px;
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .gq-auth-footer-links {
          margin-top: 24px;
          padding-top: 20px;
          border-top: 1px solid #F1F5F9;
          text-align: center;
          font-size: 13px;
          color: #64748B;
        }

        .gq-auth-footer-links a {
          color: #D97706;
          font-weight: 700;
          text-decoration: none;
        }

        .gq-auth-footer-links a:hover {
          text-decoration: underline;
        }
      `}),(0,N.jsx)(Y,{title:`Register Your School | SchoolProfit`}),(0,N.jsxs)(`div`,{className:`gq-auth-wrapper`,children:[(0,N.jsxs)(`div`,{className:`gq-auth-left`,children:[(0,N.jsx)(`div`,{className:`gq-auth-left-bg-art`}),(0,N.jsxs)(o,{to:`/`,className:`gq-auth-brand-link`,children:[(0,N.jsx)(`img`,{src:`/media/logo/schoolprofit-logo.svg`,alt:`SchoolProfit`,className:`gq-auth-brand-logo`,style:{width:`auto`,height:38}}),(0,N.jsxs)(`span`,{className:`gq-auth-brand-text`,children:[`School`,(0,N.jsx)(`span`,{style:{color:`#059669`},children:`Profit`})]})]}),(0,N.jsxs)(`div`,{className:`gq-auth-left-content`,children:[(0,N.jsxs)(`div`,{className:`gq-auth-left-kicker`,children:[(0,N.jsx)(`span`,{children:`🚀`}),` Start in Under 2 Minutes`]}),(0,N.jsxs)(`h1`,{className:`gq-auth-left-title`,children:[`Scale Your School with `,(0,N.jsx)(`em`,{children:`Total Financial & Academic Control.`})]}),(0,N.jsxs)(`ul`,{className:`gq-benefits-list`,children:[(0,N.jsxs)(`li`,{className:`gq-benefit-item`,children:[(0,N.jsx)(`span`,{className:`gq-benefit-icon`,children:`✓`}),(0,N.jsxs)(`span`,{children:[(0,N.jsx)(`strong`,{children:`Stop Fee Debts:`}),` Instant multi-bank collections, debt gatekeepers, and automated receipts.`]})]}),(0,N.jsxs)(`li`,{className:`gq-benefit-item`,children:[(0,N.jsx)(`span`,{className:`gq-benefit-icon`,children:`✓`}),(0,N.jsxs)(`span`,{children:[(0,N.jsx)(`strong`,{children:`Scale Admissions:`}),` Dedicated sales partner referral engine and student lead capture.`]})]}),(0,N.jsxs)(`li`,{className:`gq-benefit-item`,children:[(0,N.jsx)(`span`,{className:`gq-benefit-icon`,children:`✓`}),(0,N.jsxs)(`span`,{children:[(0,N.jsx)(`strong`,{children:`Instant Broadsheets:`}),` Automated cumulative GPAs, positions, and error-free result cards.`]})]}),(0,N.jsxs)(`li`,{className:`gq-benefit-item`,children:[(0,N.jsx)(`span`,{className:`gq-benefit-icon`,children:`✓`}),(0,N.jsxs)(`span`,{children:[(0,N.jsx)(`strong`,{children:`Hybrid CBT & AI:`}),` Offline computer lab examinations and instant AI lesson plans.`]})]})]})]}),(0,N.jsxs)(`div`,{className:`gq-auth-left-footer`,children:[(0,N.jsx)(`span`,{children:`🛡️ Free 30-Day Onboarding`}),(0,N.jsx)(`span`,{children:`● 0 Setup Fees`}),(0,N.jsx)(`span`,{children:`● Dedicated Growth Support`})]})]}),(0,N.jsx)(`div`,{className:`gq-auth-right`,children:(0,N.jsxs)(`div`,{className:`gq-auth-card`,children:[(0,N.jsxs)(o,{to:`/`,className:`gq-auth-mobile-logo`,children:[(0,N.jsx)(`img`,{src:`/media/logo/schoolprofit-icon.svg`,alt:`SchoolProfit`,style:{width:32,height:32}}),(0,N.jsxs)(`span`,{style:{fontSize:19,fontWeight:800,color:`#0F2744`},children:[`School`,(0,N.jsx)(`span`,{style:{color:`#059669`},children:`Profit`})]})]}),y?(0,N.jsxs)(N.Fragment,{children:[g&&(0,N.jsxs)(`div`,{style:{background:`#ECFDF5`,border:`1px solid #A7F3D0`,borderRadius:10,padding:`8px 12px`,marginBottom:14,display:`flex`,justifyContent:`space-between`,alignItems:`center`},children:[(0,N.jsxs)(`div`,{style:{fontSize:12,color:`#065F46`,fontWeight:700},children:[(0,N.jsx)(`i`,{className:`bi bi-check-circle-fill me-1 text-success`}),` Partner Referral: `,(0,N.jsx)(`strong`,{children:g})]}),(0,N.jsx)(`button`,{type:`button`,onClick:()=>{b(!1),v(``),R(`referral_code`,null)},style:{background:`transparent`,border:`none`,color:`#047857`,fontSize:11,fontWeight:800,cursor:`pointer`},children:`Change`})]}),(0,N.jsxs)(`div`,{className:`gq-step-progress`,children:[(0,N.jsxs)(`div`,{className:`gq-step-item ${m===1?`active`:``}`,onClick:()=>h(1),children:[(0,N.jsx)(`span`,{className:`gq-step-num`,children:`1`}),(0,N.jsx)(`span`,{children:`School Profile`})]}),(0,N.jsx)(`span`,{style:{color:`#CBD5E1`},children:`→`}),(0,N.jsxs)(`div`,{className:`gq-step-item ${m===2?`active`:``}`,onClick:()=>F&&h(2),children:[(0,N.jsx)(`span`,{className:`gq-step-num`,children:`2`}),(0,N.jsx)(`span`,{children:`Admin Account`})]})]}),j.general&&(0,N.jsxs)(`div`,{className:`gq-auth-error`,role:`alert`,children:[(0,N.jsx)(`i`,{className:`bi bi-exclamation-circle-fill`}),(0,N.jsx)(`span`,{children:j.general})]}),(0,N.jsxs)(`form`,{onSubmit:ee,noValidate:!0,children:[m===1&&(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`h2`,{className:`gq-form-title`,children:`Tell us about your school`}),(0,N.jsx)(`p`,{className:`gq-form-subtitle`,children:`Enter your institution name and operating location in Nigeria.`}),(0,N.jsxs)(`div`,{className:`gq-form-group`,children:[(0,N.jsx)(`label`,{className:`gq-form-label`,htmlFor:`school_name`,children:`Official School Name *`}),(0,N.jsxs)(`div`,{className:`gq-input-wrap`,children:[(0,N.jsx)(`span`,{className:`gq-input-icon`,children:(0,N.jsx)(`i`,{className:`bi bi-buildings`})}),(0,N.jsx)(`input`,{id:`school_name`,type:`text`,className:`gq-auth-input`,placeholder:`e.g. Samjane Arise and Shine Group of Schools`,value:O.school_name,onChange:e=>R(`school_name`,e.target.value),required:!0})]}),j.school_name&&(0,N.jsx)(`p`,{className:`gq-field-err`,children:j.school_name})]}),(0,N.jsxs)(`div`,{className:`gq-form-group`,children:[(0,N.jsx)(`label`,{className:`gq-form-label`,htmlFor:`address`,children:`School Address / State *`}),(0,N.jsxs)(`div`,{className:`gq-input-wrap`,children:[(0,N.jsx)(`span`,{className:`gq-input-icon`,children:(0,N.jsx)(`i`,{className:`bi bi-geo-alt`})}),(0,N.jsx)(`input`,{id:`address`,type:`text`,className:`gq-auth-input`,placeholder:`e.g. Badagry, Lagos State`,value:O.address,onChange:e=>R(`address`,e.target.value),required:!0})]}),j.address&&(0,N.jsx)(`p`,{className:`gq-field-err`,children:j.address})]}),(0,N.jsxs)(`button`,{type:`button`,className:`gq-auth-btn-submit`,disabled:!F,onClick:()=>h(2),children:[`Continue to Admin Setup`,(0,N.jsx)(`svg`,{width:`15`,height:`15`,viewBox:`0 0 14 14`,fill:`none`,children:(0,N.jsx)(`path`,{d:`M1 7h12M7 1l6 6-6 6`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`})})]})]}),m===2&&(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`h2`,{className:`gq-form-title`,children:`Create Admin Credentials`}),(0,N.jsx)(`p`,{className:`gq-form-subtitle`,children:`These details will be your primary login as the school proprietor / principal.`}),(0,N.jsxs)(`div`,{className:`row g-2 mb-3`,children:[(0,N.jsxs)(`div`,{className:`col-6`,children:[(0,N.jsx)(`label`,{className:`gq-form-label`,htmlFor:`firstname`,children:`First Name *`}),(0,N.jsx)(`input`,{id:`firstname`,type:`text`,className:`gq-auth-input`,style:{paddingLeft:14},placeholder:`e.g. Samuel`,value:O.firstname,onChange:e=>R(`firstname`,e.target.value),required:!0}),j.firstname&&(0,N.jsx)(`p`,{className:`gq-field-err`,children:j.firstname})]}),(0,N.jsxs)(`div`,{className:`col-6`,children:[(0,N.jsx)(`label`,{className:`gq-form-label`,htmlFor:`surname`,children:`Surname *`}),(0,N.jsx)(`input`,{id:`surname`,type:`text`,className:`gq-auth-input`,style:{paddingLeft:14},placeholder:`e.g. Adeyemi`,value:O.surname,onChange:e=>R(`surname`,e.target.value),required:!0}),j.surname&&(0,N.jsx)(`p`,{className:`gq-field-err`,children:j.surname})]})]}),(0,N.jsxs)(`div`,{className:`gq-form-group`,children:[(0,N.jsx)(`label`,{className:`gq-form-label`,htmlFor:`phone`,children:`Phone Number *`}),(0,N.jsxs)(`div`,{className:`gq-input-wrap`,children:[(0,N.jsx)(`span`,{className:`gq-input-icon`,children:(0,N.jsx)(`i`,{className:`bi bi-telephone`})}),(0,N.jsx)(`input`,{id:`phone`,type:`tel`,className:`gq-auth-input`,placeholder:`08012345678`,value:O.phone,onChange:e=>R(`phone`,e.target.value),required:!0})]}),j.phone&&(0,N.jsx)(`p`,{className:`gq-field-err`,children:j.phone})]}),(0,N.jsxs)(`div`,{className:`gq-form-group`,children:[(0,N.jsx)(`label`,{className:`gq-form-label`,htmlFor:`email`,children:`Email Address (Optional)`}),(0,N.jsxs)(`div`,{className:`gq-input-wrap`,children:[(0,N.jsx)(`span`,{className:`gq-input-icon`,children:(0,N.jsx)(`i`,{className:`bi bi-envelope`})}),(0,N.jsx)(`input`,{id:`email`,type:`email`,className:`gq-auth-input`,placeholder:`proprietor@school.com`,value:O.email||``,onChange:e=>R(`email`,e.target.value)})]}),j.email&&(0,N.jsx)(`p`,{className:`gq-field-err`,children:j.email})]}),(0,N.jsxs)(`div`,{className:`gq-form-group`,children:[(0,N.jsx)(`label`,{className:`gq-form-label`,htmlFor:`password`,children:`Password (Min 8 characters) *`}),(0,N.jsxs)(`div`,{className:`gq-input-wrap`,children:[(0,N.jsx)(`span`,{className:`gq-input-icon`,children:(0,N.jsx)(`i`,{className:`bi bi-lock`})}),(0,N.jsx)(`input`,{id:`password`,type:l?`text`:`password`,className:`gq-auth-input`,placeholder:`Create strong password`,value:O.password,onChange:e=>R(`password`,e.target.value),style:{paddingRight:40},required:!0}),(0,N.jsx)(`button`,{type:`button`,className:`gq-btn-eye`,onClick:()=>u(!l),children:(0,N.jsx)(`i`,{className:l?`bi bi-eye-slash`:`bi bi-eye`})})]}),O.password&&(0,N.jsxs)(`div`,{className:`gq-strength-bar-wrap`,children:[(0,N.jsx)(`div`,{className:`gq-strength-track`,children:(0,N.jsx)(`div`,{className:`gq-strength-fill`,style:{width:`${P.score/4*100}%`,backgroundColor:P.color}})}),(0,N.jsx)(`span`,{className:`gq-strength-label`,style:{color:P.color},children:P.label})]}),j.password&&(0,N.jsx)(`p`,{className:`gq-field-err`,children:j.password})]}),(0,N.jsxs)(`div`,{className:`gq-form-group`,children:[(0,N.jsx)(`label`,{className:`gq-form-label`,htmlFor:`password_confirmation`,children:`Confirm Password *`}),(0,N.jsxs)(`div`,{className:`gq-input-wrap`,children:[(0,N.jsx)(`span`,{className:`gq-input-icon`,children:(0,N.jsx)(`i`,{className:`bi bi-lock-fill`})}),(0,N.jsx)(`input`,{id:`password_confirmation`,type:f?`text`:`password`,className:`gq-auth-input`,placeholder:`Repeat your password`,value:O.password_confirmation,onChange:e=>R(`password_confirmation`,e.target.value),style:{paddingRight:40},required:!0}),(0,N.jsx)(`button`,{type:`button`,className:`gq-btn-eye`,onClick:()=>p(!f),children:(0,N.jsx)(`i`,{className:f?`bi bi-eye-slash`:`bi bi-eye`})})]}),O.password_confirmation&&O.password!==O.password_confirmation&&(0,N.jsx)(`p`,{className:`gq-field-err`,children:`Passwords do not match`})]}),(0,N.jsxs)(`div`,{className:`d-flex gap-2 mt-3`,children:[(0,N.jsx)(`button`,{type:`button`,className:`btn btn-outline-secondary`,style:{borderRadius:10,padding:`0 18px`,fontWeight:700},onClick:()=>h(1),children:`← Back`}),(0,N.jsx)(`button`,{type:`submit`,className:`gq-auth-btn-submit flex-grow-1`,style:{marginTop:0},disabled:!L||s,children:s?(0,N.jsxs)(N.Fragment,{children:[(0,N.jsx)(`span`,{className:`spinner-border spinner-border-sm`,role:`status`,"aria-hidden":`true`}),`Creating School...`]}):(0,N.jsxs)(N.Fragment,{children:[`Complete Registration`,(0,N.jsx)(`svg`,{width:`15`,height:`15`,viewBox:`0 0 14 14`,fill:`none`,children:(0,N.jsx)(`path`,{d:`M1 7h12M7 1l6 6-6 6`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`})})]})})]})]})]})]}):(0,N.jsxs)(`div`,{className:`gq-gate-card`,children:[(0,N.jsxs)(`div`,{style:{textAlign:`center`,marginBottom:20},children:[(0,N.jsxs)(`div`,{style:{display:`inline-flex`,alignItems:`center`,gap:6,background:`rgba(5, 150, 105, 0.1)`,color:`#047857`,padding:`5px 14px`,borderRadius:999,fontSize:11.5,fontWeight:800,textTransform:`uppercase`,letterSpacing:`0.06em`,marginBottom:12},children:[(0,N.jsx)(`i`,{className:`bi bi-shield-check`}),` Institutional Guided Setup`]}),(0,N.jsx)(`h2`,{className:`gq-form-title`,style:{fontSize:24,lineHeight:1.25,marginBottom:8},children:`School Onboarding is by Guided Demo & Invitation`}),(0,N.jsx)(`p`,{className:`gq-form-subtitle`,style:{fontSize:13.5,lineHeight:1.6,color:`#475569`,margin:`0 auto 18px`},children:`To ensure your school portal is configured with your official broadsheet grading templates, multi-bank split accounts, and teacher training, all new workspaces are provisioned following a quick 10-minute demonstration.`})]}),(0,N.jsxs)(`div`,{className:`d-grid gap-2 mb-4`,children:[(0,N.jsxs)(`button`,{type:`button`,className:`gq-auth-btn-submit`,style:{marginTop:0,padding:`14px 20px`,fontSize:15},onClick:()=>e(`/book-demo`),children:[(0,N.jsx)(`i`,{className:`bi bi-calendar-check me-2`}),` Book a Free 10-Minute Live Demo`]}),(0,N.jsxs)(`a`,{href:`https://wa.me/2348165748374?text=Hello%20SchoolProfit%2C%20I%20want%20to%20request%20guided%20onboarding%20for%20my%20school`,target:`_blank`,rel:`noreferrer`,className:`btn btn-outline-success`,style:{borderRadius:12,padding:`12px 18px`,fontWeight:700,fontSize:13.5,display:`inline-flex`,alignItems:`center`,justifyContent:`center`},children:[(0,N.jsx)(`i`,{className:`bi bi-whatsapp me-2`}),` Chat with School Onboarding Specialist`]})]}),(0,N.jsxs)(`div`,{style:{background:`#F8FAFC`,border:`1px solid #E2E8F0`,borderRadius:14,padding:`16px 18px`,marginTop:10},children:[(0,N.jsx)(`div`,{style:{fontSize:12.5,fontWeight:800,color:`#334155`,marginBottom:6},children:`Have a Sales Partner Referral Code or Admin Invite?`}),(0,N.jsxs)(`p`,{style:{fontSize:12,color:`#64748B`,marginBottom:12,lineHeight:1.5},children:[`Enter your certified Sales Representative code (e.g. `,(0,N.jsx)(`code`,{children:`REP-LAGOS-01`}),`) or invitation token to unlock registration immediately.`]}),(0,N.jsxs)(`form`,{onSubmit:B,children:[(0,N.jsxs)(`div`,{className:`input-group`,children:[(0,N.jsx)(`input`,{type:`text`,className:`form-control fw-bold`,style:{textTransform:`uppercase`,fontSize:13.5,borderColor:`#CBD5E1`},placeholder:`Enter Referral Code`,value:x,onChange:e=>{S(e.target.value),w(``)}}),(0,N.jsx)(`button`,{className:`btn btn-dark fw-bold px-3`,type:`submit`,style:{fontSize:13},children:`Unlock Form →`})]}),C&&(0,N.jsx)(`p`,{className:`gq-field-err mt-1`,children:C})]})]})]}),(0,N.jsxs)(`div`,{className:`gq-auth-footer-links`,children:[`Already have an active school account?`,` `,(0,N.jsx)(o,{to:`/login`,children:`Sign In Here`}),(0,N.jsxs)(`div`,{style:{marginTop:6,fontSize:`12px`},children:[`Looking to represent SchoolProfit in your state?`,` `,(0,N.jsx)(o,{to:`/sales-representative/register`,children:`Join as Sales Partner (Earn 30%)`})]})]})]})})]})]})}function Ke(e){let t=e?.data??e?.notifications??e;return Array.isArray(t)?t:[]}async function qe(){return Ke((await B.get(`/notifications`)).data)}async function Je(){return Ke((await B.get(`/notifications/all`)).data)}async function Ye(e){return(await B.post(`/notifications/read/${e}`)).data}function Xe(e){return e?.data??e?.notifications??e}function Ze(e){let t=e?.data??e?.notifications??e;return Array.isArray(t)?t:[]}async function Qe(){return Ze((await B.get(`/invoice-notifications/unread`)).data)}async function $e(){return Ze((await B.get(`/invoice-notifications`)).data)}async function et(e){return Xe((await B.get(`/invoice-notifications/${e}`)).data)}async function tt(e){await B.post(`/invoice-notifications/${e}/read`)}function nt(e){let t=(e||``).toLowerCase();return t===`paid`?{bg:`#dcfce7`,fg:`#16a34a`,icon:`bi-check-circle`}:t===`overdue`?{bg:`#fee2e2`,fg:`#dc2626`,icon:`bi-exclamation-octagon`}:{bg:`#fef3c7`,fg:`#d97706`,icon:`bi-receipt`}}function rt(e){return e.invoice??e.meta?.invoice??e.meta??{}}function it(e){let t=(e||`info`).toLowerCase();return t===`success`?{bg:`#dcfce7`,fg:`#16a34a`,icon:`bi-check-circle`}:t===`warning`?{bg:`#fef3c7`,fg:`#d97706`,icon:`bi-exclamation-triangle`}:t===`danger`||t===`error`?{bg:`#fee2e2`,fg:`#dc2626`,icon:`bi-x-circle`}:{bg:`#dbeafe`,fg:`#2563eb`,icon:`bi-info-circle`}}function at(e){return/^https?:\/\//i.test(e)}function ot(e){return Array.isArray(e)?e:[]}function st({sidebarOpen:e=!0,setSidebarOpen:t,toggleSidebar:n,onToggleSidebar:r,title:i}){let a=d(),[s,c]=(0,_.useState)(!1),[l,u]=(0,_.useState)([]),f=(0,_.useMemo)(()=>ot(l),[l]),p=(0,_.useMemo)(()=>f.length,[f]),m=async()=>{if(x){c(!0);try{u(ot(await Qe()))}catch{u([])}finally{c(!1)}}},h=async e=>{u(t=>ot(t).filter(t=>t.id!==e.id));try{await tt(e.id)}catch{u(t=>[e,...ot(t)].slice(0,10));return}a(`/invoice-notifications/${e.id}`)},[g,v]=(0,_.useState)(null),[y,b]=(0,_.useState)(!1),x=(g?.role||``)===`Parent`;(0,_.useEffect)(()=>{x&&m()},[x]);let[S,C]=(0,_.useState)(!1),[w,T]=(0,_.useState)([]),E=(0,_.useMemo)(()=>ot(w),[w]),D=(0,_.useMemo)(()=>E.length,[E]);(0,_.useEffect)(()=>{let e=A();e&&v(e)},[]),(0,_.useEffect)(()=>{b(!1)},[g?.photo_url]);let O=()=>{M()},k=e=>{if(!e)return`U`;let t=e.trim().split(` `);return t.length===1?t[0][0].toUpperCase():(t[0][0]+t[t.length-1][0]).toUpperCase()},j=()=>{b(!0)},P=async()=>{C(!0);try{T(ot(await qe()))}catch{T([])}finally{C(!1)}};(0,_.useEffect)(()=>{P()},[]);let F=async e=>{T(t=>ot(t).filter(t=>t.id!==e.id));try{await Ye(e.id)}catch{T(t=>[e,...ot(t)].slice(0,10));return}e.action_url&&(at(e.action_url)?window.open(e.action_url,`_blank`,`noopener,noreferrer`):a(e.action_url))},[I,L]=(0,_.useState)(null),[R,B]=(0,_.useState)(!1);return(0,_.useEffect)(()=>{z.get(`/platform-status`).then(e=>{(e.data?.maintenance_mode||e.data?.is_scheduled)&&L(e.data)}).catch(()=>{})},[]),(0,N.jsxs)(N.Fragment,{children:[I?.maintenance_mode&&!R&&(0,N.jsxs)(`div`,{style:{position:`fixed`,top:0,left:0,right:0,zIndex:1050,background:`linear-gradient(90deg, #9a3412 0%, #c2410c 100%)`,color:`#ffffff`,padding:`8px 20px`,fontSize:13,display:`flex`,alignItems:`center`,justifyContent:`space-between`,boxShadow:`0 2px 10px rgba(0,0,0,0.18)`},children:[(0,N.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:10,flexWrap:`wrap`},children:[(0,N.jsx)(`span`,{style:{background:`rgba(255,255,255,0.22)`,padding:`2px 8px`,borderRadius:4,fontWeight:800,fontSize:11,textTransform:`uppercase`},children:`Read-Only Mode`}),(0,N.jsxs)(`span`,{children:[(0,N.jsx)(`strong`,{children:`Platform Notice:`}),` `,I.message||`We are working harder to make things better, please hold on...`,` New entries, results publishing, CBT exams, and payments are temporarily paused.`]})]}),(0,N.jsx)(`button`,{onClick:()=>B(!0),style:{background:`none`,border:`none`,color:`#ffffff`,fontSize:18,cursor:`pointer`,opacity:.85,padding:`0 6px`},title:`Dismiss notice`,children:`×`})]}),(0,N.jsxs)(`nav`,{className:`navbar gq-topnav d-flex justify-content-between align-items-center`,children:[(0,N.jsxs)(`div`,{className:`d-flex align-items-center gap-3`,children:[(0,N.jsx)(`button`,{className:`gq-icon-btn d-md-none`,onClick:()=>{if(r)return r();if(n)return n();if(t)return t(!e)},type:`button`,children:(0,N.jsx)(`i`,{className:`bi bi-list fs-5`})}),(0,N.jsxs)(`div`,{className:`d-none d-md-block`,children:[(0,N.jsx)(`h5`,{className:`gq-topnav__title`,children:i??`Dashboard`}),(0,N.jsx)(`div`,{className:`gq-topnav__subtitle`,children:`SchoolProfit workspace`})]})]}),(0,N.jsxs)(`div`,{className:`d-flex align-items-center gap-2 gap-md-3`,children:[(0,N.jsxs)(`div`,{className:`dropdown`,children:[(0,N.jsxs)(`button`,{className:`gq-icon-btn position-relative`,"data-bs-toggle":`dropdown`,onClick:()=>P(),type:`button`,"aria-label":`Notifications`,children:[(0,N.jsx)(`i`,{className:`bi bi-bell`,style:{fontSize:`1.1rem`}}),D>0&&(0,N.jsx)(`span`,{className:`gq-badge-dot`,children:D>99?`99+`:D})]}),(0,N.jsxs)(`ul`,{className:`dropdown-menu dropdown-menu-end gq-dropdown mt-2`,style:{borderRadius:`12px`,minWidth:`320px`,maxHeight:`420px`,overflowY:`auto`},children:[(0,N.jsx)(`li`,{className:`gq-dropdown__header`,children:(0,N.jsxs)(`div`,{className:`d-flex justify-content-between align-items-center`,children:[(0,N.jsx)(`h6`,{className:`mb-0 fw-semibold`,style:{fontSize:`0.9rem`},children:`Notifications`}),(0,N.jsx)(`span`,{className:`badge`,style:{backgroundColor:`#dbeafe`,color:`#1e40af`,fontSize:`0.7rem`,padding:`4px 8px`},children:S?`...`:`${D} New`})]})}),S?(0,N.jsx)(`li`,{className:`px-3 py-3 text-muted`,style:{fontSize:`0.85rem`},children:`Loading...`}):E.length===0?(0,N.jsx)(`li`,{className:`px-3 py-3 text-muted`,style:{fontSize:`0.85rem`},children:`You have no unread notifications.`}):E.map(e=>{let t=it(e.type);return(0,N.jsx)(`li`,{children:(0,N.jsx)(`button`,{type:`button`,className:`dropdown-item py-3 gq-dropdown__item`,style:{borderBottom:`1px solid #f3f4f6`,transition:`background 0.2s ease`,whiteSpace:`normal`},onMouseEnter:e=>{e.currentTarget.style.background=`#f9fafb`},onMouseLeave:e=>{e.currentTarget.style.background=`transparent`},onClick:()=>F(e),children:(0,N.jsxs)(`div`,{className:`d-flex gap-3`,children:[(0,N.jsx)(`div`,{className:`rounded-circle d-flex align-items-center justify-content-center`,style:{width:`40px`,height:`40px`,backgroundColor:t.bg,flexShrink:0},children:(0,N.jsx)(`i`,{className:`bi ${t.icon}`,style:{color:t.fg}})}),(0,N.jsxs)(`div`,{style:{flex:1,minWidth:0},children:[(0,N.jsx)(`p`,{className:`mb-1 fw-semibold`,style:{fontSize:`0.85rem`,wordBreak:`break-word`},children:e.message}),(0,N.jsx)(`small`,{className:`text-muted`,style:{fontSize:`0.75rem`},children:e.time})]})]})})},e.id)}),(0,N.jsx)(`li`,{children:(0,N.jsx)(o,{className:`dropdown-item text-center py-2`,to:`/notifications`,style:{fontSize:`0.85rem`,fontWeight:500,color:`#6366f1`},children:`View all notifications`})})]})]}),x&&(0,N.jsxs)(`div`,{className:`dropdown`,children:[(0,N.jsxs)(`button`,{className:`gq-icon-btn position-relative`,"data-bs-toggle":`dropdown`,onClick:()=>m(),type:`button`,"aria-label":`Invoice notifications`,title:`Invoices`,children:[(0,N.jsx)(`i`,{className:`bi bi-receipt`,style:{fontSize:`1.1rem`}}),p>0&&(0,N.jsx)(`span`,{className:`gq-badge-dot`,style:{background:`var(--gq-warning)`},children:p>99?`99+`:p})]}),(0,N.jsxs)(`ul`,{className:`dropdown-menu dropdown-menu-end gq-dropdown mt-2`,style:{borderRadius:`12px`,minWidth:`340px`,maxHeight:`420px`,overflowY:`auto`},children:[(0,N.jsx)(`li`,{className:`gq-dropdown__header`,children:(0,N.jsxs)(`div`,{className:`d-flex justify-content-between align-items-center`,children:[(0,N.jsx)(`h6`,{className:`mb-0 fw-semibold`,style:{fontSize:`0.9rem`},children:`Invoices`}),(0,N.jsx)(`span`,{className:`badge`,style:{backgroundColor:`#fef3c7`,color:`#92400e`,fontSize:`0.7rem`,padding:`4px 8px`},children:s?`...`:`${p} New`})]})}),s?(0,N.jsx)(`li`,{className:`px-3 py-3 text-muted`,style:{fontSize:`0.85rem`},children:`Loading...`}):f.length===0?(0,N.jsx)(`li`,{className:`px-3 py-3 text-muted`,style:{fontSize:`0.85rem`},children:`No new invoice notifications.`}):f.map(e=>{let t=rt(e),n=nt(t?.status),r=t?.amount==null?``:`${t?.currency||`₦`}${t.amount}`,i=t?.invoice_no||t?.reference||t?.id||``;return(0,N.jsx)(`li`,{children:(0,N.jsx)(`button`,{type:`button`,className:`dropdown-item py-3 gq-dropdown__item`,style:{borderBottom:`1px solid #f3f4f6`,transition:`background 0.2s ease`,whiteSpace:`normal`},onMouseEnter:e=>e.currentTarget.style.background=`#f9fafb`,onMouseLeave:e=>e.currentTarget.style.background=`transparent`,onClick:()=>h(e),children:(0,N.jsxs)(`div`,{className:`d-flex gap-3`,children:[(0,N.jsx)(`div`,{className:`rounded-circle d-flex align-items-center justify-content-center`,style:{width:`40px`,height:`40px`,backgroundColor:n.bg,flexShrink:0},children:(0,N.jsx)(`i`,{className:`bi ${n.icon}`,style:{color:n.fg}})}),(0,N.jsxs)(`div`,{style:{flex:1,minWidth:0},children:[(0,N.jsx)(`p`,{className:`mb-1 fw-semibold`,style:{fontSize:`0.85rem`,wordBreak:`break-word`},children:e.message}),(0,N.jsxs)(`small`,{className:`text-muted`,style:{fontSize:`0.75rem`},children:[i?`Invoice: ${i} • `:``,r?`${r} • `:``,e.time||e.created_at||``]})]})]})})},e.id)}),(0,N.jsx)(`li`,{children:(0,N.jsx)(o,{className:`dropdown-item text-center py-2`,to:`/invoice-notifications`,style:{fontSize:`0.85rem`,fontWeight:500,color:`#d97706`},children:`View all invoices`})})]})]}),(0,N.jsxs)(`div`,{className:`dropdown`,children:[(0,N.jsxs)(`button`,{className:`gq-profile-btn d-flex align-items-center gap-2 px-2 px-md-3`,"data-bs-toggle":`dropdown`,type:`button`,children:[g?.photo_url&&!y?(0,N.jsx)(`img`,{src:g.photo_url,alt:g.firstname,className:`gq-avatar`,style:{width:32,height:32,objectFit:`cover`},onError:j}):(0,N.jsx)(`div`,{className:`gq-avatar`,children:g?k(g.firstname):`U`}),(0,N.jsx)(`span`,{className:`d-none d-md-inline fw-semibold`,style:{fontSize:`0.875rem`},children:g?.firstname||`User`}),(0,N.jsx)(`i`,{className:`bi bi-chevron-down d-none d-md-inline`,style:{fontSize:`0.75rem`}})]}),(0,N.jsxs)(`ul`,{className:`dropdown-menu dropdown-menu-end gq-dropdown mt-2`,style:{minWidth:`240px`},children:[(0,N.jsx)(`li`,{className:`gq-dropdown__header`,children:(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`p`,{className:`mb-0 fw-semibold`,style:{fontSize:`0.9rem`},children:g?.firstname||`User`}),(0,N.jsx)(`small`,{className:`text-muted`,style:{fontSize:`0.75rem`},children:g?.role||`User`}),(0,N.jsx)(`br`,{}),(0,N.jsx)(`small`,{className:`text-muted`,style:{fontSize:`0.7rem`},children:g?.email||`user@example.com`})]})}),(0,N.jsx)(`li`,{children:(0,N.jsxs)(o,{to:`/user/profile`,className:`dropdown-item py-2 d-flex align-items-center gap-2`,style:{fontSize:`0.85rem`,transition:`background 0.2s ease`},onMouseEnter:e=>{e.currentTarget.style.background=`#f9fafb`},onMouseLeave:e=>{e.currentTarget.style.background=`transparent`},children:[(0,N.jsx)(`i`,{className:`bi bi-person`}),`Profile Settings`]})}),(0,N.jsx)(`li`,{children:(0,N.jsx)(`hr`,{className:`dropdown-divider my-2`})}),(0,N.jsx)(`li`,{children:(0,N.jsxs)(`button`,{className:`dropdown-item py-2 d-flex align-items-center gap-2`,onClick:O,style:{fontSize:`0.85rem`,color:`#ef4444`,transition:`background 0.2s ease`},onMouseEnter:e=>{e.currentTarget.style.background=`#fef2f2`},onMouseLeave:e=>{e.currentTarget.style.background=`transparent`},children:[(0,N.jsx)(`i`,{className:`bi bi-box-arrow-right`}),`Logout`]})})]})]})]})]})]})}function ct({sidebarOpen:e,setSidebarOpen:t,isOpen:n,onClose:r}){let i=e??n??!1,o=A(),s=ne(),[c,l]=(0,_.useState)([]),[u,d]=(0,_.useState)(()=>localStorage.getItem(`gq_sidebar_collapsed`)===`1`),[f,p]=(0,_.useState)(()=>typeof window<`u`&&window.innerWidth<768),[m,h]=(0,_.useState)(!1),g=o?.school_identification_number||o?.identification_number||o?.reg_no||o?.school?.identification_number,v=e=>{let t=(e||``).toLowerCase().replace(/[\s-_]/g,``);return t===`admin`?`School ID`:t===`superadmin`||t===`platformstaff`?`Staff ID`:t===`salesrepresentative`||t===`salesrep`?`Rep ID`:t===`teacher`?`Staff ID`:t===`student`?`Student ID`:t===`parent`?`Parent ID`:t===`bursar`?`Staff ID`:`ID`},y=e=>{e&&(navigator.clipboard.writeText(e),h(!0),setTimeout(()=>h(!1),2e3))};(0,_.useEffect)(()=>{let e=()=>{p(window.innerWidth<768)};return window.addEventListener(`resize`,e),()=>window.removeEventListener(`resize`,e)},[]);let b=!f&&u;if((0,_.useEffect)(()=>(document.documentElement.classList.toggle(`gq-sidebar-collapsed`,b),localStorage.setItem(`gq_sidebar_collapsed`,u?`1`:`0`),()=>{document.documentElement.classList.remove(`gq-sidebar-collapsed`)}),[b,u]),!o)return null;let x=e=>{if(!e)return`S`;let t=e.split(` `);return t.length===1?t[0][0].toUpperCase():(t[0][0]+t[1][0]).toUpperCase()},S=(e,t)=>{t||l(t=>t.includes(e)?t.filter(t=>t!==e):[...t,e])},C=()=>{window.innerWidth<768&&(t?t(!1):r?.())},w=Array.isArray(o?.super_admin_permissions)?o.super_admin_permissions:[],T=e=>!e||w.includes(`all`)||w.includes(e);new Set([...Array.isArray(s.features)?s.features:[],...Array.isArray(o?.features)?o.features:[]].map(e=>typeof e==`string`?e:e?.feature_key||e?.key||``).filter(Boolean).map(e=>e.toLowerCase()));let E=e=>!1,D=()=>(0,N.jsx)(`span`,{className:`badge ms-2`,style:{background:`rgba(245, 158, 11, 0.2)`,border:`1px solid rgba(245, 158, 11, 0.35)`,color:`#fbbf24`,fontSize:`0.6rem`,padding:`2px 8px`,borderRadius:999,fontWeight:700,letterSpacing:`0.02em`},children:`Coming Soon`}),O=[{label:`Platform Command Center`,icon:`shield-lock`,href:`/dashboard`,roles:[`Super-Admin`,`Platform-Staff`]},{label:`Dashboard`,icon:`speedometer2`,href:`/dashboard`,roles:[`Admin`,`Teacher`,`Student`,`Parent`,`Bursar`,`Sales-Representative`]},{label:`Support`,icon:`life-preserver`,href:`/support`,roles:[`Admin`]},{label:`Hostel Management`,icon:`buildings`,href:`/hostels`,roles:[`Admin`],featureKey:`hostel_management`,hideIfNoFeature:!0},{label:`Transport Management`,icon:`bus-front`,href:`/transport`,roles:[`Admin`],featureKey:`transport_management`,hideIfNoFeature:!0},{label:`Support Desk`,icon:`headset`,href:`/superadmin/support`,roles:[`Super-Admin`,`Platform-Staff`],superAdminPermission:`support`},{label:`Students`,icon:`people`,collapseId:`studentsMenu`,children:[{label:`All Students`,href:`/students`,roles:[`Admin`]},{label:`Mark Attendance`,href:`/students/attendance`},{label:`Promote Students`,href:`/students/promote`,roles:[`Admin`]}],roles:[`Admin`,`Teacher`],featureKey:`support_student_management`,lockIfNoFeature:!0},{label:`Teachers`,icon:`people`,collapseId:`teachersMenu`,children:[{label:`All Teachers`,href:`/teachers`},{label:`Assign Subjects`,href:`/teacher-subjects`}],roles:[`Admin`],featureKey:`support_teacher_management`,lockIfNoFeature:!0},{label:`Parents`,icon:`people`,collapseId:`parentsMenu`,children:[{label:`All Parents`,href:`/parents`}],roles:[`Admin`],featureKey:`support_parent_management`,lockIfNoFeature:!0},{label:`School Operators`,icon:`person-badge`,collapseId:`operatorsMenu`,children:[{label:`All Operators`,href:`/school/operators`}],roles:[`Admin`]},{label:`Academics`,icon:`mortarboard`,collapseId:`academicsMenu`,children:[{label:`Classes`,href:`/levels`},{label:`Subjects`,href:`/subjects`},{label:`Sessions & Terms`,href:`/academics/calendar`},{label:`Departments`,href:`/departments`},{label:`Sections`,href:`/sections`}],roles:[`Admin`]},{label:`CBT`,icon:`pc-display-horizontal`,collapseId:`cbtMenu`,featureKey:`cbt_online`,lockIfNoFeature:!0,hideIfNoFeature:!0,children:[{label:`CBT Exams`,href:`/cbt/exams`,roles:[`Admin`,`Teacher`],featureKey:`cbt_online`,hideIfNoFeature:!0}],roles:[`Admin`,`Teacher`]},{label:`AI Lesson Planner`,icon:`journal-text`,href:`/settings/ai-lesson-plans`,roles:[`Admin`,`Teacher`],featureKey:`ai_lesson_plan_generator`,hideIfNoFeature:!0},{label:`AI Credits`,icon:`stars`,href:`/settings/ai-credits`,roles:[`Admin`,`Teacher`,`Bursar`],featureKey:`gradequest_plus`,hideIfNoFeature:!0},{label:`Fees`,icon:`cash`,collapseId:`feesMenu`,featureKey:`support_fee_management`,lockIfNoFeature:!0,children:[{label:`Fee Structure`,href:`/fees/structure`},{label:`Fee Assignments`,href:`/fees/methods`},{label:`Student Payments`,href:`/fees/payments`},{label:`Fee Policy & Installments`,href:`/fees/policy`},{label:`Receipt Approvals`,href:`/fees/receipts/approval`},{label:`Financial Records`,href:`/fees/report`},{label:`AI Fee Collection`,href:`/fees/ai-collection`,roles:[`Admin`,`Bursar`],featureKey:`ai_fee_collection_assistant`,hideIfNoFeature:!0}],roles:[`Admin`,`Bursar`]},{label:`Accounting Manager`,icon:`people`,collapseId:`accountMenu`,featureKey:`support_bursar_management`,lockIfNoFeature:!0,children:[{label:`Bursar`,href:`/bursar`}],roles:[`Admin`]},{label:`Staff Attendance`,icon:`calendar-check`,collapseId:`staffAttendanceMenu`,featureKey:`staff_attendance`,lockIfNoFeature:!0,hideIfNoFeature:!0,children:[{label:`Staff Attendance`,href:`/scan-qr`,roles:[`Admin`,`Teacher`]},{label:`Staff Attendance Logs`,href:`/attendance/logs`,roles:[`Admin`]},{label:`Attendance Settings`,href:`/attendance/settings`,roles:[`Admin`]}],roles:[`Admin`,`Teacher`]},{label:`Sales Workspace`,icon:`briefcase`,collapseId:`salesWorkspaceMenu`,children:[{label:`My Leads`,href:`/sales/leads`},{label:`Marketing Kit & Sales Page`,href:`/sales/marketing-kit`},{label:`My Commissions`,href:`/sales/commissions`},{label:`Payout Settings`,href:`/sales/payout-settings`}],roles:[`Sales-Representative`]},{label:`Subscribers & Billing`,icon:`cash`,collapseId:`billingMenu`,children:[{label:`Platform Staff`,href:`/superadmin/platform-staff`,superAdminPermission:`staff`},{label:`Subscribers`,href:`/superadmin/subscribers`,superAdminPermission:`billing`},{label:`Billing Policy & Bank Charges`,href:`/superadmin/billing-policy`,superAdminPermission:`billing`},{label:`Twilio WhatsApp`,href:`/superadmin/twilio-whatsapp`,superAdminPermission:`support`},{label:`Bookings`,href:`/demo-bookers`,superAdminPermission:`sales`}],roles:[`Super-Admin`,`Platform-Staff`]},{label:`Marketing`,icon:`megaphone`,collapseId:`marketingMenu`,children:[{label:`Sales Representatives`,href:`/superadmin/sales-representatives`,superAdminPermission:`sales`},{label:`Sales Leads`,href:`/superadmin/sales-leads`,superAdminPermission:`sales`},{label:`Marketing Materials`,href:`/superadmin/sales-marketing-materials`,superAdminPermission:`marketing`},{label:`Sales Payouts`,href:`/superadmin/sales-payouts`,superAdminPermission:`finance`},{label:`Newsletter Subscribers`,href:`/superadmin/newsletter-subscribers`,superAdminPermission:`marketing`},{label:`Broadcast`,href:`/superadmin/send-message`,superAdminPermission:`marketing`}],roles:[`Super-Admin`,`Platform-Staff`]},{label:`Media & Blogs`,icon:`file-earmark-richtext`,collapseId:`blogsMenu`,children:[{label:`Blogs`,href:`/blogs`,superAdminPermission:`content`}],roles:[`Super-Admin`,`Platform-Staff`]},{label:`Results`,icon:`file-earmark-text`,collapseId:`resultsMenu`,featureKey:`support_results_upload`,lockIfNoFeature:!0,children:[{label:`Search & Edit Result`,href:`/results/student-editor`,roles:[`Admin`,`Teacher`]},{label:`Prepare Term Results`,href:`/students/results/batch`,roles:[`Admin`]},{label:`Review Results`,href:`/results/review`,roles:[`Admin`]},{label:`Enter Student Scores`,href:`/students/results/add`,roles:[`Admin`,`Teacher`]},{label:`Monitor Results`,href:`/result/monitor`,roles:[`Admin`]},{label:`Result Design`,href:`/results/design`,roles:[`Admin`]},{label:`Generate PIN`,href:`/results/pins`,roles:[`Admin`]},{label:`Withdrawn Result Archive`,href:`/results/withdrawn-archive`,roles:[`Admin`]},{label:`Student Transcripts`,href:`/transcripts`,roles:[`Admin`]}],roles:[`Admin`,`Teacher`]},{label:`Reports`,icon:`bar-chart`,collapseId:`reportsMenu`,children:[{label:`Student Attendance Report`,href:`/students/report`}],roles:[`Admin`]},{label:`Wallet & Billing`,icon:`wallet2`,collapseId:`billingMenu_admin`,children:[{label:`Student Clearance`,href:`/billing`},{label:`Wallet & Credits`,href:`/wallet`}],roles:[`Admin`]},{label:`Settings`,icon:`gear`,collapseId:`settingsMenu`,children:[{label:`School Profile`,href:`/school/settings`},{label:`Bank Accounts`,href:`/school/bank-account-setting`},{label:`Result Deadline Setting`,href:`/results/deadlines`},{label:`WhatsApp Notification Settings`,href:`/settings/whatsapp`,featureKey:`gradequest_plus`,hideIfNoFeature:!0}],roles:[`Admin`]},{label:`Academics`,icon:`book`,collapseId:`studentAcademicsMenu`,children:[{label:`My Subjects`,href:`/student/my-subjects`},{label:`Lesson Notes`,href:`/student/lesson-notes`},{label:`My CBT Exams`,href:`/student/cbt/exams`,featureKey:`cbt_online`,hideIfNoFeature:!0}],roles:[`Student`]},{label:`Fees & Payments`,icon:`cash-stack`,collapseId:`studentFeesMenu`,featureKey:``,lockIfNoFeature:!0,children:[{label:`My Fees`,href:`/student/my-fees`,featureKey:`fees`}],roles:[`Student`]},{label:`My Children`,icon:`people`,collapseId:`parentChildrenMenu`,roles:[`Parent`],children:[{label:`All Children`,href:`/parent/children`}]},{label:`Attendance`,icon:`calendar-check`,collapseId:`parentAttendanceMenu`,roles:[`Parent`],children:[{label:`Attendance Report`,href:`/parent/attendance`},{label:`Absence History`,href:`/parent/attendance/history`}]},{label:`Fees & Payments`,icon:`cash-stack`,collapseId:`parentFeesMenu`,roles:[`Parent`],children:[{label:`Payment History`,href:`/parent/payments`,featureKey:`support_fee_management`},{label:`Upload Receipt`,href:`/parent/upload-receipt`,featureKey:`support_fee_management`}]},{label:`Communication`,icon:`chat-dots`,collapseId:`parentCommunicationMenu`,roles:[`Parent`],children:[{label:`Messages & Notices`,href:`/parent/messages`},{label:`Announcements`,href:`/parent/announcements`}]},{label:`School Information`,icon:`building`,collapseId:`parentSchoolMenu`,roles:[`Parent`],children:[{label:`Academic Calendar`,href:`/parent/calendar`},{label:`School Events`,href:`/parent/events`}]}];return(0,N.jsxs)(N.Fragment,{children:[(0,N.jsx)(`style`,{children:`
          .sidebar-scroll {
            overflow-y: auto;
            overflow-x: hidden;
            height: 100vh;
          }
          .sidebar-scroll::-webkit-scrollbar { width: 6px; }
          .sidebar-scroll::-webkit-scrollbar-track { background: #F8FAFC; }
          .sidebar-scroll::-webkit-scrollbar-thumb {
            background: #E2E8F0;
            border-radius: 10px;
          }
          .sidebar-scroll::-webkit-scrollbar-thumb:hover {
            background: #CBD5E1;
          }
          .gq-nav-text {
            display: inline-block !important;
            color: #1E293B !important;
            font-size: 13.5px !important;
            font-weight: 600 !important;
            opacity: 1 !important;
            visibility: visible !important;
          }
          .gq-nav-link, .gq-nav-btn {
            color: #1E293B !important;
          }
          .gq-nav-link.active .gq-nav-text, .gq-nav-btn.active .gq-nav-text {
            color: #0F2744 !important;
            font-weight: 700 !important;
          }
          .gq-submenu-link {
            color: #475569 !important;
            display: flex !important;
            align-items: center !important;
          }
          .gq-submenu-link.active {
            color: #B45309 !important;
            font-weight: 700 !important;
          }
          @media (max-width: 767.98px) {
            .gq-sidebar.sidebar,
            aside.sidebar.gq-sidebar {
              background: #FFFFFF !important;
              box-shadow: 0 0 30px rgba(15, 39, 68, 0.25) !important;
            }
            .gq-sidebar .gq-nav-text {
              display: inline-block !important;
              color: #1E293B !important;
              opacity: 1 !important;
              visibility: visible !important;
              font-size: 13.5px !important;
              font-weight: 600 !important;
            }
            .gq-sidebar .gq-nav-link, .gq-sidebar .gq-nav-btn {
              color: #1E293B !important;
            }
            .gq-sidebar .gq-submenu-link {
              color: #475569 !important;
            }
          }
        `}),i&&(0,N.jsx)(`div`,{className:`gq-sidebar-overlay d-md-none`,onClick:()=>t?.(!1),style:{position:`fixed`,top:0,left:0,right:0,bottom:0,zIndex:1040,transition:`opacity 0.3s ease`}}),(0,N.jsx)(`aside`,{className:`sidebar gq-sidebar ${i?`show`:``} ${b?`is-collapsed`:``}`,style:{minHeight:`100vh`,position:`fixed`,top:0,zIndex:1050,overflow:`hidden`},children:(0,N.jsx)(`div`,{className:`sidebar-scroll gq-sidebar-scroll`,children:(0,N.jsxs)(`div`,{children:[(0,N.jsxs)(`div`,{className:`d-flex justify-content-between align-items-center mb-3`,children:[(0,N.jsx)(`button`,{type:`button`,className:`gq-sidebar-collapse d-none d-md-inline-flex`,onClick:()=>d(e=>!e),title:b?`Open sidebar`:`Collapse sidebar`,"aria-label":b?`Open sidebar`:`Collapse sidebar`,children:(0,N.jsx)(`i`,{className:`bi bi-layout-sidebar${b?`-inset`:``}`})}),(0,N.jsx)(`button`,{className:`btn btn-sm d-md-none`,style:{background:`#F1F5F9`,color:`#0F2744`,border:`1px solid #E2E8F0`,borderRadius:`6px`},onClick:()=>{t?t(!1):r?.()},children:(0,N.jsx)(`i`,{className:`bi bi-x-lg`})})]}),(0,N.jsxs)(`div`,{className:`gq-sidebar__brand d-flex align-items-center`,children:[o.school?.logo?(0,N.jsx)(`img`,{src:o.school.logo,alt:o.school.name,className:`gq-sidebar__logo me-3`,style:{objectFit:`contain`},onError:e=>{e.target.style.display=`none`}}):(0,N.jsx)(`div`,{className:`gq-sidebar__logo gq-sidebar__initials me-3 d-flex align-items-center justify-content-center`,style:{fontWeight:800,fontSize:16},children:x(o.school?.name)}),(0,N.jsxs)(`div`,{style:{flex:1,minWidth:0},children:[(0,N.jsx)(`h6`,{className:`mb-0 text-truncate fw-bold`,title:o.school?.name,style:{fontSize:`0.92rem`,color:`#0F2744`,letterSpacing:`-0.01em`},children:o.school?.name||`My School`}),(0,N.jsx)(`small`,{className:`d-block text-truncate fw-semibold`,style:{color:`#64748B`,fontSize:`0.72rem`},children:o.role})]})]}),(0,N.jsx)(`div`,{className:`gq-sidebar__user position-relative overflow-hidden`,children:(0,N.jsxs)(`div`,{className:`d-flex align-items-center`,children:[(0,N.jsx)(`div`,{className:`gq-avatar me-3`,style:{flex:`0 0 auto`},children:o.name?.charAt(0).toUpperCase()||`U`}),(0,N.jsxs)(`div`,{style:{flex:1,minWidth:0},children:[(0,N.jsx)(`p`,{className:`mb-0 text-truncate fw-bold`,style:{fontSize:`0.85rem`,color:`#0F2744`},children:o.name||`User`}),(0,N.jsx)(`small`,{className:`text-truncate d-block`,style:{color:`#64748B`,fontSize:`0.7rem`},children:o.email||``})]})]})}),!b&&g&&(0,N.jsxs)(`div`,{className:`mt-2 mb-3 px-2 py-1 d-flex align-items-center justify-content-between`,style:{background:`rgba(15, 39, 68, 0.04)`,border:`1px solid rgba(15, 39, 68, 0.1)`,borderRadius:`8px`,fontSize:`0.75rem`},children:[(0,N.jsxs)(`div`,{className:`d-flex align-items-center gap-1 text-truncate`,style:{minWidth:0},children:[(0,N.jsx)(`i`,{className:`bi bi-person-badge text-primary`,style:{fontSize:`0.82rem`}}),(0,N.jsxs)(`span`,{className:`fw-semibold text-muted`,style:{fontSize:`0.68rem`},children:[v(o.role),`:`]}),(0,N.jsx)(`span`,{className:`fw-bold font-monospace text-dark text-truncate`,style:{letterSpacing:`0.5px`},children:g})]}),(0,N.jsx)(`button`,{type:`button`,onClick:()=>y(String(g)),title:`Copy ID`,className:`btn btn-link p-0 text-muted ms-1 text-decoration-none`,style:{fontSize:`0.78rem`,lineHeight:1},children:(0,N.jsx)(`i`,{className:`bi ${m?`bi-check2 text-success fw-bold`:`bi-clipboard`}`})})]}),(0,N.jsx)(`div`,{className:`mb-3`,children:(0,N.jsx)(`small`,{className:`gq-sidebar__label`,children:`Navigation`})}),(0,N.jsx)(`ul`,{className:`nav flex-column gap-1`,children:O.filter(e=>{let t=(o.role||``).toLowerCase(),n=t===`operator`;return!(e.roles.some(e=>e.toLowerCase()===t)||n&&e.roles.some(e=>e.toLowerCase()===`admin`)&&e.collapseId!==`billingMenu_admin`&&e.collapseId!==`settingsMenu`&&e.collapseId!==`operatorsMenu`)||!T(e.superAdminPermission)||E(e)?!1:e.children?e.children.some(e=>(!e.roles||e.roles.some(e=>e.toLowerCase()===t)||n&&e.roles.some(e=>e.toLowerCase()===`admin`))&&T(e.superAdminPermission)&&!E(e)):!0}).map(e=>{let t=e.disabled;return(0,N.jsx)(`li`,{children:e.children?(0,N.jsxs)(N.Fragment,{children:[(0,N.jsxs)(`button`,{className:`gq-nav-btn nav-link btn text-start justify-content-between`,onClick:()=>S(e.collapseId,t),disabled:t,title:b?e.label:void 0,style:{border:`none`,color:t?`#94A3B8`:`#334155`,cursor:t?`not-allowed`:`pointer`,opacity:t?.8:1},children:[(0,N.jsxs)(`span`,{className:`d-flex align-items-center gap-2`,children:[(0,N.jsx)(`span`,{className:`gq-nav-icon`,children:(0,N.jsx)(`i`,{className:`bi bi-${e.icon}`})}),(0,N.jsx)(`span`,{className:`gq-nav-text`,style:{color:t?`#94A3B8`:`#1E293B`,fontSize:`13.5px`,fontWeight:600},children:e.label}),e.comingSoon&&(0,N.jsx)(D,{}),e.badge&&(0,N.jsx)(`span`,{className:`badge`,style:{backgroundColor:`#10B981`,fontSize:`0.6rem`,padding:`2px 6px`},children:e.badge})]}),!t&&!b&&(0,N.jsx)(`i`,{className:`bi bi-chevron-${c.includes(e.collapseId)?`down`:`right`}`,style:{fontSize:`0.75rem`,transition:`transform 0.2s ease`,color:`#94A3B8`}})]}),!t&&(0,N.jsx)(`div`,{className:`gq-submenu ${c.includes(e.collapseId)?`is-open`:``}`,children:(0,N.jsx)(`div`,{className:`mt-1 mb-2`,children:e.children.filter(e=>{let t=(o.role||``).toLowerCase(),n=t===`operator`;return(!e.roles||e.roles.some(e=>e.toLowerCase()===t)||n&&e.roles.some(e=>e.toLowerCase()===`admin`))&&T(e.superAdminPermission)&&!E(e)}).map(e=>(0,N.jsxs)(a,{to:e.href,onClick:C,className:({isActive:e})=>`gq-submenu-link nav-link ${e?`active`:``}`,style:({isActive:e})=>({color:e?`#B45309`:`#475569`,fontWeight:e?700:550,display:`flex`,alignItems:`center`,gap:`8px`}),children:[(0,N.jsx)(`span`,{style:{width:`5px`,height:`5px`,borderRadius:`50%`,backgroundColor:`currentColor`,opacity:.7}}),e.label]},e.label))})})]}):(0,N.jsxs)(a,{to:e.href,onClick:C,className:({isActive:e})=>`gq-nav-link nav-link ${e?`active`:``}`,title:b?e.label:void 0,style:({isActive:e})=>({fontWeight:e?700:600,color:e?`#0F2744`:`#1E293B`}),children:[(0,N.jsx)(`span`,{className:`gq-nav-icon`,children:(0,N.jsx)(`i`,{className:`bi bi-${e.icon}`})}),(0,N.jsx)(`span`,{className:`gq-nav-text`,style:{color:`#1E293B`,fontSize:`13.5px`,fontWeight:600},children:e.label}),e.badge&&(0,N.jsx)(`span`,{className:`badge ms-auto`,style:{backgroundColor:`#10B981`,fontSize:`0.6rem`,padding:`2px 6px`},children:e.badge})]})},e.label)})}),(0,N.jsx)(`div`,{className:`mt-4 pt-4`,style:{borderTop:`1px solid #E2E8F0`},children:(0,N.jsxs)(`div`,{className:`d-flex align-items-center justify-content-between`,children:[(0,N.jsx)(`small`,{style:{color:`#94A3B8`,fontSize:`0.72rem`,fontWeight:600},children:`SchoolProfit v2.1`}),(0,N.jsxs)(`div`,{className:`d-flex align-items-center gap-1.5`,children:[(0,N.jsx)(`i`,{className:`bi bi-shield-check`,style:{color:`#10B981`,fontSize:`0.85rem`}}),(0,N.jsx)(`small`,{style:{color:`#10B981`,fontSize:`0.72rem`,fontWeight:700},children:`Secured`})]})]})})]})})})]})}function lt(){return(0,N.jsx)(`footer`,{className:`gq-footer d-flex align-items-center justify-content-center`,children:(0,N.jsxs)(`span`,{children:[`(c) `,new Date().getFullYear(),` `,(0,N.jsx)(`strong`,{children:`SchoolProfit`}),` - Smart School Management System`]})})}var ut=[{color:`#10B981`,bg:`rgba(16, 185, 129, 0.12)`,label:`enrolled`},{color:`#2563EB`,bg:`rgba(37, 99, 235, 0.12)`,label:`active staff`},{color:`#7C3AED`,bg:`rgba(124, 58, 237, 0.12)`,label:`registered`},{color:`#D97706`,bg:`rgba(217, 119, 6, 0.12)`,label:`completion`}],dt=[{label:`Search & Edit Result`,desc:`Lookup student by Reg No`,color:`#D97706`,bg:`rgba(217, 119, 6, 0.12)`,path:`/results/student-editor`,icon:(0,N.jsx)(`i`,{className:`bi bi-pencil-square`})},{label:`Register Student`,desc:`Enroll a new student`,color:`#10B981`,bg:`rgba(16, 185, 129, 0.12)`,path:`/students/register`,icon:(0,N.jsx)(`i`,{className:`bi bi-person-plus-fill`})},{label:`Upload Results`,desc:`Record continuous assessment`,color:`#D97706`,bg:`rgba(217, 119, 6, 0.12)`,path:`/students/results/add`,icon:(0,N.jsx)(`i`,{className:`bi bi-cloud-arrow-up-fill`})},{label:`Generate PINs`,desc:`Create result scratch cards`,color:`#2563EB`,bg:`rgba(37, 99, 235, 0.12)`,path:`/results/pins`,icon:(0,N.jsx)(`i`,{className:`bi bi-key-fill`})},{label:`School Settings`,desc:`Profile & academic setup`,color:`#EF4444`,bg:`rgba(239, 68, 68, 0.12)`,path:`/school/settings`,icon:(0,N.jsx)(`i`,{className:`bi bi-gear-fill`})},{label:`Master Broadsheet`,desc:`Class & subject sheets`,color:`#6366F1`,bg:`rgba(99, 102, 241, 0.12)`,path:`/results/review`,icon:(0,N.jsx)(`i`,{className:`bi bi-file-earmark-spreadsheet-fill`})}];function ft(){let e=new Date().getHours();return e<12?`Good morning`:e<17?`Good afternoon`:`Good evening`}function pt(e){if(!e)return``;let t=Date.now()-new Date(e).getTime(),n=Math.floor(t/6e4);if(n<1)return`just now`;if(n<60)return`${n}m ago`;let r=Math.floor(n/60);return r<24?`${r}h ago`:`${Math.floor(r/24)}d ago`}function mt(e){let t=String(e||``).toLowerCase();return t===`draft`?`In Progress`:t===`computed`?`Ready for Review`:t===`approved`?`Approved`:t===`published`?`Published`:`Needs Review`}function ht(e){let t=String(e||``).toLowerCase();return t===`published`?`published`:t===`approved`?`approved`:t===`computed`?`computed`:`draft`}function gt({batches:e,loading:t,busyId:n,error:r,onRefresh:i,onApprove:a,onPublish:o,onReopen:s,onOpenBroadsheet:c}){let l=e.filter(e=>String(e.status).toLowerCase()!==`published`).length;return(0,N.jsxs)(`div`,{className:`rrq-panel`,children:[(0,N.jsxs)(`div`,{className:`rrq-head`,children:[(0,N.jsxs)(`div`,{className:`rrq-title-wrap`,children:[(0,N.jsx)(`div`,{className:`rrq-icon`,children:(0,N.jsx)(`i`,{className:`bi bi-clipboard-check-fill`})}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`h2`,{className:`rrq-title`,children:`Results Approval Queue`}),(0,N.jsx)(`p`,{className:`rrq-sub`,children:`Class result batches submitted by teachers awaiting administrative verification.`})]})]}),(0,N.jsxs)(`div`,{className:`rrq-head-actions`,children:[(0,N.jsxs)(`span`,{className:`rrq-count`,children:[l,` waiting`]}),(0,N.jsxs)(`button`,{className:`db-refresh-btn`,onClick:i,disabled:t,children:[(0,N.jsx)(`i`,{className:`bi bi-arrow-clockwise ${t?`rrq-spin`:``}`}),t?`Refreshing...`:`Refresh`]})]})]}),(0,N.jsx)(`div`,{className:`rrq-body`,children:t&&e.length===0?[0,1,2].map(e=>(0,N.jsxs)(`div`,{className:`rrq-card`,children:[(0,N.jsx)(`div`,{className:`rm-skel rm-skel--title`,style:{width:`40%`}}),(0,N.jsx)(`div`,{className:`rm-skel rm-skel--sub mt-2`,style:{width:`70%`}}),(0,N.jsx)(`div`,{className:`rm-skel mt-3`,style:{width:`100%`,height:8}})]},e)):e.length===0?(0,N.jsxs)(`div`,{className:`rrq-empty`,children:[(0,N.jsx)(`i`,{className:`bi bi-check2-circle text-success`}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`p`,{children:`No results currently pending review.`}),(0,N.jsx)(`span`,{children:`Submitted score batches from class teachers will automatically appear here.`})]})]}):e.map(e=>{let t=e.review,r=Number(t?.total_students||0),i=Number(t?.completed_students||0),l=r>0?Math.min(100,Math.round(i/r*100)):0,u=ht(e.status),d=n===e.id,f=String(e.status).toLowerCase(),p=!!(t?.can_approve&&f!==`approved`&&f!==`published`),m=!!(t?.can_publish&&f!==`published`);return(0,N.jsxs)(`div`,{className:`rrq-card`,children:[(0,N.jsxs)(`div`,{className:`rrq-card-top`,children:[(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`div`,{className:`rrq-class`,children:e.class_name}),(0,N.jsxs)(`div`,{className:`rrq-meta`,children:[e.term,` · `,e.session,` · `,pt(e.updated_at)]})]}),(0,N.jsx)(`span`,{className:`rrq-badge rrq-badge--${u}`,children:mt(e.status)})]}),(0,N.jsx)(`p`,{className:`rrq-status-text`,children:t?.simple_status||`Open batch to verify scores and compute broadsheet.`}),(0,N.jsxs)(`div`,{className:`rrq-progress-row`,children:[(0,N.jsxs)(`span`,{children:[i,`/`,r,` students complete`]}),(0,N.jsxs)(`span`,{children:[l,`%`]})]}),(0,N.jsx)(`div`,{className:`rrq-track`,children:(0,N.jsx)(`div`,{className:`rrq-fill`,style:{width:`${l}%`}})}),(0,N.jsxs)(`div`,{className:`rrq-notes`,children:[Number(t?.missing_students_count||0)>0&&(0,N.jsxs)(`span`,{children:[(0,N.jsx)(`i`,{className:`bi bi-person-dash`}),t?.missing_students_count,` missing`]}),Number(t?.open_high_alerts||0)>0&&(0,N.jsxs)(`span`,{className:`rrq-note-danger`,children:[(0,N.jsx)(`i`,{className:`bi bi-exclamation-triangle`}),t?.open_high_alerts,` alerts`]}),t?.can_approve&&(0,N.jsxs)(`span`,{className:`rrq-note-good`,children:[(0,N.jsx)(`i`,{className:`bi bi-check-circle`}),`Ready`]})]}),(0,N.jsxs)(`div`,{className:`rrq-actions`,children:[(0,N.jsx)(`button`,{className:`rrq-btn rrq-btn-light`,onClick:()=>c(e),disabled:d,children:`Review`}),p&&(0,N.jsx)(`button`,{className:`rrq-btn rrq-btn-dark`,onClick:()=>a(e),disabled:d,children:d?`...`:`Approve`}),m&&(0,N.jsx)(`button`,{className:`rrq-btn rrq-btn-gold`,onClick:()=>o(e),disabled:d,children:d?`...`:`Publish`}),f===`published`&&(0,N.jsx)(`button`,{className:`rrq-btn rrq-btn-light`,onClick:()=>s(e),disabled:d,children:`Reopen`})]})]},e.id)})})]})}function _t({alerts:e,loading:t,error:n,counts:r,onRefresh:i,alertsLoading:a,onViewAll:o}){let[s,c]=(0,_.useState)(`all`),l=(0,_.useMemo)(()=>s===`all`?e:e.filter(e=>e.severity===s),[e,s]),u=e.filter(e=>e.severity===`high`).length,d=e.filter(e=>e.severity===`medium`).length,f=e.filter(e=>e.severity===`low`).length;return(0,N.jsxs)(`div`,{className:`aa-wrap`,children:[(0,N.jsxs)(`div`,{className:`aa-panel`,children:[(0,N.jsxs)(`div`,{className:`aa-head`,children:[(0,N.jsxs)(`div`,{className:`aa-head-left`,children:[(0,N.jsx)(`div`,{className:`aa-head-icon`,children:(0,N.jsx)(`i`,{className:`bi bi-bell-fill`})}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`h3`,{className:`aa-title`,children:`Academic & Score Alerts`}),(0,N.jsx)(`p`,{className:`aa-sub`,children:`Continuous assessment anomalies & missing grades`})]})]}),(0,N.jsxs)(`button`,{className:`db-refresh-btn`,onClick:i,disabled:a,children:[(0,N.jsx)(`i`,{className:`bi bi-arrow-clockwise ${a?`rrq-spin`:``}`}),a?`Refreshing...`:`Refresh`]})]}),!t&&e.length>0&&(0,N.jsx)(`div`,{className:`aa-filters`,children:[{key:`all`,label:`All Alerts`,count:e.length},{key:`high`,label:`High Severity`,count:u},{key:`medium`,label:`Medium`,count:d},{key:`low`,label:`Low`,count:f}].map(e=>(0,N.jsxs)(`button`,{className:`aa-filter-btn ${s===e.key?`aa-filter-btn--active`:``}`,onClick:()=>c(e.key),children:[e.label,e.count>0&&(0,N.jsx)(`span`,{className:`aa-filter-count`,children:e.count})]},e.key))}),n&&(0,N.jsxs)(`div`,{className:`aa-error-bar`,children:[(0,N.jsx)(`i`,{className:`bi bi-exclamation-circle-fill`}),n]}),(0,N.jsx)(`div`,{className:`aa-list`,children:t?[0,1,2].map(e=>(0,N.jsxs)(`div`,{className:`aa-skeleton-item`,children:[(0,N.jsx)(`div`,{className:`rm-skel rm-skel--title mb-2`,style:{width:`50%`}}),(0,N.jsx)(`div`,{className:`rm-skel rm-skel--sub`,style:{width:`80%`}})]},e)):l.length===0?(0,N.jsxs)(`div`,{className:`aa-empty`,children:[(0,N.jsx)(`i`,{className:`bi bi-shield-check text-success fs-3`}),(0,N.jsx)(`p`,{children:`No academic flags recorded.`}),(0,N.jsx)(`span`,{children:`Score submissions are consistent and within expected thresholds.`})]}):l.slice(0,4).map(e=>(0,N.jsx)(`div`,{className:`aa-item`,children:(0,N.jsxs)(`div`,{className:`aa-item-body`,children:[(0,N.jsxs)(`div`,{className:`d-flex justify-content-between align-items-start mb-1`,children:[(0,N.jsx)(`span`,{className:`fw-bold`,style:{color:`#0F2744`,fontSize:`13.5px`},children:e.title}),(0,N.jsx)(`span`,{className:`badge ${e.severity===`high`?`bg-danger`:e.severity===`medium`?`bg-warning text-dark`:`bg-info`}`,style:{fontSize:`10.5px`},children:e.severity.toUpperCase()})]}),(0,N.jsx)(`p`,{className:`mb-1`,style:{fontSize:`12.5px`,color:`#475569`,lineHeight:1.5},children:e.message}),(0,N.jsxs)(`div`,{className:`d-flex justify-content-between`,style:{fontSize:`11px`,color:`#94A3B8`},children:[(0,N.jsx)(`span`,{children:[e.class_name,e.subject_name,e.student_name].filter(Boolean).join(` · `)}),(0,N.jsx)(`span`,{children:pt(e.created_at)})]})]})},e.id))}),(0,N.jsxs)(`div`,{className:`aa-footer`,children:[(0,N.jsxs)(`span`,{className:`aa-footer-count`,children:[r.open_total,` open alerts`]}),(0,N.jsx)(`button`,{className:`aa-view-all-btn`,onClick:o,children:`View All Monitoring Logs →`})]})]}),(0,N.jsxs)(`div`,{className:`aa-scorecard`,children:[(0,N.jsx)(`h4`,{className:`aa-scorecard-title`,children:`Score Submissions`}),(0,N.jsxs)(`div`,{className:`aa-scorecard-hero`,children:[(0,N.jsx)(`div`,{className:`aa-scorecard-big`,children:r.submission_open_total}),(0,N.jsx)(`div`,{className:`aa-scorecard-big-label`,children:`Active Batch Monitors`})]}),(0,N.jsxs)(`div`,{className:`aa-breakdown`,children:[(0,N.jsxs)(`div`,{className:`d-flex justify-content-between`,style:{fontSize:`12.5px`},children:[(0,N.jsx)(`span`,{children:`Overdue Batches:`}),(0,N.jsx)(`strong`,{className:r.submission_overdue_total>0?`text-danger`:`text-success`,children:r.submission_overdue_total})]}),(0,N.jsxs)(`div`,{className:`d-flex justify-content-between`,style:{fontSize:`12.5px`},children:[(0,N.jsx)(`span`,{children:`Critical Severity:`}),(0,N.jsx)(`strong`,{className:r.high>0?`text-danger`:`text-muted`,children:r.high})]})]})]})]})}function vt(){let e=d(),t=A(),[n,r]=(0,_.useState)(!1),[i,a]=(0,_.useState)(!0),[o,s]=(0,_.useState)(0),[c,l]=(0,_.useState)(``),[u,f]=(0,_.useState)(``),[p,m]=(0,_.useState)(`SchoolProfit Core`),[g,v]=(0,_.useState)([{title:`Total Students`,value:0,icon:`students`},{title:`Teachers`,value:0,icon:`teachers`},{title:`Total Parents`,value:0,icon:`parents`},{title:`Results Uploaded`,value:`0%`,icon:`results`}]),[y,b]=(0,_.useState)([]),[x,S]=(0,_.useState)(!1),[C,w]=(0,_.useState)(null),[T,E]=(0,_.useState)({open_total:0,high:0,medium:0,low:0,submission_open_total:0,submission_overdue_total:0}),[D,O]=(0,_.useState)([]),[k,j]=(0,_.useState)(!1),[M,P]=(0,_.useState)(null),[F,I]=(0,_.useState)(null),[L,R]=(0,_.useState)([]),[z,V]=(0,_.useState)([]),ee=(0,_.useRef)(null),te=(0,_.useRef)(null),[ne,re]=(0,_.useState)([]),[ie,H]=(0,_.useState)(!1),[ae,oe]=(0,_.useState)(null),[U,W]=(0,_.useState)(1),[K,q]=(0,_.useState)(null),se=K?Math.max(1,Math.ceil(K.total/5)):1,ce=`${window.location.origin}/pay-school-fee`,[J,X]=(0,_.useState)(!1),le=()=>{navigator.clipboard.writeText(ce),X(!0),setTimeout(()=>X(!1),2e3)},ue=()=>{S(!0),B.get(`/admin/academic-alerts/summary`).then(e=>{b(Array.isArray(e.data?.data)?e.data.data:[]),e.data?.counts&&E(e.data.counts)}).catch(()=>w(`Could not refresh alerts`)).finally(()=>S(!1))},de=(e,t)=>{j(!0),I(null),B.get(`/admin/result-batches`,{params:{term:e,session:t}}).then(e=>{O(Array.isArray(e.data?.data)?e.data.data:Array.isArray(e.data)?e.data:[])}).catch(()=>{O([])}).finally(()=>j(!1))},fe=(e,t)=>{P(e.id),B.post(`/admin/results/review-batches/${e.id}/${t}`).then(()=>de()).catch(e=>alert(e?.response?.data?.message||`Failed to ${t} batch.`)).finally(()=>P(null))},Z=(e=1)=>{H(!0),B.get(`/top-students`,{params:{page:e,limit:5}}).then(e=>{re(e.data?.data||[]),q(e.data)}).catch(()=>oe(`Could not load leaderboard`)).finally(()=>H(!1))};return(0,_.useEffect)(()=>{a(!0),Promise.allSettled([B.get(`/current-session-term`),B.get(`/dashboard/counts`),B.get(`/performance-stats`),B.get(`/admin/academic-alerts/summary`),B.get(`/school/billing/dashboard`)]).then(([e,t,n,r,i])=>{let a=``,o=``;if(e.status===`fulfilled`&&(o=e.value.data.session??``,a=e.value.data.term??``,l(o),f(a)),t.status===`fulfilled`){let e=t.value.data??{};s(Number(e.total_users??0)),v([{title:`Total Students`,value:Number(e.students??0),icon:`students`},{title:`Teachers`,value:Number(e.teachers??0),icon:`teachers`},{title:`Total Parents`,value:Number(e.parents??0),icon:`parents`},{title:`Results Uploaded`,value:e.results_uploaded??`0%`,icon:`results`}])}if(n.status===`fulfilled`){let e=Array.isArray(n.value.data.data)?n.value.data.data:[];R(e.map(e=>e.term)),V(e.map(e=>e.average))}r.status===`fulfilled`&&(b(Array.isArray(r.value.data.data)?r.value.data.data:[]),E(r.value.data.counts||{open_total:0,high:0,medium:0,low:0,submission_open_total:0,submission_overdue_total:0})),i.status===`fulfilled`&&m(i.value.data?.package?.name||`Core`),de(a,o)}).finally(()=>{a(!1),Z(1)})},[]),(0,_.useEffect)(()=>{Z(U)},[U]),(0,_.useEffect)(()=>{if(!ee.current)return;let e=ee.current.getContext(`2d`);if(e)return te.current?.destroy(),te.current=new h(e,{type:`bar`,data:{labels:L.length>0?L:[`1st Term`,`2nd Term`,`3rd Term`],datasets:[{label:`Term Average (%)`,data:z.length>0?z:[72.4,76.8,81.2],backgroundColor:`#D97706`,borderRadius:8,barThickness:28}]},options:{responsive:!0,maintainAspectRatio:!1,plugins:{legend:{display:!1},tooltip:{backgroundColor:`#0F2744`,padding:10,cornerRadius:8,titleColor:`#F59E0B`,bodyColor:`#FFFFFF`}},scales:{x:{grid:{display:!1},ticks:{font:{size:12}}},y:{beginAtZero:!0,max:100,grid:{color:`#F1F5F9`},ticks:{font:{size:12}}}}}}),()=>{te.current?.destroy()}},[L,z]),(0,N.jsxs)(N.Fragment,{children:[(0,N.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');

        .db-main {
          background: #F8FAFC;
          min-height: 100vh;
          font-family: 'Plus Jakarta Sans', sans-serif;
          padding: 24px 28px;
        }

        /* ── Hero Banner ── */
        .db-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 18px;
          padding: 32px 36px;
          color: #FFFFFF;
          margin-bottom: 24px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
          display: flex;
          align-items: center;
          justify-content: space-between;
          flex-wrap: wrap;
          gap: 24px;
        }

        .db-session-badge {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.2);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius: 999px;
          padding: 4px 12px;
          margin-bottom: 12px;
        }

        .db-greeting {
          font-size: 26px;
          font-weight: 800;
          margin-bottom: 6px;
          color: #FFFFFF;
        }

        .db-hero-sub {
          font-size: 13.5px;
          color: #CBD5E1;
          margin-bottom: 18px;
          max-width: 500px;
        }

        .db-btn-gold {
          background: #D97706;
          color: #FFFFFF;
          font-weight: 700;
          font-size: 13px;
          border: none;
          border-radius: 10px;
          padding: 9px 18px;
          display: inline-flex;
          align-items: center;
          gap: 7px;
          cursor: pointer;
          transition: all 0.2s ease;
          text-decoration: none;
        }

        .db-btn-gold:hover {
          background: #B45309;
          transform: translateY(-1px);
          color: #FFFFFF;
        }

        .db-btn-outline {
          background: rgba(255, 255, 255, 0.1);
          color: #FFFFFF;
          font-weight: 600;
          font-size: 13px;
          border: 1px solid rgba(255, 255, 255, 0.2);
          border-radius: 10px;
          padding: 9px 18px;
          display: inline-flex;
          align-items: center;
          gap: 7px;
          cursor: pointer;
          transition: all 0.2s ease;
          text-decoration: none;
        }

        .db-btn-outline:hover {
          background: rgba(255, 255, 255, 0.18);
          color: #FFFFFF;
        }

        /* ── Metric Stat Cards ── */
        .db-stats {
          display: grid;
          grid-template-columns: repeat(4, minmax(0, 1fr));
          gap: 18px;
          margin-bottom: 24px;
        }

        @media (max-width: 1199px) { .db-stats { grid-template-columns: repeat(2, 1fr); } }
        @media (max-width: 576px) { .db-stats { grid-template-columns: 1fr; } }

        .db-stat {
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: 16px;
          padding: 22px 20px;
          box-shadow: 0 4px 12px rgba(15, 39, 68, 0.03);
          transition: all 0.2s ease;
        }

        .db-stat:hover {
          transform: translateY(-3px);
          box-shadow: 0 10px 24px rgba(15, 39, 68, 0.07);
          border-color: #CBD5E1;
        }

        .db-stat-icon {
          width: 44px;
          height: 44px;
          border-radius: 12px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 18px;
          margin-bottom: 12px;
        }

        .db-stat-label {
          font-size: 12.5px;
          font-weight: 600;
          color: #64748B;
          margin-bottom: 4px;
        }

        .db-stat-val {
          font-size: 26px;
          font-weight: 800;
          color: #0F2744;
          line-height: 1;
        }

        /* ── Panels ── */
        .rrq-panel, .aa-panel, .db-panel {
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: 18px;
          box-shadow: 0 4px 16px rgba(15, 39, 68, 0.03);
          margin-bottom: 24px;
          overflow: hidden;
        }

        .rrq-head, .aa-head, .db-panel-head {
          padding: 20px 24px;
          border-bottom: 1px solid #F1F5F9;
          display: flex;
          align-items: center;
          justify-content: space-between;
          flex-wrap: wrap;
          gap: 12px;
        }

        .rrq-title-wrap, .aa-head-left {
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .rrq-icon, .aa-head-icon {
          width: 40px;
          height: 40px;
          border-radius: 10px;
          background: rgba(217, 119, 6, 0.12);
          color: #D97706;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 18px;
          flex-shrink: 0;
        }

        .rrq-title, .aa-title, .db-panel-title {
          font-size: 17px;
          font-weight: 800;
          color: #0F2744;
          margin: 0 0 2px;
        }

        .rrq-sub, .aa-sub, .db-panel-sub {
          font-size: 12.5px;
          color: #64748B;
          margin: 0;
        }

        .rrq-count {
          background: #FEF3C7;
          color: #B45309;
          font-size: 12px;
          font-weight: 700;
          padding: 4px 12px;
          border-radius: 999px;
        }

        .db-refresh-btn {
          background: #F8FAFC;
          border: 1px solid #E2E8F0;
          color: #475569;
          border-radius: 8px;
          padding: 6px 14px;
          font-size: 12.5px;
          font-weight: 600;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          cursor: pointer;
        }

        .db-refresh-btn:hover {
          background: #F1F5F9;
          color: #0F2744;
        }

        .rrq-body {
          display: grid;
          grid-template-columns: repeat(3, minmax(0, 1fr));
          gap: 16px;
          padding: 20px;
        }

        @media (max-width: 991px) { .rrq-body { grid-template-columns: 1fr; } }

        .rrq-card {
          border: 1px solid #E2E8F0;
          border-radius: 14px;
          background: #FFFFFF;
          padding: 18px;
          display: flex;
          flex-direction: column;
          gap: 10px;
        }

        .rrq-card:hover {
          border-color: #CBD5E1;
          box-shadow: 0 6px 16px rgba(15, 39, 68, 0.04);
        }

        .rrq-class {
          font-size: 15px;
          font-weight: 800;
          color: #0F2744;
        }

        .rrq-meta {
          font-size: 11.5px;
          color: #94A3B8;
        }

        .rrq-badge {
          font-size: 11px;
          font-weight: 700;
          padding: 3px 8px;
          border-radius: 6px;
          text-transform: uppercase;
        }

        .rrq-badge--draft { background: #F1F5F9; color: #475569; }
        .rrq-badge--computed { background: #DBEAFE; color: #1D4ED8; }
        .rrq-badge--approved { background: #FEF3C7; color: #B45309; }
        .rrq-badge--published { background: #D1FAE5; color: #065F46; }

        .rrq-track {
          height: 6px;
          background: #F1F5F9;
          border-radius: 999px;
          overflow: hidden;
        }

        .rrq-fill {
          height: 100%;
          background: #D97706;
          border-radius: 999px;
        }

        .rrq-actions {
          display: flex;
          gap: 8px;
          margin-top: auto;
        }

        .rrq-btn {
          border-radius: 8px;
          font-size: 12px;
          font-weight: 700;
          padding: 6px 12px;
          cursor: pointer;
          border: none;
        }

        .rrq-btn-light { background: #F1F5F9; color: #334155; }
        .rrq-btn-dark { background: #0F2744; color: #FFFFFF; }
        .rrq-btn-gold { background: #D97706; color: #FFFFFF; }

        .rrq-empty {
          grid-column: 1 / -1;
          text-align: center;
          padding: 32px;
          color: #64748B;
        }

        /* ── Academic Alerts ── */
        .aa-wrap {
          display: grid;
          grid-template-columns: 1fr 300px;
          gap: 20px;
          margin-bottom: 24px;
        }

        @media (max-width: 991px) { .aa-wrap { grid-template-columns: 1fr; } }

        .aa-filters {
          display: flex;
          gap: 8px;
          padding: 12px 24px;
          border-bottom: 1px solid #F1F5F9;
        }

        .aa-filter-btn {
          border: 1px solid #E2E8F0;
          background: #FFFFFF;
          font-size: 12px;
          font-weight: 600;
          padding: 4px 12px;
          border-radius: 6px;
          color: #64748B;
          cursor: pointer;
        }

        .aa-filter-btn--active {
          background: #0F2744;
          color: #FFFFFF;
          border-color: #0F2744;
        }

        .aa-list {
          padding: 16px 24px;
          display: flex;
          flex-direction: column;
          gap: 12px;
        }

        .aa-item {
          border: 1px solid #F1F5F9;
          border-radius: 10px;
          padding: 14px;
          background: #F8FAFC;
        }

        .aa-footer {
          padding: 14px 24px;
          border-top: 1px solid #F1F5F9;
          display: flex;
          align-items: center;
          justify-content: space-between;
        }

        .aa-view-all-btn {
          border: none;
          background: none;
          color: #D97706;
          font-weight: 700;
          font-size: 12.5px;
          cursor: pointer;
        }

        .aa-scorecard {
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: 18px;
          padding: 24px;
          height: fit-content;
        }

        .aa-scorecard-title {
          font-size: 15px;
          font-weight: 800;
          color: #0F2744;
          margin-bottom: 16px;
        }

        .aa-scorecard-hero {
          text-align: center;
          background: #F8FAFC;
          border-radius: 12px;
          padding: 20px;
          margin-bottom: 16px;
        }

        .aa-scorecard-big {
          font-size: 42px;
          font-weight: 800;
          color: #0F2744;
          line-height: 1;
        }

        .aa-scorecard-big-label {
          font-size: 12px;
          color: #64748B;
          margin-top: 4px;
        }

        /* ── Grid ── */
        .db-grid {
          display: grid;
          grid-template-columns: 1.2fr 1fr;
          gap: 20px;
          margin-bottom: 24px;
        }

        @media (max-width: 991px) { .db-grid { grid-template-columns: 1fr; } }

        .db-table {
          width: 100%;
          border-collapse: collapse;
        }

        .db-table th {
          background: #F8FAFC;
          padding: 10px 16px;
          font-size: 11.5px;
          font-weight: 700;
          color: #64748B;
          text-transform: uppercase;
          text-align: left;
          border-bottom: 1px solid #E2E8F0;
        }

        .db-table td {
          padding: 12px 16px;
          font-size: 13.5px;
          border-bottom: 1px solid #F1F5F9;
          color: #334155;
        }

        .db-rank {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          width: 22px;
          height: 22px;
          border-radius: 50%;
          font-size: 11px;
          font-weight: 800;
        }

        .db-rank--gold { background: #FEF3C7; color: #B45309; }
        .db-rank--silver { background: #E2E8F0; color: #334155; }
        .db-rank--bronze { background: #FFEDD5; color: #C2410C; }

        .db-score-pill {
          background: #ECFDF5;
          color: #047857;
          font-weight: 700;
          padding: 2px 8px;
          border-radius: 6px;
        }

        .db-pagination {
          padding: 12px 16px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          font-size: 12px;
          color: #64748B;
        }

        .db-page-btn {
          border: 1px solid #E2E8F0;
          background: #FFFFFF;
          padding: 4px 10px;
          border-radius: 6px;
          cursor: pointer;
        }

        .db-chart-wrap {
          padding: 20px;
          height: 250px;
        }

        /* ── Quick Actions ── */
        .db-actions {
          display: grid;
          grid-template-columns: repeat(5, minmax(0, 1fr));
          gap: 14px;
          margin-bottom: 24px;
        }

        @media (max-width: 991px) { .db-actions { grid-template-columns: repeat(2, 1fr); } }
        @media (max-width: 576px) { .db-actions { grid-template-columns: 1fr; } }

        .db-action {
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: 14px;
          padding: 18px 16px;
          display: flex;
          align-items: center;
          gap: 12px;
          text-decoration: none;
          color: inherit;
          transition: all 0.2s ease;
        }

        .db-action:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 20px rgba(15, 39, 68, 0.06);
          border-color: #CBD5E1;
        }

        .db-action-icon {
          width: 40px;
          height: 40px;
          border-radius: 10px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 18px;
          flex-shrink: 0;
        }

        .db-action-label {
          font-size: 13.5px;
          font-weight: 700;
          color: #0F2744;
        }

        .db-action-desc {
          font-size: 11.5px;
          color: #64748B;
        }

        .rrq-spin { animation: rrqSpin 0.8s linear infinite; }
        @keyframes rrqSpin { to { transform: rotate(360deg); } }
      `}),(0,N.jsx)(st,{sidebarOpen:n,setSidebarOpen:r}),(0,N.jsx)(Y,{title:`School Administration Dashboard`}),(0,N.jsx)(`div`,{className:`container-fluid`,children:(0,N.jsxs)(`div`,{className:`row`,children:[(0,N.jsx)(ct,{sidebarOpen:n,setSidebarOpen:r}),(0,N.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto db-main`,children:[i&&(0,N.jsx)(G,{message:`Opening school dashboard...`}),(0,N.jsxs)(`div`,{className:`db-hero`,children:[(0,N.jsxs)(`div`,{children:[(0,N.jsxs)(`div`,{className:`db-session-badge`,children:[(0,N.jsx)(`span`,{children:`●`}),` `,c||`Current Session`,` — `,u||`Active Term`]}),(0,N.jsxs)(`h1`,{className:`db-greeting`,children:[ft(),`, `,t?.firstname||`Administrator`,`.`]}),(0,N.jsx)(`p`,{className:`db-hero-sub`,children:`Welcome to your school management cockpit. Continuous assessment and live broadsheets are active.`}),(0,N.jsxs)(`div`,{className:`d-flex flex-wrap gap-2`,children:[(0,N.jsxs)(`button`,{className:`db-btn-gold`,onClick:()=>e(`/results/pins`),children:[(0,N.jsx)(`i`,{className:`bi bi-key-fill`}),` Generate PINs`]}),(0,N.jsxs)(`button`,{className:`db-btn-outline`,onClick:()=>e(`/result/monitor`),children:[(0,N.jsx)(`i`,{className:`bi bi-speedometer2`}),` Result Monitoring`]}),(0,N.jsxs)(`button`,{className:`db-btn-outline`,onClick:()=>e(`/results/broadsheet`),children:[(0,N.jsx)(`i`,{className:`bi bi-file-earmark-spreadsheet`}),` Broadsheets`]})]})]}),(0,N.jsxs)(`div`,{className:`d-none d-md-block`,style:{background:`rgba(255,255,255,0.08)`,padding:`16px 20px`,borderRadius:`14px`,border:`1px solid rgba(255,255,255,0.15)`,maxWidth:`260px`},children:[(0,N.jsx)(`div`,{style:{fontSize:`11px`,fontWeight:700,color:`#FBBF24`,textTransform:`uppercase`,marginBottom:`6px`},children:`💳 Parent Fee Portal`}),(0,N.jsx)(`div`,{style:{fontSize:`12px`,color:`#E2E8F0`,marginBottom:`10px`,lineHeight:1.4},children:`Share payment link with parents for direct settlement.`}),(0,N.jsx)(`button`,{className:`btn btn-sm btn-light w-100 fw-bold`,style:{fontSize:`12px`,borderRadius:`8px`},onClick:le,children:J?`✓ Copied Link!`:`Copy Parent Link`})]})]}),(0,N.jsx)(`div`,{className:`db-stats`,children:g.map(({title:e,value:t},n)=>{let r=ut[n],i=[(0,N.jsx)(`i`,{className:`bi bi-mortarboard-fill`},`s`),(0,N.jsx)(`i`,{className:`bi bi-person-workspace`},`t`),(0,N.jsx)(`i`,{className:`bi bi-people-fill`},`p`),(0,N.jsx)(`i`,{className:`bi bi-check2-circle`},`r`)];return(0,N.jsxs)(`div`,{className:`db-stat`,children:[(0,N.jsx)(`div`,{className:`db-stat-icon`,style:{background:r.bg,color:r.color},children:i[n]}),(0,N.jsx)(`div`,{className:`db-stat-label`,children:e}),(0,N.jsx)(`div`,{className:`db-stat-val`,children:t})]},e)})}),(0,N.jsx)(`div`,{className:`db-actions`,children:dt.map(t=>(0,N.jsxs)(`a`,{href:t.path,className:`db-action`,onClick:n=>{n.preventDefault(),e(t.path)},children:[(0,N.jsx)(`div`,{className:`db-action-icon`,style:{background:t.bg,color:t.color},children:t.icon}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`div`,{className:`db-action-label`,children:t.label}),(0,N.jsx)(`div`,{className:`db-action-desc`,children:t.desc})]})]},t.label))}),(0,N.jsx)(gt,{batches:D,loading:k,busyId:M,error:F,onRefresh:de,onApprove:e=>fe(e,`approve`),onPublish:e=>fe(e,`publish`),onReopen:e=>fe(e,`reopen`),onOpenBroadsheet:t=>e(`/results/broadsheet/${t.id}`)}),(0,N.jsx)(_t,{alerts:y,loading:x&&y.length===0,error:C,counts:T,onRefresh:ue,alertsLoading:x,onViewAll:()=>e(`/admin/academic-alerts`)}),(0,N.jsxs)(`div`,{className:`db-grid`,children:[(0,N.jsxs)(`div`,{className:`db-panel`,children:[(0,N.jsxs)(`div`,{className:`db-panel-head`,children:[(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`h3`,{className:`db-panel-title`,children:`Top Academic Achievers`}),(0,N.jsx)(`p`,{className:`db-panel-sub`,children:K?`${K.term_used} · ${K.session_used}`:`Current Term`})]}),(0,N.jsxs)(`button`,{className:`db-refresh-btn`,onClick:()=>Z(U),disabled:ie,children:[(0,N.jsx)(`i`,{className:`bi bi-arrow-clockwise ${ie?`rrq-spin`:``}`}),ie?`...`:`Refresh`]})]}),(0,N.jsx)(`div`,{className:`overflow-auto`,children:(0,N.jsxs)(`table`,{className:`db-table`,children:[(0,N.jsx)(`thead`,{children:(0,N.jsxs)(`tr`,{children:[(0,N.jsx)(`th`,{children:`Rank`}),(0,N.jsx)(`th`,{children:`Adm. No`}),(0,N.jsx)(`th`,{children:`Student Name`}),(0,N.jsx)(`th`,{children:`Class`}),(0,N.jsx)(`th`,{children:`Avg Score`})]})}),(0,N.jsx)(`tbody`,{children:ie?Array.from({length:4}).map((e,t)=>(0,N.jsx)(`tr`,{children:(0,N.jsx)(`td`,{colSpan:5,children:(0,N.jsx)(`div`,{className:`rm-skel rm-skel--sub`,style:{width:`100%`}})})},t)):ne.length===0?(0,N.jsx)(`tr`,{children:(0,N.jsx)(`td`,{colSpan:5,className:`text-center py-4 text-muted`,children:`No student score records found for this term.`})}):ne.map((e,t)=>{let n=(U-1)*5+t+1;return(0,N.jsxs)(`tr`,{children:[(0,N.jsx)(`td`,{children:(0,N.jsx)(`span`,{className:`db-rank ${n===1?`db-rank--gold`:n===2?`db-rank--silver`:n===3?`db-rank--bronze`:``}`,children:n})}),(0,N.jsx)(`td`,{style:{color:`#64748B`,fontSize:`12.5px`},children:e.admission_no}),(0,N.jsx)(`td`,{children:(0,N.jsx)(`strong`,{style:{color:`#0F2744`},children:e.name})}),(0,N.jsx)(`td`,{children:e.class}),(0,N.jsx)(`td`,{children:(0,N.jsxs)(`span`,{className:`db-score-pill`,children:[Number.isFinite(e.score)?e.score.toFixed(1):e.score,`%`]})})]},`${e.admission_no}-${t}`)})})]})}),(0,N.jsxs)(`div`,{className:`db-pagination`,children:[(0,N.jsx)(`span`,{children:K?`${K.total} total students recorded`:``}),(0,N.jsxs)(`div`,{className:`d-flex gap-2`,children:[(0,N.jsx)(`button`,{className:`db-page-btn`,onClick:()=>W(e=>Math.max(1,e-1)),disabled:U<=1||ie,children:`← Prev`}),(0,N.jsxs)(`span`,{children:[`Page `,U,` of `,se]}),(0,N.jsx)(`button`,{className:`db-page-btn`,onClick:()=>W(e=>Math.min(se,e+1)),disabled:U>=se||ie,children:`Next →`})]})]})]}),(0,N.jsxs)(`div`,{className:`db-panel d-flex flex-column`,children:[(0,N.jsx)(`div`,{className:`db-panel-head`,children:(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`h3`,{className:`db-panel-title`,children:`Academic Trend`}),(0,N.jsx)(`p`,{className:`db-panel-sub`,children:`School average score progression`})]})}),(0,N.jsx)(`div`,{className:`db-chart-wrap flex-grow-1`,children:(0,N.jsx)(`canvas`,{ref:ee})})]})]}),(0,N.jsx)(lt,{})]})]})})]})}var yt={summary:{tracked_students:0,strong_count:0,struggling_count:0,class_average:0},top_performers:[],struggling_students:[]},bt={actions:[],attendance:{date:``,total_students:0,marked_today:0,present_today:0,absent_today:0,late_today:0,attendance_rate:0,classes_needing_attendance:[],frequent_absentees:[]},results:{total_batches:0,completed_batches:0,pending_batches_count:0,completion_percent:0,pending_batches:[]}};function xt(){let e=d(),[t,n]=(0,_.useState)(!1),[r,i]=(0,_.useState)(``),[a,o]=(0,_.useState)(``),[s,c]=(0,_.useState)(!0),[l,u]=(0,_.useState)(null),[f,p]=(0,_.useState)([{title:`My Students`,value:0,icon:`people`},{title:`My Classes`,value:0,icon:`building`},{title:`My Subjects`,value:0,icon:`book`},{title:`Results Completion`,value:`0%`,icon:`check-circle`}]),m=(0,_.useRef)(null),g=(0,_.useRef)(null),v=(0,_.useRef)(null),y=(0,_.useRef)(null),[b,x]=(0,_.useState)([]),[S,C]=(0,_.useState)([]),[w,T]=(0,_.useState)([]),[E,D]=(0,_.useState)([]),[O,k]=(0,_.useState)(yt),[A,j]=(0,_.useState)(bt);(0,_.useEffect)(()=>{c(!0);let e=B.get(`/current-session-term`),t=B.get(`/teacher/dashboard/counts`),n=B.get(`/teacher/performance-stats`),r=B.get(`/teacher/access-stats`),a=B.get(`/teacher/action-center`),s=B.get(`/teacher/student-performance`);B.get(`/admin/ai/credits`).then(e=>u(e.data?.data||null)).catch(()=>void 0),Promise.all([e,t,n,r,a,s]).then(([e,t,n,r,a,s])=>{i(e.data.session),o(e.data.term);let c=t.data;p([{title:`My Students`,value:c.students,icon:`people`},{title:`My Classes`,value:c.classes,icon:`building`},{title:`My Subjects`,value:c.subjects,icon:`book`},{title:`Results Completion`,value:c.results_uploaded,icon:`check-circle`}]);let l=n.data.data||[];T(l.map(e=>e.term)),D(l.map(e=>Number(e.average||0))),x(r.data.labels||[`Mon`,`Tue`,`Wed`,`Thu`,`Fri`]),C(r.data.data||[0,0,0,0,0]),j({...bt,...a.data||{},attendance:{...bt.attendance,...a.data?.attendance||{}},results:{...bt.results,...a.data?.results||{}}}),k({...yt,...s.data||{},summary:{...yt.summary,...s.data?.summary||{}}})}).catch(e=>console.error(e)).finally(()=>c(!1))},[]),(0,_.useEffect)(()=>{let e=getComputedStyle(document.documentElement).getPropertyValue(`--bs-secondary`).trim()||`rgb(255,200,87)`,t=(e,t)=>e.startsWith(`rgb`)?e.replace(`rgb`,`rgba`).replace(`)`,`, ${t})`):e+Math.round(t*255).toString(16).padStart(2,`0`),n=n=>{let r=n.createLinearGradient(0,0,0,320);return r.addColorStop(0,t(e,.35)),r.addColorStop(1,t(e,.05)),r};if(m.current){let e=m.current.getContext(`2d`);if(!e)return;v.current?.destroy(),v.current=new h(e,{type:`line`,data:{labels:b,datasets:[{label:`Results Saved`,data:S,borderColor:`rgb(255,200,87)`,backgroundColor:n(e),pointBackgroundColor:`rgb(255,200,87)`,pointBorderColor:`#fff`,pointBorderWidth:2,pointRadius:6,pointHoverRadius:8,tension:.4,fill:!0}]},options:{responsive:!0,maintainAspectRatio:!1,plugins:{legend:{display:!1},tooltip:{backgroundColor:`rgba(0, 0, 0, 0.8)`,padding:12,cornerRadius:8,titleFont:{size:13,weight:`bold`},bodyFont:{size:12}}},scales:{x:{grid:{display:!1},ticks:{font:{size:11}}},y:{grid:{color:`rgba(0, 0, 0, 0.05)`},ticks:{stepSize:5,font:{size:11}}}}}})}if(g.current){let e=g.current.getContext(`2d`);if(!e)return;y.current?.destroy(),y.current=new h(e,{type:`bar`,data:{labels:w,datasets:[{label:`Average Score`,data:E,backgroundColor:`rgba(255,200,87,0.88)`,borderRadius:8,barThickness:40,hoverBackgroundColor:`#ffe0a0`}]},options:{responsive:!0,maintainAspectRatio:!1,plugins:{legend:{display:!1},tooltip:{backgroundColor:`rgba(0, 0, 0, 0.8)`,padding:12,cornerRadius:8,titleFont:{size:13,weight:`bold`},bodyFont:{size:12}}},scales:{x:{grid:{display:!1},ticks:{font:{size:11}}},y:{beginAtZero:!0,grid:{color:`rgba(0, 0, 0, 0.05)`},ticks:{font:{size:11}}}}}})}return()=>{v.current?.destroy(),y.current?.destroy()}},[b,S,w,E]);let M=()=>{let e=new Date().getHours();return e<12?`Good Morning`:e<17?`Good Afternoon`:`Good Evening`},P=e=>e>=70?`#16a34a`:e>=50?`#f59e0b`:`#dc2626`,F=e=>e===`no_results`?{bg:`#f8fafc`,text:`#475569`,border:`#e2e8f0`,icon:`clipboard-data`}:e===`urgent`?{bg:`#fef2f2`,text:`#991b1b`,border:`#fecaca`,icon:`exclamation-triangle`}:e===`declining`||e===`at_risk`?{bg:`#fff7ed`,text:`#9a3412`,border:`#fed7aa`,icon:`lightbulb`}:{bg:`#ecfdf5`,text:`#166534`,border:`#bbf7d0`,icon:`stars`},I=e=>e===`high`?{bg:`#fef2f2`,text:`#991b1b`,border:`#fecaca`}:e===`medium`?{bg:`#fff7ed`,text:`#9a3412`,border:`#fed7aa`}:{bg:`#ecfdf5`,text:`#166534`,border:`#bbf7d0`},L=({value:e,color:t=`#2563eb`})=>(0,N.jsx)(`div`,{className:`rounded-pill overflow-hidden`,style:{height:8,backgroundColor:`#e2e8f0`},children:(0,N.jsx)(`div`,{className:`h-100 rounded-pill`,style:{width:`${Math.max(0,Math.min(100,e))}%`,backgroundColor:t}})}),R=({points:e})=>(0,N.jsx)(`div`,{className:`d-flex align-items-end gap-1`,style:{height:46},children:(e.length?e:[{label:`No data`,score:0}]).map((e,t)=>(0,N.jsx)(`div`,{title:`${e.label}: ${e.score}%`,className:`rounded-top flex-fill`,style:{minWidth:10,height:`${Math.max(8,Math.min(100,e.score))}%`,backgroundColor:P(e.score),opacity:.78}},`${e.label}-${t}`))}),z=({student:e,variant:t})=>{let n=F(e.insight?.level||`stable`),r=e.change<0?`#dc2626`:e.change>0?`#16a34a`:`#64748b`,i=e.status!==`no_results`;return(0,N.jsxs)(`div`,{className:`border rounded-3 p-3 bg-white`,children:[(0,N.jsxs)(`div`,{className:`d-flex justify-content-between gap-3`,children:[(0,N.jsxs)(`div`,{style:{minWidth:0},children:[(0,N.jsx)(`h6`,{className:`fw-semibold mb-1 text-truncate`,style:{color:`#0f172a`},children:e.name}),(0,N.jsxs)(`div`,{className:`d-flex flex-wrap gap-2 small text-muted`,children:[e.class_name&&(0,N.jsx)(`span`,{children:e.class_name}),e.reg_no&&(0,N.jsx)(`span`,{children:e.reg_no})]})]}),(0,N.jsxs)(`div`,{className:`text-end flex-shrink-0`,children:[(0,N.jsx)(`span`,{className:`badge rounded-pill`,style:{backgroundColor:i?`${P(e.average)}1a`:`#f1f5f9`,color:i?P(e.average):`#64748b`},children:i?`${e.average}%`:`No result`}),i&&(0,N.jsxs)(`div`,{className:`small fw-semibold mt-1`,style:{color:r},children:[e.change>0?`+`:``,e.change,`%`]})]})]}),(0,N.jsx)(`div`,{className:`mt-3`,children:(0,N.jsx)(R,{points:e.trend})}),t===`support`&&(0,N.jsxs)(N.Fragment,{children:[e.weak_subjects?.length>0&&(0,N.jsx)(`div`,{className:`d-flex flex-wrap gap-2 mt-3`,children:e.weak_subjects.map(t=>(0,N.jsxs)(`span`,{className:`badge rounded-pill fw-normal`,style:{backgroundColor:`#f1f5f9`,color:`#475569`},children:[t.subject,`: `,t.score,`%`]},`${e.id}-${t.subject}`))}),(0,N.jsx)(`div`,{className:`mt-3 p-3 rounded-3 border`,style:{backgroundColor:n.bg,borderColor:n.border},children:(0,N.jsxs)(`div`,{className:`d-flex gap-2`,children:[(0,N.jsx)(`i`,{className:`bi bi-${n.icon} flex-shrink-0`,style:{color:n.text}}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`div`,{className:`fw-semibold small mb-1`,style:{color:n.text},children:e.insight?.headline||`AI insight`}),(0,N.jsx)(`p`,{className:`small mb-0`,style:{color:`#475569`,lineHeight:1.55},children:e.insight?.recommendation})]})]})})]})]})};return(0,N.jsxs)(N.Fragment,{children:[(0,N.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');

        .teacher-db-main {
          background: #F8FAFC;
          min-height: 100vh;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          padding: 24px 28px 40px;
        }

        @media (max-width: 767.98px) {
          .teacher-db-main {
            padding: 16px 12px 32px !important;
          }
        }

        .teacher-db-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 18px;
          padding: 32px 36px;
          color: #FFFFFF;
          margin-bottom: 24px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
          position: relative;
          overflow: hidden;
        }

        @media (max-width: 767.98px) {
          .teacher-db-hero {
            padding: 20px 18px !important;
            border-radius: 14px !important;
            margin-bottom: 16px !important;
          }
        }

        .teacher-db-hero::before {
          content: '';
          position: absolute;
          inset: 0;
          background-image:
            linear-gradient(rgba(255, 255, 255, 0.035) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255, 255, 255, 0.035) 1px, transparent 1px);
          background-size: 32px 32px;
          pointer-events: none;
        }

        .teacher-db-hero-glow {
          position: absolute;
          top: -40px;
          right: -40px;
          width: 320px;
          height: 320px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.2) 0%, transparent 65%);
          pointer-events: none;
        }

        .teacher-db-hero-glow2 {
          position: absolute;
          bottom: -40px;
          left: 30%;
          width: 220px;
          height: 220px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(37, 99, 235, 0.15) 0%, transparent 70%);
          pointer-events: none;
        }

        .teacher-db-hero-inner {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: center;
          justify-content: space-between;
          flex-wrap: wrap;
          gap: 24px;
        }

        .teacher-db-session-badge {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.20);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius: 100px;
          padding: 4px 12px;
          margin-bottom: 12px;
        }

        .teacher-db-session-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #10B981;
          box-shadow: 0 0 6px #10B981;
        }

        .teacher-db-greeting {
          font-size: 26px;
          font-weight: 800;
          color: #FFFFFF;
          line-height: 1.1;
          margin-bottom: 8px;
        }

        .teacher-db-greeting em {
          font-style: normal;
          color: #FBBF24;
        }

        .teacher-db-hero-sub {
          font-size: 13.5px;
          color: #CBD5E1;
          line-height: 1.6;
          max-width: 520px;
          margin-bottom: 20px;
        }

        @media (max-width: 767.98px) {
          .teacher-db-greeting {
            font-size: 20px !important;
          }
          .teacher-db-hero-sub {
            font-size: 12.5px !important;
            margin-bottom: 16px !important;
          }
        }

        .teacher-db-hero-card {
          background: rgba(255, 255, 255, 0.08);
          border: 1px solid rgba(255, 255, 255, 0.15);
          backdrop-filter: blur(8px);
          border-radius: 14px;
          padding: 18px 22px;
          min-width: 250px;
        }

        .teacher-db-btn-gold {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 9px 18px;
          font-size: 13px;
          font-weight: 700;
          color: #0F2744;
          background: #FBBF24;
          border: none;
          border-radius: 10px;
          cursor: pointer;
          transition: all 0.2s ease;
          box-shadow: 0 4px 14px rgba(251, 191, 36, 0.3);
        }

        .teacher-db-btn-gold:hover {
          background: #F59E0B;
          transform: translateY(-1px);
        }

        .teacher-db-btn-outline {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 9px 18px;
          font-size: 13px;
          font-weight: 600;
          color: #FFFFFF;
          background: rgba(255, 255, 255, 0.10);
          border: 1px solid rgba(255, 255, 255, 0.20);
          border-radius: 10px;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .teacher-db-btn-outline:hover {
          background: rgba(255, 255, 255, 0.18);
          color: #FFFFFF;
        }

        @media (max-width: 575.98px) {
          .teacher-db-btn-gold, .teacher-db-btn-outline {
            width: 100% !important;
            justify-content: center !important;
          }
        }

        /* ── Unified Stat Cards ── */
        .t-stats-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 16px;
          margin-bottom: 24px;
        }

        @media (max-width: 1199px) {
          .t-stats-grid { grid-template-columns: repeat(2, 1fr); }
        }

        @media (max-width: 575px) {
          .t-stats-grid { grid-template-columns: 1fr; }
        }

        .t-stat-card {
          background: #FFFFFF;
          border: 1px solid rgba(15, 39, 68, 0.08);
          border-radius: 16px;
          padding: 22px 20px;
          position: relative;
          overflow: hidden;
          transition: all 0.25s ease;
          box-shadow: 0 2px 10px rgba(15, 39, 68, 0.04);
        }

        .t-stat-card:hover {
          box-shadow: 0 8px 24px rgba(15, 39, 68, 0.08);
          transform: translateY(-3px);
        }

        .t-stat-card::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          height: 3px;
          background: var(--stat-color, #D97706);
          transform: scaleX(0);
          transform-origin: left;
          transition: transform 0.3s ease;
        }

        .t-stat-card:hover::before {
          transform: scaleX(1);
        }

        .t-stat-head {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          margin-bottom: 14px;
        }

        .t-stat-icon {
          width: 44px;
          height: 44px;
          border-radius: 12px;
          background: var(--stat-bg, #FEF3C7);
          color: var(--stat-color, #D97706);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 20px;
        }

        .t-stat-label {
          font-size: 12px;
          font-weight: 600;
          color: #64748B;
          margin-bottom: 4px;
          text-transform: uppercase;
          letter-spacing: 0.04em;
        }

        .t-stat-val {
          font-size: 28px;
          font-weight: 800;
          color: #0F2744;
          line-height: 1;
        }

        .t-stat-footer {
          display: flex;
          align-items: center;
          gap: 6px;
          margin-top: 14px;
          padding-top: 12px;
          border-top: 1px solid #F1F5F9;
          font-size: 12px;
          color: #64748B;
        }

        /* ── Unified Panels ── */
        .t-panel {
          background: #FFFFFF;
          border: 1px solid rgba(15, 39, 68, 0.08);
          border-radius: 18px;
          box-shadow: 0 4px 20px rgba(15, 39, 68, 0.06);
          overflow: hidden;
          margin-bottom: 24px;
        }

        .t-panel-head {
          padding: 20px 24px;
          border-bottom: 1px solid #E2E8F0;
          display: flex;
          align-items: center;
          justify-content: space-between;
          flex-wrap: wrap;
          gap: 12px;
        }

        .t-panel-title {
          font-size: 16px;
          font-weight: 800;
          color: #0F2744;
          margin: 0;
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .t-panel-body {
          padding: 24px;
        }

        /* ── Quick Actions Grid ── */
        .t-qa-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 16px;
          margin-bottom: 24px;
        }

        @media (max-width: 991px) {
          .t-qa-grid { grid-template-columns: repeat(2, 1fr); }
        }

        @media (max-width: 575px) {
          .t-qa-grid { grid-template-columns: 1fr; }
        }

        .t-qa-card {
          background: #FFFFFF;
          border: 1px solid rgba(15, 39, 68, 0.08);
          border-radius: 16px;
          padding: 20px;
          display: flex;
          align-items: center;
          gap: 16px;
          cursor: pointer;
          transition: all 0.25s ease;
          box-shadow: 0 2px 8px rgba(15, 39, 68, 0.04);
          text-decoration: none;
          color: inherit;
        }

        .t-qa-card:hover {
          box-shadow: 0 8px 24px rgba(15, 39, 68, 0.08);
          transform: translateY(-3px);
          border-color: rgba(217, 119, 6, 0.3);
        }

        .t-qa-icon {
          width: 48px;
          height: 48px;
          border-radius: 14px;
          background: var(--qa-bg, #FEF3C7);
          color: var(--qa-color, #D97706);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 22px;
          flex-shrink: 0;
          transition: transform 0.3s ease;
        }

        .t-qa-card:hover .t-qa-icon {
          transform: scale(1.1) rotate(-4deg);
        }

        .t-qa-title {
          font-size: 14px;
          font-weight: 800;
          color: #0F2744;
          margin-bottom: 2px;
        }

        .t-qa-desc {
          font-size: 12px;
          color: #64748B;
          margin: 0;
        }
      `}),(0,N.jsx)(st,{sidebarOpen:t,setSidebarOpen:n}),(0,N.jsx)(Y,{title:`Teacher Dashboard`}),(0,N.jsx)(`div`,{className:`container-fluid`,children:(0,N.jsxs)(`div`,{className:`row`,children:[(0,N.jsx)(ct,{sidebarOpen:t,setSidebarOpen:n}),(0,N.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto gq-app-main teacher-db-main d-flex flex-column min-vh-100`,children:[s&&(0,N.jsx)(G,{message:`Loading dashboard...`}),(0,N.jsxs)(`div`,{className:`teacher-db-hero`,children:[(0,N.jsx)(`div`,{className:`teacher-db-hero-glow`}),(0,N.jsx)(`div`,{className:`teacher-db-hero-glow2`}),(0,N.jsxs)(`div`,{className:`teacher-db-hero-inner`,children:[(0,N.jsxs)(`div`,{children:[(0,N.jsxs)(`div`,{className:`teacher-db-session-badge`,children:[(0,N.jsx)(`span`,{className:`teacher-db-session-dot`}),r||`Academic Session`,` · `,a||`Active Term`]}),(0,N.jsxs)(`h1`,{className:`teacher-db-greeting`,children:[M(),`, `,(0,N.jsx)(`em`,{children:`Teacher.`})]}),(0,N.jsx)(`p`,{className:`teacher-db-hero-sub`,children:`Welcome to your teaching workspace. Manage class attendance, upload term examination results, generate AI lesson plans, and track student performance.`}),(0,N.jsxs)(`div`,{className:`d-flex gap-2 flex-wrap`,children:[(0,N.jsxs)(`button`,{className:`teacher-db-btn-gold`,onClick:()=>e(`/results/upload`),children:[(0,N.jsx)(`i`,{className:`bi bi-file-earmark-arrow-up-fill me-1`}),`Upload Results`]}),(0,N.jsxs)(`button`,{className:`teacher-db-btn-outline`,onClick:()=>e(`/students/attendance`),children:[(0,N.jsx)(`i`,{className:`bi bi-calendar2-check-fill me-1`}),`Take Attendance`]}),(0,N.jsxs)(`button`,{className:`teacher-db-btn-outline`,onClick:()=>e(`/settings/ai-lesson-plans`),children:[(0,N.jsx)(`i`,{className:`bi bi-journal-richtext me-1`}),`AI Lesson Planner`]}),(0,N.jsxs)(`button`,{className:`teacher-db-btn-outline`,onClick:()=>e(`/settings/ai-credits`),children:[(0,N.jsx)(`i`,{className:`bi bi-stars me-1 text-warning`}),`AI Credits`]})]})]}),(0,N.jsxs)(`div`,{className:`teacher-db-hero-card d-none d-md-block`,children:[(0,N.jsxs)(`div`,{className:`d-flex align-items-center justify-content-between mb-3`,children:[(0,N.jsx)(`span`,{style:{fontSize:`11px`,fontWeight:800,letterSpacing:`0.12em`,textTransform:`uppercase`,color:`#FBBF24`},children:`Quick Glance`}),(0,N.jsx)(`i`,{className:`bi bi-mortarboard-fill text-warning`})]}),(0,N.jsxs)(`div`,{className:`d-flex flex-column gap-2`,children:[(0,N.jsxs)(`div`,{className:`d-flex justify-content-between align-items-center`,children:[(0,N.jsx)(`span`,{style:{fontSize:`12.5px`,color:`#CBD5E1`},children:`My Students`}),(0,N.jsx)(`span`,{style:{fontSize:`15px`,fontWeight:800,color:`#FFFFFF`},children:f[0]?.value??0})]}),(0,N.jsxs)(`div`,{className:`d-flex justify-content-between align-items-center`,children:[(0,N.jsx)(`span`,{style:{fontSize:`12.5px`,color:`#CBD5E1`},children:`Result Completion`}),(0,N.jsx)(`span`,{style:{fontSize:`15px`,fontWeight:800,color:`#10B981`},children:f[3]?.value??`0%`})]}),(0,N.jsxs)(`div`,{className:`d-flex justify-content-between align-items-center pt-2 mt-1 border-top`,style:{borderColor:`rgba(255, 255, 255, 0.15)`,cursor:`pointer`},onClick:()=>e(`/settings/ai-credits`),title:`Click to view AI credit details`,children:[(0,N.jsxs)(`span`,{style:{fontSize:`12px`,color:`#CBD5E1`},children:[(0,N.jsx)(`i`,{className:`bi bi-stars me-1 text-warning`}),` AI Allowance`]}),(0,N.jsx)(`span`,{className:`badge bg-warning text-dark fw-bold`,style:{fontSize:`11px`},children:l?.is_plus_active?l.user_allocation?.is_unlimited?`Unlimited`:`${l.user_allocation?.remaining_credits??l.remaining_credits??0} credits`:`Plus Active`})]})]})]})]})]}),(0,N.jsx)(`div`,{className:`t-stats-grid`,children:[{title:`My Students`,value:f[0]?.value??0,icon:`people-fill`,color:`#D97706`,bg:`#FEF3C7`,footer:`Enrolled in assigned classes`},{title:`Assigned Subjects`,value:f[1]?.value??0,icon:`book-fill`,color:`#2563EB`,bg:`#DBEAFE`,footer:`Curriculum allocations`},{title:`Assigned Classes`,value:f[2]?.value??0,icon:`building`,color:`#7C3AED`,bg:`#EDE9FE`,footer:`Active teaching arms`},{title:`Result Batches`,value:f[3]?.value??`0%`,icon:`award-fill`,color:`#10B981`,bg:`#D1FAE5`,footer:`Entered and verified`}].map(e=>(0,N.jsxs)(`div`,{className:`t-stat-card`,style:{"--stat-color":e.color,"--stat-bg":e.bg},children:[(0,N.jsxs)(`div`,{className:`t-stat-head`,children:[(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`div`,{className:`t-stat-label`,children:e.title}),(0,N.jsx)(`div`,{className:`t-stat-val`,children:e.value})]}),(0,N.jsx)(`div`,{className:`t-stat-icon`,children:(0,N.jsx)(`i`,{className:`bi bi-${e.icon}`})})]}),(0,N.jsxs)(`div`,{className:`t-stat-footer`,children:[(0,N.jsx)(`i`,{className:`bi bi-info-circle text-muted`}),(0,N.jsx)(`span`,{children:e.footer})]})]},e.title))}),(0,N.jsx)(`div`,{className:`t-qa-grid`,children:[{title:`Take Attendance`,desc:`Mark daily classroom register`,icon:`clipboard-check-fill`,color:`#2563EB`,bg:`#DBEAFE`,route:`/students/attendance`},{title:`Upload Results`,desc:`Score entries & assessments`,icon:`cloud-arrow-up-fill`,color:`#D97706`,bg:`#FEF3C7`,route:`/results/upload`},{title:`AI Lesson Planner`,desc:`Generate term weekly lesson plans`,icon:`journal-richtext`,color:`#7C3AED`,bg:`#EDE9FE`,route:`/settings/ai-lesson-plans`},{title:`Broadsheets & Reports`,desc:`Class broadsheets & report cards`,icon:`file-earmark-bar-graph-fill`,color:`#10B981`,bg:`#D1FAE5`,route:`/reports`}].map(t=>(0,N.jsxs)(`div`,{className:`t-qa-card`,style:{"--qa-color":t.color,"--qa-bg":t.bg},onClick:()=>e(t.route),children:[(0,N.jsx)(`div`,{className:`t-qa-icon`,children:(0,N.jsx)(`i`,{className:`bi bi-${t.icon}`})}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`div`,{className:`t-qa-title`,children:t.title}),(0,N.jsx)(`div`,{className:`t-qa-desc`,children:t.desc})]})]},t.title))}),(0,N.jsxs)(`div`,{className:`row g-4 mb-4`,children:[(0,N.jsx)(`div`,{className:`col-xl-5`,children:(0,N.jsxs)(`div`,{className:`t-panel h-100 mb-0`,children:[(0,N.jsxs)(`div`,{className:`t-panel-head`,children:[(0,N.jsxs)(`h2`,{className:`t-panel-title`,children:[(0,N.jsx)(`i`,{className:`bi bi-lightning-charge-fill text-warning`}),`Priority Action Center`]}),(0,N.jsxs)(`span`,{className:`badge bg-warning-subtle text-warning fw-bold px-2 py-1`,style:{borderRadius:8},children:[A.actions.length,` Tasks`]})]}),(0,N.jsx)(`div`,{className:`t-panel-body`,children:(0,N.jsx)(`div`,{className:`d-flex flex-column gap-3`,children:A.actions.map((t,n)=>{let r=I(t.priority);return(0,N.jsx)(`button`,{type:`button`,className:`border rounded-3 p-3 text-start bg-white w-100 transition-all`,style:{borderColor:r.border,cursor:`pointer`,transition:`all 0.2s ease`},onClick:()=>e(t.route),children:(0,N.jsxs)(`div`,{className:`d-flex gap-3`,children:[(0,N.jsx)(`div`,{className:`rounded-3 d-flex align-items-center justify-content-center flex-shrink-0`,style:{width:42,height:42,backgroundColor:r.bg},children:(0,N.jsx)(`i`,{className:`bi bi-${t.icon}`,style:{color:r.text}})}),(0,N.jsxs)(`div`,{style:{minWidth:0},children:[(0,N.jsxs)(`div`,{className:`d-flex align-items-center gap-2 mb-1`,children:[(0,N.jsx)(`h6`,{className:`mb-0 fw-bold text-truncate`,style:{color:`#0F2744`,fontSize:`14px`},children:t.label}),(0,N.jsx)(`span`,{className:`badge rounded-pill text-capitalize`,style:{backgroundColor:r.bg,color:r.text,fontSize:`10.5px`},children:t.priority})]}),(0,N.jsx)(`p`,{className:`small mb-0`,style:{color:`#64748B`,lineHeight:1.5},children:t.description})]})]})},`${t.label}-${n}`)})})})]})}),(0,N.jsx)(`div`,{className:`col-xl-7`,children:(0,N.jsxs)(`div`,{className:`row g-4 h-100`,children:[(0,N.jsx)(`div`,{className:`col-md-6`,children:(0,N.jsxs)(`div`,{className:`t-panel h-100 mb-0`,children:[(0,N.jsxs)(`div`,{className:`t-panel-head`,children:[(0,N.jsxs)(`div`,{children:[(0,N.jsxs)(`h2`,{className:`t-panel-title`,style:{fontSize:`15px`},children:[(0,N.jsx)(`i`,{className:`bi bi-calendar-check-fill text-success`}),`Attendance Insight`]}),(0,N.jsx)(`small`,{className:`text-muted`,children:A.attendance.date||`Today`})]}),(0,N.jsxs)(`span`,{className:`badge bg-success-subtle text-success fw-bold px-2 py-1`,style:{borderRadius:8},children:[A.attendance.attendance_rate,`%`]})]}),(0,N.jsxs)(`div`,{className:`t-panel-body`,children:[(0,N.jsx)(L,{value:A.attendance.attendance_rate,color:`#16a34a`}),(0,N.jsx)(`div`,{className:`row g-2 mt-3`,children:[{label:`Marked`,value:A.attendance.marked_today,color:`#2563EB`},{label:`Present`,value:A.attendance.present_today,color:`#16A34A`},{label:`Absent`,value:A.attendance.absent_today,color:`#DC2626`},{label:`Late`,value:A.attendance.late_today,color:`#F59E0B`}].map(e=>(0,N.jsx)(`div`,{className:`col-6`,children:(0,N.jsxs)(`div`,{className:`rounded-3 p-2 text-center`,style:{backgroundColor:`#F8FAFC`,border:`1px solid #E2E8F0`},children:[(0,N.jsx)(`div`,{className:`small text-muted`,style:{fontSize:`11px`,fontWeight:600},children:e.label}),(0,N.jsx)(`div`,{className:`fw-bold`,style:{color:e.color,fontSize:`16px`},children:e.value})]})},e.label))}),A.attendance.classes_needing_attendance.length>0&&(0,N.jsxs)(`div`,{className:`mt-3`,children:[(0,N.jsx)(`div`,{className:`small fw-bold mb-2`,style:{color:`#0F2744`},children:`Arms needing attendance:`}),(0,N.jsx)(`div`,{className:`d-flex flex-column gap-2`,children:A.attendance.classes_needing_attendance.slice(0,3).map(e=>(0,N.jsxs)(`div`,{className:`d-flex justify-content-between small p-2 rounded-2`,style:{background:`#FEF2F2`,border:`1px solid #FEE2E2`},children:[(0,N.jsx)(`span`,{className:`text-truncate fw-semibold`,style:{color:`#991B1B`},children:e.class_name}),(0,N.jsxs)(`span`,{className:`text-danger fw-bold`,children:[e.missing_count,` unmarked`]})]},e.class_id))})]})]})]})}),(0,N.jsx)(`div`,{className:`col-md-6`,children:(0,N.jsxs)(`div`,{className:`t-panel h-100 mb-0`,children:[(0,N.jsxs)(`div`,{className:`t-panel-head`,children:[(0,N.jsxs)(`div`,{children:[(0,N.jsxs)(`h2`,{className:`t-panel-title`,style:{fontSize:`15px`},children:[(0,N.jsx)(`i`,{className:`bi bi-file-earmark-check-fill text-primary`}),`Result Progress`]}),(0,N.jsxs)(`small`,{className:`text-muted`,children:[A.results.completed_batches,`/`,A.results.total_batches,` completed`]})]}),(0,N.jsxs)(`span`,{className:`badge bg-primary-subtle text-primary fw-bold px-2 py-1`,style:{borderRadius:8},children:[A.results.completion_percent,`%`]})]}),(0,N.jsxs)(`div`,{className:`t-panel-body`,children:[(0,N.jsx)(L,{value:A.results.completion_percent,color:`#2563EB`}),(0,N.jsxs)(`div`,{className:`mt-3`,children:[(0,N.jsxs)(`div`,{className:`d-flex justify-content-between small mb-2`,children:[(0,N.jsx)(`span`,{className:`text-muted fw-semibold`,children:`Pending Result Batches`}),(0,N.jsx)(`span`,{className:`fw-bold`,style:{color:`#0F2744`},children:A.results.pending_batches_count})]}),(0,N.jsx)(`div`,{className:`d-flex flex-column gap-2`,children:A.results.pending_batches.length>0?A.results.pending_batches.slice(0,3).map(e=>(0,N.jsxs)(`div`,{className:`rounded-3 p-2`,style:{backgroundColor:`#F8FAFC`,border:`1px solid #E2E8F0`},children:[(0,N.jsxs)(`div`,{className:`d-flex justify-content-between gap-2 small`,children:[(0,N.jsxs)(`span`,{className:`fw-bold text-truncate`,style:{color:`#0F2744`},children:[e.class_name,` - `,e.term]}),(0,N.jsx)(`span`,{className:`text-muted`,children:e.session})]}),(0,N.jsxs)(`div`,{className:`small text-muted mt-1`,children:[e.entered_count,`/`,e.expected_count,` scores entered`]})]},e.id)):(0,N.jsx)(`div`,{className:`small text-muted p-3 text-center rounded-3`,style:{background:`#F8FAFC`},children:`All current result batches are up to date!`})})]})]})]})})]})})]}),(0,N.jsxs)(`div`,{className:`row g-4 mb-4`,children:[(0,N.jsx)(`div`,{className:`col-lg-8`,children:(0,N.jsxs)(`div`,{className:`t-panel h-100 mb-0`,children:[(0,N.jsxs)(`div`,{className:`t-panel-head`,children:[(0,N.jsxs)(`h2`,{className:`t-panel-title`,children:[(0,N.jsx)(`i`,{className:`bi bi-activity text-primary`}),`Results Activity & Score Log`]}),(0,N.jsx)(`small`,{className:`text-muted`,children:`Recent assessment distribution`})]}),(0,N.jsx)(`div`,{className:`t-panel-body`,children:(0,N.jsx)(`div`,{style:{height:300},children:(0,N.jsx)(`canvas`,{ref:m})})})]})}),(0,N.jsx)(`div`,{className:`col-lg-4`,children:(0,N.jsxs)(`div`,{className:`t-panel h-100 mb-0`,children:[(0,N.jsxs)(`div`,{className:`t-panel-head`,children:[(0,N.jsxs)(`h2`,{className:`t-panel-title`,children:[(0,N.jsx)(`i`,{className:`bi bi-bar-chart-fill text-success`}),`Term Performance Trend`]}),(0,N.jsx)(`small`,{className:`text-muted`,children:`Average score by term`})]}),(0,N.jsx)(`div`,{className:`t-panel-body`,children:(0,N.jsx)(`div`,{style:{height:300},children:(0,N.jsx)(`canvas`,{ref:g})})})]})})]}),(0,N.jsxs)(`div`,{className:`t-panel mb-4`,children:[(0,N.jsxs)(`div`,{className:`t-panel-head`,children:[(0,N.jsx)(`div`,{className:`d-flex align-items-center gap-2`,children:(0,N.jsxs)(`h2`,{className:`t-panel-title`,children:[(0,N.jsx)(`i`,{className:`bi bi-person-lines-fill text-warning`}),`Student Academic Performance Watch`]})}),(0,N.jsx)(`div`,{className:`d-flex flex-wrap gap-2`,children:[{label:`Tracked`,value:O.summary.tracked_students,color:`#2563EB`},{label:`High Honors`,value:O.summary.strong_count,color:`#16A34A`},{label:`Needs Support`,value:O.summary.struggling_count,color:`#DC2626`},{label:`Class Avg`,value:`${O.summary.class_average}%`,color:`#7C3AED`}].map(e=>(0,N.jsxs)(`div`,{className:`px-3 py-1 rounded-3`,style:{backgroundColor:`#F8FAFC`,border:`1px solid #E2E8F0`},children:[(0,N.jsxs)(`span`,{className:`small text-muted me-2`,style:{fontSize:`11px`,fontWeight:600},children:[e.label,`:`]}),(0,N.jsx)(`span`,{className:`fw-bold`,style:{color:e.color,fontSize:`13px`},children:e.value})]},e.label))})]}),(0,N.jsx)(`div`,{className:`t-panel-body`,children:(0,N.jsxs)(`div`,{className:`row g-4`,children:[(0,N.jsxs)(`div`,{className:`col-lg-6`,children:[(0,N.jsxs)(`div`,{className:`d-flex align-items-center justify-content-between mb-3`,children:[(0,N.jsxs)(`h6`,{className:`mb-0 fw-bold`,style:{color:`#991B1B`,fontSize:`14px`},children:[(0,N.jsx)(`i`,{className:`bi bi-exclamation-triangle-fill me-1`}),`Students Needing Support`]}),(0,N.jsx)(`span`,{className:`badge bg-danger-subtle text-danger fw-bold`,children:O.struggling_students.length})]}),(0,N.jsx)(`div`,{className:`d-flex flex-column gap-3`,children:O.struggling_students.length>0?O.struggling_students.map(e=>(0,N.jsx)(z,{student:e,variant:`support`},e.id)):(0,N.jsxs)(`div`,{className:`border rounded-3 p-4 text-center bg-white`,children:[(0,N.jsx)(`i`,{className:`bi bi-check2-circle fs-3 text-success d-block mb-2`}),(0,N.jsx)(`p`,{className:`mb-0 text-muted`,children:`No struggling students identified from available records.`})]})})]}),(0,N.jsxs)(`div`,{className:`col-lg-6`,children:[(0,N.jsxs)(`div`,{className:`d-flex align-items-center justify-content-between mb-3`,children:[(0,N.jsxs)(`h6`,{className:`mb-0 fw-bold`,style:{color:`#166534`,fontSize:`14px`},children:[(0,N.jsx)(`i`,{className:`bi bi-trophy-fill me-1`}),`Top Performing Students`]}),(0,N.jsx)(`span`,{className:`badge bg-success-subtle text-success fw-bold`,children:O.top_performers.length})]}),(0,N.jsx)(`div`,{className:`d-flex flex-column gap-3`,children:O.top_performers.length>0?O.top_performers.map(e=>(0,N.jsx)(z,{student:e,variant:`strong`},e.id)):(0,N.jsxs)(`div`,{className:`border rounded-3 p-4 text-center bg-white`,children:[(0,N.jsx)(`i`,{className:`bi bi-bar-chart fs-3 text-primary d-block mb-2`}),(0,N.jsx)(`p`,{className:`mb-0 text-muted`,children:`Performance analysis will appear once scores are uploaded.`})]})})]})]})})]}),(0,N.jsx)(lt,{})]})]})})]})}var St={student:{id:0,name:`Student`},stats:{subjects:0,attendance_rate:0,fee_balance:0,unread_notifications:0,results_count:0,avg_score:0},fees:{total_fees:0,total_paid:0,balance:0},charts:{performance:[],access:{labels:[`Mon`,`Tue`,`Wed`,`Thu`,`Fri`,`Sat`,`Sun`],data:[0,0,0,0,0,0,0]}},recent_notifications:[]};function Ct(){let e=new Date().getHours();return e<12?`Good morning`:e<17?`Good afternoon`:`Good evening`}function wt(e){return new Intl.NumberFormat(`en-NG`,{style:`currency`,currency:`NGN`}).format(Number(e||0))}function Tt(e){if(!e)return`Not available`;let t=new Date(e);return Number.isNaN(t.getTime())?e:t.toLocaleDateString(void 0,{day:`2-digit`,month:`short`,year:`numeric`})}function Et(e){return e?e.has_result?e.is_published?{label:`Available now`,text:`Your current term result has been published.`,tone:`success`}:{label:`Waiting for release`,text:`Your result has been prepared. It will show here after the school publishes it.`,tone:`warning`}:{label:`Not entered yet`,text:`Your scores for this term have not been entered yet.`,tone:`muted`}:{label:`No current result`,text:`The school has not prepared your current term result yet.`,tone:`muted`}}function $(e){return!!(e?.is_published&&e?.has_result)}function Dt(e){let t=typeof e?.data==`string`?(()=>{try{return JSON.parse(e.data)}catch{return{}}})():e?.data||{};return{title:t.title||t.subject||e?.type?.split(`\\`).pop()||`Notification`,body:t.message||t.body||`Open notifications to read more.`}}function Ot(){let e=d(),[t,n]=(0,_.useState)(!1),[r,i]=(0,_.useState)(!0),[a,o]=(0,_.useState)(``),[s,c]=(0,_.useState)(``),[l,u]=(0,_.useState)(``),[f,p]=(0,_.useState)(St),m=(0,_.useRef)(null),g=(0,_.useRef)(null),v=(0,_.useRef)(null),y=(0,_.useRef)(null),b=$(f.current_result)?f.current_result:f.latest_published_result,x=$(b)?b:f.current_result,S=$(f.current_result)?Et(f.current_result):$(f.latest_published_result)?{label:`Latest result available`,text:`${f.latest_published_result?.term||`Latest term`} - ${f.latest_published_result?.session||`Academic session`} has been published. Your current term result is still waiting for release.`,tone:`success`}:Et(f.current_result),C=f.fees.total_fees>0?Math.min(100,Math.round(f.fees.total_paid/f.fees.total_fees*100)):0,w=(0,_.useMemo)(()=>{let e=f.charts.performance||[],t=e.length?e[e.length-1]?.average:f.stats.avg_score;return Number(t||0).toFixed(1)},[f]);(0,_.useEffect)(()=>{let e=!0;return i(!0),o(``),Promise.allSettled([B.get(`/current-session-term`),B.get(`/student/dashboard`)]).then(([t,n])=>{e&&(t.status===`fulfilled`&&(c(t.value.data.session||``),u(t.value.data.term||``)),n.status===`fulfilled`?p({...St,...n.value.data,charts:{performance:n.value.data.charts?.performance||[],access:n.value.data.charts?.access?.labels?.length?n.value.data.charts.access:St.charts.access},recent_notifications:Array.isArray(n.value.data.recent_notifications)?n.value.data.recent_notifications:[]}):o(n.reason?.response?.data?.message||`Unable to load your dashboard.`))}).finally(()=>e&&i(!1)),()=>{e=!1}},[]),(0,_.useEffect)(()=>{if(!m.current||!g.current)return;let e=m.current.getContext(`2d`),t=g.current.getContext(`2d`);if(!e||!t)return;v.current?.destroy(),y.current?.destroy();let n=f.charts.performance||[];return v.current=new h(e,{type:`bar`,data:{labels:n.map(e=>e.label),datasets:[{label:`Average`,data:n.map(e=>Number(e.average||0)),backgroundColor:`rgba(211,0,176,0.82)`,borderRadius:7,barThickness:34}]},options:{responsive:!0,maintainAspectRatio:!1,plugins:{legend:{display:!1}},scales:{x:{grid:{display:!1},ticks:{color:`#8a7d72`,font:{size:11}}},y:{beginAtZero:!0,grid:{color:`rgba(5,0,8,0.06)`},ticks:{color:`#8a7d72`,font:{size:11}}}}}}),y.current=new h(t,{type:`line`,data:{labels:f.charts.access.labels,datasets:[{label:`Result views`,data:f.charts.access.data,borderColor:`rgb(255,200,87)`,backgroundColor:`rgba(255,200,87,0.18)`,pointBackgroundColor:`rgb(255,200,87)`,pointBorderColor:`#fff`,pointRadius:4,tension:.38,fill:!0}]},options:{responsive:!0,maintainAspectRatio:!1,plugins:{legend:{display:!1}},scales:{x:{grid:{display:!1},ticks:{color:`#8a7d72`,font:{size:11}}},y:{beginAtZero:!0,grid:{color:`rgba(5,0,8,0.06)`},ticks:{color:`#8a7d72`,font:{size:11},precision:0}}}}}),()=>{v.current?.destroy(),y.current?.destroy()}},[f.charts]);let T=()=>{let t=b;$(t)&&e(`/students/results/show`,{state:{studentId:t.student_id,classId:t.class_id,term:t.term,session:t.session,schoolId:t.school_id}})};return(0,N.jsxs)(N.Fragment,{children:[(0,N.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');
        :root{
          --sd-bg: #F8FAFC;
          --sd-dark: #0F2744;
          --sd-primary: #0F2744;
          --sd-gold: #D97706;
          --sd-border: #E2E8F0;
          --sd-radius: 16px;
        }
        .sd-main{
          background: var(--sd-bg);
          min-height: 100vh;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          padding: 24px 28px 0;
          overflow-x: hidden;
        }
        .sd-hero{
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: var(--sd-radius);
          padding: 32px;
          position: relative;
          overflow: hidden;
          color: #fff;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
          margin: 0 0 24px;
        }
        .sd-hero-inner{
          position: relative;
          z-index: 1;
          display: grid;
          grid-template-columns: minmax(0,1fr) 280px;
          gap: 24px;
          align-items: center;
        }
        .sd-pill-row{
          display: flex;
          gap: 8px;
          flex-wrap: wrap;
          margin-bottom: 14px;
        }
        .sd-pill{
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 4px 12px;
          border-radius: 999px;
          background: rgba(217, 119, 6, 0.2);
          border: 1px solid rgba(217, 119, 6, 0.35);
          font-size: 11.5px;
          font-weight: 700;
          color: #FBBF24;
        }
        .sd-title{
          font-size: clamp(22px,2.6vw,32px);
          font-weight: 800;
          margin: 0 0 8px;
        }
        .sd-title span{color: #FBBF24}
        .sd-sub{
          font-size: 13.5px;
          color: #CBD5E1;
          line-height: 1.6;
          max-width: 620px;
          margin: 0 0 20px;
        }
        .sd-actions{
          display: flex;
          gap: 10px;
          flex-wrap: wrap;
        }
        .sd-btn{
          border: 0;
          border-radius: 10px;
          padding: 9px 18px;
          font-size: 13px;
          font-weight: 700;
          display: inline-flex;
          align-items: center;
          gap: 8px;
          text-decoration: none;
          cursor: pointer;
          transition: all 0.2s ease;
        }
        .sd-btn-gold{
          background: #D97706;
          color: #FFFFFF;
        }
        .sd-btn-gold:hover{
          background: #B45309;
          transform: translateY(-1px);
        }
        .sd-btn-light{
          background: rgba(255,255,255,0.1);
          border: 1px solid rgba(255,255,255,0.2);
          color: #fff;
        }
        .sd-btn-light:hover{
          background: rgba(255,255,255,0.18);
        }
        .sd-profile-card{
          background: rgba(255,255,255,0.08);
          border: 1px solid rgba(255,255,255,0.15);
          backdrop-filter: blur(8px);
          border-radius: 14px;
          padding: 20px;
        }
        .sd-profile-stat{
          display: flex;
          justify-content: space-between;
          gap: 12px;
          padding: 10px 0;
          border-bottom: 1px solid rgba(255,255,255,0.08);
        }
        .sd-profile-stat:last-child{border-bottom: 0}
        .sd-profile-label{font-size: 12px; color: #CBD5E1}
        .sd-profile-value{font-size: 15px; font-weight: 800; color: #FBBF24; text-align: right}
        .sd-grid{display: grid; grid-template-columns: 1.2fr .8fr; gap: 20px; margin-bottom: 24px}
        .sd-stats{display: grid; grid-template-columns: repeat(4,minmax(0,1fr)); gap: 16px; margin-bottom: 24px}
        .sd-card{
          background: #fff;
          border: 1px solid var(--sd-border);
          border-radius: var(--sd-radius);
          box-shadow: 0 4px 16px rgba(15, 39, 68, 0.03);
          min-width: 0;
        }
        .sd-card-pad{padding: 22px 24px}
        .sd-stat{padding: 20px; transition: all 0.2s ease}
        .sd-stat:hover{transform: translateY(-2px); box-shadow: 0 8px 24px rgba(15, 39, 68, 0.06); border-color: #CBD5E1}
        .sd-stat-icon{width: 42px; height: 42px; border-radius: 12px; display: flex; align-items: center; justify-content: center; margin-bottom: 12px; font-size: 18px}
        .sd-stat-label{font-size: 12.5px; font-weight: 600; color: #64748B; margin: 0 0 4px}
        .sd-stat-value{font-size: 24px; font-weight: 800; color: var(--sd-dark); margin: 0}
        .sd-stat-sub{font-size: 11.5px; color: #94A3B8; margin-top: 4px}
        .sd-card-head{display: flex; align-items: center; justify-content: space-between; gap: 12px; margin-bottom: 16px}
        .sd-card-title{font-size: 16px; font-weight: 800; color: var(--sd-dark); margin: 0}
        .sd-card-sub{font-size: 12px; color: #64748B; margin: 2px 0 0}
        .sd-result-card{display: grid; grid-template-columns: minmax(0,1fr) auto; gap: 20px; align-items: center}
        .sd-result-badge{display: inline-flex; align-items: center; gap: 6px; border-radius: 999px; padding: 4px 10px; font-size: 11px; font-weight: 700; margin-bottom: 8px}
        .sd-result-badge.success{color: #065F46; background: #D1FAE5}
        .sd-result-badge.warning{color: #92400E; background: #FEF3C7}
        .sd-result-badge.muted{color: #475569; background: #F1F5F9}
        .sd-result-title{font-size: 18px; font-weight: 800; color: var(--sd-dark); margin: 0 0 4px}
        .sd-result-text{font-size: 13px; color: #475569; line-height: 1.5; margin: 0}
        .sd-result-metrics{display: flex; gap: 10px; flex-wrap: wrap; margin-top: 14px}
        .sd-mini{background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 10px; padding: 8px 14px; min-width: 90px}
        .sd-mini-label{font-size: 10.5px; font-weight: 600; color: #64748B}
        .sd-mini-value{font-size: 15px; font-weight: 800; color: var(--sd-dark)}
        .sd-chart{height: 260px}
        .sd-fee-track,.sd-att-track{height: 8px; border-radius: 999px; background: #F1F5F9; overflow: hidden}
        .sd-fee-fill,.sd-att-fill{height: 100%; border-radius: 999px; background: #D97706}
        .sd-list{display: flex; flex-direction: column; gap: 10px}
        .sd-note{padding: 12px 14px; border-radius: 10px; background: #F8FAFC; border: 1px solid #E2E8F0}
        .sd-note-title{font-size: 13px; font-weight: 700; color: var(--sd-dark); margin: 0 0 3px}
        .sd-note-body{font-size: 12px; color: #64748B; margin: 0; line-height: 1.5}
        .sd-empty{padding: 24px; border-radius: 12px; border: 1px dashed #CBD5E1; color: #64748B; background: #F8FAFC; font-size: 13px; text-align: center}
        .sd-error{background: #FEF2F2; border: 1px solid #FECACA; color: #DC2626; border-radius: 10px; padding: 12px 14px; margin-bottom: 16px; font-size: 13px}
        @media(max-width:1199.98px){.sd-stats{grid-template-columns:repeat(2,minmax(0,1fr))}.sd-grid{grid-template-columns:1fr}.sd-hero-inner{grid-template-columns:1fr}}
        @media(max-width:575.98px){.sd-main{padding:18px 14px 0}.sd-stats{grid-template-columns:1fr}.sd-result-card{grid-template-columns:1fr}.sd-actions .sd-btn{width:100%;justify-content:center}.sd-profile-card{display:none}}
      `}),(0,N.jsx)(st,{sidebarOpen:t,setSidebarOpen:n}),(0,N.jsx)(Y,{title:`Student Dashboard`}),(0,N.jsx)(`div`,{className:`container-fluid`,children:(0,N.jsxs)(`div`,{className:`row`,children:[(0,N.jsx)(ct,{sidebarOpen:t,setSidebarOpen:n}),(0,N.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto sd-main`,children:[r&&(0,N.jsx)(G,{message:`Loading student dashboard...`}),a&&(0,N.jsxs)(`div`,{className:`sd-error`,children:[(0,N.jsx)(`i`,{className:`bi bi-exclamation-circle me-2`}),a]}),(0,N.jsx)(`section`,{className:`sd-hero`,children:(0,N.jsxs)(`div`,{className:`sd-hero-inner`,children:[(0,N.jsxs)(`div`,{children:[(0,N.jsxs)(`div`,{className:`sd-pill-row`,children:[(0,N.jsxs)(`span`,{className:`sd-pill`,children:[(0,N.jsx)(`i`,{className:`bi bi-calendar-check`}),s||`Academic session`,` • `,l||`Current term`]}),f.student.class&&(0,N.jsxs)(`span`,{className:`sd-pill`,children:[(0,N.jsx)(`i`,{className:`bi bi-mortarboard`}),f.student.class]}),f.student.reg_no&&(0,N.jsxs)(`span`,{className:`sd-pill`,children:[(0,N.jsx)(`i`,{className:`bi bi-person-badge`}),f.student.reg_no]})]}),(0,N.jsxs)(`h1`,{className:`sd-title`,children:[Ct(),`, `,(0,N.jsx)(`span`,{children:f.student.name||`Student`})]}),(0,N.jsx)(`p`,{className:`sd-sub`,children:`Track your attendance, fees, notices and published results from one simple dashboard.`}),(0,N.jsxs)(`div`,{className:`sd-actions`,children:[(0,N.jsxs)(`button`,{className:`sd-btn sd-btn-gold`,onClick:T,disabled:!$(b),children:[(0,N.jsx)(`i`,{className:`bi bi-journal-check`}),` `,$(f.current_result)?`View Current Result`:`View Latest Result`]}),(0,N.jsxs)(`button`,{className:`sd-btn sd-btn-light`,onClick:()=>e(`/student/my-fees`),children:[(0,N.jsx)(`i`,{className:`bi bi-wallet2`}),` My Fees`]}),(0,N.jsxs)(`button`,{className:`sd-btn sd-btn-light`,onClick:()=>e(`/notifications`),children:[(0,N.jsx)(`i`,{className:`bi bi-bell`}),` Notices`]})]})]}),(0,N.jsxs)(`div`,{className:`sd-profile-card`,children:[(0,N.jsxs)(`div`,{className:`sd-profile-stat`,children:[(0,N.jsx)(`span`,{className:`sd-profile-label`,children:`Average score`}),(0,N.jsxs)(`span`,{className:`sd-profile-value`,children:[w,`%`]})]}),(0,N.jsxs)(`div`,{className:`sd-profile-stat`,children:[(0,N.jsx)(`span`,{className:`sd-profile-label`,children:`Attendance`}),(0,N.jsxs)(`span`,{className:`sd-profile-value`,children:[f.stats.attendance_rate||0,`%`]})]}),(0,N.jsxs)(`div`,{className:`sd-profile-stat`,children:[(0,N.jsx)(`span`,{className:`sd-profile-label`,children:`Fee balance`}),(0,N.jsx)(`span`,{className:`sd-profile-value`,children:wt(f.fees.balance)})]})]})]})}),(0,N.jsx)(`section`,{className:`sd-card sd-card-pad mb-3`,children:(0,N.jsxs)(`div`,{className:`sd-result-card`,children:[(0,N.jsxs)(`div`,{children:[(0,N.jsxs)(`span`,{className:`sd-result-badge ${S.tone}`,children:[(0,N.jsx)(`i`,{className:`bi bi-circle-fill`,style:{fontSize:7}}),S.label]}),(0,N.jsxs)(`h2`,{className:`sd-result-title`,children:[x?.term||l||`Current Term`,` Result`]}),(0,N.jsx)(`p`,{className:`sd-result-text`,children:S.text}),(0,N.jsxs)(`div`,{className:`sd-result-metrics`,children:[(0,N.jsxs)(`div`,{className:`sd-mini`,children:[(0,N.jsx)(`div`,{className:`sd-mini-label`,children:`Average`}),(0,N.jsx)(`div`,{className:`sd-mini-value`,children:x?.average??`N/A`})]}),(0,N.jsxs)(`div`,{className:`sd-mini`,children:[(0,N.jsx)(`div`,{className:`sd-mini-label`,children:`Grade`}),(0,N.jsx)(`div`,{className:`sd-mini-value`,children:x?.grade??`N/A`})]}),(0,N.jsxs)(`div`,{className:`sd-mini`,children:[(0,N.jsx)(`div`,{className:`sd-mini-label`,children:`Position`}),(0,N.jsx)(`div`,{className:`sd-mini-value`,children:x?.position??`N/A`})]})]})]}),(0,N.jsxs)(`button`,{className:`sd-btn sd-btn-gold`,onClick:T,disabled:!$(b),children:[(0,N.jsx)(`i`,{className:`bi bi-eye`}),` `,$(f.current_result)?`Open Result`:`Open Latest Result`]})]})}),(0,N.jsx)(`section`,{className:`sd-stats`,children:[{label:`Subjects`,value:f.stats.subjects,sub:`Registered subjects`,icon:`book`,bg:`rgba(211,0,176,.08)`,color:`var(--sd-primary)`},{label:`Attendance`,value:`${f.stats.attendance_rate||0}%`,sub:`Current attendance rate`,icon:`clipboard-check`,bg:`rgba(34,197,94,.1)`,color:`#16a34a`},{label:`Fee Balance`,value:wt(f.stats.fee_balance),sub:`Outstanding school fees`,icon:`wallet2`,bg:`rgba(245,158,11,.12)`,color:`#b45309`},{label:`Notices`,value:f.stats.unread_notifications,sub:`Unread messages`,icon:`bell`,bg:`rgba(59,130,246,.1)`,color:`#2563eb`}].map(e=>(0,N.jsxs)(`div`,{className:`sd-card sd-stat`,children:[(0,N.jsx)(`div`,{className:`sd-stat-icon`,style:{background:e.bg,color:e.color},children:(0,N.jsx)(`i`,{className:`bi bi-${e.icon}`})}),(0,N.jsx)(`p`,{className:`sd-stat-label`,children:e.label}),(0,N.jsx)(`p`,{className:`sd-stat-value`,children:e.value}),(0,N.jsx)(`div`,{className:`sd-stat-sub`,children:e.sub})]},e.label))}),(0,N.jsxs)(`section`,{className:`sd-grid`,children:[(0,N.jsxs)(`div`,{className:`sd-card sd-card-pad`,children:[(0,N.jsxs)(`div`,{className:`sd-card-head`,children:[(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`h3`,{className:`sd-card-title`,children:`Performance Trend`}),(0,N.jsx)(`p`,{className:`sd-card-sub`,children:`Your average score by term`})]}),(0,N.jsxs)(`span`,{className:`sd-pill`,style:{color:`#5f5147`,borderColor:`rgba(5,0,8,.08)`,background:`var(--sd-bg)`},children:[f.stats.results_count,` result record`,f.stats.results_count===1?``:`s`]})]}),(0,N.jsx)(`div`,{className:`sd-chart`,children:(0,N.jsx)(`canvas`,{ref:m})})]}),(0,N.jsxs)(`div`,{className:`sd-card sd-card-pad`,children:[(0,N.jsx)(`div`,{className:`sd-card-head`,children:(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`h3`,{className:`sd-card-title`,children:`Fees`}),(0,N.jsx)(`p`,{className:`sd-card-sub`,children:`Payment summary`})]})}),(0,N.jsxs)(`div`,{className:`sd-result-metrics mb-3`,children:[(0,N.jsxs)(`div`,{className:`sd-mini`,children:[(0,N.jsx)(`div`,{className:`sd-mini-label`,children:`Paid`}),(0,N.jsx)(`div`,{className:`sd-mini-value`,children:wt(f.fees.total_paid)})]}),(0,N.jsxs)(`div`,{className:`sd-mini`,children:[(0,N.jsx)(`div`,{className:`sd-mini-label`,children:`Balance`}),(0,N.jsx)(`div`,{className:`sd-mini-value`,children:wt(f.fees.balance)})]})]}),(0,N.jsxs)(`div`,{className:`sd-progress-text d-flex justify-content-between mb-2`,children:[(0,N.jsxs)(`small`,{children:[C,`% paid`]}),(0,N.jsx)(`small`,{children:Tt(f.fees.last_payment_date)})]}),(0,N.jsx)(`div`,{className:`sd-fee-track`,children:(0,N.jsx)(`div`,{className:`sd-fee-fill`,style:{width:`${C}%`}})}),(0,N.jsxs)(`button`,{className:`sd-btn sd-btn-gold mt-3`,onClick:()=>e(`/student/my-fees`),children:[(0,N.jsx)(`i`,{className:`bi bi-receipt`}),` View Fee Details`]})]})]}),(0,N.jsxs)(`section`,{className:`sd-grid`,children:[(0,N.jsxs)(`div`,{className:`sd-card sd-card-pad`,children:[(0,N.jsx)(`div`,{className:`sd-card-head`,children:(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`h3`,{className:`sd-card-title`,children:`Result View Activity`}),(0,N.jsx)(`p`,{className:`sd-card-sub`,children:`How often you checked results this week`})]})}),(0,N.jsx)(`div`,{className:`sd-chart`,children:(0,N.jsx)(`canvas`,{ref:g})})]}),(0,N.jsxs)(`div`,{className:`sd-card sd-card-pad`,children:[(0,N.jsx)(`div`,{className:`sd-card-head`,children:(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`h3`,{className:`sd-card-title`,children:`Today`}),(0,N.jsx)(`p`,{className:`sd-card-sub`,children:`Next class and recent notices`})]})}),f.next_class?(0,N.jsxs)(`div`,{className:`sd-note mb-3`,children:[(0,N.jsx)(`p`,{className:`sd-note-title`,children:f.next_class.subject_name||f.next_class.subject||`Next class`}),(0,N.jsxs)(`p`,{className:`sd-note-body`,children:[f.next_class.start_time||`Time not set`,` - `,f.next_class.end_time||`Time not set`,` `,f.next_class.venue?`• ${f.next_class.venue}`:``]})]}):(0,N.jsx)(`div`,{className:`sd-empty mb-3`,children:`No class timetable found for today.`}),(0,N.jsxs)(`div`,{className:`sd-list`,children:[(f.recent_notifications||[]).slice(0,3).map(e=>{let t=Dt(e);return(0,N.jsxs)(`div`,{className:`sd-note`,children:[(0,N.jsx)(`p`,{className:`sd-note-title`,children:t.title}),(0,N.jsx)(`p`,{className:`sd-note-body`,children:t.body})]},e.id)}),(!f.recent_notifications||f.recent_notifications.length===0)&&(0,N.jsx)(`div`,{className:`sd-empty`,children:`No recent notices.`})]})]})]}),(0,N.jsx)(lt,{})]})]})})]})}function kt({message:e,type:t,onClose:n,duration:r=3e3}){(0,_.useEffect)(()=>{let e=setTimeout(()=>{n()},r);return()=>clearTimeout(e)},[r,n]);let i={success:(0,N.jsx)(`svg`,{width:`24`,height:`24`,viewBox:`0 0 24 24`,fill:`none`,children:(0,N.jsx)(`path`,{d:`M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z`,fill:`currentColor`})}),error:(0,N.jsx)(`svg`,{width:`24`,height:`24`,viewBox:`0 0 24 24`,fill:`none`,children:(0,N.jsx)(`path`,{d:`M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z`,fill:`currentColor`})}),warning:(0,N.jsx)(`svg`,{width:`24`,height:`24`,viewBox:`0 0 24 24`,fill:`none`,children:(0,N.jsx)(`path`,{d:`M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z`,fill:`currentColor`})}),info:(0,N.jsx)(`svg`,{width:`24`,height:`24`,viewBox:`0 0 24 24`,fill:`none`,children:(0,N.jsx)(`path`,{d:`M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z`,fill:`currentColor`})})};return(0,N.jsxs)(`div`,{className:`toast-notification toast-${t}`,children:[(0,N.jsx)(`div`,{className:`toast-icon`,children:i[t]}),(0,N.jsx)(`div`,{className:`toast-content`,children:(0,N.jsx)(`p`,{className:`toast-message`,children:e})}),(0,N.jsx)(`button`,{className:`toast-close`,onClick:n,"aria-label":`Close`,children:(0,N.jsx)(`svg`,{width:`20`,height:`20`,viewBox:`0 0 20 20`,fill:`none`,children:(0,N.jsx)(`path`,{d:`M15 5L5 15M5 5l10 10`,stroke:`currentColor`,strokeWidth:`2`,strokeLinecap:`round`})})}),(0,N.jsx)(`div`,{className:`toast-progress`,children:(0,N.jsx)(`div`,{className:`toast-progress-bar`,style:{animationDuration:`${r}ms`}})})]})}var At=(0,_.createContext)(void 0);function jt({children:e}){let[t,n]=(0,_.useState)([]),r=(e,t,r=3e3)=>{let i=Date.now();n(n=>[...n,{id:i,message:e,type:t,duration:r}])},i=e=>{n(t=>t.filter(t=>t.id!==e))};return(0,N.jsxs)(At.Provider,{value:{showToast:r,showSuccess:(e,t)=>{r(e,`success`,t)},showError:(e,t)=>{r(e,`error`,t)},showInfo:(e,t)=>{r(e,`info`,t)},showWarning:(e,t)=>{r(e,`warning`,t)}},children:[e,(0,N.jsx)(`div`,{style:{position:`fixed`,top:0,left:0,right:0,zIndex:9999},children:t.map((e,t)=>(0,N.jsx)(`div`,{style:{position:`absolute`,top:`${20+t*80}px`,width:`100%`},children:(0,N.jsx)(kt,{message:e.message,type:e.type,duration:e.duration,onClose:()=>i(e.id)})},e.id))})]})}function Mt(){let e=(0,_.useContext)(At);if(!e)throw Error(`useToast must be used within ToastProvider`);return e}function Nt(e){let t=(e||``).trim().toLowerCase();return!t||t===`free`||t===`core`}function Pt(e){if(Nt(e.plan?.name))return`core`;if(!e.ends_at)return`premium_active`;let t=new Date(e.ends_at);return Number.isNaN(t.getTime())||t.getFullYear()>=2099?`premium_active`:t.getTime()<Date.now()?`premium_expired`:`premium_active`}function Ft(e){return e===`premium_active`?`Premium Active`:e===`premium_expired`?`Premium Expired`:`Core`}function It(e){return e===`premium_active`?`sa-pill good`:e===`premium_expired`?`sa-pill warn`:`sa-pill muted`}function Lt(e){let t=String(e||``).toLowerCase();return t.includes(`active`)?`sa-pill good`:t.includes(`pending`)?`sa-pill warn`:t.includes(`expire`)||t.includes(`cancel`)?`sa-pill danger`:`sa-pill muted`}function Rt(e){try{return new Intl.NumberFormat(`en-NG`,{style:`currency`,currency:`NGN`,maximumFractionDigits:0}).format(Number(e||0))}catch{return`NGN ${Number(e||0).toLocaleString()}`}}function zt(e){if(!e)return`Lifetime / Forever`;let t=new Date(e);return Number.isNaN(t.getTime())?e:t.getFullYear()>=2099?`Lifetime / Forever`:t.toLocaleDateString(`en-GB`,{day:`2-digit`,month:`short`,year:`numeric`})}function Bt(e){return e&&(`${e.surname??``} ${e.firstname??``}`.trim()||e.name||e.email)||`Unknown`}function Vt(e){return e.split(` `).filter(Boolean).slice(0,2).map(e=>e[0]?.toUpperCase()).join(``)||`GQ`}function Ht({title:e,value:t,hint:n,icon:r,tone:i=`pink`}){return(0,N.jsxs)(`div`,{className:`sa-metric tone-${i}`,children:[(0,N.jsxs)(`div`,{className:`sa-metric-top`,children:[(0,N.jsx)(`span`,{className:`sa-metric-icon`,children:(0,N.jsx)(`i`,{className:`bi bi-${r}`})}),(0,N.jsx)(`i`,{className:`bi bi-arrow-up-right sa-metric-arrow`})]}),(0,N.jsx)(`p`,{children:e}),(0,N.jsx)(`h3`,{children:t}),(0,N.jsx)(`small`,{children:n})]})}function Ut({title:e,subtitle:t,action:n,children:r}){return(0,N.jsxs)(`section`,{className:`sa-panel`,children:[(0,N.jsxs)(`div`,{className:`sa-panel-head`,children:[(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`h2`,{children:e}),t&&(0,N.jsx)(`p`,{children:t})]}),n&&(0,N.jsx)(`div`,{children:n})]}),r]})}function Wt({text:e}){return(0,N.jsxs)(`div`,{className:`sa-empty`,children:[(0,N.jsx)(`i`,{className:`bi bi-inbox`}),(0,N.jsx)(`span`,{children:e})]})}function Gt({data:e,perPage:t,sizes:n,onPage:r,onPerPage:i}){return!e||e.last_page<=1?null:(0,N.jsxs)(`div`,{className:`sa-pager`,children:[(0,N.jsxs)(`span`,{children:[`Showing `,e.from??0,` - `,e.to??0,` of `,e.total]}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`select`,{value:t,onChange:e=>i(Number(e.target.value)),children:n.map(e=>(0,N.jsxs)(`option`,{value:e,children:[e,`/page`]},e))}),(0,N.jsx)(`button`,{disabled:e.current_page<=1,onClick:()=>r(Math.max(1,e.current_page-1)),children:(0,N.jsx)(`i`,{className:`bi bi-chevron-left`})}),(0,N.jsxs)(`b`,{children:[e.current_page,` / `,e.last_page]}),(0,N.jsx)(`button`,{disabled:e.current_page>=e.last_page,onClick:()=>r(Math.min(e.last_page,e.current_page+1)),children:(0,N.jsx)(`i`,{className:`bi bi-chevron-right`})})]})]})}function Kt(){let e=d(),{showError:t,showSuccess:n}=Mt(),[r,i]=(0,_.useState)(!1),[a,o]=(0,_.useState)(!0),[s,c]=(0,_.useState)([]),[l,u]=(0,_.useState)(null),[f,p]=(0,_.useState)(null),[m,g]=(0,_.useState)(null),[v,y]=(0,_.useState)(null),[b,x]=(0,_.useState)(null),[S,C]=(0,_.useState)(1),[w,T]=(0,_.useState)(10),[E,D]=(0,_.useState)(``),[O,k]=(0,_.useState)(`all`),[j,M]=(0,_.useState)(``),[P,F]=(0,_.useState)(!1),[I,L]=(0,_.useState)(1),[R,z]=(0,_.useState)(8),[V,ee]=(0,_.useState)(``),[te,ne]=(0,_.useState)(1),[re,ie]=(0,_.useState)(10),[H,ae]=(0,_.useState)([]),[oe,U]=(0,_.useState)(!1),[W,K]=(0,_.useState)({is_active:!1,is_scheduled:!1,is_in_effect:!1,start_time:null,end_time:null,message:`We are working harder to make things better, please hold on...`,activated_at:null,activated_by:null,last_emailed_at:null}),[q,se]=(0,_.useState)(!1),[ce,J]=(0,_.useState)(!1),[X,le]=(0,_.useState)(`immediate`),[ue,de]=(0,_.useState)(`We are working harder to make things better, please hold on...`),[fe,Z]=(0,_.useState)(``),[pe,me]=(0,_.useState)(``),[he,ge]=(0,_.useState)(!0),_e=(0,_.useRef)(null),ve=(0,_.useRef)(null),ye=A(),be=Array.isArray(ye?.super_admin_permissions)?ye.super_admin_permissions:[],Q=e=>be.includes(`all`)||be.includes(e),xe=(0,_.useMemo)(()=>(l?.data||[]).filter(e=>{let t=Pt(e);return O===`core`?t===`core`:O===`premium_active`?t===`premium_active`:O===`premium_expired`?t===`premium_expired`:O===`premium`?t!==`core`:!0}),[l,O]),Se=(0,_.useMemo)(()=>(l?.data||[]).reduce((e,t)=>{let n=Pt(t);return e.total+=1,n===`core`&&(e.core+=1),n===`premium_active`&&(e.active+=1),n===`premium_expired`&&(e.expired+=1),e},{total:0,core:0,active:0,expired:0}),[l]),Ce=(0,_.useMemo)(()=>s.reduce((e,t)=>e+Number(t.revenue||0),0),[s]),we=Number(s[s.length-1]?.revenue||0),Te=(l?.data||[]).filter(e=>String(e.status||``).toLowerCase().includes(`active`)).length,Ee=(0,_.useMemo)(()=>(m?.data||[]).map(e=>e.id),[m]),De=Ee.length>0&&Ee.every(e=>H.includes(e));async function Oe(){try{let e=await B.get(`/superadmin/maintenance-mode/status`);e.data?.status&&(K(e.data.status),e.data.status.message&&de(e.data.status.message),e.data.status.start_time&&Z(e.data.status.start_time),e.data.status.end_time&&me(e.data.status.end_time),e.data.status.is_scheduled&&le(`scheduled`))}catch{}}async function ke(e,r=!1){se(!0);try{let t=await B.post(`/superadmin/maintenance-mode/toggle`,{is_active:e,is_scheduled:r,start_time:r&&fe?fe:void 0,end_time:r&&pe?pe:void 0,message:ue.trim()||void 0,send_email_notification:e||r?he:!1});K(t.data.status),J(!1),n(t.data.message||(e?`Maintenance mode activated.`:`Platform restored online.`))}catch(e){t(e?.response?.data?.message||`Failed to update maintenance mode.`)}finally{se(!1)}}async function Ae(){let e=await B.get(`/monthly-revenue-stats`);c(Array.isArray(e.data?.data)?e.data.data:[]),e.data?.total_active_students!==void 0&&x(Number(e.data.total_active_students))}async function je(e=S,t=w){let n=new URLSearchParams;n.set(`page`,String(e)),n.set(`per_page`,String(t)),E&&n.set(`status`,E),P&&n.set(`active`,`1`),j.trim()&&n.set(`search`,j.trim()),u((await B.get(`/admin/subscriptions?${n.toString()}`)).data?.data||null)}async function Me(e=I,t=R){let n=new URLSearchParams;n.set(`page`,String(e)),n.set(`perPage`,String(t)),V.trim()&&n.set(`search`,V.trim()),p((await B.get(`/admin-users?${n.toString()}`)).data||null)}async function Ne(e=te,t=re){let n=new URLSearchParams;n.set(`page`,String(e)),n.set(`per_page`,String(t)),g((await B.get(`/platform-logs?${n.toString()}`)).data||null)}async function Pe(){y((await B.get(`/superadmin/sales-marketing-materials`,{params:{active_only:1}})).data?.materials?.[0]||null)}async function Fe(e=!1){o(!0);try{let t=[Oe()];(Q(`finance`)||Q(`billing`))&&t.push(Ae(),je()),(Q(`support`)||Q(`billing`)||Q(`finance`))&&t.push(Me()),Q(`audit`)&&t.push(Ne()),(Q(`marketing`)||Q(`sales`))&&t.push(Pe()),await Promise.all(t),e&&n(`Dashboard refreshed.`)}catch(e){t(e?.response?.data?.message||`Failed to load Super Admin dashboard.`)}finally{o(!1)}}(0,_.useEffect)(()=>{Fe(!1)},[]),(0,_.useEffect)(()=>{(Q(`finance`)||Q(`billing`))&&je(S,w).catch(()=>t(`Failed to load subscribers.`))},[S,w]),(0,_.useEffect)(()=>{(Q(`support`)||Q(`billing`)||Q(`finance`))&&Me(I,R).catch(()=>t(`Failed to load schools.`))},[I,R]),(0,_.useEffect)(()=>{Q(`audit`)&&Ne(te,re).catch(()=>t(`Failed to load activity.`))},[te,re]),(0,_.useEffect)(()=>{if(!_e.current)return;let e=_e.current.getContext(`2d`);if(e)return ve.current?.destroy(),ve.current=new h(e,{type:`bar`,data:{labels:s.map(e=>e.month),datasets:[{label:`Revenue`,data:s.map(e=>Number(e.revenue||0)),backgroundColor:`rgba(211,0,176,.78)`,hoverBackgroundColor:`rgba(247,201,72,.95)`,borderRadius:8,barThickness:28}]},options:{responsive:!0,maintainAspectRatio:!1,plugins:{legend:{display:!1},tooltip:{callbacks:{label:e=>Rt(Number(e.raw||0))}}},scales:{x:{grid:{display:!1},ticks:{color:`#766a79`,font:{size:11}}},y:{beginAtZero:!0,grid:{color:`rgba(29,21,31,.08)`},ticks:{color:`#766a79`,font:{size:11}}}}}}),()=>ve.current?.destroy()},[s]);function Ie(){C(1),je(1,w).then(()=>n(`Subscribers updated.`)).catch(()=>t(`Failed to apply subscriber filters.`))}function Le(){L(1),Me(1,R).then(()=>n(`Schools updated.`)).catch(()=>t(`Failed to apply school search.`))}function Re(){ne(1),Ne(1,re).then(()=>n(`Activity reloaded.`)).catch(()=>t(`Failed to reload activity.`))}function ze(e){ae(t=>t.includes(e)?t.filter(t=>t!==e):[...t,e])}function Be(){ae(e=>De?e.filter(e=>!Ee.includes(e)):Array.from(new Set([...e,...Ee])))}async function Ve(){if(H.length&&window.confirm(`Delete ${H.length} selected activity log(s)?`)){U(!0);try{await B.post(`/platform-logs/delete-multiple`,{ids:H}),ae([]),n(`Selected logs deleted.`),await Ne()}catch(e){t(e?.response?.data?.message||`Failed to delete selected logs.`)}finally{U(!1)}}}return(0,N.jsxs)(N.Fragment,{children:[(0,N.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');
        :root{--sa-bg:#F8FAFC;--sa-panel:#fff;--sa-ink:#0F2744;--sa-muted:#64748B;--sa-border:#E2E8F0;--sa-gold:#D97706;--sa-primary:#0F2744;--sa-green:#10B981;--sa-blue:#2563EB;--sa-red:#EF4444}
        .sa-main{min-height:100vh;background:#F8FAFC;font-family:'Plus Jakarta Sans',system-ui,-apple-system,sans-serif;margin-left:280px;width:calc(100% - 280px);max-width:calc(100% - 280px);padding:96px 28px 32px;transition:margin .2s,width .2s}.sa-shell{max-width:1480px;margin:0 auto}.sa-hero{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:24px;align-items:end;background:linear-gradient(135deg,#0A192F 0%,#0F2744 60%,#1E3A8A 100%);border-radius:20px;padding:32px;color:#fff;box-shadow:0 10px 30px -5px rgba(15,39,68,0.15)}.sa-eyebrow{display:inline-flex;align-items:center;gap:8px;color:#FBBF24;font-size:11px;font-weight:800;letter-spacing:.12em;text-transform:uppercase;margin-bottom:10px}.sa-title{font-size:clamp(28px,3.5vw,42px);font-weight:800;letter-spacing:0;line-height:1.1;margin:0 0 10px}.sa-sub{max-width:760px;color:#CBD5E1;line-height:1.6;font-size:14px;margin:0}.sa-hero-actions{display:flex;gap:10px;flex-wrap:wrap;justify-content:flex-end}
        .sa-btn{border:0;border-radius:10px;min-height:40px;padding:9px 16px;display:inline-flex;align-items:center;justify-content:center;gap:8px;font-weight:700;font-size:13px;cursor:pointer;white-space:nowrap;transition:all .2s ease}.sa-btn:disabled{opacity:.55;cursor:not-allowed}.sa-btn-gold{background:#D97706;color:#fff}.sa-btn-gold:hover{background:#B45309;color:#fff}.sa-btn-dark{background:#0F2744;color:#fff}.sa-btn-soft{background:#fff;color:#0F2744;border:1px solid #E2E8F0}.sa-btn-soft:hover{background:#F8FAFC}.sa-btn-light{background:rgba(255,255,255,.12);color:#fff;border:1px solid rgba(255,255,255,.2)}.sa-btn-light:hover{background:rgba(255,255,255,.2)}
        .sa-metrics{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:16px;margin:20px 0}.sa-metric{background:#fff;border:1px solid #E2E8F0;border-radius:16px;padding:20px;box-shadow:0 4px 16px rgba(15,39,68,0.03);transition:all .2s ease}.sa-metric:hover{transform:translateY(-2px);box-shadow:0 10px 24px rgba(15,39,68,0.06);border-color:#CBD5E1}.sa-metric-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px}.sa-metric-icon{width:42px;height:42px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:18px;background:rgba(15,39,68,.08);color:#0F2744}.tone-gold .sa-metric-icon{background:rgba(217,119,6,.12);color:#D97706}.tone-green .sa-metric-icon{background:rgba(16,185,129,.12);color:#10B981}.tone-blue .sa-metric-icon{background:rgba(37,99,235,.12);color:#2563EB}.tone-red .sa-metric-icon{background:rgba(239,68,68,.12);color:#EF4444}.sa-metric p{font-size:12px;color:#64748B;font-weight:700;text-transform:uppercase;letter-spacing:.06em;margin:0 0 6px}.sa-metric h3{font-size:clamp(22px,2.4vw,28px);font-weight:800;color:#0F2744;margin:0;letter-spacing:0}.sa-metric small{font-size:12px;color:#94A3B8}.sa-metric-arrow{color:#CBD5E1;font-size:13px}
        .sa-grid{display:grid;grid-template-columns:minmax(0,1.35fr) minmax(320px,.65fr);gap:20px;margin-bottom:20px}.sa-two{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px}.sa-panel{background:#fff;border:1px solid #E2E8F0;border-radius:18px;box-shadow:0 4px 16px rgba(15,39,68,0.03);overflow:hidden;margin-bottom:20px}.sa-panel-head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:20px 24px;border-bottom:1px solid #F1F5F9}.sa-panel-head h2{color:#0F2744;font-weight:800;font-size:18px;margin:0;letter-spacing:0}.sa-panel-head p{font-size:12.5px;color:#64748B;margin:3px 0 0}.sa-chart{height:310px;padding:20px 24px 24px}.sa-health{display:grid;gap:12px;padding:20px 24px}.sa-health-row{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:14px 16px;border:1px solid #E2E8F0;border-radius:12px;background:#F8FAFC}.sa-health-main{display:flex;align-items:center;gap:10px}.sa-health-icon{width:36px;height:36px;border-radius:10px;display:flex;align-items:center;justify-content:center;background:#fff;border:1px solid #E2E8F0;color:#0F2744}.sa-health-title{font-weight:800;color:#0F2744;font-size:13.5px;margin:0}.sa-health-sub{font-size:12px;color:#64748B;margin:2px 0 0}.sa-health-value{font-weight:800;color:#0F2744;font-size:20px}
        .sa-actions{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:16px;margin-bottom:20px}.sa-action{border:1px solid #E2E8F0;background:#fff;border-radius:16px;padding:18px;text-decoration:none;color:#0F2744;box-shadow:0 4px 16px rgba(15,39,68,0.03);transition:all .2s ease}.sa-action:hover{color:#0F2744;transform:translateY(-2px);border-color:#CBD5E1;box-shadow:0 8px 24px rgba(15,39,68,0.06)}.sa-action i{width:40px;height:40px;border-radius:11px;display:flex;align-items:center;justify-content:center;background:rgba(217,119,6,.12);color:#D97706;font-size:18px;margin-bottom:12px}.sa-action-title{font-weight:800;margin:0 0 4px}.sa-action-sub{font-size:12px;color:#64748B;margin:0;line-height:1.5}
        .sa-filters{display:flex;align-items:center;gap:10px;flex-wrap:wrap;padding:14px 24px;border-bottom:1px solid #F1F5F9;background:#F8FAFC}.sa-input,.sa-select{height:38px;border:1px solid #E2E8F0;background:#fff;border-radius:10px;padding:0 12px;color:#0F2744;font-size:13px;outline:0}.sa-check{display:inline-flex;align-items:center;gap:8px;font-size:12.5px;color:#64748B;font-weight:700}.sa-table-wrap{overflow:auto}.sa-table{width:100%;min-width:760px;border-collapse:collapse}.sa-table th{background:#F8FAFC;color:#64748B;text-transform:uppercase;font-size:11px;font-weight:700;letter-spacing:.06em;padding:12px 16px;border-bottom:1px solid #E2E8F0}.sa-table td{padding:14px 16px;border-bottom:1px solid #F1F5F9;font-size:13.5px;color:#334155;vertical-align:middle}.sa-table tr:hover td{background:#F8FAFC}.sa-name-cell{display:flex;align-items:center;gap:10px;min-width:0}.sa-avatar{width:34px;height:34px;border-radius:10px;background:linear-gradient(135deg,#0F2744,#1E3A8A);color:#fff;font-size:12px;font-weight:800;display:flex;align-items:center;justify-content:center;flex-shrink:0}.sa-main-text{font-weight:800;color:#0F2744;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:240px}.sa-sub-text{font-size:12px;color:#64748B;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:280px}.sa-pill{display:inline-flex;align-items:center;justify-content:center;border-radius:999px;padding:4px 10px;font-size:10.5px;font-weight:700;text-transform:uppercase;letter-spacing:.04em;white-space:nowrap}.sa-pill.good{background:#D1FAE5;color:#065F46}.sa-pill.warn{background:#FEF3C7;color:#92400E}.sa-pill.danger{background:#FEE2E2;color:#991B1B}.sa-pill.muted{background:#F1F5F9;color:#475569}
        .sa-pager{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:14px 24px;color:#64748B;font-size:12.5px}.sa-pager>div{display:flex;align-items:center;gap:8px}.sa-pager select,.sa-pager button{height:34px;border:1px solid #E2E8F0;background:#fff;border-radius:8px;padding:0 10px;color:#0F2744}.sa-pager button:disabled{opacity:.45}.sa-empty{padding:36px 20px;text-align:center;color:#64748B;display:flex;flex-direction:column;align-items:center;gap:8px}.sa-empty i{font-size:28px;color:#CBD5E1}.sa-log-toolbar{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:14px 24px;border-bottom:1px solid #F1F5F9;background:#F8FAFC}.sa-log-select{display:flex;align-items:center;gap:8px;color:#64748B;font-size:12.5px;font-weight:700}.sa-risk{padding:20px 24px;display:grid;gap:12px}.sa-risk-item{display:flex;gap:12px;padding:14px 16px;border-radius:12px;border:1px solid #E2E8F0;background:#F8FAFC}.sa-risk-dot{width:10px;height:10px;border-radius:999px;margin-top:5px;flex-shrink:0}.sa-risk-dot.red{background:#EF4444}.sa-risk-dot.gold{background:#F59E0B}.sa-risk-dot.green{background:#10B981}.sa-risk-title{font-weight:800;color:#0F2744;margin:0 0 3px;font-size:13.5px}.sa-risk-sub{color:#64748B;font-size:12px;line-height:1.5;margin:0}
        @media(max-width:1199px){.sa-main{margin-left:0;width:100%;max-width:100%;padding:92px 16px 28px}.sa-metrics{grid-template-columns:repeat(2,minmax(0,1fr))}.sa-grid,.sa-two{grid-template-columns:1fr}.sa-actions{grid-template-columns:repeat(2,minmax(0,1fr))}.sa-hero{grid-template-columns:1fr}.sa-hero-actions{justify-content:flex-start}}@media(max-width:640px){.sa-main{padding-left:12px;padding-right:12px}.sa-metrics,.sa-actions{grid-template-columns:1fr}.sa-hero{padding:22px}.sa-panel-head,.sa-filters,.sa-log-toolbar,.sa-pager{align-items:flex-start;flex-direction:column}.sa-btn,.sa-input,.sa-select{width:100%}.sa-pager>div{width:100%;justify-content:space-between}.sa-chart{height:260px}}
      `}),(0,N.jsx)(st,{sidebarOpen:r,setSidebarOpen:i,title:`Platform Command Center`}),(0,N.jsx)(Y,{title:`Super Admin Dashboard`}),(0,N.jsx)(`div`,{className:`container-fluid`,children:(0,N.jsxs)(`div`,{className:`row`,children:[(0,N.jsx)(ct,{sidebarOpen:r,setSidebarOpen:i}),(0,N.jsxs)(`main`,{className:`sa-main`,children:[a&&(0,N.jsx)(G,{message:`Loading Super Admin dashboard...`}),(0,N.jsxs)(`div`,{className:`sa-shell`,children:[(0,N.jsxs)(`section`,{className:`sa-hero`,children:[(0,N.jsxs)(`div`,{children:[(0,N.jsxs)(`div`,{className:`sa-eyebrow`,children:[(0,N.jsx)(`i`,{className:`bi bi-shield-lock`}),` SchoolProfit Super Admin`]}),(0,N.jsx)(`h1`,{className:`sa-title`,children:`Platform Command Center`}),(0,N.jsxs)(`p`,{className:`sa-sub`,children:[`Monitor the platform areas assigned to your administrator account. Your access level is `,ye?.super_admin_type_label||`Super Admin`,`.`]})]}),(0,N.jsxs)(`div`,{className:`sa-hero-actions`,children:[(0,N.jsxs)(`button`,{className:`sa-btn sa-btn-light`,onClick:()=>Fe(!0),children:[(0,N.jsx)(`i`,{className:`bi bi-arrow-repeat`}),`Refresh`]}),(0,N.jsxs)(`button`,{className:`sa-btn sa-btn-gold`,onClick:()=>e(`/superadmin/billing-policy`),children:[(0,N.jsx)(`i`,{className:`bi bi-sliders`}),`Billing policy`]})]})]}),(0,N.jsxs)(`section`,{style:{background:W.is_active||W.is_in_effect?`linear-gradient(135deg, #450a0a 0%, #7f1d1d 50%, #991b1b 100%)`:W.is_scheduled?`linear-gradient(135deg, #1e1b4b 0%, #312e81 50%, #4338ca 100%)`:`#ffffff`,color:W.is_active||W.is_in_effect||W.is_scheduled?`#ffffff`:`#0f172a`,border:W.is_active||W.is_in_effect?`2px solid #ef4444`:W.is_scheduled?`2px solid #6366f1`:`1px solid rgba(29,21,31,.1)`,borderRadius:20,padding:`22px 26px`,marginTop:18,marginBottom:18,boxShadow:W.is_active||W.is_in_effect?`0 14px 34px rgba(220, 38, 38, 0.25)`:W.is_scheduled?`0 14px 34px rgba(99, 102, 241, 0.25)`:`0 10px 30px rgba(29,21,31,.05)`,display:`flex`,justifyContent:`space-between`,alignItems:`center`,gap:20,flexWrap:`wrap`},children:[(0,N.jsxs)(`div`,{style:{maxWidth:820},children:[(0,N.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:10,marginBottom:6,flexWrap:`wrap`},children:[(0,N.jsxs)(`span`,{style:{display:`inline-flex`,alignItems:`center`,gap:6,padding:`4px 12px`,borderRadius:999,fontSize:11.5,fontWeight:900,textTransform:`uppercase`,letterSpacing:`0.08em`,background:W.is_active||W.is_in_effect?`#fef2f2`:W.is_scheduled?`#eef2ff`:`#ecfdf5`,color:W.is_active||W.is_in_effect?`#b91c1c`:W.is_scheduled?`#4338ca`:`#047857`,border:`1px solid ${W.is_active||W.is_in_effect?`#fecaca`:W.is_scheduled?`#c7d2fe`:`#a7f3d0`}`},children:[(0,N.jsx)(`i`,{className:`bi ${W.is_active||W.is_in_effect?`bi-exclamation-octagon-fill`:W.is_scheduled?`bi-clock-history`:`bi-patch-check-fill`}`}),W.is_active||W.is_in_effect?`Maintenance Mode Active (Read-Only Mode)`:W.is_scheduled?`Maintenance Scheduled Ahead`:`Platform Live & Operational`]}),W.activated_at&&(0,N.jsxs)(`span`,{style:{fontSize:12,opacity:.85},children:[`Set `,new Date(W.activated_at).toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`}),` by `,W.activated_by||`Super Admin`]}),W.start_time&&(0,N.jsxs)(`span`,{style:{fontSize:12,opacity:.9},children:[`• Start: `,(0,N.jsx)(`strong`,{children:new Date(W.start_time).toLocaleString()})]}),W.end_time&&(0,N.jsxs)(`span`,{style:{fontSize:12,opacity:.9},children:[`• Est. End: `,(0,N.jsx)(`strong`,{children:new Date(W.end_time).toLocaleString()})]})]}),(0,N.jsx)(`h2`,{style:{fontSize:19,fontWeight:900,margin:`0 0 6px`,color:W.is_active||W.is_in_effect||W.is_scheduled?`#ffffff`:`#0f172a`},children:W.is_active||W.is_in_effect?`Platform Maintenance In Progress (Read-Only Portal Access)`:W.is_scheduled?`Scheduled Platform Optimization Upcoming`:`Platform Maintenance & Infrastructure Controls`}),(0,N.jsx)(`p`,{style:{margin:0,fontSize:13,color:W.is_active||W.is_in_effect||W.is_scheduled?`rgba(255,255,255,0.85)`:`#64748b`,lineHeight:1.5},children:W.is_active||W.is_in_effect?`Active Notice: "${W.message}" (School admins can browse records in read-only mode; results publishing, CBT, and parent payments are paused).`:W.is_scheduled?`Scheduled Notice: "${W.message}". Advance emails were dispatched to school administrators.`:`Trigger immediate or scheduled maintenance. School portals remain open in read-only mode while critical mutations (results, CBT, payments) are suspended.`})]}),(0,N.jsx)(`div`,{style:{display:`flex`,gap:10,flexWrap:`wrap`,alignItems:`center`},children:W.is_active||W.is_in_effect||W.is_scheduled?(0,N.jsxs)(`button`,{className:`sa-btn`,style:{background:`#ffffff`,color:`#991b1b`,fontWeight:900,padding:`10px 18px`,boxShadow:`0 4px 12px rgba(0,0,0,0.15)`},onClick:()=>ke(!1,!1),disabled:q,children:[(0,N.jsx)(`i`,{className:`bi bi-power`}),q?`Restoring...`:`End Maintenance (Bring Online)`]}):(0,N.jsxs)(`button`,{className:`sa-btn`,style:{background:`#dc2626`,color:`#ffffff`,fontWeight:900,padding:`10px 18px`},onClick:()=>J(!0),disabled:q,children:[(0,N.jsx)(`i`,{className:`bi bi-tools`}),`Trigger / Schedule Maintenance`]})})]}),ce&&(0,N.jsx)(`div`,{style:{position:`fixed`,inset:0,background:`rgba(15, 23, 42, 0.7)`,display:`flex`,alignItems:`center`,justifyContent:`center`,zIndex:9999,padding:16,backdropFilter:`blur(5px)`},children:(0,N.jsxs)(`div`,{style:{background:`#ffffff`,width:`100%`,maxWidth:580,borderRadius:20,padding:28,boxShadow:`0 24px 60px rgba(0,0,0,0.3)`},children:[(0,N.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:12,marginBottom:16},children:[(0,N.jsx)(`div`,{style:{width:46,height:46,borderRadius:12,background:`#fee2e2`,color:`#dc2626`,display:`flex`,alignItems:`center`,justifyContent:`center`,fontSize:22,flexShrink:0},children:(0,N.jsx)(`i`,{className:`bi bi-tools`})}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`h3`,{style:{fontSize:19,fontWeight:900,margin:0,color:`#0f172a`},children:`Platform Maintenance Controller`}),(0,N.jsx)(`p`,{style:{fontSize:12.5,color:`#64748b`,margin:0},children:`Manage SaaS maintenance windows, read-only mode, and admin broadcasts`})]})]}),(0,N.jsxs)(`div`,{style:{display:`flex`,gap:8,background:`#f1f5f9`,padding:4,borderRadius:12,marginBottom:16},children:[(0,N.jsxs)(`button`,{type:`button`,style:{flex:1,border:`none`,background:X===`immediate`?`#ffffff`:`transparent`,color:X===`immediate`?`#0f172a`:`#64748b`,fontWeight:800,fontSize:13,padding:`8px 12px`,borderRadius:9,boxShadow:X===`immediate`?`0 2px 6px rgba(0,0,0,0.08)`:`none`,cursor:`pointer`},onClick:()=>le(`immediate`),children:[(0,N.jsx)(`i`,{className:`bi bi-lightning-charge me-1`}),` Activate Immediately`]}),(0,N.jsxs)(`button`,{type:`button`,style:{flex:1,border:`none`,background:X===`scheduled`?`#ffffff`:`transparent`,color:X===`scheduled`?`#0f172a`:`#64748b`,fontWeight:800,fontSize:13,padding:`8px 12px`,borderRadius:9,boxShadow:X===`scheduled`?`0 2px 6px rgba(0,0,0,0.08)`:`none`,cursor:`pointer`},onClick:()=>le(`scheduled`),children:[(0,N.jsx)(`i`,{className:`bi bi-calendar-event me-1`}),` Schedule for Later`]})]}),X===`scheduled`&&(0,N.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`1fr 1fr`,gap:12,marginBottom:16},children:[(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`label`,{style:{display:`block`,fontSize:12,fontWeight:800,color:`#334155`,marginBottom:4},children:`Start Date & Time (WAT)`}),(0,N.jsx)(`input`,{type:`datetime-local`,className:`sa-input`,style:{width:`100%`},value:fe,onChange:e=>Z(e.target.value)})]}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`label`,{style:{display:`block`,fontSize:12,fontWeight:800,color:`#334155`,marginBottom:4},children:`Est. End Date & Time (WAT)`}),(0,N.jsx)(`input`,{type:`datetime-local`,className:`sa-input`,style:{width:`100%`},value:pe,onChange:e=>me(e.target.value)})]})]}),(0,N.jsxs)(`div`,{style:{background:`#eff6ff`,border:`1px solid #bfdbfe`,borderRadius:12,padding:`12px 14px`,color:`#1e40af`,fontSize:12.5,marginBottom:16,lineHeight:1.5},children:[(0,N.jsx)(`i`,{className:`bi bi-info-circle-fill me-1`}),(0,N.jsx)(`strong`,{children:`Read-Only Access Enabled:`}),` School Admins and Teachers can still log in and view past records. All score entry, CBT exams, parent payments, and data modifications will be paused until maintenance finishes.`]}),(0,N.jsxs)(`div`,{style:{marginBottom:16},children:[(0,N.jsx)(`label`,{style:{display:`block`,fontSize:12.5,fontWeight:800,color:`#334155`,marginBottom:6},children:`User & Parent Response Message`}),(0,N.jsx)(`textarea`,{style:{width:`100%`,minHeight:70,border:`1px solid #cbd5e1`,borderRadius:10,padding:`10px 12px`,fontSize:13,color:`#0f172a`,outline:`none`,resize:`vertical`},value:ue,onChange:e=>de(e.target.value),placeholder:`We are working harder to make things better, please hold on...`})]}),(0,N.jsx)(`div`,{style:{marginBottom:20},children:(0,N.jsxs)(`label`,{style:{display:`inline-flex`,alignItems:`center`,gap:8,fontSize:13,fontWeight:700,color:`#1e293b`,cursor:`pointer`},children:[(0,N.jsx)(`input`,{type:`checkbox`,checked:he,onChange:e=>ge(e.target.checked),style:{width:16,height:16,accentColor:`#d300b0`}}),(0,N.jsxs)(`span`,{children:[(0,N.jsx)(`i`,{className:`bi bi-envelope-check me-1 text-primary`}),` Send advance broadcast email notification to all active School Owners/Admins (`,f?.total??20,` schools)`]})]})}),(0,N.jsxs)(`div`,{style:{display:`flex`,justifyContent:`flex-end`,gap:10},children:[(0,N.jsx)(`button`,{className:`sa-btn sa-btn-soft`,onClick:()=>J(!1),disabled:q,children:`Cancel`}),(0,N.jsx)(`button`,{className:`sa-btn`,style:{background:X===`immediate`?`#dc2626`:`#4338ca`,color:`#ffffff`,fontWeight:800},onClick:()=>ke(X===`immediate`,X===`scheduled`),disabled:q,children:q?`Processing...`:X===`immediate`?`Confirm & Activate Now`:`Confirm & Schedule Maintenance`})]})]})}),v&&(0,N.jsxs)(`section`,{className:`sa-panel`,style:{display:`grid`,gridTemplateColumns:v.asset_url?`minmax(220px,360px) 1fr`:`1fr`,gap:22,alignItems:`center`},children:[v.asset_url&&v.type!==`copy`&&(v.type===`video`?(0,N.jsx)(`video`,{controls:!0,src:v.asset_url,style:{width:`100%`,maxHeight:210,borderRadius:14}}):(0,N.jsx)(`img`,{src:v.asset_url,alt:v.title,style:{width:`100%`,maxHeight:210,objectFit:`cover`,borderRadius:14}})),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`span`,{className:`sa-pill warn`,children:`Active sales campaign`}),(0,N.jsx)(`h2`,{children:v.title}),(0,N.jsx)(`p`,{className:`sa-sub-text`,children:v.description}),(0,N.jsxs)(`button`,{className:`sa-btn sa-btn-gold`,onClick:()=>e(`/superadmin/sales-marketing-materials`),children:[(0,N.jsx)(`i`,{className:`bi bi-megaphone`}),` Manage campaign`]})]})]}),(0,N.jsxs)(`section`,{className:`sa-metrics`,children:[(0,N.jsx)(Ht,{title:`Admin schools`,value:f?.total??0,hint:`Registered school owners`,icon:`building`}),(0,N.jsx)(Ht,{title:`Active Students`,value:b===null?`...`:b.toLocaleString(),hint:`Across all schools`,icon:`mortarboard`,tone:`green`}),(0,N.jsx)(Ht,{title:`Subscribers`,value:l?.total??0,hint:`${Te} active on this page`,icon:`people`,tone:`blue`}),(0,N.jsx)(Ht,{title:`Premium schools`,value:Se.active,hint:`Active premium on current page`,icon:`stars`,tone:`gold`}),(0,N.jsx)(Ht,{title:`Platform Revenue YTD`,value:Rt(Ce),hint:`${Rt(we)} last recorded month`,icon:`cash-coin`,tone:`pink`})]}),(0,N.jsxs)(`section`,{className:`sa-actions`,children:[(0,N.jsxs)(`a`,{className:`sa-action`,href:`/superadmin/subscribers`,onClick:t=>{t.preventDefault(),e(`/superadmin/subscribers`)},children:[(0,N.jsx)(`i`,{className:`bi bi-people`}),(0,N.jsx)(`p`,{className:`sa-action-title`,children:`Manage Subscribers`}),(0,N.jsx)(`p`,{className:`sa-action-sub`,children:`Review school subscriptions and billing records.`})]}),(0,N.jsxs)(`a`,{className:`sa-action`,href:`/superadmin/billing-policy`,onClick:t=>{t.preventDefault(),e(`/superadmin/billing-policy`)},children:[(0,N.jsx)(`i`,{className:`bi bi-sliders2`}),(0,N.jsx)(`p`,{className:`sa-action-title`,children:`Billing Policy & Bank Charges`}),(0,N.jsx)(`p`,{className:`sa-action-sub`,children:`Configure per-student tiers (₦300/₦500), universal bank charges (₦200), and +1 Year Free promo.`})]}),(0,N.jsxs)(`a`,{className:`sa-action`,href:`/superadmin/twilio-whatsapp`,onClick:t=>{t.preventDefault(),e(`/superadmin/twilio-whatsapp`)},children:[(0,N.jsx)(`i`,{className:`bi bi-whatsapp`}),(0,N.jsx)(`p`,{className:`sa-action-title`,children:`WhatsApp Gateway`}),(0,N.jsx)(`p`,{className:`sa-action-sub`,children:`Check Twilio readiness and testing.`})]}),(0,N.jsxs)(`a`,{className:`sa-action`,href:`/demo-bookers`,onClick:t=>{t.preventDefault(),e(`/demo-bookers`)},children:[(0,N.jsx)(`i`,{className:`bi bi-calendar-check`}),(0,N.jsx)(`p`,{className:`sa-action-title`,children:`Demo Requests`}),(0,N.jsx)(`p`,{className:`sa-action-sub`,children:`Follow up with interested schools.`})]}),(0,N.jsxs)(`a`,{className:`sa-action`,href:`/training/SchoolProfit-School-Training-Deck.pptx`,download:`SchoolProfit-School-Training-Deck.pptx`,children:[(0,N.jsx)(`i`,{className:`bi bi-file-earmark-slides`}),(0,N.jsx)(`p`,{className:`sa-action-title`,children:`Training Presentation`}),(0,N.jsx)(`p`,{className:`sa-action-sub`,children:`Download the editable deck for school and user training.`})]})]}),(0,N.jsxs)(`section`,{className:`sa-grid`,children:[(0,N.jsx)(Ut,{title:`Revenue trend`,subtitle:`Monthly platform revenue performance.`,children:(0,N.jsx)(`div`,{className:`sa-chart`,children:(0,N.jsx)(`canvas`,{ref:_e})})}),(0,N.jsx)(Ut,{title:`Platform health`,subtitle:`Signals that need attention.`,children:(0,N.jsxs)(`div`,{className:`sa-health`,children:[(0,N.jsxs)(`div`,{className:`sa-health-row`,children:[(0,N.jsxs)(`div`,{className:`sa-health-main`,children:[(0,N.jsx)(`div`,{className:`sa-health-icon`,children:(0,N.jsx)(`i`,{className:`bi bi-check-circle`})}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`p`,{className:`sa-health-title`,children:`Active subscribers`}),(0,N.jsx)(`p`,{className:`sa-health-sub`,children:`Active status on current page`})]})]}),(0,N.jsx)(`span`,{className:`sa-health-value`,children:Te})]}),(0,N.jsxs)(`div`,{className:`sa-health-row`,children:[(0,N.jsxs)(`div`,{className:`sa-health-main`,children:[(0,N.jsx)(`div`,{className:`sa-health-icon`,children:(0,N.jsx)(`i`,{className:`bi bi-exclamation-triangle`})}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`p`,{className:`sa-health-title`,children:`Expired premium`}),(0,N.jsx)(`p`,{className:`sa-health-sub`,children:`May need renewal follow-up`})]})]}),(0,N.jsx)(`span`,{className:`sa-health-value`,children:Se.expired})]}),(0,N.jsxs)(`div`,{className:`sa-health-row`,children:[(0,N.jsxs)(`div`,{className:`sa-health-main`,children:[(0,N.jsx)(`div`,{className:`sa-health-icon`,children:(0,N.jsx)(`i`,{className:`bi bi-activity`})}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`p`,{className:`sa-health-title`,children:`Activity logs`}),(0,N.jsx)(`p`,{className:`sa-health-sub`,children:`Recent platform actions`})]})]}),(0,N.jsx)(`span`,{className:`sa-health-value`,children:m?.total??0})]})]})})]}),(0,N.jsxs)(Ut,{title:`Schools and subscriptions`,subtitle:`Monitor current package status and renewal state.`,action:(0,N.jsxs)(`button`,{className:`sa-btn sa-btn-soft`,onClick:Ie,children:[(0,N.jsx)(`i`,{className:`bi bi-funnel`}),`Apply filters`]}),children:[(0,N.jsxs)(`div`,{className:`sa-filters`,children:[(0,N.jsxs)(`select`,{className:`sa-select`,value:E,onChange:e=>D(e.target.value),children:[(0,N.jsx)(`option`,{value:``,children:`All status`}),(0,N.jsx)(`option`,{value:`active`,children:`Active`}),(0,N.jsx)(`option`,{value:`pending`,children:`Pending`}),(0,N.jsx)(`option`,{value:`cancelled`,children:`Cancelled`}),(0,N.jsx)(`option`,{value:`canceled`,children:`Canceled`}),(0,N.jsx)(`option`,{value:`expired`,children:`Expired`})]}),(0,N.jsxs)(`select`,{className:`sa-select`,value:O,onChange:e=>k(e.target.value),children:[(0,N.jsx)(`option`,{value:`all`,children:`All packages`}),(0,N.jsx)(`option`,{value:`core`,children:`Core`}),(0,N.jsx)(`option`,{value:`premium`,children:`Premium schools`}),(0,N.jsx)(`option`,{value:`premium_active`,children:`Premium active`}),(0,N.jsx)(`option`,{value:`premium_expired`,children:`Premium expired`})]}),(0,N.jsx)(`input`,{className:`sa-input`,style:{minWidth:260},placeholder:`Search school owner or email`,value:j,onChange:e=>M(e.target.value)}),(0,N.jsxs)(`label`,{className:`sa-check`,children:[(0,N.jsx)(`input`,{type:`checkbox`,checked:P,onChange:e=>F(e.target.checked)}),`Active only`]})]}),(0,N.jsx)(`div`,{className:`sa-table-wrap`,children:(0,N.jsxs)(`table`,{className:`sa-table`,children:[(0,N.jsx)(`thead`,{children:(0,N.jsxs)(`tr`,{children:[(0,N.jsx)(`th`,{children:`School owner`}),(0,N.jsx)(`th`,{children:`Email`}),(0,N.jsx)(`th`,{children:`Package`}),(0,N.jsx)(`th`,{children:`Tier`}),(0,N.jsx)(`th`,{children:`Status`}),(0,N.jsx)(`th`,{children:`Start`}),(0,N.jsx)(`th`,{children:`End`})]})}),(0,N.jsx)(`tbody`,{children:xe.length===0?(0,N.jsx)(`tr`,{children:(0,N.jsx)(`td`,{colSpan:7,children:(0,N.jsx)(Wt,{text:`No subscribers match this selection.`})})}):xe.map(e=>{let t=Pt(e),n=Bt(e.user);return(0,N.jsxs)(`tr`,{children:[(0,N.jsx)(`td`,{children:(0,N.jsxs)(`div`,{className:`sa-name-cell`,children:[(0,N.jsx)(`div`,{className:`sa-avatar`,children:Vt(n)}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`div`,{className:`sa-main-text`,children:n}),(0,N.jsxs)(`div`,{className:`sa-sub-text`,children:[`School ID: `,e.user?.school_id??`Not linked`]})]})]})}),(0,N.jsx)(`td`,{children:(0,N.jsx)(`span`,{className:`sa-sub-text`,children:e.user?.email||`Not provided`})}),(0,N.jsx)(`td`,{children:e.plan?.name||`Core`}),(0,N.jsx)(`td`,{children:(0,N.jsx)(`span`,{className:It(t),children:Ft(t)})}),(0,N.jsx)(`td`,{children:(0,N.jsx)(`span`,{className:Lt(e.status),children:e.status||`Unknown`})}),(0,N.jsx)(`td`,{children:zt(e.starts_at)}),(0,N.jsx)(`td`,{children:zt(e.ends_at)})]},e.id)})})]})}),(0,N.jsx)(Gt,{data:l,perPage:w,sizes:[10,20,30,50],onPage:C,onPerPage:e=>{T(e),C(1)}})]}),(0,N.jsxs)(`section`,{className:`sa-two`,children:[(0,N.jsxs)(Ut,{title:`School owners`,subtitle:`Recently registered administrator accounts.`,action:(0,N.jsxs)(`button`,{className:`sa-btn sa-btn-soft`,onClick:Le,children:[(0,N.jsx)(`i`,{className:`bi bi-search`}),`Search`]}),children:[(0,N.jsx)(`div`,{className:`sa-filters`,children:(0,N.jsx)(`input`,{className:`sa-input`,style:{minWidth:260},placeholder:`Search school owner`,value:V,onChange:e=>ee(e.target.value)})}),(0,N.jsx)(`div`,{className:`sa-table-wrap`,children:(0,N.jsxs)(`table`,{className:`sa-table`,style:{minWidth:620},children:[(0,N.jsx)(`thead`,{children:(0,N.jsxs)(`tr`,{children:[(0,N.jsx)(`th`,{children:`Name`}),(0,N.jsx)(`th`,{children:`Email`}),(0,N.jsx)(`th`,{children:`School`}),(0,N.jsx)(`th`,{children:`Status`}),(0,N.jsx)(`th`,{children:`Action`})]})}),(0,N.jsx)(`tbody`,{children:(f?.data||[]).length===0?(0,N.jsx)(`tr`,{children:(0,N.jsx)(`td`,{colSpan:5,children:(0,N.jsx)(Wt,{text:`No school owner found.`})})}):(f?.data||[]).map(t=>{let n=Bt(t),r=String(t.status)===`0`;return(0,N.jsxs)(`tr`,{children:[(0,N.jsx)(`td`,{children:(0,N.jsxs)(`div`,{className:`sa-name-cell`,children:[(0,N.jsx)(`div`,{className:`sa-avatar`,children:Vt(n)}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`div`,{className:`sa-main-text`,children:n}),(0,N.jsxs)(`div`,{className:`sa-sub-text`,children:[`Joined `,zt(t.created_at)]})]})]})}),(0,N.jsx)(`td`,{children:(0,N.jsx)(`span`,{className:`sa-sub-text`,children:t.email||`Not provided`})}),(0,N.jsx)(`td`,{children:t.school?.school_name||`Not set`}),(0,N.jsx)(`td`,{children:(0,N.jsx)(`span`,{className:r?`sa-pill bad`:`sa-pill ok`,children:r?`Suspended`:`Active`})}),(0,N.jsx)(`td`,{children:(0,N.jsxs)(`button`,{className:`sa-btn sa-btn-soft`,style:{padding:`4px 10px`,fontSize:11},onClick:()=>e(`/admin-users/view/${t.id}`),children:[(0,N.jsx)(`i`,{className:`bi bi-gear`}),` Manage`]})})]},t.id)})})]})}),(0,N.jsx)(Gt,{data:f,perPage:R,sizes:[8,12,20],onPage:L,onPerPage:e=>{z(e),L(1)}})]}),(0,N.jsx)(Ut,{title:`Operational risk`,subtitle:`Business follow-up items for the platform team.`,children:(0,N.jsxs)(`div`,{className:`sa-risk`,children:[(0,N.jsxs)(`div`,{className:`sa-risk-item`,children:[(0,N.jsx)(`span`,{className:`sa-risk-dot red`}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`p`,{className:`sa-risk-title`,children:`Expired premium accounts`}),(0,N.jsxs)(`p`,{className:`sa-risk-sub`,children:[Se.expired,` premium account(s) on this page may need renewal or downgrade follow-up.`]})]})]}),(0,N.jsxs)(`div`,{className:`sa-risk-item`,children:[(0,N.jsx)(`span`,{className:`sa-risk-dot gold`}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`p`,{className:`sa-risk-title`,children:`Core package schools`}),(0,N.jsxs)(`p`,{className:`sa-risk-sub`,children:[Se.core,` school(s) on this page are on Core. They are good candidates for SchoolProfit Standard CBT Edition upgrade prompts.`]})]})]}),(0,N.jsxs)(`div`,{className:`sa-risk-item`,children:[(0,N.jsx)(`span`,{className:`sa-risk-dot green`}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`p`,{className:`sa-risk-title`,children:`Platform activity`}),(0,N.jsx)(`p`,{className:`sa-risk-sub`,children:`Keep reviewing activity logs for billing override, access changes, and support-sensitive actions.`})]})]})]})})]}),(0,N.jsxs)(Ut,{title:`Platform activity`,subtitle:`Audit trail of important activity across SchoolProfit.`,action:(0,N.jsxs)(`button`,{className:`sa-btn sa-btn-soft`,onClick:Re,children:[(0,N.jsx)(`i`,{className:`bi bi-arrow-repeat`}),`Reload`]}),children:[(0,N.jsxs)(`div`,{className:`sa-log-toolbar`,children:[(0,N.jsxs)(`label`,{className:`sa-log-select`,children:[(0,N.jsx)(`input`,{type:`checkbox`,checked:De,onChange:Be}),`Select all on this page`]}),(0,N.jsxs)(`div`,{style:{display:`flex`,gap:8,flexWrap:`wrap`},children:[(0,N.jsx)(`button`,{className:`sa-btn sa-btn-soft`,disabled:!H.length||oe,onClick:()=>ae([]),children:`Clear`}),(0,N.jsxs)(`button`,{className:`sa-btn sa-btn-dark`,disabled:!H.length||oe,onClick:Ve,children:[(0,N.jsx)(`i`,{className:`bi bi-trash3`}),oe?`Deleting`:`Delete ${H.length||``}`]})]})]}),(0,N.jsx)(`div`,{className:`sa-table-wrap`,children:(0,N.jsxs)(`table`,{className:`sa-table`,children:[(0,N.jsx)(`thead`,{children:(0,N.jsxs)(`tr`,{children:[(0,N.jsx)(`th`,{style:{width:42}}),(0,N.jsx)(`th`,{children:`When`}),(0,N.jsx)(`th`,{children:`User`}),(0,N.jsx)(`th`,{children:`Action`}),(0,N.jsx)(`th`,{children:`Description`})]})}),(0,N.jsx)(`tbody`,{children:(m?.data||[]).length===0?(0,N.jsx)(`tr`,{children:(0,N.jsx)(`td`,{colSpan:5,children:(0,N.jsx)(Wt,{text:`No platform activity found.`})})}):(m?.data||[]).map(e=>(0,N.jsxs)(`tr`,{children:[(0,N.jsx)(`td`,{children:(0,N.jsx)(`input`,{type:`checkbox`,checked:H.includes(e.id),onChange:()=>ze(e.id)})}),(0,N.jsx)(`td`,{children:zt(e.created_at)}),(0,N.jsx)(`td`,{children:(0,N.jsx)(`div`,{className:`sa-main-text`,children:e.user_name||`System`})}),(0,N.jsx)(`td`,{children:(0,N.jsx)(`span`,{className:`sa-pill muted`,children:e.action||`Activity`})}),(0,N.jsx)(`td`,{children:(0,N.jsx)(`span`,{className:`sa-sub-text`,children:e.description||`No description`})})]},e.id))})]})}),(0,N.jsx)(Gt,{data:m,perPage:re,sizes:[10,20,30],onPage:ne,onPerPage:e=>{ie(e),ne(1)}})]}),(0,N.jsx)(`div`,{className:`mt-auto`,children:(0,N.jsx)(lt,{})})]})]})]})})]})}var qt=e=>new Intl.NumberFormat(`en-NG`,{style:`currency`,currency:`NGN`}).format(e||0),Jt={parent:{id:0,name:`Parent`},stats:{children:0,total_fees:0,total_paid:0,total_balance:0,unread_notifications:0},selected_child_id:0,children:[],charts:{fee_balance_by_child:{labels:[],data:[]},attendance_weekly:{labels:[],data:[]}},recent_notifications:[]};function Yt(e){let t=e?.data??e,n=data?.children??[],r=n[0]?.id??0,i=t?.stats||{};return{...Jt,...t,parent:{...Jt.parent,...t?.parent||{}},stats:{...Jt.stats,...i,children:Number(i.children??n.length??0)},selected_child_id:Number(t?.selected_child_id||r||0),children:n,charts:{fee_balance_by_child:{labels:Array.isArray(t?.charts?.fee_balance_by_child?.labels)?t.charts.fee_balance_by_child.labels:[],data:Array.isArray(t?.charts?.fee_balance_by_child?.data)?t.charts.fee_balance_by_child.data:[]},attendance_weekly:{labels:Array.isArray(t?.charts?.attendance_weekly?.labels)?t.charts.attendance_weekly.labels:[],data:Array.isArray(t?.charts?.attendance_weekly?.data)?t.charts.attendance_weekly.data:[]}},recent_notifications:Array.isArray(t?.recent_notifications)?t.recent_notifications:[]}}function Xt(){let e=d(),[t,n]=(0,_.useState)(!1),[r,i]=(0,_.useState)(!0),[a,o]=(0,_.useState)(null),[s,c]=(0,_.useState)(null),[l,u]=(0,_.useState)(!1),[f,p]=(0,_.useState)([{title:`My Children`,value:0,icon:`people`},{title:`Total Fees`,value:qt(0),icon:`wallet2`},{title:`Total Paid`,value:qt(0),icon:`cash-stack`},{title:`Outstanding Balance`,value:qt(0),icon:`exclamation-circle`}]),m=(0,_.useRef)(null),g=(0,_.useRef)(null),v=(0,_.useRef)(null),y=(0,_.useRef)(null),b=(0,_.useMemo)(()=>a?.charts?.attendance_weekly?.labels??[],[a]),x=(0,_.useMemo)(()=>a?.charts?.attendance_weekly?.data??[],[a]),S=(0,_.useMemo)(()=>a?.charts?.fee_balance_by_child?.labels??[],[a]),C=(0,_.useMemo)(()=>a?.charts?.fee_balance_by_child?.data??[],[a]),w=e=>{i(!0);let t=e?`/parent/dashboard?child_id=${e}`:`/parent/dashboard`;B.get(t).then(e=>{let t=Yt(e.data);o(t),c(t.selected_child_id),p([{title:`My Children`,value:t.stats.children,icon:`people`},{title:`Total Fees`,value:qt(t.stats.total_fees),icon:`wallet2`},{title:`Total Paid`,value:qt(t.stats.total_paid),icon:`cash-stack`},{title:`Outstanding Balance`,value:qt(t.stats.total_balance),icon:`exclamation-circle`}])}).catch(e=>console.error(e)).finally(()=>i(!1))};(0,_.useEffect)(()=>{w()},[]),(0,_.useEffect)(()=>{let e=getComputedStyle(document.documentElement).getPropertyValue(`--bs-primary`).trim()||`#0d6efd`,t=(e,t)=>e.startsWith(`rgb`)?e.replace(`rgb`,`rgba`).replace(`)`,`, ${t})`):e+Math.round(t*255).toString(16).padStart(2,`0`),n=n=>{let r=n.createLinearGradient(0,0,0,320);return r.addColorStop(0,t(e,.35)),r.addColorStop(1,t(e,.05)),r};if(m.current){let e=m.current.getContext(`2d`);if(!e)return;v.current?.destroy(),v.current=new h(e,{type:`line`,data:{labels:b,datasets:[{label:`Present/Late Marks`,data:x,borderColor:`#0d6efd`,backgroundColor:n(e),pointBackgroundColor:`#0d6efd`,pointBorderColor:`#fff`,pointBorderWidth:2,pointRadius:6,pointHoverRadius:8,tension:.4,fill:!0}]},options:{responsive:!0,maintainAspectRatio:!1,plugins:{legend:{display:!1},tooltip:{backgroundColor:`rgba(0, 0, 0, 0.8)`,padding:12,cornerRadius:8,titleFont:{size:13,weight:`bold`},bodyFont:{size:12}}},scales:{x:{grid:{display:!1},ticks:{font:{size:11}}},y:{beginAtZero:!0,grid:{color:`rgba(0,0,0,0.05)`},ticks:{font:{size:11}}}}}})}if(g.current){let e=g.current.getContext(`2d`);if(!e)return;y.current?.destroy(),y.current=new h(e,{type:`bar`,data:{labels:S,datasets:[{label:`Balance`,data:C,backgroundColor:`#0d6efd`,borderRadius:8,barThickness:40,hoverBackgroundColor:`#0b5ed7`}]},options:{responsive:!0,maintainAspectRatio:!1,plugins:{legend:{display:!1},tooltip:{callbacks:{label:e=>` ${qt(Number(e.raw||0))}`},backgroundColor:`rgba(0, 0, 0, 0.8)`,padding:12,cornerRadius:8,titleFont:{size:13,weight:`bold`},bodyFont:{size:12}}},scales:{x:{grid:{display:!1},ticks:{font:{size:11}}},y:{beginAtZero:!0,grid:{color:`rgba(0,0,0,0.05)`},ticks:{font:{size:11}}}}}})}return()=>{v.current?.destroy(),y.current?.destroy()}},[b,x,S,C]);let T=()=>{let e=new Date().getHours();return e<12?`Good Morning`:e<17?`Good Afternoon`:`Good Evening`},E=a?.parent?.name??`Parent`,D=a?.children??[],O=D.find(e=>e.id===s)||D[0],k=`${window.location.origin}/pay-school-fee${O?.reg_no?`?student_reg_no=${encodeURIComponent(O.reg_no)}`:``}`;return(0,N.jsxs)(N.Fragment,{children:[(0,N.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');

        .parent-db-main {
          background: #F8FAFC;
          min-height: 100vh;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          padding: 24px 28px 40px;
        }

        /* ── Signature Hero Banner ── */
        .parent-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 18px;
          padding: 32px 36px;
          color: #FFFFFF;
          margin-bottom: 24px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
          position: relative;
          overflow: hidden;
        }

        .parent-hero::before {
          content: '';
          position: absolute;
          inset: 0;
          background-image:
            linear-gradient(rgba(255, 255, 255, 0.035) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255, 255, 255, 0.035) 1px, transparent 1px);
          background-size: 32px 32px;
          pointer-events: none;
        }

        .parent-hero-glow {
          position: absolute;
          top: -40px;
          right: -40px;
          width: 320px;
          height: 320px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.18) 0%, transparent 65%);
          pointer-events: none;
        }

        .parent-hero-glow2 {
          position: absolute;
          bottom: -30px;
          left: 20%;
          width: 220px;
          height: 220px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(37, 99, 235, 0.15) 0%, transparent 65%);
          pointer-events: none;
        }

        .parent-hero-inner {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: center;
          justify-content: space-between;
          flex-wrap: wrap;
          gap: 24px;
        }

        .parent-session-badge {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.2);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius: 100px;
          padding: 4px 12px;
          margin-bottom: 12px;
        }

        .parent-session-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #10B981;
          box-shadow: 0 0 6px #10B981;
          animation: parentPulse 2s ease infinite;
        }

        @keyframes parentPulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.4; transform: scale(1.5); }
        }

        .parent-greeting {
          font-size: 26px;
          font-weight: 800;
          color: #FFFFFF;
          line-height: 1.1;
          margin-bottom: 8px;
        }

        .parent-greeting em {
          font-style: normal;
          color: #FBBF24;
        }

        .parent-hero-sub {
          font-size: 13.5px;
          color: #CBD5E1;
          line-height: 1.6;
          max-width: 520px;
          margin-bottom: 20px;
        }

        .parent-hero-actions {
          display: flex;
          align-items: center;
          gap: 10px;
          flex-wrap: wrap;
        }

        .parent-btn-gold {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 9px 18px;
          font-size: 13px;
          font-weight: 700;
          border-radius: 10px;
          color: #FFFFFF !important;
          background: linear-gradient(135deg, #D97706 0%, #B45309 100%) !important;
          border: none;
          box-shadow: 0 4px 14px rgba(217, 119, 6, 0.3);
          transition: all 0.2s ease;
          text-decoration: none;
          cursor: pointer;
        }

        .parent-btn-gold:hover {
          background: linear-gradient(135deg, #B45309 0%, #92400E 100%) !important;
          transform: translateY(-1px);
        }

        .parent-btn-outline {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 9px 18px;
          font-size: 13px;
          font-weight: 700;
          border-radius: 10px;
          color: #FFFFFF !important;
          background: rgba(255, 255, 255, 0.12) !important;
          border: 1px solid rgba(255, 255, 255, 0.22) !important;
          backdrop-filter: blur(8px);
          transition: all 0.2s ease;
          text-decoration: none;
          cursor: pointer;
        }

        .parent-btn-outline:hover {
          background: rgba(255, 255, 255, 0.2) !important;
          transform: translateY(-1px);
        }

        /* ── Child Selector Card in Hero ── */
        .parent-child-card {
          background: rgba(255, 255, 255, 0.1);
          border: 1px solid rgba(255, 255, 255, 0.18);
          border-radius: 14px;
          padding: 18px 22px;
          backdrop-filter: blur(12px);
          min-width: 280px;
        }

        .parent-child-card-title {
          font-size: 12px;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          color: rgba(255, 255, 255, 0.8);
          margin-bottom: 10px;
          display: flex;
          align-items: center;
          justify-content: space-between;
        }

        /* ── Unified Stat Cards ── */
        .parent-stat-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 16px;
          margin-bottom: 24px;
        }

        @media (max-width: 1100px) {
          .parent-stat-grid {
            grid-template-columns: repeat(2, 1fr);
          }
        }

        @media (max-width: 600px) {
          .parent-stat-grid {
            grid-template-columns: 1fr;
          }
        }

        .parent-stat-card {
          background: #FFFFFF;
          border: 1px solid rgba(15, 39, 68, 0.08);
          border-radius: 16px;
          padding: 20px 24px;
          box-shadow: 0 2px 10px rgba(15, 39, 68, 0.04);
          transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1);
          position: relative;
          overflow: hidden;
        }

        .parent-stat-card:hover {
          transform: translateY(-3px);
          box-shadow: 0 8px 24px rgba(15, 39, 68, 0.08);
          border-color: rgba(217, 119, 6, 0.25);
        }

        .parent-stat-icon-wrap {
          width: 44px;
          height: 44px;
          border-radius: 12px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 20px;
          margin-bottom: 14px;
        }

        .parent-stat-title {
          font-size: 12px;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.04em;
          color: #64748B;
          margin-bottom: 6px;
        }

        .parent-stat-val {
          font-size: 24px;
          font-weight: 800;
          color: #0F2744;
          line-height: 1.1;
          margin-bottom: 8px;
        }

        /* ── Quick Actions Grid ── */
        .parent-qa-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 14px;
          margin-bottom: 24px;
        }

        @media (max-width: 1000px) {
          .parent-qa-grid {
            grid-template-columns: repeat(2, 1fr);
          }
        }

        @media (max-width: 540px) {
          .parent-qa-grid {
            grid-template-columns: 1fr;
          }
        }

        .parent-qa-card {
          background: #FFFFFF;
          border: 1px solid rgba(15, 39, 68, 0.08);
          border-radius: 14px;
          padding: 16px 20px;
          display: flex;
          align-items: center;
          gap: 14px;
          text-decoration: none;
          color: #0F2744;
          transition: all 0.2s ease;
          box-shadow: 0 2px 8px rgba(15, 39, 68, 0.03);
          cursor: pointer;
        }

        .parent-qa-card:hover {
          border-color: rgba(217, 119, 6, 0.35);
          transform: translateY(-2px);
          box-shadow: 0 6px 20px rgba(15, 39, 68, 0.07);
          color: #0F2744;
        }

        .parent-qa-icon {
          width: 42px;
          height: 42px;
          border-radius: 10px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 18px;
          flex-shrink: 0;
        }

        /* ── Content Panels & Tables ── */
        .parent-panel {
          background: #FFFFFF;
          border: 1px solid rgba(15, 39, 68, 0.08);
          border-radius: 16px;
          box-shadow: 0 2px 10px rgba(15, 39, 68, 0.04);
          overflow: hidden;
          margin-bottom: 24px;
        }

        .parent-panel-head {
          padding: 18px 24px;
          border-bottom: 1px solid #E2E8F0;
          display: flex;
          align-items: center;
          justify-content: space-between;
          flex-wrap: wrap;
          gap: 12px;
        }

        .parent-panel-title {
          font-size: 16px;
          font-weight: 800;
          color: #0F2744;
          margin: 0;
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .parent-panel-body {
          padding: 24px;
        }

        .parent-table {
          width: 100%;
          border-collapse: collapse;
          font-size: 13px;
        }

        .parent-table th {
          background: #F8FAFC;
          padding: 12px 16px;
          font-weight: 700;
          color: #475569;
          font-size: 11.5px;
          text-transform: uppercase;
          letter-spacing: 0.04em;
          border-bottom: 1px solid #E2E8F0;
        }

        .parent-table td {
          padding: 14px 16px;
          border-bottom: 1px solid #F1F5F9;
          color: #1E293B;
          vertical-align: middle;
        }

        .parent-table tr:hover td {
          background: #F8FAFC;
        }

        .parent-badge-clear {
          background: #DCFCE7;
          color: #15803D;
          font-weight: 700;
          padding: 4px 10px;
          border-radius: 999px;
          font-size: 11px;
        }

        .parent-badge-pending {
          background: #FEF3C7;
          color: #B45309;
          font-weight: 700;
          padding: 4px 10px;
          border-radius: 999px;
          font-size: 11px;
        }

        .parent-badge-owing {
          background: #FEE2E2;
          color: #B91C1C;
          font-weight: 700;
          padding: 4px 10px;
          border-radius: 999px;
          font-size: 11px;
        }
      `}),(0,N.jsx)(st,{sidebarOpen:t,setSidebarOpen:n}),(0,N.jsx)(Y,{title:`Parent Dashboard`}),(0,N.jsx)(`div`,{className:`container-fluid`,children:(0,N.jsxs)(`div`,{className:`row`,children:[(0,N.jsx)(ct,{sidebarOpen:t,setSidebarOpen:n}),(0,N.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto gq-app-main parent-db-main d-flex flex-column min-vh-100`,children:[r&&(0,N.jsx)(G,{message:`Loading parent dashboard...`}),(0,N.jsxs)(`div`,{className:`parent-hero`,children:[(0,N.jsx)(`div`,{className:`parent-hero-glow`}),(0,N.jsx)(`div`,{className:`parent-hero-glow2`}),(0,N.jsxs)(`div`,{className:`parent-hero-inner`,children:[(0,N.jsxs)(`div`,{children:[(0,N.jsxs)(`div`,{className:`parent-session-badge`,children:[(0,N.jsx)(`span`,{className:`parent-session-dot`}),`Parent Academic Portal`]}),(0,N.jsxs)(`h1`,{className:`parent-greeting`,children:[T(),`, `,(0,N.jsxs)(`em`,{children:[E,`!`]}),` 👋`]}),(0,N.jsx)(`p`,{className:`parent-hero-sub`,children:`Institutional oversight for your children — view real-time continuous assessment, verified term broadsheets, digital fee clearance, and daily attendance logs.`}),(0,N.jsxs)(`div`,{className:`parent-hero-actions`,children:[(0,N.jsxs)(`button`,{className:`parent-btn-gold`,onClick:()=>window.open(k,`_blank`),children:[(0,N.jsx)(`i`,{className:`bi bi-credit-card-2-front-fill`}),`Pay School Fees Online`]}),(0,N.jsxs)(`button`,{className:`parent-btn-outline`,onClick:()=>e(`/parent/children`),children:[(0,N.jsx)(`i`,{className:`bi bi-people-fill`}),`Manage Children`]}),(0,N.jsxs)(`button`,{className:`parent-btn-outline`,onClick:()=>e(`/notifications`),children:[(0,N.jsx)(`i`,{className:`bi bi-bell-fill`}),`Notifications (`,a?.stats.unread_notifications??0,`)`]})]})]}),(0,N.jsxs)(`div`,{className:`parent-child-card`,children:[(0,N.jsxs)(`div`,{className:`parent-child-card-title`,children:[(0,N.jsx)(`span`,{children:`Active Student`}),(0,N.jsx)(`i`,{className:`bi bi-mortarboard-fill text-warning`})]}),(0,N.jsx)(`select`,{className:`form-select mb-3`,value:s??``,onChange:e=>{let t=Number(e.target.value);c(t),w(t)},style:{borderRadius:10,border:`1px solid rgba(255,255,255,0.35)`,background:`rgba(255,255,255,0.2)`,color:`#FFFFFF`,fontSize:`13px`,fontWeight:600},children:D.map(e=>(0,N.jsxs)(`option`,{value:e.id,style:{color:`#0F2744`},children:[e.name,` (`,e.class||`No Class`,`)`]},e.id))}),(0,N.jsxs)(`div`,{className:`d-flex flex-column gap-2`,style:{fontSize:`12.5px`},children:[(0,N.jsxs)(`div`,{className:`d-flex justify-content-between align-items-center`,children:[(0,N.jsx)(`span`,{style:{color:`rgba(255, 255, 255, 0.75)`},children:`Admission No:`}),(0,N.jsx)(`strong`,{className:`text-white`,children:O?.reg_no||`N/A`})]}),(0,N.jsxs)(`div`,{className:`d-flex justify-content-between align-items-center`,children:[(0,N.jsx)(`span`,{style:{color:`rgba(255, 255, 255, 0.75)`},children:`Attendance Rate (30d):`}),(0,N.jsxs)(`strong`,{className:`text-success`,children:[O?.attendance_rate_30d??0,`%`]})]}),(0,N.jsxs)(`div`,{className:`d-flex justify-content-between align-items-center`,children:[(0,N.jsx)(`span`,{style:{color:`rgba(255, 255, 255, 0.75)`},children:`Fee Balance:`}),(0,N.jsx)(`strong`,{style:{color:Number(O?.fee_balance||0)>0?`#FCA5A5`:`#86EFAC`},children:qt(O?.fee_balance??0)})]})]})]})]})]}),(0,N.jsx)(`div`,{className:`parent-stat-grid`,children:f.map(({title:e,value:t,icon:n},r)=>{let i=[{color:`#10B981`,bg:`rgba(16, 185, 129, 0.12)`,border:`rgba(16, 185, 129, 0.3)`},{color:`#2563EB`,bg:`rgba(37, 99, 235, 0.12)`,border:`rgba(37, 99, 235, 0.3)`},{color:`#059669`,bg:`rgba(5, 150, 105, 0.12)`,border:`rgba(5, 150, 105, 0.3)`},{color:`#D97706`,bg:`rgba(217, 119, 6, 0.12)`,border:`rgba(217, 119, 6, 0.3)`}][r%4];return(0,N.jsxs)(`div`,{className:`parent-stat-card`,children:[(0,N.jsxs)(`div`,{className:`d-flex align-items-start justify-content-between`,children:[(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`div`,{className:`parent-stat-title`,children:e}),(0,N.jsx)(`div`,{className:`parent-stat-val`,children:t})]}),(0,N.jsx)(`div`,{className:`parent-stat-icon-wrap`,style:{backgroundColor:i.bg,color:i.color},children:(0,N.jsx)(`i`,{className:`bi bi-${n}`})})]}),(0,N.jsxs)(`div`,{className:`pt-2 d-flex align-items-center gap-1`,style:{borderTop:`1px solid #F1F5F9`,fontSize:`11.5px`,color:`#64748B`},children:[(0,N.jsx)(`i`,{className:`bi bi-shield-check text-success`}),`Live institutional ledger`]})]},e)})}),(0,N.jsxs)(`div`,{className:`parent-qa-grid`,children:[(0,N.jsxs)(`div`,{className:`parent-qa-card`,onClick:()=>window.open(k,`_blank`),children:[(0,N.jsx)(`div`,{className:`parent-qa-icon`,style:{background:`rgba(16, 185, 129, 0.12)`,color:`#10B981`},children:(0,N.jsx)(`i`,{className:`bi bi-credit-card-2-front-fill`})}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`div`,{style:{fontWeight:800,fontSize:`13.5px`},children:`Pay School Fees`}),(0,N.jsx)(`div`,{style:{fontSize:`11.5px`,color:`#64748B`},children:`Secure instant gateway`})]})]}),(0,N.jsxs)(`div`,{className:`parent-qa-card`,onClick:()=>e(`/parent/children`),children:[(0,N.jsx)(`div`,{className:`parent-qa-icon`,style:{background:`rgba(37, 99, 235, 0.12)`,color:`#2563EB`},children:(0,N.jsx)(`i`,{className:`bi bi-file-earmark-bar-graph-fill`})}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`div`,{style:{fontWeight:800,fontSize:`13.5px`},children:`Term Broadsheet`}),(0,N.jsx)(`div`,{style:{fontSize:`11.5px`,color:`#64748B`},children:`Official academic results`})]})]}),(0,N.jsxs)(`div`,{className:`parent-qa-card`,onClick:()=>e(`/student/my-fees`),children:[(0,N.jsx)(`div`,{className:`parent-qa-icon`,style:{background:`rgba(217, 119, 6, 0.12)`,color:`#D97706`},children:(0,N.jsx)(`i`,{className:`bi bi-receipt-cutoff`})}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`div`,{style:{fontWeight:800,fontSize:`13.5px`},children:`Payment History`}),(0,N.jsx)(`div`,{style:{fontSize:`11.5px`,color:`#64748B`},children:`Verified receipts & logs`})]})]}),(0,N.jsxs)(`div`,{className:`parent-qa-card`,onClick:()=>e(`/parent/whatsapp-verification`),children:[(0,N.jsx)(`div`,{className:`parent-qa-icon`,style:{background:`rgba(5, 150, 105, 0.12)`,color:`#059669`},children:(0,N.jsx)(`i`,{className:`bi bi-whatsapp`})}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`div`,{style:{fontWeight:800,fontSize:`13.5px`},children:`WhatsApp Alerts`}),(0,N.jsx)(`div`,{style:{fontSize:`11.5px`,color:`#64748B`},children:`Direct mobile updates`})]})]})]}),(0,N.jsxs)(`div`,{className:`row g-4 mb-4`,children:[(0,N.jsx)(`div`,{className:`col-lg-8`,children:(0,N.jsxs)(`div`,{className:`parent-panel h-100 mb-0`,children:[(0,N.jsxs)(`div`,{className:`parent-panel-head`,children:[(0,N.jsxs)(`h2`,{className:`parent-panel-title`,children:[(0,N.jsx)(`i`,{className:`bi bi-calendar2-check-fill text-primary`}),`Weekly Attendance Activity`]}),(0,N.jsx)(`span`,{className:`badge bg-light text-dark`,style:{border:`1px solid #E2E8F0`},children:O?.name||`Selected Student`})]}),(0,N.jsx)(`div`,{className:`parent-panel-body`,children:(0,N.jsx)(`div`,{style:{height:280},children:(0,N.jsx)(`canvas`,{ref:m})})})]})}),(0,N.jsx)(`div`,{className:`col-lg-4`,children:(0,N.jsxs)(`div`,{className:`parent-panel h-100 mb-0`,children:[(0,N.jsxs)(`div`,{className:`parent-panel-head`,children:[(0,N.jsxs)(`h2`,{className:`parent-panel-title`,children:[(0,N.jsx)(`i`,{className:`bi bi-pie-chart-fill text-warning`}),`Fee Balance by Child`]}),(0,N.jsx)(`span`,{className:`badge bg-light text-dark`,style:{border:`1px solid #E2E8F0`},children:`₦ NGN`})]}),(0,N.jsx)(`div`,{className:`parent-panel-body`,children:(0,N.jsx)(`div`,{style:{height:280},children:(0,N.jsx)(`canvas`,{ref:g})})})]})})]}),(0,N.jsxs)(`div`,{className:`parent-panel`,children:[(0,N.jsxs)(`div`,{className:`parent-panel-head`,children:[(0,N.jsxs)(`div`,{children:[(0,N.jsxs)(`h2`,{className:`parent-panel-title`,children:[(0,N.jsx)(`i`,{className:`bi bi-people-fill text-primary`}),`Enrolled Children Overview`]}),(0,N.jsx)(`div`,{style:{fontSize:`12px`,color:`#64748B`,marginTop:`2px`},children:`Continuous assessment, fee status, and result access for your family`})]}),(0,N.jsxs)(`button`,{className:`btn btn-sm btn-outline-primary`,style:{borderRadius:8,fontWeight:700},onClick:()=>w(s??void 0),children:[(0,N.jsx)(`i`,{className:`bi bi-arrow-clockwise me-1`}),`Refresh Data`]})]}),(0,N.jsx)(`div`,{className:`table-responsive`,children:(0,N.jsxs)(`table`,{className:`parent-table`,children:[(0,N.jsx)(`thead`,{children:(0,N.jsxs)(`tr`,{children:[(0,N.jsx)(`th`,{children:`Student`}),(0,N.jsx)(`th`,{children:`Class`}),(0,N.jsx)(`th`,{children:`Attendance (30d)`}),(0,N.jsx)(`th`,{children:`Fee Status`}),(0,N.jsx)(`th`,{children:`Outstanding`}),(0,N.jsx)(`th`,{className:`text-end`,children:`Actions`})]})}),(0,N.jsxs)(`tbody`,{children:[D.map(e=>{let t=Number(e.fee_balance||0)<=0;return(0,N.jsxs)(`tr`,{children:[(0,N.jsx)(`td`,{children:(0,N.jsxs)(`div`,{className:`d-flex align-items-center gap-3`,children:[(0,N.jsx)(`div`,{style:{width:38,height:38,borderRadius:`50%`,background:`linear-gradient(135deg, #0A192F 0%, #1E3A8A 100%)`,color:`#FBBF24`,display:`flex`,alignItems:`center`,justifyContent:`center`,fontWeight:800,fontSize:`14px`},children:(e.name?.[0]||`S`).toUpperCase()}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`div`,{style:{fontWeight:700,color:`#0F2744`},children:e.name}),(0,N.jsxs)(`div`,{style:{fontSize:`11.5px`,color:`#64748B`},children:[`Admission No: `,(0,N.jsx)(`strong`,{children:e.reg_no||`N/A`})]})]})]})}),(0,N.jsx)(`td`,{children:(0,N.jsx)(`span`,{style:{fontWeight:600},children:e.class||`—`})}),(0,N.jsx)(`td`,{children:(0,N.jsxs)(`div`,{className:`d-flex align-items-center gap-2`,children:[(0,N.jsx)(`div`,{className:`progress flex-grow-1`,style:{height:6,width:60,borderRadius:999},children:(0,N.jsx)(`div`,{className:`progress-bar bg-success`,style:{width:`${Math.min(100,e.attendance_rate_30d||0)}%`}})}),(0,N.jsxs)(`span`,{style:{fontWeight:700,fontSize:`12px`},children:[e.attendance_rate_30d,`%`]})]})}),(0,N.jsx)(`td`,{children:t?(0,N.jsxs)(`span`,{className:`parent-badge-clear`,children:[(0,N.jsx)(`i`,{className:`bi bi-check-circle-fill me-1`}),`Cleared`]}):(0,N.jsxs)(`span`,{className:`parent-badge-owing`,children:[(0,N.jsx)(`i`,{className:`bi bi-exclamation-circle-fill me-1`}),`Balance Due`]})}),(0,N.jsx)(`td`,{style:{fontWeight:700,color:t?`#15803D`:`#B91C1C`},children:qt(e.fee_balance)}),(0,N.jsx)(`td`,{className:`text-end`,children:(0,N.jsxs)(`div`,{className:`d-flex align-items-center justify-content-end gap-2`,children:[(0,N.jsx)(`button`,{className:`btn btn-sm ${e.id===s?`btn-primary`:`btn-outline-secondary`}`,style:{borderRadius:8,fontWeight:700,fontSize:`12px`},onClick:()=>{c(e.id),w(e.id)},children:e.id===s?`Selected`:`Select`}),(0,N.jsx)(`button`,{className:`btn btn-sm btn-outline-success`,style:{borderRadius:8,fontWeight:700,fontSize:`12px`},onClick:()=>{let t=`${window.location.origin}/pay-school-fee${e.reg_no?`?student_reg_no=${encodeURIComponent(e.reg_no)}`:``}`;window.open(t,`_blank`)},children:`Pay Fees`})]})})]},e.id)}),D.length===0&&(0,N.jsx)(`tr`,{children:(0,N.jsxs)(`td`,{colSpan:6,className:`text-center py-5 text-muted`,children:[(0,N.jsx)(`i`,{className:`bi bi-people fs-2 d-block mb-2 text-secondary`}),`No children assigned to this parent account yet.`]})})]})]})})]}),(0,N.jsxs)(`div`,{className:`parent-panel mb-5`,children:[(0,N.jsxs)(`div`,{className:`parent-panel-head`,children:[(0,N.jsxs)(`h2`,{className:`parent-panel-title`,children:[(0,N.jsx)(`i`,{className:`bi bi-bell-fill text-warning`}),`Recent Account & School Notifications`]}),(0,N.jsx)(`button`,{className:`btn btn-sm btn-light`,style:{borderRadius:8,fontWeight:700},onClick:()=>e(`/notifications`),children:`View All Notifications`})]}),(0,N.jsx)(`div`,{className:`parent-panel-body p-0`,children:(0,N.jsxs)(`div`,{className:`d-flex flex-column`,children:[(a?.recent_notifications??[]).map(e=>(0,N.jsxs)(`div`,{className:`p-3 d-flex align-items-center justify-content-between border-bottom`,style:{transition:`background 0.2s`},children:[(0,N.jsxs)(`div`,{className:`d-flex align-items-center gap-3`,children:[(0,N.jsx)(`div`,{style:{width:36,height:36,borderRadius:10,background:`rgba(217, 119, 6, 0.12)`,color:`#D97706`,display:`flex`,alignItems:`center`,justifyContent:`center`,fontSize:`16px`},children:(0,N.jsx)(`i`,{className:`bi bi-chat-left-dots-fill`})}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`div`,{style:{fontWeight:700,color:`#0F2744`,fontSize:`13.5px`},children:e.data?.message??`School Notification`}),e.data?.type&&(0,N.jsxs)(`small`,{className:`text-muted`,children:[`Type: `,e.data.type]})]})]}),(0,N.jsx)(`small`,{className:`text-muted`,children:new Date(e.created_at).toLocaleDateString(`en-NG`,{day:`numeric`,month:`short`,hour:`2-digit`,minute:`2-digit`})})]},e.id)),(a?.recent_notifications??[]).length===0&&(0,N.jsx)(`div`,{className:`text-muted text-center py-4`,children:`No new notifications at this time.`})]})})]}),(0,N.jsx)(lt,{})]})]})})]})}var Zt=[{color:`var(--bs-warning,  rgb(245,158,11))`,bg:`rgba(245,158,11,0.10)`,label:`fees raised`},{color:`var(--bs-success,  rgb(34,197,94))`,bg:`rgba(34,197,94,0.10)`,label:`payments received`},{color:`var(--bs-danger,   rgb(239,68,68))`,bg:`rgba(239,68,68,0.10)`,label:`still outstanding`},{color:`var(--bs-primary,  rgb(211,0,176))`,bg:`rgba(211,0,176,0.08)`,label:`transactions logged`}],Qt=[{label:`Record Payment`,desc:`Log a new fee payment`,color:`var(--bs-success, rgb(34,197,94))`,bg:`rgba(34,197,94,0.10)`,path:`/payments`,icon:(0,N.jsxs)(`svg`,{width:`22`,height:`22`,viewBox:`0 0 24 24`,fill:`none`,children:[(0,N.jsx)(`rect`,{x:`3`,y:`6`,width:`18`,height:`12`,rx:`2`,stroke:`currentColor`,strokeWidth:`1.6`}),(0,N.jsx)(`path`,{d:`M3 10h18`,stroke:`currentColor`,strokeWidth:`1.5`}),(0,N.jsx)(`path`,{d:`M8 14h3`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`})]})},{label:`Student Fees`,desc:`Manage student fee records`,color:`var(--bs-warning, rgb(245,158,11))`,bg:`rgba(245,158,11,0.10)`,path:`/student-fees`,icon:(0,N.jsxs)(`svg`,{width:`22`,height:`22`,viewBox:`0 0 24 24`,fill:`none`,children:[(0,N.jsx)(`circle`,{cx:`8`,cy:`8`,r:`3`,stroke:`currentColor`,strokeWidth:`1.6`}),(0,N.jsx)(`path`,{d:`M2 19c0-3.314 2.686-6 6-6`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`}),(0,N.jsx)(`path`,{d:`M15 7h6M15 12h6M15 17h6`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})]})},{label:`Fee Reports`,desc:`Review finance analytics`,color:`var(--bs-primary, rgb(211,0,176))`,bg:`rgba(211,0,176,0.08)`,path:`/reports/finance`,icon:(0,N.jsx)(`svg`,{width:`22`,height:`22`,viewBox:`0 0 24 24`,fill:`none`,children:(0,N.jsx)(`path`,{d:`M4 20V10M9 20V4M14 20v-7M19 20V7`,stroke:`currentColor`,strokeWidth:`1.7`,strokeLinecap:`round`})})}];function $t(){let e=new Date().getHours();return e<12?`Good morning`:e<17?`Good afternoon`:`Good evening`}var en=e=>{let t=Number(e||0);return new Intl.NumberFormat(`en-NG`,{style:`currency`,currency:`NGN`,maximumFractionDigits:2}).format(t)},tn=e=>{if(!e)return`—`;let t=new Date(e);return Number.isNaN(t.getTime())?e:t.toLocaleDateString(`en-NG`,{year:`numeric`,month:`short`,day:`numeric`})};function nn(){let e=d(),[t,n]=(0,_.useState)(!1),[r,i]=(0,_.useState)(``),[a,o]=(0,_.useState)(``),[s,c]=(0,_.useState)(!0),[l,u]=(0,_.useState)(null),[f,p]=(0,_.useState)([{title:`Total Billed`,value:en(0),icon:`billed`},{title:`Total Paid`,value:en(0),icon:`paid`},{title:`Outstanding`,value:en(0),icon:`outstanding`},{title:`Transactions`,value:0,icon:`transactions`}]),[m,g]=(0,_.useState)({paid_students_count:0,owing_students_count:0}),[v,y]=(0,_.useState)([]),[b,x]=(0,_.useState)(0),[S,C]=(0,_.useState)(!1),[w,T]=(0,_.useState)(null),[E,D]=(0,_.useState)(1),[O,k]=(0,_.useState)([]),[A,j]=(0,_.useState)(!1),[M,P]=(0,_.useState)([]),[F,I]=(0,_.useState)([]),L=(0,_.useRef)(null),R=(0,_.useRef)(null),z=(0,_.useMemo)(()=>Math.max(1,Math.ceil(b/6)),[b]);m.paid_students_count+m.owing_students_count;let V=async e=>{C(!0),T(null);try{let t=await B.get(`/bursar-dashboard/recent-payments`,{params:{limit:6,page:e}});y(t.data.data||[]),x(t.data.total||0)}catch(e){y([]),x(0),T(e?.response?.data?.message||`Unable to load recent payments.`)}finally{C(!1)}},ee=async()=>{j(!0);try{k((await B.get(`/bursar-dashboard/bank-details`)).data.data||[])}catch{k([])}finally{j(!1)}};return(0,_.useEffect)(()=>{c(!0),Promise.all([B.get(`/current-session-term`),B.get(`/bursar-dashboard/summary`),B.get(`/bursar-dashboard/payment-method-breakdown`),V(1),ee()]).then(([e,t,n])=>{B.get(`/admin/ai/credits`).then(e=>u(e.data?.data||null)).catch(()=>void 0),i(e.data.session||``),o(e.data.term||``);let r=t.data.summary;p([{title:`Total Billed`,value:en(r.total_billed),icon:`billed`},{title:`Total Paid`,value:en(r.total_paid),icon:`paid`},{title:`Outstanding`,value:en(r.total_outstanding),icon:`outstanding`},{title:`Transactions`,value:r.total_transactions,icon:`transactions`}]),g({paid_students_count:r.paid_students_count,owing_students_count:r.owing_students_count});let a=n.data.data||[];P(a.map(e=>e.method||`Unknown`)),I(a.map(e=>Number(e.total_amount||0)))}).finally(()=>c(!1))},[]),(0,_.useEffect)(()=>{V(E)},[E]),(0,_.useEffect)(()=>{if(!L.current)return;let e=L.current.getContext(`2d`);if(e)return R.current?.destroy(),R.current=new h(e,{type:`bar`,data:{labels:M,datasets:[{label:`Amount Received`,data:F,backgroundColor:e=>{let t=e.chart.ctx.createLinearGradient(0,0,0,260);return t.addColorStop(0,`rgba(255,200,87,0.88)`),t.addColorStop(1,`rgba(255,200,87,0.20)`),t},borderRadius:6,barThickness:32}]},options:{responsive:!0,maintainAspectRatio:!1,plugins:{legend:{display:!1},tooltip:{backgroundColor:`#050008`,padding:12,cornerRadius:8,titleColor:`rgb(255,200,87)`,bodyColor:`#94a3b8`,callbacks:{label:e=>` ${en(Number(e.raw||0))}`}}},scales:{x:{grid:{display:!1},ticks:{font:{size:11},color:`#9a8a7a`},border:{display:!1}},y:{beginAtZero:!0,grid:{color:`rgba(0,0,0,0.04)`},ticks:{font:{size:11},color:`#9a8a7a`,callback:e=>en(Number(e))},border:{display:!1}}}}}),()=>{R.current?.destroy()}},[M,F]),(0,N.jsxs)(N.Fragment,{children:[(0,N.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');

        :root {
          --db-light:    #F8FAFC;
          --db-dark:     #0F2744;
          --db-accent:   #D97706;
          --db-magenta:  #0F2744;
          --db-success:  #10B981;
          --db-danger:   #EF4444;
          --db-border:   #E2E8F0;
          --db-radius:   16px;

          --db-accent-dim:    rgba(217,119,6,0.10);
          --db-accent-border: rgba(217,119,6,0.22);
        }

        .db-main {
          background: var(--db-light);
          min-height: 100vh;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          padding: 24px 28px 0;
        }

        .db-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: var(--db-radius);
          padding: 32px 36px;
          position: relative;
          overflow: hidden;
          margin-bottom: 24px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
        }
        .db-hero-glow {
          position: absolute;
          top: -60px; right: -60px;
          width: 320px; height: 320px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217,119,6,0.15) 0%, transparent 65%);
          pointer-events: none;
        }
        .db-hero-glow2 {
          position: absolute;
          bottom: -40px; left: 30%;
          width: 200px; height: 200px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(37,99,235,0.10) 0%, transparent 70%);
          pointer-events: none;
        }
        .db-hero-inner {
          position: relative; z-index: 1;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 32px;
          flex-wrap: wrap;
        }
        .db-session-badge {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(217,119,6,0.20);
          border: 1px solid rgba(217,119,6,0.35);
          border-radius: 100px;
          padding: 4px 12px;
          margin-bottom: 12px;
        }
        .db-session-dot {
          width: 6px; height: 6px;
          border-radius: 50%;
          background: var(--db-success);
          animation: dbPulse 2s ease infinite;
        }
        @keyframes dbPulse {
          0%,100% { opacity: 1; transform: scale(1); }
          50% { opacity: .4; transform: scale(1.5); }
        }
        .db-greeting {
          font-size: 26px;
          font-weight: 800;
          color: #fff;
          line-height: 1.1;
          margin-bottom: 8px;
        }
        .db-greeting em { font-style: normal; color: #FBBF24; }
        .db-hero-sub {
          font-size: 13.5px;
          color: #CBD5E1;
          line-height: 1.6;
          max-width: 520px;
          margin-bottom: 20px;
        }

        .db-btn-gold, .db-btn-outline {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 9px 18px;
          font-size: 13px;
          font-weight: 700;
          border-radius: 10px;
          cursor: pointer;
          white-space: nowrap;
          transition: all .2s ease;
        }
        .db-btn-gold {
          color: #FFFFFF;
          background: var(--db-accent);
          border: none;
        }
        .db-btn-gold:hover { background: #B45309; transform: translateY(-1px); }
        .db-btn-outline {
          color: #FFFFFF;
          background: rgba(255,255,255,0.10);
          border: 1px solid rgba(255,255,255,0.20);
        }
        .db-btn-outline:hover {
          background: rgba(255,255,255,0.18);
          color: #fff;
        }

        .db-hero-stat-card {
          background: rgba(255,255,255,0.08);
          border: 1px solid rgba(255,255,255,0.15);
          backdrop-filter: blur(8px);
          border-radius: var(--db-radius);
          padding: 20px 24px;
          min-width: 220px;
        }
        .db-hero-stat-item {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 16px;
        }
        .db-hero-stat-label { font-size: 12px; font-weight: 400; color: #CBD5E1; }
        .db-hero-stat-val {
          font-size: 18px;
          font-weight: 800;
          color: #FBBF24;
        }
        .db-hero-stat-sep { height: 1px; background: rgba(255,255,255,0.08); }

        .db-stats {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 16px;
          margin-bottom: 24px;
        }
        @media (max-width: 1199.98px) { .db-stats { grid-template-columns: repeat(2, 1fr); } }
        @media (max-width: 575.98px)  { .db-stats { grid-template-columns: 1fr; } }

        .db-stat {
          background: #fff;
          border: 1px solid var(--db-border);
          border-radius: var(--db-radius);
          padding: 24px 22px;
          position: relative;
          overflow: hidden;
          transition: box-shadow .25s, transform .25s;
        }
        .db-stat:hover {
          box-shadow: 0 8px 28px rgba(0,0,0,0.08);
          transform: translateY(-3px);
        }
        .db-stat::before {
          content: '';
          position: absolute;
          top: 0; left: 0; right: 0;
          height: 3px;
          background: var(--sc);
        }
        .db-stat-head {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          margin-bottom: 16px;
        }
        .db-stat-icon {
          width: 42px;
          height: 42px;
          border-radius: 10px;
          background: var(--si);
          color: var(--sc);
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .db-stat-label {
          font-size: 12px;
          font-weight: 400;
          color: #9a8a7a;
          margin-bottom: 5px;
        }
        .db-stat-val {
          font-family: 'Playfair Display', Georgia, serif;
          font-size: 24px;
          font-weight: 700;
          color: var(--db-dark);
          line-height: 1.2;
          word-break: break-word;
        }
        .db-stat-footer {
          display: flex;
          align-items: center;
          gap: 5px;
          margin-top: 14px;
          padding-top: 12px;
          border-top: 1px solid rgba(0,0,0,0.06);
          font-size: 12px;
          color: #9a8a7a;
        }

        .db-grid {
          display: grid;
          grid-template-columns: 1fr 360px;
          gap: 20px;
          margin-bottom: 24px;
        }
        @media (max-width: 991.98px) { .db-grid { grid-template-columns: 1fr; } }

        .db-panel {
          background: #fff;
          border: 1px solid var(--db-border);
          border-radius: var(--db-radius);
          overflow: hidden;
        }
        .db-panel-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 22px 24px 18px;
          border-bottom: 1px solid rgba(0,0,0,0.06);
          gap: 12px;
          flex-wrap: wrap;
        }
        .db-panel-icon {
          width: 36px;
          height: 36px;
          border-radius: 9px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: var(--pi);
          color: var(--pc);
          flex-shrink: 0;
        }
        .db-panel-title {
          font-family: 'Playfair Display', serif;
          font-size: 16px;
          font-weight: 700;
          color: var(--db-dark);
          margin: 0;
        }
        .db-panel-sub {
          font-size: 11.5px;
          font-weight: 300;
          color: #9a8a7a;
          margin: 0;
        }

        .db-refresh-btn {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 7px 14px;
          font-size: 12px;
          color: #7a6a5a;
          background: var(--db-light);
          border: 1px solid var(--db-border);
          border-radius: 7px;
          cursor: pointer;
        }

        .db-table { width: 100%; border-collapse: collapse; }
        .db-table th {
          padding: 10px 16px;
          font-size: 11px;
          font-weight: 500;
          letter-spacing: .1em;
          text-transform: uppercase;
          color: #9a8a7a;
          background: var(--db-light);
          border-bottom: 1px solid rgba(0,0,0,0.06);
          text-align: left;
          white-space: nowrap;
        }
        .db-table td {
          padding: 13px 16px;
          font-size: 13.5px;
          color: #4a4a5a;
          border-bottom: 1px solid rgba(0,0,0,0.06);
          vertical-align: middle;
        }
        .db-table tbody tr:last-child td { border-bottom: none; }
        .db-table tbody tr:hover { background: var(--db-light); }

        .db-student-name { font-weight: 500; color: var(--db-dark); }
        .db-score-pill {
          display: inline-flex;
          align-items: center;
          font-size: 12px;
          font-weight: 500;
          padding: 3px 10px;
          border-radius: 100px;
          background: rgba(255,200,87,0.10);
          color: rgb(180,83,9);
        }

        .db-badge-method {
          display: inline-flex;
          align-items: center;
          font-size: 11.5px;
          font-weight: 500;
          padding: 4px 10px;
          border-radius: 100px;
          background: rgba(59,130,246,0.10);
          color: rgb(59,130,246);
        }

        .db-table-empty {
          padding: 48px 16px;
          text-align: center;
          color: #b5a090;
          font-size: 13.5px;
        }

        .db-pagination {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 14px 20px;
          flex-wrap: wrap;
          gap: 10px;
          border-top: 1px solid rgba(0,0,0,0.06);
        }
        .db-page-info { font-size: 12px; font-weight: 300; color: #9a8a7a; }
        .db-page-btn {
          display: inline-flex;
          align-items: center;
          gap: 5px;
          padding: 6px 12px;
          font-size: 12.5px;
          color: #7a6a5a;
          background: var(--db-light);
          border: 1px solid var(--db-border);
          border-radius: 7px;
          cursor: pointer;
        }
        .db-page-btn:disabled { opacity: .4; cursor: not-allowed; }
        .db-page-current { padding: 6px 12px; font-size: 12px; color: #9a8a7a; }

        .db-chart-wrap { padding: 20px; height: 280px; }

        .db-actions {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 14px;
          margin-bottom: 28px;
        }
        @media (max-width: 991.98px) { .db-actions { grid-template-columns: repeat(2, 1fr); } }
        @media (max-width: 575.98px)  { .db-actions { grid-template-columns: 1fr 1fr; } }

        .db-action {
          background: #fff;
          border: 1px solid var(--db-border);
          border-radius: var(--db-radius);
          padding: 22px 18px;
          cursor: pointer;
          display: flex;
          flex-direction: column;
          gap: 10px;
          transition: box-shadow .25s, transform .25s, border-color .25s;
          text-decoration: none;
          color: inherit;
        }
        .db-action:hover {
          box-shadow: 0 8px 24px rgba(0,0,0,0.08);
          transform: translateY(-4px);
        }
        .db-action-icon {
          width: 46px;
          height: 46px;
          border-radius: 12px;
          background: var(--ac-bg);
          color: var(--ac-color);
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .db-action-label { font-size: 13.5px; font-weight: 500; color: var(--db-dark); }
        .db-action-desc  { font-size: 11.5px; font-weight: 300; color: #9a8a7a; }

        .db-bank-list {
          display: flex;
          flex-direction: column;
          gap: 12px;
          padding: 18px 20px 20px;
        }
        .db-bank-card {
          border: 1px solid var(--db-border);
          border-radius: 12px;
          padding: 14px;
          background: #fff;
        }
        .db-bank-label {
          font-size: 11px;
          color: #9a8a7a;
          text-transform: uppercase;
          letter-spacing: .08em;
          margin-bottom: 4px;
        }
        .db-bank-val {
          font-size: 14px;
          font-weight: 500;
          color: var(--db-dark);
        }
        .db-bank-sub {
          font-size: 12px;
          color: #9a8a7a;
          margin-top: 8px;
        }

        .db-skeleton {
          height: 14px;
          border-radius: 7px;
          background: linear-gradient(90deg, #f0ebe3 25%, #e8e0d5 50%, #f0ebe3 75%);
          background-size: 200% 100%;
          animation: dbSkeleton 1.4s ease infinite;
        }
        @keyframes dbSkeleton {
          from { background-position: 200% 0; }
          to { background-position: -200% 0; }
        }

        @keyframes dbSpin { to { transform: rotate(360deg); } }
      `}),(0,N.jsx)(st,{sidebarOpen:t,setSidebarOpen:n}),(0,N.jsx)(Y,{title:`Bursar Dashboard`}),(0,N.jsx)(`div`,{className:`container-fluid`,children:(0,N.jsxs)(`div`,{className:`row`,children:[(0,N.jsx)(ct,{sidebarOpen:t}),(0,N.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto db-main`,children:[s&&(0,N.jsx)(G,{message:`Loading finance dashboard…`}),(0,N.jsxs)(`div`,{className:`db-hero`,children:[(0,N.jsx)(`div`,{className:`db-hero-glow`,"aria-hidden":`true`}),(0,N.jsx)(`div`,{className:`db-hero-glow2`,"aria-hidden":`true`}),(0,N.jsxs)(`div`,{className:`db-hero-inner`,children:[(0,N.jsxs)(`div`,{children:[(0,N.jsxs)(`div`,{className:`db-session-badge`,children:[(0,N.jsx)(`span`,{className:`db-session-dot`}),r||`Loading…`,` — `,a||`…`]}),(0,N.jsxs)(`h1`,{className:`db-greeting`,children:[$t(),`, `,(0,N.jsx)(`em`,{children:`Bursar.`})]}),(0,N.jsx)(`p`,{className:`db-hero-sub`,children:`Here is your school's finance overview for the current session and term, including billing, payments, balances, and bank account information.`}),(0,N.jsxs)(`div`,{className:`d-flex flex-wrap gap-2`,children:[(0,N.jsxs)(`button`,{className:`db-btn-gold`,onClick:()=>e(`/payments`),children:[(0,N.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,N.jsx)(`rect`,{x:`2`,y:`4`,width:`12`,height:`8`,rx:`1.5`,stroke:`currentColor`,strokeWidth:`1.4`}),(0,N.jsx)(`path`,{d:`M2 7h12`,stroke:`currentColor`,strokeWidth:`1.3`})]}),`Record Payment`]}),(0,N.jsxs)(`button`,{className:`db-btn-outline`,onClick:()=>e(`/student-fees`),children:[(0,N.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,N.jsx)(`path`,{d:`M3 2.5h10v11H3z`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,N.jsx)(`path`,{d:`M5 5.5h6M5 8h6M5 10.5h4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`})]}),`View Fee Records`]}),(0,N.jsxs)(`button`,{className:`db-btn-outline`,onClick:()=>e(`/fees/ai-collection`),children:[(0,N.jsx)(`i`,{className:`bi bi-robot me-1 text-warning`}),`AI Fee Assistant`]}),(0,N.jsxs)(`button`,{className:`db-btn-outline`,onClick:()=>e(`/settings/ai-credits`),children:[(0,N.jsx)(`i`,{className:`bi bi-stars me-1 text-warning`}),`AI Credits`]})]})]}),(0,N.jsxs)(`div`,{className:`db-hero-stat-card d-none d-md-block`,children:[(0,N.jsx)(`div`,{className:`d-flex align-items-center justify-content-between mb-3`,children:(0,N.jsx)(`span`,{style:{fontSize:11,fontWeight:500,letterSpacing:`0.14em`,textTransform:`uppercase`,color:`var(--db-accent)`},children:`Quick glance`})}),(0,N.jsxs)(`div`,{className:`d-flex flex-column gap-3`,children:[(0,N.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,N.jsx)(`span`,{className:`db-hero-stat-label`,children:`Students with payments`}),(0,N.jsx)(`span`,{className:`db-hero-stat-val`,children:m.paid_students_count})]}),(0,N.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,N.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,N.jsx)(`span`,{className:`db-hero-stat-label`,children:`Students owing`}),(0,N.jsx)(`span`,{className:`db-hero-stat-val`,children:m.owing_students_count})]}),(0,N.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,N.jsxs)(`div`,{className:`db-hero-stat-item`,style:{cursor:`pointer`},onClick:()=>e(`/settings/ai-credits`),title:`View AI Allowance`,children:[(0,N.jsx)(`span`,{className:`db-hero-stat-label`,children:`AI Allowance`}),(0,N.jsx)(`span`,{className:`db-hero-stat-val`,style:{color:`var(--db-accent)`,fontSize:`13px`},children:l?.is_plus_active?l.user_allocation?.is_unlimited?`Unlimited`:`${l.user_allocation?.remaining_credits??l.remaining_credits??0} credits`:`Plus Required`})]})]})]})]})]}),(0,N.jsx)(`div`,{className:`db-stats`,children:f.map(({title:e,value:t},n)=>{let r=Zt[n],i=[(0,N.jsxs)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 20 20`,fill:`none`,children:[(0,N.jsx)(`path`,{d:`M4 5h12v10H4z`,stroke:`currentColor`,strokeWidth:`1.5`}),(0,N.jsx)(`path`,{d:`M4 8h12`,stroke:`currentColor`,strokeWidth:`1.4`})]}),(0,N.jsxs)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 20 20`,fill:`none`,children:[(0,N.jsx)(`circle`,{cx:`10`,cy:`10`,r:`7`,stroke:`currentColor`,strokeWidth:`1.5`}),(0,N.jsx)(`path`,{d:`M6.5 10l2.2 2.2L13.8 7`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),(0,N.jsxs)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 20 20`,fill:`none`,children:[(0,N.jsx)(`circle`,{cx:`10`,cy:`10`,r:`7`,stroke:`currentColor`,strokeWidth:`1.5`}),(0,N.jsx)(`path`,{d:`M10 6v4M10 13h.01`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})]}),(0,N.jsx)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 20 20`,fill:`none`,children:(0,N.jsx)(`path`,{d:`M4 15V7M8 15V4M12 15V9M16 15V6`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})})];return(0,N.jsxs)(`div`,{className:`db-stat`,style:{"--sc":r.color,"--si":r.bg},children:[(0,N.jsx)(`div`,{className:`db-stat-head`,children:(0,N.jsx)(`div`,{className:`db-stat-icon`,children:i[n]})}),(0,N.jsx)(`p`,{className:`db-stat-label`,children:e}),(0,N.jsx)(`div`,{className:`db-stat-val`,children:t}),(0,N.jsx)(`div`,{className:`db-stat-footer`,children:(0,N.jsx)(`span`,{children:r.label})})]},e)})}),(0,N.jsxs)(`div`,{className:`db-grid`,children:[(0,N.jsxs)(`div`,{className:`db-panel`,children:[(0,N.jsxs)(`div`,{className:`db-panel-head`,children:[(0,N.jsxs)(`div`,{className:`d-flex align-items-center gap-3`,children:[(0,N.jsx)(`div`,{className:`db-panel-icon`,style:{"--pi":`var(--db-accent-dim)`,"--pc":`rgb(180,83,9)`},children:(0,N.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,N.jsx)(`rect`,{x:`2`,y:`4`,width:`12`,height:`8`,rx:`1.5`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,N.jsx)(`path`,{d:`M2 7h12`,stroke:`currentColor`,strokeWidth:`1.2`})]})}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`p`,{className:`db-panel-title`,children:`Recent Payments`}),(0,N.jsx)(`p`,{className:`db-panel-sub`,children:`Latest recorded fee payments`})]})]}),(0,N.jsxs)(`button`,{className:`db-refresh-btn`,onClick:()=>V(E),disabled:S,children:[(0,N.jsxs)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,style:{animation:S?`dbSpin 0.8s linear infinite`:`none`},children:[(0,N.jsx)(`path`,{d:`M12 7A5 5 0 112 7`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,N.jsx)(`path`,{d:`M12 3v4h-4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),S?`Loading…`:`Refresh`]})]}),w&&(0,N.jsx)(`div`,{style:{padding:`0 20px 16px`,color:`var(--bs-danger, rgb(239,68,68))`,fontSize:13},children:w}),(0,N.jsx)(`div`,{className:`overflow-auto`,children:(0,N.jsxs)(`table`,{className:`db-table`,children:[(0,N.jsx)(`thead`,{children:(0,N.jsxs)(`tr`,{children:[(0,N.jsx)(`th`,{children:`Reference`}),(0,N.jsx)(`th`,{children:`Student`}),(0,N.jsx)(`th`,{children:`Method`}),(0,N.jsx)(`th`,{children:`Date`}),(0,N.jsx)(`th`,{children:`Amount`})]})}),(0,N.jsx)(`tbody`,{children:S?Array.from({length:6}).map((e,t)=>(0,N.jsx)(`tr`,{children:Array.from({length:5}).map((e,t)=>(0,N.jsx)(`td`,{children:(0,N.jsx)(`div`,{className:`db-skeleton`,style:{width:t===1?140:90}})},t))},t)):v.length===0?(0,N.jsx)(`tr`,{children:(0,N.jsx)(`td`,{colSpan:5,className:`db-table-empty`,children:`No recent payments found.`})}):v.map(e=>(0,N.jsxs)(`tr`,{children:[(0,N.jsx)(`td`,{style:{fontSize:12.5,color:`#9a8a7a`},children:e.reference}),(0,N.jsxs)(`td`,{children:[(0,N.jsx)(`div`,{className:`db-student-name`,children:e.student_name}),(0,N.jsx)(`div`,{style:{fontSize:11.5,color:`#9a8a7a`},children:e.admission_no})]}),(0,N.jsx)(`td`,{children:(0,N.jsx)(`span`,{className:`db-badge-method`,children:e.payment_method||`Unknown`})}),(0,N.jsx)(`td`,{children:tn(e.created_at)}),(0,N.jsx)(`td`,{children:(0,N.jsx)(`span`,{className:`db-score-pill`,children:en(e.amount)})})]},e.id))})]})}),(0,N.jsxs)(`div`,{className:`db-pagination`,children:[(0,N.jsxs)(`span`,{className:`db-page-info`,children:[b,` payment records total`]}),(0,N.jsxs)(`div`,{className:`d-flex align-items-center gap-2`,children:[(0,N.jsx)(`button`,{className:`db-page-btn`,onClick:()=>D(e=>Math.max(1,e-1)),disabled:E<=1||S,children:`Prev`}),(0,N.jsxs)(`span`,{className:`db-page-current`,children:[`Page `,E,` of `,z]}),(0,N.jsx)(`button`,{className:`db-page-btn`,onClick:()=>D(e=>Math.min(z,e+1)),disabled:E>=z||S,children:`Next`})]})]})]}),(0,N.jsxs)(`div`,{className:`db-panel`,style:{display:`flex`,flexDirection:`column`},children:[(0,N.jsx)(`div`,{className:`db-panel-head`,children:(0,N.jsxs)(`div`,{className:`d-flex align-items-center gap-3`,children:[(0,N.jsx)(`div`,{className:`db-panel-icon`,style:{"--pi":`rgba(59,130,246,0.10)`,"--pc":`rgb(59,130,246)`},children:(0,N.jsx)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:(0,N.jsx)(`path`,{d:`M2 12V8M5 12V5M8 12V7M11 12V3M14 12V6`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`})})}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`p`,{className:`db-panel-title`,children:`Payment Method Breakdown`}),(0,N.jsx)(`p`,{className:`db-panel-sub`,children:`Amounts collected by method`})]})]})}),(0,N.jsx)(`div`,{className:`db-chart-wrap`,style:{flex:1},children:(0,N.jsx)(`canvas`,{ref:L})})]})]}),(0,N.jsxs)(`div`,{className:`db-grid`,style:{gridTemplateColumns:`1fr 1fr`},children:[(0,N.jsxs)(`div`,{className:`db-panel`,children:[(0,N.jsx)(`div`,{className:`db-panel-head`,children:(0,N.jsxs)(`div`,{className:`d-flex align-items-center gap-3`,children:[(0,N.jsx)(`div`,{className:`db-panel-icon`,style:{"--pi":`rgba(34,197,94,0.10)`,"--pc":`rgb(21,128,61)`},children:(0,N.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,N.jsx)(`rect`,{x:`2`,y:`4`,width:`12`,height:`8`,rx:`1.4`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,N.jsx)(`path`,{d:`M2 7h12`,stroke:`currentColor`,strokeWidth:`1.2`})]})}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`p`,{className:`db-panel-title`,children:`School Bank Details`}),(0,N.jsx)(`p`,{className:`db-panel-sub`,children:`Extracted from payment gateways`})]})]})}),(0,N.jsx)(`div`,{className:`db-bank-list`,children:A?Array.from({length:2}).map((e,t)=>(0,N.jsxs)(`div`,{className:`db-bank-card`,children:[(0,N.jsx)(`div`,{className:`db-skeleton`,style:{width:120,marginBottom:10}}),(0,N.jsx)(`div`,{className:`db-skeleton`,style:{width:200,marginBottom:8}}),(0,N.jsx)(`div`,{className:`db-skeleton`,style:{width:160}})]},t)):O.length===0?(0,N.jsx)(`div`,{className:`db-table-empty`,children:`No bank details configured.`}):O.map((e,t)=>(0,N.jsxs)(`div`,{className:`db-bank-card`,children:[(0,N.jsx)(`div`,{className:`db-bank-label`,children:`Bank Name`}),(0,N.jsx)(`div`,{className:`db-bank-val`,children:e.bank_name||`N/A`}),(0,N.jsxs)(`div`,{className:`db-bank-sub`,children:[(0,N.jsx)(`strong`,{children:`Account No:`}),` `,e.account_number||`N/A`]}),(0,N.jsxs)(`div`,{className:`db-bank-sub`,children:[(0,N.jsx)(`strong`,{children:`Account Name:`}),` `,e.account_name||`N/A`]})]},t))})]}),(0,N.jsx)(`div`,{className:`db-actions`,children:Qt.map(t=>(0,N.jsxs)(`a`,{href:t.path,className:`db-action`,style:{"--ac-color":t.color,"--ac-bg":t.bg},onClick:n=>{n.preventDefault(),e(t.path)},children:[(0,N.jsx)(`div`,{className:`db-action-icon`,children:t.icon}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`div`,{className:`db-action-label`,children:t.label}),(0,N.jsx)(`div`,{className:`db-action-desc`,children:t.desc})]})]},t.label))})]}),(0,N.jsx)(lt,{})]})]})})]})}const rn={workspace:async()=>(await B.get(`/sales/workspace`)).data,leads:async e=>(await B.get(`/sales/leads`,{params:e})).data,commissions:async e=>(await B.get(`/sales/commissions`,{params:e})).data,createLead:async e=>(await B.post(`/sales/leads`,e)).data,materials:async()=>(await B.get(`/sales/marketing-materials`)).data},an=new Intl.NumberFormat(`en-NG`,{style:`currency`,currency:`NGN`,maximumFractionDigits:0});function on(e){if(!e)return`Not set`;let t=new Date(e);return Number.isNaN(t.getTime())?e:t.toLocaleDateString(`en-GB`,{day:`2-digit`,month:`short`,year:`numeric`})}function sn(e){return e?e.school?.school_name||e.school?.name||e.prospect_school_name||e.demo_booking?.school_name||[e.admin_user?.firstname,e.admin_user?.surname].filter(Boolean).join(` `)||`Lead #${e.id}`:`Lead`}function cn(e){return e&&(e.contact_name||e.contact_email||e.contact_phone||e.demo_booking?.email||e.admin_user?.email||e.school?.email)||`No contact yet`}function ln(e){switch(e){case`offline_invoice`:return`Offline Term Invoice`;case`core_platform_fee`:return`Core Online Fee`;case`subscription`:return`Plus Subscription`;default:return e?e.replace(/_/g,` `):`Revenue`}}function un(e){return!e||e===1?`Term 1 (Acquisition)`:e===2||e===3?`Term ${e} (Retention)`:`Term ${e}`}var dn={assigned_leads:0,converted_leads:0,open_leads:0,pipeline_value:0,pending_commission:0,approved_commission:0,paid_commission:0,monthly_target_amount:0,monthly_target_schools:0};function fn({title:e,value:t,hint:n,icon:r}){return(0,N.jsxs)(`article`,{className:`sales-work-card`,children:[(0,N.jsx)(`span`,{className:`sales-work-icon`,children:(0,N.jsx)(`i`,{className:`bi bi-${r}`})}),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`p`,{children:e}),(0,N.jsx)(`h3`,{children:t}),(0,N.jsx)(`small`,{children:n})]})]})}function pn(){let{showError:e}=Mt(),[t,n]=(0,_.useState)(!1),[r,i]=(0,_.useState)(!0),[a,s]=(0,_.useState)(null),[c,l]=(0,_.useState)(dn),[u,d]=(0,_.useState)([]),[f,p]=(0,_.useState)([]),[m,h]=(0,_.useState)(null),g=async()=>{i(!0);try{let[e,t]=await Promise.all([rn.workspace(),rn.materials()]);s(e.representative||null),l(e.summary||dn),d(e.recent_leads||[]),p(e.commissions||[]),h(t.materials?.[0]||null)}catch(t){e?.(t?.response?.data?.message||`Failed to load sales dashboard.`)}finally{i(!1)}};(0,_.useEffect)(()=>{g()},[]);let v=c.monthly_target_amount>0?Math.min(100,Math.round(c.pipeline_value/c.monthly_target_amount*100)):0;return(0,N.jsxs)(N.Fragment,{children:[(0,N.jsx)(st,{sidebarOpen:t,setSidebarOpen:n,title:`Sales Dashboard`}),(0,N.jsx)(`div`,{className:`container-fluid`,children:(0,N.jsxs)(`div`,{className:`row`,children:[(0,N.jsx)(ct,{sidebarOpen:t,setSidebarOpen:n}),(0,N.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto db-main sales-work-main`,children:[r&&(0,N.jsx)(G,{message:`Loading sales dashboard...`}),(0,N.jsxs)(`div`,{className:`sales-work-shell`,children:[(0,N.jsxs)(`section`,{className:`sales-work-hero`,children:[(0,N.jsxs)(`div`,{children:[(0,N.jsxs)(`div`,{className:`sales-work-eyebrow`,children:[(0,N.jsx)(`i`,{className:`bi bi-briefcase`}),` Sales Workspace`]}),(0,N.jsx)(`h1`,{children:a?.name||`Sales Representative`}),(0,N.jsx)(`p`,{children:`Manage your assigned schools, demo follow-ups, pipeline value, and commission progress from one focused dashboard.`})]}),(0,N.jsxs)(`div`,{className:`sales-work-actions`,children:[(0,N.jsxs)(o,{className:`sales-work-btn sales-work-btn-light`,to:`/sales/leads`,children:[(0,N.jsx)(`i`,{className:`bi bi-kanban`}),` Leads`]}),(0,N.jsxs)(o,{className:`sales-work-btn sales-work-btn-primary`,to:`/sales/marketing-kit`,children:[(0,N.jsx)(`i`,{className:`bi bi-megaphone`}),` Marketing Kit`]})]})]}),m&&(0,N.jsxs)(`section`,{className:`sales-work-panel`,style:{display:`grid`,gridTemplateColumns:m.asset_url?`minmax(220px,360px) 1fr`:`1fr`,gap:22,alignItems:`center`},children:[m.asset_url&&m.type!==`copy`&&(m.type===`video`?(0,N.jsx)(`video`,{controls:!0,src:m.asset_url,style:{width:`100%`,maxHeight:210,borderRadius:14}}):(0,N.jsx)(`img`,{src:m.asset_url,alt:m.title,style:{width:`100%`,maxHeight:210,objectFit:`cover`,borderRadius:14}})),(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`span`,{className:`sales-work-pill sales-work-gold`,children:`Featured campaign`}),(0,N.jsx)(`h2`,{style:{marginTop:12},children:m.title}),(0,N.jsx)(`p`,{children:m.description}),(0,N.jsx)(o,{className:`sales-work-btn sales-work-btn-primary`,to:`/sales/marketing-kit`,children:`Share this campaign`})]})]}),(0,N.jsxs)(`section`,{className:`sales-work-grid`,children:[(0,N.jsx)(fn,{title:`Open Leads`,value:c.open_leads,hint:`${c.assigned_leads} assigned total`,icon:`person-lines-fill`}),(0,N.jsx)(fn,{title:`Converted`,value:c.converted_leads,hint:`Schools won`,icon:`check2-circle`}),(0,N.jsx)(fn,{title:`Pipeline`,value:an.format(c.pipeline_value),hint:`${v}% of target`,icon:`graph-up-arrow`}),(0,N.jsx)(fn,{title:`Pending Commission`,value:an.format(c.pending_commission),hint:`${an.format(c.paid_commission)} paid`,icon:`wallet2`})]}),(0,N.jsxs)(`section`,{className:`sales-work-content`,children:[(0,N.jsxs)(`div`,{className:`sales-work-panel`,children:[(0,N.jsxs)(`div`,{className:`sales-work-head`,children:[(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`h2`,{children:`Recent Leads`}),(0,N.jsx)(`p`,{children:`Your latest assigned prospects and follow-ups.`})]}),(0,N.jsx)(o,{className:`sales-work-btn sales-work-btn-primary`,to:`/sales/leads`,children:`View All`})]}),(0,N.jsxs)(`div`,{className:`sales-work-list`,children:[u.length===0&&(0,N.jsx)(`div`,{className:`sales-work-empty`,children:`No assigned lead yet.`}),u.map(e=>(0,N.jsxs)(`article`,{className:`sales-work-row`,children:[(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`h3`,{children:sn(e)}),(0,N.jsx)(`p`,{children:cn(e)}),(0,N.jsxs)(`div`,{className:`sales-work-meta`,children:[(0,N.jsx)(`span`,{className:`sales-work-pill sales-work-blue`,children:e.stage}),(0,N.jsx)(`span`,{className:`sales-work-pill`,children:an.format(Number(e.pipeline_value||0))}),(0,N.jsxs)(`span`,{className:`sales-work-pill`,children:[`Close: `,on(e.expected_close_date)]})]})]}),(0,N.jsx)(`span`,{className:`sales-work-pill sales-work-gold`,children:e.source})]},e.id))]})]}),(0,N.jsxs)(`aside`,{className:`sales-work-panel`,children:[(0,N.jsx)(`div`,{className:`sales-work-head`,children:(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`h2`,{children:`Commission Snapshot`}),(0,N.jsx)(`p`,{children:`Latest earnings status.`})]})}),(0,N.jsxs)(`div`,{className:`sales-work-list`,children:[f.length===0&&(0,N.jsx)(`div`,{className:`sales-work-empty`,children:`No commission recorded yet.`}),f.map(e=>(0,N.jsx)(`article`,{className:`sales-work-row`,children:(0,N.jsxs)(`div`,{children:[(0,N.jsx)(`h3`,{children:an.format(Number(e.amount||0))}),(0,N.jsx)(`p`,{children:e.school?.name||`School not linked`}),(0,N.jsxs)(`div`,{className:`sales-work-meta`,children:[(0,N.jsx)(`span`,{className:`sales-work-pill sales-work-green`,children:e.status}),(0,N.jsxs)(`span`,{className:`sales-work-pill`,children:[`Earned: `,on(e.earned_at)]})]})]})},e.id))]})]})]}),(0,N.jsx)(lt,{})]})]})]})})]})}function mn(){let e=A();if(!e)return(0,N.jsx)(`div`,{className:`text-center mt-5`,children:(0,N.jsx)(`h3`,{children:`User not found. Please login again.`})});switch(e.role){case`Admin`:case`Operator`:return(0,N.jsx)(`div`,{className:`pt-5`,children:(0,N.jsx)(vt,{})});case`Super-Admin`:case`Platform-Staff`:return(0,N.jsx)(`div`,{className:`pt-5`,children:(0,N.jsx)(Kt,{})});case`Teacher`:return(0,N.jsx)(`div`,{className:`pt-5`,children:(0,N.jsx)(xt,{})});case`Student`:return(0,N.jsx)(`div`,{className:`pt-5`,children:(0,N.jsx)(Ot,{})});case`Bursar`:return(0,N.jsx)(`div`,{className:`pt-5`,children:(0,N.jsx)(nn,{})});case`Parent`:return(0,N.jsx)(`div`,{className:`pt-5`,children:(0,N.jsx)(Xt,{})});case`Sales-Representative`:return(0,N.jsx)(`div`,{className:`pt-5`,children:(0,N.jsx)(pn,{})});default:return(0,N.jsx)(`div`,{className:`text-center mt-5`,children:(0,N.jsx)(`h3`,{children:`Unauthorized role. Please contact admin.`})})}}var hn=(0,_.lazy)(()=>p(()=>import(`./Unauthorized-71bQLUxl.js`),__vite__mapDeps([0,1,2,3,4,5,6,7]))),gn=(0,_.lazy)(()=>p(()=>import(`./NotFoundPage-Cg54fdsg.js`),__vite__mapDeps([8,1,2,3,4,5,6]))),_n=(0,_.lazy)(()=>p(()=>import(`./ForbiddenPage-DlxQ3X-p.js`),__vite__mapDeps([9,1,2,3,4,5,6,7]))),vn=(0,_.lazy)(()=>p(()=>import(`./ServerErrorPage-yUo7LvSf.js`),__vite__mapDeps([10,1,2,3,4,5,6]))),yn=(0,_.lazy)(()=>p(()=>import(`./MaintenancePage-Be-ZbrZB.js`),__vite__mapDeps([11,1,2,3,4,5,6,12]))),bn=(0,_.lazy)(()=>p(()=>import(`./SubscriptionRequiredPage-wbLwNw2M.js`),__vite__mapDeps([13,1,2,3,4,5,6]))),xn=(0,_.lazy)(()=>p(()=>import(`./SuperAdminDashboard-BBFoMycN.js`),__vite__mapDeps([14,1,2,3,5,4,6,12]))),Sn=(0,_.lazy)(()=>p(()=>import(`./StudentsPage-CVyqFl_y.js`),__vite__mapDeps([15,1,2,3,5,4,6,12]))),Cn=(0,_.lazy)(()=>p(()=>import(`./AttendancePage-abzPSGEE.js`),__vite__mapDeps([16,1,2,3,4,5,6,12]))),wn=(0,_.lazy)(()=>p(()=>import(`./StudentReportPage-SH9J0usc.js`),__vite__mapDeps([17,1,2,3,4,5,6,12]))),Tn=(0,_.lazy)(()=>p(()=>import(`./StudentRegisterPage-h2A-r3xV.js`),__vite__mapDeps([18,1,2,3,4,5,6,12]))),En=(0,_.lazy)(()=>p(()=>import(`./FinancialRecord-BueHR8Su.js`),__vite__mapDeps([19,1,2,3,5,4,6,12]))),Dn=(0,_.lazy)(()=>p(()=>import(`./AddResultV2Page-DzelA7Am.js`),__vite__mapDeps([20,1,2,3,4,5,6,12]))),On=(0,_.lazy)(()=>p(()=>import(`./AdminStudentResultLookupPage-wof5gnc3.js`),__vite__mapDeps([21,1,2,3,4,5,6,12,22]))),kn=(0,_.lazy)(()=>p(()=>import(`./ResultBatchSetupPage-Bn6Rd24P.js`),__vite__mapDeps([23,1,2,3,4,5,6,12]))),An=(0,_.lazy)(()=>p(()=>import(`./ResultUploadPage-Cdpiq2JW.js`),__vite__mapDeps([24,1,2,3,4,5,6,12]))),jn=(0,_.lazy)(()=>p(()=>import(`./AdminResultReviewPage-CEA9yi6u.js`),__vite__mapDeps([25,1,2,3,4,5,6,12]))),Mn=(0,_.lazy)(()=>p(()=>import(`./ResultTemplateSettingsPage-D8cWAy-P.js`),__vite__mapDeps([26,1,2,3,4,5,6,12]))),Nn=(0,_.lazy)(()=>p(()=>import(`./ShowResult-Pa3awKRe.js`),__vite__mapDeps([27,1,2,3,4,5,6,12,22]))),Pn=(0,_.lazy)(()=>p(()=>import(`./AcademicCalendarPage-BksqYwwx.js`),__vite__mapDeps([28,1,2,3,4,5,6,12]))),Fn=(0,_.lazy)(()=>p(()=>import(`./LegalPage-D5RVfbop.js`),__vite__mapDeps([29,1,2,3,4,5,6,30])).then(e=>({default:e.PrivacyPolicyPage}))),In=(0,_.lazy)(()=>p(()=>import(`./LegalPage-D5RVfbop.js`),__vite__mapDeps([29,1,2,3,4,5,6,30])).then(e=>({default:e.TermsAndConditionsPage}))),Ln=(0,_.lazy)(()=>p(()=>import(`./BroadsheetPage-DGfx8Hq1.js`),__vite__mapDeps([31,1,2,3,4,5,6,12]))),Rn=(0,_.lazy)(()=>p(()=>import(`./LevelsPage-UYbpOcMc.js`),__vite__mapDeps([32,1,2,3,4,5,6,12]))),zn=(0,_.lazy)(()=>p(()=>import(`./SubjectsPage-CfuqkCf9.js`),__vite__mapDeps([33,1,2,3,4,5,6,12]))),Bn=(0,_.lazy)(()=>p(()=>import(`./DepartmentPage-B8qJLIlq.js`),__vite__mapDeps([34,1,2,3,4,5,6,12]))),Vn=(0,_.lazy)(()=>p(()=>import(`./SectionsPage-DgPoAbEb.js`),__vite__mapDeps([35,1,2,3,4,5,6,12]))),Hn=(0,_.lazy)(()=>p(()=>import(`./FeeMethodsPage-Co6ovFfa.js`),__vite__mapDeps([36,1,2,3,4,5,6,12]))),Un=(0,_.lazy)(()=>p(()=>import(`./FeeStructurePage-BZHBRyNm.js`),__vite__mapDeps([37,1,2,3,4,5,6,12]))),Wn=(0,_.lazy)(()=>p(()=>import(`./StudentFeePaymentPage-CQfkg0hV.js`),__vite__mapDeps([38,1,2,3,4,5,6,12]))),Gn=(0,_.lazy)(()=>p(()=>import(`./ReceiptApprovalPage-BUNX1QKw.js`),__vite__mapDeps([39,1,2,3,4,5,6,12]))),Kn=(0,_.lazy)(()=>p(()=>import(`./FeesReport-Xgbh03gR.js`),__vite__mapDeps([40,1,2,3,5,4,6,12]))),qn=(0,_.lazy)(()=>p(()=>import(`./SettingsPage-BBuQoO0t.js`),__vite__mapDeps([41,1,2,3,4,5,6,12]))),Jn=(0,_.lazy)(()=>p(()=>import(`./PromoteStudentsPage-CLT8SL_w.js`),__vite__mapDeps([42,1,2,3,4,5,6,12]))),Yn=(0,_.lazy)(()=>p(()=>import(`./BillingPage-DIU5GBZA.js`),__vite__mapDeps([43,1,2,3,4,5,6,12])));(0,_.lazy)(()=>p(()=>import(`./CheckoutPage-4MQZaXPn.js`),__vite__mapDeps([44,1,2,3,4,5,6,12])));var Xn=(0,_.lazy)(()=>p(()=>import(`./SchoolProfitInvoicePaymentPage-CHKyDlbU.js`),__vite__mapDeps([45,1,2,3,4,5,6,12]))),Zn=(0,_.lazy)(()=>p(()=>import(`./WalletPage-BGlO3qRE.js`),__vite__mapDeps([46,1,2,3,4,5,6,12]))),Qn=(0,_.lazy)(()=>p(()=>import(`./AdminUserDetailsPage-C5m2ndvR.js`),__vite__mapDeps([47,1,2,3,4,5,6,12]))),$n=(0,_.lazy)(()=>p(()=>import(`./SubscribersManagementPage-cp14OsD4.js`),__vite__mapDeps([48,1,2,3,4,5,6,12]))),er=(0,_.lazy)(()=>p(()=>import(`./MarketingEmailPage-DltFZsK4.js`),__vite__mapDeps([49,1,2,3,4,5,6,12]))),tr=(0,_.lazy)(()=>p(()=>import(`./SalesRepresentativesPage-BolDB-xm.js`),__vite__mapDeps([50,1,2,3,4,5,6,12]))),nr=(0,_.lazy)(()=>p(()=>import(`./SalesLeadsPage-O2OA5FJ9.js`),__vite__mapDeps([51,1,2,3,4,5,6,12]))),rr=(0,_.lazy)(()=>p(()=>import(`./SalesPayoutsPage-mQazvdgU.js`),__vite__mapDeps([52,1,2,3,4,5,6,12]))),ir=(0,_.lazy)(()=>p(()=>import(`./PlatformStaffPage-8OcTxCR9.js`),__vite__mapDeps([53,1,2,3,4,5,6,12]))),ar=(0,_.lazy)(()=>p(()=>import(`./SubscriptionPlansPage-CZh3leJ-.js`),__vite__mapDeps([54,1,2,3,4,5,6,12]))),or=(0,_.lazy)(()=>p(()=>import(`./BillingPolicyPage-3h4Vtg4N.js`),__vite__mapDeps([55,1,2,3,4,5,6,12]))),sr=(0,_.lazy)(()=>p(()=>import(`./TwilioWhatsappPage-BbUl9VBa.js`),__vite__mapDeps([56,1,2,3,4,5,6,12]))),cr=(0,_.lazy)(()=>p(()=>import(`./BlogsPage-BoRk-819.js`),__vite__mapDeps([57,1,2,3,4,5,6,12]))),lr=(0,_.lazy)(()=>p(()=>import(`./TestimonialsPage-BVfFrrpQ.js`),__vite__mapDeps([58,1,2,3,4,5,6,12]))),ur=(0,_.lazy)(()=>p(()=>import(`./StaffQrAttendancePage-v2bM17lt.js`),__vite__mapDeps([59,1,2,3,4,5,6,12]))),dr=(0,_.lazy)(()=>p(()=>import(`./StaffAttendanceLogsPage--Wf-l2HG.js`),__vite__mapDeps([60,1,2,3,4,5,6,12]))),fr=(0,_.lazy)(()=>p(()=>import(`./AttendanceSettingsPage-Cbdw6CxG.js`),__vite__mapDeps([61,1,2,3,4,5,6,12]))),pr=(0,_.lazy)(()=>p(()=>import(`./TeachersPage-Croer2R3.js`),__vite__mapDeps([62,1,2,3,4,5,6,12,63]))),mr=(0,_.lazy)(()=>p(()=>import(`./TeacherSubjectsPage-J2tAh5Dr.js`),__vite__mapDeps([64,1,2,3,4,5,6,12]))),hr=(0,_.lazy)(()=>p(()=>import(`./ParentsPage-CJOJqggY.js`),__vite__mapDeps([65,1,2,3,4,5,6,12,63]))),gr=(0,_.lazy)(()=>p(()=>import(`./StudentMyFeesPage-erw9pAz7.js`),__vite__mapDeps([66,1,2,3,4,5,6,12]))),_r=(0,_.lazy)(()=>p(()=>import(`./StudentMySubjectsPage-BHN5xHbJ.js`),__vite__mapDeps([67,1,2,3,4,5,6,12]))),vr=(0,_.lazy)(()=>p(()=>import(`./ParentChildrenPage-MLbxHX94.js`),__vite__mapDeps([68,1,2,3,4,5,6,12]))),yr=(0,_.lazy)(()=>p(()=>import(`./SchoolBankAccountsPage-BRrAr5QI.js`),__vite__mapDeps([69,1,2,3,4,5,6,12]))),br=(0,_.lazy)(()=>p(()=>import(`./SchoolOperatorsPage-OdW2Vfx1.js`),__vite__mapDeps([70,1,2,3,4,5,6,12]))),xr=(0,_.lazy)(()=>p(()=>import(`./ChildFeeDetailsPage-VABlBNnv.js`),__vite__mapDeps([71,1,2,3,4,5,6,12]))),Sr=(0,_.lazy)(()=>p(()=>import(`./ParentAttendancePage-B1k8B9c7.js`),__vite__mapDeps([72,1,2,3,4,5,6,12]))),Cr=(0,_.lazy)(()=>p(()=>import(`./ParentCommunicationPage-DrvyANxq.js`),__vite__mapDeps([73,1,2,3,4,5,6,12]))),wr=(0,_.lazy)(()=>p(()=>import(`./ParentSchoolInfoPage-Dm-Jgj5-.js`),__vite__mapDeps([74,1,2,3,4,5,6,12]))),Tr=(0,_.lazy)(()=>p(()=>import(`./ParentResultsPage-C2GV75rV.js`),__vite__mapDeps([75,1,2,3,4,5,6,12]))),Er=(0,_.lazy)(()=>p(()=>import(`./ReceiptUploadPage-BE8ZfWUe.js`),__vite__mapDeps([76,1,2,3,4,5,6,12]))),Dr=(0,_.lazy)(()=>p(()=>import(`./ParentPaymentSummaryPage-Dlxu-buj.js`),__vite__mapDeps([77,1,2,3,4,5,6,12]))),Or=(0,_.lazy)(()=>p(()=>import(`./ResultPinsPage-B0N_pPhY.js`),__vite__mapDeps([78,1,2,3,4,5,6,12]))),kr=(0,_.lazy)(()=>p(()=>import(`./CheckResultPage-Ck18bkFr.js`),__vite__mapDeps([79,1,2,3,4,5,6,12,22]))),Ar=(0,_.lazy)(()=>p(()=>import(`./VerifyResultPage-C2WT-Qxv.js`),__vite__mapDeps([80,1,2,3,4,5,6,12,22]))),jr=(0,_.lazy)(()=>p(()=>import(`./OnboardingPage-CwGkZRSo.js`),__vite__mapDeps([81,1,2,3,4,5,6,12]))),Mr=(0,_.lazy)(()=>p(()=>import(`./ProfileSettingsPage-Lx-3JkmX.js`),__vite__mapDeps([82,1,2,3,4,5,6,12]))),Nr=(0,_.lazy)(()=>p(()=>import(`./NotificationsPage-BxyJ42EV.js`),__vite__mapDeps([83,1,2,3,4,5,6,12]))),Pr=(0,_.lazy)(()=>p(()=>import(`./InvoiceNotificationsPage-BbT9a9VJ.js`),__vite__mapDeps([84,1,2,3,4,5,6,12]))),Fr=(0,_.lazy)(()=>p(()=>import(`./InvoiceNotificationDetailsPage-DVWFunbx.js`),__vite__mapDeps([85,1,2,3,4,5,6,12]))),Ir=(0,_.lazy)(()=>p(()=>import(`./PaymentInstructionsPage-DlsjLY6j.js`),__vite__mapDeps([86,1,2,3,4,5,6,12]))),Lr=(0,_.lazy)(()=>p(()=>import(`./Bookdemo -BZlZ80-O.js`),__vite__mapDeps([87,2,3,4,1,5,6,12]))),Rr=(0,_.lazy)(()=>p(()=>import(`./DemoBookingsPage-CLXj5qZ1.js`),__vite__mapDeps([88,1,2,3,4,5,6,12]))),zr=(0,_.lazy)(()=>p(()=>import(`./BursarsPage-ClCj-KUL.js`),__vite__mapDeps([89,1,2,3,4,5,6,12]))),Br=(0,_.lazy)(()=>p(()=>import(`./Forgotpasswordpage-CTH0qRv3.js`),__vite__mapDeps([90,1,2,3,4,5,6,12]))),Vr=(0,_.lazy)(()=>p(()=>import(`./Resetpasswordpage-DbzfAtkw.js`),__vite__mapDeps([91,1,2,3,4,5,6,12]))),Hr=(0,_.lazy)(()=>p(()=>import(`./ResultSubmissionDeadlinePage-Bvq19kx9.js`),__vite__mapDeps([92,1,2,3,4,5,6,12]))),Ur=(0,_.lazy)(()=>p(()=>import(`./Resultmonitoringpage-C5bERTqW.js`),__vite__mapDeps([93,1,2,3,4,5,6,12]))),Wr=(0,_.lazy)(()=>p(()=>import(`./CbtExamsPage-DfkaDg1Q.js`),__vite__mapDeps([94,1,2,3,6,4,5,12,95]))),Gr=(0,_.lazy)(()=>p(()=>import(`./StudentCbtExamsPage-DxYCJs56.js`),__vite__mapDeps([96,1,2,3,4,5,6,12,95]))),Kr=(0,_.lazy)(()=>p(()=>import(`./StudentLessonNotesPage-BSC83hlk.js`),__vite__mapDeps([97,1,2,3,4,5,6,12]))),qr=(0,_.lazy)(()=>p(()=>import(`./WhatsAppSettingsPage-CLKLiMjk.js`),__vite__mapDeps([98,1,2,3,4,5,6,12]))),Jr=(0,_.lazy)(()=>p(()=>import(`./AiCreditsPage-C_H1RwUt.js`),__vite__mapDeps([99,1,2,3,4,5,6,12]))),Yr=(0,_.lazy)(()=>p(()=>import(`./AiLessonPlanPage-8LYTUgTV.js`),__vite__mapDeps([100,1,2,3,4,5,6,12]))),Xr=(0,_.lazy)(()=>p(()=>import(`./AiFeeCollectionAssistantPage-BkLNIEUY.js`),__vite__mapDeps([101,1,2,3,4,5,6,12]))),Zr=(0,_.lazy)(()=>p(()=>import(`./FeePolicyPage-DswmNVZl.js`),__vite__mapDeps([102,1,2,3,4,5,6,12])));(0,_.lazy)(()=>p(()=>import(`./OnlinePayFeesPage-C5B7H6bG.js`),__vite__mapDeps([103,2,3,4,1,5,6,12])));var Qr=(0,_.lazy)(()=>p(()=>import(`./PublicFeePaymentPage-CyRDBX8Q.js`),__vite__mapDeps([104,2,3,4,1,5,6,12]))),$r=(0,_.lazy)(()=>p(()=>import(`./PublicCbtAccessPage-kzOks-nd.js`),__vite__mapDeps([105,1,2,3,4,5,6,12,95]))),ei=(0,_.lazy)(()=>p(()=>import(`./OfflineCbtRunnerPage-DzhHU9iW.js`),__vite__mapDeps([106,2,3,4,1,5,6,95]))),ti=(0,_.lazy)(()=>p(()=>import(`./SalesLeadsPage-DQBcp4bD.js`),__vite__mapDeps([107,1,2,3,4,5,6,12]))),ni=(0,_.lazy)(()=>p(()=>import(`./SalesCommissionsPage-BggmffsM.js`),__vite__mapDeps([108,1,2,3,4,5,6,12]))),ri=(0,_.lazy)(()=>p(()=>import(`./SalesPayoutSettingsPage-CmEyxl19.js`),__vite__mapDeps([109,1,2,3,4,5,6,12]))),ii=(0,_.lazy)(()=>p(()=>import(`./SalesMarketingKitPage-DYwtnreK.js`),__vite__mapDeps([110,1,2,3,4,5,6,12]))),ai=(0,_.lazy)(()=>p(()=>import(`./SalesMarketingMaterialsPage-ECkb_RHY.js`),__vite__mapDeps([111,1,2,3,4,5,6,12]))),oi=(0,_.lazy)(()=>p(()=>import(`./PublicRepresentativeSalesPage-pCl3tQ70.js`),__vite__mapDeps([112,1,2,3,4,5,6,12]))),si=(0,_.lazy)(()=>p(()=>import(`./PublicRepresentativeRegisterPage-DAG1Qjh-.js`),__vite__mapDeps([113,1,2,3,4,5,6,12]))),ci=(0,_.lazy)(()=>p(()=>import(`./ChangeInitialPasswordPage-uwTprrAj.js`),__vite__mapDeps([114,1,2,3,4,5,6,12]))),li=(0,_.lazy)(()=>p(()=>import(`./SupportTicketsPage-C5oq-0NO.js`),__vite__mapDeps([115,1,2,3,4,5,6,12]))),ui=(0,_.lazy)(()=>p(()=>import(`./HostelManagementPage-CcBdZUum.js`),__vite__mapDeps([116,1,2,3,4,5,6,12]))),di=(0,_.lazy)(()=>p(()=>import(`./TransportManagementPage-CsNkn2LI.js`),__vite__mapDeps([117,1,2,3,4,5,6,12]))),fi=(0,_.lazy)(()=>p(()=>import(`./WithdrawnStudentResultsPage-DhV_54tL.js`),__vite__mapDeps([118,1,2,3,4,5,6,12,119]))),pi=(0,_.lazy)(()=>p(()=>import(`./TranscriptsPage-Dbo5QDbr.js`),__vite__mapDeps([120,1,2,3,4,5,6,12,119]))),mi=(0,_.lazy)(()=>p(()=>import(`./NewsletterSubscribersPage-CWnGtPey.js`),__vite__mapDeps([121,1,2,3,4,5,6,12]))),hi=(0,_.lazy)(()=>p(()=>import(`./PublicBlogDetailPage-9CpT9Sdv.js`),__vite__mapDeps([122,1,2,3,4,5,6,12])));function gi(){return(0,N.jsx)(s,{children:(0,N.jsx)(ce,{children:(0,N.jsx)(te,{children:(0,N.jsx)(_.Suspense,{fallback:(0,N.jsx)(G,{message:`Preparing page...`}),children:(0,N.jsxs)(f,{children:[(0,N.jsx)(l,{path:`/`,element:v()?(0,N.jsx)(r,{to:`/login`,replace:!0}):(0,N.jsx)(Ue,{})}),(0,N.jsx)(l,{path:`/login`,element:(0,N.jsx)(X,{})}),(0,N.jsx)(l,{path:`/register`,element:(0,N.jsx)(Ge,{})}),(0,N.jsx)(l,{path:`/sales-representative/register`,element:(0,N.jsx)(si,{})}),(0,N.jsx)(l,{path:`/become-a-partner`,element:(0,N.jsx)(si,{})}),(0,N.jsx)(l,{path:`/sales-page/:code`,element:(0,N.jsx)(oi,{})}),(0,N.jsx)(l,{path:`/check-result`,element:(0,N.jsx)(kr,{})}),(0,N.jsx)(l,{path:`/results/check`,element:(0,N.jsx)(kr,{})}),(0,N.jsx)(l,{path:`/results/check-result`,element:(0,N.jsx)(kr,{})}),(0,N.jsx)(l,{path:`/check-term-result`,element:(0,N.jsx)(kr,{})}),(0,N.jsx)(l,{path:`/student/check-result`,element:(0,N.jsx)(kr,{})}),(0,N.jsx)(l,{path:`/verify-result`,element:(0,N.jsx)(Ar,{})}),(0,N.jsx)(l,{path:`/unauthorized`,element:(0,N.jsx)(hn,{})}),(0,N.jsx)(l,{path:`/payment-instructions/`,element:(0,N.jsx)(Ir,{})}),(0,N.jsx)(l,{path:`/pay-school-fee`,element:(0,N.jsx)(Qr,{})}),(0,N.jsx)(l,{path:`/pay-fees`,element:(0,N.jsx)(Qr,{})}),(0,N.jsx)(l,{path:`/pay-fee`,element:(0,N.jsx)(Qr,{})}),(0,N.jsx)(l,{path:`/payonline`,element:(0,N.jsx)(Qr,{})}),(0,N.jsx)(l,{path:`/cbt/access`,element:(0,N.jsx)($r,{})}),(0,N.jsx)(l,{path:`/cbt/offline-runner`,element:(0,N.jsx)(ei,{})}),(0,N.jsx)(l,{path:`/book-demo`,element:(0,N.jsx)(Lr,{})}),(0,N.jsx)(l,{path:`/privacy-policy`,element:(0,N.jsx)(Fn,{})}),(0,N.jsx)(l,{path:`/terms-and-conditions`,element:(0,N.jsx)(In,{})}),(0,N.jsx)(l,{path:`/blog/:slug`,element:(0,N.jsx)(hi,{})}),(0,N.jsx)(l,{path:`/forgot-password`,element:(0,N.jsx)(Br,{})}),(0,N.jsx)(l,{path:`/reset-password`,element:(0,N.jsx)(Vr,{})}),(0,N.jsx)(l,{path:`/change-password`,element:(0,N.jsx)(P,{roles:[`Admin`,`Sales-Representative`,`Platform-Staff`],children:(0,N.jsx)(ci,{})})}),(0,N.jsx)(l,{path:`/onboarding`,element:(0,N.jsx)(P,{roles:[`Admin`],children:(0,N.jsx)(jr,{})})}),(0,N.jsx)(l,{path:`/support`,element:(0,N.jsx)(P,{roles:[`Admin`,`Teacher`,`Super-Admin`,`Platform-Staff`,`Student`,`Parent`,`Bursar`,`Sales-Representative`],children:(0,N.jsx)(li,{})})}),(0,N.jsx)(l,{path:`/helpdesk`,element:(0,N.jsx)(P,{roles:[`Admin`,`Teacher`,`Super-Admin`,`Platform-Staff`,`Student`,`Parent`,`Bursar`,`Sales-Representative`],children:(0,N.jsx)(li,{})})}),(0,N.jsx)(l,{path:`/contact-support`,element:(0,N.jsx)(P,{roles:[`Admin`,`Teacher`,`Super-Admin`,`Platform-Staff`,`Student`,`Parent`,`Bursar`,`Sales-Representative`],children:(0,N.jsx)(li,{})})}),(0,N.jsx)(l,{path:`/hostels`,element:(0,N.jsx)(P,{roles:[`Admin`],children:(0,N.jsx)(ui,{})})}),(0,N.jsx)(l,{path:`/transport`,element:(0,N.jsx)(P,{roles:[`Admin`],children:(0,N.jsx)(di,{})})}),(0,N.jsx)(l,{path:`/superadmin/support`,element:(0,N.jsx)(P,{roles:[`Super-Admin`,`Platform-Staff`],permissions:[`support`],children:(0,N.jsx)(li,{})})}),(0,N.jsx)(l,{path:`/dashboard`,element:(0,N.jsx)(P,{roles:[`Admin`,`Teacher`,`Super-Admin`,`Platform-Staff`,`Student`,`Parent`,`Bursar`,`Sales-Representative`],children:(0,N.jsx)(q,{children:(0,N.jsx)(mn,{})})})}),(0,N.jsx)(l,{path:`/results/deadlines`,element:(0,N.jsx)(P,{roles:[`Admin`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Hr,{})})})}),(0,N.jsx)(l,{path:`/results/withdrawn-archive`,element:(0,N.jsx)(P,{roles:[`Admin`],children:(0,N.jsx)(q,{children:(0,N.jsx)(fi,{})})})}),(0,N.jsx)(l,{path:`/transcripts`,element:(0,N.jsx)(P,{roles:[`Admin`],children:(0,N.jsx)(q,{children:(0,N.jsx)(pi,{})})})}),(0,N.jsx)(l,{path:`/notifications`,element:(0,N.jsx)(P,{roles:[`Admin`,`Teacher`,`Super-Admin`,`Platform-Staff`,`Student`,`Parent`,`Bursar`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Nr,{})})})}),(0,N.jsx)(l,{path:`/students`,element:(0,N.jsx)(P,{roles:[`Admin`,`Teacher`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Sn,{})})})}),(0,N.jsx)(l,{path:`/bursar`,element:(0,N.jsx)(P,{roles:[`Admin`],children:(0,N.jsx)(q,{children:(0,N.jsx)(zr,{})})})}),(0,N.jsx)(l,{path:`/students/attendance`,element:(0,N.jsx)(P,{roles:[`Admin`,`Teacher`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Cn,{})})})}),(0,N.jsx)(l,{path:`/students/report`,element:(0,N.jsx)(P,{roles:[`Admin`,`Teacher`],children:(0,N.jsx)(q,{children:(0,N.jsx)(wn,{})})})}),(0,N.jsx)(l,{path:`/students/register`,element:(0,N.jsx)(P,{roles:[`Admin`,`Teacher`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Tn,{})})})}),(0,N.jsx)(l,{path:`/students/promote`,element:(0,N.jsx)(P,{roles:[`Admin`,`Teacher`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Jn,{})})})}),(0,N.jsx)(l,{path:`/report/finance`,element:(0,N.jsx)(P,{roles:[`Admin`],children:(0,N.jsx)(q,{children:(0,N.jsx)(En,{})})})}),(0,N.jsx)(l,{path:`/students/results/add`,element:(0,N.jsx)(P,{roles:[`Admin`,`Teacher`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Dn,{})})})}),(0,N.jsx)(l,{path:`/results/student-editor`,element:(0,N.jsx)(P,{roles:[`Admin`,`Teacher`,`Super-Admin`,`Platform-Staff`],children:(0,N.jsx)(q,{children:(0,N.jsx)(On,{})})})}),(0,N.jsx)(l,{path:`/results/lookup`,element:(0,N.jsx)(P,{roles:[`Admin`,`Teacher`,`Super-Admin`,`Platform-Staff`],children:(0,N.jsx)(q,{children:(0,N.jsx)(On,{})})})}),(0,N.jsx)(l,{path:`/students/results/edit`,element:(0,N.jsx)(P,{roles:[`Admin`,`Teacher`,`Super-Admin`,`Platform-Staff`],children:(0,N.jsx)(q,{children:(0,N.jsx)(On,{})})})}),(0,N.jsx)(l,{path:`/admin/result-editor`,element:(0,N.jsx)(P,{roles:[`Admin`,`Teacher`,`Super-Admin`,`Platform-Staff`],children:(0,N.jsx)(q,{children:(0,N.jsx)(On,{})})})}),(0,N.jsx)(l,{path:`/students/results/lookup`,element:(0,N.jsx)(P,{roles:[`Admin`,`Teacher`,`Super-Admin`,`Platform-Staff`],children:(0,N.jsx)(q,{children:(0,N.jsx)(On,{})})})}),(0,N.jsx)(l,{path:`/students/results/batch`,element:(0,N.jsx)(P,{roles:[`Admin`,`Teacher`],children:(0,N.jsx)(q,{children:(0,N.jsx)(kn,{})})})}),(0,N.jsx)(l,{path:`/result/monitor`,element:(0,N.jsx)(P,{roles:[`Admin`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Ur,{})})})}),(0,N.jsx)(l,{path:`/results/review`,element:(0,N.jsx)(P,{roles:[`Admin`],children:(0,N.jsx)(q,{children:(0,N.jsx)(jn,{})})})}),(0,N.jsx)(l,{path:`/results/upload`,element:(0,N.jsx)(P,{roles:[`Admin`,`Teacher`],children:(0,N.jsx)(q,{children:(0,N.jsx)(An,{})})})}),(0,N.jsx)(l,{path:`/results/pins`,element:(0,N.jsx)(P,{roles:[`Admin`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Or,{})})})}),(0,N.jsx)(l,{path:`/admin/result-monitoring`,element:(0,N.jsx)(P,{roles:[`Admin`],children:(0,N.jsx)(q,{children:(0,N.jsx)(r,{to:`/result/monitor`,replace:!0})})})}),(0,N.jsx)(l,{path:`/admin/academic-alerts`,element:(0,N.jsx)(P,{roles:[`Admin`],children:(0,N.jsx)(q,{children:(0,N.jsx)(r,{to:`/result/monitor`,replace:!0})})})}),(0,N.jsx)(l,{path:`/results/design`,element:(0,N.jsx)(P,{roles:[`Admin`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Mn,{})})})}),(0,N.jsx)(l,{path:`/students/results/show`,element:(0,N.jsx)(P,{roles:[`Admin`,`Teacher`,`Student`,`Parent`,`Super Admin`,`SuperAdmin`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Nn,{})})})}),(0,N.jsx)(l,{path:`/show-result`,element:(0,N.jsx)(P,{roles:[`Admin`,`Teacher`,`Student`,`Parent`,`Super Admin`,`SuperAdmin`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Nn,{})})})}),(0,N.jsx)(l,{path:`/results/show`,element:(0,N.jsx)(P,{roles:[`Admin`,`Teacher`,`Student`,`Parent`,`Super Admin`,`SuperAdmin`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Nn,{})})})}),(0,N.jsx)(l,{path:`/results/show-result`,element:(0,N.jsx)(P,{roles:[`Admin`,`Teacher`,`Student`,`Parent`,`Super Admin`,`SuperAdmin`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Nn,{})})})}),(0,N.jsx)(l,{path:`/academics/calendar`,element:(0,N.jsx)(P,{roles:[`Admin`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Pn,{})})})}),(0,N.jsx)(l,{path:`/results/broadsheet`,element:(0,N.jsx)(P,{roles:[`Admin`,`Teacher`],children:(0,N.jsx)(q,{children:(0,N.jsx)(jn,{})})})}),(0,N.jsx)(l,{path:`/results/broadsheet/:batchId`,element:(0,N.jsx)(P,{roles:[`Admin`,`Teacher`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Ln,{})})})}),(0,N.jsx)(l,{path:`/cbt/exams`,element:(0,N.jsx)(P,{roles:[`Admin`,`Teacher`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Wr,{})})})}),(0,N.jsx)(l,{path:`/student/cbt/exams`,element:(0,N.jsx)(P,{roles:[`Student`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Gr,{})})})}),`          `,(0,N.jsx)(l,{path:`/student/lesson-notes`,element:(0,N.jsx)(P,{roles:[`Student`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Kr,{})})})}),(0,N.jsx)(l,{path:`/levels`,element:(0,N.jsx)(P,{roles:[`Admin`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Rn,{})})})}),(0,N.jsx)(l,{path:`/subjects`,element:(0,N.jsx)(P,{roles:[`Admin`],children:(0,N.jsx)(q,{children:(0,N.jsx)(zn,{})})})}),(0,N.jsx)(l,{path:`/departments`,element:(0,N.jsx)(P,{roles:[`Admin`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Bn,{})})})}),(0,N.jsx)(l,{path:`/sections`,element:(0,N.jsx)(P,{roles:[`Admin`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Vn,{})})})}),(0,N.jsx)(l,{path:`/fees/methods`,element:(0,N.jsx)(P,{roles:[`Admin`,`Bursar`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Hn,{})})})}),(0,N.jsx)(l,{path:`/fees/structure`,element:(0,N.jsx)(P,{roles:[`Admin`,`Bursar`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Un,{})})})}),(0,N.jsx)(l,{path:`/invoice-notifications`,element:(0,N.jsx)(P,{roles:[`Parent`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Pr,{})})})}),(0,N.jsx)(l,{path:`/invoice-notifications/:id`,element:(0,N.jsx)(P,{roles:[`Parent`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Fr,{})})})}),(0,N.jsx)(l,{path:`/fees/payments`,element:(0,N.jsx)(P,{roles:[`Admin`,`Bursar`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Wn,{})})})}),(0,N.jsx)(l,{path:`/fees/receipts/approval`,element:(0,N.jsx)(P,{roles:[`Admin`,`Bursar`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Gn,{})})})}),(0,N.jsx)(l,{path:`/fees/report`,element:(0,N.jsx)(P,{roles:[`Admin`,`Bursar`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Kn,{})})})}),(0,N.jsx)(l,{path:`/school/settings`,element:(0,N.jsx)(P,{roles:[`Admin`,`Bursar`],children:(0,N.jsx)(q,{children:(0,N.jsx)(qn,{})})})}),(0,N.jsx)(l,{path:`/settings`,element:(0,N.jsx)(P,{roles:[`Admin`,`Bursar`],children:(0,N.jsx)(q,{children:(0,N.jsx)(qn,{})})})}),(0,N.jsx)(l,{path:`/fees/policy`,element:(0,N.jsx)(P,{roles:[`Admin`,`Bursar`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Zr,{})})})}),(0,N.jsx)(l,{path:`/settings/ai-credits`,element:(0,N.jsx)(P,{roles:[`Admin`,`Teacher`,`Bursar`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Jr,{})})})}),`          `,(0,N.jsx)(l,{path:`/settings/ai-lesson-plans`,element:(0,N.jsx)(P,{roles:[`Admin`,`Teacher`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Yr,{})})})}),(0,N.jsx)(l,{path:`/fees/ai-collection`,element:(0,N.jsx)(P,{roles:[`Admin`,`Bursar`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Xr,{})})})}),(0,N.jsx)(l,{path:`/settings/whatsapp`,element:(0,N.jsx)(P,{roles:[`Admin`],children:(0,N.jsx)(q,{children:(0,N.jsx)(qr,{})})})}),(0,N.jsx)(l,{path:`/school/bank-account-setting`,element:(0,N.jsx)(P,{roles:[`Admin`],children:(0,N.jsx)(q,{children:(0,N.jsx)(yr,{})})})}),(0,N.jsx)(l,{path:`/school/operators`,element:(0,N.jsx)(P,{roles:[`Admin`],children:(0,N.jsx)(q,{children:(0,N.jsx)(br,{})})})}),(0,N.jsx)(l,{path:`/admin/school/operators`,element:(0,N.jsx)(P,{roles:[`Admin`],children:(0,N.jsx)(q,{children:(0,N.jsx)(br,{})})})}),(0,N.jsx)(l,{path:`/scan-qr`,element:(0,N.jsx)(P,{roles:[`Admin`,`Teacher`],children:(0,N.jsx)(q,{children:(0,N.jsx)(ur,{})})})}),(0,N.jsx)(l,{path:`/attendance/logs`,element:(0,N.jsx)(P,{roles:[`Admin`],children:(0,N.jsx)(q,{children:(0,N.jsx)(dr,{})})})}),(0,N.jsx)(l,{path:`/attendance/settings`,element:(0,N.jsx)(P,{roles:[`Admin`],children:(0,N.jsx)(q,{children:(0,N.jsx)(fr,{})})})}),(0,N.jsx)(l,{path:`/teachers`,element:(0,N.jsx)(P,{roles:[`Admin`],children:(0,N.jsx)(q,{children:(0,N.jsx)(pr,{})})})}),(0,N.jsx)(l,{path:`/teacher-subjects`,element:(0,N.jsx)(P,{roles:[`Admin`],children:(0,N.jsx)(q,{children:(0,N.jsx)(mr,{})})})}),(0,N.jsx)(l,{path:`/parents`,element:(0,N.jsx)(P,{roles:[`Admin`],children:(0,N.jsx)(q,{children:(0,N.jsx)(hr,{})})})}),(0,N.jsx)(l,{path:`/parent/children`,element:(0,N.jsx)(P,{roles:[`Parent`],children:(0,N.jsx)(q,{children:(0,N.jsx)(vr,{})})})}),(0,N.jsx)(l,{path:`/parent/students/:studentId/fees`,element:(0,N.jsx)(P,{roles:[`Parent`],children:(0,N.jsx)(q,{children:(0,N.jsx)(xr,{})})})}),(0,N.jsx)(l,{path:`/parent/upload-receipt`,element:(0,N.jsx)(P,{roles:[`Parent`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Er,{})})})}),(0,N.jsx)(l,{path:`/parent/payments`,element:(0,N.jsx)(P,{roles:[`Parent`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Dr,{})})})}),(0,N.jsx)(l,{path:`/parent/results`,element:(0,N.jsx)(P,{roles:[`Parent`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Tr,{})})})}),(0,N.jsx)(l,{path:`/parent/students/:studentId/results`,element:(0,N.jsx)(P,{roles:[`Parent`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Tr,{})})})}),(0,N.jsx)(l,{path:`/parent/attendance`,element:(0,N.jsx)(P,{roles:[`Parent`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Sr,{})})})}),(0,N.jsx)(l,{path:`/parent/attendance/history`,element:(0,N.jsx)(P,{roles:[`Parent`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Sr,{})})})}),(0,N.jsx)(l,{path:`/parent/communication`,element:(0,N.jsx)(P,{roles:[`Parent`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Cr,{})})})}),(0,N.jsx)(l,{path:`/parent/messages`,element:(0,N.jsx)(P,{roles:[`Parent`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Cr,{})})})}),(0,N.jsx)(l,{path:`/parent/announcements`,element:(0,N.jsx)(P,{roles:[`Parent`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Cr,{})})})}),(0,N.jsx)(l,{path:`/parent/calendar`,element:(0,N.jsx)(P,{roles:[`Parent`],children:(0,N.jsx)(q,{children:(0,N.jsx)(wr,{})})})}),(0,N.jsx)(l,{path:`/parent/events`,element:(0,N.jsx)(P,{roles:[`Parent`],children:(0,N.jsx)(q,{children:(0,N.jsx)(wr,{})})})}),(0,N.jsx)(l,{path:`/billing`,element:(0,N.jsx)(P,{roles:[`Admin`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Yn,{})})})}),(0,N.jsx)(l,{path:`/billing/invoice-payment/:invoiceId`,element:(0,N.jsx)(P,{roles:[`Admin`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Xn,{})})})}),(0,N.jsx)(l,{path:`/wallet`,element:(0,N.jsx)(P,{roles:[`Admin`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Zn,{})})})}),(0,N.jsx)(l,{path:`/checkout`,element:(0,N.jsx)(r,{to:`/wallet`,replace:!0})}),(0,N.jsx)(l,{path:`/subscriptions/checkout`,element:(0,N.jsx)(r,{to:`/wallet`,replace:!0})}),(0,N.jsx)(l,{path:`/sales/leads`,element:(0,N.jsx)(P,{roles:[`Sales-Representative`],children:(0,N.jsx)(q,{children:(0,N.jsx)(ti,{})})})}),(0,N.jsx)(l,{path:`/sales/commissions`,element:(0,N.jsx)(P,{roles:[`Sales-Representative`],children:(0,N.jsx)(q,{children:(0,N.jsx)(ni,{})})})}),(0,N.jsx)(l,{path:`/sales/payout-settings`,element:(0,N.jsx)(P,{roles:[`Sales-Representative`],children:(0,N.jsx)(q,{children:(0,N.jsx)(ri,{})})})}),(0,N.jsx)(l,{path:`/sales/marketing-kit`,element:(0,N.jsx)(P,{roles:[`Sales-Representative`],children:(0,N.jsx)(q,{children:(0,N.jsx)(ii,{})})})}),(0,N.jsx)(l,{path:`/superadmin/subscribers`,element:(0,N.jsx)(P,{roles:[`Super-Admin`,`Platform-Staff`],permissions:[`billing`],children:(0,N.jsx)(q,{children:(0,N.jsx)($n,{})})})}),(0,N.jsx)(l,{path:`/demo-bookers`,element:(0,N.jsx)(P,{roles:[`Super-Admin`,`Platform-Staff`],permissions:[`sales`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Rr,{})})})}),(0,N.jsx)(l,{path:`/superadmin/platform-staff`,element:(0,N.jsx)(P,{roles:[`Super-Admin`,`Platform-Staff`],permissions:[`staff`],children:(0,N.jsx)(q,{children:(0,N.jsx)(ir,{})})})}),`          `,(0,N.jsx)(l,{path:`/superadmin/sales-representatives`,element:(0,N.jsx)(P,{roles:[`Super-Admin`,`Platform-Staff`],permissions:[`sales`],children:(0,N.jsx)(q,{children:(0,N.jsx)(tr,{})})})}),(0,N.jsx)(l,{path:`/superadmin/sales-leads`,element:(0,N.jsx)(P,{roles:[`Super-Admin`,`Platform-Staff`],permissions:[`sales`],children:(0,N.jsx)(q,{children:(0,N.jsx)(nr,{})})})}),`          `,(0,N.jsx)(l,{path:`/superadmin/sales-payouts`,element:(0,N.jsx)(P,{roles:[`Super-Admin`,`Platform-Staff`],permissions:[`finance`],children:(0,N.jsx)(q,{children:(0,N.jsx)(rr,{})})})}),(0,N.jsx)(l,{path:`/superadmin/sales-marketing-materials`,element:(0,N.jsx)(P,{roles:[`Super-Admin`,`Platform-Staff`],permissions:[`marketing`],children:(0,N.jsx)(q,{children:(0,N.jsx)(ai,{})})})}),(0,N.jsx)(l,{path:`/superadmin/newsletter-subscribers`,element:(0,N.jsx)(P,{roles:[`Super-Admin`,`Platform-Staff`],permissions:[`marketing`],children:(0,N.jsx)(q,{children:(0,N.jsx)(mi,{})})})}),(0,N.jsx)(l,{path:`/superadmin/send-message`,element:(0,N.jsx)(P,{roles:[`Super-Admin`,`Platform-Staff`],permissions:[`marketing`],children:(0,N.jsx)(q,{children:(0,N.jsx)(er,{})})})}),(0,N.jsx)(l,{path:`/subplan`,element:(0,N.jsx)(P,{roles:[`Super-Admin`,`Platform-Staff`],permissions:[`billing`],children:(0,N.jsx)(q,{children:(0,N.jsx)(ar,{})})})}),(0,N.jsx)(l,{path:`/superadmin/billing-policy`,element:(0,N.jsx)(P,{roles:[`Super-Admin`,`Platform-Staff`],permissions:[`billing`],children:(0,N.jsx)(q,{children:(0,N.jsx)(or,{})})})}),(0,N.jsx)(l,{path:`/superadmin/twilio-whatsapp`,element:(0,N.jsx)(P,{roles:[`Super-Admin`,`Platform-Staff`],permissions:[`support`],children:(0,N.jsx)(q,{children:(0,N.jsx)(sr,{})})})}),(0,N.jsx)(l,{path:`/blogs`,element:(0,N.jsx)(P,{roles:[`Super-Admin`,`Platform-Staff`],permissions:[`content`],children:(0,N.jsx)(q,{children:(0,N.jsx)(cr,{})})})}),(0,N.jsx)(l,{path:`/testimonials`,element:(0,N.jsx)(P,{roles:[`Super-Admin`,`Platform-Staff`],permissions:[`content`],children:(0,N.jsx)(q,{children:(0,N.jsx)(lr,{})})})}),(0,N.jsx)(l,{path:`/admin-users/view/:id`,element:(0,N.jsx)(P,{roles:[`Super-Admin`,`Platform-Staff`],permissions:[`support`],children:(0,N.jsx)(q,{children:(0,N.jsx)(Qn,{})})})}),(0,N.jsx)(l,{path:`/superadmin`,element:(0,N.jsx)(P,{roles:[`Super-Admin`,`Platform-Staff`],children:(0,N.jsx)(q,{children:(0,N.jsx)(xn,{})})})}),(0,N.jsx)(l,{path:`/superadmin/dashboard`,element:(0,N.jsx)(P,{roles:[`Super-Admin`,`Platform-Staff`],children:(0,N.jsx)(q,{children:(0,N.jsx)(xn,{})})})}),(0,N.jsx)(l,{path:`/superadmin/command-center`,element:(0,N.jsx)(P,{roles:[`Super-Admin`,`Platform-Staff`],children:(0,N.jsx)(q,{children:(0,N.jsx)(xn,{})})})}),(0,N.jsx)(l,{path:`/student/my-fees`,element:(0,N.jsx)(P,{roles:[`Student`],children:(0,N.jsx)(q,{children:(0,N.jsx)(gr,{})})})}),(0,N.jsx)(l,{path:`/student/my-subjects`,element:(0,N.jsx)(P,{roles:[`Student`],children:(0,N.jsx)(q,{children:(0,N.jsx)(_r,{})})})}),(0,N.jsx)(l,{path:`/user/profile`,element:(0,N.jsx)(P,{children:(0,N.jsx)(q,{children:(0,N.jsx)(Mr,{})})})}),(0,N.jsx)(l,{path:`/404`,element:(0,N.jsx)(gn,{})}),(0,N.jsx)(l,{path:`/403`,element:(0,N.jsx)(_n,{})}),(0,N.jsx)(l,{path:`/unauthorized`,element:(0,N.jsx)(_n,{})}),(0,N.jsx)(l,{path:`/500`,element:(0,N.jsx)(vn,{})}),(0,N.jsx)(l,{path:`/maintenance`,element:(0,N.jsx)(yn,{})}),(0,N.jsx)(l,{path:`/upgrade-required`,element:(0,N.jsx)(bn,{})}),(0,N.jsx)(l,{path:`*`,element:(0,N.jsx)(gn,{})})]})})})})})}var _i=gi;(0,g.createRoot)(document.getElementById(`root`)).render((0,N.jsx)(_.StrictMode,{children:(0,N.jsx)(jt,{children:(0,N.jsx)(_i,{})})}));export{re as A,A as B,Y as C,W as D,G as E,z as F,k as H,I,L,ae as M,ie as N,U as O,B as P,R,Z as S,se as T,M as V,qe as _,cn as a,Se as b,Kt as c,ct as d,st as f,Je as g,tt as h,on as i,H as j,oe as k,Mt as l,et as m,un as n,sn as o,$e as p,an as r,rn as s,ln as t,lt as u,Ye as v,J as w,be as x,He as y,D as z};