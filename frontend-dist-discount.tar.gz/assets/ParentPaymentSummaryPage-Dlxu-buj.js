import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{b as t,p as n,x as r}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as i,E as a,P as o,d as s,f as c,l,u}from"./index-D6TxbaCx.js";var d=e(),f=n();function p(){let{search:e}=t();return(0,d.useMemo)(()=>new URLSearchParams(e),[e])}var m=`gq_parent_payments_last_reg_no`,h=e=>new Intl.NumberFormat(`en-NG`,{style:`currency`,currency:`NGN`}).format(Number(e||0));function g(){let e=r(),t=p(),{showError:n,showInfo:g}=l(),[_,v]=(0,d.useState)(!1),[y,b]=(0,d.useState)(!0),[x,S]=(0,d.useState)(!0),[C,w]=(0,d.useState)(t.get(`reg_no`)||localStorage.getItem(m)||``),[T,E]=(0,d.useState)(null),[D,O]=(0,d.useState)(``),[k,A]=(0,d.useState)(``),[j,M]=(0,d.useState)(``),[N,P]=(0,d.useState)(null);(0,d.useEffect)(()=>{let t=C.trim();if(t){localStorage.setItem(m,t);let n=new URLSearchParams(window.location.search);n.get(`reg_no`)!==t&&(n.set(`reg_no`,t),e({search:n.toString()},{replace:!0}))}},[C]);let F=async e=>{let t=(e??C).trim();if(!t){b(!1);return}b(!0);try{E((await o.get(`/parent/payments/summary?reg_no=${encodeURIComponent(t)}`)).data)}catch(e){console.error(e),n(e?.response?.data?.message||`Failed to load payment summary.`),E(null)}finally{b(!1)}},I=async(e,t)=>{let r=(e??C).trim();if(!r){S(!1);return}S(!0);try{let e=new URLSearchParams;e.set(`reg_no`,r),D.trim()&&e.set(`term_id`,D.trim()),k.trim()&&e.set(`session_id`,k.trim()),j.trim()&&e.set(`fee_status`,j.trim()),t&&e.set(`page`,String(t)),P((await o.get(`/parent/payments/history?${e.toString()}`)).data)}catch(e){console.error(e),n(e?.response?.data?.message||`Failed to load payment history.`),P(null)}finally{S(!1)}};(0,d.useEffect)(()=>{F(C),I(C,1)},[C]);let L=T?.student?.name||N?.student?.name||``,R=T?.totals;return(0,f.jsxs)(f.Fragment,{children:[(0,f.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');

        .parent-pay-main {
          background: #F8FAFC;
          min-height: 100vh;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          padding: calc(66px + 24px) 28px 40px !important;
        }

        @media (max-width: 767.98px) {
          .parent-pay-main {
            padding: calc(66px + 16px) 14px 36px !important;
          }
          .parent-hero {
            padding: 20px 18px !important;
            border-radius: 14px !important;
            margin-bottom: 16px !important;
          }
          .parent-greeting {
            font-size: 20px !important;
          }
          .parent-hero-sub {
            font-size: 12.5px !important;
          }
        }

        .parent-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 18px;
          padding: 32px 36px;
          color: #FFFFFF;
          margin-bottom: 24px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
          position: relative;
          overflow: hidden;
        }

        .parent-hero::before {
          content: '';
          position: absolute;
          inset: 0;
          background-image:
            linear-gradient(rgba(255, 255, 255, 0.035) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255, 255, 255, 0.035) 1px, transparent 1px);
          background-size: 32px 32px;
          pointer-events: none;
        }

        .parent-hero-glow {
          position: absolute;
          top: -40px;
          right: -40px;
          width: 320px;
          height: 320px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.18) 0%, transparent 65%);
          pointer-events: none;
        }

        .parent-hero-inner {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: center;
          justify-content: space-between;
          flex-wrap: wrap;
          gap: 24px;
        }

        .parent-session-badge {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.2);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius: 100px;
          padding: 4px 12px;
          margin-bottom: 12px;
        }

        .parent-session-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #10B981;
          box-shadow: 0 0 6px #10B981;
        }

        .parent-greeting {
          font-size: 26px;
          font-weight: 800;
          color: #FFFFFF;
          line-height: 1.1;
          margin-bottom: 8px;
        }

        .parent-hero-sub {
          font-size: 13.5px;
          color: #CBD5E1;
          line-height: 1.6;
          max-width: 520px;
          margin-bottom: 0;
        }

        .parent-stat-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 16px;
          margin-bottom: 24px;
        }

        @media (max-width: 900px) {
          .parent-stat-grid {
            grid-template-columns: 1fr;
          }
        }

        .parent-stat-card {
          background: #FFFFFF;
          border: 1px solid rgba(15, 39, 68, 0.08);
          border-radius: 16px;
          padding: 20px 24px;
          box-shadow: 0 2px 10px rgba(15, 39, 68, 0.04);
          transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1);
        }

        .parent-stat-card:hover {
          transform: translateY(-3px);
          box-shadow: 0 8px 24px rgba(15, 39, 68, 0.08);
        }

        .parent-stat-title {
          font-size: 12px;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.04em;
          color: #64748B;
          margin-bottom: 6px;
        }

        .parent-stat-val {
          font-size: 24px;
          font-weight: 800;
          color: #0F2744;
          line-height: 1.1;
        }

        .parent-panel {
          background: #FFFFFF;
          border: 1px solid rgba(15, 39, 68, 0.08);
          border-radius: 16px;
          box-shadow: 0 2px 10px rgba(15, 39, 68, 0.04);
          overflow: hidden;
          margin-bottom: 24px;
        }

        .parent-panel-head {
          padding: 18px 24px;
          border-bottom: 1px solid #E2E8F0;
          display: flex;
          align-items: center;
          justify-content: space-between;
          flex-wrap: wrap;
          gap: 12px;
        }

        .parent-table {
          width: 100%;
          border-collapse: collapse;
          font-size: 13px;
        }

        .parent-table th {
          background: #F8FAFC;
          padding: 12px 16px;
          font-weight: 700;
          color: #475569;
          font-size: 11.5px;
          text-transform: uppercase;
          letter-spacing: 0.04em;
          border-bottom: 1px solid #E2E8F0;
        }

        .parent-table td {
          padding: 14px 16px;
          border-bottom: 1px solid #F1F5F9;
          color: #1E293B;
          vertical-align: middle;
        }

        .parent-table tr:hover td {
          background: #F8FAFC;
        }
      `}),(0,f.jsx)(c,{sidebarOpen:_,setSidebarOpen:v}),(0,f.jsx)(i,{title:`Parent Payment Summary`}),(0,f.jsx)(`div`,{className:`container-fluid`,children:(0,f.jsxs)(`div`,{className:`row`,children:[(0,f.jsx)(s,{sidebarOpen:_,setSidebarOpen:v}),(0,f.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto gq-app-main parent-pay-main d-flex flex-column min-vh-100`,children:[(y||x)&&(0,f.jsx)(a,{message:`Loading payments summary...`}),(0,f.jsxs)(`div`,{className:`parent-hero`,children:[(0,f.jsx)(`div`,{className:`parent-hero-glow`}),(0,f.jsxs)(`div`,{className:`parent-hero-inner`,children:[(0,f.jsxs)(`div`,{children:[(0,f.jsxs)(`div`,{className:`parent-session-badge`,children:[(0,f.jsx)(`span`,{className:`parent-session-dot`}),`Financial Ledger`]}),(0,f.jsx)(`h1`,{className:`parent-greeting`,children:`Payment Summary & Receipts`}),(0,f.jsx)(`p`,{className:`parent-hero-sub`,children:L?`Showing financial clearance records for: ${L}`:`Enter your child's Admission No to inspect fee breakdowns and receipts.`})]}),(0,f.jsxs)(`div`,{className:`d-flex gap-2`,children:[(0,f.jsxs)(`button`,{className:`btn btn-outline-light px-4 py-2`,style:{borderRadius:10,fontWeight:700,backdropFilter:`blur(8px)`},onClick:()=>{g(`Refreshing...`),F(C),I(C,1)},children:[(0,f.jsx)(`i`,{className:`bi bi-arrow-clockwise me-2`}),`Refresh`]}),(0,f.jsxs)(`button`,{className:`btn btn-warning px-4 py-2`,style:{borderRadius:10,fontWeight:700,color:`#0F2744`,background:`#FBBF24`},onClick:()=>e(`/dashboard`),children:[(0,f.jsx)(`i`,{className:`bi bi-speedometer2 me-2`}),`Dashboard`]})]})]})]}),(0,f.jsxs)(`div`,{className:`parent-panel`,children:[(0,f.jsx)(`div`,{className:`parent-panel-head`,children:(0,f.jsxs)(`h2`,{style:{fontSize:`15px`,fontWeight:800,color:`#0F2744`,margin:0},children:[(0,f.jsx)(`i`,{className:`bi bi-funnel-fill text-primary me-2`}),`Student Lookup & Filter Criteria`]})}),(0,f.jsx)(`div`,{className:`p-4`,children:(0,f.jsxs)(`div`,{className:`row g-3 align-items-end`,children:[(0,f.jsxs)(`div`,{className:`col-md-6`,children:[(0,f.jsx)(`label`,{className:`form-label`,style:{fontSize:`12.5px`,fontWeight:700,color:`#0F2744`},children:`Student Admission Number`}),(0,f.jsx)(`input`,{className:`form-control`,style:{borderRadius:10,fontSize:`13.5px`},value:C,onChange:e=>w(e.target.value),placeholder:`e.g. REG/2026/001`}),(0,f.jsx)(`small`,{className:`text-muted`,children:`Saved automatically in your session.`})]}),(0,f.jsxs)(`div`,{className:`col-md-6 d-flex gap-2 justify-content-md-end`,children:[(0,f.jsx)(`button`,{className:`btn btn-outline-secondary`,style:{borderRadius:10,fontWeight:700},onClick:()=>{O(``),A(``),M(``),I(C,1)},children:`Reset Filters`}),(0,f.jsx)(`button`,{className:`btn btn-primary`,style:{borderRadius:10,fontWeight:700},onClick:()=>I(C,1),children:`Apply Filters`})]}),(0,f.jsxs)(`div`,{className:`col-md-4`,children:[(0,f.jsx)(`label`,{className:`form-label`,style:{fontSize:`12.5px`,fontWeight:700,color:`#0F2744`},children:`Session ID (Optional)`}),(0,f.jsx)(`input`,{className:`form-control`,style:{borderRadius:10,fontSize:`13.5px`},value:k,onChange:e=>A(e.target.value)})]}),(0,f.jsxs)(`div`,{className:`col-md-4`,children:[(0,f.jsx)(`label`,{className:`form-label`,style:{fontSize:`12.5px`,fontWeight:700,color:`#0F2744`},children:`Term ID (Optional)`}),(0,f.jsx)(`input`,{className:`form-control`,style:{borderRadius:10,fontSize:`13.5px`},value:D,onChange:e=>O(e.target.value)})]}),(0,f.jsxs)(`div`,{className:`col-md-4`,children:[(0,f.jsx)(`label`,{className:`form-label`,style:{fontSize:`12.5px`,fontWeight:700,color:`#0F2744`},children:`Fee Status (Optional)`}),(0,f.jsx)(`input`,{className:`form-control`,style:{borderRadius:10,fontSize:`13.5px`},value:j,onChange:e=>M(e.target.value),placeholder:`paid / unpaid / partial`})]})]})})]}),(0,f.jsxs)(`div`,{className:`parent-stat-grid`,children:[(0,f.jsx)(`div`,{className:`parent-stat-card`,children:(0,f.jsxs)(`div`,{className:`d-flex align-items-start justify-content-between`,children:[(0,f.jsxs)(`div`,{children:[(0,f.jsx)(`div`,{className:`parent-stat-title`,children:`Total Fees Billed`}),(0,f.jsx)(`div`,{className:`parent-stat-val`,style:{color:`#2563EB`},children:h(R?.total_due||0)})]}),(0,f.jsx)(`div`,{style:{width:44,height:44,borderRadius:12,background:`rgba(37, 99, 235, 0.12)`,color:`#2563EB`,display:`flex`,alignItems:`center`,justifyContent:`center`,fontSize:`20px`},children:(0,f.jsx)(`i`,{className:`bi bi-wallet2`})})]})}),(0,f.jsx)(`div`,{className:`parent-stat-card`,children:(0,f.jsxs)(`div`,{className:`d-flex align-items-start justify-content-between`,children:[(0,f.jsxs)(`div`,{children:[(0,f.jsx)(`div`,{className:`parent-stat-title`,children:`Total Verified Paid`}),(0,f.jsx)(`div`,{className:`parent-stat-val`,style:{color:`#10B981`},children:h(R?.total_paid||0)})]}),(0,f.jsx)(`div`,{style:{width:44,height:44,borderRadius:12,background:`rgba(16, 185, 129, 0.12)`,color:`#10B981`,display:`flex`,alignItems:`center`,justifyContent:`center`,fontSize:`20px`},children:(0,f.jsx)(`i`,{className:`bi bi-check-circle-fill`})})]})}),(0,f.jsx)(`div`,{className:`parent-stat-card`,children:(0,f.jsxs)(`div`,{className:`d-flex align-items-start justify-content-between`,children:[(0,f.jsxs)(`div`,{children:[(0,f.jsx)(`div`,{className:`parent-stat-title`,children:`Outstanding Balance`}),(0,f.jsx)(`div`,{className:`parent-stat-val`,style:{color:Number(R?.total_balance||0)>0?`#EF4444`:`#10B981`},children:h(R?.total_balance||0)})]}),(0,f.jsx)(`div`,{style:{width:44,height:44,borderRadius:12,background:Number(R?.total_balance||0)>0?`rgba(239, 68, 68, 0.12)`:`rgba(16, 185, 129, 0.12)`,color:Number(R?.total_balance||0)>0?`#EF4444`:`#10B981`,display:`flex`,alignItems:`center`,justifyContent:`center`,fontSize:`20px`},children:(0,f.jsx)(`i`,{className:`bi bi-exclamation-circle-fill`})})]})})]}),(0,f.jsxs)(`div`,{className:`row g-4 mb-4`,children:[(0,f.jsx)(`div`,{className:`col-lg-6`,children:(0,f.jsxs)(`div`,{className:`parent-panel h-100 mb-0`,children:[(0,f.jsx)(`div`,{className:`parent-panel-head`,children:(0,f.jsxs)(`h2`,{style:{fontSize:`15px`,fontWeight:800,color:`#0F2744`,margin:0},children:[(0,f.jsx)(`i`,{className:`bi bi-calendar3 text-primary me-2`}),`Breakdown by Academic Term`]})}),(0,f.jsx)(`div`,{className:`table-responsive`,children:(0,f.jsxs)(`table`,{className:`parent-table`,children:[(0,f.jsx)(`thead`,{children:(0,f.jsxs)(`tr`,{children:[(0,f.jsx)(`th`,{children:`Session`}),(0,f.jsx)(`th`,{children:`Term`}),(0,f.jsx)(`th`,{children:`Due`}),(0,f.jsx)(`th`,{children:`Paid`}),(0,f.jsx)(`th`,{children:`Bal`})]})}),(0,f.jsxs)(`tbody`,{children:[(T?.breakdown?.by_session_term||[]).map((e,t)=>(0,f.jsxs)(`tr`,{children:[(0,f.jsx)(`td`,{children:e.session_name}),(0,f.jsx)(`td`,{children:e.term_name}),(0,f.jsx)(`td`,{className:`fw-semibold`,children:h(e.due)}),(0,f.jsx)(`td`,{style:{color:`#10B981`},children:h(e.paid)}),(0,f.jsx)(`td`,{style:{fontWeight:700,color:Number(e.bal)>0?`#EF4444`:`#10B981`},children:h(e.bal)})]},t)),(!T?.breakdown?.by_session_term||T.breakdown.by_session_term.length===0)&&(0,f.jsx)(`tr`,{children:(0,f.jsx)(`td`,{colSpan:5,className:`text-center text-muted py-4`,children:`No term breakdowns available`})})]})]})})]})}),(0,f.jsx)(`div`,{className:`col-lg-6`,children:(0,f.jsxs)(`div`,{className:`parent-panel h-100 mb-0`,children:[(0,f.jsx)(`div`,{className:`parent-panel-head`,children:(0,f.jsxs)(`h2`,{style:{fontSize:`15px`,fontWeight:800,color:`#0F2744`,margin:0},children:[(0,f.jsx)(`i`,{className:`bi bi-tag-fill text-warning me-2`}),`Breakdown by Fee Type`]})}),(0,f.jsx)(`div`,{className:`table-responsive`,children:(0,f.jsxs)(`table`,{className:`parent-table`,children:[(0,f.jsx)(`thead`,{children:(0,f.jsxs)(`tr`,{children:[(0,f.jsx)(`th`,{children:`Fee Item`}),(0,f.jsx)(`th`,{children:`Due`}),(0,f.jsx)(`th`,{children:`Paid`}),(0,f.jsx)(`th`,{children:`Bal`})]})}),(0,f.jsxs)(`tbody`,{children:[(T?.breakdown?.by_fee_type||[]).map((e,t)=>(0,f.jsxs)(`tr`,{children:[(0,f.jsx)(`td`,{style:{fontWeight:600},children:e.fee_type_name}),(0,f.jsx)(`td`,{children:h(e.due)}),(0,f.jsx)(`td`,{style:{color:`#10B981`},children:h(e.paid)}),(0,f.jsx)(`td`,{style:{fontWeight:700,color:Number(e.bal)>0?`#EF4444`:`#10B981`},children:h(e.bal)})]},t)),(!T?.breakdown?.by_fee_type||T.breakdown.by_fee_type.length===0)&&(0,f.jsx)(`tr`,{children:(0,f.jsx)(`td`,{colSpan:4,className:`text-center text-muted py-4`,children:`No fee item breakdowns available`})})]})]})})]})})]}),(0,f.jsxs)(`div`,{className:`parent-panel mb-5`,children:[(0,f.jsx)(`div`,{className:`parent-panel-head`,children:(0,f.jsxs)(`h2`,{style:{fontSize:`15px`,fontWeight:800,color:`#0F2744`,margin:0},children:[(0,f.jsx)(`i`,{className:`bi bi-clock-history text-primary me-2`}),`Verified Payment Receipts & Ledger (`,N?.payments?.total??0,`)`]})}),(0,f.jsx)(`div`,{className:`table-responsive`,children:(0,f.jsxs)(`table`,{className:`parent-table`,children:[(0,f.jsx)(`thead`,{children:(0,f.jsxs)(`tr`,{children:[(0,f.jsx)(`th`,{children:`Ref Number`}),(0,f.jsx)(`th`,{children:`Amount`}),(0,f.jsx)(`th`,{children:`Method`}),(0,f.jsx)(`th`,{children:`Fee Type`}),(0,f.jsx)(`th`,{children:`Session`}),(0,f.jsx)(`th`,{children:`Term`}),(0,f.jsx)(`th`,{children:`Status`}),(0,f.jsx)(`th`,{children:`Date`}),(0,f.jsx)(`th`,{className:`text-end`,children:`Action`})]})}),(0,f.jsxs)(`tbody`,{children:[(N?.payments?.data||[]).map(e=>(0,f.jsxs)(`tr`,{children:[(0,f.jsx)(`td`,{style:{fontWeight:700,color:`#0F2744`},children:e.reference}),(0,f.jsx)(`td`,{style:{fontWeight:800,color:`#10B981`},children:h(Number(e.amount||0))}),(0,f.jsx)(`td`,{children:(0,f.jsx)(`span`,{className:`badge bg-light text-dark border`,children:(e.payment_method||`-`).toUpperCase()})}),(0,f.jsx)(`td`,{children:e.fee_type_name??`-`}),(0,f.jsx)(`td`,{children:e.session_name??`-`}),(0,f.jsx)(`td`,{children:e.term_name??`-`}),(0,f.jsx)(`td`,{children:(0,f.jsx)(`span`,{className:`badge bg-success-subtle text-success`,children:e.fee_status??`Verified`})}),(0,f.jsx)(`td`,{style:{fontSize:`12px`,color:`#64748B`},children:e.created_at?new Date(e.created_at).toLocaleDateString(`en-NG`,{day:`numeric`,month:`short`,year:`numeric`}):`—`}),(0,f.jsx)(`td`,{className:`text-end`,children:(0,f.jsxs)(`a`,{href:`/api/parent/payments/${encodeURIComponent(e.reference)}/receipt/pdf`,target:`_blank`,rel:`noopener noreferrer`,className:`btn btn-sm btn-outline-primary d-inline-flex align-items-center gap-1`,style:{borderRadius:8,fontSize:`12px`,padding:`4px 10px`,fontWeight:700},title:`Download Official PDF Receipt`,children:[(0,f.jsx)(`i`,{className:`bi bi-file-earmark-pdf`}),(0,f.jsx)(`span`,{children:`PDF`})]})})]},e.id)),!x&&(!N?.payments?.data||N.payments.data.length===0)&&(0,f.jsx)(`tr`,{children:(0,f.jsxs)(`td`,{colSpan:9,className:`text-center text-muted py-5`,children:[(0,f.jsx)(`i`,{className:`bi bi-receipt fs-2 d-block mb-2 text-secondary`}),`No payment transactions recorded for this student.`]})})]})]})}),N?.payments&&N.payments.last_page>1&&(0,f.jsxs)(`div`,{className:`p-3 border-top d-flex justify-content-between align-items-center`,children:[(0,f.jsx)(`button`,{className:`btn btn-sm btn-outline-secondary`,style:{borderRadius:8,fontWeight:700},disabled:N.payments.current_page<=1,onClick:()=>I(C,N.payments.current_page-1),children:`Previous`}),(0,f.jsxs)(`div`,{className:`text-muted small`,children:[`Page `,N.payments.current_page,` of `,N.payments.last_page]}),(0,f.jsx)(`button`,{className:`btn btn-sm btn-outline-secondary`,style:{borderRadius:8,fontWeight:700},disabled:N.payments.current_page>=N.payments.last_page,onClick:()=>I(C,N.payments.current_page+1),children:`Next`})]})]}),(0,f.jsx)(u,{})]})]})})]})}export{g as default};