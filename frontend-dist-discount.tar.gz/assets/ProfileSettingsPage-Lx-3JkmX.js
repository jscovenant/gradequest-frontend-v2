import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{p as t}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{B as n,E as r,H as i,P as a,d as o,f as s,l as c,u as l}from"./index-D6TxbaCx.js";var u=e(),d=t();function f(e){return(e||``).toLowerCase()===`student`}function ee(e){let t=(e||``).toLowerCase();return t===`admin`||t===`superadmin`||t===`super-admin`||t===`owner`}function p(){let{showToast:e}=c(),[t,p]=(0,u.useState)(!1),[m,h]=(0,u.useState)(!0),[g,_]=(0,u.useState)(!1),[v,y]=(0,u.useState)(!1),[b,x]=(0,u.useState)(!1),[S,C]=(0,u.useState)(null),[w,T]=(0,u.useState)(``),[E,D]=(0,u.useState)(``),[O,k]=(0,u.useState)(``),[A,j]=(0,u.useState)(``),[M,N]=(0,u.useState)(``),[P,F]=(0,u.useState)(null),[I,L]=(0,u.useState)(null),R=(0,u.useRef)(null),[z,B]=(0,u.useState)(``),[V,H]=(0,u.useState)(``),[U,W]=(0,u.useState)(``),[G,te]=(0,u.useState)(!1),[K,ne]=(0,u.useState)(!1),[q,re]=(0,u.useState)(!1),J=(0,u.useMemo)(()=>f(S?.role),[S?.role]),Y=(0,u.useMemo)(()=>ee(S?.role),[S?.role]),X=(0,u.useMemo)(()=>!J,[J]),Z=(0,u.useMemo)(()=>!J&&!Y,[J,Y]),Q=async()=>{h(!0);try{let e=(await a.get(`/user-profile`)).data;C(e),T(e.firstname||``),D(e.surname||``),k(e.email||``),j(e.phone||``),N(e.address||``),F(e.photo||null);let t=n();t&&i({...t,firstname:e.firstname||t.firstname,surname:e.surname||t.surname,email:e.email||t.email,photo_url:e.photo||t.photo_url})}catch(t){let r=n();r?(C(r),T(r.firstname||``),D(r.surname||``),k(r.email||``),j(r.phone||``),N(r.address||``),F(r.photo_url||null)):e(t?.response?.data?.message||`Failed to load profile.`,`error`)}finally{h(!1)}};(0,u.useEffect)(()=>{Q()},[]);let ie=()=>{X&&R.current?.click()},ae=e=>{e&&(L(e),F(URL.createObjectURL(e)))},oe=()=>{L(null),F(S?.photo||null),R.current&&(R.current.value=``)},se=async()=>{if(!X)return;if(!w.trim()||!E.trim()){e(`Firstname and surname are required.`,`error`);return}let t=(Z?O:S?.email)||O;_(!0);try{let r=new FormData;r.append(`firstname`,w.trim()),r.append(`surname`,E.trim()),r.append(`email`,t.trim()),r.append(`phone`,A.trim()),r.append(`address`,M.trim()),I&&r.append(`photo`,I),r.append(`_method`,`PUT`);let o=await a.post(`/user-profile/update`,r,{headers:{"Content-Type":`multipart/form-data`}});C(o.data),e(`Profile information updated successfully! ✅`,`success`),L(null),F(o.data.photo||P);let s=n();s&&i({...s,firstname:o.data.firstname||s.firstname,surname:o.data.surname||s.surname,email:o.data.email||s.email,photo_url:o.data.photo||s.photo_url})}catch(t){e(t?.response?.data?.message||(t?.response?.data?.errors?`Please fix validation errors.`:`Failed to update profile.`),`error`)}finally{_(!1)}},ce=async()=>{if(window.confirm(`Are you sure you want to log out all other devices and staff assistants?

All other active login sessions will be terminated immediately.`)){x(!0);try{e((await a.post(`/security/sessions/revoke-all`)).data?.message||`All other active sessions have been revoked successfully.`,`success`)}catch(t){e(t?.response?.data?.message||`Failed to revoke active sessions.`,`error`)}finally{x(!1)}}},le=async()=>{if(!z||!V||!U){e(`Please fill in all password fields.`,`error`);return}if(V.length<8){e(`New password must be at least 8 characters.`,`error`);return}if(V!==U){e(`New password confirmation does not match.`,`error`);return}y(!0);try{e((await a.post(`/user/update-password`,{old_password:z,new_password:V,new_password_confirmation:U}))?.data?.message||`Password updated successfully! ✅`,`success`),B(``),H(``),W(``)}catch(t){e(t?.response?.data?.message||(t?.response?.data?.errors?`Password validation failed.`:`Failed to update password.`),`error`)}finally{y(!1)}},ue=(e,t)=>(e||``).trim().charAt(0).toUpperCase()+(t||``).trim().charAt(0).toUpperCase()||`GQ`,$=`
    .gq-profile-main {
      min-height: 100vh;
      margin-left: 280px;
      width: calc(100% - 280px);
      padding: max(96px, calc(78px + env(safe-area-inset-top))) 28px 40px;
      background: #F8FAFC;
      color: #0F172A;
      font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
    }

    .gq-profile-shell {
      width: 100%;
      max-width: 1280px;
      margin: 0 auto;
    }

    /* ── Hero Banner ── */
    .gq-profile-hero {
      position: relative;
      overflow: hidden;
      display: flex;
      align-items: flex-end;
      justify-content: space-between;
      gap: 20px;
      padding: 32px 36px;
      margin-bottom: 28px;
      border-radius: 20px;
      color: #FFFFFF;
      background: linear-gradient(135deg, #0A192F 0%, #0F2744 55%, #1E3A8A 100%);
      box-shadow: 0 16px 40px rgba(15, 39, 68, 0.18);
      border: 1px solid rgba(255, 255, 255, 0.1);
    }

    .gq-profile-hero::after {
      content: "";
      position: absolute;
      width: 320px;
      height: 320px;
      right: -80px;
      top: -120px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(245, 158, 11, 0.18) 0%, transparent 70%);
      pointer-events: none;
    }

    .gq-profile-hero-copy {
      position: relative;
      z-index: 1;
    }

    .gq-profile-eyebrow {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      color: #FBBF24;
      font-size: 11.5px;
      font-weight: 800;
      letter-spacing: .16em;
      text-transform: uppercase;
      background: rgba(251, 191, 36, 0.15);
      border: 1px solid rgba(251, 191, 36, 0.3);
      padding: 4px 14px;
      border-radius: 999px;
      margin-bottom: 12px;
    }

    .gq-profile-hero h1 {
      margin: 0 0 8px;
      font-size: clamp(26px, 3.2vw, 36px);
      font-weight: 900;
      letter-spacing: -.02em;
      color: #FFFFFF;
    }

    .gq-profile-hero p {
      margin: 0;
      max-width: 620px;
      color: #CBD5E1;
      font-size: 14.5px;
      line-height: 1.6;
    }

    .gq-btn-refresh-profile {
      border: 1px solid rgba(255, 255, 255, 0.25) !important;
      background: rgba(255, 255, 255, 0.1) !important;
      color: #FFFFFF !important;
      font-weight: 700 !important;
      font-size: 13.5px !important;
      padding: 10px 18px !important;
      border-radius: 10px !important;
      transition: all 0.2s ease !important;
      white-space: nowrap;
    }

    .gq-btn-refresh-profile:hover {
      background: rgba(255, 255, 255, 0.2) !important;
      border-color: rgba(255, 255, 255, 0.4) !important;
      transform: translateY(-1px);
    }

    /* ── Cards ── */
    .gq-card-box {
      background: #FFFFFF;
      border: 1px solid #E2E8F0;
      border-radius: 20px;
      box-shadow: 0 4px 20px rgba(15, 39, 68, 0.05);
      padding: 28px;
      margin-bottom: 24px;
      transition: all 0.2s ease;
    }

    .gq-card-box:hover {
      box-shadow: 0 10px 30px rgba(15, 39, 68, 0.08);
      border-color: #CBD5E1;
    }

    .gq-card-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 14px;
      padding-bottom: 20px;
      margin-bottom: 24px;
      border-bottom: 1px solid #F1F5F9;
    }

    .gq-card-header-left {
      display: flex;
      align-items: center;
      gap: 14px;
    }

    .gq-icon-badge {
      width: 44px;
      height: 44px;
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 20px;
      flex-shrink: 0;
    }

    .gq-card-title {
      font-size: 18px;
      font-weight: 800;
      color: #0F2744;
      margin: 0;
    }

    .gq-card-subtitle {
      font-size: 13px;
      color: #64748B;
      margin: 2px 0 0;
    }

    /* ── Avatar Section ── */
    .gq-avatar-upload-wrap {
      display: flex;
      align-items: center;
      gap: 20px;
      padding: 18px 22px;
      background: #F8FAFC;
      border: 1px solid #E2E8F0;
      border-radius: 16px;
      margin-bottom: 24px;
      flex-wrap: wrap;
    }

    .gq-avatar-preview {
      width: 76px;
      height: 76px;
      border-radius: 18px;
      object-fit: cover;
      border: 3px solid #FFFFFF;
      box-shadow: 0 6px 18px rgba(15, 39, 68, 0.15);
      background: linear-gradient(135deg, #0F2744 0%, #1E3A8A 100%);
      color: #FFFFFF;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 26px;
      font-weight: 800;
      flex-shrink: 0;
    }

    /* ── Form Controls ── */
    .gq-form-label {
      display: block;
      font-size: 12.5px;
      font-weight: 700;
      color: #1E293B;
      margin-bottom: 6px;
      text-transform: uppercase;
      letter-spacing: 0.04em;
    }

    .gq-form-input {
      width: 100%;
      min-height: 46px;
      padding: 10px 14px;
      border: 1.5px solid #CBD5E1;
      border-radius: 10px;
      font-size: 14px;
      color: #0F172A;
      background: #FFFFFF;
      transition: all 0.2s ease;
      box-sizing: border-box;
    }

    .gq-form-input:focus {
      outline: none;
      border-color: #1D4ED8;
      box-shadow: 0 0 0 3px rgba(29, 78, 216, 0.12);
    }

    .gq-form-input:disabled, .gq-form-input[readonly] {
      background: #F1F5F9;
      color: #64748B;
      cursor: not-allowed;
      border-color: #E2E8F0;
    }

    /* ── Buttons ── */
    .gq-btn-save-profile {
      background: linear-gradient(135deg, #0F2744 0%, #1E3A8A 100%);
      color: #FFFFFF;
      font-size: 14px;
      font-weight: 800;
      padding: 12px 24px;
      border-radius: 10px;
      border: none;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: all 0.2s ease;
      box-shadow: 0 4px 14px rgba(15, 39, 68, 0.2);
    }

    .gq-btn-save-profile:hover {
      background: linear-gradient(135deg, #1E3A8A 0%, #2563EB 100%);
      transform: translateY(-1px);
      box-shadow: 0 8px 20px rgba(30, 58, 138, 0.3);
      color: #FFFFFF;
    }

    .gq-btn-update-password {
      background: linear-gradient(135deg, #D97706 0%, #B45309 100%);
      color: #FFFFFF;
      font-size: 14px;
      font-weight: 800;
      padding: 12px 24px;
      border-radius: 10px;
      border: none;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: all 0.2s ease;
      box-shadow: 0 4px 14px rgba(217, 119, 6, 0.25);
    }

    .gq-btn-update-password:hover {
      background: linear-gradient(135deg, #F59E0B 0%, #D97706 100%);
      transform: translateY(-1px);
      box-shadow: 0 8px 20px rgba(217, 119, 6, 0.35);
      color: #FFFFFF;
    }

    .gq-pass-wrap {
      position: relative;
    }

    .gq-pass-toggle-btn {
      position: absolute;
      right: 12px;
      top: 50%;
      transform: translateY(-50%);
      background: transparent;
      border: none;
      color: #64748B;
      cursor: pointer;
      font-size: 16px;
      padding: 4px;
    }

    .gq-pass-toggle-btn:hover {
      color: #0F2744;
    }

    @media(max-width: 1199px) {
      .gq-profile-main {
        margin-left: 0;
        width: 100%;
        padding: max(88px, calc(72px + env(safe-area-inset-top))) 16px 32px;
      }
    }

    @media(max-width: 767px) {
      .gq-profile-hero {
        flex-direction: column;
        align-items: flex-start;
        padding: 24px 20px;
      }
      .gq-btn-refresh-profile {
        width: 100%;
        text-align: center;
        justify-content: center;
      }
      .gq-card-box {
        padding: 20px 16px;
      }
    }
  `;return m&&!S?(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(`style`,{children:$}),(0,d.jsx)(s,{sidebarOpen:t,setSidebarOpen:p}),(0,d.jsx)(`div`,{className:`container-fluid`,children:(0,d.jsxs)(`div`,{className:`row`,children:[(0,d.jsx)(o,{sidebarOpen:t,setSidebarOpen:p}),(0,d.jsxs)(`main`,{className:`gq-profile-main d-flex flex-column`,children:[(0,d.jsx)(`div`,{className:`py-5 text-center`,children:(0,d.jsx)(r,{message:`Loading profile settings...`})}),(0,d.jsx)(l,{})]})]})})]}):(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(`style`,{children:$}),(0,d.jsx)(s,{sidebarOpen:t,setSidebarOpen:p}),(0,d.jsx)(`div`,{className:`container-fluid`,children:(0,d.jsxs)(`div`,{className:`row`,children:[(0,d.jsx)(o,{sidebarOpen:t,setSidebarOpen:p}),(0,d.jsxs)(`main`,{className:`gq-profile-main d-flex flex-column`,children:[(g||v||b)&&(0,d.jsx)(r,{message:g?`Updating personal details...`:v?`Securing new password...`:`Revoking active sessions...`}),(0,d.jsxs)(`div`,{className:`gq-profile-shell`,children:[(0,d.jsxs)(`section`,{className:`gq-profile-hero`,children:[(0,d.jsxs)(`div`,{className:`gq-profile-hero-copy`,children:[(0,d.jsxs)(`span`,{className:`gq-profile-eyebrow`,children:[(0,d.jsx)(`i`,{className:`bi bi-shield-lock-fill`}),` User Account & Security`]}),(0,d.jsx)(`h1`,{children:`Profile & Account Settings`}),(0,d.jsx)(`p`,{children:`Manage your personal credentials, contact details, authentication keys, and active session permissions.`})]}),(0,d.jsx)(`div`,{children:(0,d.jsxs)(`button`,{className:`btn gq-btn-refresh-profile d-inline-flex align-items-center gap-2`,onClick:Q,disabled:m,children:[(0,d.jsx)(`i`,{className:`bi bi-arrow-clockwise`}),`Refresh Profile`]})})]}),J&&(0,d.jsxs)(`div`,{className:`alert alert-info py-3 px-4 mb-4 d-flex align-items-center gap-3`,style:{background:`#EFF6FF`,border:`1.5px solid #BFDBFE`,borderRadius:`14px`,color:`#1E40AF`},children:[(0,d.jsx)(`i`,{className:`bi bi-info-circle-fill fs-5`}),(0,d.jsx)(`span`,{style:{fontSize:`13.5px`,fontWeight:600},children:`Student record details (names, contact info, and profile photos) are managed by your School Administrator. You can update your account password in the security section below.`})]}),(0,d.jsxs)(`div`,{className:`row g-4`,children:[(0,d.jsx)(`div`,{className:`col-12 col-lg-7`,children:(0,d.jsxs)(`div`,{className:`gq-card-box`,children:[(0,d.jsxs)(`div`,{className:`gq-card-header`,children:[(0,d.jsxs)(`div`,{className:`gq-card-header-left`,children:[(0,d.jsx)(`div`,{className:`gq-icon-badge`,style:{background:`#EEF2FF`,color:`#4F46E5`,border:`1px solid #E0E7FF`},children:(0,d.jsx)(`i`,{className:`bi bi-person-bounding-box`})}),(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`h2`,{className:`gq-card-title`,children:`Personal Profile Details`}),(0,d.jsx)(`p`,{className:`gq-card-subtitle`,children:`Keep your official contact records updated.`})]})]}),(0,d.jsxs)(`span`,{className:`badge px-3 py-2 fw-bold`,style:{background:`#FEF3C7`,color:`#92400E`,border:`1px solid #FDE68A`,borderRadius:`8px`,fontSize:`12px`,letterSpacing:`0.04em`,textTransform:`uppercase`},children:[`Role: `,S?.role||`User`]})]}),(0,d.jsxs)(`div`,{className:`gq-avatar-upload-wrap`,children:[P?(0,d.jsx)(`img`,{src:P,alt:`Avatar Preview`,className:`gq-avatar-preview`,onError:()=>F(null)}):(0,d.jsx)(`div`,{className:`gq-avatar-preview`,children:ue(w,E)}),(0,d.jsxs)(`div`,{className:`flex-grow-1`,children:[(0,d.jsx)(`h6`,{style:{fontWeight:800,color:`#0F2744`,marginBottom:`4px`},children:`Profile Avatar`}),(0,d.jsx)(`p`,{style:{fontSize:`12.5px`,color:`#64748B`,marginBottom:`10px`},children:`PNG, JPG, or WebP up to 2MB. Displayed across the portal topnav and reports.`}),(0,d.jsx)(`input`,{ref:R,type:`file`,accept:`image/png, image/jpeg, image/webp`,className:`d-none`,onChange:e=>ae(e.target.files?.[0]||null)}),X&&(0,d.jsxs)(`div`,{className:`d-flex align-items-center gap-2 flex-wrap`,children:[(0,d.jsxs)(`button`,{type:`button`,onClick:ie,className:`btn btn-sm btn-outline-primary fw-bold px-3 py-1.5`,style:{borderRadius:`8px`,fontSize:`12.5px`},children:[(0,d.jsx)(`i`,{className:`bi bi-upload me-1`}),I?`Change Selected Photo`:`Upload New Photo`]}),I&&(0,d.jsx)(`button`,{type:`button`,onClick:oe,className:`btn btn-sm btn-outline-secondary fw-semibold px-2.5 py-1.5`,style:{borderRadius:`8px`,fontSize:`12px`},children:`Cancel`})]})]})]}),(0,d.jsxs)(`div`,{className:`row g-3`,children:[(0,d.jsxs)(`div`,{className:`col-md-6`,children:[(0,d.jsx)(`label`,{className:`gq-form-label`,children:`First Name`}),(0,d.jsx)(`input`,{type:`text`,value:w,onChange:e=>T(e.target.value),disabled:!X||g,className:`gq-form-input`,placeholder:`First Name`})]}),(0,d.jsxs)(`div`,{className:`col-md-6`,children:[(0,d.jsx)(`label`,{className:`gq-form-label`,children:`Surname / Last Name`}),(0,d.jsx)(`input`,{type:`text`,value:E,onChange:e=>D(e.target.value),disabled:!X||g,className:`gq-form-input`,placeholder:`Surname`})]}),(0,d.jsxs)(`div`,{className:`col-md-6`,children:[(0,d.jsx)(`label`,{className:`gq-form-label`,children:`Email Address`}),(0,d.jsx)(`input`,{type:`email`,value:O,onChange:e=>k(e.target.value),disabled:!Z||g,className:`gq-form-input`,placeholder:`name@school.com`}),!Z&&(0,d.jsx)(`small`,{style:{fontSize:`11px`,color:`#64748B`,marginTop:`3px`,display:`block`},children:Y?`Admin email is locked for institutional security.`:`Managed by school admin.`})]}),(0,d.jsxs)(`div`,{className:`col-md-6`,children:[(0,d.jsx)(`label`,{className:`gq-form-label`,children:`Phone Number`}),(0,d.jsx)(`input`,{type:`tel`,value:A,onChange:e=>j(e.target.value),disabled:!X||g,className:`gq-form-input`,placeholder:`+234 812 000 0000`})]}),(0,d.jsxs)(`div`,{className:`col-12`,children:[(0,d.jsx)(`label`,{className:`gq-form-label`,children:`Residential / Campus Address`}),(0,d.jsx)(`textarea`,{rows:2,value:M,onChange:e=>N(e.target.value),disabled:!X||g,className:`gq-form-input`,placeholder:`Enter your current address...`,style:{minHeight:`72px`}})]}),X&&(0,d.jsx)(`div`,{className:`col-12 pt-2`,children:(0,d.jsxs)(`button`,{type:`button`,onClick:se,disabled:g,className:`gq-btn-save-profile`,children:[(0,d.jsx)(`i`,{className:`bi bi-check2-circle fs-6`}),`Save Profile Information`]})})]})]})}),(0,d.jsxs)(`div`,{className:`col-12 col-lg-5`,children:[(0,d.jsxs)(`div`,{className:`gq-card-box`,children:[(0,d.jsx)(`div`,{className:`gq-card-header`,children:(0,d.jsxs)(`div`,{className:`gq-card-header-left`,children:[(0,d.jsx)(`div`,{className:`gq-icon-badge`,style:{background:`#FEF3C7`,color:`#B45309`,border:`1px solid #FDE68A`},children:(0,d.jsx)(`i`,{className:`bi bi-key-fill`})}),(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`h2`,{className:`gq-card-title`,children:`Change Password`}),(0,d.jsx)(`p`,{className:`gq-card-subtitle`,children:`Ensure your account uses a strong password.`})]})]})}),(0,d.jsxs)(`div`,{className:`d-flex flex-column gap-3`,children:[(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`label`,{className:`gq-form-label`,children:`Current Password`}),(0,d.jsxs)(`div`,{className:`gq-pass-wrap`,children:[(0,d.jsx)(`input`,{type:G?`text`:`password`,value:z,onChange:e=>B(e.target.value),disabled:v,className:`gq-form-input`,placeholder:`Enter current password`}),(0,d.jsx)(`button`,{type:`button`,className:`gq-pass-toggle-btn`,onClick:()=>te(!G),tabIndex:-1,children:(0,d.jsx)(`i`,{className:`bi ${G?`bi-eye-slash`:`bi-eye`}`})})]})]}),(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`label`,{className:`gq-form-label`,children:`New Password (Min 8 Characters)`}),(0,d.jsxs)(`div`,{className:`gq-pass-wrap`,children:[(0,d.jsx)(`input`,{type:K?`text`:`password`,value:V,onChange:e=>H(e.target.value),disabled:v,className:`gq-form-input`,placeholder:`Enter new strong password`}),(0,d.jsx)(`button`,{type:`button`,className:`gq-pass-toggle-btn`,onClick:()=>ne(!K),tabIndex:-1,children:(0,d.jsx)(`i`,{className:`bi ${K?`bi-eye-slash`:`bi-eye`}`})})]})]}),(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`label`,{className:`gq-form-label`,children:`Confirm New Password`}),(0,d.jsxs)(`div`,{className:`gq-pass-wrap`,children:[(0,d.jsx)(`input`,{type:q?`text`:`password`,value:U,onChange:e=>W(e.target.value),disabled:v,className:`gq-form-input`,placeholder:`Confirm new password`}),(0,d.jsx)(`button`,{type:`button`,className:`gq-pass-toggle-btn`,onClick:()=>re(!q),tabIndex:-1,children:(0,d.jsx)(`i`,{className:`bi ${q?`bi-eye-slash`:`bi-eye`}`})})]})]}),(0,d.jsx)(`div`,{className:`pt-2`,children:(0,d.jsxs)(`button`,{type:`button`,onClick:le,disabled:v,className:`gq-btn-update-password w-100 justify-content-center`,children:[(0,d.jsx)(`i`,{className:`bi bi-shield-lock`}),`Update Password`]})})]})]}),(0,d.jsxs)(`div`,{className:`gq-card-box`,children:[(0,d.jsx)(`div`,{className:`gq-card-header`,children:(0,d.jsxs)(`div`,{className:`gq-card-header-left`,children:[(0,d.jsx)(`div`,{className:`gq-icon-badge`,style:{background:`#FEE2E2`,color:`#DC2626`,border:`1px solid #FECACA`},children:(0,d.jsx)(`i`,{className:`bi bi-laptop`})}),(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`h2`,{className:`gq-card-title`,children:`Session Security`}),(0,d.jsx)(`p`,{className:`gq-card-subtitle`,children:`Manage devices logged into your account.`})]})]})}),(0,d.jsx)(`p`,{style:{fontSize:`13px`,color:`#64748B`,lineHeight:1.6,marginBottom:`16px`},children:`If you suspect any unauthorized access or left your account logged in on a public computer, you can terminate all other active device sessions immediately.`}),(0,d.jsxs)(`button`,{type:`button`,onClick:ce,disabled:b,className:`btn btn-outline-danger fw-bold w-100 py-2.5 d-flex align-items-center justify-content-center gap-2`,style:{borderRadius:`10px`,fontSize:`13.5px`},children:[(0,d.jsx)(`i`,{className:`bi bi-box-arrow-right`}),`Log Out All Other Devices`]})]})]})]})]}),(0,d.jsx)(l,{})]})]})})]})}export{p as default};