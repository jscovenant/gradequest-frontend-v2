import{i as e}from"./rolldown-runtime-CWU8vmCm.js";import{Ut as t}from"./vendor-misc-OZLc0tLq.js";import{p as n}from"./vendor-react-BhRGw7qi.js";import{n as r,t as i}from"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as a,E as o,P as s,d as c,f as l,l as u,u as d}from"./index-D6TxbaCx.js";var f=t(),p=e(r(),1),m=i(),h=n();p.default.vfs=m.vfs;function g(){let e=new Date().getHours();return e<12?`Good morning`:e<17?`Good afternoon`:`Good evening`}function _(e){if(!e)return`-`;let t=new Date(e);return Number.isNaN(t.getTime())?e:t.toLocaleDateString(void 0,{day:`2-digit`,month:`short`,year:`numeric`})}function v(e,t){return!e||!t?{start:e,end:t}:new Date(e)>new Date(t)?{start:t,end:e}:{start:e,end:t}}function y(){let[e,t]=(0,f.useState)(!1),{showSuccess:n,showError:r}=u(),[i,m]=(0,f.useState)([]),[y,b]=(0,f.useState)(``),x=new Date().toISOString().slice(0,10),[S,C]=(0,f.useState)(x),[w,T]=(0,f.useState)(x),[E,D]=(0,f.useState)([]),[O,k]=(0,f.useState)(!0),[A,j]=(0,f.useState)(!1),M=(0,f.useMemo)(()=>i.find(e=>String(e.id)===String(y))?.name??`No class selected`,[i,y]),N=(0,f.useMemo)(()=>{let e=e=>E.reduce((t,n)=>t+(Number(n[e])||0),0);return{students:E.length,present:e(`present`),absent:e(`absent`),late:e(`late`),excused:e(`excused`),tp:e(`totalTimesPresent`),ta:e(`totalTimesAbsent`),total:e(`total`)}},[E]),P=(0,f.useMemo)(()=>E.length?{bg:`rgba(34,197,94,0.16)`,fg:`#22c55e`,text:`READY`}:{bg:`rgba(245,158,11,0.16)`,fg:`#fbbf24`,text:`NO DATA`},[E.length]);(0,f.useEffect)(()=>{(async()=>{try{let e=(await s.get(`/attendance/classes`)).data;m(Array.isArray(e)?e:Array.isArray(e?.classes)?e.classes:[]);let t=e?.default_class_id==null?``:String(e.default_class_id);t&&!y&&b(t)}catch(e){console.error(e),r?.(`Failed to load classes.`)}finally{k(!1)}})()},[]);let F=async()=>{if(!y)return r?.(`Please select a class`);let e=v(S,w);e.start!==S&&C(e.start),e.end!==w&&T(e.end),j(!0);try{let t=await s.get(`/student-report`,{params:{class_id:y,start_date:e.start,end_date:e.end}});D(Array.isArray(t.data)?t.data:[]),n?.(`Report generated for ${M}.`)}catch(e){console.error(e),r?.(`Failed to generate report`),D([])}finally{j(!1)}},I=()=>{if(!E.length)return;let e=`data:text/csv;charset=utf-8,`+[[`Student Name`,`Present`,`Absent`,`Late`,`Excused`,`Total Times Present`,`Total Times Absent`,`Total`],...E.map(e=>[e.name,e.present,e.absent,e.late,e.excused,e.totalTimesPresent,e.totalTimesAbsent,e.total])].map(e=>e.join(`,`)).join(`
`),t=document.createElement(`a`);t.href=encodeURI(e),t.download=`attendance_report.csv`,t.click()},L=()=>{if(!E.length)return;let e=[[`#`,`Student`,`P`,`A`,`L`,`E`,`TP`,`TA`,`Total`],...E.map((e,t)=>[t+1,e.name,e.present,e.absent,e.late,e.excused,e.totalTimesPresent,e.totalTimesAbsent,e.total]),[``,`TOTAL`,N.present,N.absent,N.late,N.excused,N.tp,N.ta,N.total]];p.default.createPdf({content:[{text:`Student Attendance Report`,bold:!0,fontSize:16,margin:[0,0,0,6]},{text:`${M} • ${_(S)} - ${_(w)}`,color:`#555`,margin:[0,0,0,10]},{table:{headerRows:1,widths:[`auto`,`*`,`auto`,`auto`,`auto`,`auto`,`auto`,`auto`,`auto`],body:e},layout:`lightHorizontalLines`}],defaultStyle:{fontSize:10}}).download(`attendance_report.pdf`)};return(0,h.jsxs)(h.Fragment,{children:[(0,h.jsx)(`style`,{children:`
        /* ===== AdminDashboard template styles (Modern SaaS) ===== */
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');
        .db-main {
          background: #F8FAFC;
          min-height: 100vh;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          padding: 24px 28px 0;
        }

        .db-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 18px;
          padding: 32px 36px;
          position: relative;
          overflow: hidden;
          margin: 10px 0 24px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
        }
        .db-hero-glow {
          position: absolute;
          top: -60px;
          right: -60px;
          width: 320px;
          height: 320px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.15) 0%, transparent 65%);
          pointer-events: none;
        }
        .db-hero-glow2 {
          position: absolute;
          bottom: -40px;
          left: 30%;
          width: 200px;
          height: 200px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(37, 99, 235, 0.10) 0%, transparent 70%);
          pointer-events: none;
        }
        .db-hero-inner {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 32px;
          flex-wrap: wrap;
        }
        @media (min-width: 768px) { .db-hero-inner { flex-wrap: nowrap; } }

        .db-session-badge {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.20);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius: 100px;
          padding: 4px 12px;
          margin-bottom: 12px;
        }
        .db-session-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #10B981;
          animation: dbPulse 2s ease infinite;
        }
        @keyframes dbPulse {
          0%,100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.4; transform: scale(1.5); }
        }

        .db-greeting {
          font-size: 26px;
          font-weight: 800;
          color: #fff;
          line-height: 1.1;
          margin-bottom: 8px;
        }
        .db-greeting em { font-style: normal; color: #FBBF24; }

        .db-hero-sub {
          font-size: 13.5px;
          color: #CBD5E1;
          line-height: 1.6;
          max-width: 520px;
          margin-bottom: 20px;
        }

        .db-hero-btns { display: flex; gap: 10px; flex-wrap: wrap; }

        .db-btn-gold {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 9px 18px;
          font-size: 13px;
          font-weight: 700;
          color: #FFFFFF;
          background: #D97706;
          border: none;
          border-radius: 10px;
          cursor: pointer;
          transition: all 0.2s ease;
          white-space: nowrap;
        }
        .db-btn-gold:hover { background: #B45309; transform: translateY(-1px); color: #FFFFFF; }
        .db-btn-gold:disabled { opacity: 0.55; cursor: not-allowed; transform: none; }

        .db-btn-outline {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 9px 18px;
          font-size: 13px;
          font-weight: 600;
          color: #FFFFFF;
          background: rgba(255, 255, 255, 0.10);
          border: 1px solid rgba(255, 255, 255, 0.20);
          border-radius: 10px;
          cursor: pointer;
          transition: all 0.2s ease;
          white-space: nowrap;
        }
        .db-btn-outline:hover { background: rgba(255, 255, 255, 0.18); color: #fff; }
        .db-btn-outline:disabled { opacity: 0.55; cursor: not-allowed; }

        .db-hero-stat-card {
          background: rgba(255, 255, 255, 0.08);
          border: 1px solid rgba(255, 255, 255, 0.15);
          backdrop-filter: blur(8px);
          border-radius: 14px;
          padding: 18px 20px;
          min-width: 240px;
          margin-left: auto;
          align-self: flex-end;
        }

        .db-hero-stat-row { display: flex; flex-direction: column; gap: 10px; }
        .db-hero-stat-item { display: flex; justify-content: space-between; align-items: center; gap: 16px; }
        .db-hero-stat-label { font-size: 12px; font-weight: 400; color: #CBD5E1; }
        .db-hero-stat-val { font-size: 18px; font-weight: 800; color: #FBBF24; }
        .db-hero-stat-sep { height: 1px; background: rgba(255, 255, 255, 0.08); }

        .db-panel {
          background: #ffffff;
          border: 1px solid #E2E8F0;
          border-radius: 16px;
          overflow: hidden;
          box-shadow: 0 4px 16px rgba(15,39,68,0.03);
          margin-bottom: 20px;
        }

        .db-panel-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 18px 20px;
          border-bottom: 1px solid #E2E8F0;
          gap: 12px;
          flex-wrap: wrap;
        }

        .db-panel-title {
          font-size: 16px;
          font-weight: 700;
          color: #0F2744;
          margin: 0;
        }

        .db-panel-sub {
          font-size: 12px;
          color: #64748B;
          margin: 0;
        }

        .db-refresh-btn {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 7px 14px;
          font-size: 12px;
          font-weight: 400;
          color: #7a6a5a;
          background: #f5f1eb;
          border: 1px solid #e5ddd3;
          border-radius: var(--bs-border-radius, 7px);
          cursor: pointer;
          transition: background 0.2s;
          white-space: nowrap;
        }
        .db-refresh-btn:hover { background: #ede8e0; }
        .db-refresh-btn:disabled { opacity: 0.5; cursor: not-allowed; }

        .db-search {
          display: flex;
          align-items: center;
          gap: 10px;
          background: #fff;
          border: 1px solid #e5ddd3;
          border-radius: 12px;
          padding: 10px 12px;
          min-width: 260px;
        }
        .db-search input { border: none; outline: none; width: 100%; font-size: 13px; }

        .db-pill {
          display: inline-flex;
          align-items: center;
          font-size: 12px;
          font-weight: 800;
          padding: 6px 10px;
          border-radius: 999px;
          white-space: nowrap;
          border: 1px solid rgba(0,0,0,0.06);
        }

        .db-progress-bar {
          height: 10px;
          border-radius: 999px;
          background: #f0ebe3;
          overflow: hidden;
          border: 1px solid rgba(0,0,0,0.06);
        }
        .db-progress-fill {
          height: 100%;
          width: var(--w, 0%);
          background: linear-gradient(90deg, rgba(201,168,76,0.9), rgba(201,168,76,0.25));
        }

        .db-table { width: 100%; border-collapse: collapse; }
        .db-table th {
          padding: 10px 16px;
          font-size: 11px;
          font-weight: 500;
          letter-spacing: 0.1em;
          text-transform: uppercase;
          color: #9a8a7a;
          background: #faf8f5;
          border-bottom: 1px solid rgba(0, 0, 0, 0.06);
          text-align: left;
          white-space: nowrap;
        }
        .db-table td {
          padding: 13px 16px;
          font-size: 13.5px;
          color: #4a4a5a;
          border-bottom: 1px solid rgba(0, 0, 0, 0.06);
          vertical-align: middle;
        }
        .db-table tbody tr:last-child td { border-bottom: none; }
        .db-table tbody tr:hover { background: #faf8f5; }

        .db-muted { color: #9a8a7a; }
        .db-strong { font-weight: 900; color: #1a1a2e; }

        .db-skeleton {
          height: 14px;
          border-radius: 7px;
          background: linear-gradient(90deg, #f0ebe3 25%, #e8e0d5 50%, #f0ebe3 75%);
          background-size: 200% 100%;
          animation: dbSkeleton 1.4s ease infinite;
        }
        @keyframes dbSkeleton { from { background-position: 200% 0; } to { background-position: -200% 0; } }

        @media (max-width: 991.98px) { .db-main { padding: 18px 14px 0; } }
      `}),(0,h.jsx)(l,{sidebarOpen:e,setSidebarOpen:t}),(0,h.jsx)(a,{title:`Report`}),(0,h.jsx)(`div`,{className:`container-fluid`,children:(0,h.jsxs)(`div`,{className:`row`,children:[(0,h.jsx)(c,{sidebarOpen:e}),(0,h.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto db-main`,children:[O&&(0,h.jsx)(o,{message:`Loading classes...`}),(0,h.jsxs)(`div`,{className:`db-hero`,children:[(0,h.jsx)(`div`,{className:`db-hero-glow`,"aria-hidden":`true`}),(0,h.jsx)(`div`,{className:`db-hero-glow2`,"aria-hidden":`true`}),(0,h.jsxs)(`div`,{className:`db-hero-inner`,children:[(0,h.jsxs)(`div`,{children:[(0,h.jsxs)(`div`,{className:`db-session-badge`,children:[(0,h.jsx)(`span`,{className:`db-session-dot`}),`Attendance — Reports`]}),(0,h.jsxs)(`h1`,{className:`db-greeting`,children:[g(),`, `,(0,h.jsx)(`em`,{children:`Staff.`})]}),(0,h.jsx)(`p`,{className:`db-hero-sub`,children:`Generate class attendance report by date range and export for printing or sharing.`}),(0,h.jsxs)(`div`,{className:`db-hero-btns`,children:[(0,h.jsx)(`button`,{className:`db-btn-gold`,onClick:F,disabled:A||O,children:A?(0,h.jsxs)(h.Fragment,{children:[(0,h.jsx)(`span`,{className:`spinner-border spinner-border-sm`}),`Generating…`]}):(0,h.jsxs)(h.Fragment,{children:[(0,h.jsx)(`i`,{className:`bi bi-play-circle`}),`Generate Report`]})}),(0,h.jsxs)(`button`,{className:`db-btn-outline`,onClick:I,disabled:!E.length||A,children:[(0,h.jsx)(`i`,{className:`bi bi-filetype-csv`}),`CSV`]}),(0,h.jsxs)(`button`,{className:`db-btn-outline`,onClick:L,disabled:!E.length||A,children:[(0,h.jsx)(`i`,{className:`bi bi-file-earmark-pdf`}),`PDF`]})]})]}),(0,h.jsxs)(`div`,{className:`db-hero-stat-card d-none d-md-block`,children:[(0,h.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,marginBottom:16},children:[(0,h.jsx)(`span`,{style:{fontSize:11,fontWeight:500,letterSpacing:`0.14em`,textTransform:`uppercase`,color:`#c9a84c`},children:`Quick glance`}),(0,h.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:(0,h.jsx)(`path`,{d:`M2 10V6M5 10V4M8 10V7M11 10V3`,stroke:`#64748b`,strokeWidth:`1.5`,strokeLinecap:`round`})})]}),(0,h.jsxs)(`div`,{className:`db-hero-stat-row`,children:[(0,h.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,h.jsx)(`span`,{className:`db-hero-stat-label`,children:`Class`}),(0,h.jsx)(`span`,{className:`db-hero-stat-val`,style:{fontSize:14,fontFamily:`DM Sans`},children:M})]}),(0,h.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,h.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,h.jsx)(`span`,{className:`db-hero-stat-label`,children:`Range`}),(0,h.jsxs)(`span`,{className:`db-hero-stat-val`,style:{fontSize:14,fontFamily:`DM Sans`},children:[_(S),` — `,_(w)]})]}),(0,h.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,h.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,h.jsx)(`span`,{className:`db-hero-stat-label`,children:`Students`}),(0,h.jsx)(`span`,{className:`db-hero-stat-val`,children:N.students})]}),(0,h.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,h.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,h.jsx)(`span`,{className:`db-hero-stat-label`,children:`Status`}),(0,h.jsx)(`span`,{className:`db-pill`,style:{background:P.bg,color:P.fg},children:P.text})]})]})]})]})]}),(0,h.jsxs)(`div`,{className:`db-panel`,children:[(0,h.jsxs)(`div`,{className:`db-panel-head`,children:[(0,h.jsxs)(`div`,{children:[(0,h.jsx)(`p`,{className:`db-panel-title`,children:`Filters`}),(0,h.jsx)(`p`,{className:`db-panel-sub`,children:`Select class and date range, then generate report.`})]}),(0,h.jsx)(`button`,{className:`db-refresh-btn`,onClick:F,disabled:A||O,children:A?(0,h.jsxs)(h.Fragment,{children:[(0,h.jsx)(`span`,{className:`spinner-border spinner-border-sm`}),`Generating…`]}):(0,h.jsxs)(h.Fragment,{children:[(0,h.jsx)(`i`,{className:`bi bi-play-circle`}),`Generate`]})})]}),(0,h.jsx)(`div`,{style:{padding:16},children:(0,h.jsxs)(`div`,{className:`row g-3 align-items-end`,children:[(0,h.jsxs)(`div`,{className:`col-12 col-md-4`,children:[(0,h.jsx)(`label`,{className:`form-label fw-semibold small mb-1`,children:`Class`}),(0,h.jsxs)(`select`,{className:`form-select`,value:y,onChange:e=>b(e.target.value),disabled:O,children:[(0,h.jsx)(`option`,{value:``,children:`Select Class`}),i.map(e=>(0,h.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]}),(0,h.jsxs)(`div`,{className:`col-6 col-md-4`,children:[(0,h.jsx)(`label`,{className:`form-label fw-semibold small mb-1`,children:`Start Date`}),(0,h.jsx)(`input`,{type:`date`,className:`form-control`,value:S,onChange:e=>C(e.target.value),disabled:O})]}),(0,h.jsxs)(`div`,{className:`col-6 col-md-4`,children:[(0,h.jsx)(`label`,{className:`form-label fw-semibold small mb-1`,children:`End Date`}),(0,h.jsx)(`input`,{type:`date`,className:`form-control`,value:w,onChange:e=>T(e.target.value),disabled:O})]})]})})]}),(0,h.jsx)(`div`,{className:`row g-3 mt-1 mb-3`,children:[{title:`Students`,value:N.students,icon:`people`,toneBg:`#ede9fe`,toneFg:`#7c3aed`},{title:`Present`,value:N.present,icon:`check2-circle`,toneBg:`#d1fae5`,toneFg:`#065f46`},{title:`Absent`,value:N.absent,icon:`x-circle`,toneBg:`#ffe4e6`,toneFg:`#be123c`},{title:`Late`,value:N.late,icon:`alarm`,toneBg:`#dbeafe`,toneFg:`#1e40af`}].map(e=>(0,h.jsx)(`div`,{className:`col-md-6 col-lg-3`,children:(0,h.jsxs)(`div`,{className:`db-panel`,style:{padding:16},children:[(0,h.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`},children:[(0,h.jsx)(`div`,{style:{width:44,height:44,borderRadius:12,background:e.toneBg,color:e.toneFg,display:`flex`,alignItems:`center`,justifyContent:`center`},children:(0,h.jsx)(`i`,{className:`bi bi-${e.icon}`,style:{fontSize:18}})}),(0,h.jsx)(`i`,{className:`bi bi-three-dots-vertical`,style:{color:`#c8bfb5`}})]}),(0,h.jsxs)(`div`,{style:{marginTop:12},children:[(0,h.jsx)(`div`,{className:`db-muted`,style:{fontSize:12},children:e.title}),(0,h.jsx)(`div`,{className:`db-strong`,style:{fontFamily:`Lora, serif`,fontSize:26,marginTop:2},children:e.value}),(0,h.jsx)(`div`,{style:{marginTop:12,paddingTop:10,borderTop:`1px solid rgba(0,0,0,0.06)`},children:(0,h.jsxs)(`span`,{className:`db-muted`,style:{fontSize:12},children:[(0,h.jsx)(`i`,{className:`bi bi-info-circle me-1`}),`Based on selected range`]})})]})]})},e.title))}),E.length>0&&(0,h.jsx)(`div`,{className:`db-panel`,children:(0,h.jsxs)(`div`,{className:`db-panel-head`,children:[(0,h.jsxs)(`div`,{children:[(0,h.jsx)(`p`,{className:`db-panel-title`,children:`Export`}),(0,h.jsx)(`p`,{className:`db-panel-sub`,children:`Download attendance report in CSV or PDF format.`})]}),(0,h.jsxs)(`div`,{style:{display:`flex`,gap:10,flexWrap:`wrap`},children:[(0,h.jsxs)(`button`,{className:`db-refresh-btn`,onClick:I,disabled:A,children:[(0,h.jsx)(`i`,{className:`bi bi-filetype-csv`}),`CSV`]}),(0,h.jsxs)(`button`,{className:`db-refresh-btn`,onClick:L,disabled:A,children:[(0,h.jsx)(`i`,{className:`bi bi-file-earmark-pdf`}),`PDF`]})]})]})}),(0,h.jsxs)(`div`,{className:`db-panel`,children:[(0,h.jsxs)(`div`,{className:`db-panel-head`,children:[(0,h.jsxs)(`div`,{children:[(0,h.jsx)(`p`,{className:`db-panel-title`,children:`Report table`}),(0,h.jsx)(`p`,{className:`db-panel-sub`,children:`P, A, L, E, TP, TA totals included.`})]}),(0,h.jsx)(`span`,{className:`db-pill`,style:{background:`rgba(0,0,0,0.04)`,color:`#7a6a5a`},children:E.length?`${E.length} students`:`No data`})]}),(0,h.jsx)(`div`,{style:{overflowX:`auto`},children:(0,h.jsxs)(`table`,{className:`db-table`,children:[(0,h.jsx)(`thead`,{children:(0,h.jsxs)(`tr`,{children:[(0,h.jsx)(`th`,{style:{width:60},children:`#`}),(0,h.jsx)(`th`,{children:`Student`}),(0,h.jsx)(`th`,{style:{textAlign:`center`},children:`P`}),(0,h.jsx)(`th`,{style:{textAlign:`center`},children:`A`}),(0,h.jsx)(`th`,{style:{textAlign:`center`},children:`L`}),(0,h.jsx)(`th`,{style:{textAlign:`center`},children:`E`}),(0,h.jsx)(`th`,{style:{textAlign:`center`},children:`TP`}),(0,h.jsx)(`th`,{style:{textAlign:`center`},children:`TA`}),(0,h.jsx)(`th`,{style:{textAlign:`center`},children:`Total`})]})}),(0,h.jsx)(`tbody`,{children:A?(0,h.jsx)(`tr`,{children:(0,h.jsxs)(`td`,{colSpan:9,style:{padding:40,textAlign:`center`},children:[(0,h.jsx)(`span`,{className:`spinner-border text-primary me-2`}),(0,h.jsx)(`span`,{className:`db-muted`,children:`Generating report…`})]})}):E.length===0?(0,h.jsx)(`tr`,{children:(0,h.jsxs)(`td`,{colSpan:9,style:{padding:46,textAlign:`center`,color:`#b5a090`},children:[(0,h.jsx)(`div`,{style:{fontWeight:800,color:`#1a1a2e`},children:`No report generated`}),(0,h.jsx)(`div`,{style:{fontSize:12.5,marginTop:4},children:`Select filters and click “Generate”.`})]})}):(0,h.jsxs)(h.Fragment,{children:[E.map((e,t)=>(0,h.jsxs)(`tr`,{children:[(0,h.jsx)(`td`,{style:{color:`#9a8a7a`},children:t+1}),(0,h.jsx)(`td`,{className:`db-strong`,style:{fontWeight:600},children:e.name}),(0,h.jsx)(`td`,{style:{textAlign:`center`},children:e.present}),(0,h.jsx)(`td`,{style:{textAlign:`center`},children:e.absent}),(0,h.jsx)(`td`,{style:{textAlign:`center`},children:e.late}),(0,h.jsx)(`td`,{style:{textAlign:`center`},children:e.excused}),(0,h.jsx)(`td`,{style:{textAlign:`center`},children:e.totalTimesPresent}),(0,h.jsx)(`td`,{style:{textAlign:`center`},children:e.totalTimesAbsent}),(0,h.jsx)(`td`,{style:{textAlign:`center`,fontWeight:900,color:`#1a1a2e`},children:e.total})]},e.id)),(0,h.jsxs)(`tr`,{style:{background:`#faf8f5`},children:[(0,h.jsx)(`td`,{}),(0,h.jsx)(`td`,{className:`db-strong`,children:`TOTAL`}),(0,h.jsx)(`td`,{style:{textAlign:`center`,fontWeight:800},children:N.present}),(0,h.jsx)(`td`,{style:{textAlign:`center`,fontWeight:800},children:N.absent}),(0,h.jsx)(`td`,{style:{textAlign:`center`,fontWeight:800},children:N.late}),(0,h.jsx)(`td`,{style:{textAlign:`center`,fontWeight:800},children:N.excused}),(0,h.jsx)(`td`,{style:{textAlign:`center`,fontWeight:800},children:N.tp}),(0,h.jsx)(`td`,{style:{textAlign:`center`,fontWeight:800},children:N.ta}),(0,h.jsx)(`td`,{style:{textAlign:`center`,fontWeight:900,color:`#1a1a2e`},children:N.total})]})]})})]})})]}),(0,h.jsx)(`div`,{className:`mt-auto`,children:(0,h.jsx)(d,{})})]})]})})]})}export{y as default};