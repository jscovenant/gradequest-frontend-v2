import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{p as t}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as n,E as r,P as i,d as a,f as o,u as s}from"./index-D6TxbaCx.js";var c=e(),l=t();function u(){let[e,t]=(0,c.useState)(!1),[u,d]=(0,c.useState)(!0),[f,p]=(0,c.useState)(null),[m,h]=(0,c.useState)(null),g=async()=>{try{d(!0);let e=await i.get(`/parent/school-info`);p(e.data.school),h(e.data.academic_calendar)}catch(e){console.error(`Failed to load school information`,e)}finally{d(!1)}};return(0,c.useEffect)(()=>{g()},[]),(0,l.jsxs)(l.Fragment,{children:[(0,l.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');

        .p-info-main {
          background: #F8FAFC;
          min-height: 100vh;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          padding: calc(66px + 24px) 28px 40px !important;
        }

        @media (max-width: 767.98px) {
          .p-info-main {
            padding: calc(66px + 16px) 14px 36px !important;
          }
        }

        .p-info-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 18px;
          padding: 32px 36px;
          color: #FFFFFF;
          margin-bottom: 24px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
          position: relative;
          overflow: hidden;
        }

        @media (max-width: 767.98px) {
          .p-info-hero {
            padding: 20px 18px !important;
            border-radius: 14px !important;
            margin-bottom: 16px !important;
          }
        }

        .p-info-hero::before {
          content: '';
          position: absolute;
          inset: 0;
          background-image:
            linear-gradient(rgba(255, 255, 255, 0.035) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255, 255, 255, 0.035) 1px, transparent 1px);
          background-size: 32px 32px;
          pointer-events: none;
        }

        .p-info-hero-glow {
          position: absolute;
          top: -40px;
          right: -40px;
          width: 320px;
          height: 320px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.2) 0%, transparent 65%);
          pointer-events: none;
        }

        .p-info-hero-inner {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          flex-wrap: wrap;
          gap: 20px;
        }

        .p-info-badge {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.20);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius: 100px;
          padding: 4px 12px;
          margin-bottom: 12px;
        }

        .p-info-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #10B981;
          box-shadow: 0 0 6px #10B981;
        }

        .p-info-title {
          font-size: 26px;
          font-weight: 800;
          color: #FFFFFF;
          line-height: 1.1;
          margin-bottom: 8px;
        }

        .p-info-title em {
          font-style: normal;
          color: #FBBF24;
        }

        .p-info-sub {
          font-size: 13.5px;
          color: #CBD5E1;
          line-height: 1.6;
          max-width: 620px;
          margin-bottom: 0;
        }

        @media (max-width: 767.98px) {
          .p-info-title {
            font-size: 20px !important;
          }
          .p-info-sub {
            font-size: 12.5px !important;
          }
        }

        /* Panels */
        .p-info-panel {
          background: #FFFFFF;
          border: 1px solid rgba(15, 39, 68, 0.08);
          border-radius: 18px;
          box-shadow: 0 4px 20px rgba(15, 39, 68, 0.06);
          overflow: hidden;
          margin-bottom: 24px;
        }

        .p-info-panel-head {
          padding: 18px 24px;
          border-bottom: 1px solid #E2E8F0;
          display: flex;
          align-items: center;
          justify-content: space-between;
          background: #FAFCFF;
        }

        .p-term-card {
          border: 1.5px solid #E2E8F0;
          border-radius: 14px;
          padding: 18px;
          transition: all 0.2s ease;
          background: #FFFFFF;
        }

        .p-term-card.active {
          border-color: #10B981;
          background: #F0FDF4;
          box-shadow: 0 4px 14px rgba(16, 185, 129, 0.12);
        }
      `}),(0,l.jsx)(o,{sidebarOpen:e,setSidebarOpen:t}),(0,l.jsx)(n,{title:`School Information & Calendar - SchoolProfit`}),(0,l.jsx)(`div`,{className:`container-fluid`,children:(0,l.jsxs)(`div`,{className:`row`,children:[(0,l.jsx)(a,{sidebarOpen:e,setSidebarOpen:t}),(0,l.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto gq-app-main p-info-main d-flex flex-column min-vh-100`,children:[u&&(0,l.jsx)(r,{message:`Loading academic calendar & school info...`}),(0,l.jsxs)(`div`,{className:`p-info-hero`,children:[(0,l.jsx)(`div`,{className:`p-info-hero-glow`}),(0,l.jsx)(`div`,{className:`p-info-hero-inner`,children:(0,l.jsxs)(`div`,{children:[(0,l.jsxs)(`div`,{className:`p-info-badge`,children:[(0,l.jsx)(`span`,{className:`p-info-dot`}),`Parent Portal · School Information & Calendar`]}),(0,l.jsxs)(`h1`,{className:`p-info-title`,children:[f?.name||`School Directory`,`, `,(0,l.jsx)(`em`,{children:`Calendar`})]}),(0,l.jsx)(`p`,{className:`p-info-sub`,children:`View active academic sessions, term milestones, holiday schedules, examination timelines, and school contact details.`})]})})]}),m&&(0,l.jsxs)(`div`,{className:`row g-3 mb-4`,children:[(0,l.jsx)(`div`,{className:`col-md-6 col-lg-4`,children:(0,l.jsx)(`div`,{className:`p-info-panel p-4 h-100`,children:(0,l.jsxs)(`div`,{className:`d-flex align-items-center gap-3`,children:[(0,l.jsx)(`div`,{className:`p-3 bg-primary-subtle text-primary rounded-3 fs-3`,children:(0,l.jsx)(`i`,{className:`bi bi-calendar3`})}),(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`span`,{className:`small text-muted fw-bold text-uppercase`,children:`Active Session`}),(0,l.jsx)(`h4`,{className:`fw-bold text-dark mb-0`,children:m.current_session})]})]})})}),(0,l.jsx)(`div`,{className:`col-md-6 col-lg-4`,children:(0,l.jsx)(`div`,{className:`p-info-panel p-4 h-100`,children:(0,l.jsxs)(`div`,{className:`d-flex align-items-center gap-3`,children:[(0,l.jsx)(`div`,{className:`p-3 bg-success-subtle text-success rounded-3 fs-3`,children:(0,l.jsx)(`i`,{className:`bi bi-bookmark-check`})}),(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`span`,{className:`small text-muted fw-bold text-uppercase`,children:`Current Term`}),(0,l.jsx)(`h4`,{className:`fw-bold text-dark mb-0`,children:m.current_term})]})]})})}),(0,l.jsx)(`div`,{className:`col-md-12 col-lg-4`,children:(0,l.jsx)(`div`,{className:`p-info-panel p-4 h-100`,children:(0,l.jsxs)(`div`,{className:`d-flex align-items-center gap-3`,children:[(0,l.jsx)(`div`,{className:`p-3 bg-warning-subtle text-warning rounded-3 fs-3`,children:(0,l.jsx)(`i`,{className:`bi bi-clock-history`})}),(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`span`,{className:`small text-muted fw-bold text-uppercase`,children:`Portal Status`}),(0,l.jsxs)(`h4`,{className:`fw-bold text-dark mb-0 text-success`,children:[(0,l.jsx)(`i`,{className:`bi bi-circle-fill me-1 small`,style:{fontSize:10}}),`Online & Synchronized`]})]})]})})})]}),(0,l.jsxs)(`div`,{className:`row g-4 mb-4`,children:[(0,l.jsx)(`div`,{className:`col-lg-8`,children:(0,l.jsxs)(`div`,{className:`p-info-panel h-100 mb-0`,children:[(0,l.jsxs)(`div`,{className:`p-info-panel-head`,children:[(0,l.jsxs)(`h2`,{className:`fs-6 fw-bold mb-0 text-dark`,children:[(0,l.jsx)(`i`,{className:`bi bi-calendar2-range me-2 text-primary`}),`Academic Terms & Schedules`]}),(0,l.jsx)(`span`,{className:`badge bg-primary-subtle text-primary fw-bold`,children:`Active Year`})]}),(0,l.jsx)(`div`,{className:`p-4`,children:(0,l.jsx)(`div`,{className:`row g-3`,children:m?.terms&&m.terms.length>0?m.terms.map(e=>{let t=e.status===`active`||e.name===m.current_term;return(0,l.jsx)(`div`,{className:`col-12`,children:(0,l.jsxs)(`div`,{className:`p-term-card ${t?`active`:``}`,children:[(0,l.jsx)(`div`,{className:`d-flex justify-content-between align-items-center flex-wrap gap-2 mb-2`,children:(0,l.jsxs)(`div`,{className:`d-flex align-items-center gap-2`,children:[(0,l.jsx)(`span`,{className:`fw-bold fs-6 text-dark`,children:e.name}),t&&(0,l.jsx)(`span`,{className:`badge bg-success fw-bold px-2 py-1`,children:`Current Active Term`})]})}),(0,l.jsxs)(`div`,{className:`row g-2 text-muted small mt-1`,children:[(0,l.jsxs)(`div`,{className:`col-sm-6`,children:[(0,l.jsx)(`i`,{className:`bi bi-calendar-event me-1 text-primary`}),`Start Date: `,(0,l.jsx)(`strong`,{children:e.start_date||`Set by School`})]}),(0,l.jsxs)(`div`,{className:`col-sm-6`,children:[(0,l.jsx)(`i`,{className:`bi bi-calendar-check me-1 text-success`}),`Closing Date: `,(0,l.jsx)(`strong`,{children:e.end_date||`Set by School`})]})]})]})},e.id)}):(0,l.jsxs)(`div`,{className:`col-12 text-center py-4 text-muted`,children:[(0,l.jsx)(`i`,{className:`bi bi-calendar-x fs-1 d-block mb-2`}),`No term breakdown currently configured.`]})})})]})}),(0,l.jsx)(`div`,{className:`col-lg-4`,children:(0,l.jsxs)(`div`,{className:`p-info-panel h-100 mb-0`,children:[(0,l.jsx)(`div`,{className:`p-info-panel-head`,children:(0,l.jsxs)(`h2`,{className:`fs-6 fw-bold mb-0 text-dark`,children:[(0,l.jsx)(`i`,{className:`bi bi-building me-2 text-primary`}),`School Information`]})}),(0,l.jsxs)(`div`,{className:`p-4`,children:[(0,l.jsxs)(`div`,{className:`text-center mb-4`,children:[f?.logo?(0,l.jsx)(`img`,{src:f.logo,alt:`School Logo`,className:`rounded-circle mb-2`,style:{width:70,height:70,objectFit:`cover`}}):(0,l.jsx)(`div`,{className:`rounded-circle bg-primary-subtle text-primary d-inline-flex align-items-center justify-content-center mb-2`,style:{width:70,height:70},children:(0,l.jsx)(`i`,{className:`bi bi-mortarboard-fill fs-2`})}),(0,l.jsx)(`h5`,{className:`fw-bold text-dark mb-1`,children:f?.name||`School Campus`}),(0,l.jsx)(`p`,{className:`text-muted small fst-italic mb-0`,children:f?.motto||`Dedicated to academic excellence`})]}),(0,l.jsxs)(`div`,{className:`border-top pt-3`,children:[(0,l.jsxs)(`div`,{className:`d-flex align-items-start gap-2 mb-3`,children:[(0,l.jsx)(`i`,{className:`bi bi-geo-alt-fill text-danger mt-1`}),(0,l.jsxs)(`div`,{className:`small`,children:[(0,l.jsx)(`div`,{className:`text-muted`,children:`Campus Address`}),(0,l.jsx)(`div`,{className:`fw-semibold text-dark`,children:f?.address||`Main Campus`})]})]}),f?.phone&&(0,l.jsxs)(`div`,{className:`d-flex align-items-start gap-2 mb-3`,children:[(0,l.jsx)(`i`,{className:`bi bi-telephone-fill text-success mt-1`}),(0,l.jsxs)(`div`,{className:`small`,children:[(0,l.jsx)(`div`,{className:`text-muted`,children:`Administrative Helpline`}),(0,l.jsx)(`div`,{className:`fw-semibold text-dark`,children:f.phone})]})]}),f?.email&&(0,l.jsxs)(`div`,{className:`d-flex align-items-start gap-2 mb-3`,children:[(0,l.jsx)(`i`,{className:`bi bi-envelope-fill text-primary mt-1`}),(0,l.jsxs)(`div`,{className:`small`,children:[(0,l.jsx)(`div`,{className:`text-muted`,children:`Official Email`}),(0,l.jsx)(`div`,{className:`fw-semibold text-dark`,children:f.email})]})]})]})]})]})})]}),(0,l.jsx)(s,{})]})]})})]})}export{u as default};