import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{b as t,p as n,x as r}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as i,E as a,P as o,d as s,f as c,u as l}from"./index-D6TxbaCx.js";var u=e(),d=n(),f=()=>{let e=new Date().getHours();return e<12?`Good morning`:e<17?`Good afternoon`:`Good evening`};function p(){let e=r(),n=t(),[p,m]=(0,u.useState)(!1),[h,g]=(0,u.useState)(!0),[_,v]=(0,u.useState)([]),[y,b]=(0,u.useState)(null),[x,S]=(0,u.useState)([]),[C,w]=(0,u.useState)(0),T=new URLSearchParams(n.search),E=T.get(`student_id`)||T.get(`child_id`),D=async e=>{try{g(!0);let t=e?`/parent/child-results?student_id=${e}`:`/parent/child-results`,n=(await o.get(t)).data;v(n.children||[]),n.selected_child?b(n.selected_child.id):n.children&&n.children.length>0&&!y&&b(n.children[0].id),S(n.results||[]),w(0)}catch(e){console.error(`Failed to load child results`,e)}finally{g(!1)}};(0,u.useEffect)(()=>{D(E?Number(E):void 0)},[n.search]);let O=t=>{b(t),e(`/parent/results?student_id=${t}`,{replace:!0}),D(t)},k=_.find(e=>e.id===y),A=x[C]||null,j=e=>{if(!e)return(0,d.jsx)(`span`,{className:`badge bg-secondary`,children:`—`});let t=e.toUpperCase();return t.startsWith(`A`)?(0,d.jsx)(`span`,{className:`badge bg-success-subtle text-success fw-bold px-2 py-1`,children:e}):t.startsWith(`B`)?(0,d.jsx)(`span`,{className:`badge bg-primary-subtle text-primary fw-bold px-2 py-1`,children:e}):t.startsWith(`C`)?(0,d.jsx)(`span`,{className:`badge bg-info-subtle text-info fw-bold px-2 py-1`,children:e}):t.startsWith(`D`)||t.startsWith(`E`)?(0,d.jsx)(`span`,{className:`badge bg-warning-subtle text-warning fw-bold px-2 py-1`,children:e}):(0,d.jsx)(`span`,{className:`badge bg-danger-subtle text-danger fw-bold px-2 py-1`,children:e})};return(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');

        .p-res-main {
          background: #F8FAFC;
          min-height: 100vh;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          padding: calc(66px + 24px) 28px 40px !important;
        }

        @media (max-width: 767.98px) {
          .p-res-main {
            padding: calc(66px + 16px) 14px 36px !important;
          }
        }

        .p-res-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 18px;
          padding: 32px 36px;
          color: #FFFFFF;
          margin-bottom: 24px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
          position: relative;
          overflow: hidden;
        }

        @media (max-width: 767.98px) {
          .p-res-hero {
            padding: 20px 18px !important;
            border-radius: 14px !important;
            margin-bottom: 16px !important;
          }
        }

        .p-res-hero::before {
          content: '';
          position: absolute;
          inset: 0;
          background-image:
            linear-gradient(rgba(255, 255, 255, 0.035) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255, 255, 255, 0.035) 1px, transparent 1px);
          background-size: 32px 32px;
          pointer-events: none;
        }

        .p-res-hero-glow {
          position: absolute;
          top: -40px;
          right: -40px;
          width: 320px;
          height: 320px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.2) 0%, transparent 65%);
          pointer-events: none;
        }

        .p-res-hero-inner {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: center;
          justify-content: space-between;
          flex-wrap: wrap;
          gap: 20px;
        }

        .p-res-badge {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.20);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius: 100px;
          padding: 4px 12px;
          margin-bottom: 12px;
        }

        .p-res-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #10B981;
          box-shadow: 0 0 6px #10B981;
        }

        .p-res-title {
          font-size: 26px;
          font-weight: 800;
          color: #FFFFFF;
          line-height: 1.1;
          margin-bottom: 8px;
        }

        .p-res-title em {
          font-style: normal;
          color: #FBBF24;
        }

        .p-res-sub {
          font-size: 13.5px;
          color: #CBD5E1;
          line-height: 1.6;
          max-width: 620px;
          margin-bottom: 0;
        }

        @media (max-width: 767.98px) {
          .p-res-title {
            font-size: 20px !important;
          }
          .p-res-sub {
            font-size: 12.5px !important;
          }
        }

        /* Child Selector Pills */
        .p-child-pill {
          display: inline-flex;
          align-items: center;
          gap: 10px;
          padding: 8px 16px;
          border-radius: 12px;
          background: #FFFFFF;
          border: 1.5px solid #E2E8F0;
          color: #475569;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .p-child-pill:hover {
          background: #F1F5F9;
          border-color: #CBD5E1;
          transform: translateY(-1px);
        }

        .p-child-pill.active {
          background: #0A192F;
          border-color: #0A192F;
          color: #FFFFFF;
          box-shadow: 0 4px 14px rgba(10, 25, 47, 0.25);
        }

        .p-child-avatar {
          width: 32px;
          height: 32px;
          border-radius: 50%;
          background: #E2E8F0;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: 700;
          font-size: 12px;
          color: #0F2744;
          overflow: hidden;
        }

        /* Panels */
        .p-res-panel {
          background: #FFFFFF;
          border: 1px solid rgba(15, 39, 68, 0.08);
          border-radius: 18px;
          box-shadow: 0 4px 20px rgba(15, 39, 68, 0.06);
          overflow: hidden;
          margin-bottom: 24px;
        }

        .p-res-panel-head {
          padding: 18px 24px;
          border-bottom: 1px solid #E2E8F0;
          display: flex;
          align-items: center;
          justify-content: space-between;
          flex-wrap: wrap;
          gap: 12px;
        }

        /* Stat Card */
        .p-stat-card {
          background: #FFFFFF;
          border: 1px solid rgba(15, 39, 68, 0.08);
          border-radius: 16px;
          padding: 20px;
          box-shadow: 0 2px 8px rgba(15, 39, 68, 0.04);
        }

        .p-res-table {
          width: 100%;
          border-collapse: collapse;
        }

        .p-res-table th {
          background: #F8FAFC;
          color: #64748B;
          font-size: 11.5px;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.04em;
          padding: 12px 18px;
          border-bottom: 1px solid #E2E8F0;
        }

        .p-res-table td {
          padding: 14px 18px;
          border-bottom: 1px solid #F1F5F9;
          font-size: 13.5px;
          color: #1E293B;
          vertical-align: middle;
        }

        .p-res-table tr:hover td {
          background: #F8FAFC;
        }
      `}),(0,d.jsx)(c,{sidebarOpen:p,setSidebarOpen:m}),(0,d.jsx)(i,{title:`Academic Results & Broadsheet - SchoolProfit`}),(0,d.jsx)(`div`,{className:`container-fluid`,children:(0,d.jsxs)(`div`,{className:`row`,children:[(0,d.jsx)(s,{sidebarOpen:p,setSidebarOpen:m}),(0,d.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto gq-app-main p-res-main d-flex flex-column min-vh-100`,children:[h&&(0,d.jsx)(a,{message:`Loading academic results...`}),(0,d.jsxs)(`div`,{className:`p-res-hero`,children:[(0,d.jsx)(`div`,{className:`p-res-hero-glow`}),(0,d.jsxs)(`div`,{className:`p-res-hero-inner`,children:[(0,d.jsxs)(`div`,{children:[(0,d.jsxs)(`div`,{className:`p-res-badge`,children:[(0,d.jsx)(`span`,{className:`p-res-dot`}),`Parent Portal · Academic Broadsheet & Results`]}),(0,d.jsxs)(`h1`,{className:`p-res-title`,children:[f(),`, `,(0,d.jsx)(`em`,{children:`Academic Records`})]}),(0,d.jsx)(`p`,{className:`p-res-sub`,children:`View official continuous assessments, examination scores, class positions, teacher remarks, and full term report cards.`})]}),(0,d.jsx)(`div`,{className:`d-flex gap-2`,children:(0,d.jsxs)(`button`,{type:`button`,className:`btn btn-outline-light rounded-pill px-4`,onClick:()=>e(`/parent/children`),children:[(0,d.jsx)(`i`,{className:`bi bi-arrow-left me-1`}),`All Children`]})})]})]}),_.length>0&&(0,d.jsxs)(`div`,{className:`mb-4`,children:[(0,d.jsx)(`div`,{className:`d-flex align-items-center justify-content-between mb-2`,children:(0,d.jsx)(`span`,{className:`fw-bold small text-uppercase text-muted`,style:{letterSpacing:`0.05em`},children:`Select Ward / Child`})}),(0,d.jsx)(`div`,{className:`d-flex flex-wrap gap-2`,children:_.map(e=>{let t=e.id===y,n=`${e.surname?.[0]||``}${e.firstname?.[0]||``}`.toUpperCase();return(0,d.jsxs)(`button`,{type:`button`,className:`p-child-pill ${t?`active`:``}`,onClick:()=>O(e.id),children:[(0,d.jsxs)(`div`,{className:`p-child-avatar`,children:[e.photo?(0,d.jsx)(`img`,{src:e.photo,alt:e.firstname,className:`w-100 h-100 object-fit-cover`,onError:e=>{e.target.style.display=`none`}}):null,(0,d.jsx)(`span`,{children:n})]}),(0,d.jsxs)(`div`,{className:`text-start`,children:[(0,d.jsxs)(`div`,{className:`fw-bold`,children:[e.surname,` `,e.firstname]}),(0,d.jsxs)(`div`,{className:`small text-muted`,style:{fontSize:`11.5px`},children:[e.class_name||`Assigned Class`,` · `,e.reg_no]})]})]},e.id)})})]}),x.length===0?(0,d.jsxs)(`div`,{className:`card border-0 shadow-sm rounded-4 p-5 text-center my-4 bg-white`,children:[(0,d.jsx)(`i`,{className:`bi bi-journal-x text-secondary fs-1 mb-3`}),(0,d.jsx)(`h5`,{className:`fw-bold text-dark mb-1`,children:`No Published Results Found`}),(0,d.jsxs)(`p`,{className:`text-muted small mb-0`,children:[`There are no published term results or broadsheets available yet for `,k?`${k.surname} ${k.firstname}`:`this student`,`. Results will be accessible once released by the school administration.`]})]}):(0,d.jsxs)(d.Fragment,{children:[(0,d.jsxs)(`div`,{className:`d-flex align-items-center gap-2 mb-4 overflow-x-auto pb-2`,children:[(0,d.jsx)(`span`,{className:`small fw-bold text-muted text-uppercase me-2`,children:`Terms Available:`}),x.map((e,t)=>(0,d.jsxs)(`button`,{type:`button`,className:`btn btn-sm rounded-pill px-3 fw-bold ${C===t?`btn-dark`:`btn-outline-secondary`}`,onClick:()=>w(t),children:[(0,d.jsx)(`i`,{className:`bi bi-award-fill me-1 text-warning`}),e.session,` · `,e.term]},t))]}),A&&(0,d.jsxs)(`div`,{className:`row g-3 mb-4`,children:[(0,d.jsx)(`div`,{className:`col-sm-6 col-xl-3`,children:(0,d.jsxs)(`div`,{className:`p-stat-card border-start border-primary border-4`,children:[(0,d.jsx)(`div`,{className:`small fw-bold text-uppercase text-muted mb-1`,children:`Term Average`}),(0,d.jsxs)(`div`,{className:`fs-3 fw-bold text-primary`,children:[A.average_score,`%`]}),(0,d.jsx)(`div`,{className:`small text-muted`,children:A.class_name||`Enrolled Class`})]})}),(0,d.jsx)(`div`,{className:`col-sm-6 col-xl-3`,children:(0,d.jsxs)(`div`,{className:`p-stat-card border-start border-warning border-4`,children:[(0,d.jsx)(`div`,{className:`small fw-bold text-uppercase text-muted mb-1`,children:`Class Position`}),(0,d.jsxs)(`div`,{className:`fs-3 fw-bold text-dark`,children:[A.position||`—`,` `,(0,d.jsxs)(`span`,{className:`fs-6 fw-normal text-muted`,children:[`/ `,A.total_students||`—`]})]}),(0,d.jsx)(`div`,{className:`small text-muted`,children:`Class ranking for this term`})]})}),(0,d.jsx)(`div`,{className:`col-sm-6 col-xl-3`,children:(0,d.jsxs)(`div`,{className:`p-stat-card border-start border-success border-4`,children:[(0,d.jsx)(`div`,{className:`small fw-bold text-uppercase text-muted mb-1`,children:`Subjects Graded`}),(0,d.jsxs)(`div`,{className:`fs-3 fw-bold text-success`,children:[A.subjects_count,` Subjects`]}),(0,d.jsx)(`div`,{className:`small text-muted`,children:`Total curriculum courses`})]})}),(0,d.jsx)(`div`,{className:`col-sm-6 col-xl-3`,children:(0,d.jsxs)(`div`,{className:`p-stat-card border-start border-info border-4`,children:[(0,d.jsx)(`div`,{className:`small fw-bold text-uppercase text-muted mb-1`,children:`Session & Term`}),(0,d.jsx)(`div`,{className:`fs-5 fw-bold text-dark`,children:A.term}),(0,d.jsxs)(`div`,{className:`small text-muted`,children:[A.session,` Academic Year`]})]})})]}),A&&(0,d.jsxs)(`div`,{className:`p-res-panel`,children:[(0,d.jsxs)(`div`,{className:`p-res-panel-head`,children:[(0,d.jsxs)(`div`,{children:[(0,d.jsxs)(`h2`,{className:`fs-6 fw-bold mb-0 text-dark`,children:[(0,d.jsx)(`i`,{className:`bi bi-table me-2 text-primary`}),`Subject Breakdown — `,A.term,` (`,A.session,`)`]}),(0,d.jsx)(`small`,{className:`text-muted`,children:`Comprehensive subject assessment & exam scores`})]}),(0,d.jsx)(`div`,{className:`d-flex gap-2`,children:(0,d.jsxs)(`button`,{type:`button`,className:`btn btn-sm btn-primary rounded-pill px-3 fw-bold`,onClick:()=>window.print(),children:[(0,d.jsx)(`i`,{className:`bi bi-printer-fill me-1`}),`Print Result Sheet`]})})]}),(0,d.jsx)(`div`,{className:`table-responsive`,children:(0,d.jsxs)(`table`,{className:`p-res-table`,children:[(0,d.jsx)(`thead`,{children:(0,d.jsxs)(`tr`,{children:[(0,d.jsx)(`th`,{children:`#`}),(0,d.jsx)(`th`,{children:`Subject Name`}),(0,d.jsx)(`th`,{children:`CA Score`}),(0,d.jsx)(`th`,{children:`Exam Score`}),(0,d.jsx)(`th`,{children:`Total (100%)`}),(0,d.jsx)(`th`,{children:`Grade`}),(0,d.jsx)(`th`,{children:`Teacher Remark`})]})}),(0,d.jsx)(`tbody`,{children:A.subjects.map((e,t)=>{let n=e.ca_total??(typeof e.ca==`object`?Object.values(e.ca||{}).reduce((e,t)=>Number(e||0)+Number(t||0),0):e.ca),r=e.exam_score??e.exam??`—`,i=e.total_score??e.total??`—`;return(0,d.jsxs)(`tr`,{children:[(0,d.jsx)(`td`,{className:`text-muted small`,children:t+1}),(0,d.jsx)(`td`,{className:`fw-bold`,children:e.subject_name}),(0,d.jsx)(`td`,{children:n??`—`}),(0,d.jsx)(`td`,{children:r}),(0,d.jsx)(`td`,{className:`fw-bold fs-6`,style:{color:`#0F2744`},children:i}),(0,d.jsx)(`td`,{children:j(e.grade)}),(0,d.jsx)(`td`,{className:`small text-muted`,children:e.remark||`Satisfactory progress`})]},e.id||t)})})]})}),(A.class_teacher_comment||A.principal_comment)&&(0,d.jsx)(`div`,{className:`p-4 bg-light border-top`,children:(0,d.jsxs)(`div`,{className:`row g-3`,children:[A.class_teacher_comment&&(0,d.jsx)(`div`,{className:`col-md-6`,children:(0,d.jsxs)(`div`,{className:`p-3 bg-white rounded-3 border`,children:[(0,d.jsxs)(`div`,{className:`small fw-bold text-muted text-uppercase mb-1`,children:[(0,d.jsx)(`i`,{className:`bi bi-chat-quote-fill me-1 text-primary`}),`Class Teacher's Remark`]}),(0,d.jsxs)(`div`,{className:`text-dark small fst-italic`,children:[`"`,A.class_teacher_comment,`"`]})]})}),A.principal_comment&&(0,d.jsx)(`div`,{className:`col-md-6`,children:(0,d.jsxs)(`div`,{className:`p-3 bg-white rounded-3 border`,children:[(0,d.jsxs)(`div`,{className:`small fw-bold text-muted text-uppercase mb-1`,children:[(0,d.jsx)(`i`,{className:`bi bi-patch-check-fill me-1 text-success`}),`Principal's Comment`]}),(0,d.jsxs)(`div`,{className:`text-dark small fst-italic`,children:[`"`,A.principal_comment,`"`]})]})})]})})]})]}),(0,d.jsx)(l,{})]})]})})]})}export{p as default};