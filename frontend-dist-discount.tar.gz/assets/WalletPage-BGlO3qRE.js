import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{p as t}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as n,E as r,P as i,d as a,f as o,l as s,u as c}from"./index-D6TxbaCx.js";var l=e(),u=t();function d(e){try{return new Intl.NumberFormat(`en-NG`,{style:`currency`,currency:`NGN`}).format(e)}catch{return`₦${Number(e||0).toLocaleString()}`}}function f(e){if(!e)return`—`;let t=new Date(e);return Number.isNaN(t.getTime())?e:t.toLocaleDateString(`en-GB`,{day:`2-digit`,month:`short`,year:`numeric`})}function p(e){let t=(e||``).toLowerCase();return t===`credit`?{bg:`rgba(34,197,94,0.14)`,fg:`#22c55e`,text:`CREDIT`}:t===`debit`?{bg:`rgba(239,68,68,0.14)`,fg:`#ef4444`,text:`DEBIT`}:{bg:`rgba(148,163,184,0.14)`,fg:`#94a3b8`,text:(e||`OTHER`).toUpperCase()}}function m(e,t,n){return Math.min(Math.max(e,t),n)}function h(){let{showError:e,showSuccess:t}=s(),[h,g]=(0,l.useState)(!1),[_,v]=(0,l.useState)(!0),[y,b]=(0,l.useState)(0),[x,S]=(0,l.useState)(null),[C,w]=(0,l.useState)(5e3),[T,E]=(0,l.useState)(!1),[D,O]=(0,l.useState)(!1),[k,A]=(0,l.useState)(``),[j,M]=(0,l.useState)([]),[N,P]=(0,l.useState)(1),[F,I]=(0,l.useState)(10),[L,R]=(0,l.useState)(0),[z,B]=(0,l.useState)(1),V=(0,l.useMemo)(()=>Number(C||0)>=100,[C]),H=async()=>{let e=await i.get(`/user/wallet`);b(Number(e.data?.balance??0))},U=async()=>{S((await i.get(`/product/student-slot`)).data)},W=async(t=N,n=F)=>{O(!0);try{let e=(await i.get(`/user/transactions`,{params:{page:t,perPage:n}})).data.transactions;M(e.data||[]),P(e.current_page||t),I(e.per_page||n),R(e.total||0),B(e.last_page||1)}catch(t){console.error(t),e?.(t?.response?.data?.message||`Failed to load wallet transactions.`)}finally{O(!1)}};(0,l.useEffect)(()=>{async function n(){v(!0);try{let n=new URLSearchParams(window.location.search),r=n.get(`reference`)||n.get(`trxref`);if(r)try{let e=await i.get(`/verify-payment/${encodeURIComponent(r)}`);(e.data?.status===`success`||e.data?.message)&&t?.(e.data?.message||`Payment verified and wallet credited!`)}catch(t){console.error(`Verification error:`,t),e?.(t?.response?.data?.message||`Could not verify transaction with Paystack.`)}finally{let e=window.location.pathname;window.history.replaceState({},document.title,e)}await Promise.all([H(),U(),W(1,F)])}catch(t){console.error(t),e?.(t?.response?.data?.message||`Failed to load wallet page.`)}finally{v(!1)}}n()},[]);let G=(0,l.useMemo)(()=>{let e=k.trim().toLowerCase();return e?j.filter(t=>(t.reference_id||``).toLowerCase().includes(e)||(t.description||``).toLowerCase().includes(e)||(t.type||``).toLowerCase().includes(e)):j},[j,k]),K=async()=>{if(!V)return e?.(`Minimum top-up is ${d(100)}.`);E(!0);try{let e=window.location.origin+`/wallet`,t=(await i.post(`/initialize-payment`,{amount:C,callback_url:e})).data?.authorization_url;if(!t)throw Error(`Authorization URL not returned.`);window.location.href=t}catch(t){console.error(t),e?.(t?.response?.data?.error||t?.response?.data?.message||`Failed to initialize payment.`)}finally{E(!1)}},q=m(N,1,z),J=(0,l.useMemo)(()=>{let e=Math.max(1,q-2),t=Math.min(z,q+2),n=[];for(let r=e;r<=t;r++)n.push(r);return n},[q,z]),Y=(0,l.useMemo)(()=>j.reduce((e,t)=>e+((t.type||``).toLowerCase()===`credit`?Number(t.amount||0):0),0),[j]),X=(0,l.useMemo)(()=>j.reduce((e,t)=>e+((t.type||``).toLowerCase()===`debit`?Number(t.amount||0):0),0),[j]);return(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');
        .db-main {
          background: #F8FAFC;
          min-height: 100vh;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          padding: 24px 28px 0;
        }
        .db-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 18px;
          padding: 32px 36px;
          position: relative;
          overflow: hidden;
          margin-bottom: 24px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
        }
        .db-hero-glow {
          position: absolute; top: -60px; right: -60px; width: 320px; height: 320px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.15) 0%, transparent 65%);
          pointer-events: none;
        }
        .db-hero-glow2 {
          position: absolute; bottom: -40px; left: 30%; width: 200px; height: 200px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(37, 99, 235, 0.10) 0%, transparent 70%);
          pointer-events: none;
        }
        .db-hero-inner {
          position: relative; z-index: 1;
          display: flex; align-items: center; justify-content: space-between;
          gap: 32px; flex-wrap: wrap;
        }
        @media (min-width: 768px) { .db-hero-inner { flex-wrap: nowrap; } }

        .db-session-badge {
          display: inline-flex; align-items: center; gap: 7px;
          font-size: 11.5px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase;
          color: #FBBF24; background: rgba(217, 119, 6, 0.20);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius: 100px; padding: 4px 12px; margin-bottom: 12px;
        }
        .db-session-dot {
          width: 6px; height: 6px; border-radius: 50%; background: #10B981;
          animation: dbPulse 2s ease infinite;
        }
        @keyframes dbPulse {
          0%,100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.4; transform: scale(1.5); }
        }
        .db-greeting {
          font-size: 26px; font-weight: 800; color: #fff;
          line-height: 1.1; margin-bottom: 8px;
        }
        .db-greeting em { font-style: normal; color: #FBBF24; }
        .db-hero-sub {
          font-size: 13.5px; color: #CBD5E1;
          line-height: 1.6; max-width: 560px; margin-bottom: 18px;
        }
        .db-hero-btns { display: flex; gap: 10px; flex-wrap: wrap; }
        .db-btn-gold {
          display: inline-flex; align-items: center; gap: 8px;
          padding: 9px 18px; font-size: 13px; font-weight: 700; color: #FFFFFF;
          background: #D97706; border: none;
          border-radius: 10px;
          cursor: pointer; transition: all 0.2s ease; white-space: nowrap;
        }
        .db-btn-gold:hover { background: #B45309; transform: translateY(-1px); color: #FFFFFF; }
        .db-btn-gold:disabled { opacity: 0.55; cursor: not-allowed; transform: none; }
        .db-btn-outline {
          display: inline-flex; align-items: center; gap: 8px;
          padding: 9px 18px; font-size: 13px; font-weight: 600; color: #FFFFFF;
          background: rgba(255,255,255,0.10); border: 1px solid rgba(255,255,255,0.20);
          border-radius: 10px;
          cursor: pointer; transition: all 0.2s ease; white-space: nowrap;
        }
        .db-btn-outline:hover { background: rgba(255,255,255,0.18); color: #fff; }
        .db-btn-outline:disabled { opacity: 0.55; cursor: not-allowed; }
        .db-hero-stat-card {
          background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.15);
          backdrop-filter: blur(8px); border-radius: 14px;
          padding: 18px 20px; min-width: 270px; margin-left: auto; align-self: flex-end;
        }
        .db-hero-stat-row { display: flex; flex-direction: column; gap: 10px; }
        .db-hero-stat-item { display: flex; justify-content: space-between; align-items: center; gap: 16px; }
        .db-hero-stat-label { font-size: 12px; font-weight: 400; color: #CBD5E1; }
        .db-hero-stat-val { font-size: 18px; font-weight: 800; color: #FBBF24; }
        .db-hero-stat-sep { height: 1px; background: rgba(255,255,255,0.08); }
        .db-panel {
          background: #fff;
          border: 1px solid #E2E8F0;
          border-radius: 16px;
          overflow: hidden; box-shadow: 0 4px 16px rgba(15,39,68,0.03); margin-bottom: 20px;
        }
        .db-panel-head {
          display: flex; align-items: center; justify-content: space-between;
          padding: 18px 20px; border-bottom: 1px solid #E2E8F0; gap: 12px; flex-wrap: wrap;
        }
        .db-panel-title { font-size: 16px; font-weight: 800; color: #0F2744; margin: 0; }
        .db-panel-sub { font-size: 12px; color: #64748B; margin: 0; }
        .db-refresh-btn {
          display: inline-flex; align-items: center; gap: 6px;
          padding: 8px 14px; font-size: 12.5px; font-weight: 600; color: #0F2744;
          background: #F1F5F9; border: 1px solid #E2E8F0;
          border-radius: 8px;
          cursor: pointer; transition: all 0.2s ease; white-space: nowrap;
        }
        .db-refresh-btn:hover { background: #E2E8F0; }
        .db-refresh-btn:disabled { opacity: 0.5; cursor: not-allowed; }
        .db-pill {
          display: inline-flex; align-items: center;
          font-size: 11.5px; font-weight: 700; padding: 5px 10px;
          border-radius: 999px; white-space: nowrap; border: 1px solid rgba(0,0,0,0.06);
        }
        .db-search {
          display: flex; align-items: center; gap: 10px;
          background: #fff; border: 1px solid #E2E8F0;
          border-radius: 10px; padding: 10px 14px; min-width: 260px;
        }
        .db-search input { border: none; outline: none; width: 100%; font-size: 13px; color: #0F2744; }
        .db-table { width: 100%; border-collapse: separate; border-spacing: 0; }
        .db-table th {
          padding: 12px 16px; font-size: 11.5px; font-weight: 700; letter-spacing: 0.04em;
          text-transform: uppercase; color: #64748B; background: #F8FAFC;
          border-bottom: 1px solid #E2E8F0; text-align: left; white-space: nowrap;
        }
        .db-table td {
          padding: 14px 16px; font-size: 13px; color: #334155;
          border-bottom: 1px solid #E2E8F0; vertical-align: middle;
        }
        .db-table tbody tr:last-child td { border-bottom: none; }
        .db-table tbody tr:hover { background: #F8FAFC; }
        .db-muted { color: #64748B; }
        .db-strong { font-weight: 700; color: #0F2744; }

        /* ── qty input stepper ── */
        .wlt-qty-wrap {
          display: flex; align-items: center; gap: 0;
          border: 1px solid #E2E8F0; border-radius: 10px; overflow: hidden;
          background: #fff; width: fit-content;
        }
        .wlt-qty-btn {
          width: 44px; height: 46px; border: none; background: #F1F5F9;
          color: #0F2744; font-size: 20px; font-weight: 600; cursor: pointer;
          display: flex; align-items: center; justify-content: center;
          transition: all 0.15s ease; flex-shrink: 0; line-height: 1;
        }
        .wlt-qty-btn:hover { background: #E2E8F0; color: #0F2744; }
        .wlt-qty-btn:disabled { opacity: 0.35; cursor: not-allowed; }
        .wlt-qty-input {
          width: 90px; height: 46px; border: none; outline: none;
          text-align: center; font-size: 16px; font-weight: 700; color: #0F2744;
          font-family: 'Plus Jakarta Sans', system-ui, sans-serif; background: #fff;
        }
        /* hide native number arrows */
        .wlt-qty-input::-webkit-inner-spin-button,
        .wlt-qty-input::-webkit-outer-spin-button { -webkit-appearance: none; margin: 0; }
        .wlt-qty-input[type=number] { -moz-appearance: textfield; }

        /* ── qty input stepper ── */
        .wlt-qty-wrap {
          display: flex; align-items: center; gap: 0;
          border: 1px solid #e5ddd3; border-radius: 10px; overflow: hidden;
          background: #fff; width: fit-content;
        }
        .wlt-qty-btn {
          width: 44px; height: 46px; border: none; background: #f5f1eb;
          color: #7a6a5a; font-size: 20px; font-weight: 300; cursor: pointer;
          display: flex; align-items: center; justify-content: center;
          transition: background 0.15s, color 0.15s; flex-shrink: 0; line-height: 1;
        }
        .wlt-qty-btn:hover { background: #ede8e0; color: #1a1a2e; }
        .wlt-qty-btn:disabled { opacity: 0.35; cursor: not-allowed; }
        .wlt-qty-input {
          width: 90px; height: 46px; border: none; outline: none;
          text-align: center; font-size: 16px; font-weight: 700; color: #1a1a2e;
          font-family: "DM Sans", sans-serif; background: #fff;
        }
        /* hide native number arrows */
        .wlt-qty-input::-webkit-inner-spin-button,
        .wlt-qty-input::-webkit-outer-spin-button { -webkit-appearance: none; margin: 0; }
        .wlt-qty-input[type=number] { -moz-appearance: textfield; }

        /* ── cost preview card ── */
        .wlt-cost-card {
          background: linear-gradient(135deg, rgba(201,168,76,0.08) 0%, rgba(201,168,76,0.03) 100%);
          border: 1px solid rgba(201,168,76,0.22); border-radius: 12px; padding: 16px 20px;
        }
        .wlt-cost-label { font-size: 12px; color: #9a8a7a; margin: 0 0 4px; }
        .wlt-cost-val { font-family: "Lora", serif; font-size: 28px; font-weight: 700; color: #1a1a2e; margin: 0; line-height: 1; }
        .wlt-cost-sub { font-size: 12px; color: #9a8a7a; margin: 6px 0 0; }

        /* ── min-topup notice ── */
        .wlt-min-notice {
          display: flex; align-items: center; gap: 8px;
          padding: 10px 14px; border-radius: 9px; font-size: 12.5px; line-height: 1.5;
        }
        .wlt-min-notice--warn {
          background: rgba(239,68,68,0.05); border: 1px solid rgba(239,68,68,0.16); color: #dc2626;
        }
        .wlt-min-notice--ok {
          background: rgba(34,197,94,0.05); border: 1px solid rgba(34,197,94,0.18); color: #16a34a;
        }

        @media (max-width: 991.98px) { .db-main { padding: 18px 14px 0; } }
      `}),(0,u.jsx)(o,{sidebarOpen:h,setSidebarOpen:g}),(0,u.jsx)(n,{title:`My Wallet`}),(0,u.jsx)(`div`,{className:`container-fluid`,children:(0,u.jsxs)(`div`,{className:`row`,children:[(0,u.jsx)(a,{sidebarOpen:h}),(0,u.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto db-main`,children:[_&&(0,u.jsx)(r,{message:`Loading wallet...`}),(0,u.jsxs)(`div`,{className:`db-hero`,children:[(0,u.jsx)(`div`,{className:`db-hero-glow`,"aria-hidden":`true`}),(0,u.jsx)(`div`,{className:`db-hero-glow2`,"aria-hidden":`true`}),(0,u.jsxs)(`div`,{className:`db-hero-inner`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsxs)(`div`,{className:`db-session-badge`,children:[(0,u.jsx)(`span`,{className:`db-session-dot`}),`Wallet — Top up & Transactions`]}),(0,u.jsxs)(`h1`,{className:`db-greeting`,children:[`Wallet `,(0,u.jsx)(`em`,{children:`&`}),` Balance`]}),(0,u.jsxs)(`p`,{className:`db-hero-sub`,children:[`Top up your wallet and monitor all credits and debits in one place. Minimum top-up is `,d(100),`.`]}),(0,u.jsxs)(`div`,{className:`db-hero-btns`,children:[(0,u.jsx)(`button`,{className:`db-btn-gold`,disabled:T||!V,onClick:K,title:V?`Make Payment`:`Minimum top-up is ${d(100)}`,children:T?(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`span`,{className:`spinner-border spinner-border-sm`}),` Initializing…`]}):(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`i`,{className:`bi bi-shield-lock-fill`}),` Make Payment`]})}),(0,u.jsxs)(`button`,{className:`db-btn-outline`,disabled:_,onClick:async()=>{try{await H(),t?.(`Wallet balance refreshed.`)}catch{}},children:[(0,u.jsx)(`i`,{className:`bi bi-arrow-clockwise`}),` Refresh Balance`]}),(0,u.jsxs)(`button`,{className:`db-btn-outline`,disabled:D,onClick:()=>W(1,F),children:[(0,u.jsx)(`i`,{className:`bi bi-arrow-clockwise`}),` Refresh Transactions`]})]})]}),(0,u.jsxs)(`div`,{className:`db-hero-stat-card d-none d-md-block`,children:[(0,u.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,marginBottom:16},children:[(0,u.jsx)(`span`,{style:{fontSize:11,fontWeight:500,letterSpacing:`0.14em`,textTransform:`uppercase`,color:`#c9a84c`},children:`Quick glance`}),(0,u.jsx)(`i`,{className:`bi bi-wallet2`,style:{color:`#64748b`}})]}),(0,u.jsxs)(`div`,{className:`db-hero-stat-row`,children:[(0,u.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,u.jsx)(`span`,{className:`db-hero-stat-label`,children:`Available Balance`}),(0,u.jsx)(`span`,{className:`db-hero-stat-val`,children:d(y)})]}),(0,u.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,u.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,u.jsx)(`span`,{className:`db-hero-stat-label`,children:`Min. Top-up`}),(0,u.jsx)(`span`,{className:`db-hero-stat-val`,style:{fontSize:14},children:d(100)})]}),(0,u.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,u.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,u.jsx)(`span`,{className:`db-hero-stat-label`,children:`Usage Float`}),(0,u.jsx)(`span`,{className:`db-hero-stat-val`,style:{fontSize:13,color:`#34D399`},children:`All Services Active`})]})]})]})]})]}),(0,u.jsx)(`div`,{className:`row g-3 mt-1 mb-3`,children:[{title:`Wallet Balance`,value:d(y),icon:`cash-coin`,toneBg:`#dbeafe`,toneFg:`#1e40af`},{title:`Total Credits`,value:d(Y),icon:`arrow-down-circle`,toneBg:`#d1fae5`,toneFg:`#065f46`},{title:`Total Debits`,value:d(X),icon:`arrow-up-circle`,toneBg:`#ffe4e6`,toneFg:`#be123c`},{title:`Top-up Selection`,value:d(C),icon:`wallet2`,toneBg:`#fef3c7`,toneFg:`#b45309`}].map(e=>(0,u.jsx)(`div`,{className:`col-md-6 col-lg-3`,children:(0,u.jsxs)(`div`,{className:`db-panel`,style:{padding:16},children:[(0,u.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`},children:[(0,u.jsx)(`div`,{style:{width:44,height:44,borderRadius:12,background:e.toneBg,color:e.toneFg,display:`flex`,alignItems:`center`,justifyContent:`center`},children:(0,u.jsx)(`i`,{className:`bi bi-${e.icon}`,style:{fontSize:18}})}),(0,u.jsx)(`i`,{className:`bi bi-three-dots-vertical`,style:{color:`#c8bfb5`}})]}),(0,u.jsxs)(`div`,{style:{marginTop:12},children:[(0,u.jsx)(`div`,{className:`db-muted`,style:{fontSize:12},children:e.title}),(0,u.jsx)(`div`,{className:`db-strong`,style:{fontFamily:`Lora, serif`,fontSize:22,marginTop:2},children:e.value}),(0,u.jsx)(`div`,{style:{marginTop:12,paddingTop:10,borderTop:`1px solid rgba(0,0,0,0.06)`},children:(0,u.jsxs)(`span`,{className:`db-muted`,style:{fontSize:12},children:[(0,u.jsx)(`i`,{className:`bi bi-info-circle me-1`}),`Treasury Account`]})})]})]})},e.title))}),(0,u.jsxs)(`div`,{className:`db-panel`,children:[(0,u.jsxs)(`div`,{className:`db-panel-head`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`p`,{className:`db-panel-title`,children:`Fund School Wallet`}),(0,u.jsxs)(`p`,{className:`db-panel-sub`,children:[`Add money to your school wallet balance via Paystack (Debit Card, Bank Transfer, USSD). Minimum top-up is `,d(100),`.`]})]}),(0,u.jsxs)(`span`,{className:`db-pill`,style:{background:`rgba(217, 119, 6, 0.12)`,color:`#D97706`,fontWeight:700},children:[`Top-up: `,d(C)]})]}),(0,u.jsx)(`div`,{style:{padding:`20px 20px 24px`},children:(0,u.jsxs)(`div`,{className:`row g-4 align-items-start`,children:[(0,u.jsxs)(`div`,{className:`col-12 col-md-6`,children:[(0,u.jsx)(`label`,{style:{fontSize:13,fontWeight:700,color:`#0F2744`,display:`block`,marginBottom:8},children:`Select or Enter Amount (₦)`}),(0,u.jsx)(`div`,{className:`d-flex flex-wrap gap-2 mb-3`,children:[2e3,5e3,1e4,2e4,5e4,1e5].map(e=>(0,u.jsx)(`button`,{type:`button`,className:`btn`,onClick:()=>w(e),style:{borderRadius:`10px`,padding:`8px 14px`,fontSize:`13px`,fontWeight:700,border:C===e?`2px solid #D97706`:`1px solid #E2E8F0`,background:C===e?`#FEF3C7`:`#F8FAFC`,color:C===e?`#B45309`:`#334155`,transition:`all 0.2s ease`},children:d(e)},e))}),(0,u.jsxs)(`div`,{style:{position:`relative`},children:[(0,u.jsx)(`span`,{style:{position:`absolute`,left:14,top:12,fontWeight:700,color:`#64748B`,fontSize:16},children:`₦`}),(0,u.jsx)(`input`,{className:`form-control`,type:`number`,min:100,step:100,value:C,onChange:e=>{let t=parseFloat(e.target.value);w(Number.isNaN(t)?0:t)},style:{paddingLeft:34,height:48,borderRadius:10,fontSize:16,fontWeight:700,color:`#0F2744`,border:`1px solid #CBD5E1`,background:`#FFFFFF`},placeholder:`Enter custom amount in Naira`})]}),(0,u.jsx)(`div`,{className:`wlt-min-notice mt-3 ${V?`wlt-min-notice--ok`:`wlt-min-notice--warn`}`,children:V?(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`i`,{className:`bi bi-check-circle-fill text-success`}),(0,u.jsxs)(`span`,{children:[`Amount of `,(0,u.jsx)(`strong`,{children:d(C)}),` meets the minimum top-up requirement.`]})]}):(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`i`,{className:`bi bi-exclamation-triangle-fill text-danger`}),(0,u.jsxs)(`span`,{children:[`Minimum top-up is `,(0,u.jsx)(`strong`,{children:d(100)}),`. Current amount: `,d(C),`.`]})]})})]}),(0,u.jsxs)(`div`,{className:`col-12 col-md-6`,children:[(0,u.jsxs)(`div`,{className:`wlt-cost-card`,style:{marginBottom:16,padding:`18px 20px`,borderRadius:`14px`,background:`#F8FAFC`,border:`1px solid #E2E8F0`},children:[(0,u.jsx)(`p`,{className:`wlt-cost-label`,style:{fontSize:`12px`,color:`#64748B`,marginBottom:`4px`},children:`Total Amount to Pay`}),(0,u.jsx)(`p`,{className:`wlt-cost-val`,style:{fontSize:`28px`,fontWeight:800,color:`#0F2744`,marginBottom:`6px`},children:d(C)}),(0,u.jsxs)(`p`,{className:`wlt-cost-sub`,style:{fontSize:`12px`,color:`#64748B`,margin:0},children:[`Estimated wallet balance after funding: `,(0,u.jsx)(`strong`,{children:d(y+(V?C:0))})]})]}),(0,u.jsx)(`button`,{className:`db-btn-gold w-100 justify-content-center`,style:{padding:`13px 18px`,fontSize:`14.5px`,fontWeight:800,borderRadius:`12px`},disabled:T||!V,onClick:K,children:T?(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`span`,{className:`spinner-border spinner-border-sm me-2`}),` Initializing Payment…`]}):(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`i`,{className:`bi bi-shield-lock-fill me-2`}),` Make Payment (`,d(C),`)`]})}),(0,u.jsxs)(`div`,{className:`db-muted mt-2 text-center`,style:{fontSize:`12px`},children:[(0,u.jsx)(`i`,{className:`bi bi-shield-check me-1 text-success`}),`Multi-purpose treasury: Usable for Student Clearances, AI Credits, and WhatsApp Messaging.`]})]})]})})]}),(0,u.jsxs)(`div`,{className:`db-panel`,children:[(0,u.jsxs)(`div`,{className:`db-panel-head`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`p`,{className:`db-panel-title`,children:`Wallet transactions`}),(0,u.jsx)(`p`,{className:`db-panel-sub`,children:`All credits and debits. Search applies to the current page.`})]}),(0,u.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:10,flexWrap:`wrap`},children:[(0,u.jsxs)(`div`,{className:`db-search`,children:[(0,u.jsx)(`i`,{className:`bi bi-search`,style:{color:`#9a8a7a`}}),(0,u.jsx)(`input`,{placeholder:`Search reference or description…`,value:k,onChange:e=>A(e.target.value)})]}),(0,u.jsx)(`select`,{className:`form-select`,style:{width:140,borderRadius:12,borderColor:`#e5ddd3`},value:F,onChange:e=>{let t=Number(e.target.value);I(t),W(1,t)},children:[10,20,50].map(e=>(0,u.jsxs)(`option`,{value:e,children:[e,`/page`]},e))}),(0,u.jsxs)(`button`,{className:`db-refresh-btn`,disabled:D,onClick:()=>W(1,F),children:[(0,u.jsx)(`i`,{className:`bi bi-arrow-clockwise`}),` Refresh`]})]})]}),D&&(0,u.jsx)(`div`,{style:{padding:16},children:(0,u.jsx)(r,{message:`Loading transactions...`})}),(0,u.jsx)(`div`,{style:{overflowX:`auto`},children:(0,u.jsxs)(`table`,{className:`db-table`,children:[(0,u.jsx)(`thead`,{children:(0,u.jsxs)(`tr`,{children:[(0,u.jsx)(`th`,{children:`Date`}),(0,u.jsx)(`th`,{children:`Description`}),(0,u.jsx)(`th`,{children:`Reference`}),(0,u.jsx)(`th`,{children:`Type`}),(0,u.jsx)(`th`,{style:{textAlign:`right`},children:`Amount`})]})}),(0,u.jsx)(`tbody`,{children:G.length===0?(0,u.jsx)(`tr`,{children:(0,u.jsxs)(`td`,{colSpan:5,style:{padding:46,textAlign:`center`,color:`#b5a090`},children:[(0,u.jsx)(`div`,{style:{fontWeight:800,color:`#1a1a2e`},children:`No transactions found`}),(0,u.jsx)(`div`,{style:{fontSize:12.5,marginTop:4},children:`Try a different keyword or switch pages.`})]})}):G.map(e=>{let t=p(e.type);return(0,u.jsxs)(`tr`,{children:[(0,u.jsx)(`td`,{className:`db-muted`,children:f(e.created_at)}),(0,u.jsx)(`td`,{className:`db-strong`,style:{fontWeight:600},children:e.description||`—`}),(0,u.jsx)(`td`,{children:(0,u.jsx)(`code`,{style:{fontSize:12,color:`#1a1a2e`},children:e.reference_id||`—`})}),(0,u.jsx)(`td`,{children:(0,u.jsx)(`span`,{className:`db-pill`,style:{background:t.bg,color:t.fg},children:t.text})}),(0,u.jsx)(`td`,{style:{textAlign:`right`},className:`db-strong`,children:d(Number(e.amount||0))})]},e.id)})})]})}),(0,u.jsxs)(`div`,{style:{padding:16,display:`flex`,justifyContent:`space-between`,alignItems:`center`,gap:12,flexWrap:`wrap`},children:[(0,u.jsxs)(`div`,{className:`db-muted`,style:{fontSize:12.5},children:[`Page `,(0,u.jsx)(`b`,{children:q}),` of `,(0,u.jsx)(`b`,{children:z}),` · Total `,(0,u.jsx)(`b`,{children:L}),` record`,L===1?``:`s`]}),(0,u.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:8,flexWrap:`wrap`},children:[(0,u.jsxs)(`button`,{className:`db-refresh-btn`,disabled:q<=1||D,onClick:()=>W(q-1,F),children:[(0,u.jsx)(`i`,{className:`bi bi-chevron-left`}),` Prev`]}),q>3&&(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`button`,{className:`db-refresh-btn`,disabled:D,onClick:()=>W(1,F),children:`1`}),(0,u.jsx)(`span`,{className:`db-muted`,children:`…`})]}),J.map(e=>(0,u.jsx)(`button`,{className:`db-refresh-btn`,disabled:D,onClick:()=>W(e,F),style:{background:e===q?`#c9a84c`:void 0,color:e===q?`#0f172a`:void 0,borderColor:e===q?`#c9a84c`:void 0,fontWeight:e===q?800:400,minWidth:44,justifyContent:`center`},children:e},e)),q<z-2&&(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`span`,{className:`db-muted`,children:`…`}),(0,u.jsx)(`button`,{className:`db-refresh-btn`,disabled:D,onClick:()=>W(z,F),children:z})]}),(0,u.jsxs)(`button`,{className:`db-refresh-btn`,disabled:q>=z||D,onClick:()=>W(q+1,F),children:[`Next `,(0,u.jsx)(`i`,{className:`bi bi-chevron-right`})]})]})]}),(0,u.jsxs)(`div`,{style:{padding:`0 16px 16px`},className:`db-muted`,children:[(0,u.jsx)(`i`,{className:`bi bi-info-circle me-1`}),`If you paid and weren't credited, contact support with the transaction reference.`]})]}),(0,u.jsx)(`div`,{className:`mt-auto`,children:(0,u.jsx)(c,{})})]})]})})]})}export{h as default};