import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{b as t,p as n,x as r}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as i,F as a}from"./index-D6TxbaCx.js";var o=e(),s=n(),c=(e,t)=>a.post(e,t);function l(){let e=r(),n=t().state?.email;sessionStorage.getItem(`reset_email`);let[a,l]=(0,o.useState)(n),[u,d]=(0,o.useState)(`otp`),[f,p]=(0,o.useState)([``,``,``,``,``,``]),[m,h]=(0,o.useState)(!1),[g,_]=(0,o.useState)(``),v=(0,o.useRef)([]),[y,b]=(0,o.useState)(``),[x,S]=(0,o.useState)(``),[C,w]=(0,o.useState)(!1),[T,E]=(0,o.useState)(!1),[D,O]=(0,o.useState)(!1),[k,A]=(0,o.useState)(``),j=f.join(``),M=j.length===6,N=(()=>{if(!y)return 0;let e=0;return y.length>=8&&e++,/[A-Z]/.test(y)&&e++,/[0-9]/.test(y)&&e++,/[^A-Za-z0-9]/.test(y)&&e++,e})(),P=[``,`Weak`,`Fair`,`Good`,`Strong`][N],F=[``,`#ef4444`,`#f59e0b`,`#3b82f6`,`#22c55e`][N],I=x.length>0&&y===x,L=x.length>0&&y!==x?`Passwords do not match.`:``,R=y.length>=8&&I;(0,o.useEffect)(()=>{v.current[0]?.focus()},[]);let z=(e,t)=>{let n=e?.response?.data;if(n?.errors){let e=Object.keys(n.errors)[0];if(e&&n.errors[e]?.[0])return n.errors[e][0]}return n?.message||t},B=(e,t)=>{let n=t.replace(/\D/g,``).slice(-1),r=[...f];r[e]=n,p(r),_(``),n&&e<5&&v.current[e+1]?.focus()},V=(e,t)=>{t.key===`Backspace`&&!f[e]&&e>0&&v.current[e-1]?.focus(),t.key===`ArrowLeft`&&e>0&&v.current[e-1]?.focus(),t.key===`ArrowRight`&&e<5&&v.current[e+1]?.focus()},H=e=>{e.preventDefault();let t=e.clipboardData.getData(`text`).replace(/\D/g,``).slice(0,6).split(``),n=[``,``,``,``,``,``];t.forEach((e,t)=>{t<6&&(n[t]=e)}),p(n),_(``),v.current[Math.min(t.length,5)]?.focus()},U=async e=>{if(e.preventDefault(),!a.trim()){_(`Email is missing. Go back to forgot password.`);return}if(!M){_(`Please enter all 6 digits.`);return}_(``),h(!0);try{await c(`/verify-reset-code`,{email:a.trim(),code:j}),d(`password`)}catch(e){_(z(e,`Invalid or expired reset code.`)),v.current[0]?.closest(`.rp-otp-row`)?.animate([{transform:`translateX(-6px)`},{transform:`translateX(6px)`},{transform:`translateX(-4px)`},{transform:`translateX(0)`}],{duration:300,easing:`ease-out`})}finally{h(!1)}},W=async e=>{if(e.preventDefault(),R){A(``),O(!0);try{await c(`/reset-password`,{email:a.trim(),code:j,password:y,password_confirmation:x}),sessionStorage.removeItem(`reset_email`),d(`done`)}catch(e){A(z(e,`Failed to reset password. Try again.`))}finally{O(!1)}}},G=[{key:`otp`,label:`Enter 6-digit code`,sub:`Sent to your admin email.`},{key:`password`,label:`Set a new password`,sub:`Min 8 characters.`},{key:`done`,label:`Access restored`,sub:`Log in with your new password.`}],K={otp:0,password:1,done:2}[u];return(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,700;1,400&family=DM+Sans:wght@300;400;500&display=swap');
        *, *::before, *::after { box-sizing:border-box; margin:0; padding:0; }

        .rp-root {
          min-height:100vh; display:flex;
          font-family:'DM Sans',sans-serif; background:#0a0f1e;
        }

        .rp-left {
          flex:1; background:#0f172a; position:relative; overflow:hidden;
          display:flex; flex-direction:column; justify-content:space-between;
          padding:48px 52px;
        }
        @media(max-width:900px){ .rp-left{ display:none; } }

        .rp-noise {
          position:absolute; inset:0;
          background-image:radial-gradient(circle,rgba(255,255,255,.04) 1px,transparent 1px);
          background-size:24px 24px; pointer-events:none;
        }
        .rp-glow1 {
          position:absolute; top:-80px; right:-80px; width:420px; height:420px;
          border-radius:50%;
          background:radial-gradient(circle,rgba(201,168,76,.09) 0%,transparent 65%);
          pointer-events:none;
        }
        .rp-glow2 {
          position:absolute; bottom:-60px; left:-40px; width:300px; height:300px;
          border-radius:50%;
          background:radial-gradient(circle,rgba(99,102,241,.06) 0%,transparent 70%);
          pointer-events:none;
        }

        .rp-logo { position:relative; z-index:1; display:flex; align-items:center; gap:10px; }
        .rp-logo-mark {
          width:36px; height:36px; border-radius:9px;
          background:linear-gradient(135deg,#c9a84c,#e8c97a);
          display:flex; align-items:center; justify-content:center;
        }
        .rp-logo-name {
          font-family:'Lora',serif; font-size:18px; font-weight:700;
          color:#fff; letter-spacing:-.01em;
        }
        .rp-logo-name span { color:#c9a84c; }

        .rp-left-body { position:relative; z-index:1; }

        .rp-kicker {
          display:inline-flex; align-items:center; gap:7px;
          font-size:10.5px; font-weight:500; letter-spacing:.14em; text-transform:uppercase;
          color:#e8c97a; background:rgba(201,168,76,.1); border:1px solid rgba(201,168,76,.2);
          border-radius:999px; padding:4px 13px; margin-bottom:22px;
        }
        .rp-kicker-dot { width:5px; height:5px; border-radius:50%; background:#c9a84c; }

        .rp-headline {
          font-family:'Lora',serif; font-size:clamp(28px,3vw,40px);
          font-weight:700; color:#fff; line-height:1.1; margin-bottom:16px;
        }
        .rp-headline em { font-style:italic; color:#e8c97a; }

        .rp-desc {
          font-size:14px; font-weight:300; color:#64748b;
          line-height:1.7; max-width:360px; margin-bottom:40px;
        }

        .rp-steps { display:flex; flex-direction:column; gap:0; }
        .rp-step {
          display:flex; gap:16px; align-items:flex-start;
          padding:14px 0; border-bottom:1px solid rgba(255,255,255,.05);
          transition:opacity .3s;
        }
        .rp-step:last-child { border-bottom:none; }
        .rp-step--done   { opacity:.45; }
        .rp-step--future { opacity:.3; }
        .rp-step--active { opacity:1; }

        .rp-step-num {
          width:28px; height:28px; border-radius:8px; flex-shrink:0;
          display:flex; align-items:center; justify-content:center;
          font-size:11.5px; font-weight:600;
          transition:background .3s, border-color .3s, color .3s;
          margin-top:1px;
        }
        .rp-step-num--done {
          background:rgba(34,197,94,.15); border:1px solid rgba(34,197,94,.3); color:#22c55e;
        }
        .rp-step-num--active {
          background:rgba(201,168,76,.15); border:1px solid rgba(201,168,76,.3); color:#c9a84c;
        }
        .rp-step-num--future {
          background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.08); color:#475569;
        }

        .rp-step-text { display:flex; flex-direction:column; gap:2px; }
        .rp-step-label { font-size:13.5px; font-weight:500; color:rgba(255,255,255,.85); }
        .rp-step-sub   { font-size:12px; font-weight:300; color:#475569; }

        .rp-left-foot {
          position:relative; z-index:1; font-size:12px; font-weight:300; color:#334155;
          display:flex; align-items:center; gap:8px;
        }

        .rp-right {
          width:520px; flex-shrink:0; background:#faf8f5;
          display:flex; flex-direction:column; justify-content:center;
          padding:56px 52px; position:relative; overflow:hidden;
        }
        @media(max-width:900px){
          .rp-right{ width:100%; padding:40px 24px; padding-top:60px; justify-content:flex-start; }
        }

        .rp-right::before {
          content:''; position:absolute; top:-80px; right:-80px;
          width:400px; height:400px; border-radius:50%;
          background:radial-gradient(circle,rgba(180,83,9,.05) 0%,transparent 70%);
          pointer-events:none;
        }

        .rp-mobile-logo {
          display:none; align-items:center; gap:9px; margin-bottom:32px;
        }
        @media(max-width:900px){ .rp-mobile-logo{ display:flex; } }

        .rp-panel {
          position:relative; z-index:1;
          animation:rpIn .45s cubic-bezier(.4,0,.2,1) both;
        }
        @keyframes rpIn {
          from{ opacity:0; transform:translateY(16px); }
          to  { opacity:1; transform:translateY(0); }
        }

        .rp-eyebrow {
          font-size:11px; font-weight:500; letter-spacing:.16em; text-transform:uppercase;
          color:#b45309; margin-bottom:10px; display:flex; align-items:center; gap:7px;
        }
        .rp-title {
          font-family:'Lora',serif; font-size:26px; font-weight:700;
          color:#1a1a2e; line-height:1.15; margin-bottom:8px;
        }
        .rp-title em { font-style:italic; color:#b45309; }
        .rp-sub {
          font-size:13.5px; font-weight:300; color:#9a8a7a;
          line-height:1.6; margin-bottom:28px;
        }

        .rp-email-chip {
          display:inline-flex; align-items:center; gap:7px;
          font-size:12.5px; font-weight:400; color:#b45309;
          background:rgba(180,83,9,.07); border:1px solid rgba(180,83,9,.16);
          border-radius:100px; padding:5px 13px; margin-bottom:24px;
        }

        .rp-otp-row {
          display:flex; gap:10px; margin-bottom:22px; justify-content:center;
        }
        .rp-otp-box {
          width:52px; height:60px; border-radius:12px;
          background:#fff; border:1.5px solid #e5ddd3;
          font-family:'Lora',serif; font-size:22px; font-weight:700;
          color:#1a1a2e; text-align:center;
          outline:none; transition:border-color .2s,box-shadow .2s,background .2s;
          caret-color:#c9a84c;
        }
        .rp-otp-box::placeholder { color:#e5ddd3; }
        .rp-otp-box:focus {
          border-color:#c9a84c; box-shadow:0 0 0 3px rgba(201,168,76,.15);
          background:#fffdf9;
        }
        .rp-otp-box--filled {
          border-color:#c9a84c; background:#fffdf9; color:#1a1a2e;
        }
        .rp-otp-box--error {
          border-color:#ef4444 !important; box-shadow:0 0 0 3px rgba(239,68,68,.1) !important;
          animation:rpShake .3s ease;
        }
        @keyframes rpShake {
          0%,100%{transform:translateX(0)} 25%{transform:translateX(-5px)} 75%{transform:translateX(5px)}
        }
        @media(max-width:400px){ .rp-otp-box{ width:42px; height:52px; font-size:18px; } }

        .rp-resend {
          font-size:13px; font-weight:300; color:#9a8a7a;
          text-align:center; margin-bottom:24px;
        }
        .rp-resend button {
          background:none; border:none; font-size:13px; font-weight:500;
          color:#b45309; cursor:pointer; transition:color .2s; padding:0;
        }
        .rp-resend button:hover { color:#92400e; }

        .rp-field { margin-bottom:18px; }
        .rp-label {
          display:block; font-size:12px; font-weight:500; color:#4a4a5a;
          margin-bottom:7px; letter-spacing:.02em;
        }
        .rp-input-wrap { position:relative; }
        .rp-input-icon {
          position:absolute; left:14px; top:50%; transform:translateY(-50%);
          color:#b5a090; display:flex; align-items:center; pointer-events:none;
        }
        .rp-input {
          width:100%; background:#fff; border:1.5px solid #e5ddd3; border-radius:10px;
          padding:13px 44px 13px 42px;
          font-family:'DM Sans',sans-serif; font-size:14px; color:#1a1a2e;
          outline:none; transition:border-color .2s,box-shadow .2s;
        }
        .rp-input::placeholder { color:#c8bfb5; }
        .rp-input:focus { border-color:#c9a84c; box-shadow:0 0 0 3px rgba(201,168,76,.14); }
        .rp-input--ok    { border-color:#22c55e !important; }
        .rp-input--error { border-color:#ef4444 !important; }

        .rp-toggle {
          position:absolute; right:13px; top:50%; transform:translateY(-50%);
          background:none; border:none; cursor:pointer; color:#b5a090;
          display:flex; align-items:center; padding:4px; transition:color .2s;
        }
        .rp-toggle:hover { color:#7a6a5a; }

        .rp-strength { margin-top:8px; }
        .rp-strength-track {
          height:3px; background:#ede8e0; border-radius:999px; overflow:hidden; margin-bottom:4px;
        }
        .rp-strength-fill {
          height:3px; border-radius:999px;
          transition:width .3s ease, background .3s ease;
        }
        .rp-strength-label {
          font-size:11.5px; font-weight:400;
          transition:color .3s;
        }

        .rp-match-msg {
          display:flex; align-items:center; gap:5px;
          font-size:12px; margin-top:6px; font-weight:400;
        }

        .rp-error-banner {
          display:flex; align-items:flex-start; gap:10px;
          background:#fff5f5; border:1px solid #fecaca; border-radius:10px;
          padding:13px 15px; margin-bottom:20px;
          font-size:13px; color:#b91c1c; line-height:1.5;
        }

        .rp-btn {
          width:100%; padding:14px;
          font-family:'DM Sans',sans-serif; font-size:14.5px; font-weight:500;
          color:#0f172a; background:#c9a84c; border:none; border-radius:10px;
          cursor:pointer; display:flex; align-items:center; justify-content:center; gap:9px;
          transition:background .2s,transform .15s,box-shadow .2s; margin-bottom:18px;
        }
        .rp-btn:hover:not(:disabled) {
          background:#e8c97a; transform:translateY(-1px); box-shadow:0 6px 20px rgba(201,168,76,.3);
        }
        .rp-btn:disabled { opacity:.5; cursor:not-allowed; }

        .rp-btn--dark {
          background:#1a1a2e; color:#fff;
        }
        .rp-btn--dark:hover:not(:disabled) {
          background:#0a0f1e; box-shadow:0 6px 20px rgba(0,0,0,.18);
        }

        .rp-back-btn {
          display:flex; align-items:center; justify-content:center; gap:7px;
          width:100%; background:none; border:none; cursor:pointer;
          font-size:13px; font-weight:400; color:#9a8a7a; transition:color .2s;
        }
        .rp-back-btn:hover { color:#1a1a2e; }

        .rp-spinner {
          width:16px; height:16px;
          border:2px solid rgba(15,23,42,.2); border-top-color:#0f172a;
          border-radius:50%; animation:rpSpin .7s linear infinite; flex-shrink:0;
        }
        @keyframes rpSpin { to{ transform:rotate(360deg); } }

        .rp-success {
          display:flex; flex-direction:column; align-items:center; text-align:center; gap:0;
          animation:rpIn .5s ease both;
        }
        .rp-success-icon {
          width:80px; height:80px; border-radius:50%; margin-bottom:24px;
          background:linear-gradient(135deg,rgba(201,168,76,.15),rgba(232,201,122,.1));
          border:2px solid rgba(201,168,76,.25);
          display:flex; align-items:center; justify-content:center;
          animation:rpPop .5s cubic-bezier(.34,1.56,.64,1) .1s both;
        }
        @keyframes rpPop {
          from{ transform:scale(.6); opacity:0; }
          to  { transform:scale(1); opacity:1; }
        }
        .rp-success-title {
          font-family:'Lora',serif; font-size:26px; font-weight:700; color:#1a1a2e; margin-bottom:10px;
        }
        .rp-success-desc {
          font-size:13.5px; font-weight:300; color:#7a6a5a; line-height:1.7;
          max-width:320px; margin-bottom:28px;
        }
        .rp-success-note {
          display:flex; align-items:center; gap:7px;
          font-size:12px; font-weight:300; color:#b5a090;
          background:#f5f1eb; border-radius:8px; padding:10px 14px;
          width:100%; justify-content:center; margin-bottom:28px;
        }


          /* Hover effect */
.ft-logo:hover .ft-logo-wrap {
  transform: scale(1.05);
  transition: 0.25s ease;
}/* Logo image */
.ft-logo-img {
  width: 10%;
  height: 10%;
  object-fit: contain;
  border-radius: 8px;
}



/* Hover effect */
.ft-logo:hover .ft-logo-wrap {
  transform: scale(1.05);
  transition: 0.25s ease;
}
  
      `}),(0,s.jsx)(i,{title:`Reset Password`}),(0,s.jsxs)(`div`,{className:`rp-root`,children:[(0,s.jsxs)(`div`,{className:`rp-left`,children:[(0,s.jsx)(`div`,{className:`rp-noise`,"aria-hidden":`true`}),(0,s.jsx)(`div`,{className:`rp-glow1`,"aria-hidden":`true`}),(0,s.jsx)(`div`,{className:`rp-glow2`,"aria-hidden":`true`}),(0,s.jsx)(`div`,{className:`rp-logo`,children:(0,s.jsx)(`a`,{href:`/`,className:`ft-logo`,"aria-label":`SchoolProfit home`,children:(0,s.jsx)(`div`,{className:`ft-logo-wrap`,style:{background:`transparent`,border:`none`},children:(0,s.jsx)(`img`,{src:`/media/logo/schoolprofit-icon.svg`,alt:`SchoolProfit logo`,className:`ft-logo-img`,style:{width:`32px`,height:`32px`}})})})}),(0,s.jsxs)(`div`,{className:`rp-left-body`,children:[(0,s.jsxs)(`div`,{className:`rp-kicker`,children:[(0,s.jsx)(`span`,{className:`rp-kicker-dot`}),`Password reset`]}),(0,s.jsxs)(`h1`,{className:`rp-headline`,children:[`Almost there —`,(0,s.jsx)(`br`,{}),(0,s.jsx)(`em`,{children:`new password,`}),(0,s.jsx)(`br`,{}),`fresh start.`]}),(0,s.jsx)(`p`,{className:`rp-desc`,children:`Enter the 6-digit code from your inbox, then choose a strong new password for your admin account.`}),(0,s.jsx)(`div`,{className:`rp-steps`,children:G.map((e,t)=>{let n=t<K?`done`:t===K?`active`:`future`;return(0,s.jsxs)(`div`,{className:`rp-step rp-step--${n}`,children:[(0,s.jsx)(`div`,{className:`rp-step-num rp-step-num--${n}`,children:n===`done`?(0,s.jsx)(`svg`,{width:`12`,height:`12`,viewBox:`0 0 12 12`,fill:`none`,children:(0,s.jsx)(`path`,{d:`M2 6l2.5 2.5 5.5-5`,stroke:`currentColor`,strokeWidth:`1.7`,strokeLinecap:`round`,strokeLinejoin:`round`})}):`0${t+1}`}),(0,s.jsxs)(`div`,{className:`rp-step-text`,children:[(0,s.jsx)(`span`,{className:`rp-step-label`,children:e.label}),(0,s.jsx)(`span`,{className:`rp-step-sub`,children:e.sub})]})]},e.label)})})]}),(0,s.jsxs)(`div`,{className:`rp-left-foot`,children:[(0,s.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:(0,s.jsx)(`path`,{d:`M7 1.5L2 3.5v4c0 2.9 2.2 5.6 5 6.5 2.8-.9 5-3.6 5-6.5v-4L7 1.5z`,stroke:`currentColor`,strokeWidth:`1.2`,strokeLinejoin:`round`})}),`Admin accounts only.`]})]}),(0,s.jsxs)(`div`,{className:`rp-right`,children:[(0,s.jsxs)(`div`,{className:`rp-mobile-logo`,children:[(0,s.jsx)(`div`,{className:`rp-logo-mark`,children:(0,s.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 20 20`,fill:`none`,children:[(0,s.jsx)(`path`,{d:`M10 2L17 6v8l-7 4-7-4V6l7-4z`,stroke:`#0f172a`,strokeWidth:`1.6`,strokeLinejoin:`round`}),(0,s.jsx)(`path`,{d:`M10 10l7-4M10 10v8M10 10L3 6`,stroke:`#0f172a`,strokeWidth:`1.4`,strokeLinecap:`round`})]})}),(0,s.jsxs)(`span`,{className:`rp-logo-name`,children:[`School`,(0,s.jsx)(`span`,{children:`Profit`})]})]}),u===`otp`&&(0,s.jsxs)(`div`,{className:`rp-panel`,children:[(0,s.jsxs)(`div`,{className:`rp-eyebrow`,children:[(0,s.jsxs)(`svg`,{width:`12`,height:`12`,viewBox:`0 0 14 14`,fill:`none`,children:[(0,s.jsx)(`rect`,{x:`1`,y:`3`,width:`12`,height:`9`,rx:`1.5`,stroke:`currentColor`,strokeWidth:`1.2`}),(0,s.jsx)(`path`,{d:`M1 5l6 4 6-4`,stroke:`currentColor`,strokeWidth:`1.2`,strokeLinecap:`round`})]}),`Step 1 of 2`]}),(0,s.jsxs)(`h2`,{className:`rp-title`,children:[`Enter your`,(0,s.jsx)(`br`,{}),(0,s.jsx)(`em`,{children:`reset code`})]}),(0,s.jsx)(`p`,{className:`rp-sub`,children:`We sent a 6-digit code to your inbox. It expires in 15 minutes.`}),a&&(0,s.jsxs)(`div`,{className:`rp-email-chip`,children:[(0,s.jsxs)(`svg`,{width:`12`,height:`12`,viewBox:`0 0 14 14`,fill:`none`,children:[(0,s.jsx)(`rect`,{x:`1`,y:`3`,width:`12`,height:`9`,rx:`1.5`,stroke:`currentColor`,strokeWidth:`1.2`}),(0,s.jsx)(`path`,{d:`M1 5l6 4 6-4`,stroke:`currentColor`,strokeWidth:`1.2`,strokeLinecap:`round`})]}),a]}),g&&(0,s.jsxs)(`div`,{className:`rp-error-banner`,children:[(0,s.jsxs)(`svg`,{width:`15`,height:`15`,viewBox:`0 0 16 16`,fill:`none`,style:{flexShrink:0,marginTop:1},children:[(0,s.jsx)(`circle`,{cx:`8`,cy:`8`,r:`7`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,s.jsx)(`path`,{d:`M8 5v4M8 10.5v.5`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`})]}),g]}),(0,s.jsxs)(`form`,{onSubmit:U,children:[(0,s.jsx)(`div`,{className:`rp-otp-row`,onPaste:H,children:f.map((e,t)=>(0,s.jsx)(`input`,{ref:e=>{v.current[t]=e},type:`text`,inputMode:`numeric`,maxLength:1,placeholder:`·`,value:e,onChange:e=>B(t,e.target.value),onKeyDown:e=>V(t,e),className:`rp-otp-box${e?` rp-otp-box--filled`:``}${g?` rp-otp-box--error`:``}`,autoComplete:`one-time-code`},t))}),(0,s.jsxs)(`div`,{className:`rp-resend`,children:[`Didn't get the code?`,` `,(0,s.jsx)(`button`,{type:`button`,onClick:()=>e(`/forgot-password`),children:`Resend it`})]}),(0,s.jsx)(`button`,{type:`submit`,className:`rp-btn`,disabled:!M||m,children:m?(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)(`span`,{className:`rp-spinner`}),`Verifying code…`]}):(0,s.jsxs)(s.Fragment,{children:[`Verify code`,(0,s.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,children:(0,s.jsx)(`path`,{d:`M1 7h12M7 1l6 6-6 6`,stroke:`currentColor`,strokeWidth:`1.7`,strokeLinecap:`round`,strokeLinejoin:`round`})})]})})]}),(0,s.jsxs)(`button`,{className:`rp-back-btn`,onClick:()=>e(`/forgot-password`),children:[(0,s.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:(0,s.jsx)(`path`,{d:`M13 7H1M7 13L1 7l6-6`,stroke:`currentColor`,strokeWidth:`1.7`,strokeLinecap:`round`,strokeLinejoin:`round`})}),`Back to forgot password`]})]},`otp`),u===`password`&&(0,s.jsxs)(`div`,{className:`rp-panel`,children:[(0,s.jsxs)(`div`,{className:`rp-eyebrow`,children:[(0,s.jsxs)(`svg`,{width:`12`,height:`12`,viewBox:`0 0 14 14`,fill:`none`,children:[(0,s.jsx)(`rect`,{x:`2`,y:`6`,width:`10`,height:`7`,rx:`1.5`,stroke:`currentColor`,strokeWidth:`1.2`}),(0,s.jsx)(`path`,{d:`M4 6V4a3 3 0 016 0v2`,stroke:`currentColor`,strokeWidth:`1.2`}),(0,s.jsx)(`circle`,{cx:`7`,cy:`9.5`,r:`1`,fill:`currentColor`})]}),`Step 2 of 2`]}),(0,s.jsxs)(`h2`,{className:`rp-title`,children:[`Set a `,(0,s.jsx)(`em`,{children:`new password`})]}),(0,s.jsx)(`p`,{className:`rp-sub`,children:`Choose something strong. Minimum 8 characters.`}),k&&(0,s.jsxs)(`div`,{className:`rp-error-banner`,children:[(0,s.jsxs)(`svg`,{width:`15`,height:`15`,viewBox:`0 0 16 16`,fill:`none`,style:{flexShrink:0,marginTop:1},children:[(0,s.jsx)(`circle`,{cx:`8`,cy:`8`,r:`7`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,s.jsx)(`path`,{d:`M8 5v4M8 10.5v.5`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`})]}),k]}),(0,s.jsxs)(`form`,{onSubmit:W,children:[(0,s.jsxs)(`div`,{className:`rp-field`,children:[(0,s.jsx)(`label`,{className:`rp-label`,htmlFor:`rp-pw`,children:`New password`}),(0,s.jsxs)(`div`,{className:`rp-input-wrap`,children:[(0,s.jsx)(`span`,{className:`rp-input-icon`,children:(0,s.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,s.jsx)(`rect`,{x:`2`,y:`7`,width:`12`,height:`7`,rx:`1.5`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,s.jsx)(`path`,{d:`M5 7V5a3 3 0 016 0v2`,stroke:`currentColor`,strokeWidth:`1.2`}),(0,s.jsx)(`circle`,{cx:`8`,cy:`10.5`,r:`1`,fill:`currentColor`})]})}),(0,s.jsx)(`input`,{id:`rp-pw`,type:C?`text`:`password`,className:`rp-input`,placeholder:`Min. 8 characters`,value:y,onChange:e=>{b(e.target.value),A(``)},autoFocus:!0,required:!0}),(0,s.jsx)(`button`,{type:`button`,className:`rp-toggle`,onClick:()=>w(e=>!e),"aria-label":C?`Hide`:`Show`,children:C?(0,s.jsxs)(`svg`,{width:`15`,height:`15`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,s.jsx)(`path`,{d:`M2 8s2.5-5 6-5 6 5 6 5-2.5 5-6 5-6-5-6-5z`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,s.jsx)(`circle`,{cx:`8`,cy:`8`,r:`2`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,s.jsx)(`path`,{d:`M3 3l10 10`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`})]}):(0,s.jsxs)(`svg`,{width:`15`,height:`15`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,s.jsx)(`path`,{d:`M2 8s2.5-5 6-5 6 5 6 5-2.5 5-6 5-6-5-6-5z`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,s.jsx)(`circle`,{cx:`8`,cy:`8`,r:`2`,stroke:`currentColor`,strokeWidth:`1.3`})]})})]}),y.length>0&&(0,s.jsxs)(`div`,{className:`rp-strength`,children:[(0,s.jsx)(`div`,{className:`rp-strength-track`,children:(0,s.jsx)(`div`,{className:`rp-strength-fill`,style:{width:`${N*25}%`,background:F}})}),(0,s.jsx)(`span`,{className:`rp-strength-label`,style:{color:F},children:P})]})]}),(0,s.jsxs)(`div`,{className:`rp-field`,children:[(0,s.jsx)(`label`,{className:`rp-label`,htmlFor:`rp-confirm`,children:`Confirm password`}),(0,s.jsxs)(`div`,{className:`rp-input-wrap`,children:[(0,s.jsx)(`span`,{className:`rp-input-icon`,children:(0,s.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,s.jsx)(`rect`,{x:`2`,y:`7`,width:`12`,height:`7`,rx:`1.5`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,s.jsx)(`path`,{d:`M5 7V5a3 3 0 016 0v2`,stroke:`currentColor`,strokeWidth:`1.2`}),(0,s.jsx)(`path`,{d:`M6 10.5l1.5 1.5 3-3`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})]})}),(0,s.jsx)(`input`,{id:`rp-confirm`,type:T?`text`:`password`,className:`rp-input${I?` rp-input--ok`:L?` rp-input--error`:``}`,placeholder:`Re-enter password`,value:x,onChange:e=>{S(e.target.value),A(``)},required:!0}),(0,s.jsx)(`button`,{type:`button`,className:`rp-toggle`,onClick:()=>E(e=>!e),"aria-label":T?`Hide`:`Show`,children:T?(0,s.jsxs)(`svg`,{width:`15`,height:`15`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,s.jsx)(`path`,{d:`M2 8s2.5-5 6-5 6 5 6 5-2.5 5-6 5-6-5-6-5z`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,s.jsx)(`circle`,{cx:`8`,cy:`8`,r:`2`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,s.jsx)(`path`,{d:`M3 3l10 10`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`})]}):(0,s.jsxs)(`svg`,{width:`15`,height:`15`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,s.jsx)(`path`,{d:`M2 8s2.5-5 6-5 6 5 6 5-2.5 5-6 5-6-5-6-5z`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,s.jsx)(`circle`,{cx:`8`,cy:`8`,r:`2`,stroke:`currentColor`,strokeWidth:`1.3`})]})})]}),L&&(0,s.jsxs)(`div`,{className:`rp-match-msg`,style:{color:`#ef4444`},children:[(0,s.jsxs)(`svg`,{width:`12`,height:`12`,viewBox:`0 0 12 12`,fill:`none`,children:[(0,s.jsx)(`circle`,{cx:`6`,cy:`6`,r:`5.5`,stroke:`currentColor`,strokeWidth:`1.2`}),(0,s.jsx)(`path`,{d:`M6 3.5v3M6 8v.5`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`})]}),L]}),I&&(0,s.jsxs)(`div`,{className:`rp-match-msg`,style:{color:`#22c55e`},children:[(0,s.jsxs)(`svg`,{width:`12`,height:`12`,viewBox:`0 0 12 12`,fill:`none`,children:[(0,s.jsx)(`circle`,{cx:`6`,cy:`6`,r:`5.5`,stroke:`currentColor`,strokeWidth:`1.2`}),(0,s.jsx)(`path`,{d:`M3 6l2 2 4-4`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),`Passwords match`]})]}),(0,s.jsx)(`button`,{type:`submit`,className:`rp-btn${D?``:` rp-btn--dark`}`,style:R&&!D?{background:`#c9a84c`,color:`#0f172a`}:{},disabled:!R||D,children:D?(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)(`span`,{className:`rp-spinner`}),`Resetting password…`]}):(0,s.jsxs)(s.Fragment,{children:[(0,s.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,children:[(0,s.jsx)(`rect`,{x:`2`,y:`6`,width:`10`,height:`7`,rx:`1.5`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,s.jsx)(`path`,{d:`M4 6V4a3 3 0 016 0v2`,stroke:`currentColor`,strokeWidth:`1.2`}),(0,s.jsx)(`path`,{d:`M5 9.5l1.5 1.5 3-3`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),`Reset password`]})})]}),(0,s.jsxs)(`button`,{className:`rp-back-btn`,onClick:()=>{d(`otp`),p([``,``,``,``,``,``]),A(``)},children:[(0,s.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:(0,s.jsx)(`path`,{d:`M13 7H1M7 13L1 7l6-6`,stroke:`currentColor`,strokeWidth:`1.7`,strokeLinecap:`round`,strokeLinejoin:`round`})}),`Back to code entry`]})]},`password`),u===`done`&&(0,s.jsxs)(`div`,{className:`rp-panel rp-success`,children:[(0,s.jsx)(`div`,{className:`rp-success-icon`,children:(0,s.jsx)(`svg`,{width:`34`,height:`34`,viewBox:`0 0 36 36`,fill:`none`,children:(0,s.jsx)(`path`,{d:`M6 18l8 8 16-16`,stroke:`#c9a84c`,strokeWidth:`2.8`,strokeLinecap:`round`,strokeLinejoin:`round`})})}),(0,s.jsx)(`h2`,{className:`rp-success-title`,children:`Password reset!`}),(0,s.jsx)(`p`,{className:`rp-success-desc`,children:`Your admin password has been updated. You can now sign in with your new credentials.`}),(0,s.jsxs)(`div`,{className:`rp-success-note`,children:[(0,s.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:(0,s.jsx)(`path`,{d:`M7 1.5L2 3.5v4c0 2.9 2.2 5.6 5 6.5 2.8-.9 5-3.6 5-6.5v-4L7 1.5z`,stroke:`currentColor`,strokeWidth:`1.2`,strokeLinejoin:`round`})}),`Your password has been changed successfully.`]}),(0,s.jsxs)(`button`,{className:`rp-btn`,onClick:()=>e(`/login`),children:[(0,s.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,children:(0,s.jsx)(`path`,{d:`M1 7h12M7 1l6 6-6 6`,stroke:`currentColor`,strokeWidth:`1.7`,strokeLinecap:`round`,strokeLinejoin:`round`})}),`Sign in now`]})]},`done`)]})]})]})}export{l as default};