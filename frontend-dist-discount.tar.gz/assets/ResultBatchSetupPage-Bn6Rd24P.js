import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{p as t,x as n}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as r,E as i,P as a,d as o,f as s,l as c,u as ee}from"./index-D6TxbaCx.js";var l=e(),u=t(),d=`gq_result_batch_setup_v1`;function f(e){if(!e)return null;try{return JSON.parse(e)}catch{return null}}function p(){let e=new Date().getHours();return e<12?`Good morning`:e<17?`Good afternoon`:`Good evening`}function m(){let e=n(),{showSuccess:t,showError:m,showWarning:h,showInfo:g}=c(),[_,v]=(0,l.useState)(!1),[y,b]=(0,l.useState)(!0),[x,S]=(0,l.useState)(!0),[C,w]=(0,l.useState)(!1),[T,E]=(0,l.useState)(``),[D,O]=(0,l.useState)([]),[k,A]=(0,l.useState)([]),[j,M]=(0,l.useState)([]),[N,P]=(0,l.useState)([]),[F,I]=(0,l.useState)([]),[L,R]=(0,l.useState)(``),[z,B]=(0,l.useState)(``),[V,H]=(0,l.useState)(``),[U,W]=(0,l.useState)(``),[G,K]=(0,l.useState)(``);(0,l.useEffect)(()=>{let e=f(localStorage.getItem(d));e&&(R(e.classId??``),B(e.term??``),H(e.session??``),W(e.departmentId??``),K(e.sectionId??``))},[]),(0,l.useEffect)(()=>{localStorage.setItem(d,JSON.stringify({classId:L,term:z,session:V,departmentId:U,sectionId:G}))},[L,z,V,U,G]),(0,l.useEffect)(()=>{let e=window.setTimeout(()=>b(!1),120);return()=>window.clearTimeout(e)},[]),(0,l.useEffect)(()=>{let e=!0;async function t(){S(!0);try{let[t,n,r]=await Promise.all([a.get(`/fstudent-classes`),a.get(`/fterms`),a.get(`/facademic-sessions`)]);if(!e)return;let i=t.data,o=Array.isArray(i)?i:i?.classes??[],s=Array.isArray(i)?``:i?.user_role??``;O(o),E(s),A(n.data?.data??n.data??[]),M((r.data?.data??r.data??[]).map(e=>({id:e.id,name:e.name??e.session??e.title??``})));try{let t=await a.get(`/fdepartments`);if(!e)return;P(t.data?.data??t.data??[])}catch{if(!e)return;P([])}try{let t=await a.get(`/fsections`);if(!e)return;I(t.data?.data??t.data??[])}catch{if(!e)return;I([])}R(e=>e&&(o.some(t=>t.id===e)?e:``))}catch(e){console.error(e),m?.(e?.response?.data?.message||`Failed to load batch setup data.`)}finally{e&&S(!1)}}return t(),()=>{e=!1}},[]);let q=(0,l.useMemo)(()=>String(T)===`Teacher`,[T]),J=(0,l.useMemo)(()=>!!L&&!!z&&!!V,[L,z,V]),Y=(0,l.useMemo)(()=>L?D.find(e=>e.id===L)?.name??`-`:`—`,[L,D]),X=(0,l.useMemo)(()=>U?N.find(e=>e.id===U)?.name??`-`:`—`,[U,N]),Z=(0,l.useMemo)(()=>G?F.find(e=>e.id===G)?.name??`-`:`—`,[G,F]),Q=()=>{localStorage.removeItem(d),R(``),B(``),H(``),W(``),K(``),g?.(`Saved selection cleared.`)},$=async()=>{if(!J)return h?.(`Please select Class, Term and Session.`);w(!0);try{let n={class_id:L,term:z,session:V};U&&(n.department_id=U),G&&(n.section_id=G);let{data:r}=await a.post(`/result-batches/resolve`,n),i=r?.batch?.id;if(!i)return m?.(`Batch resolved but no batch id returned.`);t?.(`Batch ready (#${i}) ✅`),e(`/results/upload?batchId=${i}`)}catch(e){console.error(e),m?.(e?.response?.data?.message||`Failed to prepare batch.`)}finally{w(!1)}};return(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`style`,{children:`
        /* ======= ResultBatchSetupPage - Modern SaaS style ======= */
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');
        .db-main {
          background: #F8FAFC;
          min-height: 100vh;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          padding: 24px 28px 0;
        }
        @media (max-width: 991.98px) { .db-main { padding: 18px 14px 0; } }

        .db-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 18px;
          padding: 32px 36px;
          position: relative;
          overflow: hidden;
          margin: 10px 0 24px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
        }
        .db-hero-glow {
          position: absolute;
          top: -60px;
          right: -60px;
          width: 320px;
          height: 320px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.15) 0%, transparent 65%);
          pointer-events: none;
        }
        .db-hero-glow2 {
          position: absolute;
          bottom: -40px;
          left: 30%;
          width: 200px;
          height: 200px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(37, 99, 235, 0.10) 0%, transparent 70%);
          pointer-events: none;
        }
        .db-hero-inner {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: 28px;
          flex-wrap: wrap;
        }

        .db-session-badge {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.20);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius: 100px;
          padding: 4px 12px;
          margin-bottom: 12px;
        }
        .db-session-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #10B981;
          animation: dbPulse 2s ease infinite;
        }
        @keyframes dbPulse {
          0%,100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.4; transform: scale(1.5); }
        }

        .db-greeting {
          font-size: 26px;
          font-weight: 800;
          color: #fff;
          line-height: 1.1;
          margin-bottom: 8px;
        }
        .db-greeting em { font-style: normal; color: #FBBF24; }

        .db-hero-sub {
          font-size: 13.5px;
          color: #CBD5E1;
          line-height: 1.6;
          max-width: 760px;
          margin-bottom: 20px;
        }

        .db-hero-btns { display: flex; gap: 10px; flex-wrap: wrap; }

        .db-btn-gold {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 9px 18px;
          font-size: 13px;
          font-weight: 700;
          color: #FFFFFF;
          background: #D97706;
          border: none;
          border-radius: 10px;
          cursor: pointer;
          transition: all 0.2s ease;
          white-space: nowrap;
        }
        .db-btn-gold:hover { background: #B45309; transform: translateY(-1px); color: #FFFFFF; }
        .db-btn-gold:disabled { opacity: 0.55; cursor: not-allowed; transform: none; }

        .db-btn-outline {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 9px 18px;
          font-size: 13px;
          font-weight: 600;
          color: #FFFFFF;
          background: rgba(255, 255, 255, 0.10);
          border: 1px solid rgba(255, 255, 255, 0.20);
          border-radius: 10px;
          cursor: pointer;
          transition: all 0.2s ease;
          white-space: nowrap;
        }
        .db-btn-outline:hover { background: rgba(255, 255, 255, 0.18); color: #fff; }
        .db-btn-outline:disabled { opacity: 0.55; cursor: not-allowed; }

        .db-hero-stat-card {
          background: rgba(255, 255, 255, 0.08);
          border: 1px solid rgba(255, 255, 255, 0.15);
          backdrop-filter: blur(8px);
          border-radius: 14px;
          padding: 18px 20px;
          min-width: 300px;
        }
        @media (max-width: 991.98px) { .db-hero { padding: 24px 20px; } .db-hero-stat-card { min-width: 0; width: 100%; } }
        .db-hero-stat-row { display: flex; flex-direction: column; gap: 10px; }
        .db-hero-stat-item { display: flex; justify-content: space-between; align-items: center; gap: 16px; }
        .db-hero-stat-label { font-size: 12px; font-weight: 400; color: #CBD5E1; }
        .db-hero-stat-val { font-size: 18px; font-weight: 800; color: #FBBF24; }
        .db-hero-stat-sep { height: 1px; background: rgba(255, 255, 255, 0.08); }

        .db-grid {
          display: grid;
          grid-template-columns: 1fr 360px;
          gap: 20px;
          margin-bottom: 24px;
        }
        @media (max-width: 991.98px) { .db-grid { grid-template-columns: 1fr; } }

        .db-panel {
          background: #fff;
          border: 1px solid #ede8e0;
          border-radius: 14px;
          overflow: hidden;
          box-shadow: 0 2px 10px rgba(15,23,42,0.04);
        }
        .db-panel-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 18px 18px;
          border-bottom: 1px solid rgba(0, 0, 0, 0.06);
          gap: 12px;
          flex-wrap: wrap;
        }
        .db-panel-title {
          font-family: "Lora", serif;
          font-size: 16px;
          font-weight: 800;
          color: #1a1a2e;
          margin: 0;
        }
        .db-panel-sub {
          font-size: 11.5px;
          font-weight: 300;
          color: #9a8a7a;
          margin: 0;
        }

        .db-refresh-btn {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 8px 12px;
          font-size: 12px;
          font-weight: 600;
          color: #7a6a5a;
          background: #f5f1eb;
          border: 1px solid #e5ddd3;
          border-radius: 10px;
          cursor: pointer;
          transition: background 0.2s;
          white-space: nowrap;
        }
        .db-refresh-btn:hover { background: #ede8e0; }
        .db-refresh-btn:disabled { opacity: 0.55; cursor: not-allowed; }

        .db-muted { color: #9a8a7a; }
        .db-strong { font-weight: 900; color: #1a1a2e; }

        .db-input, .db-select {
          width: 100%;
          padding: 10px 12px;
          border-radius: 10px;
          border: 1px solid #e5ddd3;
          outline: none;
          font-size: 13px;
          background: #fff;
        }
        .db-input:focus, .db-select:focus { border-color: rgba(201,168,76,0.7); box-shadow: 0 0 0 3px rgba(201,168,76,0.18); }

        .db-alert {
          display: flex;
          align-items: flex-start;
          gap: 10px;
          background: #fff7ed;
          border: 1px solid #fed7aa;
          border-radius: 12px;
          padding: 11px 14px;
          font-size: 13px;
          color: #9a3412;
        }
        .db-alert--info {
          background: #eef2ff;
          border-color: rgba(99,102,241,0.25);
          color: #3730a3;
        }
        .db-alert--warn {
          background: rgba(245, 158, 11, 0.10);
          border-color: rgba(245, 158, 11, 0.25);
          color: #92400e;
        }

        .db-pill {
          display: inline-flex;
          align-items: center;
          font-size: 12px;
          font-weight: 800;
          padding: 6px 10px;
          border-radius: 999px;
          white-space: nowrap;
          border: 1px solid rgba(0,0,0,0.06);
        }

        .db-kv {
          display: grid;
          gap: 10px;
          margin-top: 12px;
        }
        .db-kv-row {
          display: flex;
          justify-content: space-between;
          gap: 12px;
          padding: 10px 12px;
          border: 1px solid rgba(0,0,0,0.06);
          border-radius: 12px;
          background: #faf8f5;
        }
      `}),(0,u.jsx)(s,{sidebarOpen:_,setSidebarOpen:v}),(0,u.jsx)(r,{title:`Result Batch`}),(0,u.jsx)(`div`,{className:`container-fluid`,children:(0,u.jsxs)(`div`,{className:`row`,children:[(0,u.jsx)(o,{sidebarOpen:_}),(0,u.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto db-main`,children:[(y||C)&&(0,u.jsx)(i,{message:y?`Preparing Batch Setup...`:`Preparing batch…`}),(0,u.jsxs)(`div`,{className:`db-hero`,children:[(0,u.jsx)(`div`,{className:`db-hero-glow`,"aria-hidden":`true`}),(0,u.jsx)(`div`,{className:`db-hero-glow2`,"aria-hidden":`true`}),(0,u.jsxs)(`div`,{className:`db-hero-inner`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsxs)(`div`,{className:`db-session-badge`,children:[(0,u.jsx)(`span`,{className:`db-session-dot`}),`Results • Batch Setup`]}),(0,u.jsxs)(`h1`,{className:`db-greeting`,children:[p(),`, `,(0,u.jsxs)(`em`,{children:[q?`Teacher`:`Admin`,`.`]})]}),(0,u.jsxs)(`p`,{className:`db-hero-sub`,children:[`Select `,(0,u.jsx)(`b`,{children:`Class`}),`, `,(0,u.jsx)(`b`,{children:`Term`}),` and `,(0,u.jsx)(`b`,{children:`Session`}),` to resolve a result batch, then proceed to upload results.`,q?` You will only see classes assigned to you.`:``]}),(0,u.jsxs)(`div`,{className:`db-hero-btns`,children:[(0,u.jsxs)(`button`,{className:`db-btn-gold`,onClick:$,disabled:!J||C||x,children:[(0,u.jsx)(`i`,{className:`bi bi-arrow-right-circle`}),`Start Uploading Results`]}),(0,u.jsxs)(`button`,{className:`db-btn-outline`,onClick:Q,disabled:C,children:[(0,u.jsx)(`i`,{className:`bi bi-eraser`}),`Clear selection`]}),(0,u.jsxs)(`button`,{className:`db-btn-outline`,onClick:()=>e(`/results/upload`),disabled:C,children:[(0,u.jsx)(`i`,{className:`bi bi-upload`}),`Go to upload`]})]})]}),(0,u.jsx)(`div`,{className:`db-hero-stat-card d-none d-md-block`,children:(0,u.jsxs)(`div`,{className:`db-hero-stat-row`,children:[(0,u.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,u.jsx)(`span`,{className:`db-hero-stat-label`,children:`Classes`}),(0,u.jsx)(`span`,{className:`db-hero-stat-val`,children:x?`…`:D.length})]}),(0,u.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,u.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,u.jsx)(`span`,{className:`db-hero-stat-label`,children:`Terms`}),(0,u.jsx)(`span`,{className:`db-hero-stat-val`,children:x?`…`:k.length})]}),(0,u.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,u.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,u.jsx)(`span`,{className:`db-hero-stat-label`,children:`Sessions`}),(0,u.jsx)(`span`,{className:`db-hero-stat-val`,children:x?`…`:j.length})]}),(0,u.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,u.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,u.jsx)(`span`,{className:`db-hero-stat-label`,children:`Selected class`}),(0,u.jsx)(`span`,{className:`db-hero-stat-val`,children:Y})]})]})})]})]}),x?(0,u.jsxs)(`div`,{className:`db-panel`,children:[(0,u.jsx)(`div`,{className:`db-panel-head`,children:(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`p`,{className:`db-panel-title`,children:`Loading setup…`}),(0,u.jsx)(`p`,{className:`db-panel-sub`,children:`Fetching classes, terms and sessions`})]})}),(0,u.jsx)(`div`,{style:{padding:16},children:(0,u.jsxs)(`div`,{className:`db-muted`,style:{display:`flex`,alignItems:`center`,gap:10},children:[(0,u.jsx)(`span`,{className:`spinner-border spinner-border-sm`,role:`status`}),`Please wait…`]})})]}):(0,u.jsxs)(`div`,{className:`db-grid`,children:[(0,u.jsxs)(`div`,{className:`db-panel`,children:[(0,u.jsxs)(`div`,{className:`db-panel-head`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`p`,{className:`db-panel-title`,children:`Batch context`}),(0,u.jsx)(`p`,{className:`db-panel-sub`,children:`This selection will be used to resolve the result batch`})]}),(0,u.jsxs)(`button`,{className:`db-refresh-btn`,onClick:Q,disabled:C,children:[(0,u.jsx)(`i`,{className:`bi bi-eraser-fill`}),`Clear saved`]})]}),(0,u.jsxs)(`div`,{style:{padding:16,display:`grid`,gap:12},children:[q?(0,u.jsxs)(`div`,{className:`db-alert db-alert--warn`,children:[(0,u.jsx)(`i`,{className:`bi bi-exclamation-triangle-fill`}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{style:{fontWeight:900,marginBottom:2},children:`Teacher restriction`}),(0,u.jsx)(`div`,{style:{opacity:.85},children:`You can only prepare batches for classes assigned to you by the admin.`})]})]}):(0,u.jsxs)(`div`,{className:`db-alert db-alert--info`,children:[(0,u.jsx)(`i`,{className:`bi bi-info-circle-fill`}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{style:{fontWeight:900,marginBottom:2},children:`Tip`}),(0,u.jsx)(`div`,{style:{opacity:.85},children:`Prepare once, upload for all students, then compute positions/averages once per batch.`})]})]}),(0,u.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`1fr 1fr`,gap:12},children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`db-muted`,style:{fontSize:11,fontWeight:800,letterSpacing:`0.1em`,textTransform:`uppercase`,marginBottom:6},children:`Class *`}),(0,u.jsxs)(`select`,{className:`db-select`,value:L,onChange:e=>R(e.target.value?Number(e.target.value):``),disabled:C,children:[(0,u.jsx)(`option`,{value:``,children:`-- Select Class --`}),D.map(e=>(0,u.jsx)(`option`,{value:e.id,children:e.name},e.id))]}),q&&D.length===0?(0,u.jsx)(`div`,{style:{color:`#b91c1c`,fontSize:12,marginTop:6},children:`No class assigned to you yet. Ask admin to assign your class.`}):null]}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`db-muted`,style:{fontSize:11,fontWeight:800,letterSpacing:`0.1em`,textTransform:`uppercase`,marginBottom:6},children:`Term *`}),(0,u.jsxs)(`select`,{className:`db-select`,value:z,onChange:e=>B(e.target.value),disabled:C,children:[(0,u.jsx)(`option`,{value:``,children:`-- Select Term --`}),k.map(e=>(0,u.jsx)(`option`,{value:e.name,children:e.name},e.id))]})]}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`db-muted`,style:{fontSize:11,fontWeight:800,letterSpacing:`0.1em`,textTransform:`uppercase`,marginBottom:6},children:`Session *`}),(0,u.jsxs)(`select`,{className:`db-select`,value:V,onChange:e=>H(e.target.value),disabled:C,children:[(0,u.jsx)(`option`,{value:``,children:`-- Select Session --`}),j.map(e=>(0,u.jsx)(`option`,{value:e.name,children:e.name},e.id))]})]}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`db-muted`,style:{fontSize:11,fontWeight:800,letterSpacing:`0.1em`,textTransform:`uppercase`,marginBottom:6},children:`Department (optional)`}),(0,u.jsxs)(`select`,{className:`db-select`,value:U,onChange:e=>W(e.target.value?Number(e.target.value):``),disabled:C||N.length===0,title:N.length===0?`Departments not configured`:``,children:[(0,u.jsx)(`option`,{value:``,children:N.length?`-- Select Department --`:`Not configured`}),N.map(e=>(0,u.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`db-muted`,style:{fontSize:11,fontWeight:800,letterSpacing:`0.1em`,textTransform:`uppercase`,marginBottom:6},children:`Section (optional)`}),(0,u.jsxs)(`select`,{className:`db-select`,value:G,onChange:e=>K(e.target.value?Number(e.target.value):``),disabled:C||F.length===0,title:F.length===0?`Sections not configured`:``,children:[(0,u.jsx)(`option`,{value:``,children:F.length?`-- Select Section --`:`Not configured`}),F.map(e=>(0,u.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]})]}),(0,u.jsx)(`div`,{style:{height:1,background:`rgba(0,0,0,0.06)`,margin:`4px 0`}}),(0,u.jsxs)(`div`,{style:{display:`flex`,gap:10,flexWrap:`wrap`,justifyContent:`flex-end`},children:[(0,u.jsx)(`button`,{className:`db-refresh-btn`,onClick:$,disabled:!J||C,children:C?(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`span`,{className:`spinner-border spinner-border-sm`,role:`status`}),`Preparing…`]}):(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`i`,{className:`bi bi-check2-circle`}),`Resolve batch`]})}),(0,u.jsxs)(`button`,{className:`db-btn-gold`,onClick:$,disabled:!J||C,children:[(0,u.jsx)(`i`,{className:`bi bi-arrow-right-circle-fill`}),`Start Uploading Results`]})]}),J?null:(0,u.jsxs)(`div`,{className:`db-muted`,style:{fontSize:12,lineHeight:1.6},children:[`Please select `,(0,u.jsx)(`b`,{children:`Class`}),`, `,(0,u.jsx)(`b`,{children:`Term`}),`, and `,(0,u.jsx)(`b`,{children:`Session`}),` to continue.`]})]})]}),(0,u.jsxs)(`div`,{className:`db-panel`,style:{alignSelf:`start`},children:[(0,u.jsxs)(`div`,{className:`db-panel-head`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`p`,{className:`db-panel-title`,children:`Selected context`}),(0,u.jsx)(`p`,{className:`db-panel-sub`,children:`Preview of what will be used`})]}),(0,u.jsx)(`span`,{className:`db-pill`,style:{background:`rgba(180,83,9,0.08)`,color:`#b45309`},children:`Preview`})]}),(0,u.jsxs)(`div`,{style:{padding:16},children:[(0,u.jsxs)(`div`,{className:`db-kv`,children:[(0,u.jsxs)(`div`,{className:`db-kv-row`,children:[(0,u.jsx)(`span`,{className:`db-muted`,children:`Class`}),(0,u.jsx)(`span`,{className:`db-strong`,children:Y})]}),(0,u.jsxs)(`div`,{className:`db-kv-row`,children:[(0,u.jsx)(`span`,{className:`db-muted`,children:`Term`}),(0,u.jsx)(`span`,{className:`db-strong`,children:z||`—`})]}),(0,u.jsxs)(`div`,{className:`db-kv-row`,children:[(0,u.jsx)(`span`,{className:`db-muted`,children:`Session`}),(0,u.jsx)(`span`,{className:`db-strong`,children:V||`—`})]}),(0,u.jsxs)(`div`,{className:`db-kv-row`,children:[(0,u.jsx)(`span`,{className:`db-muted`,children:`Department`}),(0,u.jsx)(`span`,{className:`db-strong`,children:X})]}),(0,u.jsxs)(`div`,{className:`db-kv-row`,children:[(0,u.jsx)(`span`,{className:`db-muted`,children:`Section`}),(0,u.jsx)(`span`,{className:`db-strong`,children:Z})]})]}),(0,u.jsxs)(`div`,{style:{marginTop:12},className:`db-alert`,children:[(0,u.jsx)(`i`,{className:`bi bi-shield-check`}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{style:{fontWeight:900,marginBottom:2},children:`Note`}),(0,u.jsx)(`div`,{style:{opacity:.85},children:`After uploading for all students, compute positions/averages once per batch.`})]})]}),(0,u.jsxs)(`div`,{style:{display:`grid`,gap:10,marginTop:12},children:[(0,u.jsxs)(`button`,{className:`db-refresh-btn`,onClick:Q,disabled:C,children:[(0,u.jsx)(`i`,{className:`bi bi-eraser-fill`}),`Clear selection`]}),(0,u.jsxs)(`button`,{className:`db-btn-gold`,onClick:$,disabled:!J||C,title:J?``:`Select Class, Term and Session first`,children:[(0,u.jsx)(`i`,{className:`bi bi-arrow-right-circle-fill`}),`Continue to upload`]})]})]})]})]}),(0,u.jsx)(`div`,{className:`mt-auto`,children:(0,u.jsx)(ee,{})})]})]})})]})}export{m as default};