import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{p as t}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as n,E as r,P as i,d as a,f as o,l as ee,u as s}from"./index-D6TxbaCx.js";var c=e(),l=t();function u(e){let t=e?.response?.status,n=e?.response?.data;if(t===409)return n?.message??n?.error??`This item already exists.`;if(t===404)return n?.message??`Not found.`;if(t===422){let e=n?.errors;if(e){let t=e[Object.keys(e)[0]]?.[0];if(t)return t}return n?.message??`Validation error.`}return n?.message??n?.error??e?.message??`Something went wrong.`}function d(){let e=new Date().getHours();return e<12?`Good morning`:e<17?`Good afternoon`:`Good evening`}var f=(e,t,n)=>Math.max(t,Math.min(n,e));function p(){let{showSuccess:e,showError:t}=ee(),[p,m]=(0,c.useState)(!1),[h,g]=(0,c.useState)(!0),[_,v]=(0,c.useState)(!0),[y,b]=(0,c.useState)(null),[x,S]=(0,c.useState)([]),[C,w]=(0,c.useState)(``),[T,E]=(0,c.useState)(!1),[D,O]=(0,c.useState)(1),[k,A]=(0,c.useState)(1),[j,M]=(0,c.useState)(10),[N,P]=(0,c.useState)(0),[F,I]=(0,c.useState)(!1),[L,R]=(0,c.useState)(!1),[z,B]=(0,c.useState)(``),[V,H]=(0,c.useState)(null),[U,W]=(0,c.useState)(``),G=e=>y===e;async function K(e=D){try{v(!0);let t;try{t=await i.get(`/sections`,{params:{page:e,...T?{archived:1}:{}}})}catch{t=await i.get(`/sections/`,{params:{page:e,...T?{archived:1}:{}}})}let n=t.data,r=Array.isArray(n?.data)?n.data:Array.isArray(n)?n:[];S(r),O(n?.current_page??e),A(n?.last_page??1),M(n?.per_page??(r.length||10)),P(n?.total??r.length)}catch(e){t(u(e)),S([]),A(1),P(0),M(10)}finally{v(!1)}}(0,c.useEffect)(()=>{g(!0),K(1).finally(()=>g(!1))},[T]),(0,c.useEffect)(()=>{K(D)},[D,T]);let q=(0,c.useMemo)(()=>{let e=C.trim().toLowerCase();return e?x.filter(t=>(t.name??``).toLowerCase().includes(e)):x},[x,C]),J=C.trim().length>0,Y=(0,c.useMemo)(()=>Math.max(1,Math.ceil(q.length/Math.max(1,j))),[q.length,j]);(0,c.useEffect)(()=>{J&&O(1)},[C]);let X=J?f(D,1,Y):f(D,1,k),Z=(0,c.useMemo)(()=>{if(!J)return q;let e=(X-1)*Math.max(1,j);return q.slice(e,e+Math.max(1,j))},[q,J,X,j]),Q=J?q.length:N,$=J?Y:k;async function te(){let n=z.trim();if(!n)return t(`Please enter a section name.`);try{b(`sec:create`),e((await i.post(`/sections`,{name:n})).data?.message??`Section saved successfully.`),I(!1),B(``),J?(w(``),await K(1)):await K(D)}catch(e){t(u(e))}finally{b(null)}}function ne(e){H(e.id),W(e.name??``),R(!0)}async function re(){if(!V)return;let n=U.trim();if(!n)return t(`Please enter a section name.`);try{b(`sec:update:${V}`),e((await i.put(`/sections/${V}`,{name:n})).data?.message??`Section updated successfully.`),R(!1),H(null),W(``),J?await K(1):await K(D)}catch(e){t(u(e))}finally{b(null)}}async function ie(n){if(window.confirm(`Archive "${n.name}"?\n\nArchived sections will be hidden from future setup forms, but old records will remain safe.`))try{b(`sec:archive:${n.id}`),e((await i.delete(`/sections/${n.id}`)).data?.message??`Section archived successfully.`),await K(D)}catch(e){t(u(e))}finally{b(null)}}async function ae(n){try{b(`sec:restore:${n.id}`),e((await i.post(`/sections/${n.id}/restore`)).data?.message??`Section restored successfully.`),await K(D)}catch(e){t(u(e))}finally{b(null)}}return(0,l.jsxs)(l.Fragment,{children:[(0,l.jsx)(`style`,{children:`
        /* ======= SectionsPage - Modern SaaS style ======= */
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');
        .db-main {
          background: #F8FAFC;
          min-height: 100vh;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          padding: 24px 28px 0;
        }

        .db-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 18px;
          padding: 32px 36px;
          position: relative;
          overflow: hidden;
          margin-bottom: 24px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
        }
        .db-hero-glow {
          position: absolute;
          top: -60px;
          right: -60px;
          width: 320px;
          height: 320px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.15) 0%, transparent 65%);
          pointer-events: none;
        }
        .db-hero-glow2 {
          position: absolute;
          bottom: -40px;
          left: 18%;
          width: 220px;
          height: 220px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(37, 99, 235, 0.10) 0%, transparent 70%);
          pointer-events: none;
        }
        .db-hero-inner {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 28px;
          flex-wrap: wrap;
        }

        .db-session-badge {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.20);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius: 100px;
          padding: 4px 12px;
          margin-bottom: 12px;
        }
        .db-session-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #10B981;
          animation: dbPulse 2s ease infinite;
        }
        @keyframes dbPulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.4; transform: scale(1.5); }
        }

        .db-greeting {
          font-size: 26px;
          font-weight: 800;
          color: #fff;
          line-height: 1.1;
          margin-bottom: 8px;
        }
        .db-greeting em { font-style: normal; color: #FBBF24; }

        .db-hero-sub {
          font-size: 13.5px;
          color: #CBD5E1;
          line-height: 1.6;
          max-width: 720px;
          margin-bottom: 20px;
        }

        .db-hero-btns { display:flex; gap:10px; flex-wrap:wrap; }

        .db-btn-green, .db-btn-gold {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 9px 18px;
          font-size: 13px;
          font-weight: 700;
          color: #FFFFFF;
          background: #D97706;
          border: none;
          border-radius: 10px;
          cursor: pointer;
          transition: all 0.2s ease;
          white-space: nowrap;
        }
        .db-btn-green:hover, .db-btn-gold:hover { background: #B45309; transform: translateY(-1px); color: #FFFFFF; }

        .db-btn-outline {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 9px 18px;
          font-size: 13px;
          font-weight: 600;
          color: #FFFFFF;
          background: rgba(255, 255, 255, 0.10);
          border: 1px solid rgba(255, 255, 255, 0.20);
          border-radius: 10px;
          cursor: pointer;
          transition: all 0.2s ease;
          white-space: nowrap;
        }
        .db-btn-outline:hover { background: rgba(255, 255, 255, 0.18); color: #fff; }

        .db-hero-stat-card {
          background: rgba(255, 255, 255, 0.08);
          border: 1px solid rgba(255, 255, 255, 0.15);
          backdrop-filter: blur(8px);
          border-radius: 14px;
          padding: 20px 24px;
          min-width: 260px;
        }
        .db-hero-stat-row { display:flex; flex-direction:column; gap:10px; }
        .db-hero-stat-item { display:flex; justify-content:space-between; align-items:center; gap:16px; }
        .db-hero-stat-label { font-size: 12px; font-weight: 400; color: #CBD5E1; }
        .db-hero-stat-val { font-size: 18px; font-weight: 800; color: #FBBF24; }
        .db-hero-stat-sep { height: 1px; background: rgba(255, 255, 255, 0.08); }

        .db-panel {
          background: #fff;
          border: 1px solid #E2E8F0;
          border-radius: 16px;
          overflow: hidden;
          margin-bottom: 24px;
          box-shadow: 0 4px 16px rgba(15,39,68,0.03);
        }
        .db-panel-head {
          display:flex;
          align-items:center;
          justify-content: space-between;
          padding: 18px 20px 16px;
          border-bottom: 1px solid #F1F5F9;
          gap: 12px;
          flex-wrap: wrap;
        }
        .db-panel-title {
          font-size: 16px;
          font-weight: 700;
          color: #0F2744;
          margin: 0;
        }
        .db-panel-sub {
          font-size: 11.5px;
          font-weight: 400;
          color: #64748B;
          margin: 0;
        }
        .db-toolbar { display:flex; align-items:center; gap: 10px; flex-wrap: wrap; }
        .db-input {
          display:flex;
          align-items:center;
          gap: 8px;
          padding: 8px 12px;
          background: #F8FAFC;
          border: 1px solid #E2E8F0;
          border-radius: 10px;
          min-width: 260px;
        }
        .db-input input {
          border: none;
          outline: none;
          background: transparent;
          width: 100%;
          font-size: 13px;
          color: #0F2744;
        }

        .db-chip-btn {
          display:inline-flex;
          align-items:center;
          gap: 6px;
          padding: 8px 12px;
          font-size: 12.5px;
          font-weight: 700;
          color: #0F2744;
          background: #F8FAFC;
          border: 1px solid #E2E8F0;
          border-radius: 10px;
          cursor: pointer;
          transition: all .2s ease;
          white-space: nowrap;
        }
        .db-chip-btn:hover:not(:disabled) { background:#E2E8F0; color:#0F2744; transform: translateY(-1px); }
        .db-chip-btn:disabled { opacity: .5; cursor: not-allowed; }

        .db-table { width: 100%; border-collapse: collapse; }
        .db-table th {
          padding: 10px 16px;
          font-size: 11px;
          font-weight: 600;
          letter-spacing: 0.10em;
          text-transform: uppercase;
          color: #64748B;
          background: #F8FAFC;
          border-bottom: 1px solid #E2E8F0;
          text-align: left;
          white-space: nowrap;
        }
        .db-table th:last-child { text-align: right; }
        .db-table td {
          padding: 13px 16px;
          font-size: 13.5px;
          color: #334155;
          border-bottom: 1px solid #F1F5F9;
          vertical-align: middle;
        }
        .db-table tbody tr { transition: background 0.15s; }
        .db-table tbody tr:hover { background: #F8FAFC; }
        .db-table tbody tr:last-child td { border-bottom: none; }

        .db-actions { display:inline-flex; justify-content:flex-end; gap: 8px; flex-wrap: wrap; }
        .db-action-btn {
          display:inline-flex;
          align-items:center;
          gap: 6px;
          padding: 7px 12px;
          font-size: 12.5px;
          font-weight: 900;
          border-radius: 10px;
          cursor: pointer;
          border: 1px solid rgba(0,0,0,0.10);
          background: #fff;
          transition: transform .2s, box-shadow .2s, background .2s;
          white-space: nowrap;
        }
        .db-action-btn:hover:not(:disabled) { transform: translateY(-1px); box-shadow: 0 8px 18px rgba(0,0,0,0.08); background: #faf8f5; }
        .db-action-btn:disabled { opacity: .5; cursor: not-allowed; }
        .db-action-primary { border-color: rgba(30, 64, 175, 0.25); color: #1e40af; }
        .db-action-danger  { border-color: rgba(185, 28, 28, 0.25); color: #b91c1c; }
        .db-action-green   { border-color: rgba(6, 95, 70, 0.25); color: #065f46; }

        .db-pagination {
          display:flex;
          align-items:center;
          justify-content: space-between;
          padding: 14px 16px;
          border-top: 1px solid rgba(0,0,0,0.06);
          flex-wrap: wrap;
          gap: 10px;
        }
        .db-page-info { font-size: 12px; color:#9a8a7a; }
        .db-page-btns { display:flex; align-items:center; gap: 8px; }
        .db-page-btn {
          display:inline-flex;
          align-items:center;
          gap: 6px;
          padding: 7px 12px;
          font-size: 12.5px;
          font-weight: 900;
          color: #7a6a5a;
          background: #f5f1eb;
          border: 1px solid #e5ddd3;
          border-radius: 10px;
          cursor: pointer;
          transition: background .2s, transform .2s, color .2s;
        }
        .db-page-btn:hover:not(:disabled) { background:#ede8e0; color:#1a1a2e; transform: translateY(-1px); }
        .db-page-btn:disabled { opacity: .45; cursor:not-allowed; }

        /* Modals */
        .db-modal-backdrop {
          position: fixed;
          inset: 0;
          background: rgba(0,0,0,0.55);
          backdrop-filter: blur(7px);
          z-index: 1400;
          display:flex;
          align-items:center;
          justify-content:center;
          padding: 12px;
        }
        .db-modal {
          width: min(900px, 96vw);
          max-height: 92vh;
          border-radius: 18px;
          overflow: hidden;
          background: #fff;
          box-shadow: 0 24px 70px rgba(0,0,0,0.35);
          border: 1px solid rgba(255,255,255,0.12);
        }
        .db-modal-head {
          padding: 18px 20px;
          background: linear-gradient(135deg, #0f172a 0%, #1f2937 100%);
          color: #fff;
          position: relative;
          overflow: hidden;
        }
        .db-modal-head::before {
          content:"";
          position:absolute;
          inset:0;
          background-image: radial-gradient(circle, rgba(255,255,255,0.045) 1px, transparent 1px);
          background-size: 24px 24px;
          pointer-events:none;
        }
        .db-modal-head-inner {
          position: relative;
          z-index: 1;
          display:flex;
          align-items:flex-start;
          justify-content: space-between;
          gap: 12px;
        }
        .db-modal-title {
          margin:0;
          font-family: "Lora", Georgia, serif;
          font-size: 16px;
          font-weight: 900;
        }
        .db-modal-sub {
          margin: 2px 0 0;
          color: rgba(255,255,255,0.72);
          font-size: 12.5px;
          font-weight: 300;
        }
        .db-modal-close {
          width: 36px;
          height: 36px;
          border-radius: 10px;
          border: 1px solid rgba(255,255,255,0.18);
          background: rgba(255,255,255,0.06);
          color: #fff;
          cursor: pointer;
          display:flex;
          align-items:center;
          justify-content:center;
          transition: background .2s, border-color .2s, transform .2s;
          flex-shrink: 0;
        }
        .db-modal-close:hover:not(:disabled) { background: rgba(255,255,255,0.10); border-color: rgba(255,255,255,0.26); transform: translateY(-1px); }
        .db-modal-close:disabled { opacity: .5; cursor:not-allowed; }

        .db-modal-body { background:#f5f1eb; padding: 16px; overflow:auto; max-height: calc(92vh - 130px); }
        .db-modal-card { background:#fff; border: 1px solid #ede8e0; border-radius: 16px; padding: 16px; }

        .db-field label {
          display:block;
          font-size: 12px;
          font-weight: 900;
          color: #7a6a5a;
          margin-bottom: 6px;
          letter-spacing: .02em;
        }
        .db-field input {
          width: 100%;
          padding: 10px 12px;
          border-radius: 12px;
          border: 1px solid #e5ddd3;
          background: #faf8f5;
          outline: none;
          font-size: 13.5px;
          color: #1a1a2e;
        }
        .db-field input:focus {
          border-color: rgba(34,197,94,0.55);
          box-shadow: 0 0 0 4px rgba(34,197,94,0.16);
          background: #fff;
        }
        .db-help { margin-top: 6px; font-size: 11.5px; color: #9a8a7a; }

        .db-modal-foot {
          padding: 14px 16px;
          background: #fff;
          border-top: 1px solid rgba(0,0,0,0.06);
          display:flex;
          justify-content: flex-end;
          gap: 10px;
          flex-wrap: wrap;
        }

        .db-btn {
          display:inline-flex;
          align-items:center;
          gap: 7px;
          padding: 10px 14px;
          border-radius: 12px;
          font-size: 13px;
          font-weight: 900;
          cursor: pointer;
          border: 1px solid transparent;
          transition: transform .2s, box-shadow .2s, background .2s, border-color .2s;
          white-space: nowrap;
        }
        .db-btn:hover:not(:disabled) { transform: translateY(-1px); box-shadow: 0 10px 22px rgba(0,0,0,0.10); }
        .db-btn:disabled { opacity: .55; cursor:not-allowed; box-shadow:none; transform:none; }
        .db-btn-secondary { background: #f5f1eb; border-color: #e5ddd3; color: #7a6a5a; }
        .db-btn-secondary:hover:not(:disabled) { background: #ede8e0; color:#1a1a2e; }
        .db-btn-primary { background: #22c55e; color: #052e1b; border-color: rgba(34,197,94,0.35); }
        .db-btn-primary:hover:not(:disabled) { background:#86efac; }

        @keyframes dbSpin { to { transform: rotate(360deg); } }
      `}),(0,l.jsx)(o,{sidebarOpen:p,setSidebarOpen:m}),(0,l.jsx)(n,{title:`Academic Section`}),(0,l.jsx)(`div`,{className:`container-fluid`,children:(0,l.jsxs)(`div`,{className:`row`,children:[(0,l.jsx)(a,{sidebarOpen:p}),(0,l.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto db-main`,children:[h&&(0,l.jsx)(r,{message:`Loading sections...`}),(0,l.jsxs)(`div`,{className:`db-hero`,children:[(0,l.jsx)(`div`,{className:`db-hero-glow`,"aria-hidden":`true`}),(0,l.jsx)(`div`,{className:`db-hero-glow2`,"aria-hidden":`true`}),(0,l.jsxs)(`div`,{className:`db-hero-inner`,children:[(0,l.jsxs)(`div`,{children:[(0,l.jsxs)(`div`,{className:`db-session-badge`,children:[(0,l.jsx)(`span`,{className:`db-session-dot`}),`Sections • School Structure`]}),(0,l.jsxs)(`h1`,{className:`db-greeting`,children:[d(),`, `,(0,l.jsx)(`em`,{children:`Admin.`})]}),(0,l.jsx)(`p`,{className:`db-hero-sub`,children:`Create and manage sections (e.g. Primary, Junior Secondary, Senior Secondary). Sections help you group classes properly.`}),(0,l.jsxs)(`div`,{className:`db-hero-btns`,children:[(0,l.jsxs)(`button`,{className:`db-btn-green`,onClick:()=>I(!0),disabled:T||y!==null,type:`button`,children:[(0,l.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:(0,l.jsx)(`path`,{d:`M8 3v10M3 8h10`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})}),`Add Section`]}),(0,l.jsxs)(`button`,{className:`db-btn-outline`,onClick:()=>K(D),disabled:y!==null||_,type:`button`,children:[(0,l.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,style:{animation:_?`dbSpin 0.8s linear infinite`:`none`},children:[(0,l.jsx)(`path`,{d:`M12 7A5 5 0 112 7`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,l.jsx)(`path`,{d:`M12 3v4h-4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),`Refresh`]})]})]}),(0,l.jsxs)(`div`,{className:`db-hero-stat-card d-none d-md-block`,children:[(0,l.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,marginBottom:16},children:[(0,l.jsx)(`span`,{style:{fontSize:11,fontWeight:600,letterSpacing:`0.14em`,textTransform:`uppercase`,color:`#86efac`},children:`Quick summary`}),(0,l.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:(0,l.jsx)(`path`,{d:`M2 10V6M5 10V4M8 10V7M11 10V3`,stroke:`#64748b`,strokeWidth:`1.5`,strokeLinecap:`round`})})]}),(0,l.jsxs)(`div`,{className:`db-hero-stat-row`,children:[(0,l.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,l.jsx)(`span`,{className:`db-hero-stat-label`,children:`Total sections`}),(0,l.jsx)(`span`,{className:`db-hero-stat-val`,children:_?`…`:Q})]}),(0,l.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,l.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,l.jsx)(`span`,{className:`db-hero-stat-label`,children:`Pagination`}),(0,l.jsxs)(`span`,{className:`db-hero-stat-val`,children:[X,`/`,$]})]})]}),(0,l.jsx)(`div`,{style:{marginTop:14,paddingTop:12,borderTop:`1px solid rgba(255,255,255,0.06)`},children:(0,l.jsx)(`div`,{style:{fontSize:12,color:`#64748b`},children:`Search uses local paging (does not request server).`})})]})]})]}),(0,l.jsxs)(`div`,{className:`db-panel`,children:[(0,l.jsxs)(`div`,{className:`db-panel-head`,children:[(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`p`,{className:`db-panel-title`,children:`Sections`}),(0,l.jsx)(`p`,{className:`db-panel-sub`,children:`Search, create and edit sections.`})]}),(0,l.jsxs)(`div`,{className:`db-toolbar`,children:[(0,l.jsxs)(`div`,{className:`db-input`,title:`Search`,children:[(0,l.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,style:{flexShrink:0},children:[(0,l.jsx)(`circle`,{cx:`7`,cy:`7`,r:`4.5`,stroke:`#9a8a7a`,strokeWidth:`1.4`}),(0,l.jsx)(`path`,{d:`M11 11l3 3`,stroke:`#9a8a7a`,strokeWidth:`1.4`,strokeLinecap:`round`})]}),(0,l.jsx)(`input`,{placeholder:`Search sections…`,value:C,onChange:e=>w(e.target.value),disabled:y!==null}),C.trim()?(0,l.jsx)(`button`,{className:`db-chip-btn`,style:{padding:`6px 10px`,borderRadius:10},onClick:()=>w(``),type:`button`,children:`Clear`}):null]}),(0,l.jsx)(`button`,{className:`db-chip-btn`,onClick:()=>K(D),disabled:y!==null||_,type:`button`,children:`Refresh`}),(0,l.jsx)(`button`,{className:`db-chip-btn`,onClick:()=>E(e=>!e),disabled:y!==null,type:`button`,children:T?`Show Active`:`View Archived`}),T?null:(0,l.jsx)(`button`,{className:`db-chip-btn`,onClick:()=>I(!0),disabled:y!==null,type:`button`,children:`Add Section`})]})]}),(0,l.jsx)(`div`,{style:{overflowX:`auto`},children:(0,l.jsxs)(`table`,{className:`db-table`,children:[(0,l.jsx)(`thead`,{children:(0,l.jsxs)(`tr`,{children:[(0,l.jsx)(`th`,{style:{width:340},children:`Section`}),(0,l.jsx)(`th`,{style:{width:220,textAlign:`right`},children:`Actions`})]})}),(0,l.jsx)(`tbody`,{children:_?(0,l.jsx)(`tr`,{children:(0,l.jsxs)(`td`,{colSpan:2,style:{padding:28,textAlign:`center`,color:`#9a8a7a`},children:[(0,l.jsx)(`span`,{className:`spinner-border spinner-border-sm`}),` `,(0,l.jsx)(`span`,{style:{marginLeft:8},children:`Loading sections…`})]})}):Z.length===0?(0,l.jsx)(`tr`,{children:(0,l.jsxs)(`td`,{colSpan:2,style:{padding:34,textAlign:`center`,color:`#9a8a7a`},children:[(0,l.jsx)(`div`,{style:{fontWeight:900,color:`#1a1a2e`},children:`No sections found`}),(0,l.jsx)(`div`,{style:{marginTop:6},children:`Click “Add section” to create one.`})]})}):Z.map(e=>{let t=G(`sec:archive:${e.id}`),n=G(`sec:restore:${e.id}`);return(0,l.jsxs)(`tr`,{children:[(0,l.jsxs)(`td`,{children:[(0,l.jsx)(`div`,{style:{fontWeight:900,color:`#1a1a2e`},children:e.name}),(0,l.jsxs)(`div`,{style:{fontSize:12,color:`#9a8a7a`},children:[`ID: `,e.id]})]}),(0,l.jsx)(`td`,{style:{textAlign:`right`},children:(0,l.jsxs)(`div`,{className:`db-actions`,children:[(0,l.jsx)(`button`,{className:`db-action-btn db-action-primary`,onClick:()=>ne(e),disabled:T||y!==null,type:`button`,children:`Edit`}),(0,l.jsx)(`button`,{className:`db-action-btn ${T?`db-action-green`:`db-action-danger`}`,onClick:()=>T?ae(e):ie(e),disabled:y!==null,type:`button`,children:T?n?`Restoring...`:`Restore`:t?`Archiving...`:`Archive`})]})})]},e.id)})})]})}),(0,l.jsxs)(`div`,{className:`db-pagination`,children:[(0,l.jsxs)(`div`,{className:`db-page-info`,children:[`Showing `,(0,l.jsx)(`b`,{children:Z.length}),` of `,(0,l.jsx)(`b`,{children:Q}),` • Page `,(0,l.jsx)(`b`,{children:X}),` of `,(0,l.jsx)(`b`,{children:$})]}),(0,l.jsxs)(`div`,{className:`db-page-btns`,children:[(0,l.jsx)(`button`,{className:`db-page-btn`,onClick:()=>O(e=>Math.max(1,e-1)),disabled:X<=1||y!==null,type:`button`,children:`Prev`}),(0,l.jsx)(`button`,{className:`db-page-btn`,onClick:()=>{let e=$;O(t=>Math.min(e,t+1))},disabled:X>=$||y!==null,type:`button`,children:`Next`})]})]})]}),(0,l.jsx)(s,{}),F&&(0,l.jsx)(`div`,{className:`db-modal-backdrop`,onMouseDown:()=>y?null:I(!1),children:(0,l.jsxs)(`div`,{className:`db-modal`,onMouseDown:e=>e.stopPropagation(),children:[(0,l.jsx)(`div`,{className:`db-modal-head`,children:(0,l.jsxs)(`div`,{className:`db-modal-head-inner`,children:[(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`h3`,{className:`db-modal-title`,children:`Add Section`}),(0,l.jsx)(`p`,{className:`db-modal-sub`,children:`Create a new section.`})]}),(0,l.jsx)(`button`,{className:`db-modal-close`,onClick:()=>I(!1),disabled:y!==null,type:`button`,children:`✕`})]})}),(0,l.jsx)(`div`,{className:`db-modal-body`,children:(0,l.jsx)(`div`,{className:`db-modal-card`,children:(0,l.jsxs)(`div`,{className:`db-field`,children:[(0,l.jsx)(`label`,{children:`Name *`}),(0,l.jsx)(`input`,{placeholder:`e.g. Junior Secondary`,value:z,onChange:e=>B(e.target.value),disabled:G(`sec:create`)}),(0,l.jsx)(`div`,{className:`db-help`,children:`Examples: Primary, Junior, Senior.`})]})})}),(0,l.jsxs)(`div`,{className:`db-modal-foot`,children:[(0,l.jsx)(`button`,{className:`db-btn db-btn-secondary`,onClick:()=>I(!1),disabled:y!==null,type:`button`,children:`Cancel`}),(0,l.jsx)(`button`,{className:`db-btn db-btn-primary`,onClick:te,disabled:y!==null,type:`button`,children:G(`sec:create`)?(0,l.jsxs)(l.Fragment,{children:[(0,l.jsx)(`span`,{className:`spinner-border spinner-border-sm`,role:`status`,style:{width:14,height:14}}),`Saving…`]}):`Save Section`})]})]})}),L&&V&&(0,l.jsx)(`div`,{className:`db-modal-backdrop`,onMouseDown:()=>y?null:R(!1),children:(0,l.jsxs)(`div`,{className:`db-modal`,onMouseDown:e=>e.stopPropagation(),children:[(0,l.jsx)(`div`,{className:`db-modal-head`,children:(0,l.jsxs)(`div`,{className:`db-modal-head-inner`,children:[(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`h3`,{className:`db-modal-title`,children:`Edit Section`}),(0,l.jsx)(`p`,{className:`db-modal-sub`,children:`Update section name.`})]}),(0,l.jsx)(`button`,{className:`db-modal-close`,onClick:()=>R(!1),disabled:y!==null,type:`button`,children:`✕`})]})}),(0,l.jsx)(`div`,{className:`db-modal-body`,children:(0,l.jsx)(`div`,{className:`db-modal-card`,children:(0,l.jsxs)(`div`,{className:`db-field`,children:[(0,l.jsx)(`label`,{children:`Name *`}),(0,l.jsx)(`input`,{value:U,onChange:e=>W(e.target.value),disabled:G(`sec:update:${V}`)})]})})}),(0,l.jsxs)(`div`,{className:`db-modal-foot`,children:[(0,l.jsx)(`button`,{className:`db-btn db-btn-secondary`,onClick:()=>R(!1),disabled:y!==null,type:`button`,children:`Cancel`}),(0,l.jsx)(`button`,{className:`db-btn db-btn-primary`,onClick:re,disabled:y!==null,type:`button`,children:G(`sec:update:${V}`)?(0,l.jsxs)(l.Fragment,{children:[(0,l.jsx)(`span`,{className:`spinner-border spinner-border-sm`,role:`status`,style:{width:14,height:14}}),`Saving…`]}):`Update Section`})]})]})})]})]})})]})}export{p as default};