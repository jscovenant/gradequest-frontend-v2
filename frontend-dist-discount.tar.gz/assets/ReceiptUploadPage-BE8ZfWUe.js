import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{b as t,p as n,x as r}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as i,E as a,P as o,d as s,f as c,l,u}from"./index-D6TxbaCx.js";var d=e(),f=n();function p(){let{search:e}=t();return(0,d.useMemo)(()=>new URLSearchParams(e),[e])}function m(e){let t=(e||``).toLowerCase();return t===`accepted`||t===`approved`?(0,f.jsxs)(`span`,{className:`badge bg-success-subtle text-success fw-bold px-2 py-1`,children:[(0,f.jsx)(`i`,{className:`bi bi-check-circle-fill me-1`}),`Verified & Approved`]}):t===`rejected`?(0,f.jsxs)(`span`,{className:`badge bg-danger-subtle text-danger fw-bold px-2 py-1`,children:[(0,f.jsx)(`i`,{className:`bi bi-x-circle-fill me-1`}),`Declined`]}):(0,f.jsxs)(`span`,{className:`badge bg-warning-subtle text-warning fw-bold px-2 py-1`,children:[(0,f.jsx)(`i`,{className:`bi bi-clock-history me-1`}),`Under Bursary Review`]})}function h(e){let t=(e||``).toLowerCase();return t.endsWith(`.jpg`)||t.endsWith(`.jpeg`)||t.endsWith(`.png`)||t.endsWith(`.webp`)}var g=`gq_receipts_last_reg_no`;function _(){let e=r(),t=p(),{showSuccess:n,showError:_,showInfo:v}=l(),[y,b]=(0,d.useState)(!1),[x,S]=(0,d.useState)(!0),[C,w]=(0,d.useState)(!1),[T,E]=(0,d.useState)(t.get(`reg_no`)||localStorage.getItem(g)||``),[D,O]=(0,d.useState)([]),[k,A]=(0,d.useState)(`online`),[j,M]=(0,d.useState)(``),[N,P]=(0,d.useState)([]),[F,I]=(0,d.useState)([]),[L,R]=(0,d.useState)(``);(0,d.useEffect)(()=>{o.get(`/parent/children`).then(e=>{let t=e.data?.children||[];if(O(t),!T&&t.length>0){let e=t[0].reg_no;e&&E(e)}}).catch(()=>{})},[]);let z=(0,d.useMemo)(()=>!!T.trim()&&N.length>0&&!C,[T,N.length,C]),B=async e=>{let t=(e??T).trim();if(!t){S(!1);return}S(!0);try{let e=await o.get(`/my-receipts?reg_no=${encodeURIComponent(t)}`);I(e.data?.receipts||[]),R(e.data?.student?.name||``)}catch(e){console.error(e),_(e?.response?.data?.message||`Failed to load receipts.`)}finally{S(!1)}};(0,d.useEffect)(()=>{let t=T.trim();if(t){localStorage.setItem(g,t);let n=new URLSearchParams(window.location.search);n.get(`reg_no`)!==t&&(n.set(`reg_no`,t),e({search:n.toString()},{replace:!0}))}},[T]),(0,d.useEffect)(()=>{B(T)},[T]);let V=e=>{let t=Array.from(e.target.files||[]);if(t.length){if(t.find(e=>e.size>5*1024*1024)){_(`One of the files is larger than 5MB. Please upload a smaller document.`);return}P(t)}},H=e=>{P(t=>t.filter((t,n)=>n!==e))};return(0,f.jsxs)(f.Fragment,{children:[(0,f.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');

        .p-up-main {
          background: #F8FAFC;
          min-height: 100vh;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          padding: calc(66px + 24px) 28px 40px !important;
        }

        @media (max-width: 767.98px) {
          .p-up-main {
            padding: calc(66px + 16px) 14px 36px !important;
          }
          .p-up-hero {
            padding: 20px 18px !important;
            border-radius: 14px !important;
            margin-bottom: 16px !important;
          }
          .p-up-title {
            font-size: 20px !important;
          }
          .p-up-sub {
            font-size: 12.5px !important;
          }
        }

        .p-up-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 18px;
          padding: 32px 36px;
          color: #FFFFFF;
          margin-bottom: 24px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
          position: relative;
          overflow: hidden;
        }

        .p-up-hero::before {
          content: '';
          position: absolute;
          inset: 0;
          background-image:
            linear-gradient(rgba(255, 255, 255, 0.035) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255, 255, 255, 0.035) 1px, transparent 1px);
          background-size: 32px 32px;
          pointer-events: none;
        }

        .p-up-hero-glow {
          position: absolute;
          top: -40px;
          right: -40px;
          width: 320px;
          height: 320px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.2) 0%, transparent 65%);
          pointer-events: none;
        }

        .p-up-hero-inner {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: center;
          justify-content: space-between;
          flex-wrap: wrap;
          gap: 20px;
        }

        .p-up-badge {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.20);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius: 100px;
          padding: 4px 12px;
          margin-bottom: 12px;
        }

        .p-up-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #10B981;
          box-shadow: 0 0 6px #10B981;
        }

        .p-up-title {
          font-size: 26px;
          font-weight: 800;
          color: #FFFFFF;
          line-height: 1.1;
          margin-bottom: 8px;
        }

        .p-up-title em {
          font-style: normal;
          color: #FBBF24;
        }

        .p-up-sub {
          font-size: 13.5px;
          color: #CBD5E1;
          line-height: 1.6;
          max-width: 620px;
          margin-bottom: 0;
        }

        .p-card {
          background: #FFFFFF;
          border: 1px solid rgba(15, 39, 68, 0.08);
          border-radius: 18px;
          box-shadow: 0 4px 20px rgba(15, 39, 68, 0.06);
          overflow: hidden;
        }

        .p-card-head {
          padding: 18px 24px;
          border-bottom: 1px solid #E2E8F0;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
        }
      `}),(0,f.jsx)(c,{sidebarOpen:y,setSidebarOpen:b}),(0,f.jsx)(i,{title:`Upload Payment Receipt - SchoolProfit`}),(0,f.jsx)(`div`,{className:`container-fluid`,children:(0,f.jsxs)(`div`,{className:`row`,children:[(0,f.jsx)(s,{sidebarOpen:y,setSidebarOpen:b}),(0,f.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto gq-app-main p-up-main d-flex flex-column min-vh-100`,children:[x&&(0,f.jsx)(a,{message:`Loading receipts...`}),(0,f.jsxs)(`div`,{className:`p-up-hero`,children:[(0,f.jsx)(`div`,{className:`p-up-hero-glow`}),(0,f.jsxs)(`div`,{className:`p-up-hero-inner`,children:[(0,f.jsxs)(`div`,{children:[(0,f.jsxs)(`div`,{className:`p-up-badge`,children:[(0,f.jsx)(`span`,{className:`p-up-dot`}),`Parent Portal · Bursary Clearance`]}),(0,f.jsxs)(`h1`,{className:`p-up-title`,children:[`Upload Payment Receipt `,L?(0,f.jsxs)(`span`,{children:[`— `,(0,f.jsx)(`em`,{children:L})]}):``]}),(0,f.jsx)(`p`,{className:`p-up-sub`,children:`Upload proof of direct bank transfer, deposit slip, or electronic receipt for school review and clearance.`})]}),(0,f.jsxs)(`div`,{className:`d-flex gap-2 flex-wrap`,children:[(0,f.jsxs)(`button`,{type:`button`,className:`btn btn-outline-light rounded-pill px-4 fw-bold`,onClick:()=>e(`/parent/children`),children:[(0,f.jsx)(`i`,{className:`bi bi-arrow-left me-1`}),`My Children`]}),(0,f.jsxs)(`button`,{type:`button`,className:`btn btn-warning rounded-pill px-4 fw-bold`,style:{color:`#0F2744`,background:`#FBBF24`},onClick:()=>{v(`Refreshing receipt history...`),B()},children:[(0,f.jsx)(`i`,{className:`bi bi-arrow-clockwise me-1`}),`Refresh`]})]})]})]}),(0,f.jsxs)(`div`,{className:`row g-4 mb-5`,children:[(0,f.jsx)(`div`,{className:`col-lg-5`,children:(0,f.jsxs)(`div`,{className:`p-card`,children:[(0,f.jsx)(`div`,{className:`p-card-head`,children:(0,f.jsxs)(`div`,{children:[(0,f.jsxs)(`h2`,{className:`fs-6 fw-bold mb-0 text-dark`,children:[(0,f.jsx)(`i`,{className:`bi bi-cloud-arrow-up-fill me-2 text-primary`}),`Submit New Proof of Payment`]}),(0,f.jsx)(`small`,{className:`text-muted`,children:`Accepted formats: JPG, PNG, PDF (Max 5MB)`})]})}),(0,f.jsxs)(`div`,{className:`p-4`,children:[D.length>0&&(0,f.jsxs)(`div`,{className:`mb-3`,children:[(0,f.jsx)(`label`,{className:`form-label fw-bold small text-muted text-uppercase`,children:`Select Child / Ward`}),(0,f.jsxs)(`select`,{className:`form-select rounded-3 py-2`,value:T,onChange:e=>E(e.target.value),children:[(0,f.jsx)(`option`,{value:``,children:`-- Choose student --`}),D.map(e=>(0,f.jsxs)(`option`,{value:e.reg_no||``,children:[e.name||`${e.surname||``} ${e.firstname||``}`.trim(),` (`,e.reg_no||`No Reg No`,`)`]},e.id))]})]}),(0,f.jsxs)(`div`,{className:`mb-3`,children:[(0,f.jsx)(`label`,{className:`form-label fw-bold small text-muted text-uppercase`,children:`Student Admission / Reg No`}),(0,f.jsx)(`input`,{className:`form-control rounded-3 py-2`,value:T,onChange:e=>E(e.target.value),placeholder:`e.g. REG/2026/001`})]}),(0,f.jsxs)(`div`,{className:`mb-3`,children:[(0,f.jsx)(`label`,{className:`form-label fw-bold small text-muted text-uppercase`,children:`Payment Channel / Method`}),(0,f.jsxs)(`select`,{className:`form-select rounded-3 py-2`,value:k,onChange:e=>A(e.target.value),children:[(0,f.jsx)(`option`,{value:`online`,children:`Bank Transfer / Electronic Deposit`}),(0,f.jsx)(`option`,{value:`cash`,children:`Direct Bank Teller Deposit / Cash`})]})]}),(0,f.jsxs)(`div`,{className:`mb-3`,children:[(0,f.jsxs)(`label`,{className:`form-label fw-bold small text-muted text-uppercase`,children:[`Amount Paid (₦) `,(0,f.jsx)(`span`,{className:`text-muted fw-normal`,children:`(optional)`})]}),(0,f.jsx)(`input`,{type:`number`,className:`form-control rounded-3 py-2`,value:j,onChange:e=>M(e.target.value),placeholder:`e.g. 50000`})]}),(0,f.jsxs)(`div`,{className:`mb-3`,children:[(0,f.jsxs)(`label`,{className:`form-label fw-bold small text-muted text-uppercase`,children:[`Attach Receipt Evidence `,(0,f.jsx)(`span`,{className:`text-danger`,children:`*`})]}),(0,f.jsx)(`input`,{className:`form-control rounded-3 py-2`,type:`file`,multiple:!0,accept:`.jpg,.jpeg,.png,.pdf`,onChange:V})]}),N.length>0&&(0,f.jsxs)(`div`,{className:`p-3 rounded-3 mb-3 bg-light border`,children:[(0,f.jsxs)(`div`,{className:`fw-bold small text-dark mb-2`,children:[`Attached Files (`,N.length,`):`]}),(0,f.jsx)(`div`,{className:`d-flex flex-column gap-2`,children:N.map((e,t)=>(0,f.jsxs)(`div`,{className:`d-flex align-items-center justify-content-between bg-white p-2 rounded border`,children:[(0,f.jsxs)(`div`,{className:`small`,children:[(0,f.jsx)(`div`,{className:`fw-bold text-truncate`,style:{maxWidth:220},children:e.name}),(0,f.jsxs)(`div`,{className:`text-muted`,style:{fontSize:`11px`},children:[(e.size/(1024*1024)).toFixed(2),` MB`]})]}),(0,f.jsx)(`button`,{type:`button`,className:`btn btn-sm btn-outline-danger rounded-pill px-2 py-0`,onClick:()=>H(t),children:`×`})]},t))})]}),(0,f.jsxs)(`div`,{className:`d-flex gap-2 pt-2`,children:[(0,f.jsx)(`button`,{type:`button`,className:`btn btn-outline-secondary rounded-pill px-3`,onClick:()=>{P([]),M(``)},disabled:C,children:`Clear`}),(0,f.jsx)(`button`,{type:`button`,className:`btn btn-primary rounded-pill px-4 fw-bold ms-auto`,onClick:async()=>{if(!z)return;let e=T.trim();if(!e){_(`Student Admission / Reg No is required.`);return}let t=new FormData;t.append(`reg_no`,e),t.append(`payment_method`,k),j.trim()&&t.append(`amount`,j.trim()),N.forEach(e=>t.append(`receipts[]`,e)),w(!0);try{await o.post(`/upload-receipts`,t,{headers:{"Content-Type":`multipart/form-data`}}),n(`Receipt uploaded successfully. The school bursary will review and confirm.`),P([]),M(``),await B(e)}catch(e){console.error(e),_(e?.response?.data?.message||`Upload failed. Please try again.`)}finally{w(!1)}},disabled:!z,children:C?(0,f.jsxs)(f.Fragment,{children:[(0,f.jsx)(`span`,{className:`spinner-border spinner-border-sm me-2`}),`Uploading Proof...`]}):(0,f.jsxs)(f.Fragment,{children:[(0,f.jsx)(`i`,{className:`bi bi-cloud-arrow-up-fill me-1`}),`Submit Receipt`]})})]})]})]})}),(0,f.jsx)(`div`,{className:`col-lg-7`,children:(0,f.jsxs)(`div`,{className:`p-card`,children:[(0,f.jsxs)(`div`,{className:`p-card-head`,children:[(0,f.jsxs)(`div`,{children:[(0,f.jsxs)(`h2`,{className:`fs-6 fw-bold mb-0 text-dark`,children:[(0,f.jsx)(`i`,{className:`bi bi-clock-history me-2 text-primary`}),`Receipt Submissions & Verification History`]}),(0,f.jsx)(`small`,{className:`text-muted`,children:`Track clearance reviews from school bursary`})]}),(0,f.jsxs)(`span`,{className:`badge bg-primary rounded-pill px-3 py-1`,children:[F.length,` submission`,F.length===1?``:`s`]})]}),(0,f.jsx)(`div`,{className:`p-4`,children:F.length===0?(0,f.jsxs)(`div`,{className:`text-center py-5 text-muted`,children:[(0,f.jsx)(`i`,{className:`bi bi-receipt-cutoff fs-1 d-block mb-2 text-secondary`}),`No receipts uploaded yet for this student.`]}):(0,f.jsx)(`div`,{className:`d-flex flex-column gap-3`,children:F.map(e=>(0,f.jsxs)(`div`,{className:`p-3 border rounded-4 bg-light`,children:[(0,f.jsxs)(`div`,{className:`d-flex flex-wrap justify-content-between gap-2 align-items-center mb-2`,children:[(0,f.jsxs)(`div`,{children:[(0,f.jsxs)(`div`,{className:`fw-bold text-dark fs-6`,children:[`Receipt #`,e.id]}),(0,f.jsxs)(`div`,{className:`text-muted small`,children:[`Channel: `,(0,f.jsx)(`strong`,{children:String(e.payment_method).toUpperCase()}),` • Submitted:`,` `,e.created_at?new Date(e.created_at).toLocaleString():`—`]})]}),(0,f.jsx)(`div`,{children:m(e.status)})]}),(0,f.jsx)(`div`,{className:`row g-2 mt-2`,children:e.files?.map((e,t)=>(0,f.jsx)(`div`,{className:`col-sm-6`,children:(0,f.jsx)(`div`,{className:`p-2 bg-white rounded-3 border`,children:h(e)?(0,f.jsxs)(`a`,{href:e,target:`_blank`,rel:`noreferrer`,className:`d-block text-decoration-none`,children:[(0,f.jsx)(`img`,{src:e,alt:`receipt attachment`,className:`w-100 rounded-2 object-fit-cover`,style:{height:140}}),(0,f.jsx)(`small`,{className:`text-muted d-block mt-1 text-center`,children:`Click to view full image`})]}):(0,f.jsxs)(`div`,{className:`d-flex align-items-center justify-content-between p-2`,children:[(0,f.jsxs)(`div`,{className:`d-flex align-items-center gap-2`,children:[(0,f.jsx)(`i`,{className:`bi bi-file-earmark-pdf fs-3 text-danger`}),(0,f.jsx)(`div`,{className:`small fw-bold`,children:`PDF Document`})]}),(0,f.jsx)(`a`,{className:`btn btn-sm btn-outline-dark rounded-pill px-3`,href:e,target:`_blank`,rel:`noreferrer`,children:`View PDF`})]})})},t))})]},e.id))})})]})})]}),(0,f.jsx)(u,{})]})]})})]})}export{_ as default};