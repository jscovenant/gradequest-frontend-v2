import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{p as t,x as n}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as r,E as i,P as a,d as o,f as s,l as ee,u as c}from"./index-D6TxbaCx.js";var l=e(),u=t();function d(e){return[e.firstname,e.surname].filter(Boolean).join(` `)||`Unnamed student`}function f(e){let t=String(e||`draft`).toLowerCase();return t===`draft`?`Still entering`:t===`computed`?`Ready for review`:t===`approved`?`Approved`:t===`published`?`Published`:`Needs attention`}function p(e){let t=String(e||`draft`).toLowerCase();return t===`published`?`published`:t===`approved`?`approved`:t===`computed`?`computed`:`draft`}function m(e){if(!e)return`Not yet`;let t=new Date(e);return Number.isNaN(t.getTime())?`Not yet`:t.toLocaleDateString(void 0,{day:`2-digit`,month:`short`,year:`numeric`})}function h(e){let t=e?.review,n=Number(t?.total_students||0),r=Number(t?.completed_students||0);return n>0?Math.min(100,Math.round(r/n*100)):0}function g(){let e=n(),{showSuccess:t,showError:g,showWarning:_}=ee(),[v,y]=(0,l.useState)(!1),[b,x]=(0,l.useState)(!0),[S,C]=(0,l.useState)(!1),[w,T]=(0,l.useState)(!1),[E,D]=(0,l.useState)(null),[O,k]=(0,l.useState)(null),[A,j]=(0,l.useState)([]),[M,N]=(0,l.useState)(null),[P,F]=(0,l.useState)([]),[I,te]=(0,l.useState)([]),[ne,L]=(0,l.useState)([]),[R,z]=(0,l.useState)(``),[B,V]=(0,l.useState)(``),[H,U]=(0,l.useState)(`all`),[W,G]=(0,l.useState)(``),K=(0,l.useMemo)(()=>A.find(e=>e.id===M)||null,[A,M]),q=(0,l.useMemo)(()=>{let e=W.trim().toLowerCase();return e?P.filter(t=>`${t.firstname} ${t.surname} ${t.reg_no}`.toLowerCase().includes(e)):P},[P,W]),J=P.filter(e=>e.status===`completed`).length,Y=Math.max(0,P.length-J),X=h(K);(0,l.useEffect)(()=>{let e=!0;async function t(){x(!0);try{let[t,n,r]=await Promise.allSettled([a.get(`/current-session-term`),a.get(`/fterms`),a.get(`/facademic-sessions`)]);if(!e)return;let i=``,o=``;t.status===`fulfilled`&&(i=t.value.data?.term||``,o=t.value.data?.session||``,z(i),V(o)),n.status===`fulfilled`&&te(n.value.data?.data??n.value.data??[]),r.status===`fulfilled`&&L((r.value.data?.data??r.value.data??[]).map(e=>({id:e.id,name:e.name??e.session??``}))),await Z(i,o,`all`)}catch(e){k(e?.response?.data?.message||`Unable to load result review data.`)}finally{e&&x(!1)}}return t(),()=>{e=!1}},[]),(0,l.useEffect)(()=>{if(!M){F([]);return}Q(M)},[M]);async function Z(e=R,t=B,n=H){C(!0),k(null);try{let r={};e&&(r.term=e),t&&(r.session=t),n&&n!==`all`&&(r.status=n);let{data:i}=await a.get(`/admin/result-batches`,{params:r}),o=Array.isArray(i?.data)?i.data:[],s=await Promise.all(o.map(async e=>{try{let t=await a.get(`/result-batches/${e.id}/review-summary`);return{...e,...t.data.batch,review:t.data.review}}catch{return e}}));j(s),N(e=>e&&s.some(t=>t.id===e)?e:s[0]?.id??null)}catch(e){j([]),N(null),k(e?.response?.data?.message||`Unable to load result batches.`)}finally{C(!1)}}async function Q(e){T(!0),k(null);try{let{data:t}=await a.get(`/result-batches/${e}/students`);F(Array.isArray(t?.data)?t.data:[])}catch(e){F([]),k(e?.response?.data?.message||`Unable to load students in this result batch.`)}finally{T(!1)}}async function re(){if(M)try{let e=await a.get(`/result-batches/${M}/review-summary`);j(t=>t.map(t=>t.id===M?{...t,...e.data.batch,review:e.data.review}:t)),await Q(M)}catch{await Z()}}async function $(e){if(K){if(e===`approve`&&!K.review?.can_approve){_?.(`This result is not ready for approval. Check missing students or serious alerts first.`);return}if(e===`publish`&&!K.review?.can_publish){_?.(`This result is not ready to publish yet.`);return}D(e);try{await a.post(`/result-batches/${K.id}/${e}`),t?.(e===`compute`?`Result totals and positions updated.`:e===`approve`?`Result approved successfully.`:e===`publish`?`Result published for parents and students.`:`Result reopened for correction.`),await re()}catch(t){g?.(t?.response?.data?.message||`Unable to ${e} this result.`)}finally{D(null)}}}function ie(t){K&&e(`/students/results/show?${new URLSearchParams({student_id:String(t.id),class_id:String(K.class_id),term:String(K.term),session:String(K.session),school_id:String(K.school_id)}).toString()}`,{state:{studentId:t.id,classId:K.class_id,term:K.term,session:K.session,schoolId:K.school_id}})}return(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');
        .rr-main {
          min-height: 100vh;
          margin-left: 280px;
          width: calc(100% - 280px);
          padding: max(96px, calc(78px + env(safe-area-inset-top))) 28px 40px;
          background: #F8FAFC;
          color: #0F172A;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
        }
        @media(max-width: 1199px) {
          .rr-main {
            margin-left: 0;
            width: 100%;
            padding: max(88px, calc(72px + env(safe-area-inset-top))) 16px 32px;
          }
        }
        .rr-shell { max-width: 100%; margin: 0 auto; }
        .rr-hero {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 24px;
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 18px;
          padding: 32px 36px;
          color: #fff;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
          position: relative;
          overflow: hidden;
        }
        .rr-hero-glow {
          position: absolute;
          top: -60px;
          right: -60px;
          width: 320px;
          height: 320px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.15) 0%, transparent 65%);
          pointer-events: none;
        }
        .rr-hero>* { position: relative; z-index: 1; }
        .rr-eyebrow {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.20);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius: 100px;
          padding: 4px 12px;
          margin-bottom: 12px;
        }
        .rr-title {
          font-size: 26px;
          font-weight: 800;
          line-height: 1.1;
          margin: 0 0 8px;
          color: #fff;
        }
        .rr-sub {
          max-width: 720px;
          margin: 0;
          color: #CBD5E1;
          font-size: 13.5px;
          line-height: 1.6;
        }
        .rr-hero-actions { display: flex; gap: 10px; flex-wrap: wrap; justify-content: flex-end; }
        .rr-btn {
          border: 0;
          border-radius: 10px;
          padding: 9px 16px;
          font-weight: 700;
          font-size: 13px;
          display: inline-flex;
          align-items: center;
          gap: 8px;
          min-height: 40px;
          cursor: pointer;
          transition: all 0.2s ease;
          white-space: nowrap;
        }
        .rr-btn:hover { transform: translateY(-1px); }
        .rr-btn:disabled { opacity: 0.55; cursor: not-allowed; transform: none; }
        .rr-btn-gold { background: #D97706; color: #FFFFFF; }
        .rr-btn-gold:hover { background: #B45309; }
        .rr-btn-dark { background: #0F2744; color: #fff; }
        .rr-btn-dark:hover { background: #1E3A8A; }
        .rr-btn-soft { background: #F1F5F9; color: #0F2744; border: 1px solid #E2E8F0; }
        .rr-btn-soft:hover { background: #E2E8F0; }
        .rr-btn-light { background: rgba(255,255,255,0.10); color: #fff; border: 1px solid rgba(255,255,255,0.20); }
        .rr-btn-light:hover { background: rgba(255,255,255,0.18); color: #fff; }
        .rr-filter { display: grid; grid-template-columns: repeat(4, minmax(0,1fr)); gap: 12px; margin: 20px 0; }
        .rr-field { background: #fff; border: 1px solid #E2E8F0; border-radius: 12px; padding: 10px 14px; box-shadow: 0 2px 8px rgba(15,39,68,0.02); }
        .rr-label { display: block; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; color: #64748B; margin-bottom: 6px; }
        .rr-select, .rr-input { width: 100%; border: 0; outline: 0; background: transparent; color: #0F2744; font-weight: 700; font-size: 13.5px; min-height: 24px; }
        .rr-grid { display: grid; grid-template-columns: minmax(310px, 390px) minmax(0, 1fr); gap: 20px; align-items: start; }
        .rr-panel { background: #fff; border: 1px solid #E2E8F0; border-radius: 16px; box-shadow: 0 4px 16px rgba(15,39,68,0.03); overflow: hidden; }
        .rr-panel-head { display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 18px 20px; border-bottom: 1px solid #E2E8F0; }
        .rr-panel-title { margin: 0; color: #0F2744; font-size: 16px; font-weight: 800; }
        .rr-panel-sub { margin: 2px 0 0; color: #64748B; font-size: 12px; }
        .rr-batch-list { padding: 14px; display: flex; flex-direction: column; gap: 10px; max-height: 720px; overflow-y: auto; }
        .rr-batch-card { width: 100%; text-align: left; border: 1px solid #E2E8F0; background: #fff; border-radius: 12px; padding: 14px 16px; cursor: pointer; transition: all 0.2s ease; }
        .rr-batch-card:hover, .rr-batch-card.active { border-color: #D97706; box-shadow: 0 4px 16px rgba(217,119,6,0.10); transform: translateY(-1px); }
        .rr-batch-top { display: flex; align-items: flex-start; justify-content: space-between; gap: 10px; }
        .rr-class { font-weight: 800; color: #0F2744; font-size: 14.5px; margin: 0; }
        .rr-meta { color: #64748B; font-size: 12px; margin: 4px 0 0; }
        .rr-badge { display: inline-flex; align-items: center; padding: 4px 10px; border-radius: 999px; font-size: 10.5px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.04em; }
        .rr-badge.draft { background: #FEF3C7; color: #92400E; }
        .rr-badge.computed { background: #EEF2FF; color: #3730A3; }
        .rr-badge.approved { background: #F3E8FF; color: #6B21A8; }
        .rr-badge.published { background: #DCFCE7; color: #166534; }
        .rr-mini-progress { margin-top: 12px; }
        .rr-progress-line { display: flex; align-items: center; justify-content: space-between; color: #64748B; font-size: 11.5px; font-weight: 700; margin-bottom: 6px; }
        .rr-track { height: 6px; border-radius: 999px; background: #E2E8F0; overflow: hidden; }
        .rr-fill { height: 100%; border-radius: 999px; background: linear-gradient(90deg, #D97706, #FBBF24); }
        .rr-detail-head { padding: 20px 22px; border-bottom: 1px solid #E2E8F0; display: grid; grid-template-columns: minmax(0,1fr) auto; gap: 18px; align-items: center; }
        .rr-detail-title { font-size: 20px; font-weight: 800; color: #0F2744; margin: 0; }
        .rr-detail-sub { color: #64748B; font-size: 13px; margin: 4px 0 0; }
        .rr-kpis { display: grid; grid-template-columns: repeat(4, minmax(0,1fr)); gap: 12px; padding: 16px 20px; border-bottom: 1px solid #E2E8F0; background: #F8FAFC; }
        .rr-kpi { background: #fff; border: 1px solid #E2E8F0; border-radius: 12px; padding: 14px; }
        .rr-kpi-label { font-size: 11px; color: #64748B; text-transform: uppercase; font-weight: 700; letter-spacing: 0.04em; margin: 0 0 6px; }
        .rr-kpi-value { font-size: 22px; color: #0F2744; font-weight: 800; margin: 0; }
        .rr-status-note { margin: 16px 20px 0; padding: 12px 14px; border-radius: 12px; background: #EFF6FF; border: 1px solid #BFDBFE; color: #1E40AF; font-size: 13px; line-height: 1.6; display: flex; gap: 10px; align-items: flex-start; }
        .rr-action-row { display: flex; gap: 10px; flex-wrap: wrap; padding: 16px 20px; border-bottom: 1px solid #E2E8F0; }
        .rr-student-toolbar { display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 16px 20px; border-bottom: 1px solid #E2E8F0; }
        .rr-search { width: min(360px, 100%); border: 1px solid #E2E8F0; border-radius: 10px; padding: 10px 14px; font-size: 13px; outline: 0; background: #F8FAFC; color: #0F2744; font-weight: 600; }
        .rr-search:focus { border-color: #D97706; background: #fff; }
        .rr-table-wrap { overflow-x: auto; }
        .rr-table { width: 100%; border-collapse: separate; border-spacing: 0; min-width: 760px; }
        .rr-table th { background: #F8FAFC; color: #64748B; text-transform: uppercase; font-size: 11px; letter-spacing: 0.04em; font-weight: 700; padding: 12px 16px; border-bottom: 1px solid #E2E8F0; }
        .rr-table td { padding: 14px 16px; border-bottom: 1px solid #E2E8F0; font-size: 13px; color: #334155; vertical-align: middle; }
        .rr-student-name { font-weight: 700; color: #0F2744; }
        .rr-muted { color: #64748B; font-size: 12px; }
        .rr-student-status { display: inline-flex; align-items: center; gap: 6px; border-radius: 999px; padding: 4px 10px; font-size: 11px; font-weight: 700; text-transform: uppercase; }
        .rr-student-status.completed { background: #DCFCE7; color: #166534; }
        .rr-student-status.pending { background: #FEF3C7; color: #92400E; }
        .rr-empty { padding: 40px 20px; text-align: center; color: #64748B; }
        .rr-empty i { font-size: 32px; color: #94A3B8; display: block; margin-bottom: 8px; }
        .rr-error { margin: 0 0 14px; padding: 12px 14px; border-radius: 12px; background: #FEE2E2; border: 1px solid #FECACA; color: #991B1B; font-size: 13px; display: flex; gap: 8px; align-items: center; }
        .rr-skeleton { height: 12px; border-radius: 999px; background: linear-gradient(90deg, #E2E8F0, #F8FAFC, #E2E8F0); background-size: 220% 100%; animation: rrSkel 1.1s infinite linear; }
        @keyframes rrSkel { to { background-position: -220% 0; } }
        @media(max-width: 991px) { .rr-grid { grid-template-columns: 1fr; } .rr-filter { grid-template-columns: repeat(2, minmax(0, 1fr)); } .rr-detail-head { grid-template-columns: 1fr; } .rr-kpis { grid-template-columns: repeat(2, minmax(0, 1fr)); } }
        @media(max-width: 640px) { .rr-hero { align-items: flex-start; flex-direction: column; padding: 22px; } .rr-filter { grid-template-columns: 1fr; } .rr-kpis { grid-template-columns: 1fr; } .rr-student-toolbar { align-items: flex-start; flex-direction: column; } .rr-action-row .rr-btn { width: 100%; justify-content: center; } .rr-main { padding-left: 14px; padding-right: 14px; } }
      `}),(0,u.jsx)(s,{sidebarOpen:v,setSidebarOpen:y}),(0,u.jsx)(r,{title:`Result Review`}),(0,u.jsx)(`div`,{className:`container-fluid`,children:(0,u.jsxs)(`div`,{className:`row`,children:[(0,u.jsx)(o,{sidebarOpen:v,setSidebarOpen:y}),(0,u.jsxs)(`main`,{className:`rr-main d-flex flex-column`,children:[b&&(0,u.jsx)(i,{message:`Preparing result review...`}),(0,u.jsxs)(`div`,{className:`rr-shell`,children:[(0,u.jsxs)(`section`,{className:`rr-hero`,children:[(0,u.jsx)(`div`,{className:`rr-hero-glow`}),(0,u.jsxs)(`div`,{children:[(0,u.jsxs)(`div`,{className:`rr-eyebrow`,children:[(0,u.jsx)(`i`,{className:`bi bi-clipboard-check`}),` Result Review Center`]}),(0,u.jsx)(`h1`,{className:`rr-title`,children:`Review student results before release.`}),(0,u.jsx)(`p`,{className:`rr-sub`,children:`Open a class result, check completion, preview each student's report card, review the broadsheet, then approve and publish when everything is correct.`})]}),(0,u.jsxs)(`div`,{className:`rr-hero-actions`,children:[(0,u.jsxs)(`button`,{className:`rr-btn rr-btn-light`,onClick:()=>e(`/students/results/batch`),children:[(0,u.jsx)(`i`,{className:`bi bi-plus-circle`}),` Prepare result`]}),(0,u.jsxs)(`button`,{className:`rr-btn rr-btn-gold`,onClick:()=>e(`/results/design`),children:[(0,u.jsx)(`i`,{className:`bi bi-palette`}),` Result design`]})]})]}),(0,u.jsxs)(`section`,{className:`rr-filter`,children:[(0,u.jsxs)(`label`,{className:`rr-field`,children:[(0,u.jsx)(`span`,{className:`rr-label`,children:`Term`}),(0,u.jsxs)(`select`,{className:`rr-select`,value:R,onChange:e=>z(e.target.value),children:[(0,u.jsx)(`option`,{value:``,children:`All terms`}),I.map(e=>(0,u.jsx)(`option`,{value:e.name,children:e.name},e.id))]})]}),(0,u.jsxs)(`label`,{className:`rr-field`,children:[(0,u.jsx)(`span`,{className:`rr-label`,children:`Session`}),(0,u.jsxs)(`select`,{className:`rr-select`,value:B,onChange:e=>V(e.target.value),children:[(0,u.jsx)(`option`,{value:``,children:`All sessions`}),ne.map(e=>(0,u.jsx)(`option`,{value:e.name,children:e.name},e.id))]})]}),(0,u.jsxs)(`label`,{className:`rr-field`,children:[(0,u.jsx)(`span`,{className:`rr-label`,children:`Status`}),(0,u.jsxs)(`select`,{className:`rr-select`,value:H,onChange:e=>U(e.target.value),children:[(0,u.jsx)(`option`,{value:`all`,children:`All results`}),(0,u.jsx)(`option`,{value:`draft`,children:`Still entering`}),(0,u.jsx)(`option`,{value:`computed`,children:`Ready for review`}),(0,u.jsx)(`option`,{value:`approved`,children:`Approved`}),(0,u.jsx)(`option`,{value:`published`,children:`Published`})]})]}),(0,u.jsx)(`div`,{className:`rr-field`,style:{display:`flex`,alignItems:`end`},children:(0,u.jsxs)(`button`,{className:`rr-btn rr-btn-dark`,style:{width:`100%`,justifyContent:`center`},onClick:()=>Z(),disabled:S,children:[(0,u.jsx)(`i`,{className:`bi bi-search`}),` `,S?`Loading`:`Find results`]})})]}),O&&(0,u.jsxs)(`div`,{className:`rr-error`,children:[(0,u.jsx)(`i`,{className:`bi bi-exclamation-circle`}),` `,O]}),(0,u.jsxs)(`section`,{className:`rr-grid`,children:[(0,u.jsxs)(`aside`,{className:`rr-panel`,children:[(0,u.jsxs)(`div`,{className:`rr-panel-head`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`h2`,{className:`rr-panel-title`,children:`Class Results`}),(0,u.jsx)(`p`,{className:`rr-panel-sub`,children:`Choose the class result to inspect.`})]}),(0,u.jsx)(`button`,{className:`rr-btn rr-btn-soft`,onClick:()=>Z(),disabled:S,children:(0,u.jsx)(`i`,{className:`bi bi-arrow-clockwise`})})]}),(0,u.jsx)(`div`,{className:`rr-batch-list`,children:S&&A.length===0?[1,2,3].map(e=>(0,u.jsxs)(`div`,{className:`rr-batch-card`,children:[(0,u.jsx)(`div`,{className:`rr-skeleton`,style:{width:`55%`}}),(0,u.jsx)(`div`,{className:`rr-skeleton`,style:{width:`80%`,marginTop:12}})]},e)):A.length===0?(0,u.jsxs)(`div`,{className:`rr-empty`,children:[(0,u.jsx)(`i`,{className:`bi bi-folder2-open`}),`No result batch found for this selection.`]}):A.map(e=>{let t=h(e);return(0,u.jsxs)(`button`,{className:`rr-batch-card ${M===e.id?`active`:``}`,onClick:()=>N(e.id),children:[(0,u.jsxs)(`div`,{className:`rr-batch-top`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`p`,{className:`rr-class`,children:e.class_name}),(0,u.jsxs)(`p`,{className:`rr-meta`,children:[e.term,` - `,e.session]})]}),(0,u.jsx)(`span`,{className:`rr-badge ${p(e.status)}`,children:f(e.status)})]}),(0,u.jsxs)(`div`,{className:`rr-mini-progress`,children:[(0,u.jsxs)(`div`,{className:`rr-progress-line`,children:[(0,u.jsxs)(`span`,{children:[e.review?.completed_students??0,`/`,e.review?.total_students??0,` completed`]}),(0,u.jsxs)(`span`,{children:[t,`%`]})]}),(0,u.jsx)(`div`,{className:`rr-track`,children:(0,u.jsx)(`div`,{className:`rr-fill`,style:{width:`${t}%`}})})]})]},e.id)})})]}),(0,u.jsx)(`section`,{className:`rr-panel`,children:K?(0,u.jsxs)(u.Fragment,{children:[(0,u.jsxs)(`div`,{className:`rr-detail-head`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`h2`,{className:`rr-detail-title`,children:K.class_name}),(0,u.jsxs)(`p`,{className:`rr-detail-sub`,children:[K.term,` - `,K.session,` - Last updated `,m(K.updated_at)]})]}),(0,u.jsx)(`span`,{className:`rr-badge ${p(K.status)}`,children:f(K.status)})]}),(0,u.jsxs)(`div`,{className:`rr-kpis`,children:[(0,u.jsxs)(`div`,{className:`rr-kpi`,children:[(0,u.jsx)(`p`,{className:`rr-kpi-label`,children:`Completion`}),(0,u.jsxs)(`p`,{className:`rr-kpi-value`,children:[X,`%`]})]}),(0,u.jsxs)(`div`,{className:`rr-kpi`,children:[(0,u.jsx)(`p`,{className:`rr-kpi-label`,children:`Entered`}),(0,u.jsx)(`p`,{className:`rr-kpi-value`,children:J})]}),(0,u.jsxs)(`div`,{className:`rr-kpi`,children:[(0,u.jsx)(`p`,{className:`rr-kpi-label`,children:`Pending`}),(0,u.jsx)(`p`,{className:`rr-kpi-value`,children:Y})]}),(0,u.jsxs)(`div`,{className:`rr-kpi`,children:[(0,u.jsx)(`p`,{className:`rr-kpi-label`,children:`Alerts`}),(0,u.jsx)(`p`,{className:`rr-kpi-value`,children:K.review?.open_alerts??0})]})]}),(0,u.jsxs)(`div`,{className:`rr-status-note`,children:[(0,u.jsx)(`i`,{className:`bi bi-info-circle`}),` `,(0,u.jsx)(`span`,{children:K.review?.simple_status||`Review the class result and student report cards before publishing.`})]}),(0,u.jsxs)(`div`,{className:`rr-action-row`,children:[(0,u.jsxs)(`button`,{className:`rr-btn rr-btn-soft`,onClick:()=>e(`/results/broadsheet/${K.id}`),children:[(0,u.jsx)(`i`,{className:`bi bi-table`}),` Open broadsheet`]}),(0,u.jsxs)(`button`,{className:`rr-btn rr-btn-soft`,onClick:()=>e(`/results/upload?batchId=${K.id}`),children:[(0,u.jsx)(`i`,{className:`bi bi-upload`}),` Upload/enter scores`]}),(0,u.jsxs)(`button`,{className:`rr-btn rr-btn-dark`,onClick:()=>$(`compute`),disabled:E!==null,children:[(0,u.jsx)(`i`,{className:`bi bi-calculator`}),` `,E===`compute`?`Computing`:`Compute`]}),(0,u.jsxs)(`button`,{className:`rr-btn rr-btn-dark`,onClick:()=>$(`approve`),disabled:E!==null||!K.review?.can_approve,children:[(0,u.jsx)(`i`,{className:`bi bi-check2-circle`}),` `,E===`approve`?`Approving`:`Approve`]}),(0,u.jsxs)(`button`,{className:`rr-btn rr-btn-gold`,onClick:()=>$(`publish`),disabled:E!==null||!K.review?.can_publish,children:[(0,u.jsx)(`i`,{className:`bi bi-send-check`}),` `,E===`publish`?`Publishing`:`Publish`]}),String(K.status).toLowerCase()===`published`&&(0,u.jsxs)(`button`,{className:`rr-btn rr-btn-soft`,onClick:()=>$(`reopen`),disabled:E!==null,children:[(0,u.jsx)(`i`,{className:`bi bi-unlock`}),` Reopen`]})]}),(0,u.jsxs)(`div`,{className:`rr-student-toolbar`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`h3`,{className:`rr-panel-title`,style:{fontSize:18},children:`Students in this result`}),(0,u.jsx)(`p`,{className:`rr-panel-sub`,children:`Open any completed student result for report-card preview.`})]}),(0,u.jsx)(`input`,{className:`rr-search`,placeholder:`Search student or admission no`,value:W,onChange:e=>G(e.target.value)})]}),(0,u.jsx)(`div`,{className:`rr-table-wrap`,children:(0,u.jsxs)(`table`,{className:`rr-table`,children:[(0,u.jsx)(`thead`,{children:(0,u.jsxs)(`tr`,{children:[(0,u.jsx)(`th`,{children:`#`}),(0,u.jsx)(`th`,{children:`Student`}),(0,u.jsx)(`th`,{children:`Admission No`}),(0,u.jsx)(`th`,{children:`Status`}),(0,u.jsx)(`th`,{children:`Saved`}),(0,u.jsx)(`th`,{children:`Action`})]})}),(0,u.jsx)(`tbody`,{children:w?[1,2,3,4].map(e=>(0,u.jsx)(`tr`,{children:(0,u.jsx)(`td`,{colSpan:6,children:(0,u.jsx)(`div`,{className:`rr-skeleton`,style:{width:`${55+e*7}%`}})})},e)):q.length===0?(0,u.jsx)(`tr`,{children:(0,u.jsx)(`td`,{colSpan:6,children:(0,u.jsxs)(`div`,{className:`rr-empty`,children:[(0,u.jsx)(`i`,{className:`bi bi-person-lines-fill`}),`No student found.`]})})}):q.map((e,t)=>{let n=e.status===`completed`;return(0,u.jsxs)(`tr`,{children:[(0,u.jsx)(`td`,{children:t+1}),(0,u.jsxs)(`td`,{children:[(0,u.jsx)(`div`,{className:`rr-student-name`,children:d(e)}),(0,u.jsxs)(`div`,{className:`rr-muted`,children:[`ID: `,e.id]})]}),(0,u.jsx)(`td`,{children:e.reg_no||`-`}),(0,u.jsx)(`td`,{children:(0,u.jsxs)(`span`,{className:`rr-student-status ${n?`completed`:`pending`}`,children:[(0,u.jsx)(`i`,{className:`bi ${n?`bi-check-circle`:`bi-hourglass-split`}`}),n?`Ready`:`Pending`]})}),(0,u.jsx)(`td`,{children:m(e.saved_at)}),(0,u.jsx)(`td`,{children:(0,u.jsxs)(`button`,{className:`rr-btn rr-btn-soft`,onClick:()=>ie(e),disabled:!n,children:[(0,u.jsx)(`i`,{className:`bi bi-eye`}),` View result`]})})]},e.id)})})]})})]}):(0,u.jsxs)(`div`,{className:`rr-empty`,children:[(0,u.jsx)(`i`,{className:`bi bi-clipboard`}),`Select a class result to view students and actions.`]})})]}),(0,u.jsx)(c,{})]})]})]})})]})}export{g as default};