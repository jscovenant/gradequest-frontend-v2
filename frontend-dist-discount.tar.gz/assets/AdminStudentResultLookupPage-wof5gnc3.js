import{i as e}from"./rolldown-runtime-CWU8vmCm.js";import{Ut as t}from"./vendor-misc-OZLc0tLq.js";import{b as n,p as r,x as i}from"./vendor-react-BhRGw7qi.js";import{i as a,r as o}from"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as s,L as c,P as l,d as u,f as d,l as f,u as p}from"./index-D6TxbaCx.js";import{t as m}from"./vendor-qr-Xjq4Czgo.js";var h=t(),g=e(a(),1),ee=e(m(),1),_=r(),v=[{label:`10 / 10 / 10 / 10 / 60 (4 CAs + Exam)`,value:`10/10/10/10/60`,caCount:4,caMax:10,examMax:60},{label:`20 / 20 / 60 (2 CAs + Exam)`,value:`20/20/60`,caCount:2,caMax:20,examMax:60},{label:`40 / 60 (1 CA + Exam)`,value:`40/60`,caCount:1,caMax:40,examMax:60},{label:`30 / 70 (1 CA + Exam)`,value:`30/70`,caCount:1,caMax:30,examMax:70}];function y(e){return e>=75?{grade:`A1`,remark:`Distinction`}:e>=70?{grade:`B2`,remark:`Very Good`}:e>=65?{grade:`B3`,remark:`Good`}:e>=60?{grade:`C4`,remark:`Credit`}:e>=55?{grade:`C5`,remark:`Credit`}:e>=50?{grade:`C6`,remark:`Credit`}:e>=45?{grade:`D7`,remark:`Pass`}:e>=40?{grade:`E8`,remark:`Pass`}:{grade:`F9`,remark:`Fail`}}var b=e=>{let t=(e||``).replace(`#`,``);if(t.length!==6)return`#fff`;let n=parseInt(t.substring(0,2),16),r=parseInt(t.substring(2,4),16),i=parseInt(t.substring(4,6),16);return(n*299+r*587+i*114)/1e3>=140?`#111827`:`#fff`},x=(e,t)=>{let n=(e||``).replace(`#`,``);return n.length===6?`rgba(${parseInt(n.substring(0,2),16)}, ${parseInt(n.substring(2,4),16)}, ${parseInt(n.substring(4,6),16)}, ${t})`:`rgba(13, 71, 161, ${t})`};function S(){let[e,t]=(0,h.useState)(!1),r=n(),a=i(),{showSuccess:m,showError:S}=f(),[C,te]=(0,h.useState)(``),[w,T]=(0,h.useState)(``),[E,D]=(0,h.useState)(`First Term`),[O,k]=(0,h.useState)(``),[A,j]=(0,h.useState)(`edit`),[M,N]=(0,h.useState)(!1),[P,F]=(0,h.useState)(!1),[I,L]=(0,h.useState)(!1),[R,ne]=(0,h.useState)(null),[z,re]=(0,h.useState)(null),[B,ie]=(0,h.useState)({name:`SchoolProfit Academic Partner School`,address:`Academic Campus`,phone:``,primary_color:`#0d47a1`,secondary_color:`#ffc107`,background_color:`#ffffff`}),[ae,oe]=(0,h.useState)(null),[V,se]=(0,h.useState)(``),[H,U]=(0,h.useState)([]),[ce,W]=(0,h.useState)([]),[le,ue]=(0,h.useState)([]),[de,fe]=(0,h.useState)([]),[G,pe]=(0,h.useState)(`40/60`),[K,q]=(0,h.useState)([]),[J,Y]=(0,h.useState)({total_grade:``,principal_comment:``,class_teacher_comment:``,total_average:0,school_open:110,school_close:0,no_present:105,no_absent:5,general_remark:``,resumption_date:``,class_teacher:``,class_size:30,position:``}),[X,me]=(0,h.useState)({punctuality:4,attendance:4,neatness:5,politeness:4,honesty:5,relationship_with_others:4,leadership:4,emotional_stability:4,sports:3,handwriting:4,crafts:4,music:3}),Z=(0,h.useMemo)(()=>v.find(e=>e.value===G)||v[2],[G]);(0,h.useEffect)(()=>{let e=new URLSearchParams(r.search),t=e.get(`reg_no`),n=e.get(`session`),i=e.get(`term`),a=e.get(`class_id`);t&&te(t),n&&T(n),i&&D(i),a&&k(a),t?Q(t,n||void 0,i||void 0,a||void 0):l.get(`/admin/student-result-lookup`).then(({data:e})=>{e.sessions?.length&&U(e.sessions),e.terms?.length&&W(e.terms),e.classes?.length&&ue(e.classes),e.current_session&&T(t=>t||e.current_session),e.current_term&&D(t=>t||e.current_term),e.current_class_id&&k(t=>t||e.current_class_id)}).catch(()=>void 0)},[r.search]);let Q=async(e,t,n,r)=>{let i=(e||C).trim();if(!i){S(`Please enter a student registration number / admission number.`);return}N(!0);try{let e=t??w,o=n??E,s=r??O,{data:u}=await l.get(`/admin/student-result-lookup`,{params:{reg_no:i,...e?{session:e}:{},...o?{term:o}:{},...s?{class_id:s}:{}}}),d=u.student;ne(d),u.sessions?.length&&U(u.sessions),u.terms?.length&&W(u.terms),u.classes?.length&&ue(u.classes),u.subjects?.length&&fe(u.subjects);let f=u.current_session||e||(u.sessions?.[0]?.name??`2025/2026`),p=u.current_term||o||(u.terms?.[0]?.name??`First Term`),h=u.current_class_id||s||d.level_id||(u.classes?.[0]?.id??``);T(f),D(p),k(h),u.score_type&&pe(u.score_type);let g=u.results||[],_=u.subjects||[];if(g.length>0?q(g.map(e=>{let t={};try{let n=typeof e.ca==`string`?JSON.parse(e.ca):e.ca||{};if(typeof n==`number`)t={ca1:n};else if(typeof n==`object`&&n){let e=Object.keys(n),r=e.includes(`ca0`)||e.includes(`0`)&&!e.includes(`ca1`);e.forEach(e=>{let i=n[e]!==null&&n[e]!==void 0&&n[e]!==``?Number(n[e]):``;e===`ca0`||e===`0`?t.ca1=i:e===`ca1`||e===`1`?t[r?`ca2`:`ca1`]=i:e===`ca2`||e===`2`?t[r?`ca3`:`ca2`]=i:e===`ca3`||e===`3`?t[r?`ca4`:`ca3`]=i:e===`ca4`||e===`4`?t.ca4=i:t[e]=i}),Object.keys(t).length===0&&e.length>0&&(t.ca1=Number(n[e[0]])||0)}}catch{t={}}let n=e.exam!==null&&e.exam!==void 0&&e.exam!==``?Number(e.exam):``,r=e.total!==null&&e.total!==void 0?Number(e.total):0,{grade:i,remark:a}=y(r);return{subject_id:e.subject_id,subject_name:e.subject?.name||`Subject #${e.subject_id}`,ca:t,exam:n,total:r,grade:e.grade||i,remark:e.remark||a,firstterm:e.firstterm??``,secondterm:e.secondterm??``,average:e.average??``}})):q(_.map(e=>({subject_id:e.id,subject_name:e.name,ca:{},exam:``,total:0,grade:`-`,remark:`-`}))),u.average){let e=u.average;Y({total_grade:e.total_grade||``,principal_comment:e.principal_comment||``,class_teacher_comment:e.class_teacher_comment||``,total_average:e.total_average??0,school_open:e.school_open??110,school_close:e.school_close??0,no_present:e.no_present??105,no_absent:e.no_absent??5,general_remark:e.general_remark||``,resumption_date:e.resumption_date||``,class_teacher:e.class_teacher||``,class_size:e.class_size??30,position:e.position||``})}else Y(e=>({...e,total_average:0,total_grade:``,position:``}));if(u.ratings){let e=u.ratings;me({punctuality:Number(e.punctuality)||4,attendance:Number(e.attendance)||4,neatness:Number(e.neatness)||5,politeness:Number(e.politeness)||4,honesty:Number(e.honesty)||5,relationship_with_others:Number(e.relationship_with_others)||4,leadership:Number(e.leadership)||4,emotional_stability:Number(e.emotional_stability)||4,sports:Number(e.sports)||3,handwriting:Number(e.handwriting)||4,crafts:Number(e.crafts)||4,music:Number(e.music)||3})}u.school_info&&ie(u.school_info),u.result_template&&oe(u.result_template),u.student_photo_base64&&re(u.student_photo_base64);let v={studentId:d.id,reg_no:d.reg_no,term:p,session:f},b=encodeURIComponent(JSON.stringify(v)),x=`${c()}/verify-result?data=${b}&reg_no=${encodeURIComponent(d.reg_no||``)}&term=${encodeURIComponent(p)}&session=${encodeURIComponent(f)}`;ee.toDataURL(x).then(se).catch(()=>void 0),a(`/results/student-editor?reg_no=${encodeURIComponent(i)}&session=${encodeURIComponent(f)}&term=${encodeURIComponent(p)}&class_id=${h}`,{replace:!0}),m(`Loaded academic record for ${d.firstname} ${d.surname} (${d.reg_no})`)}catch(e){S(e.response?.data?.message||`Student record could not be loaded. Please verify the Reg No.`)}finally{N(!1)}},he=async()=>{if(R){L(!0);try{let e=document.getElementById(`admin-result-sheet`);if(!e)return;let t=await(0,g.default)(e,{scale:2,useCORS:!0}),n=t.toDataURL(`image/png`),r=new o(`p`,`pt`,`a4`),i=595.28,a=t.height*i/t.width;r.addImage(n,`PNG`,0,0,i,Math.min(a,841.89)),r.save(`Result_${R.reg_no||R.id}.pdf`),m(`Downloaded official result sheet PDF!`)}catch(e){console.error(e),S(`Unable to export PDF. Please try printing directly.`)}finally{L(!1)}}},ge=(e,t,n,r)=>{let i=[...K],a={...i[e]};if(t===`ca`&&n){let e=r===``||r===void 0?0:Number(r);a.ca={...a.ca,[n]:e}}else t===`exam`&&(a.exam=r===``||r===void 0?``:Number(r));let o=Object.values(a.ca).reduce((e,t)=>e+(Number(t)||0),0),s=Number(a.exam)||0,c=Math.min(100,Math.max(0,o+s)),{grade:l,remark:u}=y(c);a.total=c,a.grade=l,a.remark=u,i[e]=a,q(i),$(i)},$=e=>{let t=e.filter(e=>e.total>0||e.exam!==``);if(t.length===0)return;let n=t.reduce((e,t)=>e+t.total,0),r=Number((n/t.length).toFixed(1)),{grade:i}=y(r);Y(e=>({...e,total_average:r,total_grade:i}))},_e=e=>{let t=de.find(t=>t.id===e);if(!t)return;if(K.some(t=>t.subject_id===e)){S(`Subject is already present in the result sheet.`);return}let n={subject_id:t.id,subject_name:t.name,ca:{},exam:``,total:0,grade:`-`,remark:`-`},r=[...K,n];q(r),$(r),m(`Added ${t.name} to student score sheet.`)},ve=e=>{let t=K[e],n=K.filter((t,n)=>n!==e);q(n),$(n),m(`Removed ${t.subject_name}`)};return(0,_.jsxs)(`div`,{className:`admin-result-editor-layout`,children:[(0,_.jsx)(s,{title:`Student Result Lookup & Editor | SchoolProfit`}),(0,_.jsx)(`style`,{children:`
        .db-main {
          min-height: 100vh;
          margin-left: 280px;
          width: calc(100% - 280px);
          padding: max(96px, calc(78px + env(safe-area-inset-top))) 28px 48px;
          background: #F8FAFC;
          color: #0F172A;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
        }

        @media (max-width: 1199px) {
          .db-main {
            margin-left: 0;
            width: 100%;
            padding: max(88px, calc(72px + env(safe-area-inset-top))) 16px 32px;
          }
        }

        /* Hero Banner */
        .re-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 20px;
          padding: 32px 36px;
          position: relative;
          overflow: hidden;
          margin-bottom: 28px;
          box-shadow: 0 12px 35px -5px rgba(15, 39, 68, 0.18);
          color: #FFFFFF;
        }
        .re-hero-glow {
          position: absolute;
          top: -90px;
          right: -40px;
          width: 380px;
          height: 380px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.20), transparent 70%);
          pointer-events: none;
        }
        .re-hero-inner {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 24px;
          flex-wrap: wrap;
        }
        .re-kicker {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          font-size: 11.5px;
          font-weight: 800;
          letter-spacing: 0.05em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.22);
          border: 1px solid rgba(217, 119, 6, 0.40);
          border-radius: 999px;
          padding: 5px 14px;
          margin-bottom: 12px;
        }
        .re-title {
          font-size: 26px;
          font-weight: 800;
          color: #FFFFFF;
          margin: 0 0 8px;
          letter-spacing: -0.02em;
        }
        .re-title em {
          color: #FBBF24;
          font-style: normal;
        }
        .re-sub {
          font-size: 13.5px;
          color: #CBD5E1;
          line-height: 1.6;
          max-width: 680px;
          margin: 0;
        }
        .re-badge-permanent {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          background: rgba(16, 185, 129, 0.15);
          border: 1px solid rgba(16, 185, 129, 0.35);
          color: #34D399;
          font-size: 12px;
          font-weight: 700;
          padding: 6px 14px;
          border-radius: 999px;
        }

        /* Search Card */
        .re-search-card {
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: 18px;
          padding: 24px 28px;
          margin-bottom: 28px;
          box-shadow: 0 4px 20px rgba(15, 39, 68, 0.04);
        }
        .re-input-group {
          display: flex;
          align-items: center;
          background: #F8FAFC;
          border: 1px solid #CBD5E1;
          border-radius: 12px;
          padding: 4px 12px;
          transition: all 0.2s ease;
        }
        .re-input-group:focus-within {
          border-color: #D97706;
          background: #FFFFFF;
          box-shadow: 0 0 0 3px rgba(217, 119, 6, 0.15);
        }
        .re-input-group input {
          border: none;
          background: transparent;
          outline: none;
          padding: 10px 8px;
          width: 100%;
          font-size: 14.5px;
          font-weight: 600;
          color: #0F172A;
        }
        .re-select {
          background: #F8FAFC;
          border: 1px solid #CBD5E1;
          border-radius: 12px;
          padding: 12px 14px;
          font-size: 13.5px;
          font-weight: 600;
          color: #0F172A;
          width: 100%;
          outline: none;
          transition: all 0.2s ease;
        }
        .re-select:focus {
          border-color: #D97706;
          box-shadow: 0 0 0 3px rgba(217, 119, 6, 0.15);
          background: #FFFFFF;
        }
        .re-btn-search {
          background: linear-gradient(135deg, #D97706 0%, #B45309 100%);
          color: #FFFFFF;
          border: none;
          border-radius: 12px;
          padding: 12px 24px;
          font-size: 14px;
          font-weight: 700;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          cursor: pointer;
          transition: all 0.2s ease;
          width: 100%;
          box-shadow: 0 4px 14px rgba(217, 119, 6, 0.25);
        }
        .re-btn-search:hover:not(:disabled) {
          transform: translateY(-1px);
          box-shadow: 0 6px 20px rgba(217, 119, 6, 0.35);
        }

        /* Student Profile Card */
        .re-profile-bar {
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: 18px;
          padding: 22px 28px;
          margin-bottom: 24px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 20px;
          flex-wrap: wrap;
          box-shadow: 0 4px 20px rgba(15, 39, 68, 0.04);
        }
        .re-avatar {
          width: 64px;
          height: 64px;
          border-radius: 16px;
          background: #0F2744;
          color: #FBBF24;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 24px;
          font-weight: 800;
          object-fit: cover;
          border: 2px solid #E2E8F0;
        }
        .re-stat-pill {
          background: #F8FAFC;
          border: 1px solid #E2E8F0;
          border-radius: 12px;
          padding: 10px 18px;
          text-align: center;
        }
        .re-stat-label {
          font-size: 11px;
          font-weight: 700;
          text-transform: uppercase;
          color: #64748B;
          letter-spacing: 0.04em;
        }
        .re-stat-value {
          font-size: 18px;
          font-weight: 800;
          color: #0F172A;
          margin-top: 2px;
        }

        /* Tabs */
        .re-tab-pill {
          padding: 10px 22px;
          border-radius: 12px;
          font-size: 13.5px;
          font-weight: 700;
          border: 1px solid transparent;
          cursor: pointer;
          display: inline-flex;
          align-items: center;
          gap: 8px;
          transition: all 0.2s ease;
          background: #F1F5F9;
          color: #475569;
        }
        .re-tab-pill.active {
          background: #0F2744;
          color: #FFFFFF;
          border-color: #0F2744;
          box-shadow: 0 4px 12px rgba(15, 39, 68, 0.15);
        }

        /* Tables & Score Editor */
        .re-table-card {
          background: #FFFFFF;
          border: 1px solid #E2E8F0;
          border-radius: 18px;
          overflow: hidden;
          margin-bottom: 24px;
          box-shadow: 0 4px 20px rgba(15, 39, 68, 0.04);
        }
        .re-table {
          width: 100%;
          margin: 0;
          border-collapse: collapse;
        }
        .re-table th {
          background: #F8FAFC;
          color: #475569;
          font-size: 12px;
          font-weight: 800;
          text-transform: uppercase;
          letter-spacing: 0.04em;
          padding: 14px 18px;
          border-bottom: 2px solid #E2E8F0;
        }
        .re-table td {
          padding: 12px 18px;
          border-bottom: 1px solid #F1F5F9;
          vertical-align: middle;
          font-size: 13.5px;
        }
        .re-score-input {
          width: 68px;
          padding: 8px 10px;
          border-radius: 8px;
          border: 1px solid #CBD5E1;
          font-size: 14px;
          font-weight: 700;
          text-align: center;
          outline: none;
          background: #FFFFFF;
          color: #0F172A;
          transition: all 0.2s ease;
        }
        .re-score-input:focus {
          border-color: #D97706;
          box-shadow: 0 0 0 2px rgba(217, 119, 6, 0.20);
        }
        .re-grade-tag {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          min-width: 38px;
          padding: 4px 10px;
          border-radius: 8px;
          font-size: 12.5px;
          font-weight: 800;
        }
        .re-grade-A { background: #ECFDF5; color: #047857; border: 1px solid #A7F3D0; }
        .re-grade-B { background: #EFF6FF; color: #1D4ED8; border: 1px solid #BFDBFE; }
        .re-grade-C { background: #FEF3C7; color: #B45309; border: 1px solid #FDE68A; }
        .re-grade-D { background: #FFF7ED; color: #C2410C; border: 1px solid #FED7AA; }
        .re-grade-E { background: #FAF5FF; color: #7E22CE; border: 1px solid #E9D5FF; }
        .re-grade-F { background: #FEF2F2; color: #B91C1C; border: 1px solid #FECACA; }

        /* Save Button */
        .re-btn-save {
          background: linear-gradient(135deg, #10B981 0%, #047857 100%);
          color: #FFFFFF;
          border: none;
          border-radius: 12px;
          padding: 14px 28px;
          font-size: 15px;
          font-weight: 800;
          display: inline-flex;
          align-items: center;
          gap: 10px;
          cursor: pointer;
          box-shadow: 0 6px 20px rgba(16, 185, 129, 0.30);
          transition: all 0.2s ease;
        }
        .re-btn-save:hover:not(:disabled) {
          transform: translateY(-2px);
          box-shadow: 0 8px 25px rgba(16, 185, 129, 0.40);
        }

        /* Printable Result Sheet Styling */
        .re-print-sheet {
          background: #FFFFFF;
          border: 2px solid #E2E8F0;
          border-radius: 18px;
          padding: 40px;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
          font-family: 'Plus Jakarta Sans', system-ui, sans-serif;
        }
        .re-sheet-header {
          text-align: center;
          border-bottom: 2px solid #0F2744;
          padding-bottom: 20px;
          margin-bottom: 24px;
        }
        .re-sheet-school-name {
          font-size: 24px;
          font-weight: 900;
          color: #0F2744;
          text-transform: uppercase;
          letter-spacing: 0.02em;
          margin: 0 0 6px;
        }
        .re-sheet-school-sub {
          font-size: 13px;
          font-weight: 600;
          color: #64748B;
        }
      `}),(0,_.jsx)(d,{sidebarOpen:e,setSidebarOpen:t,title:`Student Result Editor`}),(0,_.jsx)(`div`,{className:`container-fluid`,children:(0,_.jsxs)(`div`,{className:`row`,children:[(0,_.jsx)(u,{sidebarOpen:e,setSidebarOpen:t}),(0,_.jsxs)(`main`,{className:`db-main d-flex flex-column`,children:[(0,_.jsxs)(`div`,{className:`re-hero`,children:[(0,_.jsx)(`div`,{className:`re-hero-glow`}),(0,_.jsxs)(`div`,{className:`re-hero-inner`,children:[(0,_.jsxs)(`div`,{children:[(0,_.jsxs)(`div`,{className:`re-kicker`,children:[(0,_.jsx)(`i`,{className:`bi bi-shield-check`}),` Admin Result Command Center`]}),(0,_.jsxs)(`h1`,{className:`re-title`,children:[`Student Result `,(0,_.jsx)(`em`,{children:`Search & Quick Editor`})]}),(0,_.jsx)(`p`,{className:`re-sub`,children:`Instantly look up any student by Registration / Admission Number to view, audit, modify, recalculate, and print complete terminal academic reports.`})]}),(0,_.jsx)(`div`,{children:(0,_.jsxs)(`span`,{className:`re-badge-permanent`,children:[(0,_.jsx)(`i`,{className:`bi bi-unlock-fill`}),` Perpetual Academic Access Active (Sub-Exemption)`]})})]})]}),(0,_.jsx)(`div`,{className:`re-search-card`,children:(0,_.jsxs)(`form`,{onSubmit:e=>{e.preventDefault(),Q()},className:`row g-3 align-items-end`,children:[(0,_.jsxs)(`div`,{className:`col-12 col-md-4`,children:[(0,_.jsxs)(`label`,{className:`form-label text-xs fw-bold text-uppercase text-muted`,children:[`Student Admission / Reg No `,(0,_.jsx)(`span`,{className:`text-danger`,children:`*`})]}),(0,_.jsxs)(`div`,{className:`re-input-group`,children:[(0,_.jsx)(`i`,{className:`bi bi-person-badge text-muted fs-5 me-2`}),(0,_.jsx)(`input`,{type:`text`,placeholder:`e.g. STU/2026/001 or ID`,value:C,onChange:e=>te(e.target.value),required:!0})]})]}),(0,_.jsxs)(`div`,{className:`col-6 col-md-2`,children:[(0,_.jsx)(`label`,{className:`form-label text-xs fw-bold text-uppercase text-muted`,children:`Academic Session`}),(0,_.jsx)(`select`,{className:`re-select`,value:w,onChange:e=>T(e.target.value),children:H.length===0?(0,_.jsx)(`option`,{value:`2025/2026`,children:`2025/2026`}):H.map(e=>(0,_.jsx)(`option`,{value:e.name,children:e.name},e.id))})]}),(0,_.jsxs)(`div`,{className:`col-6 col-md-2`,children:[(0,_.jsx)(`label`,{className:`form-label text-xs fw-bold text-uppercase text-muted`,children:`Academic Term`}),(0,_.jsxs)(`select`,{className:`re-select`,value:E,onChange:e=>D(e.target.value),children:[(0,_.jsx)(`option`,{value:`First Term`,children:`First Term`}),(0,_.jsx)(`option`,{value:`Second Term`,children:`Second Term`}),(0,_.jsx)(`option`,{value:`Third Term`,children:`Third Term`})]})]}),(0,_.jsxs)(`div`,{className:`col-6 col-md-2`,children:[(0,_.jsx)(`label`,{className:`form-label text-xs fw-bold text-muted text-uppercase`,children:`Class / Level`}),(0,_.jsxs)(`select`,{className:`re-select`,value:O,onChange:e=>k(e.target.value),children:[(0,_.jsx)(`option`,{value:``,children:`Default Student Class`}),le.map(e=>(0,_.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]}),(0,_.jsx)(`div`,{className:`col-6 col-md-2`,children:(0,_.jsx)(`button`,{type:`submit`,className:`re-btn-search`,disabled:M,children:M?(0,_.jsxs)(_.Fragment,{children:[(0,_.jsx)(`span`,{className:`spinner-border spinner-border-sm`}),` Loading...`]}):(0,_.jsxs)(_.Fragment,{children:[(0,_.jsx)(`i`,{className:`bi bi-search`}),` Load Result`]})})})]})}),R?(0,_.jsxs)(_.Fragment,{children:[(0,_.jsxs)(`div`,{className:`re-profile-bar`,children:[(0,_.jsxs)(`div`,{className:`d-flex align-items-center gap-3`,children:[R.photo?(0,_.jsx)(`img`,{src:`/uploads/users/${R.photo}`,alt:R.firstname,className:`re-avatar`,onError:e=>{e.target.src=``,e.target.className=`re-avatar d-flex align-items-center justify-content-center`}}):(0,_.jsxs)(`div`,{className:`re-avatar`,children:[R.firstname[0],R.surname[0]]}),(0,_.jsxs)(`div`,{children:[(0,_.jsxs)(`div`,{className:`d-flex align-items-center gap-2`,children:[(0,_.jsxs)(`h3`,{className:`fs-5 fw-bold text-dark m-0`,children:[R.firstname,` `,R.surname,` `,R.othername||``]}),(0,_.jsx)(`span`,{className:`badge bg-primary-subtle text-primary fw-bold text-uppercase px-2 py-1`,children:R.level?.name||`General`})]}),(0,_.jsxs)(`div`,{className:`d-flex align-items-center gap-3 text-muted text-sm mt-1`,children:[(0,_.jsxs)(`span`,{children:[(0,_.jsx)(`strong`,{children:`Reg No:`}),` `,R.reg_no]}),(0,_.jsx)(`span`,{children:`•`}),(0,_.jsxs)(`span`,{children:[(0,_.jsx)(`strong`,{children:`Dept:`}),` `,R.department?.name||`General`]}),(0,_.jsx)(`span`,{children:`•`}),(0,_.jsxs)(`span`,{children:[(0,_.jsx)(`strong`,{children:`Period:`}),` `,w,` • `,E]})]})]})]}),(0,_.jsxs)(`div`,{className:`d-flex align-items-center gap-3`,children:[(0,_.jsxs)(`div`,{className:`re-stat-pill`,children:[(0,_.jsx)(`div`,{className:`re-stat-label`,children:`Term Average`}),(0,_.jsxs)(`div`,{className:`re-stat-value text-primary`,children:[J.total_average,`%`]})]}),(0,_.jsxs)(`div`,{className:`re-stat-pill`,children:[(0,_.jsx)(`div`,{className:`re-stat-label`,children:`Grade`}),(0,_.jsx)(`div`,{className:`re-stat-value text-warning`,children:J.total_grade||`-`})]}),(0,_.jsxs)(`div`,{className:`re-stat-pill`,children:[(0,_.jsx)(`div`,{className:`re-stat-label`,children:`Position`}),(0,_.jsx)(`div`,{className:`re-stat-value text-success`,children:J.position||`N/A`})]})]})]}),(0,_.jsxs)(`div`,{className:`d-flex align-items-center justify-content-between mb-4 flex-wrap gap-3`,children:[(0,_.jsxs)(`div`,{className:`d-flex gap-2`,children:[(0,_.jsxs)(`button`,{type:`button`,className:`re-tab-pill ${A===`edit`?`active`:``}`,onClick:()=>j(`edit`),children:[(0,_.jsx)(`i`,{className:`bi bi-pencil-square`}),` Live Score Editor`]}),(0,_.jsxs)(`button`,{type:`button`,className:`re-tab-pill ${A===`preview`?`active`:``}`,onClick:()=>j(`preview`),children:[(0,_.jsx)(`i`,{className:`bi bi-file-earmark-text`}),` Official Result Sheet Preview`]})]}),A===`edit`&&(0,_.jsxs)(`div`,{className:`d-flex align-items-center gap-2`,children:[(0,_.jsx)(`label`,{className:`text-xs fw-bold text-muted text-uppercase me-1`,children:`CA Scoring Model:`}),(0,_.jsx)(`select`,{className:`form-select form-select-sm fw-bold border-secondary-subtle`,style:{width:`auto`},value:G,onChange:e=>pe(e.target.value),children:v.map(e=>(0,_.jsx)(`option`,{value:e.value,children:e.label},e.value))})]})]}),A===`edit`&&(0,_.jsxs)(`form`,{onSubmit:async e=>{if(e&&e.preventDefault(),!R){S(`Please look up a student first before saving.`);return}if(K.length===0){S(`Please add at least one subject to the score sheet.`);return}F(!0);try{let e=K.map(e=>({subject_id:e.subject_id,ca:JSON.stringify(e.ca),exam:e.exam===``?0:Number(e.exam),total:e.total,grade:e.grade,remark:e.remark,firstterm:e.firstterm?Number(e.firstterm):null,secondterm:e.secondterm?Number(e.secondterm):null,average:e.average?Number(e.average):null})),t={total_grade:J.total_grade,principal_comment:J.principal_comment,class_teacher_comment:J.class_teacher_comment,total_average:Number(J.total_average)||0,school_open:Number(J.school_open)||0,school_close:Number(J.school_close)||0,no_present:Number(J.no_present)||0,no_absent:Number(J.no_absent)||0,general_remark:J.general_remark,resumption_date:J.resumption_date||null,class_teacher:J.class_teacher,class_size:Number(J.class_size)||0};await l.put(`/update-result/${R.id}/${encodeURIComponent(w)}/${O}/${encodeURIComponent(E)}`,{results:e,summary:t}),R.school_id&&await l.post(`/save-ratings`,{user_id:R.id,school_id:R.school_id,affective:[{id:1,rate:X.punctuality||4},{id:2,rate:X.attendance||4},{id:3,rate:X.neatness||5},{id:4,rate:X.politeness||4},{id:5,rate:X.honesty||5}],psychomotor:[{id:1,rate:X.sports||3},{id:2,rate:X.crafts||4},{id:3,rate:X.music||3}]}).catch(()=>void 0),m(`Successfully saved and computed results for ${R.firstname} ${R.surname}!`),Q(R.reg_no,w,E,O)}catch(e){S(e.response?.data?.message||`Unable to save student result. Please review inputs.`)}finally{F(!1)}},children:[(0,_.jsxs)(`div`,{className:`re-table-card`,children:[(0,_.jsxs)(`div`,{className:`p-3 bg-light border-bottom d-flex align-items-center justify-content-between flex-wrap gap-2`,children:[(0,_.jsxs)(`div`,{className:`fw-bold text-dark fs-6 d-flex align-items-center gap-2`,children:[(0,_.jsx)(`i`,{className:`bi bi-card-checklist text-primary`}),` Subject Continuous Assessment & Exam Scores (`,K.length,` Subjects)`]}),(0,_.jsx)(`div`,{className:`d-flex align-items-center gap-2`,children:(0,_.jsxs)(`select`,{className:`form-select form-select-sm fw-semibold`,style:{width:`220px`},onChange:e=>{e.target.value&&(_e(Number(e.target.value)),e.target.value=``)},defaultValue:``,children:[(0,_.jsx)(`option`,{value:``,disabled:!0,children:`+ Add Additional Subject...`}),de.filter(e=>!K.some(t=>t.subject_id===e.id)).map(e=>(0,_.jsx)(`option`,{value:e.id,children:e.name},e.id))]})})]}),(0,_.jsx)(`div`,{className:`table-responsive`,children:(0,_.jsxs)(`table`,{className:`re-table`,children:[(0,_.jsx)(`thead`,{children:(0,_.jsxs)(`tr`,{children:[(0,_.jsx)(`th`,{style:{width:`40px`},children:`#`}),(0,_.jsx)(`th`,{children:`Subject Name`}),Array.from({length:Z.caCount}).map((e,t)=>(0,_.jsxs)(`th`,{style:{width:`90px`,textAlign:`center`},children:[`CA `,t+1,` (`,Z.caMax,`)`]},t)),(0,_.jsxs)(`th`,{style:{width:`100px`,textAlign:`center`},children:[`Exam (`,Z.examMax,`)`]}),(0,_.jsx)(`th`,{style:{width:`90px`,textAlign:`center`},children:`Total (100)`}),(0,_.jsx)(`th`,{style:{width:`80px`,textAlign:`center`},children:`Grade`}),(0,_.jsx)(`th`,{style:{width:`130px`},children:`Remark`}),(0,_.jsx)(`th`,{style:{width:`60px`,textAlign:`center`},children:`Action`})]})}),(0,_.jsx)(`tbody`,{children:K.map((e,t)=>{let n=e.grade?.charAt(0)||`F`;return(0,_.jsxs)(`tr`,{children:[(0,_.jsx)(`td`,{className:`text-muted fw-bold`,children:t+1}),(0,_.jsx)(`td`,{className:`fw-bold text-dark`,children:e.subject_name}),Array.from({length:Z.caCount}).map((n,r)=>{let i=`ca${r+1}`,a=e.ca?.[i]??``;return(0,_.jsx)(`td`,{style:{textAlign:`center`},children:(0,_.jsx)(`input`,{type:`number`,min:`0`,max:Z.caMax,className:`re-score-input`,value:a,onChange:e=>ge(t,`ca`,i,e.target.value)})},i)}),(0,_.jsx)(`td`,{style:{textAlign:`center`},children:(0,_.jsx)(`input`,{type:`number`,min:`0`,max:Z.examMax,className:`re-score-input`,value:e.exam,onChange:e=>ge(t,`exam`,void 0,e.target.value)})}),(0,_.jsx)(`td`,{style:{textAlign:`center`},className:`fw-bold fs-6 text-dark`,children:e.total}),(0,_.jsx)(`td`,{style:{textAlign:`center`},children:(0,_.jsx)(`span`,{className:`re-grade-tag re-grade-${n}`,children:e.grade})}),(0,_.jsx)(`td`,{children:(0,_.jsx)(`span`,{className:`text-sm fw-semibold text-muted`,children:e.remark})}),(0,_.jsx)(`td`,{style:{textAlign:`center`},children:(0,_.jsx)(`button`,{type:`button`,className:`btn btn-sm btn-outline-danger p-1 border-0`,title:`Remove Subject`,onClick:()=>ve(t),children:(0,_.jsx)(`i`,{className:`bi bi-trash3`})})})]},e.subject_id||t)})})]})})]}),(0,_.jsxs)(`div`,{className:`row g-4 mb-4`,children:[(0,_.jsx)(`div`,{className:`col-12 col-lg-6`,children:(0,_.jsxs)(`div`,{className:`bg-white p-4 rounded-4 border shadow-sm h-100`,children:[(0,_.jsxs)(`div`,{className:`d-flex align-items-center justify-content-between mb-3`,children:[(0,_.jsxs)(`h5`,{className:`fs-6 fw-bold text-dark m-0 d-flex align-items-center gap-2`,children:[(0,_.jsx)(`i`,{className:`bi bi-chat-quote-fill text-primary`}),` Teacher & Principal Comments`]}),(0,_.jsxs)(`button`,{type:`button`,className:`btn btn-xs btn-outline-primary rounded-pill px-3 py-1 fw-bold`,onClick:()=>{if(!R)return;let e=Number(J.total_average)||0,t=``,n=``;e>=75?(t=`${R.firstname} has shown exceptional brilliance and consistency throughout this academic term. Highly commendable performance!`,n=`An outstanding academic result. Keep up the high intellectual curiosity and dedication to excellence.`):e>=60?(t=`${R.firstname} is a dedicated and hardworking student with strong analytical potential. Good performance overall.`,n=`A very commendable term report. With further effort in continuous assessments, top honours can be achieved.`):e>=50?(t=`${R.firstname} possesses steady academic capabilities but needs more focus and active revision during study periods.`,n=`A satisfactory result with clear room for significant improvement. Focus on weaker subject areas next term.`):(t=`${R.firstname} requires intensive tutorial attention and close supervision in continuous class assessments.`,n=`Performance is below required academic standards. Urgent remedial support and focused studying recommended.`),Y(r=>({...r,class_teacher_comment:t,principal_comment:n,general_remark:e>=50?`Promoted with Credit`:`Advised to work harder`})),m(`Generated intelligent academic remarks based on student average.`)},children:[(0,_.jsx)(`i`,{className:`bi bi-magic`}),` AI Suggest Comments`]})]}),(0,_.jsxs)(`div`,{className:`mb-3`,children:[(0,_.jsx)(`label`,{className:`form-label text-xs fw-bold text-muted text-uppercase`,children:`Class Teacher's Comment`}),(0,_.jsx)(`textarea`,{className:`form-control`,rows:2,value:J.class_teacher_comment,onChange:e=>Y({...J,class_teacher_comment:e.target.value}),placeholder:`e.g. An active and promising learner with outstanding performance.`})]}),(0,_.jsxs)(`div`,{className:`mb-3`,children:[(0,_.jsx)(`label`,{className:`form-label text-xs fw-bold text-muted text-uppercase`,children:`Principal / Headteacher Remark`}),(0,_.jsx)(`textarea`,{className:`form-control`,rows:2,value:J.principal_comment,onChange:e=>Y({...J,principal_comment:e.target.value}),placeholder:`e.g. Excellent academic results. Keep striving for the highest honours.`})]}),(0,_.jsxs)(`div`,{className:`row g-3`,children:[(0,_.jsxs)(`div`,{className:`col-6`,children:[(0,_.jsx)(`label`,{className:`form-label text-xs fw-bold text-muted text-uppercase`,children:`Class Teacher Name`}),(0,_.jsx)(`input`,{type:`text`,className:`form-control form-control-sm`,value:J.class_teacher,onChange:e=>Y({...J,class_teacher:e.target.value})})]}),(0,_.jsxs)(`div`,{className:`col-6`,children:[(0,_.jsx)(`label`,{className:`form-label text-xs fw-bold text-muted text-uppercase`,children:`Resumption Date`}),(0,_.jsx)(`input`,{type:`date`,className:`form-control form-control-sm`,value:J.resumption_date,onChange:e=>Y({...J,resumption_date:e.target.value})})]})]})]})}),(0,_.jsx)(`div`,{className:`col-12 col-lg-6`,children:(0,_.jsxs)(`div`,{className:`bg-white p-4 rounded-4 border shadow-sm h-100`,children:[(0,_.jsxs)(`h5`,{className:`fs-6 fw-bold text-dark mb-3 d-flex align-items-center gap-2`,children:[(0,_.jsx)(`i`,{className:`bi bi-calendar2-check-fill text-primary`}),` Attendance & Class Analytics`]}),(0,_.jsxs)(`div`,{className:`row g-3 mb-3`,children:[(0,_.jsxs)(`div`,{className:`col-6 col-sm-3`,children:[(0,_.jsx)(`label`,{className:`form-label text-xs fw-bold text-muted text-uppercase`,children:`School Opened`}),(0,_.jsx)(`input`,{type:`number`,className:`form-control form-control-sm text-center fw-bold`,value:J.school_open,onChange:e=>Y({...J,school_open:e.target.value})})]}),(0,_.jsxs)(`div`,{className:`col-6 col-sm-3`,children:[(0,_.jsx)(`label`,{className:`form-label text-xs fw-bold text-muted text-uppercase`,children:`Days Present`}),(0,_.jsx)(`input`,{type:`number`,className:`form-control form-control-sm text-center fw-bold`,value:J.no_present,onChange:e=>Y({...J,no_present:e.target.value})})]}),(0,_.jsxs)(`div`,{className:`col-6 col-sm-3`,children:[(0,_.jsx)(`label`,{className:`form-label text-xs fw-bold text-muted text-uppercase`,children:`Days Absent`}),(0,_.jsx)(`input`,{type:`number`,className:`form-control form-control-sm text-center fw-bold`,value:J.no_absent,onChange:e=>Y({...J,no_absent:e.target.value})})]}),(0,_.jsxs)(`div`,{className:`col-6 col-sm-3`,children:[(0,_.jsx)(`label`,{className:`form-label text-xs fw-bold text-muted text-uppercase`,children:`Class Size`}),(0,_.jsx)(`input`,{type:`number`,className:`form-control form-control-sm text-center fw-bold`,value:J.class_size,onChange:e=>Y({...J,class_size:e.target.value})})]})]}),(0,_.jsxs)(`div`,{className:`border-top pt-3 mt-3`,children:[(0,_.jsx)(`label`,{className:`form-label text-xs fw-bold text-muted text-uppercase mb-2`,children:`Behavioural & Skill Ratings (1 = Low, 5 = Excellent)`}),(0,_.jsx)(`div`,{className:`row g-2 text-xs`,children:[[`punctuality`,`Punctuality`],[`neatness`,`Neatness`],[`politeness`,`Politeness`],[`honesty`,`Honesty`],[`sports`,`Sports/Games`],[`crafts`,`Handicrafts`]].map(([e,t])=>(0,_.jsxs)(`div`,{className:`col-6 col-md-4 d-flex align-items-center justify-content-between bg-light p-2 rounded`,children:[(0,_.jsxs)(`span`,{className:`fw-semibold text-dark`,children:[t,`:`]}),(0,_.jsx)(`select`,{className:`form-select form-select-sm p-1 text-center fw-bold`,style:{width:`50px`},value:X[e],onChange:t=>me({...X,[e]:Number(t.target.value)}),children:[5,4,3,2,1].map(e=>(0,_.jsx)(`option`,{value:e,children:e},e))})]},e))})]})]})})]}),(0,_.jsxs)(`div`,{className:`d-flex align-items-center justify-content-between p-4 bg-white rounded-4 border shadow-sm flex-wrap gap-3`,children:[(0,_.jsx)(`div`,{children:(0,_.jsxs)(`span`,{className:`text-muted text-sm`,children:[`Editing results for `,(0,_.jsxs)(`strong`,{children:[R.firstname,` `,R.surname]}),` (`,R.reg_no,`) • `,E,`, `,w]})}),(0,_.jsxs)(`div`,{className:`d-flex align-items-center gap-3`,children:[(0,_.jsx)(`button`,{type:`button`,className:`btn btn-outline-secondary px-4 py-2 rounded-3 fw-bold`,onClick:()=>Q(),children:`Discard Changes`}),(0,_.jsx)(`button`,{type:`submit`,className:`re-btn-save`,disabled:P,children:P?(0,_.jsxs)(_.Fragment,{children:[(0,_.jsx)(`span`,{className:`spinner-border spinner-border-sm`}),` Saving...`]}):(0,_.jsxs)(_.Fragment,{children:[(0,_.jsx)(`i`,{className:`bi bi-cloud-arrow-up-fill`}),` Save & Update Result`]})})]})]})]}),A===`preview`&&(0,_.jsxs)(`div`,{className:`re-preview-container`,children:[(0,_.jsxs)(`div`,{className:`d-flex align-items-center justify-content-between mb-4 p-3 bg-white rounded-4 border shadow-sm flex-wrap gap-3 d-print-none`,children:[(0,_.jsxs)(`div`,{children:[(0,_.jsx)(`h4`,{className:`fs-6 fw-bold text-dark m-0`,children:`Official Student Terminal Assessment Report`}),(0,_.jsx)(`span`,{className:`text-muted text-xs`,children:`Formatted to match official school report card layout`})]}),(0,_.jsxs)(`div`,{className:`d-flex gap-2 flex-wrap`,children:[(0,_.jsxs)(`button`,{type:`button`,className:`btn btn-outline-primary btn-sm rounded-pill px-3 fw-bold`,onClick:()=>{let e=new URLSearchParams({school_id:String(R.school_id),class_id:String(O||R.level_id||``),student_id:String(R.id),term:E,session:w});window.open(`/results/show-result?${e.toString()}`,`_blank`)},children:[(0,_.jsx)(`i`,{className:`bi bi-box-arrow-up-right me-1`}),` Open in Full ShowResult Page`]}),(0,_.jsxs)(`button`,{type:`button`,className:`btn btn-secondary btn-sm rounded-pill px-3 fw-bold`,onClick:()=>window.print(),children:[(0,_.jsx)(`i`,{className:`bi bi-printer-fill me-1`}),` Print`]}),(0,_.jsx)(`button`,{type:`button`,className:`btn btn-primary btn-sm rounded-pill px-4 fw-bold`,disabled:I,onClick:he,children:I?(0,_.jsxs)(_.Fragment,{children:[(0,_.jsx)(`span`,{className:`spinner-border spinner-border-sm me-1`}),` Generating PDF...`]}):(0,_.jsxs)(_.Fragment,{children:[(0,_.jsx)(`i`,{className:`bi bi-file-earmark-pdf-fill me-1`}),` Download Official PDF`]})})]})]}),(0,_.jsxs)(`div`,{id:`admin-result-sheet`,style:{width:`min(780px, 100%)`,margin:`auto`,padding:`20px`,background:B.background_color||`#ffffff`,fontFamily:ae?.font_family||`Arial, sans-serif`,fontSize:`12px`,border:`3px solid ${B.primary_color||`#0d47a1`}`,borderRadius:`8px`,boxSizing:`border-box`,position:`relative`,overflow:`visible`,color:`#111827`,boxShadow:`0 10px 30px rgba(0,0,0,0.08)`},children:[B.logo&&(0,_.jsx)(`div`,{style:{position:`absolute`,top:0,left:0,width:`100%`,height:`100%`,backgroundImage:`url(${B.logo})`,backgroundRepeat:`repeat`,backgroundSize:`150px 150px`,opacity:.04,transform:`rotate(-30deg)`,zIndex:0,pointerEvents:`none`}}),(0,_.jsxs)(`div`,{style:{position:`relative`,zIndex:1},children:[(0,_.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`90px 1fr 90px`,gap:`12px`,alignItems:`center`,borderBottom:`2px solid ${B.primary_color||`#0d47a1`}`,paddingBottom:`10px`},children:[(0,_.jsx)(`img`,{src:B.logo||`https://via.placeholder.com/90x90.png?text=Logo`,alt:`School Logo`,onError:e=>{e.target.src=`https://via.placeholder.com/90x90.png?text=Logo`},style:{width:`90px`,height:`90px`,borderRadius:`6px`,objectFit:`cover`,border:`2px solid ${B.secondary_color||`#ffc107`}`}}),(0,_.jsxs)(`div`,{style:{flex:1,textAlign:`center`},children:[(0,_.jsx)(`h1`,{style:{margin:0,fontSize:`20px`,fontWeight:`bold`,color:B.primary_color||`#0d47a1`},children:B.name}),(0,_.jsx)(`p`,{style:{margin:`3px 0`,fontSize:`12px`},children:B.address}),(0,_.jsxs)(`p`,{style:{margin:`3px 0`,fontSize:`12px`},children:[`Tel: `,B.phone]}),(0,_.jsxs)(`h2`,{style:{margin:`6px 0`,fontSize:`15px`,textTransform:`uppercase`,background:B.primary_color||`#0d47a1`,color:b(B.primary_color||`#0d47a1`),padding:`6px 12px`,borderRadius:`6px`,textAlign:`center`,letterSpacing:`1px`,border:`1px solid ${B.secondary_color||`#ffc107`}`,fontWeight:700},children:[E,` REPORT SHEET • `,w]})]}),z||R.photo?(0,_.jsx)(`img`,{src:z||`/uploads/users/${R.photo}`,alt:`student photo`,onError:e=>{let t=e.target;t.onerror=null,t.style.display=`none`},style:{width:`90px`,height:`90px`,borderRadius:`6px`,objectFit:`cover`,border:`2px solid ${B.secondary_color||`#ffc107`}`}}):(0,_.jsx)(`div`,{style:{width:`90px`,height:`90px`,border:`2px dashed ${B.primary_color||`#0d47a1`}`,borderRadius:`6px`,display:`flex`,alignItems:`center`,justifyContent:`center`,fontSize:`11px`,color:`#666`,textAlign:`center`},children:`Student Photo`})]}),(0,_.jsx)(`div`,{style:{display:`grid`,gridTemplateColumns:`repeat(2, minmax(0, 1fr))`,gap:6,marginTop:10,fontSize:`11.5px`},children:[[`Name`,`${R.surname} ${R.firstname} ${R.othername||``}`.trim()],[`Admission No`,R.reg_no],[`Class`,R.level?.name||le.find(e=>String(e.id)===String(O))?.name||`SS2`],[`Session`,w],[`Gender`,R.gender||`N/A`],[`Term`,E],[`Class Size`,J.class_size||`N/A`],...J.position&&String(J.position).trim()!==``&&String(J.position).trim().toLowerCase()!==`n/a`&&String(J.position).trim()!==`-`&&String(J.position).trim().toLowerCase()!==`recorded`?[[`Position`,J.position]]:[],[`Times School Opened`,J.school_open||0],[`Times Present`,J.no_present||0],[`Times Absent`,J.no_absent||0],[`Resumption Date`,J.resumption_date||`To Be Announced`]].map(([e,t])=>(0,_.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,padding:`4px 8px`,background:`#f8fafc`,border:`1px solid ${x(B.primary_color||`#0d47a1`,.2)}`,borderRadius:`4px`},children:[(0,_.jsxs)(`strong`,{style:{color:B.primary_color||`#0d47a1`},children:[e,`:`]}),(0,_.jsx)(`span`,{style:{fontWeight:600},children:t})]},e))}),(0,_.jsx)(`div`,{style:{marginTop:12},children:(0,_.jsxs)(`table`,{style:{width:`100%`,borderCollapse:`collapse`,fontSize:`11.5px`},children:[(0,_.jsx)(`thead`,{children:(0,_.jsxs)(`tr`,{children:[(0,_.jsx)(`th`,{style:{border:`1px solid ${B.primary_color||`#0d47a1`}`,padding:`6px 4px`,textAlign:`center`,background:B.primary_color||`#0d47a1`,color:b(B.primary_color||`#0d47a1`),width:`30px`},children:`#`}),(0,_.jsx)(`th`,{style:{border:`1px solid ${B.primary_color||`#0d47a1`}`,padding:`6px 8px`,textAlign:`left`,background:B.primary_color||`#0d47a1`,color:b(B.primary_color||`#0d47a1`)},children:`Subject`}),Array.from({length:Z.caCount}).map((e,t)=>(0,_.jsxs)(`th`,{style:{border:`1px solid ${B.primary_color||`#0d47a1`}`,padding:`6px 4px`,textAlign:`center`,background:B.primary_color||`#0d47a1`,color:b(B.primary_color||`#0d47a1`),width:`65px`},children:[`CA `,t+1,` (`,Z.caMax,`)`]},t)),(0,_.jsxs)(`th`,{style:{border:`1px solid ${B.primary_color||`#0d47a1`}`,padding:`6px 4px`,textAlign:`center`,background:B.primary_color||`#0d47a1`,color:b(B.primary_color||`#0d47a1`),width:`65px`},children:[`Exam (`,Z.examMax,`)`]}),(0,_.jsx)(`th`,{style:{border:`1px solid ${B.primary_color||`#0d47a1`}`,padding:`6px 4px`,textAlign:`center`,background:B.primary_color||`#0d47a1`,color:b(B.primary_color||`#0d47a1`),width:`65px`},children:`Total (100)`}),(0,_.jsx)(`th`,{style:{border:`1px solid ${B.primary_color||`#0d47a1`}`,padding:`6px 4px`,textAlign:`center`,background:B.primary_color||`#0d47a1`,color:b(B.primary_color||`#0d47a1`),width:`55px`},children:`Grade`}),(0,_.jsx)(`th`,{style:{border:`1px solid ${B.primary_color||`#0d47a1`}`,padding:`6px 8px`,textAlign:`left`,background:B.primary_color||`#0d47a1`,color:b(B.primary_color||`#0d47a1`)},children:`Remark`})]})}),(0,_.jsx)(`tbody`,{children:K.map((e,t)=>{let n=Array.from({length:Z.caCount}).map((e,t)=>`ca${t+1}`),r=e.exam===``?0:Number(e.exam);return(0,_.jsxs)(`tr`,{style:{background:t%2==0?`#ffffff`:`#f8fafc`},children:[(0,_.jsx)(`td`,{style:{border:`1px solid ${x(B.primary_color||`#0d47a1`,.3)}`,padding:`6px 4px`,textAlign:`center`,fontWeight:`bold`,color:`#64748B`},children:t+1}),(0,_.jsx)(`td`,{style:{border:`1px solid ${x(B.primary_color||`#0d47a1`,.3)}`,padding:`6px 8px`,textAlign:`left`,fontWeight:`bold`,color:`#0F2744`},children:e.subject_name}),n.map((t,n)=>(0,_.jsx)(`td`,{style:{border:`1px solid ${x(B.primary_color||`#0d47a1`,.3)}`,padding:`6px 4px`,textAlign:`center`},children:e.ca?.[t]!==void 0&&e.ca?.[t]!==null&&e.ca?.[t]!==``?e.ca[t]:n===0?e.ca?.ca0??e.ca?.[`0`]??`-`:`-`},t)),(0,_.jsx)(`td`,{style:{border:`1px solid ${x(B.primary_color||`#0d47a1`,.3)}`,padding:`6px 4px`,textAlign:`center`},children:r}),(0,_.jsx)(`td`,{style:{border:`1px solid ${x(B.primary_color||`#0d47a1`,.3)}`,padding:`6px 4px`,textAlign:`center`,fontWeight:`bold`,color:`#0F2744`},children:e.total}),(0,_.jsx)(`td`,{style:{border:`1px solid ${x(B.primary_color||`#0d47a1`,.3)}`,padding:`6px 4px`,textAlign:`center`,fontWeight:`bold`},children:(0,_.jsx)(`span`,{className:`re-grade-tag re-grade-${e.grade?.charAt(0)||`F`}`,children:e.grade})}),(0,_.jsx)(`td`,{style:{border:`1px solid ${x(B.primary_color||`#0d47a1`,.3)}`,padding:`6px 8px`,textAlign:`left`},children:e.remark})]},t)})})]})}),(0,_.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:J.position&&String(J.position).trim()!==``&&String(J.position).trim().toLowerCase()!==`n/a`&&String(J.position).trim()!==`-`&&String(J.position).trim().toLowerCase()!==`recorded`?`repeat(4, 1fr)`:`repeat(3, 1fr)`,gap:8,marginTop:12,textAlign:`center`},children:[(0,_.jsxs)(`div`,{style:{padding:`8px`,background:`#f8fafc`,border:`1px solid ${x(B.primary_color||`#0d47a1`,.3)}`,borderRadius:`6px`},children:[(0,_.jsx)(`div`,{style:{fontSize:`10px`,color:`#64748B`,fontWeight:700,textTransform:`uppercase`},children:`Total Marks`}),(0,_.jsx)(`div`,{style:{fontSize:`16px`,fontWeight:800,color:B.primary_color||`#0d47a1`},children:K.reduce((e,t)=>e+Number(t.total||0),0)})]}),(0,_.jsxs)(`div`,{style:{padding:`8px`,background:`#f8fafc`,border:`1px solid ${x(B.primary_color||`#0d47a1`,.3)}`,borderRadius:`6px`},children:[(0,_.jsx)(`div`,{style:{fontSize:`10px`,color:`#64748B`,fontWeight:700,textTransform:`uppercase`},children:`Overall Average`}),(0,_.jsxs)(`div`,{style:{fontSize:`16px`,fontWeight:800,color:`#16A34A`},children:[J.total_average,`%`]})]}),(0,_.jsxs)(`div`,{style:{padding:`8px`,background:`#f8fafc`,border:`1px solid ${x(B.primary_color||`#0d47a1`,.3)}`,borderRadius:`6px`},children:[(0,_.jsx)(`div`,{style:{fontSize:`10px`,color:`#64748B`,fontWeight:700,textTransform:`uppercase`},children:`Overall Grade`}),(0,_.jsx)(`div`,{style:{fontSize:`16px`,fontWeight:800,color:B.primary_color||`#0d47a1`},children:J.total_grade||y(Number(J.total_average)||0).grade})]}),J.position&&String(J.position).trim()!==``&&String(J.position).trim().toLowerCase()!==`n/a`&&String(J.position).trim()!==`-`&&String(J.position).trim().toLowerCase()!==`recorded`&&(0,_.jsxs)(`div`,{style:{padding:`8px`,background:`#f8fafc`,border:`1px solid ${x(B.primary_color||`#0d47a1`,.3)}`,borderRadius:`6px`},children:[(0,_.jsx)(`div`,{style:{fontSize:`10px`,color:`#64748B`,fontWeight:700,textTransform:`uppercase`},children:`Class Position`}),(0,_.jsx)(`div`,{style:{fontSize:`16px`,fontWeight:800,color:B.primary_color||`#0d47a1`},children:J.position})]})]}),(0,_.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`1fr 1fr`,gap:10,marginTop:12},children:[(0,_.jsxs)(`div`,{children:[(0,_.jsx)(`div`,{style:{fontSize:`11px`,fontWeight:700,color:B.primary_color||`#0d47a1`,textTransform:`uppercase`,marginBottom:4},children:`Affective Domain Traits`}),(0,_.jsxs)(`table`,{style:{width:`100%`,borderCollapse:`collapse`,border:`1px solid ${B.primary_color||`#0d47a1`}`,fontSize:`11px`},children:[(0,_.jsx)(`thead`,{children:(0,_.jsxs)(`tr`,{children:[(0,_.jsx)(`th`,{style:{background:B.primary_color||`#0d47a1`,color:b(B.primary_color||`#0d47a1`),fontSize:`10.5px`,padding:`4px`,textAlign:`left`},children:`Trait / Attribute`}),(0,_.jsx)(`th`,{style:{background:B.primary_color||`#0d47a1`,color:b(B.primary_color||`#0d47a1`),fontSize:`10.5px`,padding:`4px`,width:`70px`,textAlign:`center`},children:`Score (1-5)`})]})}),(0,_.jsx)(`tbody`,{children:[[`Punctuality`,X.punctuality],[`Attendance`,X.attendance],[`Neatness`,X.neatness],[`Politeness`,X.politeness],[`Honesty`,X.honesty]].map(([e,t],n)=>(0,_.jsxs)(`tr`,{style:{background:n%2==0?`#fff`:`#f8fafc`},children:[(0,_.jsx)(`td`,{style:{border:`1px solid ${x(B.primary_color||`#0d47a1`,.3)}`,textAlign:`left`,padding:`3px 6px`},children:e}),(0,_.jsx)(`td`,{style:{border:`1px solid ${x(B.primary_color||`#0d47a1`,.3)}`,padding:`3px`,fontWeight:`bold`,textAlign:`center`},children:t})]},n))})]})]}),(0,_.jsxs)(`div`,{children:[(0,_.jsx)(`div`,{style:{fontSize:`11px`,fontWeight:700,color:B.primary_color||`#0d47a1`,textTransform:`uppercase`,marginBottom:4},children:`Psychomotor & Skills`}),(0,_.jsxs)(`table`,{style:{width:`100%`,borderCollapse:`collapse`,border:`1px solid ${B.primary_color||`#0d47a1`}`,fontSize:`11px`},children:[(0,_.jsx)(`thead`,{children:(0,_.jsxs)(`tr`,{children:[(0,_.jsx)(`th`,{style:{background:B.primary_color||`#0d47a1`,color:b(B.primary_color||`#0d47a1`),fontSize:`10.5px`,padding:`4px`,textAlign:`left`},children:`Skill / Domain`}),(0,_.jsx)(`th`,{style:{background:B.primary_color||`#0d47a1`,color:b(B.primary_color||`#0d47a1`),fontSize:`10.5px`,padding:`4px`,width:`70px`,textAlign:`center`},children:`Score (1-5)`})]})}),(0,_.jsx)(`tbody`,{children:[[`Sports & Athletics`,X.sports],[`Handicrafts & Arts`,X.crafts],[`Music & Performance`,X.music],[`Handwriting`,X.handwriting],[`Leadership Ability`,X.leadership]].map(([e,t],n)=>(0,_.jsxs)(`tr`,{style:{background:n%2==0?`#fff`:`#f8fafc`},children:[(0,_.jsx)(`td`,{style:{border:`1px solid ${x(B.primary_color||`#0d47a1`,.3)}`,textAlign:`left`,padding:`3px 6px`},children:e}),(0,_.jsx)(`td`,{style:{border:`1px solid ${x(B.primary_color||`#0d47a1`,.3)}`,padding:`3px`,fontWeight:`bold`,textAlign:`center`},children:t})]},n))})]})]})]}),(0,_.jsxs)(`div`,{style:{marginTop:12,border:`1px solid ${x(B.primary_color||`#0d47a1`,.3)}`,borderRadius:`6px`,padding:`10px`,background:`#f8fafc`},children:[(0,_.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`1fr 90px`,gap:12,alignItems:`center`},children:[(0,_.jsxs)(`div`,{children:[(0,_.jsxs)(`div`,{style:{marginBottom:`6px`,fontSize:`11.5px`},children:[(0,_.jsx)(`strong`,{children:`Class Teacher's Remark:`}),` `,(0,_.jsx)(`span`,{style:{color:`#334155`},children:J.class_teacher_comment||`Commendable effort this term.`})]}),(0,_.jsxs)(`div`,{style:{marginBottom:`6px`,fontSize:`11.5px`},children:[(0,_.jsx)(`strong`,{children:`Principal's Remark:`}),` `,(0,_.jsx)(`span`,{style:{color:`#334155`},children:J.principal_comment||`Good academic progress recorded.`})]}),(0,_.jsxs)(`div`,{style:{fontSize:`11px`,color:`#64748B`},children:[(0,_.jsx)(`strong`,{children:`Next Term Resumption:`}),` `,J.resumption_date||`To be communicated`,` •`,` `,(0,_.jsx)(`strong`,{children:`General Remark:`}),` `,J.general_remark||`Promoted with Credit`]})]}),(0,_.jsxs)(`div`,{style:{textAlign:`center`},children:[V&&(0,_.jsx)(`img`,{src:V,alt:`QR Verification`,style:{width:`70px`,height:`70px`,margin:`auto`,display:`block`}}),(0,_.jsx)(`div`,{style:{fontSize:`8.5px`,color:`#64748B`,marginTop:`2px`,fontWeight:700},children:`VERIFIED SEAL`})]})]}),B.principal_signature&&(0,_.jsx)(`div`,{style:{display:`flex`,justifyContent:`flex-end`,marginTop:`8px`,borderTop:`1px dashed #cbd5e1`,paddingTop:`6px`},children:(0,_.jsxs)(`div`,{style:{textAlign:`center`},children:[(0,_.jsx)(`img`,{src:B.principal_signature,alt:`Principal Signature`,style:{height:`35px`,display:`block`,margin:`auto`}}),(0,_.jsx)(`div`,{style:{fontSize:`10px`,fontWeight:700,color:B.primary_color||`#0d47a1`},children:`Principal's Authorized Stamp`})]})})]})]})]})]})]}):(0,_.jsxs)(`div`,{className:`bg-white p-5 rounded-4 border text-center my-4 shadow-sm`,children:[(0,_.jsx)(`div`,{className:`mx-auto mb-3 d-flex align-items-center justify-content-center rounded-circle`,style:{width:`80px`,height:`80px`,background:`rgba(217, 119, 6, 0.12)`,color:`#D97706`},children:(0,_.jsx)(`i`,{className:`bi bi-search fs-1`})}),(0,_.jsx)(`h3`,{className:`fs-5 fw-bold text-dark mb-2`,children:`Search Student by Admission / Registration Number`}),(0,_.jsx)(`p`,{className:`text-muted text-sm max-w-md mx-auto mb-4`,style:{maxWidth:`540px`},children:`Enter any student's registered admission number above to retrieve their complete continuous assessment, examination marks, and affective ratings for live editing or printing.`}),(0,_.jsxs)(`div`,{className:`d-flex justify-content-center gap-2`,children:[(0,_.jsxs)(`span`,{className:`badge bg-light text-muted border px-3 py-2`,children:[(0,_.jsx)(`i`,{className:`bi bi-check-circle-fill text-success me-1`}),` Live CA & Exam Recalculation`]}),(0,_.jsxs)(`span`,{className:`badge bg-light text-muted border px-3 py-2`,children:[(0,_.jsx)(`i`,{className:`bi bi-check-circle-fill text-success me-1`}),` Permanent Academic Access`]})]})]}),(0,_.jsx)(p,{})]})]})})]})}export{S as default};