import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{S as t,p as n,x as r}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as i,E as a,P as o,d as s,f as c,u as l}from"./index-D6TxbaCx.js";var u=e(),d=n();function f(e){let t=Number(e??0);return Number.isNaN(t)?`₦0.00`:new Intl.NumberFormat(`en-NG`,{style:`currency`,currency:`NGN`}).format(t)}function p(e){try{return navigator.clipboard.writeText(e),!0}catch{return!1}}function m(){let[e,n]=(0,u.useState)(!1),[m,h]=(0,u.useState)(!0),[g,_]=(0,u.useState)(null),[v,y]=(0,u.useState)(``),[b,x]=(0,u.useState)(null),[S,C]=(0,u.useState)(!1),[w,T]=(0,u.useState)(!1),[E,D]=(0,u.useState)(null),{studentId:O}=t(),k=r(),A=async()=>{if(O){h(!0),y(``);try{_((await o.get(`/parent/students/${O}/fees`)).data)}catch(e){console.error(e),y(e?.response?.data?.message||`Failed to load fee details.`)}finally{h(!1)}}};(0,u.useEffect)(()=>{A()},[O]);let j=async()=>{if(O){C(!0),T(!0),D(null);try{D((await o.get(`/parent/students/${O}/bank-accounts`)).data)}catch(e){console.error(e),D(null)}finally{T(!1)}}},M=(0,u.useMemo)(()=>{let e=g?.student;return e?`${e.firstname||``} ${e.surname||``}`.trim():``},[g]);(0,u.useMemo)(()=>{let e=g?.student;return e&&`${e.firstname?.[0]||``}${e.surname?.[0]||``}`.toUpperCase()||`ST`},[g]);let N=e=>{p(e.account_number),x(e.id),setTimeout(()=>x(null),2e3)},P=e=>{let t=(e||`unpaid`).toLowerCase();return t===`paid`?(0,d.jsxs)(`span`,{className:`badge bg-success-subtle text-success fw-bold px-2 py-1`,children:[(0,d.jsx)(`i`,{className:`bi bi-check-circle-fill me-1`}),`Paid in Full`]}):t===`partial`?(0,d.jsxs)(`span`,{className:`badge bg-warning-subtle text-warning fw-bold px-2 py-1`,children:[(0,d.jsx)(`i`,{className:`bi bi-clock-history me-1`}),`Partially Paid`]}):(0,d.jsxs)(`span`,{className:`badge bg-danger-subtle text-danger fw-bold px-2 py-1`,children:[(0,d.jsx)(`i`,{className:`bi bi-exclamation-circle-fill me-1`}),`Unpaid Balance`]})};return(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');

        .p-fee-main {
          background: #F8FAFC;
          min-height: 100vh;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          padding: calc(66px + 24px) 28px 40px !important;
        }

        @media (max-width: 767.98px) {
          .p-fee-main {
            padding: calc(66px + 16px) 14px 36px !important;
          }
        }

        .p-fee-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 18px;
          padding: 32px 36px;
          color: #FFFFFF;
          margin-bottom: 24px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
          position: relative;
          overflow: hidden;
        }

        @media (max-width: 767.98px) {
          .p-fee-hero {
            padding: 20px 18px !important;
            border-radius: 14px !important;
            margin-bottom: 16px !important;
          }
        }

        .p-fee-hero::before {
          content: '';
          position: absolute;
          inset: 0;
          background-image:
            linear-gradient(rgba(255, 255, 255, 0.035) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255, 255, 255, 0.035) 1px, transparent 1px);
          background-size: 32px 32px;
          pointer-events: none;
        }

        .p-fee-hero-glow {
          position: absolute;
          top: -40px;
          right: -40px;
          width: 320px;
          height: 320px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.2) 0%, transparent 65%);
          pointer-events: none;
        }

        .p-fee-hero-inner {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: center;
          justify-content: space-between;
          flex-wrap: wrap;
          gap: 20px;
        }

        .p-fee-badge {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.20);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius: 100px;
          padding: 4px 12px;
          margin-bottom: 12px;
        }

        .p-fee-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #10B981;
          box-shadow: 0 0 6px #10B981;
        }

        .p-fee-title {
          font-size: 26px;
          font-weight: 800;
          color: #FFFFFF;
          line-height: 1.1;
          margin-bottom: 8px;
        }

        .p-fee-title em {
          font-style: normal;
          color: #FBBF24;
        }

        .p-fee-sub {
          font-size: 13.5px;
          color: #CBD5E1;
          line-height: 1.6;
          max-width: 620px;
          margin-bottom: 0;
        }

        @media (max-width: 767.98px) {
          .p-fee-title {
            font-size: 20px !important;
          }
          .p-fee-sub {
            font-size: 12.5px !important;
          }
        }

        /* KPI Stat Cards */
        .p-stat-card {
          background: #FFFFFF;
          border: 1px solid rgba(15, 39, 68, 0.08);
          border-radius: 16px;
          padding: 20px 24px;
          box-shadow: 0 2px 10px rgba(15, 39, 68, 0.04);
          transition: all 0.2s ease;
        }

        .p-stat-card:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 24px rgba(15, 39, 68, 0.08);
        }

        /* Panel */
        .p-fee-panel {
          background: #FFFFFF;
          border: 1px solid rgba(15, 39, 68, 0.08);
          border-radius: 18px;
          box-shadow: 0 4px 20px rgba(15, 39, 68, 0.06);
          overflow: hidden;
          margin-bottom: 24px;
        }

        .p-fee-panel-head {
          padding: 18px 24px;
          border-bottom: 1px solid #E2E8F0;
          display: flex;
          align-items: center;
          justify-content: space-between;
          flex-wrap: wrap;
          gap: 12px;
        }

        .p-fee-table {
          width: 100%;
          border-collapse: collapse;
        }

        .p-fee-table th {
          background: #F8FAFC;
          color: #64748B;
          font-size: 11.5px;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.04em;
          padding: 12px 18px;
          border-bottom: 1px solid #E2E8F0;
        }

        .p-fee-table td {
          padding: 14px 18px;
          border-bottom: 1px solid #F1F5F9;
          font-size: 13.5px;
          color: #1E293B;
          vertical-align: middle;
        }

        .p-fee-table tr:hover td {
          background: #F8FAFC;
        }
      `}),(0,d.jsx)(c,{sidebarOpen:e,setSidebarOpen:n}),(0,d.jsx)(i,{title:`Fee Details - ${M||`Student`}`}),(0,d.jsx)(`div`,{className:`container-fluid`,children:(0,d.jsxs)(`div`,{className:`row`,children:[(0,d.jsx)(s,{sidebarOpen:e,setSidebarOpen:n}),(0,d.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto gq-app-main p-fee-main d-flex flex-column min-vh-100`,children:[m&&(0,d.jsx)(a,{message:`Loading fee details...`}),(0,d.jsxs)(`div`,{className:`p-fee-hero`,children:[(0,d.jsx)(`div`,{className:`p-fee-hero-glow`}),(0,d.jsxs)(`div`,{className:`p-fee-hero-inner`,children:[(0,d.jsxs)(`div`,{children:[(0,d.jsxs)(`div`,{className:`p-fee-badge`,children:[(0,d.jsx)(`span`,{className:`p-fee-dot`}),`Parent Portal · Fee & Payment Breakdown`]}),(0,d.jsxs)(`h1`,{className:`p-fee-title`,children:[`Fee Statement: `,(0,d.jsx)(`em`,{children:M||`Ward`})]}),(0,d.jsxs)(`p`,{className:`p-fee-sub`,children:[g?.filters?.term?.name||`Current Term`,` · `,g?.filters?.session?.name||`Session`,` · Reg No: `,(0,d.jsx)(`strong`,{children:g?.student?.reg_no||`—`})]})]}),(0,d.jsxs)(`div`,{className:`d-flex gap-2 flex-wrap`,children:[(0,d.jsxs)(`button`,{type:`button`,className:`btn btn-outline-light rounded-pill px-4 fw-bold`,onClick:()=>k(`/parent/children`),children:[(0,d.jsx)(`i`,{className:`bi bi-arrow-left me-1`}),`My Children`]}),(0,d.jsxs)(`button`,{type:`button`,className:`btn btn-warning rounded-pill px-4 fw-bold`,style:{color:`#0F2744`,background:`#FBBF24`},onClick:j,disabled:!g,children:[(0,d.jsx)(`i`,{className:`bi bi-bank2 me-1`}),`School Bank Accounts`]})]})]})]}),v&&(0,d.jsxs)(`div`,{className:`alert alert-danger rounded-4 mb-4 shadow-sm`,children:[(0,d.jsx)(`i`,{className:`bi bi-exclamation-triangle-fill me-2`}),v]}),(0,d.jsxs)(`div`,{className:`row g-3 mb-4`,children:[(0,d.jsx)(`div`,{className:`col-sm-6 col-xl-3`,children:(0,d.jsxs)(`div`,{className:`p-stat-card border-start border-primary border-4`,children:[(0,d.jsx)(`div`,{className:`small fw-bold text-uppercase text-muted mb-1`,children:`Total Fee Assessed`}),(0,d.jsx)(`div`,{className:`fs-3 fw-bold text-dark`,children:f(g?.summary?.total)}),(0,d.jsx)(`div`,{className:`small text-muted`,children:`Curriculum & facility fees`})]})}),(0,d.jsx)(`div`,{className:`col-sm-6 col-xl-3`,children:(0,d.jsxs)(`div`,{className:`p-stat-card border-start border-success border-4`,children:[(0,d.jsx)(`div`,{className:`small fw-bold text-uppercase text-muted mb-1`,children:`Total Amount Paid`}),(0,d.jsx)(`div`,{className:`fs-3 fw-bold text-success`,children:f(g?.summary?.paid)}),(0,d.jsx)(`div`,{className:`small text-muted`,children:`Confirmed bank & online receipts`})]})}),(0,d.jsx)(`div`,{className:`col-sm-6 col-xl-3`,children:(0,d.jsxs)(`div`,{className:`p-stat-card border-start border-danger border-4`,children:[(0,d.jsx)(`div`,{className:`small fw-bold text-uppercase text-muted mb-1`,children:`Outstanding Balance`}),(0,d.jsx)(`div`,{className:`fs-3 fw-bold ${(g?.summary?.balance||0)<=0?`text-success`:`text-danger`}`,children:f(g?.summary?.balance)}),(0,d.jsx)(`div`,{className:`small text-muted`,children:`Amount currently due`})]})}),(0,d.jsx)(`div`,{className:`col-sm-6 col-xl-3`,children:(0,d.jsxs)(`div`,{className:`p-stat-card border-start border-warning border-4`,children:[(0,d.jsx)(`div`,{className:`small fw-bold text-uppercase text-muted mb-1`,children:`Payment Status`}),(0,d.jsx)(`div`,{className:`mt-1`,children:P(g?.summary?.status)}),(0,d.jsx)(`div`,{className:`small text-muted mt-2`,children:`Overall account clearance`})]})})]}),(0,d.jsxs)(`div`,{className:`p-fee-panel mb-4`,children:[(0,d.jsxs)(`div`,{className:`p-fee-panel-head`,children:[(0,d.jsxs)(`div`,{children:[(0,d.jsxs)(`h2`,{className:`fs-6 fw-bold mb-0 text-dark`,children:[(0,d.jsx)(`i`,{className:`bi bi-receipt me-2 text-primary`}),`Itemized Fee Schedule`]}),(0,d.jsx)(`small`,{className:`text-muted`,children:`Itemized breakdown for the academic term`})]}),(0,d.jsxs)(`div`,{className:`d-flex gap-2`,children:[(0,d.jsxs)(`button`,{type:`button`,className:`btn btn-sm btn-outline-secondary rounded-pill px-3`,onClick:A,children:[(0,d.jsx)(`i`,{className:`bi bi-arrow-clockwise me-1`}),`Refresh`]}),(0,d.jsxs)(`button`,{type:`button`,className:`btn btn-sm btn-primary rounded-pill px-3 fw-bold`,onClick:()=>k(`/parent/upload-receipt`),children:[(0,d.jsx)(`i`,{className:`bi bi-cloud-arrow-up-fill me-1`}),`Upload Bank Receipt`]})]})]}),(0,d.jsx)(`div`,{className:`table-responsive`,children:(0,d.jsxs)(`table`,{className:`p-fee-table`,children:[(0,d.jsx)(`thead`,{children:(0,d.jsxs)(`tr`,{children:[(0,d.jsx)(`th`,{children:`#`}),(0,d.jsx)(`th`,{children:`Fee Description`}),(0,d.jsx)(`th`,{children:`Assessed Amount`}),(0,d.jsx)(`th`,{children:`Amount Paid`}),(0,d.jsx)(`th`,{children:`Balance Due`}),(0,d.jsx)(`th`,{children:`Status`})]})}),(0,d.jsx)(`tbody`,{children:!g?.items||g.items.length===0?(0,d.jsx)(`tr`,{children:(0,d.jsxs)(`td`,{colSpan:6,className:`text-center py-5 text-muted`,children:[(0,d.jsx)(`i`,{className:`bi bi-cash-stack fs-2 d-block mb-2 text-secondary`}),`No specific fee items assigned for this term.`]})}):g.items.map((e,t)=>(0,d.jsxs)(`tr`,{children:[(0,d.jsx)(`td`,{className:`text-muted small`,children:t+1}),(0,d.jsx)(`td`,{className:`fw-bold text-dark`,children:e.fee_name}),(0,d.jsx)(`td`,{children:f(e.total_amount)}),(0,d.jsx)(`td`,{className:`text-success fw-bold`,children:f(e.amount_paid)}),(0,d.jsx)(`td`,{className:`fw-bold ${Number(e.balance||0)<=0?`text-success`:`text-danger`}`,children:f(e.balance)}),(0,d.jsx)(`td`,{children:P(e.status)})]},e.id||t))})]})})]}),S&&(0,d.jsx)(`div`,{className:`modal show d-block gq-modal-backdrop`,style:{background:`rgba(15, 39, 68, 0.6)`,backdropFilter:`blur(4px)`},children:(0,d.jsx)(`div`,{className:`modal-dialog modal-dialog-centered modal-lg`,children:(0,d.jsxs)(`div`,{className:`modal-content rounded-4 border-0 shadow-lg overflow-hidden`,children:[(0,d.jsxs)(`div`,{className:`modal-header text-white`,style:{background:`linear-gradient(135deg, #0A192F 0%, #0F2744 100%)`},children:[(0,d.jsxs)(`h5`,{className:`modal-title fw-bold fs-6`,children:[(0,d.jsx)(`i`,{className:`bi bi-bank me-2 text-warning`}),`School Official Bank Accounts`]}),(0,d.jsx)(`button`,{type:`button`,className:`btn-close btn-close-white`,onClick:()=>C(!1)})]}),(0,d.jsxs)(`div`,{className:`modal-body p-4`,children:[w&&(0,d.jsx)(`div`,{className:`text-center py-4`,children:(0,d.jsx)(a,{message:`Loading bank details...`})}),!w&&(!E?.accounts||E.accounts.length===0)&&(0,d.jsxs)(`div`,{className:`text-center py-5 text-muted`,children:[(0,d.jsx)(`i`,{className:`bi bi-building-x fs-1 d-block mb-2`}),`No bank accounts currently listed by the school.`]}),!w&&E?.accounts&&E.accounts.length>0&&(0,d.jsx)(`div`,{className:`row g-3`,children:E.accounts.map(e=>(0,d.jsx)(`div`,{className:`col-md-6`,children:(0,d.jsxs)(`div`,{className:`border rounded-4 p-3 bg-light position-relative h-100`,children:[(0,d.jsxs)(`div`,{className:`d-flex justify-content-between align-items-start mb-2`,children:[(0,d.jsx)(`span`,{className:`badge bg-primary-subtle text-primary fw-bold`,children:e.bank_name}),(0,d.jsxs)(`button`,{type:`button`,className:`btn btn-sm ${b===e.id?`btn-success`:`btn-outline-secondary`} rounded-pill`,onClick:()=>N(e),children:[(0,d.jsx)(`i`,{className:`bi ${b===e.id?`bi-check-lg`:`bi-clipboard`} me-1`}),b===e.id?`Copied!`:`Copy`]})]}),(0,d.jsx)(`div`,{className:`fs-5 fw-bold text-dark mb-1 font-monospace`,children:e.account_number}),(0,d.jsxs)(`div`,{className:`small text-muted`,children:[`Account Name: `,(0,d.jsx)(`strong`,{children:e.account_name})]})]})},e.id))}),(0,d.jsxs)(`div`,{className:`alert alert-info rounded-3 mt-4 small mb-0`,children:[(0,d.jsx)(`i`,{className:`bi bi-info-circle-fill me-2`}),`After making a direct bank deposit or electronic transfer, please use the `,(0,d.jsx)(`strong`,{children:`Upload Bank Receipt`}),` button to attach your payment receipt for bursary clearance.`]})]}),(0,d.jsxs)(`div`,{className:`modal-footer bg-light`,children:[(0,d.jsx)(`button`,{type:`button`,className:`btn btn-secondary rounded-pill px-4`,onClick:()=>C(!1),children:`Close`}),(0,d.jsxs)(`button`,{type:`button`,className:`btn btn-primary rounded-pill px-4 fw-bold`,onClick:()=>{C(!1),k(`/parent/upload-receipt`)},children:[(0,d.jsx)(`i`,{className:`bi bi-cloud-arrow-up me-1`}),`Proceed to Upload Receipt`]})]})]})})}),(0,d.jsx)(l,{})]})]})})]})}export{m as default};