import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{p as t}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as n,E as r,P as i,d as a,f as o,l as s,u as c}from"./index-D6TxbaCx.js";var l=e(),u=t();function d(e){return e?e.slice(0,5):``}function f(){let e=new Date().getHours();return e<12?`Good morning`:e<17?`Good afternoon`:`Good evening`}function p(e,t){if(!e)return``;let[n,r]=e.split(`:`).map(e=>Number(e));if(Number.isNaN(n)||Number.isNaN(r))return``;let i=new Date;return i.setHours(n,r,0,0),i.setMinutes(i.getMinutes()+(Number(t)||0)),`${String(i.getHours()).padStart(2,`0`)}:${String(i.getMinutes()).padStart(2,`0`)}`}function m(){let[e,t]=(0,l.useState)(!1),{showError:m,showSuccess:h}=s(),[g,_]=(0,l.useState)(!0),[v,y]=(0,l.useState)(!1),[b,x]=(0,l.useState)({staff_checkin_time:`08:00`,grace_minutes:10,staff_checkout_time:``,absent_after_time:``,school_latitude:``,school_longitude:``,allowed_radius_meters:100,qr_expires_seconds:300,require_location_verification:!0,is_active:!0}),S=async()=>{try{_(!0);let e=(await i.get(`/attendance-settings`)).data?.data;x({staff_checkin_time:d(e.staff_checkin_time)||`08:00`,grace_minutes:e.grace_minutes??10,staff_checkout_time:d(e.staff_checkout_time),absent_after_time:d(e.absent_after_time),school_latitude:e.school_latitude??``,school_longitude:e.school_longitude??``,allowed_radius_meters:e.allowed_radius_meters??100,qr_expires_seconds:e.qr_expires_seconds??60,require_location_verification:e.require_location_verification??!0,is_active:!!e.is_active})}catch(e){console.error(e),m?.(e?.response?.data?.message||`Failed to load attendance settings`)}finally{_(!1)}};(0,l.useEffect)(()=>{S()},[]);let C=async()=>{try{if(y(!0),!b.staff_checkin_time)return m?.(`Check-in time is required`);if(Number(b.grace_minutes)<0||Number(b.grace_minutes)>180)return m?.(`Grace minutes must be between 0 and 180`);if(Number(b.allowed_radius_meters)<10||Number(b.allowed_radius_meters)>5e3)return m?.(`Allowed distance must be between 10 and 5000 meters`);if(Number(b.qr_expires_seconds)<60||Number(b.qr_expires_seconds)>600)return m?.(`QR expiry must be between 60 and 600 seconds`);let e={staff_checkin_time:b.staff_checkin_time,grace_minutes:Number(b.grace_minutes),staff_checkout_time:b.staff_checkout_time||null,absent_after_time:b.absent_after_time||null,school_latitude:b.school_latitude===``?null:Number(b.school_latitude),school_longitude:b.school_longitude===``?null:Number(b.school_longitude),allowed_radius_meters:Number(b.allowed_radius_meters),qr_expires_seconds:Number(b.qr_expires_seconds),require_location_verification:b.require_location_verification,is_active:b.is_active},t=await i.put(`/attendance-settings`,e);h?.(t.data?.message||`Saved`),await S()}catch(e){console.error(e),m?.(e?.response?.data?.message||`Failed to save settings`)}finally{y(!1)}},w=()=>{if(!navigator.geolocation){m?.(`Location is not supported on this browser`);return}navigator.geolocation.getCurrentPosition(e=>{x(t=>({...t,school_latitude:e.coords.latitude.toFixed(7),school_longitude:e.coords.longitude.toFixed(7)})),h?.(`School location captured`)},()=>m?.(`Please allow location access to capture the school location`),{enableHighAccuracy:!0,timeout:12e3,maximumAge:0})},T=(0,l.useMemo)(()=>b.is_active?{bg:`rgba(34,197,94,0.18)`,fg:`#22c55e`,text:`Enabled`,dot:`#22c55e`}:{bg:`rgba(239,68,68,0.18)`,fg:`#f87171`,text:`Disabled`,dot:`#f87171`},[b.is_active]),E=(0,l.useMemo)(()=>p(b.staff_checkin_time,Number(b.grace_minutes)||0)||`—`,[b.staff_checkin_time,b.grace_minutes]),D=(0,l.useMemo)(()=>[{label:`Check-in`,value:b.staff_checkin_time||`—`,hint:`Expected time`,icon:`clock`,top:`linear-gradient(135deg,#3b82f6 0%,#60a5fa 100%)`},{label:`Grace`,value:`${Number(b.grace_minutes)||0} min`,hint:`Late buffer`,icon:`hourglass-split`,top:`linear-gradient(135deg,#f59e0b 0%,#fbbf24 100%)`},{label:`Late after`,value:E,hint:`Check-in + grace`,icon:`alarm`,top:`linear-gradient(135deg,#16a34a 0%,#22c55e 100%)`},{label:`Status`,value:T.text,hint:`Rule engine`,icon:b.is_active?`check2-circle`:`x-circle`,top:b.is_active?`linear-gradient(135deg,#22c55e 0%,#86efac 100%)`:`linear-gradient(135deg,#ef4444 0%,#fda4af 100%)`}],[b.staff_checkin_time,b.grace_minutes,E,T.text,b.is_active]);return(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`style`,{children:`
    /* ======= AttendanceSettingsPage - Modern SaaS style ======= */
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');
    .db-main {
      background: #F8FAFC;
      min-height: 100vh;
      font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
      padding: 24px 28px 0;
    }
    @media (max-width: 991.98px) { .db-main { padding: 18px 14px 0; } }

    .db-hero {
      background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
      border-radius: 18px;
      padding: 32px 36px;
      position: relative;
      overflow: hidden;
      margin: 10px 0 24px;
      box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
    }
    .db-hero-glow {
      position: absolute;
      top: -60px;
      right: -60px;
      width: 320px;
      height: 320px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(217, 119, 6, 0.15) 0%, transparent 65%);
      pointer-events: none;
    }
    .db-hero-glow2 {
      position: absolute;
      bottom: -40px;
      left: 26%;
      width: 220px;
      height: 220px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(37, 99, 235, 0.10) 0%, transparent 70%);
      pointer-events: none;
    }
    .db-hero-inner {
      position: relative;
      z-index: 1;
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
      gap: 28px;
      flex-wrap: wrap;
    }

    .db-session-badge {
      display: inline-flex;
      align-items: center;
      gap: 7px;
      font-size: 11.5px;
      font-weight: 700;
      letter-spacing: 0.04em;
      text-transform: uppercase;
      color: #FBBF24;
      background: rgba(217, 119, 6, 0.20);
      border: 1px solid rgba(217, 119, 6, 0.35);
      border-radius: 100px;
      padding: 4px 12px;
      margin-bottom: 12px;
    }
    .db-session-dot {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: #10B981;
      animation: dbPulse 2s ease infinite;
    }
    @keyframes dbPulse {
      0%,100% { opacity: 1; transform: scale(1); }
      50% { opacity: 0.4; transform: scale(1.5); }
    }
    .db-greeting {
      font-size: 26px;
      font-weight: 800;
      color: #fff;
      line-height: 1.1;
      margin-bottom: 8px;
    }
    .db-greeting em { font-style: normal; color: #FBBF24; }

    .db-hero-sub {
      font-size: 13.5px;
      color: #CBD5E1;
      line-height: 1.6;
      max-width: 760px;
      margin-bottom: 20px;
    }
    .db-hero-btns { display: flex; gap: 10px; flex-wrap: wrap; }

    .db-btn-gold {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 9px 18px;
      font-size: 13px;
      font-weight: 700;
      color: #FFFFFF;
      background: #D97706;
      border: none;
      border-radius: 10px;
      cursor: pointer;
      transition: all 0.2s ease;
      white-space: nowrap;
    }
    .db-btn-gold:hover { background: #B45309; transform: translateY(-1px); color: #FFFFFF; }
    .db-btn-gold:disabled { opacity: 0.55; cursor: not-allowed; transform: none; }

    .db-btn-outline {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 9px 18px;
      font-size: 13px;
      font-weight: 600;
      color: #FFFFFF;
      background: rgba(255, 255, 255, 0.10);
      border: 1px solid rgba(255, 255, 255, 0.20);
      border-radius: 10px;
      cursor: pointer;
      transition: all 0.2s ease;
      white-space: nowrap;
    }
    .db-btn-outline:hover { background: rgba(255, 255, 255, 0.18); color: #fff; }
    .db-btn-outline:disabled { opacity: 0.55; cursor: not-allowed; }

    .db-hero-stat-card {
      background: rgba(255, 255, 255, 0.08);
      border: 1px solid rgba(255, 255, 255, 0.15);
      backdrop-filter: blur(8px);
      border-radius: 14px;
      padding: 18px 20px;
      min-width: 330px;
    }
    @media (max-width: 991.98px) { .db-hero { padding: 24px 20px; } .db-hero-stat-card { min-width: 0; width: 100%; } }
    .db-hero-stat-row { display: flex; flex-direction: column; gap: 10px; }
    .db-hero-stat-item { display: flex; justify-content: space-between; align-items: center; gap: 16px; }
    .db-hero-stat-label { font-size: 12px; font-weight: 400; color: #CBD5E1; }
    .db-hero-stat-val {
      font-size: 18px;
      font-weight: 800;
      color: #FBBF24;
    }
    .db-hero-stat-sep { height: 1px; background: rgba(255, 255, 255, 0.08); }

    .db-panel {
      background: #ffffff;
      border: 1px solid #E2E8F0;
      border-radius: 16px;
      overflow: hidden;
      box-shadow: 0 4px 16px rgba(15,39,68,0.03);
      margin-bottom: 24px;
    }
    .db-panel-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 18px 20px;
      border-bottom: 1px solid #E2E8F0;
      gap: 12px;
      flex-wrap: wrap;
    }
    .db-panel-title {
      font-size: 16px;
      font-weight: 700;
      color: #0F2744;
      margin: 0;
    }
    .db-panel-sub { font-size: 12px; color: #64748B; margin: 0; }

    .db-refresh-btn {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 8px 14px;
      font-size: 12.5px;
      font-weight: 600;
      color: #0F2744;
      background: #F1F5F9;
      border: 1px solid #E2E8F0;
      border-radius: 8px;
      cursor: pointer;
      transition: all 0.2s;
      white-space: nowrap;
    }
    .db-refresh-btn:hover { background: #E2E8F0; }
    .db-refresh-btn:disabled { opacity: 0.55; cursor: not-allowed; }

    .db-grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 18px; margin: 16px 0 18px; }
    @media (max-width: 991.98px) { .db-grid2 { grid-template-columns: 1fr; } }

    .db-input {
      width: 100%;
      padding: 10px 12px;
      border-radius: 10px;
      border: 1px solid #E2E8F0;
      outline: none;
      font-size: 13px;
      background: #F8FAFC;
      color: #0F2744;
      font-weight: 600;
      transition: border-color 0.2s;
    }
    .db-input:focus { border-color: #D97706; background: #fff; box-shadow: 0 0 0 3px rgba(217,119,6,0.12); }

    .miniCard {
      background: #fff;
      border: 1px solid #E2E8F0;
      border-radius: 14px;
      box-shadow: 0 4px 12px rgba(15,39,68,0.02);
      overflow: hidden;
    }
    .miniCardTop { height: 3px; background: linear-gradient(135deg, #D97706 0%, #FBBF24 100%); }
    .miniCardBody { padding: 16px 18px; display: grid; gap: 6px; }
    .miniCardLabel { font-size: 11px; color: #64748B; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; }
    .miniCardValue { font-size: 22px; font-weight: 800; color: #0F2744; line-height: 1.1; }
    .miniCardHint { font-size: 12px; color: #64748B; }
    .miniCardIcon {
      width: 38px; height: 38px; border-radius: 10px;
      display: flex; align-items: center; justify-content: center;
      background: rgba(217,119,6,0.12);
      border: 1px solid rgba(217,119,6,0.20);
      color: #D97706;
    }

    .db-pill {
      display: inline-flex;
      align-items: center;
      font-size: 11.5px;
      font-weight: 700;
      padding: 5px 10px;
      border-radius: 999px;
      white-space: nowrap;
      border: 1px solid rgba(0,0,0,0.06);
    }
    .db-muted { color: #64748B; }
    .db-strong { font-weight: 700; color: #0F2744; }
  `}),(0,u.jsx)(o,{sidebarOpen:e,setSidebarOpen:t}),(0,u.jsx)(n,{title:`Attendance Settings`}),(0,u.jsx)(`div`,{className:`container-fluid`,children:(0,u.jsxs)(`div`,{className:`row`,children:[(0,u.jsx)(a,{sidebarOpen:e}),(0,u.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto db-main`,children:[(g||v)&&(0,u.jsx)(r,{message:g?`Loading settings...`:`Saving settings...`}),(0,u.jsxs)(`div`,{className:`db-hero`,children:[(0,u.jsx)(`div`,{className:`db-hero-glow`,"aria-hidden":`true`}),(0,u.jsx)(`div`,{className:`db-hero-glow2`,"aria-hidden":`true`}),(0,u.jsxs)(`div`,{className:`db-hero-inner`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsxs)(`div`,{className:`db-session-badge`,children:[(0,u.jsx)(`span`,{className:`db-session-dot`}),`Attendance • Settings`]}),(0,u.jsxs)(`h1`,{className:`db-greeting`,children:[f(),`, `,(0,u.jsx)(`em`,{children:`Admin.`})]}),(0,u.jsx)(`p`,{className:`db-hero-sub`,children:`Configure check-in policy (late, grace time, optional checkout/absent cutoffs). These settings apply per school.`}),(0,u.jsxs)(`div`,{className:`db-hero-btns`,children:[(0,u.jsxs)(`button`,{className:`db-btn-gold`,onClick:C,disabled:g||v,children:[(0,u.jsx)(`i`,{className:`bi bi-save`}),`Save`]}),(0,u.jsxs)(`button`,{className:`db-btn-outline`,onClick:S,disabled:g||v,children:[(0,u.jsx)(`i`,{className:`bi bi-arrow-clockwise`}),`Reload`]}),(0,u.jsxs)(`button`,{className:`db-btn-outline`,onClick:()=>x(e=>({...e,is_active:!e.is_active})),disabled:g||v,children:[(0,u.jsx)(`i`,{className:`bi ${b.is_active?`bi-toggle-on`:`bi-toggle-off`}`}),`Toggle`]})]})]}),(0,u.jsx)(`div`,{className:`db-hero-stat-card d-none d-md-block`,children:(0,u.jsxs)(`div`,{className:`db-hero-stat-row`,children:[(0,u.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,u.jsx)(`span`,{className:`db-hero-stat-label`,children:`Rule engine`}),(0,u.jsx)(`span`,{className:`db-hero-stat-val`,style:{color:T.fg},children:T.text})]}),(0,u.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,u.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,u.jsx)(`span`,{className:`db-hero-stat-label`,children:`Check-in`}),(0,u.jsx)(`span`,{className:`db-hero-stat-val`,children:b.staff_checkin_time||`—`})]}),(0,u.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,u.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,u.jsx)(`span`,{className:`db-hero-stat-label`,children:`Grace minutes`}),(0,u.jsx)(`span`,{className:`db-hero-stat-val`,children:Number(b.grace_minutes)||0})]}),(0,u.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,u.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,u.jsx)(`span`,{className:`db-hero-stat-label`,children:`Late after`}),(0,u.jsx)(`span`,{className:`db-hero-stat-val`,children:E})]})]})})]})]}),(0,u.jsx)(`div`,{style:{display:`grid`,gridTemplateColumns:`repeat(4, 1fr)`,gap:14,margin:`14px 0 8px`},className:`d-none d-lg-grid`,children:D.map(e=>(0,u.jsxs)(`div`,{className:`miniCard`,children:[(0,u.jsx)(`div`,{className:`miniCardTop`,style:{background:e.top}}),(0,u.jsxs)(`div`,{className:`miniCardBody`,children:[(0,u.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,alignItems:`start`,gap:12},children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`miniCardLabel`,children:e.label}),(0,u.jsx)(`div`,{className:`miniCardValue`,children:e.value})]}),(0,u.jsx)(`div`,{className:`miniCardIcon`,style:{background:`rgba(0,0,0,0.04)`,borderColor:`rgba(0,0,0,0.06)`,color:`#0f172a`},children:(0,u.jsx)(`i`,{className:`bi bi-${e.icon}`})})]}),(0,u.jsx)(`div`,{className:`miniCardHint`,children:e.hint})]})]},e.label))}),(0,u.jsxs)(`div`,{className:`db-grid2`,style:{marginTop:14},children:[(0,u.jsxs)(`div`,{className:`db-panel`,children:[(0,u.jsxs)(`div`,{className:`db-panel-head`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`p`,{className:`db-panel-title`,children:`Staff attendance policy`}),(0,u.jsx)(`p`,{className:`db-panel-sub`,children:`Controls present / late + optional time-based rules`})]}),(0,u.jsxs)(`span`,{className:`db-pill`,style:{background:T.bg,color:T.fg,borderColor:`rgba(255,255,255,0.12)`},title:`Whether the rule engine is active`,children:[(0,u.jsx)(`span`,{style:{width:8,height:8,borderRadius:999,background:T.dot,display:`inline-block`,marginRight:8}}),T.text.toUpperCase()]})]}),(0,u.jsxs)(`div`,{style:{padding:16,display:`grid`,gap:12},children:[(0,u.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`1fr 1fr`,gap:12},children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`miniCardLabel`,style:{marginBottom:6},children:`Expected check-in time`}),(0,u.jsx)(`input`,{type:`time`,className:`db-input`,value:b.staff_checkin_time,onChange:e=>x(t=>({...t,staff_checkin_time:e.target.value})),disabled:g||v}),(0,u.jsxs)(`div`,{className:`db-muted`,style:{fontSize:12,marginTop:6,lineHeight:1.55},children:[`Late is calculated after `,(0,u.jsx)(`b`,{children:b.staff_checkin_time||`—`}),` + grace minutes.`]})]}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`miniCardLabel`,style:{marginBottom:6},children:`Grace minutes (0–180)`}),(0,u.jsx)(`input`,{type:`number`,className:`db-input`,value:b.grace_minutes,min:0,max:180,onChange:e=>x(t=>({...t,grace_minutes:Number(e.target.value)})),disabled:g||v}),(0,u.jsx)(`div`,{className:`db-muted`,style:{fontSize:12,marginTop:6,lineHeight:1.55},children:`Example: 10 means late after +10 minutes.`})]})]}),(0,u.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`1fr 1fr`,gap:12},children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`miniCardLabel`,style:{marginBottom:6},children:`Optional checkout time`}),(0,u.jsx)(`input`,{type:`time`,className:`db-input`,value:b.staff_checkout_time,onChange:e=>x(t=>({...t,staff_checkout_time:e.target.value})),disabled:g||v}),(0,u.jsx)(`div`,{className:`db-muted`,style:{fontSize:12,marginTop:6,lineHeight:1.55},children:`Used for reporting (not required).`})]}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`miniCardLabel`,style:{marginBottom:6},children:`Optional absent-after time`}),(0,u.jsx)(`input`,{type:`time`,className:`db-input`,value:b.absent_after_time,onChange:e=>x(t=>({...t,absent_after_time:e.target.value})),disabled:g||v}),(0,u.jsx)(`div`,{className:`db-muted`,style:{fontSize:12,marginTop:6,lineHeight:1.55},children:`For future automation: mark absent if no check-in by this time.`})]})]}),(0,u.jsxs)(`div`,{style:{borderRadius:14,border:`1px solid #ede8e0`,background:`#fff`,padding:14,display:`grid`,gap:12},children:[(0,u.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:12,flexWrap:`wrap`,alignItems:`center`},children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`db-strong`,style:{fontSize:13.5},children:`School location security`}),(0,u.jsx)(`div`,{className:`db-muted`,style:{fontSize:12,lineHeight:1.55},children:`Staff scans must happen close to this school location.`})]}),(0,u.jsxs)(`button`,{className:`db-refresh-btn`,type:`button`,onClick:w,disabled:g||v,children:[(0,u.jsx)(`i`,{className:`bi bi-geo-alt`}),` Use current location`]})]}),(0,u.jsxs)(`div`,{style:{borderRadius:12,border:`1px solid #e5ddd3`,background:`#faf8f5`,padding:12,fontSize:12.5,color:`#7a6a5a`,lineHeight:1.6},children:[`Use a computer or phone physically inside the school compound, click `,(0,u.jsx)(`b`,{children:`Use current location`}),`, then choose `,(0,u.jsx)(`b`,{children:`Allow`}),` when the browser asks. If location was blocked, click the lock or site settings icon beside the address bar, allow `,(0,u.jsx)(`b`,{children:`Location`}),`, and refresh the page.`]}),(0,u.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`1fr 1fr`,gap:12},children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`miniCardLabel`,style:{marginBottom:6},children:`Latitude`}),(0,u.jsx)(`input`,{type:`number`,step:`0.0000001`,className:`db-input`,value:b.school_latitude,onChange:e=>x(t=>({...t,school_latitude:e.target.value})),disabled:g||v})]}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`miniCardLabel`,style:{marginBottom:6},children:`Longitude`}),(0,u.jsx)(`input`,{type:`number`,step:`0.0000001`,className:`db-input`,value:b.school_longitude,onChange:e=>x(t=>({...t,school_longitude:e.target.value})),disabled:g||v})]})]}),(0,u.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`1fr 1fr`,gap:12},children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`miniCardLabel`,style:{marginBottom:6},children:`Allowed distance in meters`}),(0,u.jsx)(`input`,{type:`number`,min:10,max:5e3,className:`db-input`,value:b.allowed_radius_meters,onChange:e=>x(t=>({...t,allowed_radius_meters:Number(e.target.value)})),disabled:g||v}),(0,u.jsx)(`div`,{className:`db-muted`,style:{fontSize:12,marginTop:6,lineHeight:1.55},children:`Start with 100m. Increase only if the school compound is large.`})]}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`miniCardLabel`,style:{marginBottom:6},children:`QR expiry in seconds`}),(0,u.jsx)(`input`,{type:`number`,min:60,max:600,className:`db-input`,value:b.qr_expires_seconds,onChange:e=>x(t=>({...t,qr_expires_seconds:Number(e.target.value)})),disabled:g||v}),(0,u.jsx)(`div`,{className:`db-muted`,style:{fontSize:12,marginTop:6,lineHeight:1.55},children:`Use 300 seconds for normal school use. Shorter expiry reduces QR sharing abuse.`})]})]}),(0,u.jsxs)(`label`,{style:{display:`flex`,gap:10,alignItems:`center`,margin:0},children:[(0,u.jsx)(`input`,{type:`checkbox`,checked:b.require_location_verification,onChange:e=>x(t=>({...t,require_location_verification:e.target.checked})),disabled:g||v}),(0,u.jsx)(`span`,{className:`db-muted`,style:{fontSize:12.5},children:`Require location verification before staff attendance is marked.`})]})]}),(0,u.jsxs)(`div`,{style:{borderRadius:14,border:`1px solid #ede8e0`,background:`#faf8f5`,padding:14,display:`flex`,alignItems:`center`,justifyContent:`space-between`,gap:12,flexWrap:`wrap`},children:[(0,u.jsxs)(`div`,{style:{display:`grid`,gap:4},children:[(0,u.jsx)(`div`,{className:`db-strong`,style:{fontSize:13.5},children:`Enable attendance marking`}),(0,u.jsx)(`div`,{className:`db-muted`,style:{fontSize:12,lineHeight:1.55},children:`If disabled, your QR attendance endpoint should reject marking attendance.`})]}),(0,u.jsxs)(`div`,{style:{display:`flex`,gap:10,alignItems:`center`},children:[(0,u.jsx)(`span`,{className:`db-muted`,style:{fontSize:12},children:`Active`}),(0,u.jsx)(`div`,{className:`form-check form-switch m-0`,children:(0,u.jsx)(`input`,{className:`form-check-input`,type:`checkbox`,checked:b.is_active,onChange:e=>x(t=>({...t,is_active:e.target.checked})),disabled:g||v,id:`attendanceActive`})})]})]}),(0,u.jsxs)(`div`,{style:{display:`flex`,gap:10,flexWrap:`wrap`,marginTop:4},children:[(0,u.jsxs)(`button`,{className:`db-refresh-btn`,onClick:S,disabled:g||v,children:[(0,u.jsx)(`i`,{className:`bi bi-arrow-clockwise`}),` Reset to saved`]}),(0,u.jsxs)(`button`,{className:`db-btn-gold`,onClick:C,disabled:g||v,children:[(0,u.jsx)(`i`,{className:`bi bi-save`}),` Save settings`]})]})]})]}),(0,u.jsxs)(`div`,{className:`db-panel`,children:[(0,u.jsx)(`div`,{className:`db-panel-head`,children:(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`p`,{className:`db-panel-title`,children:`Rule preview`}),(0,u.jsx)(`p`,{className:`db-panel-sub`,children:`Quick explanation of what the system will do`})]})}),(0,u.jsxs)(`div`,{style:{padding:16,display:`grid`,gap:12},children:[(0,u.jsx)(`div`,{style:{borderRadius:14,padding:16,color:`#fff`,background:`linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)`},children:(0,u.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:12},children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{style:{fontWeight:800,marginBottom:6},children:`How “late” is calculated`}),(0,u.jsxs)(`div`,{style:{opacity:.92,fontSize:13.5,lineHeight:1.65},children:[`Check-in time is `,(0,u.jsx)(`b`,{children:b.staff_checkin_time||`—`}),` and grace is`,` `,(0,u.jsxs)(`b`,{children:[Number(b.grace_minutes)||0,` mins`]}),`. Staff are marked `,(0,u.jsx)(`b`,{children:`late`}),` after`,` `,(0,u.jsx)(`b`,{children:E}),`.`]})]}),(0,u.jsx)(`i`,{className:`bi bi-info-circle`,style:{fontSize:20,opacity:.95}})]})}),(0,u.jsxs)(`div`,{style:{border:`1px solid #ede8e0`,background:`#fff`,borderRadius:14,padding:14},children:[(0,u.jsx)(`div`,{className:`miniCardLabel`,style:{marginBottom:8},children:`Current values`}),(0,u.jsxs)(`div`,{style:{display:`grid`,gap:10},children:[(0,u.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:10},children:[(0,u.jsx)(`span`,{className:`db-muted`,children:`Check-in`}),(0,u.jsx)(`span`,{className:`db-strong`,children:b.staff_checkin_time||`—`})]}),(0,u.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:10},children:[(0,u.jsx)(`span`,{className:`db-muted`,children:`Grace minutes`}),(0,u.jsx)(`span`,{className:`db-strong`,children:Number(b.grace_minutes)||0})]}),(0,u.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:10},children:[(0,u.jsx)(`span`,{className:`db-muted`,children:`Late after`}),(0,u.jsx)(`span`,{className:`db-strong`,children:E})]}),(0,u.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:10},children:[(0,u.jsx)(`span`,{className:`db-muted`,children:`Checkout time`}),(0,u.jsx)(`span`,{className:`db-strong`,children:b.staff_checkout_time||`—`})]}),(0,u.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:10},children:[(0,u.jsx)(`span`,{className:`db-muted`,children:`Absent-after`}),(0,u.jsx)(`span`,{className:`db-strong`,children:b.absent_after_time||`—`})]}),(0,u.jsx)(`div`,{style:{height:1,background:`rgba(0,0,0,0.06)`}}),(0,u.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:10,alignItems:`center`},children:[(0,u.jsx)(`span`,{className:`db-muted`,children:`Engine status`}),(0,u.jsx)(`span`,{className:`db-pill`,style:{background:T.bg,color:T.fg,borderColor:`rgba(0,0,0,0.06)`},children:T.text.toUpperCase()})]})]})]}),(0,u.jsxs)(`div`,{className:`db-muted`,style:{fontSize:12,lineHeight:1.65},children:[(0,u.jsx)(`i`,{className:`bi bi-shield-check`,style:{marginRight:6}}),`Tip: Keep “Absent-after” empty unless your backend is already using it to auto-mark absent.`]})]})]})]}),(0,u.jsx)(`div`,{className:`mt-auto`,children:(0,u.jsx)(c,{})})]})]})})]})}export{m as default};