import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{p as t,x as n}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as r,E as i,P as a,d as o,f as s,l as c,u as l}from"./index-D6TxbaCx.js";var u=e(),d=t();function f(){let e=new Date().getHours();return e<12?`Good morning`:e<17?`Good afternoon`:`Good evening`}function p({icon:e,title:t,subtitle:n,tag:r}){return(0,d.jsxs)(`div`,{className:`sr-section-head`,children:[(0,d.jsx)(`div`,{className:`sr-section-icon`,children:e}),(0,d.jsxs)(`div`,{className:`sr-section-info`,children:[(0,d.jsx)(`div`,{className:`sr-section-title`,children:t}),(0,d.jsx)(`div`,{className:`sr-section-sub`,children:n})]}),r&&(0,d.jsx)(`span`,{className:`sr-section-tag`,children:r})]})}function m({label:e,required:t,hint:n,children:r}){return(0,d.jsxs)(`div`,{className:`sr-field`,children:[(0,d.jsxs)(`label`,{className:`sr-label`,children:[e,t&&(0,d.jsx)(`span`,{className:`sr-required`,children:`*`})]}),r,n&&(0,d.jsx)(`p`,{className:`sr-hint`,children:n})]})}function h(){let[e,t]=(0,u.useState)(!1),[h,g]=(0,u.useState)(!1),[_,v]=(0,u.useState)(!0),{showSuccess:y,showError:b}=c(),x=n(),[S,C]=(0,u.useState)([]),[w,T]=(0,u.useState)([]),[E,D]=(0,u.useState)([]),[O,k]=(0,u.useState)(0),[A,j]=(0,u.useState)({firstname:``,surname:``,third_name:``,gender:``,dob:``,reg_no:``,level_id:``,section_id:``,department_id:``,role:`Student`,blood_group:``,religion:``,nationality:`Nigerian`,phone:``,address:``}),[M,N]=(0,u.useState)(null),[P,F]=(0,u.useState)(null),I=(0,u.useMemo)(()=>!!(A.firstname.trim()&&A.surname.trim()&&A.third_name.trim()&&A.gender.trim()&&A.level_id&&A.section_id&&A.department_id),[A]),L=(0,u.useMemo)(()=>{let e=[A.firstname,A.surname,A.third_name,A.gender,A.dob,A.level_id,A.section_id,A.department_id,A.blood_group,A.religion,A.nationality,A.phone,A.address,M?`photo`:``],t=e.filter(Boolean).length;return Math.round(t/e.length*100)},[A,M]);(0,u.useEffect)(()=>{(async()=>{try{let[e,t,n,r]=await Promise.all([a.get(`/student-class`),a.get(`/all-sections`),a.get(`/student-department`),a.get(`/settings/auto-admission-status`)]);C(e.data),T(t.data),D(n.data),k(Number(r.data.auto_admission??0))}catch{b(`Failed to load registration options.`)}finally{v(!1)}})()},[]);let R=e=>j(t=>({...t,[e.target.name]:e.target.value})),z=e=>{let t=e.target.files?.[0];t&&(N(t),F(URL.createObjectURL(t)))},B=()=>{N(null),F(null)},V=async e=>{if(e.preventDefault(),!I)return b(`Complete all required fields.`);g(!0);try{let e={...A,reg_no:O===1?``:A.reg_no},t=new FormData;Object.entries(e).forEach(([e,n])=>{n!=null&&String(n).trim()&&t.append(e,n)}),M&&t.append(`photo`,M),y(`Student registered!\nReg No: ${(await a.post(`/students/store`,t,{headers:{"Content-Type":`multipart/form-data`}})).data.reg_no??`Generated`}`),x(`/students`)}catch(e){b(e.response?.data?.message||`Registration failed. Try again.`)}finally{g(!1)}};return(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,700;1,400&family=DM+Sans:wght@300;400;500&display=swap');

        .sr-main { background:#f5f1eb; min-height:100vh; font-family:'DM Sans',sans-serif; padding:28px 28px 0; }

        /* ── Hero ── */
        .sr-hero { background:#0f172a; border-radius:16px; padding:32px 36px; position:relative; overflow:hidden; margin-bottom:28px; }
        .sr-hero::before { content:''; position:absolute; inset:0; background-image:radial-gradient(circle,rgba(255,255,255,.045) 1px,transparent 1px); background-size:24px 24px; pointer-events:none; }
        .sr-hero-glow  { position:absolute; top:-60px; right:-60px; width:320px; height:320px; border-radius:50%; background:radial-gradient(circle,rgba(201,168,76,.10) 0%,transparent 65%); pointer-events:none; }
        .sr-hero-glow2 { position:absolute; bottom:-40px; left:25%; width:240px; height:240px; border-radius:50%; background:radial-gradient(circle,rgba(99,102,241,.07) 0%,transparent 70%); pointer-events:none; }
        .sr-hero-inner { position:relative; z-index:1; display:flex; align-items:center; justify-content:space-between; gap:32px; flex-wrap:wrap; }
        .sr-kicker { display:inline-flex; align-items:center; gap:7px; font-size:11px; font-weight:500; letter-spacing:.12em; text-transform:uppercase; color:#e8c97a; background:rgba(201,168,76,.10); border:1px solid rgba(201,168,76,.2); border-radius:999px; padding:4px 12px; margin-bottom:14px; }
        .sr-kicker-dot { width:6px; height:6px; border-radius:50%; background:#c9a84c; }
        .sr-hero-title { font-family:'Lora',serif; font-size:clamp(22px,2.5vw,32px); font-weight:700; color:#fff; line-height:1.1; margin-bottom:8px; }
        .sr-hero-title em { font-style:italic; color:#e8c97a; }
        .sr-hero-sub { font-size:13.5px; font-weight:300; color:#64748b; line-height:1.65; max-width:480px; margin-bottom:24px; }
        .sr-hero-btns { display:flex; gap:10px; flex-wrap:wrap; }
        .sr-btn-back { display:inline-flex; align-items:center; gap:7px; padding:9px 18px; font-size:13px; font-weight:400; color:rgba(255,255,255,.7); background:rgba(255,255,255,.07); border:1px solid rgba(255,255,255,.14); border-radius:9px; cursor:pointer; transition:background .2s,color .2s; }
        .sr-btn-back:hover { background:rgba(255,255,255,.12); color:#fff; }

        /* Right progress card */
        .sr-hero-card { background:rgba(255,255,255,.05); border:1px solid rgba(255,255,255,.09); backdrop-filter:blur(8px); border-radius:14px; padding:22px 26px; min-width:220px; }
        .sr-progress-label { display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; }
        .sr-progress-text { font-size:11px; font-weight:500; letter-spacing:.14em; text-transform:uppercase; color:#c9a84c; }
        .sr-progress-pct { font-family:'Lora',serif; font-size:18px; font-weight:700; color:#fff; }
        .sr-progress-track { height:5px; background:rgba(255,255,255,.08); border-radius:999px; margin-bottom:18px; overflow:hidden; }
        .sr-progress-fill { height:5px; background:linear-gradient(90deg,#c9a84c,#e8c97a); border-radius:999px; transition:width .4s cubic-bezier(.4,0,.2,1); }
        .sr-status-row { display:flex; align-items:center; gap:7px; font-size:12.5px; font-weight:300; color:#64748b; }
        .sr-status-dot { width:7px; height:7px; border-radius:50%; flex-shrink:0; }
        .sr-status-dot--ok   { background:#22c55e; box-shadow:0 0 0 3px rgba(34,197,94,.2); }
        .sr-status-dot--warn { background:#f59e0b; box-shadow:0 0 0 3px rgba(245,158,11,.2); }

        /* ── Tip pills ── */
        .sr-tips { display:flex; flex-direction:column; gap:7px; margin-top:14px; padding-top:14px; border-top:1px solid rgba(255,255,255,.07); }
        .sr-tip { font-size:11.5px; font-weight:300; color:#94a3b8; display:flex; align-items:center; gap:6px; }
        .sr-tip-dot { width:4px; height:4px; border-radius:50%; background:#c9a84c; flex-shrink:0; }

        /* ── Form sections ── */
        .sr-form-wrap { display:flex; flex-direction:column; gap:16px; padding-bottom:120px; }

        .sr-section { background:#fff; border:1px solid #ede8e0; border-radius:14px; overflow:hidden; animation:srFadeUp .5s ease both; }
        @keyframes srFadeUp { from{opacity:0;transform:translateY(12px)} to{opacity:1;transform:translateY(0)} }
        .sr-section:nth-child(1){ animation-delay:.04s; }
        .sr-section:nth-child(2){ animation-delay:.08s; }
        .sr-section:nth-child(3){ animation-delay:.12s; }
        .sr-section:nth-child(4){ animation-delay:.16s; }
        .sr-section:nth-child(5){ animation-delay:.20s; }

        /* Section head */
        .sr-section-head { display:flex; align-items:center; gap:12px; padding:18px 22px; border-bottom:1px solid #f0ebe3; flex-wrap:wrap; }
        .sr-section-icon { width:36px; height:36px; border-radius:9px; display:flex; align-items:center; justify-content:center; background:var(--si,#fef3c7); color:var(--sc,#b45309); flex-shrink:0; }
        .sr-section-info { flex:1; min-width:0; }
        .sr-section-title { font-family:'Lora',serif; font-size:14.5px; font-weight:700; color:#1a1a2e; }
        .sr-section-sub { font-size:11.5px; font-weight:300; color:#9a8a7a; }
        .sr-section-tag { font-size:10px; font-weight:600; letter-spacing:.1em; text-transform:uppercase; color:#b45309; background:rgba(180,83,9,.08); border:1px solid rgba(180,83,9,.18); border-radius:100px; padding:2px 10px; white-space:nowrap; }

        .sr-section-body { padding:22px; }

        /* Grid */
        .sr-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:14px; }
        @media(max-width:900px){ .sr-grid{grid-template-columns:1fr 1fr;} }
        @media(max-width:560px){ .sr-grid{grid-template-columns:1fr;} }
        .sr-col2 { grid-column:span 2; }
        @media(max-width:900px){ .sr-col2{grid-column:1/-1;} }

        /* Field */
        .sr-field { display:flex; flex-direction:column; gap:0; }
        .sr-label { font-size:12px; font-weight:500; color:#4a4a5a; margin-bottom:7px; letter-spacing:.02em; display:flex; align-items:center; gap:4px; }
        .sr-required { color:#ef4444; font-size:12px; }
        .sr-hint { font-size:11.5px; font-weight:300; color:#b5a090; margin-top:5px; }
        .sr-input, .sr-select {
          width:100%; background:#faf8f5; border:1.5px solid #e5ddd3; border-radius:9px;
          padding:10px 13px; font-family:'DM Sans',sans-serif; font-size:13.5px; color:#1a1a2e;
          outline:none; -webkit-appearance:none;
          transition:border-color .2s,box-shadow .2s,background .2s;
        }
        .sr-input:focus,.sr-select:focus { border-color:#c9a84c; box-shadow:0 0 0 3px rgba(201,168,76,.12); background:#fff; }
        .sr-input::placeholder { color:#bdb3a8; }
        .sr-input:disabled { opacity:.5; cursor:not-allowed; }

        /* Photo upload */
        .sr-photo-section { display:flex; align-items:center; gap:20px; flex-wrap:wrap; }
        .sr-avatar { width:82px; height:82px; border-radius:50%; overflow:hidden; background:#f5f1eb; border:2px solid #e5ddd3; flex-shrink:0; display:flex; align-items:center; justify-content:center; position:relative; }
        .sr-avatar img { width:100%; height:100%; object-fit:cover; }
        .sr-avatar-placeholder { display:flex; flex-direction:column; align-items:center; gap:4px; color:#b5a090; }
        .sr-avatar-placeholder span { font-size:10.5px; font-weight:400; }
        .sr-photo-actions { display:flex; flex-direction:column; gap:6px; }
        .sr-photo-name { font-weight:500; font-size:13.5px; color:#1a1a2e; margin-bottom:2px; }
        .sr-photo-desc { font-size:12px; font-weight:300; color:#9a8a7a; }
        .sr-photo-btns { display:flex; gap:8px; margin-top:6px; }
        .sr-upload-btn { display:inline-flex; align-items:center; gap:6px; padding:8px 14px; font-size:12.5px; font-weight:400; color:#b45309; background:rgba(180,83,9,.07); border:1.5px solid rgba(180,83,9,.2); border-radius:8px; cursor:pointer; transition:background .2s; }
        .sr-upload-btn:hover { background:rgba(180,83,9,.12); }
        .sr-remove-btn { display:inline-flex; align-items:center; gap:5px; padding:8px 12px; font-size:12.5px; font-weight:400; color:#64748b; background:#f5f1eb; border:1px solid #e5ddd3; border-radius:8px; cursor:pointer; transition:background .2s; }
        .sr-remove-btn:hover { background:#ede8e0; }

        /* ── Sticky action bar ── */
        .sr-action-bar {
          position: fixed;
          bottom: 0;
          left: 0;
          right: 0;
          z-index: 1020;
          background: rgba(255,255,255,0.95);
          backdrop-filter: blur(12px);
          border-top: 1px solid #ede8e0;
          box-shadow: 0 -4px 20px rgba(0,0,0,0.06);
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          padding: 12px 28px;
          flex-wrap: wrap;
          transition: left 0.3s ease;
        }

        @media (min-width: 768px) {
          .sr-action-bar {
            left: var(--gq-sidebar-width, 280px);
          }
          .gq-sidebar-collapsed .sr-action-bar {
            left: var(--gq-sidebar-collapsed-width, 80px);
          }
        }

        .sr-action-status { display:flex; align-items:center; gap:8px; font-size:13px; font-weight:400; color:#7a6a5a; }
        .sr-action-status-dot { width:7px; height:7px; border-radius:50%; flex-shrink:0; }
        .sr-action-status-dot--ok   { background:#22c55e; }
        .sr-action-status-dot--warn { background:#f59e0b; }
        .sr-action-btns { display:flex; gap:10px; align-items:center; }

        .sr-cancel-btn { display:inline-flex; align-items:center; gap:7px; padding:10px 18px; font-size:13px; font-weight:500; color:#7a6a5a; background:#f5f1eb; border:1px solid #e5ddd3; border-radius:9px; cursor:pointer; transition:background .2s; }
        .sr-cancel-btn:hover { background:#ede8e0; }
        .sr-cancel-btn:disabled { opacity:.5; cursor:not-allowed; }

        .sr-submit-btn { display:inline-flex; align-items:center; gap:8px; padding:10px 22px; font-size:13.5px; font-weight:600; color:#fff; background:#1a1a2e; border:none; border-radius:9px; cursor:pointer; transition:background .2s,transform .2s,box-shadow .2s; }
        .sr-submit-btn:hover:not(:disabled) { background:#0a0f1e; transform:translateY(-1px); box-shadow:0 4px 14px rgba(0,0,0,.14); }
        .sr-submit-btn:disabled { opacity:.5; cursor:not-allowed; }
        .sr-submit-btn--ready { background:#c9a84c; color:#0f172a; }
        .sr-submit-btn--ready:hover:not(:disabled) { background:#e8c97a; }

        .sr-spinner { width:15px; height:15px; border:2px solid rgba(255,255,255,.3); border-top-color:#fff; border-radius:50%; animation:srSpin .7s linear infinite; flex-shrink:0; }
        .sr-spinner--dark { border:2px solid rgba(0,0,0,.12); border-top-color:#0f172a; }
        @keyframes srSpin { to{transform:rotate(360deg)} }
      `}),(0,d.jsx)(s,{sidebarOpen:e,setSidebarOpen:t}),(0,d.jsx)(r,{title:`Student Registration`}),(0,d.jsx)(`div`,{className:`container-fluid`,children:(0,d.jsxs)(`div`,{className:`row`,children:[(0,d.jsx)(o,{sidebarOpen:e,setSidebarOpen:t}),(0,d.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto db-main sr-main`,children:[_&&(0,d.jsx)(i,{message:`Loading registration options…`}),(0,d.jsxs)(`div`,{className:`sr-hero`,children:[(0,d.jsx)(`div`,{className:`sr-hero-glow`,"aria-hidden":`true`}),(0,d.jsx)(`div`,{className:`sr-hero-glow2`,"aria-hidden":`true`}),(0,d.jsxs)(`div`,{className:`sr-hero-inner`,children:[(0,d.jsxs)(`div`,{children:[(0,d.jsxs)(`div`,{className:`sr-kicker`,children:[(0,d.jsx)(`span`,{className:`sr-kicker-dot`}),`Student Registration`]}),(0,d.jsxs)(`h1`,{className:`sr-hero-title`,children:[f(),`, `,(0,d.jsx)(`em`,{children:`Admin.`})]}),(0,d.jsx)(`p`,{className:`sr-hero-sub`,children:`Register a new student into the school system. Fill in personal, academic, and contact details below.`}),(0,d.jsx)(`div`,{className:`sr-hero-btns`,children:(0,d.jsxs)(`button`,{type:`button`,className:`sr-btn-back`,onClick:()=>x(`/students`),children:[(0,d.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:(0,d.jsx)(`path`,{d:`M13 7H1M7 13L1 7l6-6`,stroke:`currentColor`,strokeWidth:`1.7`,strokeLinecap:`round`,strokeLinejoin:`round`})}),`Back to Students`]})})]}),(0,d.jsxs)(`div`,{className:`sr-hero-card d-none d-md-block`,children:[(0,d.jsxs)(`div`,{className:`sr-progress-label`,children:[(0,d.jsx)(`span`,{className:`sr-progress-text`,children:`Form progress`}),(0,d.jsxs)(`span`,{className:`sr-progress-pct`,children:[L,`%`]})]}),(0,d.jsx)(`div`,{className:`sr-progress-track`,children:(0,d.jsx)(`div`,{className:`sr-progress-fill`,style:{width:`${L}%`}})}),(0,d.jsxs)(`div`,{className:`sr-status-row`,children:[(0,d.jsx)(`span`,{className:`sr-status-dot ${I?`sr-status-dot--ok`:`sr-status-dot--warn`}`}),I?`Ready to submit`:`Complete required fields`]}),(0,d.jsxs)(`div`,{className:`sr-tips`,children:[(0,d.jsxs)(`div`,{className:`sr-tip`,children:[(0,d.jsx)(`span`,{className:`sr-tip-dot`}),`\xA0Upload a photo for easy ID`]}),(0,d.jsxs)(`div`,{className:`sr-tip`,children:[(0,d.jsx)(`span`,{className:`sr-tip-dot`}),`\xA0Leave Admission No blank to auto-generate`]}),(0,d.jsxs)(`div`,{className:`sr-tip`,children:[(0,d.jsx)(`span`,{className:`sr-tip-dot`}),`\xA0Fields marked `,(0,d.jsx)(`b`,{style:{color:`#c9a84c`},children:`*`}),` are required`]})]})]})]})]}),(0,d.jsx)(`form`,{onSubmit:V,children:(0,d.jsxs)(`div`,{className:`sr-form-wrap`,children:[(0,d.jsxs)(`div`,{className:`sr-section`,children:[(0,d.jsx)(p,{icon:(0,d.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,d.jsx)(`circle`,{cx:`8`,cy:`5`,r:`3`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,d.jsx)(`path`,{d:`M1 14c0-3.866 3.134-7 7-7s7 3.134 7 7`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`})]}),title:`Student Photo`,subtitle:`Optional — helps with quick identification in the directory.`}),(0,d.jsx)(`div`,{className:`sr-section-body`,children:(0,d.jsxs)(`div`,{className:`sr-photo-section`,children:[(0,d.jsx)(`div`,{className:`sr-avatar`,children:P?(0,d.jsx)(`img`,{src:P,alt:`Preview`}):(0,d.jsxs)(`div`,{className:`sr-avatar-placeholder`,children:[(0,d.jsxs)(`svg`,{width:`22`,height:`22`,viewBox:`0 0 24 24`,fill:`none`,children:[(0,d.jsx)(`circle`,{cx:`12`,cy:`9`,r:`4`,stroke:`currentColor`,strokeWidth:`1.4`}),(0,d.jsx)(`path`,{d:`M3 20c0-4.418 4.03-8 9-8s9 3.582 9 8`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`})]}),(0,d.jsx)(`span`,{children:`No photo`})]})}),(0,d.jsxs)(`div`,{className:`sr-photo-actions`,children:[(0,d.jsx)(`div`,{className:`sr-photo-name`,children:`Student photo`}),(0,d.jsx)(`div`,{className:`sr-photo-desc`,children:`JPEG or PNG. Recommended 200×200px or larger.`}),(0,d.jsxs)(`div`,{className:`sr-photo-btns`,children:[(0,d.jsxs)(`label`,{className:`sr-upload-btn`,children:[(0,d.jsxs)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:[(0,d.jsx)(`circle`,{cx:`7`,cy:`7`,r:`3`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,d.jsx)(`path`,{d:`M1 11.5V4.5a1 1 0 011-1h1l1-2h6l1 2h1a1 1 0 011 1v7a1 1 0 01-1 1H2a1 1 0 01-1-1z`,stroke:`currentColor`,strokeWidth:`1.2`,strokeLinejoin:`round`})]}),P?`Change photo`:`Upload photo`,(0,d.jsx)(`input`,{type:`file`,accept:`image/*`,onChange:z,style:{display:`none`}})]}),P&&(0,d.jsxs)(`button`,{type:`button`,className:`sr-remove-btn`,onClick:B,children:[(0,d.jsx)(`svg`,{width:`12`,height:`12`,viewBox:`0 0 12 12`,fill:`none`,children:(0,d.jsx)(`path`,{d:`M1 1l10 10M11 1L1 11`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})}),`Remove`]})]})]})]})})]}),(0,d.jsxs)(`div`,{className:`sr-section`,style:{"--si":`#fef3c7`,"--sc":`#b45309`},children:[(0,d.jsx)(p,{icon:(0,d.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,d.jsx)(`circle`,{cx:`8`,cy:`5.5`,r:`3`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,d.jsx)(`path`,{d:`M1 14c0-3.314 2.686-6 6-6h2c3.314 0 6 2.686 6 6`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`})]}),title:`Personal Information`,subtitle:`Full legal name, gender and date of birth.`,tag:`Required`}),(0,d.jsx)(`div`,{className:`sr-section-body`,children:(0,d.jsxs)(`div`,{className:`sr-grid`,children:[(0,d.jsx)(m,{label:`First Name`,required:!0,children:(0,d.jsx)(`input`,{name:`firstname`,className:`sr-input`,placeholder:`e.g. Covenant`,value:A.firstname,onChange:R,autoFocus:!0})}),(0,d.jsx)(m,{label:`Surname`,required:!0,children:(0,d.jsx)(`input`,{name:`surname`,className:`sr-input`,placeholder:`e.g. Okafor`,value:A.surname,onChange:R})}),(0,d.jsx)(m,{label:`Other Name`,required:!0,children:(0,d.jsx)(`input`,{name:`third_name`,className:`sr-input`,placeholder:`e.g. Emmanuel`,value:A.third_name,onChange:R})}),(0,d.jsx)(m,{label:`Gender`,required:!0,children:(0,d.jsxs)(`select`,{name:`gender`,className:`sr-select`,value:A.gender,onChange:R,children:[(0,d.jsx)(`option`,{value:``,children:`Select gender`}),(0,d.jsx)(`option`,{value:`Male`,children:`Male`}),(0,d.jsx)(`option`,{value:`Female`,children:`Female`})]})}),(0,d.jsx)(m,{label:`Date of Birth`,hint:`Optional`,children:(0,d.jsx)(`input`,{name:`dob`,type:`date`,className:`sr-input`,value:A.dob,onChange:R})})]})})]}),(0,d.jsxs)(`div`,{className:`sr-section`,style:{"--si":`#dbeafe`,"--sc":`#1e40af`},children:[(0,d.jsx)(p,{icon:(0,d.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,d.jsx)(`path`,{d:`M8 2L15 5.5l-7 3.5-7-3.5L8 2z`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinejoin:`round`}),(0,d.jsx)(`path`,{d:`M3.5 7.5V12c0 1.5 2 2.5 4.5 2.5s4.5-1 4.5-2.5V7.5`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`})]}),title:`Academic Information`,subtitle:`Class, section, department and admission number.`,tag:`Required`}),(0,d.jsx)(`div`,{className:`sr-section-body`,children:(0,d.jsxs)(`div`,{className:`sr-grid`,children:[O===0&&(0,d.jsx)(m,{label:`Admission Number`,hint:`Leave blank to auto-generate`,children:(0,d.jsx)(`input`,{name:`reg_no`,className:`sr-input`,placeholder:`e.g. GQ/2026/001`,value:A.reg_no,onChange:R})}),(0,d.jsx)(m,{label:`Class / Level`,required:!0,children:(0,d.jsxs)(`select`,{name:`level_id`,className:`sr-select`,value:A.level_id,onChange:R,children:[(0,d.jsx)(`option`,{value:``,children:`Select class`}),S.map(e=>(0,d.jsx)(`option`,{value:e.id,children:e.name},e.id))]})}),(0,d.jsx)(m,{label:`Section`,required:!0,children:(0,d.jsxs)(`select`,{name:`section_id`,className:`sr-select`,value:A.section_id,onChange:R,children:[(0,d.jsx)(`option`,{value:``,children:`Select section`}),w.map(e=>(0,d.jsx)(`option`,{value:e.id,children:e.name},e.id))]})}),(0,d.jsx)(m,{label:`Department`,required:!0,children:(0,d.jsxs)(`select`,{name:`department_id`,className:`sr-select`,value:A.department_id,onChange:R,children:[(0,d.jsx)(`option`,{value:``,children:`Select department`}),E.map(e=>(0,d.jsx)(`option`,{value:e.id,children:e.name},e.id))]})})]})})]}),(0,d.jsxs)(`div`,{className:`sr-section`,style:{"--si":`#d1fae5`,"--sc":`#065f46`},children:[(0,d.jsx)(p,{icon:(0,d.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,d.jsx)(`circle`,{cx:`8`,cy:`8`,r:`7`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,d.jsx)(`path`,{d:`M8 5v3.5L10 10`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),title:`Additional Details`,subtitle:`Health, religious and nationality information.`}),(0,d.jsx)(`div`,{className:`sr-section-body`,children:(0,d.jsxs)(`div`,{className:`sr-grid`,children:[(0,d.jsx)(m,{label:`Blood Group`,children:(0,d.jsxs)(`select`,{name:`blood_group`,className:`sr-select`,value:A.blood_group,onChange:R,children:[(0,d.jsx)(`option`,{value:``,children:`Select`}),[`A+`,`A-`,`B+`,`B-`,`AB+`,`AB-`,`O+`,`O-`].map(e=>(0,d.jsx)(`option`,{children:e},e))]})}),(0,d.jsx)(m,{label:`Religion`,children:(0,d.jsx)(`input`,{name:`religion`,className:`sr-input`,placeholder:`e.g. Christianity, Islam`,value:A.religion,onChange:R})}),(0,d.jsx)(m,{label:`Nationality`,children:(0,d.jsx)(`input`,{name:`nationality`,className:`sr-input`,placeholder:`e.g. Nigerian`,value:A.nationality,onChange:R})})]})})]}),(0,d.jsxs)(`div`,{className:`sr-section`,style:{"--si":`#ede9fe`,"--sc":`#7c3aed`},children:[(0,d.jsx)(p,{icon:(0,d.jsx)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:(0,d.jsx)(`path`,{d:`M2 2h3l1.5 4-1.5 1.5a9 9 0 004 4l1.5-1.5L14 11.5V14a1.5 1.5 0 01-1.5 1.5A13.5 13.5 0 011 2A1.5 1.5 0 012.5 .5H2z`,stroke:`currentColor`,strokeWidth:`1.2`,strokeLinejoin:`round`})}),title:`Contact Information`,subtitle:`Phone number and residential address.`}),(0,d.jsx)(`div`,{className:`sr-section-body`,children:(0,d.jsxs)(`div`,{className:`sr-grid`,children:[(0,d.jsx)(m,{label:`Phone Number`,children:(0,d.jsx)(`input`,{name:`phone`,className:`sr-input`,placeholder:`e.g. 08012345678`,value:A.phone,onChange:R})}),(0,d.jsx)(`div`,{className:`sr-col2`,children:(0,d.jsx)(m,{label:`Address`,children:(0,d.jsx)(`input`,{name:`address`,className:`sr-input`,placeholder:`Residential address`,value:A.address,onChange:R})})})]})})]})]})}),(0,d.jsx)(`div`,{style:{marginTop:`auto`},children:(0,d.jsx)(l,{})})]})]})}),(0,d.jsxs)(`div`,{className:`sr-action-bar`,children:[(0,d.jsxs)(`div`,{className:`sr-action-status`,children:[(0,d.jsx)(`span`,{className:`sr-action-status-dot ${I?`sr-action-status-dot--ok`:`sr-action-status-dot--warn`}`}),I?`All required fields complete — ready to register.`:`Complete required fields (*) to enable submission.`]}),(0,d.jsxs)(`div`,{className:`sr-action-btns mb-5`,children:[(0,d.jsx)(`button`,{type:`button`,className:`sr-cancel-btn`,onClick:()=>x(`/students`),disabled:h,children:`Cancel`}),(0,d.jsx)(`button`,{type:`submit`,form:`sr-form`,className:`sr-submit-btn ${I&&!h?`sr-submit-btn--ready`:``}`,disabled:h||!I,onClick:V,children:h?(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(`span`,{className:`sr-spinner`}),`Registering…`]}):(0,d.jsxs)(d.Fragment,{children:[(0,d.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,children:[(0,d.jsx)(`circle`,{cx:`7`,cy:`7`,r:`5.5`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,d.jsx)(`path`,{d:`M4 7l2 2 4-4`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),`Register Student`]})})]})]})]})}export{h as default};