import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{p as t}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{E as n,P as r,d as i,f as a,u as o}from"./index-D6TxbaCx.js";var s=e(),c=t();function l(e){if(!e)return`—`;let t=new Date(e);return Number.isNaN(t.getTime())?e:t.toLocaleDateString()}function u(e){switch(e){case`confirmed`:return{bg:`#d1fae5`,color:`#065f46`};case`completed`:return{bg:`#dbeafe`,color:`#1e40af`};case`cancelled`:return{bg:`#fee2e2`,color:`#b91c1c`};default:return{bg:`#fef3c7`,color:`#b45309`}}}function d(){let[e,t]=(0,s.useState)(!1),[d,f]=(0,s.useState)(!0),[p,m]=(0,s.useState)(!1),[h,g]=(0,s.useState)(null),[_,v]=(0,s.useState)([]),[y,b]=(0,s.useState)(1),[x,S]=(0,s.useState)({current_page:1,last_page:1,per_page:10,total:0}),[C,w]=(0,s.useState)(``),[T,E]=(0,s.useState)(``),[D,O]=(0,s.useState)(``),[k,A]=(0,s.useState)(null),[j,M]=(0,s.useState)(null),N=async(e=1)=>{try{m(!0),g(null);let t=await r.get(`/admin/demo-bookings`,{params:{page:e,per_page:10,search:C||void 0,status:T||void 0,date:D||void 0}});v(t.data.data||[]),S({current_page:t.data.current_page,last_page:t.data.last_page,per_page:t.data.per_page,total:t.data.total})}catch(e){g(e?.response?.data?.message||`Unable to load demo bookings.`),v([])}finally{f(!1),m(!1)}};(0,s.useEffect)(()=>{N(1)},[]),(0,s.useEffect)(()=>{y!==1&&N(y)},[y]);let P=(0,s.useMemo)(()=>Math.max(1,x.last_page||1),[x.last_page]),F=()=>{b(1),N(1)},I=()=>{w(``),E(``),O(``),b(1),setTimeout(()=>N(1),0)},L=async(e,t)=>{try{M(e),await r.patch(`/admin/demo-bookings/${e}/status`,{status:t}),v(n=>n.map(n=>n.id===e?{...n,status:t}:n)),k?.id===e&&A({...k,status:t})}catch(e){alert(e?.response?.data?.message||`Failed to update booking status.`)}finally{M(null)}};return(0,c.jsxs)(c.Fragment,{children:[(0,c.jsx)(`style`,{children:`
        .db-main {
          background: var(--bs-body-bg, #f5f1eb);
          min-height: 100vh;
          font-family: "DM Sans", system-ui, sans-serif;
          padding: 28px 28px 0;
        }

        .db-hero {
          background: #0f172a;
          border-radius: 16px;
          padding: 32px 36px;
          position: relative;
          overflow: hidden;
          margin-bottom: 24px;
        }

        .db-hero::before {
          content: "";
          position: absolute;
          inset: 0;
          background-image: radial-gradient(circle, rgba(255,255,255,0.045) 1px, transparent 1px);
          background-size: 24px 24px;
        }

        .db-hero-inner {
          position: relative;
          z-index: 1;
          display: flex;
          justify-content: space-between;
          gap: 24px;
          flex-wrap: wrap;
          align-items: center;
        }

        .db-greeting {
          font-size: clamp(22px, 2.5vw, 32px);
          font-weight: 700;
          color: #fff;
          margin: 0 0 10px;
        }

        .db-greeting em {
          font-style: italic;
          color: #e8c97a;
        }

        .db-hero-sub {
          font-size: 13.5px;
          font-weight: 300;
          color: #94a3b8;
          line-height: 1.7;
          max-width: 650px;
          margin: 0;
        }

        .db-mini-card {
          background: rgba(255,255,255,0.05);
          border: 1px solid rgba(255,255,255,0.09);
          border-radius: 14px;
          padding: 18px 20px;
          min-width: 220px;
        }

        .db-mini-label {
          font-size: 11px;
          letter-spacing: 0.1em;
          text-transform: uppercase;
          color: #c9a84c;
          margin-bottom: 6px;
        }

        .db-mini-value {
          font-size: 28px;
          font-weight: 700;
          color: #fff;
        }

        .db-panel {
          background: #fff;
          border: 1px solid #ede8e0;
          border-radius: 14px;
          overflow: hidden;
          margin-bottom: 24px;
        }

        .db-panel-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          padding: 22px 24px 18px;
          border-bottom: 1px solid rgba(0,0,0,0.06);
          flex-wrap: wrap;
        }

        .db-panel-title {
          font-size: 18px;
          font-weight: 700;
          color: #1a1a2e;
          margin: 0;
        }

        .db-panel-sub {
          font-size: 12px;
          color: #9a8a7a;
          margin: 4px 0 0;
        }

        .db-filter-wrap {
          padding: 18px 24px;
          border-bottom: 1px solid rgba(0,0,0,0.06);
          display: grid;
          grid-template-columns: 2fr 1fr 1fr auto auto;
          gap: 12px;
        }

        @media (max-width: 991.98px) {
          .db-filter-wrap {
            grid-template-columns: 1fr;
          }
        }

        .db-input,
        .db-select {
          width: 100%;
          border: 1px solid #e5ddd3;
          background: #fff;
          border-radius: 10px;
          padding: 11px 14px;
          font-size: 14px;
          outline: none;
        }

        .db-input:focus,
        .db-select:focus {
          border-color: #c9a84c;
          box-shadow: 0 0 0 3px rgba(201,168,76,0.12);
        }

        .db-btn-gold,
        .db-btn-outline {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          border-radius: 10px;
          padding: 11px 16px;
          font-size: 13px;
          cursor: pointer;
          white-space: nowrap;
        }

        .db-btn-gold {
          background: #c9a84c;
          color: #0f172a;
          border: none;
        }

        .db-btn-outline {
          background: #fff;
          color: #7a6a5a;
          border: 1px solid #e5ddd3;
        }

        .db-btn-gold:hover { background: #e8c97a; }
        .db-btn-outline:hover { background: #f8f5ef; }

        .db-table-wrap {
          overflow-x: auto;
        }

        .db-table {
          width: 100%;
          border-collapse: collapse;
        }

        .db-table th {
          padding: 12px 16px;
          font-size: 11px;
          text-transform: uppercase;
          letter-spacing: 0.08em;
          color: #9a8a7a;
          background: #faf8f5;
          border-bottom: 1px solid rgba(0,0,0,0.06);
          text-align: left;
          white-space: nowrap;
        }

        .db-table td {
          padding: 14px 16px;
          font-size: 13.5px;
          color: #4a4a5a;
          border-bottom: 1px solid rgba(0,0,0,0.06);
          vertical-align: top;
        }

        .db-table tbody tr:hover {
          background: #faf8f5;
        }

        .db-name {
          font-weight: 600;
          color: #1a1a2e;
        }

        .db-subtext {
          font-size: 12px;
          color: #9a8a7a;
          margin-top: 3px;
        }

        .db-status-pill {
          display: inline-flex;
          align-items: center;
          padding: 4px 10px;
          border-radius: 999px;
          font-size: 12px;
          font-weight: 600;
          text-transform: capitalize;
        }

        .db-action-row {
          display: flex;
          gap: 8px;
          flex-wrap: wrap;
        }

        .db-icon-btn {
          border: 1px solid #e5ddd3;
          background: #fff;
          border-radius: 8px;
          padding: 7px 10px;
          font-size: 12px;
          cursor: pointer;
        }

        .db-icon-btn:hover {
          background: #f8f5ef;
        }

        .db-pagination {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 14px 20px;
          border-top: 1px solid rgba(0,0,0,0.06);
          flex-wrap: wrap;
          gap: 10px;
        }

        .db-page-info {
          font-size: 12px;
          color: #9a8a7a;
        }

        .db-page-btns {
          display: flex;
          gap: 8px;
          align-items: center;
        }

        .db-page-btn {
          border: 1px solid #e5ddd3;
          background: #f5f1eb;
          color: #7a6a5a;
          border-radius: 8px;
          padding: 7px 12px;
          font-size: 12px;
          cursor: pointer;
        }

        .db-page-btn:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }

        .db-empty {
          padding: 48px 16px;
          text-align: center;
          color: #9a8a7a;
          font-size: 14px;
        }

        .db-error {
          margin: 16px 24px;
          background: #fff7ed;
          border: 1px solid #fed7aa;
          color: #9a3412;
          border-radius: 10px;
          padding: 12px 14px;
          font-size: 13px;
        }

        .db-modal-backdrop {
          position: fixed;
          inset: 0;
          background: rgba(15, 23, 42, 0.45);
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 20px;
          z-index: 2000;
        }

        .db-modal {
          width: 100%;
          max-width: 680px;
          background: #fff;
          border-radius: 16px;
          overflow: hidden;
          border: 1px solid #ede8e0;
          box-shadow: 0 20px 60px rgba(0,0,0,0.18);
        }

        .db-modal-head {
          padding: 20px 22px;
          border-bottom: 1px solid rgba(0,0,0,0.06);
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 12px;
        }

        .db-modal-body {
          padding: 22px;
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 14px 18px;
        }

        @media (max-width: 767.98px) {
          .db-modal-body {
            grid-template-columns: 1fr;
          }
        }

        .db-detail {
          background: #faf8f5;
          border: 1px solid #efe8dc;
          border-radius: 12px;
          padding: 14px;
        }

        .db-detail-label {
          font-size: 11px;
          text-transform: uppercase;
          letter-spacing: 0.08em;
          color: #9a8a7a;
          margin-bottom: 6px;
        }

        .db-detail-value {
          font-size: 14px;
          color: #1a1a2e;
          word-break: break-word;
        }

        .db-detail-full {
          grid-column: 1 / -1;
        }
      `}),(0,c.jsx)(a,{sidebarOpen:e,setSidebarOpen:t}),(0,c.jsx)(`div`,{className:`container-fluid`,children:(0,c.jsxs)(`div`,{className:`row`,children:[(0,c.jsx)(i,{sidebarOpen:e,setSidebarOpen:t}),(0,c.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto db-main sa-main`,children:[d&&(0,c.jsx)(n,{message:`Loading demo bookings…`}),(0,c.jsx)(`div`,{className:`db-hero`,children:(0,c.jsxs)(`div`,{className:`db-hero-inner`,children:[(0,c.jsxs)(`div`,{children:[(0,c.jsxs)(`h1`,{className:`db-greeting`,children:[`Demo `,(0,c.jsx)(`em`,{children:`Bookers`})]}),(0,c.jsx)(`p`,{className:`db-hero-sub`,children:`View, search, filter, and manage all demo booking requests submitted from your public website form.`})]}),(0,c.jsxs)(`div`,{className:`db-mini-card`,children:[(0,c.jsx)(`div`,{className:`db-mini-label`,children:`Total bookings`}),(0,c.jsx)(`div`,{className:`db-mini-value`,children:x.total})]})]})}),(0,c.jsxs)(`div`,{className:`db-panel`,children:[(0,c.jsx)(`div`,{className:`db-panel-head`,children:(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`h2`,{className:`db-panel-title`,children:`Booking Requests`}),(0,c.jsx)(`p`,{className:`db-panel-sub`,children:`Authenticated dashboard view powered by authApi`})]})}),(0,c.jsxs)(`div`,{className:`db-filter-wrap`,children:[(0,c.jsx)(`input`,{className:`db-input`,type:`text`,placeholder:`Search by name, email, phone, or school...`,value:C,onChange:e=>w(e.target.value)}),(0,c.jsxs)(`select`,{className:`db-select`,value:T,onChange:e=>E(e.target.value),children:[(0,c.jsx)(`option`,{value:``,children:`All statuses`}),(0,c.jsx)(`option`,{value:`pending`,children:`Pending`}),(0,c.jsx)(`option`,{value:`confirmed`,children:`Confirmed`}),(0,c.jsx)(`option`,{value:`cancelled`,children:`Cancelled`}),(0,c.jsx)(`option`,{value:`completed`,children:`Completed`})]}),(0,c.jsx)(`input`,{className:`db-input`,type:`date`,value:D,onChange:e=>O(e.target.value)}),(0,c.jsx)(`button`,{className:`db-btn-gold`,onClick:F,children:`Apply Filters`}),(0,c.jsx)(`button`,{className:`db-btn-outline`,onClick:I,children:`Clear`})]}),h&&(0,c.jsx)(`div`,{className:`db-error`,children:h}),(0,c.jsx)(`div`,{className:`db-table-wrap`,children:(0,c.jsxs)(`table`,{className:`db-table`,children:[(0,c.jsx)(`thead`,{children:(0,c.jsxs)(`tr`,{children:[(0,c.jsx)(`th`,{children:`Name`}),(0,c.jsx)(`th`,{children:`School`}),(0,c.jsx)(`th`,{children:`Contact`}),(0,c.jsx)(`th`,{children:`Preferred Slot`}),(0,c.jsx)(`th`,{children:`Status`}),(0,c.jsx)(`th`,{children:`Action`})]})}),(0,c.jsx)(`tbody`,{children:p?(0,c.jsx)(`tr`,{children:(0,c.jsx)(`td`,{colSpan:6,className:`db-empty`,children:`Loading bookings...`})}):_.length===0?(0,c.jsx)(`tr`,{children:(0,c.jsx)(`td`,{colSpan:6,className:`db-empty`,children:`No booking requests found.`})}):_.map(e=>{let t=u(e.status);return(0,c.jsxs)(`tr`,{children:[(0,c.jsxs)(`td`,{children:[(0,c.jsx)(`div`,{className:`db-name`,children:e.full_name}),(0,c.jsx)(`div`,{className:`db-subtext`,children:e.role})]}),(0,c.jsxs)(`td`,{children:[(0,c.jsx)(`div`,{className:`db-name`,children:e.school_name}),(0,c.jsx)(`div`,{className:`db-subtext`,children:e.school_type})]}),(0,c.jsxs)(`td`,{children:[(0,c.jsx)(`div`,{children:e.email}),(0,c.jsx)(`div`,{className:`db-subtext`,children:e.phone})]}),(0,c.jsxs)(`td`,{children:[(0,c.jsx)(`div`,{children:l(e.preferred_date)}),(0,c.jsxs)(`div`,{className:`db-subtext`,children:[e.preferred_time,` (WAT)`]})]}),(0,c.jsx)(`td`,{children:(0,c.jsx)(`span`,{className:`db-status-pill`,style:{background:t.bg,color:t.color},children:e.status})}),(0,c.jsx)(`td`,{children:(0,c.jsxs)(`div`,{className:`db-action-row`,children:[(0,c.jsx)(`button`,{className:`db-icon-btn`,onClick:()=>A(e),children:`View`}),(0,c.jsx)(`button`,{className:`db-icon-btn`,disabled:j===e.id,onClick:()=>L(e.id,`confirmed`),children:`Confirm`}),(0,c.jsx)(`button`,{className:`db-icon-btn`,disabled:j===e.id,onClick:()=>L(e.id,`completed`),children:`Complete`})]})})]},e.id)})})]})}),(0,c.jsxs)(`div`,{className:`db-pagination`,children:[(0,c.jsxs)(`span`,{className:`db-page-info`,children:[`Showing page `,x.current_page,` of `,P,` · `,x.total,` total`]}),(0,c.jsxs)(`div`,{className:`db-page-btns`,children:[(0,c.jsx)(`button`,{className:`db-page-btn`,disabled:y<=1||p,onClick:()=>b(e=>Math.max(1,e-1)),children:`Prev`}),(0,c.jsx)(`button`,{className:`db-page-btn`,disabled:y>=P||p,onClick:()=>b(e=>Math.min(P,e+1)),children:`Next`})]})]})]}),(0,c.jsx)(o,{})]})]})}),k&&(0,c.jsx)(`div`,{className:`db-modal-backdrop`,onClick:()=>A(null),children:(0,c.jsxs)(`div`,{className:`db-modal`,onClick:e=>e.stopPropagation(),children:[(0,c.jsxs)(`div`,{className:`db-modal-head`,children:[(0,c.jsxs)(`div`,{children:[(0,c.jsx)(`h3`,{style:{margin:0,fontSize:18,color:`#1a1a2e`},children:k.full_name}),(0,c.jsx)(`p`,{style:{margin:`4px 0 0`,fontSize:12,color:`#9a8a7a`},children:`Demo booking details`})]}),(0,c.jsx)(`button`,{className:`db-icon-btn`,onClick:()=>A(null),children:`Close`})]}),(0,c.jsxs)(`div`,{className:`db-modal-body`,children:[(0,c.jsxs)(`div`,{className:`db-detail`,children:[(0,c.jsx)(`div`,{className:`db-detail-label`,children:`Email`}),(0,c.jsx)(`div`,{className:`db-detail-value`,children:k.email})]}),(0,c.jsxs)(`div`,{className:`db-detail`,children:[(0,c.jsx)(`div`,{className:`db-detail-label`,children:`Phone`}),(0,c.jsx)(`div`,{className:`db-detail-value`,children:k.phone})]}),(0,c.jsxs)(`div`,{className:`db-detail`,children:[(0,c.jsx)(`div`,{className:`db-detail-label`,children:`School`}),(0,c.jsx)(`div`,{className:`db-detail-value`,children:k.school_name})]}),(0,c.jsxs)(`div`,{className:`db-detail`,children:[(0,c.jsx)(`div`,{className:`db-detail-label`,children:`Role`}),(0,c.jsx)(`div`,{className:`db-detail-value`,children:k.role})]}),(0,c.jsxs)(`div`,{className:`db-detail`,children:[(0,c.jsx)(`div`,{className:`db-detail-label`,children:`School Type`}),(0,c.jsx)(`div`,{className:`db-detail-value`,children:k.school_type})]}),(0,c.jsxs)(`div`,{className:`db-detail`,children:[(0,c.jsx)(`div`,{className:`db-detail-label`,children:`Student Count`}),(0,c.jsx)(`div`,{className:`db-detail-value`,children:k.student_count})]}),(0,c.jsxs)(`div`,{className:`db-detail`,children:[(0,c.jsx)(`div`,{className:`db-detail-label`,children:`Preferred Date`}),(0,c.jsx)(`div`,{className:`db-detail-value`,children:l(k.preferred_date)})]}),(0,c.jsxs)(`div`,{className:`db-detail`,children:[(0,c.jsx)(`div`,{className:`db-detail-label`,children:`Preferred Time`}),(0,c.jsxs)(`div`,{className:`db-detail-value`,children:[k.preferred_time,` (WAT)`]})]}),(0,c.jsxs)(`div`,{className:`db-detail`,children:[(0,c.jsx)(`div`,{className:`db-detail-label`,children:`Status`}),(0,c.jsx)(`div`,{className:`db-detail-value`,children:k.status})]}),(0,c.jsxs)(`div`,{className:`db-detail`,children:[(0,c.jsx)(`div`,{className:`db-detail-label`,children:`Submitted`}),(0,c.jsx)(`div`,{className:`db-detail-value`,children:l(k.created_at||``)})]}),(0,c.jsxs)(`div`,{className:`db-detail db-detail-full`,children:[(0,c.jsx)(`div`,{className:`db-detail-label`,children:`Message`}),(0,c.jsx)(`div`,{className:`db-detail-value`,children:k.message||`No additional note provided.`})]})]})]})})]})}export{d as default};