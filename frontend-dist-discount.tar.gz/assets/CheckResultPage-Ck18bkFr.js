import{i as e}from"./rolldown-runtime-CWU8vmCm.js";import{Ut as t}from"./vendor-misc-OZLc0tLq.js";import{h as n,p as r}from"./vendor-react-BhRGw7qi.js";import{i,r as a}from"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as o,F as ee,L as te,l as ne,u as re}from"./index-D6TxbaCx.js";import{t as s}from"./vendor-qr-Xjq4Czgo.js";var c=e(t(),1),ie=e(i(),1),ae=e(s(),1),l=r(),oe=[`#2563eb`,`#16a34a`,`#f59e0b`,`#dc2626`,`#7c3aed`,`#0891b2`],se=[`#0f766e`,`#9333ea`,`#ea580c`,`#0284c7`,`#be123c`,`#4f46e5`],u={show_position:!0,show_grade:!0,show_remarks:!0,show_first_term:!1,show_second_term:!1,show_cumulative_total:!1,show_cumulative_average:!1};function d(e){return(e||`all`).trim().toLowerCase()}function ce(e=[],t,n){return!Array.isArray(e)||e.length===0?{...u}:e.map(e=>{if(!e)return{rule:e,score:-1};let r=e.section_id??`all`,i=r===`all`||Number(r)===Number(t),a=d(e.term)===`all`||d(e.term)===d(n),o=(r===`all`?0:2)+(d(e.term)===`all`?0:1);return{rule:e,score:i&&a?o:-1}}).filter(e=>e.score>=0).sort((e,t)=>e.score-t.score).reduce((e,t)=>({...e,...t?.rule?.columns||{}}),{...u})}var f=e=>e===``||e===` `||e===`0`||e===0||e==null||e===`N/A`||e===`-`||e===`null`,p=(e,t=`N/A`)=>f(e)?t:e,m=e=>{let t=e?.carry_over_enabled;return t===!0||t===1||t===`1`},h=e=>{if(!e)return null;if(typeof e==`object`)return e;try{return JSON.parse(e)}catch{return null}},g=e=>{if(!e)return[];if(typeof e==`object`)return Object.values(e).map(e=>Number(e)||0);try{return Object.values(JSON.parse(e)).map(e=>Number(e)||0)}catch{return[Number(e)||0]}},le=e=>`subject_name`in e&&e.subject_name?e.subject_name:`subject`in e&&e.subject?.name?e.subject.name:`Unknown Subject`,ue=e=>{let t=(e||``).replace(`#`,``);if(t.length!==6)return`#fff`;let n=parseInt(t.substring(0,2),16),r=parseInt(t.substring(2,4),16),i=parseInt(t.substring(4,6),16);return(n*299+r*587+i*114)/1e3>=140?`#111827`:`#fff`},de=(e,t)=>{let n=(e||``).replace(`#`,``);return n.length===6?`rgba(${parseInt(n.substring(0,2),16)}, ${parseInt(n.substring(2,4),16)}, ${parseInt(n.substring(4,6),16)}, ${t})`:`rgba(13, 71, 161, ${t})`},fe=(e,t=82)=>{let n=(e||``).replace(`#`,``);if(n.length!==6)return`#f8fafc`;let r=Math.max(0,Math.min(100,t))/100;return`rgb(${Math.round(parseInt(n.substring(0,2),16)*(1-r)+255*r)}, ${Math.round(parseInt(n.substring(2,4),16)*(1-r)+255*r)}, ${Math.round(parseInt(n.substring(4,6),16)*(1-r)+255*r)})`};function _(){let{showSuccess:e,showError:t}=ne(),[r,i]=(0,c.useState)(!1),[s,u]=(0,c.useState)(!1),[_,v]=(0,c.useState)(``),[y,b]=(0,c.useState)(``),[x,S]=(0,c.useState)(null),[pe,C]=(0,c.useState)(``);(0,c.useEffect)(()=>{let e=new URLSearchParams(window.location.search),t=e.get(`reg_no`)||e.get(`student_reg_no`)||``,n=e.get(`pin`)||``;t&&v(t),n&&b(n)},[]);let me=e=>({msg:e?.response?.data?.message||e?.message||`Something went wrong. Please try again.`,errors:e?.response?.data?.errors,payload:e?.response?.data}),he=(0,c.useMemo)(()=>_.trim().length>0&&y.trim().length>0&&!r,[_,y,r]),ge=async n=>{n.preventDefault(),i(!0),S(null),C(``);try{let t=await ee.get(`/public/check-result`,{params:{reg_no:_.trim(),pin:y.trim()}});S(t.data);let n=t.data.average?.term,r=t.data.average?.session,i={studentId:t.data.user.id,reg_no:t.data.user.reg_no||_.trim(),term:n,session:r},a=encodeURIComponent(JSON.stringify(i)),o=`${te()}/verify-result?data=${a}&reg_no=${encodeURIComponent(i.reg_no||``)}&term=${encodeURIComponent(i.term)}&session=${encodeURIComponent(i.session)}`;C(await ae.toDataURL(o)),e(`Result loaded successfully.`)}catch(e){console.error(e);let{msg:n,errors:r,payload:i}=me(e);if(r&&typeof r==`object`){let e=r[Object.keys(r)[0]];t((Array.isArray(e)?e[0]:String(e))||n);return}if(i?.status===`fee_restricted`){t(i?.message||`Access restricted due to unpaid fees.`);return}t(n)}finally{i(!1)}},_e=()=>{v(``),b(``),S(null),C(``)},w=x?.source===`v2`,T=x?.user,ve=x?.user_photo_base64,E=x?.school_info,D=x?.term_result||[],O=x?.average,k=x?.affective_domains||[],A=x?.psychomotor_domains||[],ye=x?.class_name||`N/A`,j=x?.result_template||{},M={show_position:!0,show_grade:!0,show_remarks:!0,show_attendance:!0,show_domains:!0,show_qr_code:!0,show_signature:!0,show_student_photo:!0,show_watermark:!0,...j.display_options||{}},N=ce(M.report_column_rules||[],x?.class_section_id,String(O?.term||``)),be=M.show_position&&N.show_position,P=M.show_grade&&N.show_grade,F=M.show_remarks&&N.show_remarks,I=j.primary_color||E?.primary_color||`#0d47a1`,L=j.secondary_color||E?.secondary_color||`#ffc107`,xe=j.background_color||E?.background_color||`#ffffff`,R=j.template_key||`classic_academic`,Se=j.font_family||`Arial`,z=R===`modern_scholar`,B=R===`premium_letterhead`,Ce=M.custom_report_layout,V=R===`custom_builder`&&Ce?.enabled!==!1,H=Ce?.blocks||[],U=e=>{if(!V)return{};let t=H.findIndex(t=>t.type===e),n=t>=0?H[t]:void 0;return{order:t>=0?t:H.length,gridColumn:n?.width===`half`?`span 1`:`1 / -1`,display:n?.visible===!1?`none`:void 0,minWidth:0}},W=ue(I),G=I,K={border:`1px solid ${G}`,padding:`7px 5px`,textAlign:`center`,background:I,color:W},q={border:`1px solid ${de(G,.55)}`,padding:`6px 5px`,textAlign:`center`},we={width:`100%`,borderCollapse:`collapse`,border:`1px solid ${G}`,fontSize:`11px`},Te={display:`grid`,gridTemplateColumns:z?`minmax(0, 1.25fr) minmax(245px, .75fr)`:`1fr`,gap:12,alignItems:`start`,borderTop:B?`1px solid ${I}55`:void 0,marginTop:B?12:void 0,paddingTop:B?2:void 0},Ee={minWidth:0,marginTop:z?12:0,display:B?`grid`:void 0,gridTemplateColumns:B?`1.2fr .8fr`:void 0,gap:B?10:void 0,alignItems:B?`start`:void 0},De={display:`grid`,gridTemplateColumns:z?`1fr`:`1.2fr .8fr`,gap:10,marginTop:12},Oe={display:`grid`,gridTemplateColumns:z?`1fr`:`1fr 1fr`,marginTop:B?0:12,gap:10},ke=O?.term||``,Ae=(0,c.useMemo)(()=>{if(!x||!w)return[];let e=new Set;D.forEach(t=>{if(!(t.carry_over?.enabled||m(t)))return;let n=(h(t.carry_over_json)??t.carry_over)?.terms??{};Object.keys(n).forEach(t=>{t&&t!==ke&&e.add(t)})});let t={"First Term":1,"Second Term":2,"Third Term":3};return Array.from(e).sort((e,n)=>(t[e]??99)-(t[n]??99))},[x,w,D,ke]),{maxCAColumns:je,caColumnValue:Me}=(0,c.useMemo)(()=>{let e=0;if(!Array.isArray(D)||D.length===0)return{maxCAColumns:0,caColumnValue:0};for(let t of D){let n=g(t?.ca);if(n.length>0){e=Math.round(40/n.length);break}}return{maxCAColumns:Math.max(...D.map(e=>g(e?.ca).length),0),caColumnValue:e}},[D]),Ne=Ae.filter(e=>{let t=d(e);return t.includes(`first`)?N.show_first_term:t.includes(`second`)?N.show_second_term:!0}),J=Array.from(new Set([...N.show_first_term?[`First Term`]:[],...N.show_second_term?[`Second Term`]:[],...Ne])),Y=N.show_cumulative_total,X=N.show_cumulative_average,Z=!w&&Array.isArray(D)&&D.length>0,Pe=Z?!N.show_first_term||D.every(e=>f(e?.firstterm)):!0,Fe=Z?!N.show_second_term||D.every(e=>f(e?.secondterm)):!0,Ie=Z?!N.show_cumulative_average||D.every(e=>f(e?.average)):!0,Le=Array.isArray(D)?D.every(e=>f(e?.grade)):!0,Re=Array.isArray(D)?D.every(e=>f(e?.remark)):!0,Q=Array.isArray(D)?D.map(e=>({name:le(e),total:Math.max(0,Math.min(100,Number(e?.total)||0)),grade:String(e?.grade||`N/A`).toUpperCase()})).sort((e,t)=>t.total-e.total):[],ze=Q.slice(0,6),Be=Q.reduce((e,t)=>{let n=t.grade&&t.grade!==`N/A`?t.grade.charAt(0):`N/A`;return e[n]=(e[n]||0)+1,e},{}),Ve=(()=>{let e=Number(O?.no_present)||0,t=Number(O?.school_open)||0;return t>0?Math.round(e/t*100):0})(),He=!!w&&(N.show_first_term||N.show_second_term||Y||X||J.length>0),Ue=(0,c.useMemo)(()=>T?`${T.surname||``} ${T.firstname||``} ${T.third_name||``}`.trim():``,[T]),We=async()=>{if(x){u(!0);try{let e=document.getElementById(`result-sheet`);if(!e)return;let t=await(0,ie.default)(e,{scale:2,useCORS:!0}),n=t.toDataURL(`image/png`),r=new a(`p`,`pt`,`a4`),i=595.28,o=t.height*i/t.width;r.addImage(n,`PNG`,0,0,i,Math.min(o,841.89)),r.save(`Result_${T?.reg_no||_.trim()||`student`}.pdf`)}catch(e){console.error(`Error generating PDF:`,e),t(`Failed to generate PDF.`)}finally{u(!1)}}},$=()=>{window.print()};return(0,l.jsxs)(`main`,{className:`gq-cr-page`,children:[(0,l.jsx)(o,{title:`Student Result Checker | SchoolProfit`}),(0,l.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&family=Playfair+Display:ital,wght@0,400..900;1,400..900&family=Cinzel:wght@600;700;800&display=swap');

        .gq-cr-page {
          min-height: 100vh;
          background: #f8fafc;
          color: #0f172a;
          padding: 24px 16px 60px;
          font-family: 'DM Sans', system-ui, -apple-system, sans-serif;
        }

        .gq-cr-shell {
          max-width: 1200px;
          margin: 0 auto;
        }

        /* ── Top Bar with Security Badges ── */
        .gq-cr-topbar {
          display: flex;
          justify-content: space-between;
          align-items: center;
          background: #ffffff;
          border: 1px solid #e2e8f0;
          border-radius: 16px;
          padding: 12px 24px;
          margin-bottom: 20px;
          box-shadow: 0 2px 8px rgba(15, 23, 42, 0.04);
        }

        .gq-cr-brand {
          display: flex;
          align-items: center;
          gap: 12px;
          text-decoration: none;
          color: #0f172a;
        }

        .gq-cr-logo-badge {
          width: 36px;
          height: 36px;
          border-radius: 10px;
          background: linear-gradient(135deg, #f59e0b, #d97706);
          color: #ffffff;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: 900;
          font-size: 16px;
          box-shadow: 0 4px 12px rgba(245, 158, 11, 0.25);
        }

        .gq-cr-brand-title {
          font-weight: 800;
          font-size: 16px;
          color: #0f172a;
          line-height: 1.1;
          letter-spacing: -0.02em;
        }

        .gq-cr-brand-sub {
          font-size: 10.5px;
          text-transform: uppercase;
          letter-spacing: 0.08em;
          color: #64748b;
          font-weight: 700;
        }

        .gq-cr-badge-row {
          display: flex;
          align-items: center;
          gap: 16px;
          font-size: 12px;
          color: #475569;
          font-weight: 600;
        }

        .gq-cr-badge-item {
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .gq-cr-badge-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #10b981;
          box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.2);
        }

        /* ── Hero Banner ── */
        .gq-cr-hero {
          background: linear-gradient(135deg, #090e1f 0%, #151d38 60%, #1a2244 100%);
          border-radius: 20px;
          padding: 32px 36px;
          color: #ffffff;
          position: relative;
          overflow: hidden;
          border: 1px solid rgba(255, 255, 255, 0.1);
          box-shadow: 0 16px 36px rgba(9, 14, 31, 0.18);
          margin-bottom: 24px;
        }

        .gq-cr-hero::before {
          content: "";
          position: absolute;
          inset: 0;
          background-image: radial-gradient(circle, rgba(255,255,255,0.06) 1px, transparent 1px);
          background-size: 24px 24px;
          pointer-events: none;
        }

        .gq-cr-hero > * {
          position: relative;
          z-index: 1;
        }

        .gq-cr-pill {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          background: rgba(245, 158, 11, 0.16);
          border: 1px solid rgba(245, 158, 11, 0.35);
          color: #fbbf24;
          padding: 6px 14px;
          border-radius: 999px;
          font-size: 11.5px;
          font-weight: 800;
          margin-bottom: 14px;
          letter-spacing: 0.04em;
          text-transform: uppercase;
        }

        .gq-cr-title {
          font-family: 'Playfair Display', Georgia, serif;
          font-size: clamp(22px, 3.2vw, 32px);
          font-weight: 800;
          margin-bottom: 8px;
          color: #ffffff;
          line-height: 1.2;
        }

        .gq-cr-desc {
          font-size: 14px;
          color: rgba(255, 255, 255, 0.82);
          max-width: 680px;
          line-height: 1.5;
          margin: 0;
        }

        /* ── Left Form Card ── */
        .gq-cr-form-card {
          background: #ffffff;
          border: 1px solid #e2e8f0;
          border-radius: 18px;
          padding: 24px;
          box-shadow: 0 4px 16px rgba(15, 23, 42, 0.04);
        }

        .gq-cr-card-head {
          display: flex;
          align-items: center;
          gap: 10px;
          padding-bottom: 16px;
          margin-bottom: 20px;
          border-bottom: 1px solid #f1f5f9;
          font-weight: 800;
          font-size: 15px;
          color: #0f172a;
        }

        .gq-cr-label {
          display: block;
          font-size: 13px;
          font-weight: 700;
          color: #334155;
          margin-bottom: 6px;
        }

        .gq-cr-input {
          width: 100%;
          padding: 12px 14px;
          border-radius: 12px;
          border: 1px solid #cbd5e1;
          font-size: 14px;
          font-family: inherit;
          color: #0f172a;
          background: #ffffff;
          transition: all 0.2s ease;
          outline: none;
        }

        .gq-cr-input:focus {
          border-color: #f59e0b;
          box-shadow: 0 0 0 3px rgba(245, 158, 11, 0.18);
        }

        .gq-cr-btn-submit {
          width: 100%;
          padding: 13px 20px;
          border-radius: 12px;
          background: linear-gradient(135deg, #0f172a, #1e293b);
          color: #ffffff;
          font-weight: 800;
          font-size: 14px;
          border: 1px solid rgba(255, 255, 255, 0.1);
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          transition: all 0.2s ease;
          box-shadow: 0 4px 14px rgba(15, 23, 42, 0.15);
        }

        .gq-cr-btn-submit:hover:not(:disabled) {
          background: linear-gradient(135deg, #f59e0b, #d97706);
          color: #090e17;
          transform: translateY(-1px);
          box-shadow: 0 6px 18px rgba(245, 158, 11, 0.3);
        }

        .gq-cr-btn-submit:disabled {
          opacity: 0.65;
          cursor: not-allowed;
        }

        .gq-cr-btn-clear {
          width: 100%;
          padding: 10px 18px;
          border-radius: 12px;
          background: #f1f5f9;
          color: #475569;
          font-weight: 700;
          font-size: 13px;
          border: 1px solid #e2e8f0;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          transition: all 0.2s ease;
        }

        .gq-cr-btn-clear:hover {
          background: #e2e8f0;
          color: #0f172a;
        }

        .gq-cr-notice-box {
          background: #f8fafc;
          border: 1px solid #e2e8f0;
          border-radius: 12px;
          padding: 12px 14px;
          font-size: 12px;
          color: #64748b;
          line-height: 1.5;
          display: flex;
          gap: 10px;
          align-items: flex-start;
          margin-top: 14px;
        }

        /* ── Empty State / Result Preview Area ── */
        .gq-cr-empty-card {
          background: #ffffff;
          border: 1px solid #e2e8f0;
          border-radius: 18px;
          padding: 48px 32px;
          text-align: center;
          box-shadow: 0 4px 16px rgba(15, 23, 42, 0.04);
        }

        .gq-cr-empty-icon {
          width: 72px;
          height: 72px;
          border-radius: 20px;
          background: rgba(245, 158, 11, 0.1);
          color: #f59e0b;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          font-size: 32px;
          margin-bottom: 20px;
          border: 1px solid rgba(245, 158, 11, 0.2);
        }

        .gq-cr-step-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 14px;
          margin-top: 28px;
          text-align: left;
        }

        .gq-cr-step-item {
          background: #f8fafc;
          border: 1px solid #e2e8f0;
          border-radius: 14px;
          padding: 14px;
        }

        .gq-cr-step-num {
          font-weight: 900;
          font-size: 11px;
          color: #f59e0b;
          text-transform: uppercase;
          margin-bottom: 4px;
        }

        .gq-cr-step-title {
          font-weight: 700;
          font-size: 13px;
          color: #0f172a;
          margin-bottom: 4px;
        }

        .gq-cr-step-desc {
          font-size: 11.5px;
          color: #64748b;
          line-height: 1.4;
          margin: 0;
        }

        .gq-cr-toolbar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          background: #ffffff;
          border: 1px solid #e2e8f0;
          border-radius: 14px;
          padding: 12px 18px;
          margin-bottom: 16px;
          box-shadow: 0 2px 8px rgba(15, 23, 42, 0.04);
          flex-wrap: wrap;
          gap: 12px;
        }

        @media (max-width: 768px) {
          .gq-cr-topbar {
            flex-direction: column;
            align-items: flex-start;
            gap: 10px;
          }
          .gq-cr-badge-row {
            flex-wrap: wrap;
            gap: 10px;
          }
          .gq-cr-step-grid {
            grid-template-columns: 1fr;
          }
          .gq-cr-toolbar {
            flex-direction: column;
            align-items: stretch;
          }
        }
      `}),(0,l.jsxs)(`div`,{className:`gq-cr-shell`,children:[(0,l.jsxs)(`header`,{className:`gq-cr-topbar`,children:[(0,l.jsxs)(n,{to:`/`,className:`gq-cr-brand`,children:[(0,l.jsx)(`div`,{className:`gq-cr-logo-badge`,children:`GQ`}),(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`div`,{className:`gq-cr-brand-title`,children:`SchoolProfit Portal`}),(0,l.jsx)(`div`,{className:`gq-cr-brand-sub`,children:`Academic Records & Result Verification`})]})]}),(0,l.jsxs)(`div`,{className:`gq-cr-badge-row`,children:[(0,l.jsxs)(`div`,{className:`gq-cr-badge-item`,children:[(0,l.jsx)(`span`,{className:`gq-cr-badge-dot`}),(0,l.jsx)(`span`,{children:`256-Bit Encrypted`})]}),(0,l.jsxs)(`div`,{className:`gq-cr-badge-item d-none d-md-flex`,children:[(0,l.jsx)(`i`,{className:`bi bi-shield-check text-warning`}),(0,l.jsx)(`span`,{children:`Cryptographic PIN Verification`})]}),(0,l.jsx)(n,{to:`/verify-result`,className:`btn btn-sm btn-outline-secondary`,style:{borderRadius:`8px`,fontSize:`12px`,fontWeight:600},children:`Verify QR Seal`})]})]}),(0,l.jsx)(`section`,{className:`gq-cr-hero`,children:(0,l.jsxs)(`div`,{className:`row align-items-center`,children:[(0,l.jsxs)(`div`,{className:`col-lg-8`,children:[(0,l.jsxs)(`div`,{className:`gq-cr-pill`,children:[(0,l.jsx)(`i`,{className:`bi bi-patch-check-fill`}),` Official Result Checker`]}),(0,l.jsx)(`h1`,{className:`gq-cr-title`,children:`Student Academic Report & Result Portal`}),(0,l.jsx)(`p`,{className:`gq-cr-desc`,children:`Access certified continuous assessment broadsheets, subject breakdowns, and official termly report cards with your school admission number and result PIN.`})]}),x?.school_info?.name&&(0,l.jsx)(`div`,{className:`col-lg-4 d-none d-lg-block text-end`,children:(0,l.jsxs)(`div`,{style:{background:`rgba(255, 255, 255, 0.12)`,backdropFilter:`blur(12px)`,borderRadius:`16px`,padding:`16px 20px`,border:`1px solid rgba(255, 255, 255, 0.22)`,textAlign:`left`,display:`inline-block`},children:[(0,l.jsx)(`div`,{style:{fontSize:`11px`,textTransform:`uppercase`,color:`#fbbf24`,fontWeight:800},children:`Certified School`}),(0,l.jsx)(`div`,{style:{fontSize:`15px`,fontWeight:800,color:`#ffffff`,marginTop:`2px`},children:x.school_info.name}),(0,l.jsx)(`div`,{style:{fontSize:`12px`,color:`rgba(255,255,255,0.8)`,marginTop:`2px`},children:x.class_name})]})})]})}),(0,l.jsxs)(`div`,{className:`row g-4`,children:[(0,l.jsxs)(`div`,{className:`col-lg-4`,children:[(0,l.jsx)(`form`,{onSubmit:ge,children:(0,l.jsxs)(`div`,{className:`gq-cr-form-card`,children:[(0,l.jsxs)(`div`,{className:`gq-cr-card-head`,children:[(0,l.jsx)(`i`,{className:`bi bi-shield-lock text-warning`,style:{fontSize:`18px`}}),(0,l.jsx)(`span`,{children:`Enter Student Credentials`})]}),(0,l.jsxs)(`div`,{className:`mb-3`,children:[(0,l.jsx)(`label`,{className:`gq-cr-label`,children:`Student Registration / Admission No`}),(0,l.jsx)(`div`,{className:`position-relative`,children:(0,l.jsx)(`input`,{className:`gq-cr-input`,placeholder:`e.g. GQA/2026/001`,value:_,onChange:e=>v(e.target.value),autoComplete:`off`,required:!0})}),(0,l.jsx)(`small`,{style:{fontSize:`11px`,color:`#64748b`,marginTop:`4px`,display:`block`},children:`Assigned admission identifier by the school`})]}),(0,l.jsxs)(`div`,{className:`mb-3`,children:[(0,l.jsx)(`label`,{className:`gq-cr-label`,children:`Result Checking PIN`}),(0,l.jsx)(`input`,{className:`gq-cr-input`,placeholder:`e.g. GQ-7842-9901-X812`,value:y,onChange:e=>b(e.target.value),autoComplete:`off`,required:!0}),(0,l.jsx)(`small`,{style:{fontSize:`11px`,color:`#64748b`,marginTop:`4px`,display:`block`},children:`12-digit authentic termly scratch PIN`})]}),(0,l.jsxs)(`div`,{className:`d-grid gap-2 mt-4`,children:[(0,l.jsx)(`button`,{type:`submit`,className:`gq-cr-btn-submit`,disabled:!he,children:r?(0,l.jsxs)(l.Fragment,{children:[(0,l.jsx)(`span`,{className:`spinner-border spinner-border-sm`}),`Verifying Credentials...`]}):(0,l.jsxs)(l.Fragment,{children:[(0,l.jsx)(`i`,{className:`bi bi-search`}),`Check Result`]})}),(0,l.jsxs)(`button`,{type:`button`,className:`gq-cr-btn-clear`,onClick:_e,disabled:r,children:[(0,l.jsx)(`i`,{className:`bi bi-arrow-counterclockwise`}),`Clear Form`]})]}),(0,l.jsxs)(`div`,{className:`gq-cr-notice-box`,children:[(0,l.jsx)(`i`,{className:`bi bi-info-circle text-primary`,style:{fontSize:`16px`,marginTop:`2px`}}),(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`strong`,{children:`Bursary Notice:`}),` Academic results are accessible to students with full fee clearance. Contact your institution's bursary if restricted.`]})]})]})}),x&&(0,l.jsxs)(`div`,{className:`gq-cr-form-card mt-3`,children:[(0,l.jsxs)(`div`,{className:`gq-cr-card-head`,children:[(0,l.jsx)(`i`,{className:`bi bi-file-earmark-text text-success`,style:{fontSize:`18px`}}),(0,l.jsx)(`span`,{children:`Document Export`})]}),(0,l.jsxs)(`div`,{className:`d-grid gap-2`,children:[(0,l.jsx)(`button`,{type:`button`,className:`btn btn-primary`,style:{borderRadius:`12px`,padding:`12px`,fontWeight:700,display:`flex`,alignItems:`center`,justifyContent:`center`,gap:`8px`},onClick:We,disabled:s,children:s?(0,l.jsxs)(l.Fragment,{children:[(0,l.jsx)(`span`,{className:`spinner-border spinner-border-sm`}),`Generating PDF...`]}):(0,l.jsxs)(l.Fragment,{children:[(0,l.jsx)(`i`,{className:`bi bi-file-earmark-pdf`}),`Download Official PDF`]})}),(0,l.jsxs)(`button`,{type:`button`,className:`btn btn-outline-secondary`,style:{borderRadius:`12px`,padding:`10px`,fontWeight:600,display:`flex`,alignItems:`center`,justifyContent:`center`,gap:`8px`},onClick:$,children:[(0,l.jsx)(`i`,{className:`bi bi-printer`}),`Print Report Sheet`]})]})]})]}),(0,l.jsx)(`div`,{className:`col-lg-8`,children:x?(0,l.jsxs)(`div`,{children:[(0,l.jsxs)(`div`,{className:`gq-cr-toolbar`,children:[(0,l.jsxs)(`div`,{className:`d-flex align-items-center gap-2`,children:[(0,l.jsxs)(`span`,{className:`badge bg-success px-3 py-2`,style:{borderRadius:`8px`,fontSize:`12px`,fontWeight:700},children:[(0,l.jsx)(`i`,{className:`bi bi-patch-check-fill me-1`}),` Certified Result`]}),(0,l.jsxs)(`span`,{style:{fontSize:`13px`,fontWeight:700,color:`#0f172a`},children:[Ue,` · `,x.class_name]})]}),(0,l.jsxs)(`div`,{className:`d-flex align-items-center gap-2`,children:[(0,l.jsxs)(`button`,{type:`button`,className:`btn btn-sm btn-outline-secondary`,style:{borderRadius:`8px`,fontSize:`12px`,fontWeight:600},onClick:$,children:[(0,l.jsx)(`i`,{className:`bi bi-printer me-1`}),` Print`]}),(0,l.jsxs)(`button`,{type:`button`,className:`btn btn-sm btn-primary`,style:{borderRadius:`8px`,fontSize:`12px`,fontWeight:700},onClick:We,disabled:s,children:[(0,l.jsx)(`i`,{className:`bi bi-file-earmark-pdf me-1`}),` PDF`]})]})]}),(0,l.jsx)(`div`,{style:{padding:`10px`,background:xe,borderRadius:16,border:`1px solid #e2e8f0`,boxShadow:`0 4px 16px rgba(15, 23, 42, 0.04)`},children:(0,l.jsxs)(`div`,{id:`result-sheet`,style:{width:`min(780px, 100%)`,margin:`auto`,padding:`18px`,background:xe,fontFamily:Se,fontSize:`12px`,border:`3px solid ${I}`,borderRadius:R===`modern_scholar`?`18px`:`8px`,boxShadow:R===`premium_letterhead`?`inset 0 8px 0 ${I}`:void 0,boxSizing:`border-box`,position:`relative`,overflow:`visible`,color:`#111827`},children:[M.show_watermark&&E?.logo&&(0,l.jsx)(`div`,{style:{position:`absolute`,top:0,left:0,width:`100%`,height:`100%`,backgroundImage:`url(${E?.logo})`,backgroundRepeat:`repeat`,backgroundSize:`150px 150px`,opacity:.05,transform:`rotate(-30deg)`,zIndex:0,pointerEvents:`none`}}),(0,l.jsxs)(`div`,{style:{position:`relative`,zIndex:1},children:[(0,l.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:M.show_student_photo?`90px 1fr 90px`:`90px 1fr`,gap:`12px`,alignItems:`center`,borderBottom:`2px solid ${I}`,paddingBottom:`10px`},children:[(0,l.jsx)(`img`,{src:E?.logo||`https://via.placeholder.com/90x90.png?text=Logo`,alt:`School Logo`,style:{width:`90px`,height:`90px`,borderRadius:`6px`,objectFit:`cover`,border:`2px solid ${L}`}}),(0,l.jsxs)(`div`,{style:{flex:1,textAlign:`center`},children:[(0,l.jsx)(`h1`,{style:{margin:0,fontSize:`20px`,fontWeight:`bold`,color:I},children:E?.name}),(0,l.jsx)(`p`,{style:{margin:`3px 0`},children:E?.address}),(0,l.jsxs)(`p`,{style:{margin:`3px 0`},children:[`Tel: `,E?.phone]}),(0,l.jsxs)(`h2`,{style:{margin:`6px 0`,fontSize:`16px`,textTransform:`uppercase`,background:I,color:W,padding:`6px 12px`,borderRadius:`6px`,textAlign:`center`,letterSpacing:`1px`,border:`1px solid ${L}`},children:[O.term,` REPORT SHEET`]})]}),M.show_student_photo&&ve?(0,l.jsx)(`img`,{src:ve,alt:`student photo`,onError:e=>{let t=e.target;t.onerror=null,t.style.display=`none`},style:{width:`90px`,height:`90px`,borderRadius:`6px`,objectFit:`cover`,border:`2px solid ${L}`}}):M.show_student_photo?(0,l.jsx)(`div`,{style:{width:`90px`,height:`90px`,border:`2px dashed ${I}`,borderRadius:`6px`,display:`flex`,alignItems:`center`,justifyContent:`center`,fontSize:`12px`,color:`#666`,textAlign:`center`},children:`Student Photo`}):null]}),(0,l.jsxs)(`div`,{style:V?{display:`grid`,gridTemplateColumns:`repeat(2, minmax(0, 1fr))`,gap:12,alignItems:`start`}:void 0,children:[(0,l.jsx)(`div`,{style:{display:`grid`,gridTemplateColumns:`repeat(2, minmax(0, 1fr))`,gap:8,marginTop:12,...U(`student_info`)},children:[[`Name`,`${T?.surname} ${T?.firstname} ${T?.third_name||``}`.trim()],[`Admission No`,T?.reg_no],[`Class`,ye],[`Session`,O.session],[`Gender`,T?.sex],[`DOB`,T?.dob],[`Term`,O.term],[`Class Size`,p(O.class_size,`N/A`)],...be?[[`Position`,p(O.position,`N/A`)]]:[],...M.show_attendance?[[`Present`,`${p(O.no_present,`N/A`)} Days`],[`Times Open`,`${p(O.school_open,`N/A`)} Days`]]:[],[`Resumption Date`,O.resumption_date?new Date(O.resumption_date).toLocaleDateString(`en-GB`):`N/A`]].map(([e,t])=>(0,l.jsxs)(`div`,{style:{border:`1px solid ${I}66`,borderLeft:`4px solid ${I}`,borderRadius:9,padding:8,fontSize:11,background:fe(L,82)},children:[(0,l.jsxs)(`strong`,{style:{color:I},children:[e,`:`]}),` `,t]},e))}),(0,l.jsxs)(`div`,{style:V?{display:`contents`}:Te,children:[(0,l.jsxs)(`section`,{style:{minWidth:0,...U(`scores_table`)},children:[(0,l.jsxs)(`table`,{style:{width:`100%`,borderCollapse:`collapse`,fontSize:`11px`,marginTop:12},children:[(0,l.jsx)(`thead`,{children:(0,l.jsxs)(`tr`,{style:{background:I,color:W},children:[(0,l.jsx)(`th`,{style:K,children:`Subject`}),Array.from({length:je}).map((e,t)=>(0,l.jsxs)(`th`,{style:K,children:[`CA (`,Me,`)`]},t)),(0,l.jsx)(`th`,{style:K,children:`Exam (60)`}),(0,l.jsx)(`th`,{style:K,children:`Total`}),w&&He&&(0,l.jsxs)(l.Fragment,{children:[J.map(e=>(0,l.jsx)(`th`,{style:K,children:e},e)),Y&&(0,l.jsx)(`th`,{style:K,children:`Cum Total`}),X&&(0,l.jsx)(`th`,{style:K,children:`Cum Avg`})]}),!Pe&&(0,l.jsx)(`th`,{style:K,children:`First Term`}),!Fe&&(0,l.jsx)(`th`,{style:K,children:`Second Term`}),!Ie&&(0,l.jsx)(`th`,{style:K,children:`Cumm Avg`}),P&&!Le&&(0,l.jsx)(`th`,{style:K,children:`Grade`}),F&&!Re&&(0,l.jsx)(`th`,{style:K,children:`Remark`})]})}),(0,l.jsx)(`tbody`,{children:D.map((e,t)=>{let n=g(e.ca),r=e;return(0,l.jsxs)(`tr`,{style:{background:t%2==0?`rgba(0,0,0,0.02)`:`transparent`},children:[(0,l.jsx)(`td`,{style:q,children:le(e)}),n.map((e,t)=>(0,l.jsx)(`td`,{style:q,children:e},t)),Array(je-n.length).fill(``).map((e,t)=>(0,l.jsx)(`td`,{style:q},`empty-`+t)),(0,l.jsx)(`td`,{style:q,children:e.exam}),(0,l.jsx)(`td`,{style:q,children:e.total}),w&&He&&(0,l.jsxs)(l.Fragment,{children:[J.map(t=>{let n=e;if(!(n.carry_over?.enabled||m(n)))return(0,l.jsx)(`td`,{style:q},t);let r=(h(n.carry_over_json)??n.carry_over)?.terms?.[t];return(0,l.jsx)(`td`,{style:q,children:f(r)?``:r},t)}),Y&&(0,l.jsx)(`td`,{style:q,children:p(e.cumulative_total(h(e.carry_over_json)?.cumulative_total(e).carry_over?.cumulative_total),``)}),X&&(0,l.jsx)(`td`,{style:q,children:p(e.cumulative_average(h(e.carry_over_json)?.cumulative_average(e).carry_over?.cumulative_average),``)})]}),!Pe&&(0,l.jsx)(`td`,{style:q,children:r.firstterm||``}),!Fe&&(0,l.jsx)(`td`,{style:q,children:r.secondterm||``}),!Ie&&(0,l.jsx)(`td`,{style:q,children:r.average||``}),P&&!Le&&(0,l.jsx)(`td`,{style:q,children:e.grade||``}),F&&!Re&&(0,l.jsx)(`td`,{style:q,children:e.remark||``})]},t)})})]}),(0,l.jsxs)(`div`,{style:{display:`flex`,gap:8,flexWrap:`wrap`,marginTop:11},children:[(0,l.jsxs)(`span`,{style:{background:L,border:`1px solid ${I}`,borderRadius:999,padding:`5px 9px`,fontSize:11,fontWeight:900},children:[`Average: `,p(O.total_average,`N/A`),`%`]}),P&&(0,l.jsxs)(`span`,{style:{background:L,border:`1px solid ${I}`,borderRadius:999,padding:`5px 9px`,fontSize:11,fontWeight:900},children:[`Grade: `,p(O.total_grade,`N/A`)]}),(0,l.jsxs)(`span`,{style:{background:L,border:`1px solid ${I}`,borderRadius:999,padding:`5px 9px`,fontSize:11,fontWeight:900},children:[`Status: `,p(O.general_remark,`N/A`)]})]})]}),(0,l.jsxs)(`aside`,{style:V?{display:`contents`}:Ee,children:[M.show_domains&&(0,l.jsxs)(`div`,{style:{...De,...U(`performance_chart`)},children:[(0,l.jsxs)(`div`,{style:{border:`1px solid ${I}`,borderRadius:10,padding:10,background:`rgba(255,255,255,0.62)`},children:[(0,l.jsx)(`h4`,{style:{margin:`0 0 8px`,color:I,fontSize:12,textTransform:`uppercase`,borderLeft:`4px solid ${I}`,paddingLeft:7},children:`Subject Performance`}),ze.map((e,t)=>(0,l.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`120px 1fr 42px`,gap:8,alignItems:`center`,margin:`6px 0`,fontSize:10.5},children:[(0,l.jsx)(`span`,{children:e.name}),(0,l.jsx)(`span`,{style:{height:8,borderRadius:999,background:`rgba(15,23,42,0.08)`,overflow:`hidden`},children:(0,l.jsx)(`span`,{style:{display:`block`,height:`100%`,width:`${e.total}%`,background:oe[t%oe.length],borderRadius:999}})}),(0,l.jsxs)(`b`,{children:[e.total,`%`]})]},e.name))]}),(0,l.jsxs)(`div`,{style:{border:`1px solid ${I}`,borderRadius:10,padding:10,background:`rgba(255,255,255,0.62)`},children:[(0,l.jsx)(`h4`,{style:{margin:`0 0 8px`,color:I,fontSize:12,textTransform:`uppercase`,borderLeft:`4px solid ${I}`,paddingLeft:7},children:`Result Analytics`}),[...Object.entries(Be).filter(([e])=>e!==`N/A`).sort(([e],[t])=>e.localeCompare(t)).map(([e,t])=>[`${e} grades`,t,Math.round(t/Math.max(Q.length,1)*100)]),...M.show_attendance?[[`Attendance`,`${Ve}%`,Ve]]:[]].map(([e,t,n],r)=>(0,l.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`92px 1fr 40px`,gap:8,alignItems:`center`,margin:`6px 0`,fontSize:10.5},children:[(0,l.jsx)(`span`,{children:e}),(0,l.jsx)(`span`,{style:{height:8,borderRadius:999,background:`rgba(15,23,42,0.08)`,overflow:`hidden`},children:(0,l.jsx)(`span`,{style:{display:`block`,height:`100%`,width:`${Math.max(0,Math.min(100,Number(n)||0))}%`,background:se[r%se.length],borderRadius:999}})}),(0,l.jsx)(`b`,{children:t})]},e))]})]}),M.show_domains&&(k.length>0||A.length>0)&&(0,l.jsxs)(`div`,{style:{...Oe,...U(`domains`)},children:[k.length>0&&(0,l.jsx)(`div`,{children:(0,l.jsxs)(`table`,{style:we,children:[(0,l.jsx)(`caption`,{style:{fontWeight:900,color:I,paddingBottom:6,borderBottom:`2px solid ${I}`},children:`Affective Domain`}),(0,l.jsx)(`tbody`,{children:k.map((e,t)=>(0,l.jsxs)(`tr`,{children:[(0,l.jsx)(`td`,{style:q,children:e.domain}),(0,l.jsx)(`td`,{style:q,children:e.rating})]},t))})]})}),A.length>0&&(0,l.jsx)(`div`,{children:(0,l.jsxs)(`table`,{style:we,children:[(0,l.jsx)(`caption`,{style:{fontWeight:900,color:I,paddingBottom:6,borderBottom:`2px solid ${I}`},children:`Psychomotor Skills`}),(0,l.jsx)(`tbody`,{children:A.map((e,t)=>(0,l.jsxs)(`tr`,{children:[(0,l.jsx)(`td`,{style:q,children:e.domain}),(0,l.jsx)(`td`,{style:q,children:e.rating})]},t))})]})})]})]})]}),M.show_remarks&&(0,l.jsxs)(`div`,{style:{...U(`comments`),marginTop:`12px`,border:`1px solid ${I}55`,borderRadius:12,padding:10,background:`rgba(255,255,255,0.62)`,fontSize:11,lineHeight:1.6},children:[(0,l.jsxs)(`p`,{style:{margin:`0 0 5px`},children:[(0,l.jsx)(`strong`,{style:{color:I},children:`Teacher's Remark:`}),` `,p(O.class_teacher_comment,``)]}),(0,l.jsxs)(`p`,{style:{margin:`0 0 8px`},children:[(0,l.jsx)(`strong`,{style:{color:I},children:`Principal/HM Remark:`}),` `,p(O.principal_comment,``)]})]}),(0,l.jsxs)(`div`,{style:{marginTop:`20px`,display:`flex`,justifyContent:`space-between`,alignItems:`center`,borderTop:B?`1px solid ${I}55`:void 0,paddingTop:B?12:void 0,...U(`signature`)},children:[M.show_signature&&(E?.principal_signature||E?.stamp)?(0,l.jsxs)(`div`,{style:{display:`flex`,alignItems:`end`,gap:18},children:[E?.principal_signature?(0,l.jsxs)(`div`,{style:{textAlign:`center`},children:[(0,l.jsx)(`img`,{src:E.principal_signature,alt:`Principal/HM Signature`,style:{width:`120px`,height:`60px`,objectFit:`contain`}}),(0,l.jsx)(`p`,{style:{margin:0,color:I,fontWeight:700},children:`Principal/HM Signature`})]}):null,E?.stamp?(0,l.jsx)(`img`,{src:E.stamp,alt:`School stamp`,style:{width:68,height:68,objectFit:`contain`,transform:`rotate(-8deg)`}}):null]}):(0,l.jsx)(`div`,{}),M.show_qr_code?(0,l.jsxs)(`div`,{style:{textAlign:`center`},children:[(0,l.jsx)(`img`,{src:pe||`/media/result/default-qrcode.svg`,alt:`QR Code`,style:{width:`100px`,height:`100px`}}),(0,l.jsx)(`p`,{style:{margin:0,color:I,fontWeight:700},children:`Verify Result`})]}):null]})]})]})]})})]}):(0,l.jsxs)(`div`,{className:`gq-cr-empty-card`,children:[(0,l.jsx)(`div`,{className:`gq-cr-empty-icon`,children:(0,l.jsx)(`i`,{className:`bi bi-mortarboard-fill`})}),(0,l.jsx)(`h3`,{style:{fontFamily:`'Playfair Display', serif`,fontWeight:800,fontSize:`24px`,color:`#0f172a`,marginBottom:`8px`},children:`Certified Academic Record Verification`}),(0,l.jsx)(`p`,{style:{color:`#64748b`,fontSize:`14px`,maxWidth:`520px`,margin:`0 auto 20px`,lineHeight:1.5},children:`Enter your student admission number and result checking PIN on the left to securely retrieve, view, and print your certified termly report card.`}),(0,l.jsxs)(`div`,{className:`gq-cr-step-grid`,children:[(0,l.jsxs)(`div`,{className:`gq-cr-step-item`,children:[(0,l.jsx)(`div`,{className:`gq-cr-step-num`,children:`Step 01`}),(0,l.jsx)(`div`,{className:`gq-cr-step-title`,children:`Enter Reg Number`}),(0,l.jsx)(`p`,{className:`gq-cr-step-desc`,children:`Type your unique admission identifier assigned by your school.`})]}),(0,l.jsxs)(`div`,{className:`gq-cr-step-item`,children:[(0,l.jsx)(`div`,{className:`gq-cr-step-num`,children:`Step 02`}),(0,l.jsx)(`div`,{className:`gq-cr-step-title`,children:`Enter Result PIN`}),(0,l.jsx)(`p`,{className:`gq-cr-step-desc`,children:`Input your 12-digit termly scratch card PIN obtained from the school.`})]}),(0,l.jsxs)(`div`,{className:`gq-cr-step-item`,children:[(0,l.jsx)(`div`,{className:`gq-cr-step-num`,children:`Step 03`}),(0,l.jsx)(`div`,{className:`gq-cr-step-title`,children:`View & Download`}),(0,l.jsx)(`p`,{className:`gq-cr-step-desc`,children:`Instantly inspect cumulative broadsheet grades and download verified PDF.`})]})]})]})})]}),(0,l.jsx)(`div`,{className:`mt-5`,children:(0,l.jsx)(re,{})})]})]})}export{_ as default};