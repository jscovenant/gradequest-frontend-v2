import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{p as t}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as n,E as r,P as i,d as a,f as o,l as s,u as c}from"./index-D6TxbaCx.js";var l=e(),u=t(),d=(e,t)=>{let n=String(e||t);return/openai|api key|quota|billing|organization|insufficient_quota|provider/i.test(n)?`Something went wrong while processing this AI request. Please try again later.`:n};function f(e){return`NGN ${Number(e||0).toLocaleString(void 0,{minimumFractionDigits:2,maximumFractionDigits:2})}`}function p(e){let t=String(e||`medium`).toLowerCase();return t===`high`?`fee-ai-risk-high`:t===`low`?`fee-ai-risk-low`:`fee-ai-risk-medium`}function m(){let{showError:e,showSuccess:t}=s(),[m,h]=(0,l.useState)(!1),[g,_]=(0,l.useState)(!1),[v,y]=(0,l.useState)(null),[b,x]=(0,l.useState)(null),[S,C]=(0,l.useState)(null),[w,T]=(0,l.useState)([]),[E,D]=(0,l.useState)([]),[O,k]=(0,l.useState)([]),[A,j]=(0,l.useState)([]),[M,N]=(0,l.useState)({session_id:``,term_id:``,class_id:``,section_id:``,limit:10}),P=(0,l.useMemo)(()=>{let e=[w.find(e=>String(e.id)===M.session_id)?.name,E.find(e=>String(e.id)===M.term_id)?.name,O.find(e=>String(e.id)===M.class_id)?.name,A.find(e=>String(e.id)===M.section_id)?.name].filter(Boolean);return e.length?e.join(` • `):`All outstanding fees`},[O,M,A,w,E]),F=async()=>{let[e,t,n,r,a]=await Promise.allSettled([i.get(`/admin/ai/credits`),i.get(`/facademic-sessions`),i.get(`/fterms`),i.get(`/levels`),i.get(`/sections`)]);e.status===`fulfilled`&&x(e.value.data?.data||null),t.status===`fulfilled`&&T(Array.isArray(t.value.data)?t.value.data:t.value.data?.data||[]),n.status===`fulfilled`&&D(Array.isArray(n.value.data)?n.value.data:n.value.data?.data||[]),r.status===`fulfilled`&&k(Array.isArray(r.value.data)?r.value.data:r.value.data?.data||[]),a.status===`fulfilled`&&j(Array.isArray(a.value.data)?a.value.data:a.value.data?.data||[])};(0,l.useEffect)(()=>{F().catch(()=>void 0)},[]);let I=async()=>{_(!0);try{let e=Object.fromEntries(Object.entries(M).filter(([,e])=>e!==``&&e!=null).map(([e,t])=>[e,Number(t)])),n=await i.post(`/admin/ai/fee-collection/analyze`,e);C(n.data?.analysis||null);let r=n.data?.ai_credits;r?.remaining!==null&&r?.remaining!==void 0&&x({remaining_credits:r.remaining,ai_fee_collection_credit_cost:r.charged}),t?.(r?.charged?`Analysis generated. ${r.charged} credit(s) used.`:`Analysis generated.`)}catch(t){e?.(d(t?.response?.data?.message,`Unable to generate fee collection analysis.`))}finally{_(!1)}},L=e=>{let t={parent_id:e};return Object.entries(M).forEach(([e,n])=>{e!==`limit`&&n!==``&&n!=null&&(t[e]=Number(n))}),t},R=async n=>{if(!n.parent_id){e?.(`This reminder cannot be sent because no parent account is linked.`);return}y(n.parent_id);try{let e=(await i.post(`/admin/ai/fee-collection/reminders/send`,L(n.parent_id))).data||{},r=[e.email_queued?`email`:null,e.whatsapp_sent?`WhatsApp`:null].filter(Boolean).join(` and `);t?.(r?`Reminder sent by ${r}.`:e.message||`Reminder request completed.`)}catch(t){e?.(t?.response?.data?.message||`Unable to send reminder to this parent.`)}finally{y(null)}},z=async e=>{await navigator.clipboard.writeText(e),t?.(`Reminder message copied.`)},B=(e,t)=>N(n=>({...n,[e]:t}));return(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');
        .fee-ai-main {
          background: #F8FAFC;
          min-height: 100vh;
          padding: 24px 28px 0;
          overflow-x: hidden;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
        }
        .fee-ai-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          color: #fff;
          border-radius: 18px;
          padding: 32px 36px;
          margin-bottom: 24px;
          position: relative;
          overflow: hidden;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
        }
        .fee-ai-hero-glow {
          position: absolute;
          top: -60px;
          right: -60px;
          width: 320px;
          height: 320px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.15) 0%, transparent 65%);
          pointer-events: none;
        }
        .fee-ai-hero>* { position: relative; z-index: 1; }
        .fee-ai-kicker {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.20);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius: 100px;
          padding: 4px 12px;
          margin-bottom: 12px;
        }
        .fee-ai-title {
          font-weight: 800;
          font-size: 26px;
          margin: 6px 0 8px;
          color: #fff;
        }
        .fee-ai-sub {
          max-width: 800px;
          color: #CBD5E1;
          font-size: 13.5px;
          line-height: 1.6;
          margin: 0;
        }
        .fee-ai-grid {
          display: grid;
          grid-template-columns: 360px 1fr;
          gap: 20px;
          align-items: start;
        }
        .fee-ai-card {
          background: #fff;
          border: 1px solid #E2E8F0;
          border-radius: 16px;
          box-shadow: 0 4px 16px rgba(15, 39, 68, 0.03);
          overflow: hidden;
        }
        .fee-ai-pad { padding: 20px; }
        .fee-ai-card h2 { font-size: 16px; font-weight: 700; color: #0F2744; margin: 0; }
        .fee-ai-muted { font-size: 12.5px; color: #64748B; line-height: 1.5; margin: 4px 0 0; }
        .fee-ai-field { display: flex; flex-direction: column; gap: 6px; margin-top: 14px; }
        .fee-ai-field span { font-size: 12px; font-weight: 700; color: #0F2744; }
        .fee-ai-input {
          border: 1px solid #E2E8F0;
          border-radius: 10px;
          padding: 10px 12px;
          outline: none;
          background: #F8FAFC;
          color: #0F2744;
          font-size: 13px;
          font-weight: 600;
          transition: border-color 0.2s;
        }
        .fee-ai-input:focus { border-color: #D97706; background: #fff; }
        .fee-ai-btn {
          border: 0;
          border-radius: 10px;
          background: #D97706;
          color: #FFFFFF;
          font-weight: 700;
          font-size: 13px;
          padding: 11px 15px;
          width: 100%;
          margin-top: 16px;
          cursor: pointer;
          transition: all 0.2s ease;
        }
        .fee-ai-btn:hover { background: #B45309; transform: translateY(-1px); }
        .fee-ai-btn:disabled { opacity: .65; transform: none; cursor: not-allowed; }
        .fee-ai-credit {
          display: flex;
          justify-content: space-between;
          gap: 10px;
          border: 1px solid #E2E8F0;
          background: #F8FAFC;
          border-radius: 12px;
          padding: 12px 14px;
          margin-top: 14px;
        }
        .fee-ai-credit span { font-size: 12px; color: #64748B; font-weight: 500; }
        .fee-ai-credit strong { font-weight: 700; color: #0F2744; font-size: 13px; }
        .fee-ai-stats {
          display: grid;
          grid-template-columns: repeat(4, minmax(0, 1fr));
          gap: 14px;
          margin-bottom: 18px;
        }
        .fee-ai-stat {
          background: #fff;
          border: 1px solid #E2E8F0;
          border-radius: 14px;
          padding: 18px 20px;
          box-shadow: 0 4px 12px rgba(15,39,68,0.02);
        }
        .fee-ai-stat span { font-size: 11.5px; text-transform: uppercase; letter-spacing: .04em; color: #64748B; font-weight: 700; }
        .fee-ai-stat strong { display: block; font-size: 22px; font-weight: 800; color: #0F2744; margin-top: 6px; }
        .fee-ai-section { border: 1px solid #E2E8F0; border-radius: 12px; padding: 16px; background: #F8FAFC; margin-top: 14px; }
        .fee-ai-section h3 { font-size: 14px; font-weight: 700; color: #0F2744; margin: 0 0 8px; }
        .fee-ai-section p, .fee-ai-section li { font-size: 13px; line-height: 1.7; color: #334155; }
        .fee-ai-risk-card { border: 1px solid #E2E8F0; border-radius: 12px; padding: 14px 16px; background: #F8FAFC; margin-top: 10px; }
        .fee-ai-risk-top { display: flex; justify-content: space-between; gap: 12px; align-items: flex-start; }
        .fee-ai-risk-name { font-weight: 700; color: #0F2744; font-size: 14px; }
        .fee-ai-pill { border-radius: 999px; padding: 4px 10px; font-size: 11px; font-weight: 700; text-transform: uppercase; }
        .fee-ai-risk-high { background: rgba(239, 68, 68, .12); color: #b91c1c; }
        .fee-ai-risk-medium { background: rgba(245, 158, 11, .14); color: #b45309; }
        .fee-ai-risk-low { background: rgba(16, 185, 129, .12); color: #059669; }
        .fee-ai-table { width: 100%; border-collapse: collapse; }
        .fee-ai-table th { font-size: 11.5px; text-transform: uppercase; color: #64748B; letter-spacing: .04em; font-weight: 700; }
        .fee-ai-table th, .fee-ai-table td { padding: 10px 12px; border-bottom: 1px solid #F1F5F9; font-size: 13px; color: #334155; }
        .fee-ai-message { background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 12px; padding: 14px; margin-top: 12px; white-space: pre-wrap; font-size: 13px; line-height: 1.7; color: #334155; }
        .fee-ai-copy { border: 1px solid #E2E8F0; background: #fff; border-radius: 8px; padding: 7px 12px; font-size: 12px; font-weight: 700; color: #0F2744; cursor: pointer; transition: all 0.2s; }
        .fee-ai-copy:hover { background: #E2E8F0; }
        .fee-ai-send { border: 0; background: #D97706; color: #fff; border-radius: 8px; padding: 7px 14px; font-size: 12px; font-weight: 700; cursor: pointer; transition: all 0.2s; }
        .fee-ai-send:hover { background: #B45309; }
        .fee-ai-send:disabled { opacity: .6; cursor: not-allowed; }
        .fee-ai-message-actions { display: flex; gap: 8px; flex-wrap: wrap; justify-content: flex-end; }
        @media(max-width:1199.98px){.fee-ai-grid{grid-template-columns:1fr}.fee-ai-stats{grid-template-columns:repeat(2,minmax(0,1fr))}}
        @media(max-width:767.98px){.fee-ai-main{padding:20px 16px 0}.fee-ai-stats{grid-template-columns:1fr}}
      `}),(0,u.jsx)(o,{sidebarOpen:m,setSidebarOpen:h,title:`AI Fee Collection`}),(0,u.jsx)(`div`,{className:`container-fluid`,children:(0,u.jsxs)(`div`,{className:`row`,children:[(0,u.jsx)(a,{sidebarOpen:m,setSidebarOpen:h}),(0,u.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto db-main fee-ai-main`,children:[(0,u.jsx)(n,{title:`AI Fee Collection Assistant`}),g&&(0,u.jsx)(r,{message:`Analyzing outstanding fees...`}),(0,u.jsxs)(`section`,{className:`fee-ai-hero`,children:[(0,u.jsx)(`div`,{className:`fee-ai-hero-glow`}),(0,u.jsx)(`div`,{className:`fee-ai-kicker`,children:`SchoolProfit AI finance tools`}),(0,u.jsx)(`h1`,{className:`fee-ai-title`,children:`AI Fee Collection Assistant`}),(0,u.jsx)(`p`,{className:`fee-ai-sub`,children:`Identify parents with the highest outstanding balances, summarize debts by class, term, parent, or student, and generate polite reminder drafts.`})]}),(0,u.jsxs)(`div`,{className:`fee-ai-grid`,children:[(0,u.jsx)(`section`,{className:`fee-ai-card`,children:(0,u.jsxs)(`div`,{className:`fee-ai-pad`,children:[(0,u.jsx)(`h2`,{children:`Analysis filters`}),(0,u.jsx)(`p`,{className:`fee-ai-muted`,children:`Leave filters empty to analyze all unpaid fee records.`}),(0,u.jsxs)(`label`,{className:`fee-ai-field`,children:[(0,u.jsx)(`span`,{children:`Academic session`}),(0,u.jsxs)(`select`,{className:`fee-ai-input`,value:M.session_id,onChange:e=>B(`session_id`,e.target.value),children:[(0,u.jsx)(`option`,{value:``,children:`All sessions`}),w.map(e=>(0,u.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]}),(0,u.jsxs)(`label`,{className:`fee-ai-field`,children:[(0,u.jsx)(`span`,{children:`Term`}),(0,u.jsxs)(`select`,{className:`fee-ai-input`,value:M.term_id,onChange:e=>B(`term_id`,e.target.value),children:[(0,u.jsx)(`option`,{value:``,children:`All terms`}),E.map(e=>(0,u.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]}),(0,u.jsxs)(`label`,{className:`fee-ai-field`,children:[(0,u.jsx)(`span`,{children:`Class`}),(0,u.jsxs)(`select`,{className:`fee-ai-input`,value:M.class_id,onChange:e=>B(`class_id`,e.target.value),children:[(0,u.jsx)(`option`,{value:``,children:`All classes`}),O.map(e=>(0,u.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]}),(0,u.jsxs)(`label`,{className:`fee-ai-field`,children:[(0,u.jsx)(`span`,{children:`Section`}),(0,u.jsxs)(`select`,{className:`fee-ai-input`,value:M.section_id,onChange:e=>B(`section_id`,e.target.value),children:[(0,u.jsx)(`option`,{value:``,children:`All sections`}),A.map(e=>(0,u.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]}),(0,u.jsxs)(`label`,{className:`fee-ai-field`,children:[(0,u.jsx)(`span`,{children:`Parents to review`}),(0,u.jsx)(`input`,{className:`fee-ai-input`,type:`number`,min:3,max:25,value:M.limit,onChange:e=>B(`limit`,Number(e.target.value))})]}),(0,u.jsxs)(`div`,{className:`fee-ai-credit`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`span`,{children:`Cost per analysis`}),(0,u.jsxs)(`strong`,{children:[b?.ai_fee_collection_credit_cost??2,` credit(s)`]})]}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`span`,{children:b?.user_allocation?`Your Quota`:`Remaining`}),(0,u.jsx)(`strong`,{children:b?.user_allocation?b.user_allocation.is_unlimited?`Unlimited`:`${b.user_allocation.remaining_credits} credits`:`${b?.remaining_credits??`-`} credits`})]})]}),b&&b.is_plus_active===!1&&(0,u.jsxs)(`div`,{className:`alert alert-warning py-2 px-3 mt-3 mb-0`,style:{fontSize:`12px`,borderRadius:`10px`},children:[(0,u.jsx)(`i`,{className:`bi bi-exclamation-triangle me-1`}),(0,u.jsx)(`strong`,{children:`SchoolProfit Plus Required:`}),` AI Fee Assistant requires an active SchoolProfit Plus subscription.`]}),(0,u.jsx)(`button`,{className:`fee-ai-btn`,disabled:g||b&&b.is_plus_active===!1,onClick:I,children:g?`Analyzing...`:`Generate Fee Analysis`})]})}),(0,u.jsx)(`section`,{children:S?(0,u.jsxs)(u.Fragment,{children:[(0,u.jsxs)(`div`,{className:`fee-ai-stats`,children:[(0,u.jsxs)(`div`,{className:`fee-ai-stat`,children:[(0,u.jsx)(`span`,{children:`Total outstanding`}),(0,u.jsx)(`strong`,{children:f(S.summary.total_balance)})]}),(0,u.jsxs)(`div`,{className:`fee-ai-stat`,children:[(0,u.jsx)(`span`,{children:`Owing parents`}),(0,u.jsx)(`strong`,{children:S.summary.owing_parents})]}),(0,u.jsxs)(`div`,{className:`fee-ai-stat`,children:[(0,u.jsx)(`span`,{children:`Owing students`}),(0,u.jsx)(`strong`,{children:S.summary.owing_students})]}),(0,u.jsxs)(`div`,{className:`fee-ai-stat`,children:[(0,u.jsx)(`span`,{children:`High risk`}),(0,u.jsx)(`strong`,{children:S.summary.high_risk_parents})]})]}),(0,u.jsx)(`section`,{className:`fee-ai-card`,children:(0,u.jsxs)(`div`,{className:`fee-ai-pad`,children:[(0,u.jsx)(`h2`,{children:`Collection summary`}),(0,u.jsx)(`p`,{className:`fee-ai-muted`,children:P}),(0,u.jsxs)(`div`,{className:`fee-ai-section`,children:[(0,u.jsx)(`h3`,{children:`Executive summary`}),(0,u.jsx)(`p`,{children:S.executive_summary})]}),(0,u.jsxs)(`div`,{className:`fee-ai-section`,children:[(0,u.jsx)(`h3`,{children:`Recommended actions`}),(0,u.jsx)(`ol`,{children:S.collection_priorities.map((e,t)=>(0,u.jsx)(`li`,{children:e},t))})]}),S.risk_notes.length>0&&(0,u.jsxs)(`div`,{className:`fee-ai-section`,children:[(0,u.jsx)(`h3`,{children:`Risk notes`}),(0,u.jsx)(`ol`,{children:S.risk_notes.map((e,t)=>(0,u.jsx)(`li`,{children:e},t))})]})]})}),(0,u.jsx)(`section`,{className:`fee-ai-card mt-3`,children:(0,u.jsxs)(`div`,{className:`fee-ai-pad`,children:[(0,u.jsx)(`h2`,{children:`Parents most likely to owe`}),(0,u.jsx)(`p`,{className:`fee-ai-muted`,children:`Ranked by balance, unpaid records, partial payment pattern, and contact availability.`}),S.at_risk_parents.map(e=>(0,u.jsxs)(`div`,{className:`fee-ai-risk-card`,children:[(0,u.jsxs)(`div`,{className:`fee-ai-risk-top`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`fee-ai-risk-name`,children:e.parent_name}),(0,u.jsxs)(`div`,{className:`fee-ai-muted`,children:[e.children_count,` child(ren) • `,e.fee_items_count,` fee item(s) • `,e.phone||`No phone`]})]}),(0,u.jsxs)(`span`,{className:`fee-ai-pill ${p(e.risk_level)}`,children:[e.risk_level,` • `,e.risk_score]})]}),(0,u.jsx)(`div`,{className:`mt-2 fw-bold`,children:f(e.balance)}),e.students.map(t=>(0,u.jsxs)(`div`,{className:`fee-ai-muted`,children:[t.student_name,` `,t.reg_no?`(${t.reg_no})`:``,` - `,t.class_name||`Class not set`,`: `,f(t.balance)]},`${e.parent_id}-${t.reg_no}`))]},`${e.parent_id}-${e.parent_name}`))]})}),(0,u.jsx)(`section`,{className:`fee-ai-card mt-3`,children:(0,u.jsxs)(`div`,{className:`fee-ai-pad`,children:[(0,u.jsx)(`h2`,{children:`Reminder drafts`}),(0,u.jsx)(`p`,{className:`fee-ai-muted`,children:`Review the message, then send it directly to the parent by email and WhatsApp where contact details are available.`}),S.parent_messages.length?S.parent_messages.map((e,t)=>(0,u.jsxs)(`div`,{className:`fee-ai-message`,children:[(0,u.jsxs)(`div`,{className:`d-flex justify-content-between gap-2 align-items-start mb-2`,children:[(0,u.jsx)(`strong`,{children:e.parent_name}),(0,u.jsxs)(`div`,{className:`fee-ai-message-actions`,children:[(0,u.jsx)(`button`,{className:`fee-ai-copy`,onClick:()=>z(e.message),children:`Copy`}),(0,u.jsx)(`button`,{className:`fee-ai-send`,disabled:!e.parent_id||v===e.parent_id,onClick:()=>R(e),children:v===e.parent_id?`Sending...`:`Send Email + WhatsApp`})]})]}),e.message]},`${e.parent_id}-${t}`)):(0,u.jsx)(`p`,{className:`fee-ai-muted mt-3`,children:`No reminder message needed for this selection.`})]})}),(0,u.jsx)(`section`,{className:`fee-ai-card mt-3`,children:(0,u.jsxs)(`div`,{className:`fee-ai-pad`,children:[(0,u.jsx)(`h2`,{children:`Debt breakdown`}),(0,u.jsx)(`div`,{className:`table-responsive`,children:(0,u.jsxs)(`table`,{className:`fee-ai-table`,children:[(0,u.jsx)(`thead`,{children:(0,u.jsxs)(`tr`,{children:[(0,u.jsx)(`th`,{children:`Class`}),(0,u.jsx)(`th`,{children:`Records`}),(0,u.jsx)(`th`,{className:`text-end`,children:`Balance`})]})}),(0,u.jsx)(`tbody`,{children:S.breakdowns.by_class.map(e=>(0,u.jsxs)(`tr`,{children:[(0,u.jsx)(`td`,{children:e.label}),(0,u.jsx)(`td`,{children:e.count}),(0,u.jsx)(`td`,{className:`text-end fw-bold`,children:f(e.balance)})]},e.label))})]})}),(0,u.jsx)(`div`,{className:`table-responsive mt-3`,children:(0,u.jsxs)(`table`,{className:`fee-ai-table`,children:[(0,u.jsx)(`thead`,{children:(0,u.jsxs)(`tr`,{children:[(0,u.jsx)(`th`,{children:`Term`}),(0,u.jsx)(`th`,{children:`Records`}),(0,u.jsx)(`th`,{className:`text-end`,children:`Balance`})]})}),(0,u.jsx)(`tbody`,{children:S.breakdowns.by_term.map(e=>(0,u.jsxs)(`tr`,{children:[(0,u.jsx)(`td`,{children:e.label}),(0,u.jsx)(`td`,{children:e.count}),(0,u.jsx)(`td`,{className:`text-end fw-bold`,children:f(e.balance)})]},e.label))})]})})]})})]}):(0,u.jsx)(`section`,{className:`fee-ai-card`,children:(0,u.jsxs)(`div`,{className:`fee-ai-pad`,children:[(0,u.jsx)(`h2`,{children:`No analysis yet`}),(0,u.jsx)(`p`,{className:`fee-ai-muted`,children:`Choose a period or class, then generate the analysis. The system uses your fee records; balances are not guessed.`})]})})})]}),(0,u.jsx)(c,{})]})]})})]})}export{m as default};