import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{p as t}from"./vendor-react-BhRGw7qi.js";import{r as n}from"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as r,E as i,P as a,d as o,f as s,l as c,u as l}from"./index-D6TxbaCx.js";var u=e(),d=t();function f(){let e=new Date().getHours();return e<12?`Good morning`:e<17?`Good afternoon`:`Good evening`}function p(e){let t=e?.response?.status,n=e?.response?.data;return t===422?n?.message??`Validation error.`:t===404?n?.message??`Not found.`:t===403?n?.message??`Forbidden.`:n?.message??e?.message??`Something went wrong.`}function m(e){return`${e?.firstname??``} ${e?.surname??``}`.trim()||`—`}function h(e){let t=(e||``).toLowerCase();return t===`approved`?`db-pill db-pill--green`:t===`rejected`?`db-pill db-pill--red`:`db-pill db-pill--gold`}function g(){return String(a.defaults.baseURL||``).replace(/\/+$/,``).replace(/\/api\/-$/,``)}function _(e){if(!e)return``;if(/^https?:\/\//i.test(e))return e;let t=e.trim();t=t.replace(/^\/+/,``),t=t.replace(/^fees\/receipts\/+/i,``);let n=t.toLowerCase().indexOf(`uploads/receipts/`);return n>0&&(t=t.slice(n)),`${g()}/${t}`.replace(/([^:]\/)\/+/g,`$1`)}function v(e){return e.split(`-`)[0].toLowerCase().endsWith(`.pdf`)}function y(e){let t=e.split(`-`)[0].toLowerCase();return t.endsWith(`.png`)||t.endsWith(`.jpg`)||t.endsWith(`.jpeg`)||t.endsWith(`.webp`)}async function b(e){return new Promise((t,n)=>{let r=new FileReader;r.onload=()=>t(String(r.result)),r.onerror=n,r.readAsDataURL(e)})}function x(){let{showSuccess:e,showError:t,showWarning:g}=c(),[x,S]=(0,u.useState)(!1),[C,w]=(0,u.useState)(!0),[T,E]=(0,u.useState)(!1),[D,O]=(0,u.useState)([]),[k,A]=(0,u.useState)(``),[j,M]=(0,u.useState)(``),[N,P]=(0,u.useState)(null),F=e=>N===e,[I,L]=(0,u.useState)(!1),[R,z]=(0,u.useState)(null),[B,V]=(0,u.useState)(`pending`),[H,U]=(0,u.useState)(``);(0,u.useEffect)(()=>{let e=window.setTimeout(()=>w(!1),120);return()=>window.clearTimeout(e)},[]);async function W(){try{E(!0);let e=await a.get(`/receipts`);O(Array.isArray(e.data)?e.data:[])}catch(e){console.error(e),t(p(e)),O([])}finally{E(!1)}}(0,u.useEffect)(()=>{W()},[]);let G=(0,u.useMemo)(()=>({total:D.length,pending:D.filter(e=>(e.status||``).toLowerCase()===`pending`).length,approved:D.filter(e=>(e.status||``).toLowerCase()===`approved`).length,rejected:D.filter(e=>(e.status||``).toLowerCase()===`rejected`).length}),[D]),K=(0,u.useMemo)(()=>{let e=k.trim().toLowerCase();return D.filter(t=>{let n=(t.status||``).toLowerCase();return j&&n!==j?!1:e?[m(t.student),t.student?.reg_no??``,t.payment_method??``,t.status??``,String(t.amount??t.amount_paid??``)].join(` `).toLowerCase().trim().includes(e):!0})},[D,k,j]);function q(e){z(e),V((e.status||`pending`).toLowerCase()||`pending`),U(e.notes??``),L(!0)}async function J(e){let r=_(e);if(r)try{if(P(`receipt:open:${e}`),v(r)){window.open(r,`_blank`,`noopener,noreferrer`);return}if(y(r))try{let e=await fetch(r,{credentials:`include`});if(!e.ok)throw Error(`Failed to fetch image (${e.status})`);let t=await b(await e.blob()),i=new n({orientation:`portrait`,unit:`pt`,format:`a4`}),a=i.internal.pageSize.getWidth(),o=i.internal.pageSize.getHeight(),s=new Image;await new Promise((e,n)=>{s.onload=()=>e(),s.onerror=n,s.src=t});let c=a-48,l=o-48,u=Math.min(c/s.width,l/s.height),d=s.width*u,f=s.height*u,p=(a-d)/2,m=(o-f)/2,h=t.startsWith(`data:image/png`)?`PNG`:`JPEG`;i.addImage(t,h,p,m,d,f);let g=i.output(`blob`),_=URL.createObjectURL(g);window.open(_,`_blank`,`noopener,noreferrer`),setTimeout(()=>URL.revokeObjectURL(_),6e4);return}catch(e){console.warn(`Image fetch blocked (likely CORS). Falling back to direct open.`,e),window.open(r,`_blank`,`noopener,noreferrer`);return}window.open(r,`_blank`,`noopener,noreferrer`)}catch(e){console.error(e),t(e?.response?.data?.message||e?.message||`Failed to open receipt.`)}finally{P(null)}}async function Y(){if(R)try{P(`receipt:update:${R.payment_id}`);let t=await a.put(`/payment-status/${R.payment_id}`,{status:B,notes:H.trim()||null});e(t.data?.message??`Receipt status updated.`),O(e=>e.map(e=>e.payment_id===R.payment_id?{...e,status:t.data?.data?.status??B,notes:t.data?.data?.notes??H,receipts:t.data?.data?.receipts??e.receipts}:e)),L(!1),z(null),U(``)}catch(e){console.error(e),t(p(e))}finally{P(null)}}return(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(`style`,{children:`
    /* ======= ReceiptApprovalPage - Modern SaaS style ======= */
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');
    .db-main {
      background: #F8FAFC;
      min-height: 100vh;
      font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
      padding: 24px 28px 0;
    }

    .db-hero {
      background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
      border-radius: 18px;
      padding: 32px 36px;
      position: relative;
      overflow: hidden;
      margin-bottom: 24px;
      box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
    }
    .db-hero-glow {
      position: absolute;
      top: -60px;
      right: -60px;
      width: 320px;
      height: 320px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(217, 119, 6, 0.15) 0%, transparent 65%);
      pointer-events: none;
    }
    .db-hero-glow2 {
      position: absolute;
      bottom: -40px;
      left: 30%;
      width: 200px;
      height: 200px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(37, 99, 235, 0.10) 0%, transparent 70%);
      pointer-events: none;
    }
    .db-hero-inner {
      position: relative;
      z-index: 1;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 32px;
      flex-wrap: wrap;
    }

    .db-session-badge {
      display: inline-flex;
      align-items: center;
      gap: 7px;
      font-size: 11.5px;
      font-weight: 700;
      letter-spacing: 0.04em;
      text-transform: uppercase;
      color: #FBBF24;
      background: rgba(217, 119, 6, 0.20);
      border: 1px solid rgba(217, 119, 6, 0.35);
      border-radius: 100px;
      padding: 4px 12px;
      margin-bottom: 12px;
    }
    .db-session-dot {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: #10B981;
      animation: dbPulse 2s ease infinite;
    }
    @keyframes dbPulse {
      0%,100% { opacity: 1; transform: scale(1); }
      50% { opacity: 0.4; transform: scale(1.5); }
    }

    .db-greeting {
      font-size: 26px;
      font-weight: 800;
      color: #fff;
      line-height: 1.1;
      margin-bottom: 8px;
    }
    .db-greeting em { font-style: normal; color: #FBBF24; }

    .db-hero-sub {
      font-size: 13.5px;
      color: #CBD5E1;
      line-height: 1.6;
      max-width: 620px;
      margin-bottom: 20px;
    }

    .db-hero-btns { display: flex; gap: 10px; flex-wrap: wrap; }

    .db-btn-gold {
      display: inline-flex;
      align-items: center;
      gap: 7px;
      padding: 9px 18px;
      font-size: 13px;
      font-weight: 700;
      color: #FFFFFF;
      background: #D97706;
      border: none;
      border-radius: 10px;
      cursor: pointer;
      transition: all 0.2s ease;
      text-decoration: none;
      white-space: nowrap;
    }
    .db-btn-gold:hover { background: #B45309; transform: translateY(-1px); color: #FFFFFF; }
    .db-btn-gold:disabled { opacity: 0.55; cursor: not-allowed; transform: none; }

    .db-btn-outline {
      display: inline-flex;
      align-items: center;
      gap: 7px;
      padding: 9px 18px;
      font-size: 13px;
      font-weight: 600;
      color: #FFFFFF;
      background: rgba(255, 255, 255, 0.10);
      border: 1px solid rgba(255, 255, 255, 0.20);
      border-radius: 10px;
      cursor: pointer;
      transition: all 0.2s ease;
      white-space: nowrap;
    }
    .db-btn-outline:hover { background: rgba(255, 255, 255, 0.18); color: #fff; }
    .db-btn-outline:disabled { opacity: 0.55; cursor: not-allowed; }

    .db-hero-stat-card {
      background: rgba(255, 255, 255, 0.08);
      border: 1px solid rgba(255, 255, 255, 0.15);
      backdrop-filter: blur(8px);
      border-radius: 14px;
      padding: 20px 24px;
      min-width: 320px;
    }
    .db-hero-stat-row { display: flex; flex-direction: column; gap: 10px; }
    .db-hero-stat-item { display: flex; justify-content: space-between; align-items: center; gap: 16px; }
    .db-hero-stat-label { font-size: 12px; font-weight: 400; color: #CBD5E1; }
    .db-hero-stat-val { font-size: 18px; font-weight: 800; color: #FBBF24; }
    .db-hero-stat-sep { height: 1px; background: rgba(255, 255, 255, 0.06); }

    .db-panel {
      background: var(--bs-body-bg, #fff);
      border: 1px solid var(--bs-border-color, #ede8e0);
      border-radius: var(--bs-border-radius-lg, 14px);
      overflow: hidden;
    }
    .db-panel-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 18px 20px;
      border-bottom: 1px solid rgba(0, 0, 0, 0.06);
      gap: 12px;
      flex-wrap: wrap;
    }
    .db-panel-title-group { display: flex; align-items: center; gap: 12px; min-width: 240px; }
    .db-panel-icon {
      width: 36px;
      height: 36px;
      border-radius: 9px;
      display: flex;
      align-items: center;
      justify-content: center;
      background: var(--pi, #fef3c7);
      color: var(--pc, #b45309);
      flex-shrink: 0;
    }
    .db-panel-title {
      font-family: "Lora", serif;
      font-size: 16px;
      font-weight: 700;
      color: #1a1a2e;
      margin: 0;
    }
    .db-panel-sub { font-size: 11.5px; font-weight: 300; color: #9a8a7a; margin: 0; }

    .db-table { width: 100%; border-collapse: collapse; }
    .db-table th {
      padding: 10px 16px;
      font-size: 11px;
      font-weight: 500;
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: #9a8a7a;
      background: #faf8f5;
      border-bottom: 1px solid rgba(0, 0, 0, 0.06);
      text-align: left;
      white-space: nowrap;
    }
    .db-table td {
      padding: 13px 16px;
      font-size: 13.5px;
      color: #4a4a5a;
      border-bottom: 1px solid rgba(0, 0, 0, 0.06);
      vertical-align: middle;
    }
    .db-table tbody tr { transition: background 0.15s; }
    .db-table tbody tr:hover { background: #faf8f5; }

    .db-skeleton {
      height: 14px;
      border-radius: 7px;
      background: linear-gradient(90deg, #f0ebe3 25%, #e8e0d5 50%, #f0ebe3 75%);
      background-size: 200% 100%;
      animation: dbSkeleton 1.4s ease infinite;
    }
    @keyframes dbSkeleton {
      from { background-position: 200% 0; }
      to { background-position: -200% 0; }
    }

    .db-pill {
      display: inline-flex;
      align-items: center;
      font-size: 12px;
      font-weight: 600;
      padding: 3px 10px;
      border-radius: 999px;
      background: rgba(30, 64, 175, 0.08);
      color: #1e40af;
      border: 1px solid rgba(30, 64, 175, 0.12);
      white-space: nowrap;
    }
    .db-pill--gold {
      background: rgba(180, 83, 9, 0.08);
      color: #b45309;
      border-color: rgba(180, 83, 9, 0.14);
    }
    .db-pill--violet {
      background: rgba(124, 58, 237, 0.08);
      color: #7c3aed;
      border-color: rgba(124, 58, 237, 0.12);
    }
    .db-pill--green {
      background: rgba(6, 95, 70, 0.08);
      color: #065f46;
      border-color: rgba(6, 95, 70, 0.12);
    }
    .db-pill--red {
      background: rgba(220, 38, 38, 0.08);
      color: #b91c1c;
      border-color: rgba(220, 38, 38, 0.14);
    }

    .db-refresh-btn {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 7px 14px;
      font-size: 12px;
      font-weight: 500;
      color: #7a6a5a;
      background: #f5f1eb;
      border: 1px solid #e5ddd3;
      border-radius: var(--bs-border-radius, 9px);
      cursor: pointer;
      transition: background 0.2s;
      white-space: nowrap;
    }
    .db-refresh-btn:hover { background: #ede8e0; }
    .db-refresh-btn:disabled { opacity: 0.5; cursor: not-allowed; }

    .db-grid2 { display: grid; grid-template-columns: 1fr 420px; gap: 18px; margin-bottom: 22px; }
    @media (max-width: 991.98px) {
      .db-grid2 { grid-template-columns: 1fr; }
      .db-main { padding: 18px 14px 0; }
      .db-hero { padding: 24px 20px; }
      .db-hero-stat-card { min-width: 0; width: 100%; }
    }
    @keyframes dbSpin { to { transform: rotate(360deg); } }
  `}),(0,d.jsx)(s,{sidebarOpen:x,setSidebarOpen:S}),(0,d.jsx)(r,{title:`Approve Receipt`}),(0,d.jsx)(`div`,{className:`container-fluid`,children:(0,d.jsxs)(`div`,{className:`row`,children:[(0,d.jsx)(o,{sidebarOpen:x}),(0,d.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto db-main`,children:[C&&(0,d.jsx)(i,{message:`Loading receipts...`}),(0,d.jsxs)(`div`,{className:`db-hero`,children:[(0,d.jsx)(`div`,{className:`db-hero-glow`,"aria-hidden":`true`}),(0,d.jsx)(`div`,{className:`db-hero-glow2`,"aria-hidden":`true`}),(0,d.jsxs)(`div`,{className:`db-hero-inner`,children:[(0,d.jsxs)(`div`,{children:[(0,d.jsxs)(`div`,{className:`db-session-badge`,children:[(0,d.jsx)(`span`,{className:`db-session-dot`}),`Fees • Receipt Review`]}),(0,d.jsxs)(`h1`,{className:`db-greeting`,children:[f(),`, `,(0,d.jsx)(`em`,{children:`Admin.`})]}),(0,d.jsxs)(`p`,{className:`db-hero-sub`,children:[`Review uploaded payment receipts, then set status to `,(0,d.jsx)(`b`,{children:`Approved`}),` or `,(0,d.jsx)(`b`,{children:`Rejected`}),`. This decision can control whether fee payments can be processed.`]}),(0,d.jsxs)(`div`,{className:`db-hero-btns`,children:[(0,d.jsxs)(`button`,{className:`db-btn-gold`,onClick:W,disabled:N!==null||T,title:N?`Busy...`:``,children:[(0,d.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,children:[(0,d.jsx)(`path`,{d:`M12 7A5 5 0 112 7`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,d.jsx)(`path`,{d:`M12 3v4h-4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`})]}),T?`Refreshing...`:`Refresh receipts`]}),(0,d.jsxs)(`button`,{className:`db-btn-outline`,onClick:()=>{A(``),M(``),g(`Filters cleared.`)},disabled:!k&&!j,children:[(0,d.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,d.jsx)(`path`,{d:`M3 3l10 10`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`}),(0,d.jsx)(`path`,{d:`M13 3L3 13`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})]}),`Clear filters`]})]})]}),(0,d.jsxs)(`div`,{className:`db-hero-stat-card d-none d-md-block`,children:[(0,d.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,marginBottom:16},children:[(0,d.jsx)(`span`,{style:{fontSize:11,fontWeight:500,letterSpacing:`0.14em`,textTransform:`uppercase`,color:`#c9a84c`},children:`Quick glance`}),(0,d.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:(0,d.jsx)(`path`,{d:`M2 10V6M5 10V4M8 10V7M11 10V3`,stroke:`#64748b`,strokeWidth:`1.5`,strokeLinecap:`round`})})]}),(0,d.jsxs)(`div`,{className:`db-hero-stat-row`,children:[(0,d.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,d.jsx)(`span`,{className:`db-hero-stat-label`,children:`Total`}),(0,d.jsx)(`span`,{className:`db-hero-stat-val`,children:G.total})]}),(0,d.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,d.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,d.jsx)(`span`,{className:`db-hero-stat-label`,children:`Pending`}),(0,d.jsx)(`span`,{className:`db-hero-stat-val`,children:G.pending})]}),(0,d.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,d.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,d.jsx)(`span`,{className:`db-hero-stat-label`,children:`Approved`}),(0,d.jsx)(`span`,{className:`db-hero-stat-val`,children:G.approved})]}),(0,d.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,d.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,d.jsx)(`span`,{className:`db-hero-stat-label`,children:`Rejected`}),(0,d.jsx)(`span`,{className:`db-hero-stat-val`,children:G.rejected})]})]})]})]})]}),(0,d.jsxs)(`div`,{className:`db-grid2`,children:[(0,d.jsxs)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:18},children:[(0,d.jsxs)(`div`,{className:`db-panel`,children:[(0,d.jsxs)(`div`,{className:`db-panel-head`,children:[(0,d.jsxs)(`div`,{className:`db-panel-title-group`,children:[(0,d.jsx)(`div`,{className:`db-panel-icon`,style:{"--pi":`#dbeafe`,"--pc":`#1e40af`},children:(0,d.jsx)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:(0,d.jsx)(`path`,{d:`M2.5 3.5h11M4.5 7.5h7M6.5 11.5h3`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`})})}),(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`p`,{className:`db-panel-title`,children:`Filters`}),(0,d.jsx)(`p`,{className:`db-panel-sub`,children:`Search by student name, reg no, method, or receipt id`})]})]}),(0,d.jsxs)(`button`,{className:`db-refresh-btn`,onClick:W,disabled:N!==null||T,children:[(0,d.jsxs)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,style:{animation:T?`dbSpin 0.8s linear infinite`:`none`},children:[(0,d.jsx)(`path`,{d:`M12 7A5 5 0 112 7`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,d.jsx)(`path`,{d:`M12 3v4h-4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`})]}),`Refresh`]})]}),(0,d.jsxs)(`div`,{style:{padding:18},children:[(0,d.jsxs)(`div`,{className:`row g-3`,children:[(0,d.jsxs)(`div`,{className:`col-12 col-lg-4`,children:[(0,d.jsx)(`label`,{className:`form-label fw-semibold small mb-1`,children:`Status`}),(0,d.jsxs)(`select`,{className:`form-select`,value:j,onChange:e=>M(e.target.value),disabled:N!==null,children:[(0,d.jsx)(`option`,{value:``,children:`All status`}),(0,d.jsx)(`option`,{value:`pending`,children:`Pending`}),(0,d.jsx)(`option`,{value:`approved`,children:`Approved`}),(0,d.jsx)(`option`,{value:`rejected`,children:`Rejected`})]})]}),(0,d.jsxs)(`div`,{className:`col-12 col-lg-8`,children:[(0,d.jsx)(`label`,{className:`form-label fw-semibold small mb-1`,children:`Search`}),(0,d.jsx)(`input`,{className:`form-control`,placeholder:`e.g. John Doe • GQ/2026/012 • bank transfer • 102`,value:k,onChange:e=>A(e.target.value),disabled:N!==null})]})]}),(0,d.jsx)(`div`,{style:{marginTop:12,display:`flex`,gap:10,flexWrap:`wrap`,justifyContent:`flex-end`},children:(0,d.jsx)(`button`,{className:`db-refresh-btn`,onClick:()=>{A(``),M(``),g(`Filters cleared.`)},disabled:!k&&!j,children:`Clear`})})]})]}),(0,d.jsxs)(`div`,{className:`db-panel`,children:[(0,d.jsxs)(`div`,{className:`db-panel-head`,children:[(0,d.jsxs)(`div`,{className:`db-panel-title-group`,children:[(0,d.jsx)(`div`,{className:`db-panel-icon`,style:{"--pi":`#fef3c7`,"--pc":`#b45309`},children:(0,d.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,d.jsx)(`path`,{d:`M4 2h8v12H4z`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinejoin:`round`}),(0,d.jsx)(`path`,{d:`M6 5h4M6 8h4M6 11h3`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`})]})}),(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`p`,{className:`db-panel-title`,children:`Receipts`}),(0,d.jsx)(`p`,{className:`db-panel-sub`,children:`Open files, then approve/reject in the review modal`})]})]}),(0,d.jsxs)(`span`,{className:`db-pill db-pill--violet`,children:[`Showing `,K.length,`/`,D.length]})]}),(0,d.jsx)(`div`,{style:{overflowX:`auto`},children:(0,d.jsxs)(`table`,{className:`db-table`,children:[(0,d.jsx)(`thead`,{children:(0,d.jsxs)(`tr`,{children:[(0,d.jsx)(`th`,{style:{width:60},children:`#`}),(0,d.jsx)(`th`,{children:`Student`}),(0,d.jsx)(`th`,{style:{width:160},children:`Reg No`}),(0,d.jsx)(`th`,{style:{width:170},children:`Method`}),(0,d.jsx)(`th`,{style:{width:140},children:`Status`}),(0,d.jsx)(`th`,{style:{width:110},children:`Files`}),(0,d.jsx)(`th`,{style:{width:150,textAlign:`right`},children:`Action`})]})}),(0,d.jsx)(`tbody`,{children:T?(0,d.jsx)(`tr`,{children:(0,d.jsxs)(`td`,{colSpan:7,style:{padding:18},children:[(0,d.jsx)(`div`,{className:`db-skeleton`,style:{width:`60%`,marginBottom:10}}),(0,d.jsx)(`div`,{className:`db-skeleton`,style:{width:`92%`,marginBottom:10}}),(0,d.jsx)(`div`,{className:`db-skeleton`,style:{width:`75%`}})]})}):K.length===0?(0,d.jsx)(`tr`,{children:(0,d.jsx)(`td`,{colSpan:7,style:{padding:18,textAlign:`center`,color:`#9a8a7a`},children:`No receipts found. Try adjusting your filters.`})}):K.map((e,t)=>(0,d.jsxs)(`tr`,{children:[(0,d.jsx)(`td`,{children:t+1}),(0,d.jsxs)(`td`,{children:[(0,d.jsx)(`div`,{style:{fontWeight:700,color:`#1a1a2e`},children:m(e.student)}),(0,d.jsxs)(`div`,{style:{fontSize:12,color:`#9a8a7a`},children:[`Receipt ID: `,e.payment_id]})]}),(0,d.jsx)(`td`,{style:{color:`#6b7280`},children:e.student?.reg_no??`-`}),(0,d.jsx)(`td`,{children:(0,d.jsx)(`span`,{className:`db-pill`,children:e.payment_method||`-`})}),(0,d.jsx)(`td`,{children:(0,d.jsx)(`span`,{className:h(e.status),children:(e.status||`pending`).toUpperCase()})}),(0,d.jsx)(`td`,{children:(0,d.jsx)(`span`,{className:`db-pill db-pill--violet`,children:Array.isArray(e.receipts)?e.receipts.length:0})}),(0,d.jsx)(`td`,{style:{textAlign:`right`},children:(0,d.jsx)(`button`,{className:`db-refresh-btn`,onClick:()=>q(e),disabled:N!==null,children:`Review`})})]},e.payment_id))})]})}),(0,d.jsxs)(`div`,{style:{padding:14,borderTop:`1px solid rgba(0,0,0,0.06)`,display:`flex`,justifyContent:`space-between`,gap:12,flexWrap:`wrap`},children:[(0,d.jsxs)(`div`,{style:{fontSize:12,color:`#9a8a7a`},children:[`Tip: keep `,(0,d.jsx)(`b`,{children:`Pending`}),` filter to process new uploads faster.`]}),(0,d.jsx)(`div`,{style:{fontSize:12,color:`#9a8a7a`},children:`PDFs open directly; images may require CORS to convert to PDF.`})]})]})]}),(0,d.jsxs)(`div`,{className:`db-panel`,style:{height:`fit-content`,position:`sticky`,top:16},children:[(0,d.jsxs)(`div`,{className:`db-panel-head`,children:[(0,d.jsxs)(`div`,{className:`db-panel-title-group`,children:[(0,d.jsx)(`div`,{className:`db-panel-icon`,style:{"--pi":`#d1fae5`,"--pc":`#065f46`},children:(0,d.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,d.jsx)(`path`,{d:`M4 8l2.2 2.2L12 4.5`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`,strokeLinejoin:`round`}),(0,d.jsx)(`path`,{d:`M8 15A7 7 0 108 1a7 7 0 000 14z`,stroke:`currentColor`,strokeWidth:`1.2`})]})}),(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`p`,{className:`db-panel-title`,children:`Summary`}),(0,d.jsx)(`p`,{className:`db-panel-sub`,children:`Counts by status`})]})]}),(0,d.jsx)(`button`,{className:`db-refresh-btn`,onClick:W,disabled:N!==null||T,children:`Refresh`})]}),(0,d.jsxs)(`div`,{style:{padding:18,display:`grid`,gap:10},children:[(0,d.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:12},children:[(0,d.jsx)(`span`,{style:{color:`#9a8a7a`,fontSize:12},children:`Total`}),(0,d.jsx)(`span`,{style:{fontFamily:`Lora, serif`,fontWeight:700,color:`#1a1a2e`},children:G.total})]}),(0,d.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:12},children:[(0,d.jsx)(`span`,{style:{color:`#9a8a7a`,fontSize:12},children:`Pending`}),(0,d.jsx)(`span`,{style:{fontFamily:`Lora, serif`,fontWeight:700,color:`#b45309`},children:G.pending})]}),(0,d.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:12},children:[(0,d.jsx)(`span`,{style:{color:`#9a8a7a`,fontSize:12},children:`Approved`}),(0,d.jsx)(`span`,{style:{fontFamily:`Lora, serif`,fontWeight:700,color:`#065f46`},children:G.approved})]}),(0,d.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:12},children:[(0,d.jsx)(`span`,{style:{color:`#9a8a7a`,fontSize:12},children:`Rejected`}),(0,d.jsx)(`span`,{style:{fontFamily:`Lora, serif`,fontWeight:700,color:`#b91c1c`},children:G.rejected})]}),(0,d.jsx)(`hr`,{style:{opacity:.08}}),(0,d.jsx)(`div`,{className:`db-pill db-pill--gold`,style:{justifyContent:`center`},children:`Action: review → approve/reject → notify`})]})]})]}),(0,d.jsx)(`div`,{className:`mt-auto`,children:(0,d.jsx)(l,{})}),I&&R&&(0,d.jsx)(`div`,{className:`position-fixed top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center`,style:{background:`rgba(15, 23, 42, 0.55)`,backdropFilter:`blur(6px)`,zIndex:1100,padding:12},onClick:()=>N?null:L(!1),children:(0,d.jsxs)(`div`,{className:`db-panel`,style:{width:`100%`,maxWidth:980,borderRadius:16,boxShadow:`0 30px 80px rgba(0,0,0,0.35)`},onClick:e=>e.stopPropagation(),children:[(0,d.jsxs)(`div`,{className:`db-panel-head`,style:{borderBottom:`1px solid rgba(0,0,0,0.08)`},children:[(0,d.jsxs)(`div`,{className:`db-panel-title-group`,children:[(0,d.jsx)(`div`,{className:`db-panel-icon`,style:{"--pi":`#ede9fe`,"--pc":`#7c3aed`},children:(0,d.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,d.jsx)(`path`,{d:`M4 2h8v12H4z`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinejoin:`round`}),(0,d.jsx)(`path`,{d:`M6 5h4M6 8h4M6 11h3`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`})]})}),(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`p`,{className:`db-panel-title`,children:`Review receipt`}),(0,d.jsxs)(`p`,{className:`db-panel-sub`,children:[m(R.student),` | `,R.student?.reg_no??`-`,` | `,R.payment_method]})]})]}),(0,d.jsx)(`button`,{className:`db-refresh-btn`,onClick:()=>L(!1),disabled:N!==null,style:{background:`transparent`},title:`Close`,children:`Close`})]}),(0,d.jsx)(`div`,{style:{padding:18},children:(0,d.jsxs)(`div`,{className:`row g-3`,children:[(0,d.jsxs)(`div`,{className:`col-12 col-lg-7`,children:[(0,d.jsx)(`div`,{style:{fontWeight:700,color:`#1a1a2e`,marginBottom:10},children:`Uploaded files`}),Array.isArray(R.receipts)&&R.receipts.length>0?(0,d.jsx)(`div`,{style:{display:`flex`,flexDirection:`column`,gap:10},children:R.receipts.map((e,t)=>(0,d.jsxs)(`div`,{style:{border:`1px solid rgba(0,0,0,0.08)`,borderRadius:12,padding:12,display:`flex`,alignItems:`center`,justifyContent:`space-between`,gap:12},children:[(0,d.jsxs)(`div`,{style:{minWidth:0},children:[(0,d.jsx)(`div`,{style:{fontSize:12,color:`#9a8a7a`},children:`File`}),(0,d.jsx)(`div`,{style:{fontWeight:600,color:`#1a1a2e`,overflow:`hidden`,textOverflow:`ellipsis`,whiteSpace:`nowrap`},children:e})]}),(0,d.jsx)(`button`,{className:`db-refresh-btn`,onClick:()=>J(e),disabled:N!==null,children:F(`receipt:open:${e}`)?`Opening...`:`Open`})]},`${R.payment_id}-${t}`))}):(0,d.jsx)(`div`,{className:`alert alert-warning mb-0`,children:`No receipt files found on this record.`}),(0,d.jsxs)(`div`,{className:`alert alert-info mt-3 mb-0`,children:[(0,d.jsx)(`b`,{children:`Note:`}),` PDFs open directly (no CORS needed). Image-to-PDF conversion can fail if your server blocks cross-origin requests.`]})]}),(0,d.jsx)(`div`,{className:`col-12 col-lg-5`,children:(0,d.jsxs)(`div`,{style:{border:`1px solid rgba(0,0,0,0.08)`,borderRadius:14,padding:14,background:`#faf8f5`},children:[(0,d.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,alignItems:`center`,gap:12},children:[(0,d.jsx)(`div`,{style:{fontWeight:800,color:`#1a1a2e`},children:`Decision`}),(0,d.jsx)(`span`,{className:h(R.status),children:(R.status||`pending`).toUpperCase()})]}),(0,d.jsxs)(`div`,{style:{marginTop:12},children:[(0,d.jsx)(`label`,{className:`form-label fw-semibold small mb-1`,children:`Update status *`}),(0,d.jsxs)(`select`,{className:`form-select`,value:B,onChange:e=>V(e.target.value),disabled:N!==null,children:[(0,d.jsx)(`option`,{value:`pending`,children:`Pending`}),(0,d.jsx)(`option`,{value:`approved`,children:`Approved`}),(0,d.jsx)(`option`,{value:`rejected`,children:`Rejected`})]})]}),(0,d.jsxs)(`div`,{style:{marginTop:12},children:[(0,d.jsx)(`label`,{className:`form-label fw-semibold small mb-1`,children:`Notes (optional)`}),(0,d.jsx)(`textarea`,{className:`form-control`,rows:4,placeholder:`e.g. bank slip unclear, please re-upload with a clear screenshot...`,value:H,onChange:e=>U(e.target.value),disabled:N!==null}),(0,d.jsx)(`div`,{className:`form-text`,children:`If rejected, add a clear reason so parents know what to fix.`})]}),(0,d.jsxs)(`div`,{style:{display:`flex`,gap:10,justifyContent:`flex-end`,marginTop:14,flexWrap:`wrap`},children:[(0,d.jsx)(`button`,{className:`db-refresh-btn`,onClick:()=>L(!1),disabled:N!==null,children:`Cancel`}),(0,d.jsx)(`button`,{className:`db-btn-gold`,onClick:Y,disabled:N!==null,style:{borderRadius:10,padding:`9px 14px`},children:F(`receipt:update:${R.payment_id}`)?`Saving...`:`Save status`})]}),(0,d.jsxs)(`div`,{className:`alert alert-warning mt-3 mb-0`,children:[(0,d.jsx)(`b`,{children:`Reminder:`}),` Approved receipts typically unlock fee payment (your backend enforces this rule).`]})]})})]})})]})})]})]})})]})}export{x as default};