import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{p as t}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{t as n}from"./vendor-chart-J6aekJfr.js";import{C as r,E as i,P as a,d as o,f as s,l as ee,u as c}from"./index-D6TxbaCx.js";var l=e(),u=t();function d(e){let t=Number(e??0);try{return new Intl.NumberFormat(`en-NG`,{style:`currency`,currency:`NGN`}).format(t)}catch{return`₦${t.toLocaleString()}`}}function f(){let e=new Date().getHours();return e<12?`Good morning`:e<17?`Good afternoon`:`Good evening`}function p(e){let t=(e||``).toLowerCase();return t===`paid`?`db-pill db-pill--green`:t===`partial`?`db-pill db-pill--violet`:`db-pill db-pill--gold`}function m(){let{showError:e,showWarning:t,showSuccess:m}=ee(),[h,te]=(0,l.useState)(!1),[g,_]=(0,l.useState)(!0),[v,y]=(0,l.useState)(!0),[b,x]=(0,l.useState)(!1),[S,C]=(0,l.useState)([]),[w,T]=(0,l.useState)([]),[E,D]=(0,l.useState)([]),[O,k]=(0,l.useState)(``),[A,j]=(0,l.useState)(``),[M,N]=(0,l.useState)(``),[P,F]=(0,l.useState)(10),[I,L]=(0,l.useState)(1),[R,z]=(0,l.useState)(``),[B,V]=(0,l.useState)(null),H=(0,l.useRef)(null),U=(0,l.useRef)(null),W=(0,l.useRef)(null),G=(0,l.useRef)(null);(0,l.useEffect)(()=>{let t=!0;_(!0);async function n(){try{y(!0);let e=await a.get(`/filters`);if(!t)return;C(e.data?.sessions??[]),T(e.data?.terms??[]),D(e.data?.sections??[]),y(!1),await K(1,{mounted:t})}catch(t){console.error(t),e(t?.response?.data?.message||t?.message||`Failed to load report filters.`)}finally{t&&_(!1)}}return n(),()=>{t=!1}},[]);async function K(t,n){let r=t??I,i=n?.mounted??!0;try{x(!0);let e={per_page:P,page:r};O&&(e.session_id=O),A&&(e.term_id=A),M&&(e.section_id=M);let t=await a.get(`/financial-report`,{params:e});if(!i)return;V(t.data?.data??null),L(r)}catch(t){console.error(t),e(t?.response?.data?.message||t?.message||`Failed to generate financial report.`),V(null)}finally{x(!1)}}function q(){z(``),K(1)}function J(){k(``),j(``),N(``),F(10),L(1),z(``),t(`Filters cleared.`),K(1)}let Y=B?.summary,X=(0,l.useMemo)(()=>{let e=Number(Y?.payment_percentage??0);return Math.max(0,Math.min(100,Number.isFinite(e)?e:0))},[Y]),Z=B?.breakdown,Q=Z?.data??[],$=(0,l.useMemo)(()=>{let e=R.trim().toLowerCase();return e?Q.filter(t=>{let n=t.feeType??t.fee_type,r=t.student;return`${r?.firstname??``} ${r?.surname??``} ${r?.reg_no??``} ${n?.name??``} ${t.status??``} ${t.id}`.toLowerCase().trim().includes(e)}):Q},[Q,R]);(0,l.useEffect)(()=>{let e=(e,t)=>{let n=(e||``).trim();return/^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(n)?`${n.length===4?`#${n[1]}${n[1]}${n[2]}${n[2]}${n[3]}${n[3]}`:n}${Math.round(t*255).toString(16).padStart(2,`0`)}`:n},t=(t,n)=>{let r=t.createLinearGradient(0,0,0,320);return r.addColorStop(0,e(n,.28)),r.addColorStop(1,e(n,.04)),r};if(H.current){let e=H.current.getContext(`2d`);e&&(W.current?.destroy(),W.current=new n(e,{type:`line`,data:{labels:[`Assigned`,`Collected`,`Balance`],datasets:[{label:`Amount (₦)`,data:[Number(Y?.total_fees_assigned??0),Number(Y?.total_paid??0)+Number(Y?.total_partially_paid??0),Number(Y?.total_balance_remaining??0)],borderColor:`#c9a84c`,backgroundColor:t(e,`#c9a84c`),pointBackgroundColor:`#c9a84c`,pointBorderColor:`#0f172a`,pointBorderWidth:2,pointRadius:5,pointHoverRadius:7,tension:.35,fill:!0}]},options:{responsive:!0,maintainAspectRatio:!1,plugins:{legend:{display:!1},tooltip:{callbacks:{label:e=>` ${d(e.parsed.y)}`}}},scales:{x:{grid:{display:!1},ticks:{font:{size:11}}},y:{grid:{color:`rgba(0,0,0,0.06)`},ticks:{font:{size:11},callback:e=>`${e}`}}}}}))}if(U.current){let e=U.current.getContext(`2d`);if(e){G.current?.destroy();let t=Q.filter(e=>(e.status||``).toLowerCase()===`paid`).length,r=Q.filter(e=>(e.status||``).toLowerCase()===`partial`).length,i=Q.filter(e=>(e.status||``).toLowerCase()===`unpaid`).length;G.current=new n(e,{type:`bar`,data:{labels:[`Paid`,`Partial`,`Unpaid`],datasets:[{label:`Records (current page)`,data:[t,r,i],backgroundColor:`#64748b`,borderRadius:10,barThickness:34}]},options:{responsive:!0,maintainAspectRatio:!1,plugins:{legend:{display:!1}},scales:{x:{grid:{display:!1},ticks:{font:{size:11}}},y:{beginAtZero:!0,grid:{color:`rgba(0,0,0,0.06)`},ticks:{font:{size:11}}}}}})}}return()=>{W.current?.destroy(),G.current?.destroy()}},[Y,Q]);let ne=(0,l.useMemo)(()=>{let e=Number(Y?.total_fees_assigned??0),t=Number(Y?.total_paid??0),n=Number(Y?.total_partially_paid??0),r=Number(Y?.total_unpaid??0),i=Number(Y?.total_balance_remaining??0);return[{title:`Total Assigned`,value:d(e),hint:`Total fee value assigned`,icon:`bi-cash-stack`,tone:`gold`},{title:`Fully Paid`,value:d(t),hint:`Collections fully settled`,icon:`bi-check2-circle`,tone:`green`},{title:`Partially Paid`,value:d(n),hint:`Collections in progress`,icon:`bi-pie-chart`,tone:`violet`},{title:`Balance Remaining`,value:d(i),hint:`Outstanding balance`,icon:`bi-exclamation-circle`,tone:`red`},{title:`Unpaid (incl partial bal)`,value:d(r),hint:`Unpaid total exposure`,icon:`bi-dash-circle`,tone:`slate`},{title:`Payment %`,value:`${X}%`,hint:`Overall collection rate`,icon:`bi-percent`,tone:`slate`}]},[Y,X]),re=(0,l.useMemo)(()=>S.find(e=>e.id===O)?.name,[S,O]),ie=(0,l.useMemo)(()=>w.find(e=>e.id===A)?.name,[w,A]),ae=(0,l.useMemo)(()=>E.find(e=>e.id===M)?.name,[E,M]);return(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`style`,{children:`
    /* ======= FeesReport - Modern SaaS style ======= */
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');
    .db-main {
      background: #F8FAFC;
      min-height: 100vh;
      font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
      padding: 24px 28px 0;
    }
    @media (max-width: 991.98px) { .db-main { padding: 18px 14px 0; } }

    .db-hero {
      background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
      border-radius: 18px;
      padding: 32px 36px;
      position: relative;
      overflow: hidden;
      margin: 10px 0 24px;
      box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
    }
    .db-hero-glow {
      position: absolute;
      top: -60px;
      right: -60px;
      width: 320px;
      height: 320px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(217, 119, 6, 0.15) 0%, transparent 65%);
      pointer-events: none;
    }
    .db-hero-glow2 {
      position: absolute;
      bottom: -40px;
      left: 26%;
      width: 220px;
      height: 220px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(37, 99, 235, 0.10) 0%, transparent 70%);
      pointer-events: none;
    }
    .db-hero-inner {
      position: relative;
      z-index: 1;
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
      gap: 28px;
      flex-wrap: wrap;
    }

    .db-session-badge {
      display: inline-flex;
      align-items: center;
      gap: 7px;
      font-size: 11.5px;
      font-weight: 700;
      letter-spacing: 0.04em;
      text-transform: uppercase;
      color: #FBBF24;
      background: rgba(217, 119, 6, 0.20);
      border: 1px solid rgba(217, 119, 6, 0.35);
      border-radius: 100px;
      padding: 4px 12px;
      margin-bottom: 12px;
    }
    .db-session-dot {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: #10B981;
      animation: dbPulse 2s ease infinite;
    }
    @keyframes dbPulse {
      0%,100% { opacity: 1; transform: scale(1); }
      50% { opacity: 0.4; transform: scale(1.5); }
    }
    .db-greeting {
      font-size: 26px;
      font-weight: 800;
      color: #fff;
      line-height: 1.1;
      margin-bottom: 8px;
    }
    .db-greeting em { font-style: normal; color: #FBBF24; }

    .db-hero-sub {
      font-size: 13.5px;
      color: #CBD5E1;
      line-height: 1.6;
      max-width: 680px;
      margin-bottom: 20px;
    }
    .db-hero-btns { display: flex; gap: 10px; flex-wrap: wrap; }

    .db-btn-gold {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 9px 18px;
      font-size: 13px;
      font-weight: 700;
      color: #FFFFFF;
      background: #D97706;
      border: none;
      border-radius: 10px;
      cursor: pointer;
      transition: all 0.2s ease;
      white-space: nowrap;
    }
    .db-btn-gold:hover { background: #B45309; transform: translateY(-1px); color: #FFFFFF; }
    .db-btn-gold:disabled { opacity: 0.55; cursor: not-allowed; transform: none; }

    .db-btn-outline {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 9px 18px;
      font-size: 13px;
      font-weight: 600;
      color: #FFFFFF;
      background: rgba(255, 255, 255, 0.10);
      border: 1px solid rgba(255, 255, 255, 0.20);
      border-radius: 10px;
      cursor: pointer;
      transition: all 0.2s ease;
      white-space: nowrap;
    }
    .db-btn-outline:hover { background: rgba(255, 255, 255, 0.18); color: #fff; }
    .db-btn-outline:disabled { opacity: 0.55; cursor: not-allowed; }

    .db-hero-stat-card {
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid rgba(255, 255, 255, 0.09);
      backdrop-filter: blur(8px);
      border-radius: 14px;
      padding: 18px 20px;
      min-width: 330px;
    }
    @media (max-width: 991.98px) { .db-hero { padding: 24px 20px; } .db-hero-stat-card { min-width: 0; width: 100%; } }
    .db-hero-stat-row { display: flex; flex-direction: column; gap: 10px; }
    .db-hero-stat-item { display: flex; justify-content: space-between; align-items: center; gap: 16px; }
    .db-hero-stat-label { font-size: 12px; font-weight: 300; color: #94a3b8; }
    .db-hero-stat-val {
      font-family: "Lora", serif;
      font-size: 18px;
      font-weight: 700;
      color: #fff;
    }
    .db-hero-stat-sep { height: 1px; background: rgba(255, 255, 255, 0.06); }
    .db-progress { height: 10px; border-radius: 999px; background: rgba(255,255,255,0.12); overflow: hidden; }
    .db-progress > div { height: 100%; border-radius: 999px; background: linear-gradient(90deg, #c9a84c, #e8c97a); width: 0%; transition: width 0.35s ease; }

    .db-panel {
      background: #ffffff;
      border: 1px solid #ede8e0;
      border-radius: 14px;
      overflow: hidden;
      box-shadow: 0 2px 10px rgba(15,23,42,0.04);
    }
    .db-panel-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 16px 18px;
      border-bottom: 1px solid rgba(0, 0, 0, 0.06);
      gap: 12px;
      flex-wrap: wrap;
    }
    .db-panel-title {
      font-family: "Lora", serif;
      font-size: 16px;
      font-weight: 800;
      color: #1a1a2e;
      margin: 0;
    }
    .db-panel-sub { font-size: 11.5px; font-weight: 300; color: #9a8a7a; margin: 0; }

    .db-pill {
      display: inline-flex;
      align-items: center;
      font-size: 12px;
      font-weight: 700;
      padding: 3px 10px;
      border-radius: 999px;
      background: rgba(30, 64, 175, 0.08);
      color: #1e40af;
      border: 1px solid rgba(30, 64, 175, 0.12);
      white-space: nowrap;
    }
    .db-pill--gold {
      background: rgba(180, 83, 9, 0.08);
      color: #b45309;
      border-color: rgba(180, 83, 9, 0.14);
    }
    .db-pill--violet {
      background: rgba(124, 58, 237, 0.08);
      color: #7c3aed;
      border-color: rgba(124, 58, 237, 0.12);
    }
    .db-pill--green {
      background: rgba(6, 95, 70, 0.08);
      color: #065f46;
      border-color: rgba(6, 95, 70, 0.12);
    }

    .db-refresh-btn {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 8px 12px;
      font-size: 12px;
      font-weight: 600;
      color: #7a6a5a;
      background: #f5f1eb;
      border: 1px solid #e5ddd3;
      border-radius: 10px;
      cursor: pointer;
      transition: background 0.2s;
      white-space: nowrap;
    }
    .db-refresh-btn:hover { background: #ede8e0; }
    .db-refresh-btn:disabled { opacity: 0.55; cursor: not-allowed; }

    .db-grid2 { display: grid; grid-template-columns: 1fr 420px; gap: 18px; margin: 16px 0 18px; }
    @media (max-width: 991.98px) { .db-grid2 { grid-template-columns: 1fr; } }
    .db-cardgrid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 14px; margin: 14px 0 18px; }
    @media (max-width: 991.98px) { .db-cardgrid { grid-template-columns: repeat(2, minmax(0, 1fr)); } }
    @media (max-width: 575.98px) { .db-cardgrid { grid-template-columns: 1fr; } }

    .db-stat {
      border: 1px solid #ede8e0;
      border-radius: 14px;
      padding: 14px 14px;
      background: #fff;
      box-shadow: 0 2px 10px rgba(15,23,42,0.04);
      transition: transform 0.2s, box-shadow 0.2s;
      position: relative;
      overflow: hidden;
    }
    .db-stat:hover { transform: translateY(-2px); box-shadow: 0 12px 26px rgba(15,23,42,0.08); }
    .db-stat::before {
      content: "";
      position: absolute;
      inset: 0;
      opacity: 0.55;
      pointer-events: none;
      background: radial-gradient(circle at 12% 10%, rgba(201,168,76,0.10), transparent 45%),
                  radial-gradient(circle at 90% 25%, rgba(99,102,241,0.08), transparent 55%);
    }
    .db-stat-inner { position: relative; z-index: 1; display: flex; gap: 12px; align-items: flex-start; }
    .db-stat-icon {
      width: 40px;
      height: 40px;
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      flex: 0 0 auto;
      border: 1px solid rgba(0,0,0,0.06);
    }
    .db-tone-gold { background: rgba(201,168,76,0.12); color: #b45309; }
    .db-tone-green { background: rgba(34,197,94,0.12); color: #065f46; }
    .db-tone-violet { background: rgba(124,58,237,0.10); color: #7c3aed; }
    .db-tone-red { background: rgba(239,68,68,0.10); color: #b91c1c; }
    .db-tone-slate { background: rgba(100,116,139,0.10); color: #334155; }

    .db-stat-title { font-size: 12px; color: #9a8a7a; margin: 0 0 4px; }
    .db-stat-value { font-family: "Lora", serif; font-weight: 900; color: #1a1a2e; font-size: 18px; margin: 0; }
    .db-stat-hint { font-size: 11px; color: #a89a8a; margin: 8px 0 0; }

    .db-table { width: 100%; border-collapse: collapse; }
    .db-table th {
      padding: 10px 14px;
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: #9a8a7a;
      background: #faf8f5;
      border-bottom: 1px solid rgba(0, 0, 0, 0.06);
      text-align: left;
      white-space: nowrap;
    }
    .db-table td {
      padding: 12px 14px;
      font-size: 13.5px;
      color: #4a4a5a;
      border-bottom: 1px solid rgba(0, 0, 0, 0.06);
      vertical-align: middle;
    }
    .db-table tbody tr:hover { background: #faf8f5; }

    .db-input {
      width: 100%;
      padding: 10px 12px;
      border-radius: 10px;
      border: 1px solid #e5ddd3;
      outline: none;
      font-size: 13px;
      background: #fff;
    }
    .db-input:focus { border-color: rgba(201,168,76,0.7); box-shadow: 0 0 0 3px rgba(201,168,76,0.18); }

    .db-select {
      width: 100%;
      padding: 10px 12px;
      border-radius: 10px;
      border: 1px solid #e5ddd3;
      outline: none;
      font-size: 13px;
      background: #fff;
    }
    .db-select:focus { border-color: rgba(201,168,76,0.7); box-shadow: 0 0 0 3px rgba(201,168,76,0.18); }

    .db-row { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 10px; padding: 14px 18px; }
    @media (max-width: 991.98px) { .db-row { grid-template-columns: repeat(2, minmax(0, 1fr)); } }
    @media (max-width: 575.98px) { .db-row { grid-template-columns: 1fr; } }
    .db-field label { font-size: 11px; color: #9a8a7a; font-weight: 700; letter-spacing: 0.08em; text-transform: uppercase; margin-bottom: 6px; display: block; }
    .db-actions { display: flex; gap: 10px; justify-content: flex-end; align-items: flex-end; flex-wrap: wrap; }

    .db-chartWrap { padding: 14px 18px 16px; }
    .db-chartBox { height: 300px; }
    .db-foot {
      padding: 12px 18px;
      display: flex;
      justify-content: space-between;
      gap: 12px;
      flex-wrap: wrap;
      border-top: 1px solid rgba(0,0,0,0.06);
      color: #9a8a7a;
      font-size: 12px;
    }

    @keyframes dbSpin { to { transform: rotate(360deg); } }
  `}),(0,u.jsx)(s,{sidebarOpen:h,setSidebarOpen:te}),(0,u.jsx)(r,{title:`Fees Report`}),(0,u.jsx)(`div`,{className:`container-fluid`,children:(0,u.jsxs)(`div`,{className:`row`,children:[(0,u.jsx)(o,{sidebarOpen:h}),(0,u.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto db-main`,children:[(g||b)&&(0,u.jsx)(i,{message:g?`Loading report...`:`Generating report...`}),(0,u.jsxs)(`div`,{className:`db-hero`,children:[(0,u.jsx)(`div`,{className:`db-hero-glow`,"aria-hidden":`true`}),(0,u.jsx)(`div`,{className:`db-hero-glow2`,"aria-hidden":`true`}),(0,u.jsxs)(`div`,{className:`db-hero-inner`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsxs)(`div`,{className:`db-session-badge`,children:[(0,u.jsx)(`span`,{className:`db-session-dot`}),`Fees • Finance Dashboard`]}),(0,u.jsxs)(`h1`,{className:`db-greeting`,children:[f(),`, `,(0,u.jsx)(`em`,{children:`Admin.`})]}),(0,u.jsxs)(`p`,{className:`db-hero-sub`,children:[`Track assigned fees, collections, and outstanding balances. Use filters to drill down by`,` `,(0,u.jsx)(`b`,{children:`session`}),`, `,(0,u.jsx)(`b`,{children:`term`}),`, and `,(0,u.jsx)(`b`,{children:`section`}),`.`]}),(0,u.jsxs)(`div`,{className:`db-hero-btns`,children:[(0,u.jsxs)(`button`,{className:`db-btn-gold`,onClick:q,disabled:v||b,children:[(0,u.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:(0,u.jsx)(`path`,{d:`M2 3h12M4 7h8M6 11h4`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`})}),b?`Generating…`:`Apply filters`]}),(0,u.jsxs)(`button`,{className:`db-btn-outline`,onClick:J,disabled:b,children:[(0,u.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,u.jsx)(`path`,{d:`M3 3l10 10`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`}),(0,u.jsx)(`path`,{d:`M13 3L3 13`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})]}),`Clear filters`]})]})]}),(0,u.jsxs)(`div`,{className:`db-hero-stat-card d-none d-md-block`,children:[(0,u.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,marginBottom:14},children:[(0,u.jsx)(`span`,{style:{fontSize:11,fontWeight:700,letterSpacing:`0.14em`,textTransform:`uppercase`,color:`#c9a84c`},children:`Active filters`}),(0,u.jsxs)(`span`,{className:`db-pill db-pill--violet`,children:[X,`%`]})]}),(0,u.jsxs)(`div`,{className:`db-hero-stat-row`,children:[(0,u.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,u.jsx)(`span`,{className:`db-hero-stat-label`,children:`Session`}),(0,u.jsx)(`span`,{className:`db-hero-stat-val`,style:{fontSize:14},children:re||`All`})]}),(0,u.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,u.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,u.jsx)(`span`,{className:`db-hero-stat-label`,children:`Term`}),(0,u.jsx)(`span`,{className:`db-hero-stat-val`,style:{fontSize:14},children:ie||`All`})]}),(0,u.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,u.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,u.jsx)(`span`,{className:`db-hero-stat-label`,children:`Section`}),(0,u.jsx)(`span`,{className:`db-hero-stat-val`,style:{fontSize:14},children:ae||`All`})]}),(0,u.jsxs)(`div`,{style:{marginTop:10},children:[(0,u.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,color:`#cbd5e1`,fontSize:12,marginBottom:6},children:[(0,u.jsx)(`span`,{children:`Collection progress`}),(0,u.jsxs)(`span`,{style:{fontWeight:800},children:[X,`%`]})]}),(0,u.jsx)(`div`,{className:`db-progress`,children:(0,u.jsx)(`div`,{style:{width:`${X}%`}})})]})]})]})]})]}),(0,u.jsxs)(`div`,{className:`db-panel`,children:[(0,u.jsxs)(`div`,{className:`db-panel-head`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`p`,{className:`db-panel-title`,children:`Report filters`}),(0,u.jsx)(`p`,{className:`db-panel-sub`,children:`Choose session, term, section, and paging size`})]}),(0,u.jsxs)(`button`,{className:`db-refresh-btn`,onClick:()=>K(I),disabled:b,children:[(0,u.jsxs)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,style:{animation:b?`dbSpin 0.8s linear infinite`:`none`},children:[(0,u.jsx)(`path`,{d:`M12 7A5 5 0 112 7`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,u.jsx)(`path`,{d:`M12 3v4h-4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`})]}),`Refresh`]})]}),(0,u.jsxs)(`div`,{className:`db-row`,children:[(0,u.jsxs)(`div`,{className:`db-field`,children:[(0,u.jsx)(`label`,{children:`Session`}),(0,u.jsxs)(`select`,{className:`db-select`,value:O,onChange:e=>k(e.target.value?Number(e.target.value):``),disabled:v||b,children:[(0,u.jsx)(`option`,{value:``,children:`All sessions`}),S.map(e=>(0,u.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]}),(0,u.jsxs)(`div`,{className:`db-field`,children:[(0,u.jsx)(`label`,{children:`Term`}),(0,u.jsxs)(`select`,{className:`db-select`,value:A,onChange:e=>j(e.target.value?Number(e.target.value):``),disabled:v||b,children:[(0,u.jsx)(`option`,{value:``,children:`All terms`}),w.map(e=>(0,u.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]}),(0,u.jsxs)(`div`,{className:`db-field`,children:[(0,u.jsx)(`label`,{children:`Section`}),(0,u.jsxs)(`select`,{className:`db-select`,value:M,onChange:e=>N(e.target.value?Number(e.target.value):``),disabled:v||b,children:[(0,u.jsx)(`option`,{value:``,children:`All sections`}),E.map(e=>(0,u.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]}),(0,u.jsxs)(`div`,{className:`db-field`,children:[(0,u.jsx)(`label`,{children:`Per page`}),(0,u.jsx)(`select`,{className:`db-select`,value:P,onChange:e=>F(Number(e.target.value)),disabled:b,children:[10,20,30,50].map(e=>(0,u.jsx)(`option`,{value:e,children:e},e))})]}),(0,u.jsxs)(`div`,{className:`db-actions`,style:{gridColumn:`1 / -1`},children:[(0,u.jsx)(`button`,{className:`db-refresh-btn`,onClick:J,disabled:b,children:`Clear`}),(0,u.jsx)(`button`,{className:`db-btn-gold`,onClick:q,disabled:v||b,children:b?`Generating…`:`Apply`})]})]})]}),(0,u.jsx)(`div`,{className:`db-cardgrid`,children:ne.map(e=>(0,u.jsx)(`div`,{className:`db-stat`,children:(0,u.jsxs)(`div`,{className:`db-stat-inner`,children:[(0,u.jsx)(`div`,{className:`db-stat-icon ${e.tone===`gold`?`db-tone-gold`:e.tone===`green`?`db-tone-green`:e.tone===`violet`?`db-tone-violet`:e.tone===`red`?`db-tone-red`:`db-tone-slate`}`,children:(0,u.jsx)(`i`,{className:`bi ${e.icon}`})}),(0,u.jsxs)(`div`,{style:{minWidth:0},children:[(0,u.jsx)(`p`,{className:`db-stat-title`,children:e.title}),(0,u.jsx)(`p`,{className:`db-stat-value`,children:e.value}),(0,u.jsx)(`p`,{className:`db-stat-hint`,children:e.hint})]})]})},e.title))}),(0,u.jsxs)(`div`,{className:`db-grid2`,children:[(0,u.jsxs)(`div`,{className:`db-panel`,children:[(0,u.jsxs)(`div`,{className:`db-panel-head`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`p`,{className:`db-panel-title`,children:`Financial trend`}),(0,u.jsx)(`p`,{className:`db-panel-sub`,children:`Assigned vs Collected vs Balance`})]}),(0,u.jsxs)(`span`,{className:`db-pill db-pill--gold`,children:[X,`% collected`]})]}),(0,u.jsxs)(`div`,{className:`db-chartWrap`,children:[(0,u.jsx)(`div`,{className:`db-chartBox`,children:(0,u.jsx)(`canvas`,{ref:H})}),(0,u.jsx)(`div`,{style:{marginTop:10,color:`#9a8a7a`,fontSize:12},children:`Tip: If collected is far below assigned, focus on partial + unpaid balances.`})]})]}),(0,u.jsxs)(`div`,{className:`db-panel`,children:[(0,u.jsxs)(`div`,{className:`db-panel-head`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`p`,{className:`db-panel-title`,children:`Status mix`}),(0,u.jsx)(`p`,{className:`db-panel-sub`,children:`Counts (current page only)`})]}),(0,u.jsx)(`button`,{className:`db-refresh-btn`,onClick:()=>{m?.(`Chart refreshed.`),K(I)},disabled:b,children:`Refresh`})]}),(0,u.jsxs)(`div`,{className:`db-chartWrap`,children:[(0,u.jsx)(`div`,{className:`db-chartBox`,children:(0,u.jsx)(`canvas`,{ref:U})}),(0,u.jsx)(`div`,{style:{marginTop:10,color:`#9a8a7a`,fontSize:12},children:`Note: status counts are computed from the current page of results.`})]})]})]}),(0,u.jsxs)(`div`,{className:`db-panel`,style:{marginBottom:18},children:[(0,u.jsxs)(`div`,{className:`db-panel-head`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`p`,{className:`db-panel-title`,children:`Breakdown`}),(0,u.jsxs)(`p`,{className:`db-panel-sub`,children:[`Page `,(0,u.jsx)(`b`,{children:Z?.current_page??1}),` of `,(0,u.jsx)(`b`,{children:Z?.last_page??1}),` • Total`,` `,(0,u.jsx)(`b`,{children:Z?.total??0})]})]}),(0,u.jsxs)(`div`,{style:{display:`flex`,gap:10,flexWrap:`wrap`,alignItems:`center`},children:[(0,u.jsx)(`input`,{className:`db-input`,style:{width:320},placeholder:`Search student / reg no / fee / status (this page)`,value:R,onChange:e=>z(e.target.value),disabled:b}),(0,u.jsx)(`button`,{className:`db-refresh-btn`,onClick:()=>z(``),disabled:!R||b,children:`Clear`}),(0,u.jsx)(`button`,{className:`db-refresh-btn`,onClick:()=>K(Math.max(1,(Z?.current_page??1)-1)),disabled:b||(Z?.current_page??1)<=1,children:`← Prev`}),(0,u.jsxs)(`span`,{className:`db-pill db-pill--violet`,children:[`Page `,Z?.current_page??1]}),(0,u.jsx)(`button`,{className:`db-refresh-btn`,onClick:()=>K(Math.min(Z?.last_page??1,(Z?.current_page??1)+1)),disabled:b||(Z?.current_page??1)>=(Z?.last_page??1),children:`Next →`})]})]}),(0,u.jsx)(`div`,{style:{overflowX:`auto`},children:(0,u.jsxs)(`table`,{className:`db-table`,children:[(0,u.jsx)(`thead`,{children:(0,u.jsxs)(`tr`,{children:[(0,u.jsx)(`th`,{style:{width:70},children:`#`}),(0,u.jsx)(`th`,{children:`Student`}),(0,u.jsx)(`th`,{style:{width:160},children:`Reg No`}),(0,u.jsx)(`th`,{children:`Fee Type`}),(0,u.jsx)(`th`,{style:{width:150,textAlign:`right`},children:`Total`}),(0,u.jsx)(`th`,{style:{width:150,textAlign:`right`},children:`Paid`}),(0,u.jsx)(`th`,{style:{width:150,textAlign:`right`},children:`Balance`}),(0,u.jsx)(`th`,{style:{width:120},children:`Status`}),(0,u.jsx)(`th`,{style:{width:90,textAlign:`right`},children:`ID`})]})}),(0,u.jsx)(`tbody`,{children:!B&&!b?(0,u.jsx)(`tr`,{children:(0,u.jsx)(`td`,{colSpan:9,style:{padding:18,textAlign:`center`,color:`#9a8a7a`},children:`No report loaded. Apply filters to generate.`})}):b?(0,u.jsx)(`tr`,{children:(0,u.jsxs)(`td`,{colSpan:9,style:{padding:18},children:[(0,u.jsx)(`div`,{style:{height:14,borderRadius:8,background:`#f0ebe3`,marginBottom:10}}),(0,u.jsx)(`div`,{style:{height:14,borderRadius:8,background:`#f0ebe3`,marginBottom:10}}),(0,u.jsx)(`div`,{style:{height:14,borderRadius:8,background:`#f0ebe3`}})]})}):$.length===0?(0,u.jsx)(`tr`,{children:(0,u.jsx)(`td`,{colSpan:9,style:{padding:18,textAlign:`center`,color:`#9a8a7a`},children:`No records found. Try changing filters or search query.`})}):$.map((e,t)=>{let n=e.feeType??e.fee_type,r=(e.status||``).toLowerCase();return(0,u.jsxs)(`tr`,{children:[(0,u.jsx)(`td`,{children:(Z?.from??1)+t}),(0,u.jsxs)(`td`,{children:[(0,u.jsx)(`div`,{style:{fontWeight:800,color:`#1a1a2e`},children:((e.student?.firstname??``)+` `+(e.student?.surname??``)).trim()||`-`}),(0,u.jsxs)(`div`,{style:{fontSize:12,color:`#9a8a7a`},children:[`Student ID: `,e.student_id]})]}),(0,u.jsx)(`td`,{style:{color:`#6b7280`},children:e.student?.reg_no??`-`}),(0,u.jsx)(`td`,{children:n?.name??`Fee #${e.fee_type_id}`}),(0,u.jsx)(`td`,{style:{textAlign:`right`},children:d(e.total_amount)}),(0,u.jsx)(`td`,{style:{textAlign:`right`},children:d(e.amount_paid)}),(0,u.jsx)(`td`,{style:{textAlign:`right`},children:(0,u.jsx)(`span`,{style:{fontWeight:Number(e.balance??0)>0?800:500,color:Number(e.balance??0)>0?`#1a1a2e`:`#9a8a7a`},children:d(e.balance)})}),(0,u.jsx)(`td`,{children:(0,u.jsx)(`span`,{className:p(r),children:(r||`—`).toUpperCase()})}),(0,u.jsx)(`td`,{style:{textAlign:`right`,color:`#9a8a7a`},children:e.id})]},e.id)})})]})}),(0,u.jsxs)(`div`,{className:`db-foot`,children:[(0,u.jsxs)(`div`,{children:[`Showing `,(0,u.jsx)(`b`,{children:$.length}),` of `,(0,u.jsx)(`b`,{children:Q.length}),` rows on this page`]}),(0,u.jsx)(`div`,{children:`Tip: Use Section filter to identify the most affected classes.`})]})]}),(0,u.jsx)(`div`,{className:`mt-auto`,children:(0,u.jsx)(c,{})})]})]})})]})}export{m as default};