import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{p as t}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as n,E as ee,P as r,d as te,f as ne,u as re}from"./index-D6TxbaCx.js";var i=e(),a=t(),o=e=>e===!0||e===1||e===`1`,ie=e=>o(e.online_payment_enabled??e.accepts_online_payment);function ae(e){let t=(e||``).trim();return t.length<=4?t:`${`*`.repeat(Math.max(0,t.length-4))}${t.slice(-4)}`}async function oe(e){try{return await navigator.clipboard.writeText(e),!0}catch{return!1}}function se(e){if(!e)return`—`;let t=new Date(e);return Number.isNaN(t.getTime())?e:t.toLocaleString(`en-GB`,{day:`2-digit`,month:`short`,year:`numeric`,hour:`2-digit`,minute:`2-digit`})}function s(){let[e,t]=(0,i.useState)(!1),[s,c]=(0,i.useState)(!0),[l,u]=(0,i.useState)(!1),[d,f]=(0,i.useState)(null),[p,ce]=(0,i.useState)([]),[m,le]=(0,i.useState)(`offline`),[ue,h]=(0,i.useState)(``),[g,de]=(0,i.useState)(``),[_,v]=(0,i.useState)(!1),[y,b]=(0,i.useState)(null),[x,fe]=(0,i.useState)([]),[S,C]=(0,i.useState)(``),[w,T]=(0,i.useState)(``),[E,D]=(0,i.useState)(``),[O,k]=(0,i.useState)(``),[pe,me]=(0,i.useState)(!1),[A,j]=(0,i.useState)(!1),[M,N]=(0,i.useState)(`NGN`),[P,F]=(0,i.useState)(!0),[I,L]=(0,i.useState)(!1),[R,z]=(0,i.useState)(0),[he,B]=(0,i.useState)(!1),[V,H]=(0,i.useState)(``),[ge,_e]=(0,i.useState)(``),[U,W]=(0,i.useState)(!1),[G,ve]=(0,i.useState)(0),[ye,K]=(0,i.useState)(``),[be,xe]=(0,i.useState)(!1),[Se,Ce]=(0,i.useState)(null);(0,i.useEffect)(()=>{if(G<=0)return;let e=setInterval(()=>{ve(e=>e-1)},1e3);return()=>clearInterval(e)},[G]);let q=async(e=`modify school bank account settings`)=>{W(!0),K(``);try{return _e((await r.post(`/security/otp/request`,{action:`bank_account_update`,action_description:e})).data.masked_email||`School Proprietor Email`),ve(60),B(!0),!0}catch(e){return h(e?.response?.data?.message||`Unable to request security verification code.`),!1}finally{W(!1)}},we=async()=>{if(!V||V.length!==6){K(`Please enter the 6-digit code sent to the proprietor's email.`);return}xe(!0),K(``);try{Se&&await Se(V)}catch(e){K(e?.response?.data?.message||`Verification failed. Please check the code.`)}finally{xe(!1)}},J=()=>{b(null),T(``),C(``),k(``),D(``),N(`NGN`),F(!0),L(!0),z(0),j(!1)},Y=()=>{J(),v(!0)},Te=e=>{b(e),T(e.bank_name||``),C(e.bank_code||``),k(e.account_name||``),D(e.account_number||``),N(e.currency||`NGN`),F(o(e.is_active)),L(ie(e)||m===`online`),z(Number(e.sort_order??0)),j(!0),v(!0)},X=async()=>{c(!0),h(``);try{let[e,t]=await Promise.all([r.get(`/school/bank-accounts`),r.get(`/school/billing/settings`)]),n=t.data?.settings?.payment_mode===`online`?`online`:`offline`;le(n),ce((e.data||[]).map(e=>({...e,online_payment_enabled:n===`online`&&o(e.is_active)})))}catch(e){console.error(e),h(e?.response?.data?.message||`Failed to load bank accounts.`)}finally{c(!1)}};(0,i.useEffect)(()=>{X(),Ee()},[]);let Ee=async()=>{try{fe((await r.get(`/banks`)).data)}catch(e){console.error(e)}};(0,i.useEffect)(()=>{if(E.length!==10||!S){j(!1),k(``);return}let e=setTimeout(()=>{De()},500);return()=>clearTimeout(e)},[E,S]);let De=async()=>{try{me(!0),k((await r.get(`/bank-account/verify`,{params:{bank_code:S,account_number:E}})).data.account_name),j(!0)}catch{j(!1),k(``)}finally{me(!1)}},Oe=(0,i.useMemo)(()=>{let e=g.trim().toLowerCase(),t=p;return e?t.filter(t=>[t.bank_name,t.bank_code||``,t.account_name,t.account_number,t.currency||``].join(` `).toLowerCase().includes(e)):t},[p,g]),Z=(0,i.useMemo)(()=>p.filter(e=>o(e.is_active)).length,[p]);(0,i.useMemo)(()=>p.filter(e=>!o(e.is_active)).length,[p]);let Q=(0,i.useMemo)(()=>m===`online`?Z:0,[Z,m]),ke=(0,i.useMemo)(()=>m===`offline`?Z:0,[Z,m]),Ae=()=>{let e=[];w.trim()||e.push(`Bank name is required.`),O.trim()||e.push(`Account name is required.`),E.trim()||e.push(`Account number is required.`);let t=E.trim();return t&&(t.length<6||t.length>20)&&e.push(`Account number length looks invalid.`),M.trim().length<3&&e.push(`Currency is invalid.`),e.length?(h(e.join(` `)),!1):!0},je=async e=>{if(h(``),Ae()){u(!0);try{let t=typeof e==`string`&&e.trim().length>0?e.trim():void 0,n={bank_name:w.trim(),bank_code:S.trim()||null,account_name:O.trim(),account_number:E.trim(),currency:M.trim()||`NGN`,is_active:P,online_payment_enabled:I,sort_order:Number.isFinite(R)?R:0};t&&(n.security_otp=t),y?.id?await r.put(`/school/bank-accounts/${y.id}`,n):await r.post(`/school/bank-accounts`,n),await X(),v(!1),B(!1),H(``),J()}catch(e){e?.response?.data?.otp_required?(h(``),K(``),Ce(()=>e=>je(e)),await q(y?.id?`Update Bank Account (${w} - ${E})`:`Connect New Bank Account (${w} - ${E})`)):(console.error(e),h(e?.response?.data?.message||`Failed to save bank account.`),K(e?.response?.data?.message||`Verification failed.`))}finally{u(!1)}}},$=async(e,t)=>{let n=typeof t==`string`&&t.trim().length>0?t.trim():void 0;if(!(!n&&!window.confirm(`Delete this bank account?\n\n${e.bank_name} - ${e.account_number}`))){f(e.id),h(``);try{await r.delete(`/school/bank-accounts/${e.id}`,{data:n?{security_otp:n}:void 0}),await X(),B(!1),H(``)}catch(t){t?.response?.data?.otp_required?(Ce(()=>t=>$(e,t)),await q(`Delete Bank Account (${e.bank_name} - ${e.account_number})`)):(console.error(t),h(t?.response?.data?.message||`Failed to delete bank account.`),K(t?.response?.data?.message||`Verification failed.`))}finally{f(null)}}},Me=async e=>{h(``);try{await r.put(`/school/bank-accounts/${e.id}`,{is_active:!o(e.is_active)}),await X()}catch(e){console.error(e),h(e?.response?.data?.message||`Unable to update status.`)}},Ne=async e=>{h(``),u(!0);let t=m===`online`?`offline`:`online`;try{t===`online`&&!e.paystack_subaccount_code?await r.put(`/school/bank-accounts/${e.id}`,{online_payment_enabled:!0}):await r.put(`/school/billing/settings`,{payment_mode:t}),await X()}catch(e){console.error(e),h(e?.response?.data?.message||`Unable to update payment mode.`)}finally{u(!1)}};return(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)(`style`,{children:`
        /* ======= SchoolBankAccountsPage - Modern SaaS style ======= */
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');
        .db-main {
          background: #F8FAFC;
          min-height: 100vh;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          padding: 24px 28px 0;
        }
        .db-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 18px;
          padding: 32px 36px;
          position: relative;
          overflow: hidden;
          margin: 10px 0 24px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
        }
        .db-hero-glow {
          position: absolute;
          top: -60px;
          right: -60px;
          width: 320px;
          height: 320px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.15) 0%, transparent 65%);
          pointer-events: none;
        }
        .db-hero-glow2 {
          position: absolute;
          bottom: -40px;
          left: 30%;
          width: 200px;
          height: 200px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(37, 99, 235, 0.10) 0%, transparent 70%);
          pointer-events: none;
        }
        .db-hero-inner {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 32px;
          flex-wrap: wrap;
        }
        @media (min-width: 768px) {.db-hero-inner { flex-wrap: nowrap; } }
        .db-session-badge {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.20);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius: 100px;
          padding: 4px 12px;
          margin-bottom: 12px;
        }
        .db-session-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #10B981;
          animation: dbPulse 2s ease infinite;
        }
        @keyframes dbPulse {
          0%,100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.4; transform: scale(1.5); }
        }
        .db-greeting {
          font-size: 26px;
          font-weight: 800;
          color: #fff;
          line-height: 1.1;
          margin-bottom: 8px;
        }
        .db-greeting em { font-style: normal; color: #FBBF24; }
        .db-hero-sub {
          font-size: 13.5px;
          color: #CBD5E1;
          line-height: 1.6;
          max-width: 680px;
          margin-bottom: 20px;
        }
        .db-hero-btns { display: flex; gap: 10px; flex-wrap: wrap; }
        .db-btn-gold {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 9px 18px;
          font-size: 13px;
          font-weight: 700;
          color: #FFFFFF;
          background: #D97706;
          border: none;
          border-radius: 10px;
          cursor: pointer;
          transition: all 0.2s ease;
          white-space: nowrap;
        }
        .db-btn-gold:hover { background: #B45309; transform: translateY(-1px); color: #FFFFFF; }
        .db-btn-gold:disabled { opacity: 0.55; cursor: not-allowed; transform: none; }
        .db-btn-outline {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 9px 18px;
          font-size: 13px;
          font-weight: 600;
          color: #FFFFFF;
          background: rgba(255, 255, 255, 0.10);
          border: 1px solid rgba(255, 255, 255, 0.20);
          border-radius: 10px;
          cursor: pointer;
          transition: all 0.2s ease;
          white-space: nowrap;
        }
        .db-btn-outline:hover { background: rgba(255, 255, 255, 0.18); color: #fff; }
        .db-btn-outline:disabled { opacity: 0.55; cursor: not-allowed; }
        .db-hero-stat-card {
          background: rgba(255, 255, 255, 0.08);
          border: 1px solid rgba(255, 255, 255, 0.15);
          backdrop-filter: blur(8px);
          border-radius: 14px;
          padding: 20px 24px;
          min-width: 320px;
          margin-left: auto;
          align-self: flex-end;
        }
        .db-hero-stat-row { display: flex; flex-direction: column; gap: 10px; }
        .db-hero-stat-item { display: flex; justify-content: space-between; align-items: center; gap: 16px; }
        .db-hero-stat-label { font-size: 12px; font-weight: 400; color: #CBD5E1; }
        .db-hero-stat-val { font-size: 20px; font-weight: 800; color: #FBBF24; }
        .db-panel {
          background: #fff;
          border: 1px solid #E2E8F0;
          border-radius: 16px;
          overflow: hidden;
          box-shadow: 0 4px 16px rgba(15,39,68,0.03);
          margin-bottom: 24px;
        }
        .db-panel-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 18px 20px;
          border-bottom: 1px solid #F1F5F9;
          gap: 12px;
          flex-wrap: wrap;
        }
        .db-panel-title {
          font-size: 16px;
          font-weight: 700;
          color: #0F2744;
          margin: 0;
        }
        .db-panel-sub {
          font-size: 11.5px;
          font-weight: 400;
          color: #64748B;
          margin: 0;
        }
       .db-refresh-btn {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 8px 14px;
          font-size: 12px;
          font-weight: 500;
          color: #7a6a5a;
          background: #f5f1eb;
          border: 1px solid #e5ddd3;
          border-radius: 10px;
          cursor: pointer;
          transition: background 0.2s;
          white-space: nowrap;
        }
       .db-refresh-btn:hover { background: #ede8e0; }
       .db-refresh-btn.active {
          background: #0f172a;
          border-color: #0f172a;
          color: #fff;
        }
       .db-refresh-btn:disabled { opacity: 0.5; cursor: not-allowed; }
       .db-pill {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          font-size: 12px;
          font-weight: 800;
          padding: 6px 10px;
          border-radius: 999px;
          white-space: nowrap;
          border: 1px solid rgba(0,0,0,0.06);
        }
       .db-muted { color: #9a8a7a; }
       .db-strong { font-weight: 900; color: #1a1a2e; }
       .db-card {
          border: 1px solid rgba(0,0,0,0.06);
          border-radius: 14px;
          background: #fff;
          box-shadow: 0 2px 10px rgba(15,23,42,0.04);
        }
       .db-rowcard {
          border: 1px solid rgba(0,0,0,0.06);
          border-radius: 14px;
          background: #fff;
          box-shadow: 0 2px 10px rgba(15,23,42,0.04);
          padding: 14px;
        }
       .db-iconbox {
          width: 40px;
          height: 40px;
          border-radius: 14px;
          display: flex;
          align-items: center;
          justify-content: center;
          border: 1px solid rgba(0,0,0,0.06);
          background: rgba(201,168,76,0.14);
          color: #c9a84c;
          flex: 0 0 auto;
        }
       .db-mini {
          font-size: 12px;
          color: #9a8a7a;
        }
       .db-segmented {
          display: inline-flex;
          background: #f5f1eb;
          border: 1px solid #e5ddd3;
          border-radius: 10px;
          padding: 4px;
          gap: 4px;
        }
       .db-segmented button {
          border: none;
          background: transparent;
          padding: 6px 14px;
          border-radius: 8px;
          font-size: 12px;
          font-weight: 600;
          color: #7a6a5a;
          cursor: pointer;
          transition: all 0.2s;
        }
       .db-segmented button.active {
          background: #fff;
          color: #1a1a2e;
          box-shadow: 0 1px 3px rgba(0,0,0,0.08);
        }
       .db-warning-banner {
          background: rgba(245,158,11,0.08);
          border: 1px solid rgba(245,158,11,0.2);
          border-radius: 12px;
          padding: 12px 16px;
          display: flex;
          gap: 12px;
          align-items: start;
          margin-bottom: 16px;
        }
        @media (max-width: 991.98px) {.db-main { padding: 18px 14px 0; } }
      `}),(0,a.jsx)(ne,{sidebarOpen:e,setSidebarOpen:t}),(0,a.jsx)(n,{title:`Bank Details`}),(0,a.jsx)(`div`,{className:`container-fluid`,children:(0,a.jsxs)(`div`,{className:`row`,children:[(0,a.jsx)(te,{sidebarOpen:e}),(0,a.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto db-main`,children:[s&&(0,a.jsx)(ee,{message:`Loading school bank accounts...`}),(0,a.jsxs)(`div`,{className:`db-hero`,children:[(0,a.jsx)(`div`,{className:`db-hero-glow`,"aria-hidden":`true`}),(0,a.jsx)(`div`,{className:`db-hero-glow2`,"aria-hidden":`true`}),(0,a.jsxs)(`div`,{className:`db-hero-inner`,children:[(0,a.jsxs)(`div`,{children:[(0,a.jsxs)(`div`,{className:`db-session-badge`,children:[(0,a.jsx)(`span`,{className:`db-session-dot`}),`Settings — Bank Transfer`]}),(0,a.jsxs)(`h1`,{className:`db-greeting`,children:[`School `,(0,a.jsx)(`em`,{children:`Bank Accounts`})]}),(0,a.jsx)(`p`,{className:`db-hero-sub`,children:`Manage the bank accounts parents can use for school fee payments.`}),(0,a.jsxs)(`div`,{className:`db-hero-btns`,children:[(0,a.jsxs)(`button`,{className:`db-btn-gold`,type:`button`,onClick:Y,disabled:s||l,children:[(0,a.jsx)(`i`,{className:`bi bi-plus-lg`}),`Add bank account`]}),(0,a.jsxs)(`button`,{className:`db-btn-outline`,type:`button`,onClick:X,disabled:s,children:[(0,a.jsx)(`i`,{className:`bi bi-arrow-clockwise`}),`Refresh`]})]})]}),(0,a.jsx)(`div`,{className:`db-hero-stat-card d-none d-md-block`,children:(0,a.jsxs)(`div`,{className:`db-hero-stat-row`,children:[(0,a.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,a.jsx)(`span`,{className:`db-hero-stat-label`,children:`Total Active`}),(0,a.jsx)(`span`,{className:`db-hero-stat-val`,children:Z})]}),(0,a.jsx)(`div`,{style:{height:1,background:`rgba(255,255,255,0.06)`}}),(0,a.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,a.jsx)(`span`,{className:`db-hero-stat-label`,children:`Online Enabled`}),(0,a.jsx)(`span`,{className:`db-hero-stat-val`,children:Q})]}),(0,a.jsx)(`div`,{style:{height:1,background:`rgba(255,255,255,0.06)`}}),(0,a.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,a.jsx)(`span`,{className:`db-hero-stat-label`,children:`Offline Only`}),(0,a.jsx)(`span`,{className:`db-hero-stat-val`,children:ke})]})]})})]})]}),Q===0&&Z>0&&(0,a.jsxs)(`div`,{className:`db-warning-banner`,children:[(0,a.jsx)(`i`,{className:`bi bi-exclamation-triangle`,style:{color:`#f59e0b`,fontSize:18}}),(0,a.jsxs)(`div`,{children:[(0,a.jsx)(`div`,{className:`db-strong`,style:{fontSize:13,marginBottom:2},children:`Online Payment Disabled`}),(0,a.jsx)(`div`,{className:`db-mini`,children:`Parents will only see bank transfer option at checkout. Enable online payment on at least one account to accept cards.`})]})]}),ue&&(0,a.jsxs)(`div`,{className:`alert alert-danger`,role:`alert`,style:{borderRadius:14},children:[(0,a.jsx)(`i`,{className:`bi bi-exclamation-triangle me-2`}),ue]}),(0,a.jsxs)(`div`,{className:`row g-3`,children:[(0,a.jsxs)(`div`,{className:`col-12 col-lg-7`,children:[(0,a.jsxs)(`div`,{className:`db-panel`,children:[(0,a.jsxs)(`div`,{className:`db-panel-head`,children:[(0,a.jsxs)(`div`,{children:[(0,a.jsx)(`p`,{className:`db-panel-title`,children:`Accounts`}),(0,a.jsx)(`p`,{className:`db-panel-sub`,children:`Search, update account status, edit or delete.`})]}),(0,a.jsx)(`div`,{className:`d-flex align-items-center gap-2 flex-wrap`,children:(0,a.jsxs)(`div`,{className:`input-group`,style:{width:280},children:[(0,a.jsx)(`span`,{className:`input-group-text bg-white`,style:{borderRadius:`10px 0 0 10px`},children:(0,a.jsx)(`i`,{className:`bi bi-search`})}),(0,a.jsx)(`input`,{className:`form-control`,placeholder:`Search bank / account...`,value:g,onChange:e=>de(e.target.value),style:{borderRadius:`0 10px 10px 0`}})]})})]}),(0,a.jsx)(`div`,{style:{padding:16},children:Oe.length===0?(0,a.jsxs)(`div`,{className:`text-center py-5`,children:[(0,a.jsx)(`div`,{className:`mx-auto mb-3 d-flex align-items-center justify-content-center`,style:{width:56,height:56,borderRadius:16,background:`rgba(201,168,76,0.14)`,color:`#c9a84c`,border:`1px solid rgba(0,0,0,0.06)`},children:(0,a.jsx)(`i`,{className:`bi bi-bank fs-3`})}),(0,a.jsx)(`div`,{className:`fw-semibold`,style:{color:`#1a1a2e`},children:`No bank accounts found`}),(0,a.jsx)(`div`,{className:`db-muted mb-3`,children:`Add one to allow parents pay via bank transfer.`}),(0,a.jsxs)(`button`,{className:`db-btn-gold`,type:`button`,onClick:Y,children:[(0,a.jsx)(`i`,{className:`bi bi-plus-lg`}),`Add bank account`]})]}):(0,a.jsx)(`div`,{className:`d-flex flex-column gap-2`,children:Oe.map(e=>{let t=o(e.is_active),n=m===`online`&&t;return(0,a.jsx)(`div`,{className:`db-rowcard`,children:(0,a.jsxs)(`div`,{className:`d-flex justify-content-between gap-3 flex-wrap`,children:[(0,a.jsxs)(`div`,{className:`d-flex gap-12`,style:{gap:12,minWidth:260},children:[(0,a.jsx)(`div`,{className:`db-iconbox`,style:{background:t?`rgba(34,197,94,0.14)`:`rgba(148,163,184,0.18)`,color:t?`#22c55e`:`#64748b`},children:(0,a.jsx)(`i`,{className:`bi bi-bank`})}),(0,a.jsxs)(`div`,{children:[(0,a.jsx)(`div`,{className:`d-flex align-items-center gap-2 flex-wrap`,children:(0,a.jsx)(`div`,{className:`db-strong`,style:{fontWeight:900},children:e.bank_name})}),(0,a.jsxs)(`div`,{className:`db-mini`,children:[`Currency: `,(0,a.jsx)(`b`,{style:{color:`#1a1a2e`},children:e.currency||`NGN`}),` • Sort:`,` `,(0,a.jsx)(`b`,{style:{color:`#1a1a2e`},children:e.sort_order??0})]}),(0,a.jsxs)(`div`,{style:{marginTop:10},children:[(0,a.jsx)(`div`,{className:`db-mini`,children:`Account name`}),(0,a.jsx)(`div`,{className:`db-strong`,style:{fontWeight:800},children:e.account_name})]}),(0,a.jsxs)(`div`,{style:{marginTop:8},children:[(0,a.jsx)(`div`,{className:`db-mini`,children:`Account number`}),(0,a.jsxs)(`div`,{className:`d-flex align-items-center gap-2 flex-wrap`,children:[(0,a.jsx)(`code`,{style:{fontSize:13,padding:`4px 8px`,borderRadius:10,background:`#f5f1eb`,border:`1px solid #e5ddd3`},children:e.account_number}),(0,a.jsxs)(`button`,{type:`button`,className:`db-refresh-btn`,onClick:async()=>{await oe(e.account_number)||alert(`Failed to copy. Please copy manually.`)},children:[(0,a.jsx)(`i`,{className:`bi bi-clipboard`}),`Copy`]}),(0,a.jsxs)(`span`,{className:`db-mini`,children:[`Masked: `,(0,a.jsx)(`code`,{style:{fontSize:12},children:ae(e.account_number)})]})]})]})]})]}),(0,a.jsxs)(`div`,{className:`ms-auto d-flex flex-column align-items-end gap-2`,children:[(0,a.jsxs)(`span`,{className:`db-pill`,style:{background:t?`rgba(34,197,94,0.14)`:`rgba(245,158,11,0.14)`,color:t?`#22c55e`:`#f59e0b`},children:[(0,a.jsx)(`i`,{className:`bi ${t?`bi-check-circle`:`bi-exclamation-circle`}`}),t?`ACTIVE`:`INACTIVE`]}),(0,a.jsxs)(`div`,{className:`d-flex gap-2 flex-wrap justify-content-end`,children:[(0,a.jsxs)(`button`,{type:`button`,className:`db-refresh-btn`,onClick:()=>Ne(e),disabled:s||l||d===e.id,title:n?`Disable online payment collection`:`Enable online payment collection`,style:{borderColor:n?`rgba(99,102,241,0.25)`:`rgba(34,197,94,0.25)`,background:n?`rgba(99,102,241,0.06)`:`rgba(34,197,94,0.06)`,color:n?`#6366f1`:`#15803d`},children:[(0,a.jsx)(`i`,{className:`bi ${n?`bi-toggle-on`:`bi-lightning-charge`}`}),n?`Disable online`:`Enable online`]}),(0,a.jsxs)(`button`,{type:`button`,className:`db-refresh-btn`,onClick:()=>Me(e),disabled:s||l||d===e.id,title:`Toggle active`,children:[(0,a.jsx)(`i`,{className:`bi ${t?`bi-pause-circle`:`bi-play-circle`}`}),t?`Deactivate`:`Activate`]}),(0,a.jsxs)(`button`,{type:`button`,className:`db-refresh-btn`,onClick:()=>Te(e),disabled:s||l||d===e.id,children:[(0,a.jsx)(`i`,{className:`bi bi-pencil-square`}),`Edit`]}),(0,a.jsx)(`button`,{type:`button`,className:`db-refresh-btn`,style:{borderColor:`rgba(239,68,68,0.25)`,background:`rgba(239,68,68,0.06)`,color:`#b91c1c`},onClick:()=>$(e),disabled:d===e.id||s||l,children:d===e.id?(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)(`span`,{className:`spinner-border spinner-border-sm`}),`Deleting…`]}):(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)(`i`,{className:`bi bi-trash`}),`Delete`]})})]}),(0,a.jsxs)(`div`,{className:`db-mini text-end`,children:[`Updated: `,(0,a.jsx)(`b`,{style:{color:`#1a1a2e`},children:se(e.updated_at)})]})]})]})},e.id)})})})]}),(0,a.jsxs)(`div`,{className:`db-panel`,children:[(0,a.jsx)(`div`,{className:`db-panel-head`,children:(0,a.jsxs)(`div`,{children:[(0,a.jsx)(`p`,{className:`db-panel-title`,children:`Tip for parents`}),(0,a.jsx)(`p`,{className:`db-panel-sub`,children:`Optional guidance you can show on the payment page.`})]})}),(0,a.jsx)(`div`,{style:{padding:16},children:(0,a.jsx)(`div`,{className:`db-card`,style:{padding:14,background:`#faf8f5`},children:(0,a.jsxs)(`div`,{className:`d-flex align-items-start gap-3`,children:[(0,a.jsx)(`div`,{className:`db-iconbox`,style:{background:`rgba(34,197,94,0.14)`,color:`#22c55e`},children:(0,a.jsx)(`i`,{className:`bi bi-info-circle`})}),(0,a.jsxs)(`div`,{children:[(0,a.jsx)(`div`,{className:`db-strong`,children:`Use a clear narration`}),(0,a.jsx)(`div`,{className:`db-muted`,style:{fontSize:13},children:`Encourage parents to include student Reg No + Term in narration, then upload receipt for approval.`}),(0,a.jsxs)(`div`,{className:`db-mini`,style:{marginTop:8},children:[`Example: `,(0,a.jsx)(`code`,{children:`GQ-REG1234-2ndTerm-2025/2026`})]})]})]})})})]})]}),(0,a.jsxs)(`div`,{className:`col-12 col-lg-5`,children:[(0,a.jsxs)(`div`,{className:`db-panel`,children:[(0,a.jsxs)(`div`,{className:`db-panel-head`,children:[(0,a.jsxs)(`div`,{children:[(0,a.jsx)(`p`,{className:`db-panel-title`,children:y?`Edit bank account`:`Add bank account`}),(0,a.jsx)(`p`,{className:`db-panel-sub`,children:`Only active accounts show to parents.`})]}),(0,a.jsx)(`div`,{className:`d-flex gap-2 flex-wrap`,children:(0,a.jsx)(`button`,{type:`button`,className:`db-refresh-btn`,onClick:()=>{_?(v(!1),J()):Y()},disabled:l||s,children:_?(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)(`i`,{className:`bi bi-x-lg`}),`Close`]}):(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)(`i`,{className:`bi bi-plus-lg`}),`New`]})})})]}),(0,a.jsx)(`div`,{style:{padding:16},children:_?(0,a.jsxs)(`div`,{className:`row g-3`,children:[(0,a.jsxs)(`div`,{className:`col-12`,children:[(0,a.jsx)(`label`,{className:`form-label fw-semibold`,children:`Bank`}),(0,a.jsxs)(`select`,{className:`form-select`,value:S,onChange:e=>{let t=x.find(t=>t.code===e.target.value);C(t?.code||``),T(t?.name||``)},style:{borderRadius:12},disabled:l,children:[(0,a.jsx)(`option`,{value:``,children:`Select Bank`}),x.map(e=>(0,a.jsx)(`option`,{value:e.code,children:e.name},e.code))]})]}),(0,a.jsxs)(`div`,{className:`col-12 col-md-6`,children:[(0,a.jsx)(`label`,{className:`form-label fw-semibold small mb-1`,children:`Currency`}),(0,a.jsx)(`input`,{className:`form-control`,value:M,onChange:e=>N(e.target.value),placeholder:`NGN`,style:{borderRadius:12},disabled:l})]}),(0,a.jsxs)(`div`,{className:`col-12`,children:[(0,a.jsx)(`label`,{className:`form-label fw-semibold small mb-1`,children:`Account number`}),(0,a.jsx)(`input`,{className:`form-control`,value:E,onChange:e=>D(e.target.value),placeholder:`e.g. 0123456789`,style:{borderRadius:12,letterSpacing:.7},disabled:l}),(0,a.jsxs)(`div`,{className:`db-mini`,style:{marginTop:6},children:[`Preview masked: `,(0,a.jsx)(`code`,{children:ae(E)})]})]}),(0,a.jsxs)(`div`,{className:`col-12`,children:[(0,a.jsx)(`label`,{className:`form-label fw-semibold small mb-1`,children:`Account name`}),(0,a.jsx)(`input`,{className:`form-control`,value:O,readOnly:!0,style:{background:`#f8f9fa`}})]}),pe&&(0,a.jsxs)(`div`,{className:`text-primary small mt-2`,children:[(0,a.jsx)(`span`,{className:`spinner-border spinner-border-sm me-2`}),`Verifying account...`]}),A&&(0,a.jsxs)(`div`,{className:`text-success small mt-2`,children:[(0,a.jsx)(`i`,{className:`bi bi-check-circle-fill me-2`}),`Verified account`]}),!A&&E.length===10&&!pe&&(0,a.jsxs)(`div`,{className:`text-danger small mt-2`,children:[(0,a.jsx)(`i`,{className:`bi bi-x-circle-fill me-2`}),`Invalid account details`]}),(0,a.jsxs)(`div`,{className:`col-12`,children:[(0,a.jsx)(`label`,{className:`form-label fw-semibold small mb-1`,children:`Payment Mode`}),(0,a.jsx)(`div`,{className:`db-card`,style:{padding:12,background:`#faf8f5`},children:(0,a.jsxs)(`div`,{className:`d-flex justify-content-between align-items-start gap-3 mb-2`,children:[(0,a.jsxs)(`div`,{children:[(0,a.jsx)(`div`,{className:`fw-semibold`,style:{fontSize:13,color:`#1a1a2e`},children:`Enable Online Payment`}),(0,a.jsx)(`div`,{className:`db-mini`,children:`If enabled, parents can pay with card via Paystack to this account.`})]}),(0,a.jsx)(`div`,{className:`form-check form-switch m-0`,children:(0,a.jsx)(`input`,{className:`form-check-input`,type:`checkbox`,role:`switch`,checked:I,onChange:e=>L(e.target.checked),id:`bankAcctOnlineSwitch`,disabled:l,style:{width:44,height:24,cursor:`pointer`}})})]})})]}),(0,a.jsxs)(`div`,{className:`col-12 col-md-6`,children:[(0,a.jsx)(`label`,{className:`form-label fw-semibold small mb-1`,children:`Sort order`}),(0,a.jsx)(`input`,{type:`number`,className:`form-control`,value:R,onChange:e=>z(parseInt(e.target.value||`0`,10)),min:0,max:1e3,style:{borderRadius:12},disabled:l}),(0,a.jsx)(`div`,{className:`db-mini`,style:{marginTop:6},children:`Lower values appear first.`})]}),(0,a.jsxs)(`div`,{className:`col-12 col-md-6`,children:[(0,a.jsx)(`label`,{className:`form-label fw-semibold small mb-1`,children:`Status`}),(0,a.jsxs)(`div`,{className:`db-card`,style:{padding:12,background:`#faf8f5`},children:[(0,a.jsxs)(`div`,{className:`form-check form-switch m-0`,children:[(0,a.jsx)(`input`,{className:`form-check-input`,type:`checkbox`,role:`switch`,checked:P,onChange:e=>F(e.target.checked),id:`bankAcctActiveSwitch`,disabled:l,style:{width:44,height:24,cursor:`pointer`}}),(0,a.jsx)(`label`,{className:`form-check-label fw-semibold`,htmlFor:`bankAcctActiveSwitch`,children:`Active (visible)`})]}),(0,a.jsx)(`div`,{className:`db-mini`,style:{marginTop:6},children:`Inactive accounts won't show to parents.`})]})]}),(0,a.jsxs)(`div`,{className:`col-12 d-flex gap-2 pt-2`,children:[(0,a.jsxs)(`button`,{type:`button`,className:`db-refresh-btn`,onClick:()=>{J(),v(!1)},disabled:l,children:[(0,a.jsx)(`i`,{className:`bi bi-x-circle`}),`Cancel`]}),(0,a.jsx)(`button`,{type:`button`,className:`db-btn-gold ms-auto`,onClick:()=>je(),style:{borderRadius:12,padding:`10px 14px`},disabled:l||!A,children:l?(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)(`span`,{className:`spinner-border spinner-border-sm`}),`Saving…`]}):(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)(`i`,{className:`bi bi-save2`}),`Save`]})})]}),y?.id&&(0,a.jsx)(`div`,{className:`col-12`,children:(0,a.jsxs)(`div`,{className:`db-mini`,children:[`Editing ID: `,(0,a.jsx)(`code`,{children:y.id})]})})]}):(0,a.jsxs)(`div`,{className:`db-muted`,children:[`Click `,(0,a.jsx)(`b`,{children:`New`}),` to add an account, or `,(0,a.jsx)(`b`,{children:`Edit`}),` on an existing one.`]})})]}),(0,a.jsxs)(`div`,{className:`db-panel`,children:[(0,a.jsx)(`div`,{className:`db-panel-head`,children:(0,a.jsxs)(`div`,{children:[(0,a.jsx)(`p`,{className:`db-panel-title`,children:`Safety note`}),(0,a.jsx)(`p`,{className:`db-panel-sub`,children:`Avoid exposing sensitive details unnecessarily.`})]})}),(0,a.jsx)(`div`,{style:{padding:16},children:(0,a.jsx)(`div`,{className:`db-card`,style:{padding:14,background:`#faf8f5`},children:(0,a.jsx)(`div`,{className:`db-muted`,style:{fontSize:13},children:`Only share official school accounts. If you rotate an account, deactivate the old one to prevent parents sending funds to the wrong place.`})})})]})]})]}),(0,a.jsx)(`div`,{className:`mt-auto`,children:(0,a.jsx)(re,{})}),he&&(0,a.jsx)(`div`,{className:`modal fade show d-block`,style:{backgroundColor:`rgba(0,0,0,0.65)`,zIndex:1050},children:(0,a.jsx)(`div`,{className:`modal-dialog modal-dialog-centered`,style:{maxWidth:460},children:(0,a.jsxs)(`div`,{className:`modal-content`,style:{borderRadius:16,border:`1px solid rgba(211,0,176,0.25)`,overflow:`hidden`,boxShadow:`0 20px 50px rgba(0,0,0,0.3)`},children:[(0,a.jsxs)(`div`,{className:`modal-header text-white p-3 border-0`,style:{background:`linear-gradient(135deg, #0d0614 0%, #1e092b 100%)`},children:[(0,a.jsxs)(`h5`,{className:`modal-title fs-6 fw-bold text-white d-flex align-items-center gap-2 m-0`,children:[(0,a.jsx)(`i`,{className:`bi bi-shield-lock-fill`,style:{color:`#ffc857`}}),`School Proprietor Security Guard`]}),(0,a.jsx)(`button`,{type:`button`,className:`btn-close btn-close-white`,onClick:()=>B(!1)})]}),(0,a.jsxs)(`div`,{className:`modal-body p-4 text-center`,children:[(0,a.jsxs)(`div`,{className:`badge bg-warning text-dark px-3 py-2 mb-3 rounded-pill fw-bold`,style:{fontSize:`12px`},children:[(0,a.jsx)(`i`,{className:`bi bi-exclamation-triangle-fill me-1`}),` High-Security Verification`]}),(0,a.jsx)(`h6`,{className:`fw-bold mb-2 text-dark`,children:`Confirm School Bank Account Details`}),(0,a.jsxs)(`p`,{className:`text-muted small mb-3`,children:[`To protect school fee payments from unauthorized alterations, a `,(0,a.jsx)(`strong`,{children:`6-digit security verification code`}),` has been sent to the school proprietor's email:`,(0,a.jsx)(`br`,{}),(0,a.jsx)(`span`,{className:`badge bg-light text-dark border mt-2 px-3 py-1 fs-7`,children:ge||`Proprietor Email`})]}),(0,a.jsx)(`div`,{className:`my-3`,children:(0,a.jsx)(`input`,{type:`text`,maxLength:6,className:`form-control form-control-lg text-center fw-bold fs-2 letter-spacing-4`,style:{letterSpacing:`8px`,borderRadius:12,border:`2px solid #d300b0`,color:`#1a1a2e`},value:V,onChange:e=>H(e.target.value.replace(/\D/g,``)),placeholder:`000000`,autoFocus:!0})}),ye&&(0,a.jsx)(`div`,{className:`alert alert-danger py-2 px-3 small`,children:ye}),(0,a.jsxs)(`div`,{className:`d-flex justify-content-between align-items-center mt-3 pt-2`,children:[(0,a.jsx)(`button`,{type:`button`,className:`btn btn-link btn-sm text-decoration-none p-0`,disabled:G>0||U,onClick:()=>q(`resend verification code for bank account`),children:U?`Sending code...`:G>0?`Resend code in ${G}s`:`Resend Code`}),(0,a.jsx)(`button`,{type:`button`,className:`db-btn-gold px-4 fw-bold`,style:{borderRadius:10,padding:`9px 18px`},disabled:V.length!==6||be,onClick:we,children:be?`Verifying...`:`Confirm & Save`})]})]})]})})})]})]})})]})}export{s as default};