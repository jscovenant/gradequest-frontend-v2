import{i as e}from"./rolldown-runtime-CWU8vmCm.js";import{Ut as t}from"./vendor-misc-OZLc0tLq.js";import{p as n}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as r,E as i,P as a,d as o,f as s,l as c,u as l}from"./index-D6TxbaCx.js";var u=e(t(),1),d=n();function f(){let{showToast:e}=c(),[t,n]=(0,u.useState)(!1),[f,p]=(0,u.useState)([]),[m,h]=(0,u.useState)(!0),[g,_]=(0,u.useState)(``),[v,y]=(0,u.useState)(!1),[b,x]=(0,u.useState)(!1),[S,C]=(0,u.useState)({firstname:``,surname:``,email:``,phone:``,operator_title:`Desk Officer / Portal Operator`}),[w,T]=(0,u.useState)(null),[E,D]=(0,u.useState)(null),[O,k]=(0,u.useState)({firstname:``,surname:``,phone:``,operator_title:``}),[A,j]=(0,u.useState)(!1),[M,N]=(0,u.useState)(null),[P,F]=(0,u.useState)(null),[I,L]=(0,u.useState)(!1),R=async()=>{h(!0);try{p((await a.get(`/school/operators`)).data.operators||[])}catch(t){e(t?.response?.data?.message||`Failed to load school operators.`,`error`)}finally{h(!1)}};(0,u.useEffect)(()=>{R()},[]);let z=(0,u.useMemo)(()=>{let e=g.trim().toLowerCase();return e?f.filter(t=>t.firstname.toLowerCase().includes(e)||t.surname.toLowerCase().includes(e)||t.email.toLowerCase().includes(e)||t.phone&&t.phone.includes(e)||t.operator_title&&t.operator_title.toLowerCase().includes(e)):f},[f,g]),B=(0,u.useMemo)(()=>f.filter(e=>e.status===1).length,[f]),V=(0,u.useMemo)(()=>f.filter(e=>e.status===0).length,[f]),H=async t=>{if(t.preventDefault(),!S.firstname.trim()||!S.surname.trim()||!S.email.trim()){e(`Firstname, surname, and email are required.`,`error`);return}x(!0);try{let t=await a.post(`/school/operators`,S);e(t.data.message||`Operator registered successfully!`,`success`),y(!1),T({name:`${S.firstname} ${S.surname}`,email:S.email,pass:t.data.temporary_password}),C({firstname:``,surname:``,email:``,phone:``,operator_title:`Desk Officer / Portal Operator`}),R()}catch(t){e(t?.response?.data?.message||`Failed to register operator.`,`error`)}finally{x(!1)}},U=e=>{D(e),k({firstname:e.firstname,surname:e.surname,phone:e.phone||``,operator_title:e.operator_title||`Desk Officer`})},W=async t=>{if(t.preventDefault(),E){j(!0);try{e((await a.put(`/school/operators/${E.id}`,O)).data.message||`Operator updated successfully.`,`success`),D(null),R()}catch(t){e(t?.response?.data?.message||`Failed to update operator.`,`error`)}finally{j(!1)}}},G=async t=>{let n=t.status===1?`Deactivate operator ${t.firstname} ${t.surname}?\n\nThey will be logged out immediately across all devices.`:`Activate operator ${t.firstname} ${t.surname}?`;if(window.confirm(n))try{e((await a.patch(`/school/operators/${t.id}/toggle-status`)).data.message||`Operator status updated.`,`success`),R()}catch(t){e(t?.response?.data?.message||`Failed to update status.`,`error`)}},K=async t=>{N(t),F(null),L(!0);try{let n=await a.post(`/school/operators/${t.id}/reset-password`);F(n.data.temporary_password),e(n.data.message||`Password reset successfully.`,`success`)}catch(t){e(t?.response?.data?.message||`Failed to reset password.`,`error`),N(null)}finally{L(!1)}},q=async t=>{if(window.confirm(`Permanently delete operator ${t.firstname} ${t.surname}?\n\nThis action cannot be undone.`))try{e((await a.delete(`/school/operators/${t.id}`)).data.message||`Operator removed.`,`success`),R()}catch(t){e(t?.response?.data?.message||`Failed to delete operator.`,`error`)}},J=t=>{navigator.clipboard.writeText(t),e(`Copied to clipboard!`,`success`)};return(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');
        .db-main {
          background: #F8FAFC;
          min-height: 100vh;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          padding: 24px 28px 0;
        }
        .db-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 18px;
          padding: 32px 36px;
          position: relative;
          overflow: hidden;
          margin: 10px 0 24px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
        }
        .db-hero-glow {
          position: absolute;
          top: -60px;
          right: -60px;
          width: 320px;
          height: 320px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.15) 0%, transparent 65%);
          pointer-events: none;
        }
        .db-hero-glow2 {
          position: absolute;
          bottom: -40px;
          left: 30%;
          width: 200px;
          height: 200px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(37, 99, 235, 0.10) 0%, transparent 70%);
          pointer-events: none;
        }
        .db-hero-inner {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 32px;
          flex-wrap: wrap;
        }
        @media (min-width: 768px) { .db-hero-inner { flex-wrap: nowrap; } }
        .db-session-badge {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.20);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius: 100px;
          padding: 4px 12px;
          margin-bottom: 12px;
        }
        .db-session-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #10B981;
          display: inline-block;
        }
        .db-hero-title {
          font-size: 26px;
          font-weight: 800;
          color: #fff;
          margin: 0 0 6px;
          line-height: 1.2;
        }
        .db-hero-sub {
          font-size: 13.5px;
          color: #CBD5E1;
          margin: 0;
          max-width: 620px;
          line-height: 1.6;
        }
        .db-btn-gold {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          background: #D97706;
          color: #FFFFFF;
          font-size: 13.5px;
          font-weight: 700;
          border: none;
          border-radius: 10px;
          padding: 9px 18px;
          cursor: pointer;
          transition: all .2s ease;
        }
        .db-btn-gold:hover {
          background: #B45309;
          transform: translateY(-1px);
          color: #FFFFFF;
        }
          padding: 12px 20px;
          cursor: pointer;
          transition: all 0.2s;
          white-space: nowrap;
          text-decoration: none;
        }
        .db-btn-gold:hover {
          background: #e8c97a;
          color: #0f172a;
          transform: translateY(-1px);
        }
        .gq-stat-badge {
          background: rgba(255,255,255,0.06);
          border: 1px solid rgba(255,255,255,0.12);
          border-radius: 10px;
          padding: 6px 14px;
          color: #fff;
          font-size: 12.5px;
        }
        .gq-card {
          background: #fff;
          border-radius: 14px;
          border: 1px solid #e2e8f0;
          box-shadow: 0 2px 8px rgba(0,0,0,0.04);
          overflow: hidden;
        }
        .gq-avatar {
          width: 38px;
          height: 38px;
          border-radius: 50%;
          background: #f1f5f9;
          color: #475569;
          font-weight: 700;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          font-size: 14px;
        }
        @media (max-width: 991.98px) {
          .db-main { padding: 18px 14px 0; }
        }
      `}),(0,d.jsx)(s,{sidebarOpen:t,setSidebarOpen:n}),(0,d.jsx)(r,{title:`School Operators & Delegated Managers | SchoolProfit`}),(0,d.jsx)(`div`,{className:`container-fluid`,children:(0,d.jsxs)(`div`,{className:`row`,children:[(0,d.jsx)(o,{sidebarOpen:t,setSidebarOpen:n}),(0,d.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto px-3 px-md-4 db-main`,children:[m&&(0,d.jsx)(i,{message:`Loading school operators...`}),(0,d.jsxs)(`div`,{className:`db-hero`,children:[(0,d.jsx)(`div`,{className:`db-hero-glow`,"aria-hidden":`true`}),(0,d.jsx)(`div`,{className:`db-hero-glow2`,"aria-hidden":`true`}),(0,d.jsxs)(`div`,{className:`db-hero-inner`,children:[(0,d.jsxs)(`div`,{children:[(0,d.jsxs)(`div`,{className:`db-session-badge`,children:[(0,d.jsx)(`span`,{className:`db-session-dot`}),`School Management — Safe Delegation`]}),(0,d.jsx)(`h1`,{className:`db-hero-title`,children:`School Operators & Portal Managers`}),(0,d.jsx)(`p`,{className:`db-hero-sub`,children:`Assign secretaries, IT teachers, and desk clerks to register students, upload results, and manage CBT exams—without exposing your proprietor master credentials or bank accounts.`}),(0,d.jsxs)(`div`,{className:`d-flex gap-2 flex-wrap mt-3`,children:[(0,d.jsxs)(`div`,{className:`gq-stat-badge`,children:[`Total Operators: `,(0,d.jsx)(`strong`,{className:`text-warning`,children:f.length})]}),(0,d.jsxs)(`div`,{className:`gq-stat-badge`,children:[`Active: `,(0,d.jsx)(`strong`,{className:`text-success`,children:B})]}),V>0&&(0,d.jsxs)(`div`,{className:`gq-stat-badge`,children:[`Deactivated: `,(0,d.jsx)(`strong`,{className:`text-danger`,children:V})]})]})]}),(0,d.jsx)(`div`,{children:(0,d.jsxs)(`button`,{className:`db-btn-gold`,onClick:()=>y(!0),children:[(0,d.jsx)(`i`,{className:`bi bi-person-plus-fill`}),`+ Add School Operator`]})})]})]}),(0,d.jsxs)(`div`,{className:`gq-card p-3 p-md-4 mb-4`,children:[(0,d.jsxs)(`div`,{className:`d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3`,children:[(0,d.jsxs)(`div`,{className:`input-group`,style:{maxWidth:360},children:[(0,d.jsx)(`span`,{className:`input-group-text bg-light border-end-0`,children:(0,d.jsx)(`i`,{className:`bi bi-search text-muted`})}),(0,d.jsx)(`input`,{type:`text`,className:`form-control border-start-0 ps-0`,placeholder:`Search operator name, email, role...`,value:g,onChange:e=>_(e.target.value)})]}),(0,d.jsxs)(`button`,{className:`btn btn-outline-secondary btn-sm`,onClick:R,disabled:m,children:[(0,d.jsx)(`i`,{className:`bi bi-arrow-clockwise me-1`}),`Refresh`]})]}),m?(0,d.jsx)(`div`,{className:`text-center py-5`,children:(0,d.jsx)(`p`,{className:`text-muted small mt-2`,children:`Loading school operators...`})}):z.length===0?(0,d.jsxs)(`div`,{className:`text-center py-5`,children:[(0,d.jsx)(`i`,{className:`bi bi-people text-muted`,style:{fontSize:42}}),(0,d.jsx)(`h6`,{className:`fw-bold mt-2 text-dark`,children:`No School Operators Added Yet`}),(0,d.jsx)(`p`,{className:`text-muted small`,style:{maxWidth:450,margin:`0 auto 16px`},children:`Create dedicated logins for your desk officers and computer operators to manage school operations safely.`}),(0,d.jsxs)(`button`,{className:`db-btn-gold`,onClick:()=>y(!0),children:[(0,d.jsx)(`i`,{className:`bi bi-person-plus-fill`}),` Add First Operator`]})]}):(0,d.jsx)(`div`,{className:`table-responsive`,children:(0,d.jsxs)(`table`,{className:`table table-hover align-middle mb-0`,children:[(0,d.jsx)(`thead`,{className:`table-light small text-uppercase`,style:{fontSize:11,letterSpacing:`0.5px`},children:(0,d.jsxs)(`tr`,{children:[(0,d.jsx)(`th`,{children:`Operator`}),(0,d.jsx)(`th`,{children:`Role Title`}),(0,d.jsx)(`th`,{children:`Contact Details`}),(0,d.jsx)(`th`,{children:`Status`}),(0,d.jsx)(`th`,{children:`Registered`}),(0,d.jsx)(`th`,{className:`text-end`,children:`Actions`})]})}),(0,d.jsx)(`tbody`,{children:z.map(e=>(0,d.jsxs)(`tr`,{children:[(0,d.jsx)(`td`,{children:(0,d.jsxs)(`div`,{className:`d-flex align-items-center gap-2`,children:[(0,d.jsxs)(`div`,{className:`gq-avatar`,children:[e.firstname.charAt(0),e.surname.charAt(0)]}),(0,d.jsxs)(`div`,{children:[(0,d.jsxs)(`div`,{className:`fw-bold text-dark`,children:[e.firstname,` `,e.surname]}),(0,d.jsx)(`small`,{className:`text-muted`,children:e.email})]})]})}),(0,d.jsx)(`td`,{children:(0,d.jsx)(`span`,{className:`badge bg-light text-dark border px-2 py-1`,children:e.operator_title||`Desk Officer`})}),(0,d.jsxs)(`td`,{children:[(0,d.jsx)(`div`,{className:`small text-dark`,children:e.phone||`—`}),e.last_login_at&&(0,d.jsxs)(`small`,{className:`text-muted`,style:{fontSize:11},children:[`Last login: `,new Date(e.last_login_at).toLocaleDateString()]})]}),(0,d.jsx)(`td`,{children:e.status===1?(0,d.jsx)(`span`,{className:`badge bg-success-subtle text-success border border-success-subtle px-2 py-1`,children:`● Active`}):(0,d.jsx)(`span`,{className:`badge bg-danger-subtle text-danger border border-danger-subtle px-2 py-1`,children:`● Deactivated`})}),(0,d.jsx)(`td`,{className:`small text-muted`,children:e.created_at?new Date(e.created_at).toLocaleDateString():`—`}),(0,d.jsx)(`td`,{className:`text-end`,children:(0,d.jsxs)(`div`,{className:`btn-group btn-group-sm`,children:[(0,d.jsx)(`button`,{className:`btn btn-outline-primary`,title:`Edit details`,onClick:()=>U(e),children:(0,d.jsx)(`i`,{className:`bi bi-pencil`})}),(0,d.jsx)(`button`,{className:`btn btn-outline-secondary`,title:`Reset password`,onClick:()=>K(e),children:(0,d.jsx)(`i`,{className:`bi bi-key`})}),(0,d.jsx)(`button`,{className:`btn ${e.status===1?`btn-outline-warning`:`btn-outline-success`}`,title:e.status===1?`Deactivate operator`:`Activate operator`,onClick:()=>G(e),children:(0,d.jsx)(`i`,{className:`bi ${e.status===1?`bi-pause-circle`:`bi-play-circle`}`})}),(0,d.jsx)(`button`,{className:`btn btn-outline-danger`,title:`Delete operator`,onClick:()=>q(e),children:(0,d.jsx)(`i`,{className:`bi bi-trash`})})]})})]},e.id))})]})})]}),(0,d.jsxs)(`div`,{className:`alert alert-info py-3 px-4 d-flex align-items-start gap-3 mb-4`,style:{borderRadius:12},children:[(0,d.jsx)(`i`,{className:`bi bi-shield-lock-fill text-info fs-4 mt-1`}),(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`strong`,{children:`Proprietor Security Guard:`}),(0,d.jsx)(`br`,{}),`Operators have access to student records, results, attendance, CBT, and AI lesson planners. They are strictly blocked from viewing or editing School Bank Accounts, subscriptions, finances, or school ownership.`]})]}),(0,d.jsx)(`div`,{className:`mt-auto`,children:(0,d.jsx)(l,{})})]})]})}),v&&(0,d.jsx)(`div`,{className:`modal fade show d-block`,style:{backgroundColor:`rgba(0,0,0,0.6)`,zIndex:1050},children:(0,d.jsx)(`div`,{className:`modal-dialog modal-dialog-centered`,children:(0,d.jsxs)(`div`,{className:`modal-content`,style:{borderRadius:16,overflow:`hidden`},children:[(0,d.jsxs)(`div`,{className:`modal-header bg-dark text-white p-3 border-0`,children:[(0,d.jsxs)(`h5`,{className:`modal-title fs-6 fw-bold text-white d-flex align-items-center gap-2 m-0`,children:[(0,d.jsx)(`i`,{className:`bi bi-person-plus-fill text-warning`}),`Add School Operator / Manager`]}),(0,d.jsx)(`button`,{type:`button`,className:`btn-close btn-close-white`,onClick:()=>y(!1)})]}),(0,d.jsxs)(`form`,{onSubmit:H,children:[(0,d.jsxs)(`div`,{className:`modal-body p-4`,children:[(0,d.jsx)(`p`,{className:`text-muted small mb-3`,children:`Register an assistant, secretary, or IT operator. A temporary login password will be generated and emailed to them.`}),(0,d.jsxs)(`div`,{className:`row g-3`,children:[(0,d.jsxs)(`div`,{className:`col-md-6`,children:[(0,d.jsx)(`label`,{className:`form-label fw-bold small`,children:`First Name *`}),(0,d.jsx)(`input`,{type:`text`,className:`form-control`,required:!0,value:S.firstname,onChange:e=>C({...S,firstname:e.target.value}),placeholder:`e.g. John`})]}),(0,d.jsxs)(`div`,{className:`col-md-6`,children:[(0,d.jsx)(`label`,{className:`form-label fw-bold small`,children:`Surname *`}),(0,d.jsx)(`input`,{type:`text`,className:`form-control`,required:!0,value:S.surname,onChange:e=>C({...S,surname:e.target.value}),placeholder:`e.g. Doe`})]}),(0,d.jsxs)(`div`,{className:`col-12`,children:[(0,d.jsx)(`label`,{className:`form-label fw-bold small`,children:`Login Email Address *`}),(0,d.jsx)(`input`,{type:`email`,className:`form-control`,required:!0,value:S.email,onChange:e=>C({...S,email:e.target.value}),placeholder:`operator@school.edu or gmail.com`})]}),(0,d.jsxs)(`div`,{className:`col-md-6`,children:[(0,d.jsx)(`label`,{className:`form-label fw-bold small`,children:`Phone Number`}),(0,d.jsx)(`input`,{type:`text`,className:`form-control`,value:S.phone,onChange:e=>C({...S,phone:e.target.value}),placeholder:`08012345678`})]}),(0,d.jsxs)(`div`,{className:`col-md-6`,children:[(0,d.jsx)(`label`,{className:`form-label fw-bold small`,children:`Role / Job Title`}),(0,d.jsx)(`input`,{type:`text`,className:`form-control`,value:S.operator_title,onChange:e=>C({...S,operator_title:e.target.value}),placeholder:`e.g. Desk Officer / ICT Coordinator`})]})]})]}),(0,d.jsxs)(`div`,{className:`modal-footer bg-light p-3`,children:[(0,d.jsx)(`button`,{type:`button`,className:`btn btn-secondary btn-sm`,onClick:()=>y(!1),children:`Cancel`}),(0,d.jsx)(`button`,{type:`submit`,className:`db-btn-gold btn-sm`,disabled:b,children:b?`Creating...`:`Create Operator Account`})]})]})]})})}),w&&(0,d.jsx)(`div`,{className:`modal fade show d-block`,style:{backgroundColor:`rgba(0,0,0,0.7)`,zIndex:1060},children:(0,d.jsx)(`div`,{className:`modal-dialog modal-dialog-centered`,style:{maxWidth:440},children:(0,d.jsxs)(`div`,{className:`modal-content`,style:{borderRadius:16,overflow:`hidden`},children:[(0,d.jsxs)(`div`,{className:`modal-header bg-success text-white p-3 border-0`,children:[(0,d.jsxs)(`h5`,{className:`modal-title fs-6 fw-bold text-white d-flex align-items-center gap-2 m-0`,children:[(0,d.jsx)(`i`,{className:`bi bi-check-circle-fill`}),` Operator Created Successfully`]}),(0,d.jsx)(`button`,{type:`button`,className:`btn-close btn-close-white`,onClick:()=>T(null)})]}),(0,d.jsxs)(`div`,{className:`modal-body p-4 text-center`,children:[(0,d.jsxs)(`p`,{className:`small text-muted mb-3`,children:[`The account for `,(0,d.jsx)(`strong`,{children:w.name}),` is active. An email has been sent to`,` `,(0,d.jsx)(`code`,{children:w.email}),`.`]}),(0,d.jsxs)(`div`,{className:`p-3 bg-light rounded-3 border text-start mb-3`,children:[(0,d.jsx)(`div`,{className:`small text-muted`,children:`Email:`}),(0,d.jsx)(`div`,{className:`fw-bold text-dark`,children:w.email}),(0,d.jsx)(`div`,{className:`small text-muted mt-2`,children:`Temporary Password:`}),(0,d.jsxs)(`div`,{className:`d-flex justify-content-between align-items-center`,children:[(0,d.jsx)(`code`,{className:`fs-5 fw-bold text-primary`,children:w.pass}),(0,d.jsxs)(`button`,{className:`btn btn-sm btn-outline-secondary`,onClick:()=>J(w.pass),children:[(0,d.jsx)(`i`,{className:`bi bi-clipboard me-1`}),` Copy`]})]})]}),(0,d.jsx)(`button`,{className:`btn btn-primary w-100`,onClick:()=>T(null),children:`Done`})]})]})})}),E&&(0,d.jsx)(`div`,{className:`modal fade show d-block`,style:{backgroundColor:`rgba(0,0,0,0.6)`,zIndex:1050},children:(0,d.jsx)(`div`,{className:`modal-dialog modal-dialog-centered`,children:(0,d.jsxs)(`div`,{className:`modal-content`,style:{borderRadius:16,overflow:`hidden`},children:[(0,d.jsxs)(`div`,{className:`modal-header bg-dark text-white p-3 border-0`,children:[(0,d.jsxs)(`h5`,{className:`modal-title fs-6 fw-bold text-white d-flex align-items-center gap-2 m-0`,children:[(0,d.jsx)(`i`,{className:`bi bi-pencil-fill text-warning`}),`Edit School Operator`]}),(0,d.jsx)(`button`,{type:`button`,className:`btn-close btn-close-white`,onClick:()=>D(null)})]}),(0,d.jsxs)(`form`,{onSubmit:W,children:[(0,d.jsx)(`div`,{className:`modal-body p-4`,children:(0,d.jsxs)(`div`,{className:`row g-3`,children:[(0,d.jsxs)(`div`,{className:`col-md-6`,children:[(0,d.jsx)(`label`,{className:`form-label fw-bold small`,children:`First Name`}),(0,d.jsx)(`input`,{type:`text`,className:`form-control`,required:!0,value:O.firstname,onChange:e=>k({...O,firstname:e.target.value})})]}),(0,d.jsxs)(`div`,{className:`col-md-6`,children:[(0,d.jsx)(`label`,{className:`form-label fw-bold small`,children:`Surname`}),(0,d.jsx)(`input`,{type:`text`,className:`form-control`,required:!0,value:O.surname,onChange:e=>k({...O,surname:e.target.value})})]}),(0,d.jsxs)(`div`,{className:`col-md-6`,children:[(0,d.jsx)(`label`,{className:`form-label fw-bold small`,children:`Phone`}),(0,d.jsx)(`input`,{type:`text`,className:`form-control`,value:O.phone,onChange:e=>k({...O,phone:e.target.value})})]}),(0,d.jsxs)(`div`,{className:`col-md-6`,children:[(0,d.jsx)(`label`,{className:`form-label fw-bold small`,children:`Role Title`}),(0,d.jsx)(`input`,{type:`text`,className:`form-control`,value:O.operator_title,onChange:e=>k({...O,operator_title:e.target.value})})]})]})}),(0,d.jsxs)(`div`,{className:`modal-footer bg-light p-3`,children:[(0,d.jsx)(`button`,{type:`button`,className:`btn btn-secondary btn-sm`,onClick:()=>D(null),children:`Cancel`}),(0,d.jsx)(`button`,{type:`submit`,className:`db-btn-gold btn-sm`,disabled:A,children:A?`Saving...`:`Save Changes`})]})]})]})})}),M&&P&&(0,d.jsx)(`div`,{className:`modal fade show d-block`,style:{backgroundColor:`rgba(0,0,0,0.7)`,zIndex:1060},children:(0,d.jsx)(`div`,{className:`modal-dialog modal-dialog-centered`,style:{maxWidth:420},children:(0,d.jsxs)(`div`,{className:`modal-content`,style:{borderRadius:16,overflow:`hidden`},children:[(0,d.jsxs)(`div`,{className:`modal-header bg-dark text-white p-3 border-0`,children:[(0,d.jsxs)(`h5`,{className:`modal-title fs-6 fw-bold text-white d-flex align-items-center gap-2 m-0`,children:[(0,d.jsx)(`i`,{className:`bi bi-key-fill text-warning`}),` New Operator Password`]}),(0,d.jsx)(`button`,{type:`button`,className:`btn-close btn-close-white`,onClick:()=>N(null)})]}),(0,d.jsxs)(`div`,{className:`modal-body p-4 text-center`,children:[(0,d.jsxs)(`p`,{className:`small text-muted mb-3`,children:[`Password reset for `,(0,d.jsxs)(`strong`,{children:[M.firstname,` `,M.surname]}),` (`,(0,d.jsx)(`code`,{children:M.email}),`).`]}),(0,d.jsxs)(`div`,{className:`p-3 bg-light rounded-3 border d-flex justify-content-between align-items-center mb-3`,children:[(0,d.jsx)(`code`,{className:`fs-4 fw-bold text-primary`,children:P}),(0,d.jsxs)(`button`,{className:`btn btn-sm btn-outline-secondary`,onClick:()=>J(P),children:[(0,d.jsx)(`i`,{className:`bi bi-clipboard me-1`}),` Copy`]})]}),(0,d.jsx)(`button`,{className:`btn btn-primary w-100`,onClick:()=>N(null),children:`Done`})]})]})})})]})}export{f as default};