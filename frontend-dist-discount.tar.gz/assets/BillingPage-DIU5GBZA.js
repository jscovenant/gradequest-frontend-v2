import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{p as t,x as n}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as r,E as i,P as a,d as ee,f as te,l as ne,u as re}from"./index-D6TxbaCx.js";var o=e(),s=t();function c(e){try{return new Intl.NumberFormat(`en-NG`,{style:`currency`,currency:`NGN`}).format(e)}catch{return`₦${Number(e||0).toLocaleString()}`}}function l(e){if(!e)return`—`;let t=new Date(e);return Number.isNaN(t.getTime())?e:t.toLocaleDateString(`en-GB`,{day:`2-digit`,month:`short`,year:`numeric`})}function ie(e){let t=(e||``).toLowerCase();return t.includes(`success`)||t.includes(`paid`)?{bg:`rgba(34,197,94,0.14)`,fg:`#22c55e`,text:e}:t.includes(`pending`)?{bg:`rgba(245,158,11,0.16)`,fg:`#fbbf24`,text:e}:t.includes(`fail`)||t.includes(`error`)?{bg:`rgba(239,68,68,0.14)`,fg:`#ef4444`,text:e}:t.includes(`cancel`)?{bg:`rgba(148,163,184,0.14)`,fg:`#94a3b8`,text:e}:{bg:`rgba(0,0,0,0.04)`,fg:`#7a6a5a`,text:e||`Unknown`}}function ae(e,t,n){return Math.min(Math.max(e,t),n)}function u(e){return e===`online_transaction_fee`?`Online transaction fee`:e===`offline_term_invoice`?`Offline term invoice`:`Not configured`}function d(e){return e===`online_transaction_fee`?`Core access is supported by SchoolProfit charges collected automatically from parent fee payments.`:e===`offline_term_invoice`?`SchoolProfit bills the school directly based on active students for the current term.`:`Set up online payments or offline billing to activate the SchoolProfit revenue model.`}function f(){let{showError:e,showSuccess:t}=ne(),f=n(),[p,oe]=(0,o.useState)(!1),[m,h]=(0,o.useState)(!0),[g,se]=(0,o.useState)(null),[_,ce]=(0,o.useState)([]),[v,y]=(0,o.useState)(null),[b,le]=(0,o.useState)(``),[x,S]=(0,o.useState)(1),[C,w]=(0,o.useState)(10),T=(0,o.useMemo)(()=>{let e=b.trim().toLowerCase();return e?_.filter(t=>(t.reference||``).toLowerCase().includes(e)||(t.plan?.name||``).toLowerCase().includes(e)||(t.status||``).toLowerCase().includes(e)||(t.channel||``).toLowerCase().includes(e)):_},[_,b]);(0,o.useEffect)(()=>{S(1)},[b,C]);let E=T.length,D=(0,o.useMemo)(()=>Math.max(1,Math.ceil(E/C)),[E,C]),O=(0,o.useMemo)(()=>ae(x,1,D),[x,D]),k=(0,o.useMemo)(()=>{let e=(O-1)*C;return T.slice(e,e+C)},[T,O,C]),ue=(0,o.useMemo)(()=>{let e=Math.max(1,O-2),t=Math.min(D,O+2),n=[];for(let r=e;r<=t;r++)n.push(r);return n},[O,D]),de=E===0?0:(O-1)*C+1,fe=Math.min(O*C,E),[A,j]=(0,o.useState)(null),[M,N]=(0,o.useState)(!1),[P,F]=(0,o.useState)(!1),I=async(n=!1)=>{h(!0);try{let[e,r,i]=await Promise.all([a.get(`/subscription/billing`),a.get(`/school/billing/dashboard`),a.get(`/school/clearance/summary`)]);se(e.data.subscription||null),ce(e.data.payments||[]),y(r.data||null),j(i.data||null),n&&t?.(`Billing refreshed.`)}catch(t){console.error(t),e?.(t?.response?.data?.message||`Failed to load billing records.`)}finally{h(!1)}},pe=async()=>{if(!A?.session_id||!A?.term_id){e?.(`Current academic period is not active.`);return}let n=Number(A.term_clearance_fee||0),r=Number(A.pending_count||0);if(r===0){t?.(`All active students are already cleared for the current term.`);return}if((A.wallet_balance||0)<n){e?.(`Insufficient wallet balance. Total fee is ${c(n)}, but wallet balance is ${c(A.wallet_balance)}. Please top up your wallet first.`);return}if(window.confirm(`Debit ${c(n)} from school wallet to clear all ${r} unpaid student(s) for the current term?`)){N(!0);try{let e=await a.post(`/school/clearance/clear-school-term`,{session_id:A.session_id,term_id:A.term_id});t?.(e.data.message||`Whole-school term clearance completed successfully!`),await I()}catch(t){e?.(t?.response?.data?.message||`Failed to clear students from wallet.`)}finally{N(!1)}}},L=async()=>{if(!A?.session_id){e?.(`Current academic session is not active.`);return}let n=Number(A.session_clearance_fee||0),r=Number(A.total_students||0),i=Number(A.terms_count||3);if((A.wallet_balance||0)<n){e?.(`Insufficient wallet balance. Session clearance requires ${c(n)}, but wallet balance is ${c(A.wallet_balance)}. Please top up your wallet first.`);return}if(window.confirm(`Debit ${c(n)} from school wallet to clear all ${r} active students across ALL ${i} terms in this academic session?`)){F(!0);try{let e=await a.post(`/school/clearance/clear-school-session`,{session_id:A.session_id});t?.(e.data.message||`Full academic session clearance completed successfully!`),await I()}catch(t){e?.(t?.response?.data?.message||`Failed to clear session from wallet.`)}finally{F(!1)}}};(0,o.useEffect)(()=>{I()},[]),g?.status&&g.status;let R=(g?.status||``).toLowerCase()===`active`;(0,o.useMemo)(()=>g?R?{bg:`rgba(34,197,94,0.16)`,fg:`#22c55e`,text:`ACTIVE`}:{bg:`rgba(245,158,11,0.16)`,fg:`#fbbf24`,text:`INACTIVE`}:{bg:`rgba(245,158,11,0.16)`,fg:`#fbbf24`,text:`NO SUBSCRIPTION`},[g,R]),g?.plan?.name,l(g?.ends_at),g?.auto_renew_source,g&&g.auto_renew;let z=(0,o.useMemo)(()=>{let e=_.reduce((e,t)=>e+(Number(t.amount)||0),0),t=_.filter(e=>(e.status||``).toLowerCase().includes(`success`)).length,n=_.length?_[0]:null;return{totalPaid:e,successCount:t,lastPaymentDate:l(n?.created_at||n?.starts_at)}},[_]),B=v?.invoice||null,V=v?.transition_invoice||v?.switch_check?.transition_invoice||null,H=v?.revenue_model===`online_transaction_fee`,U=v?.legacy_subscription,me=!!U?.active,W=Number(B?.amount_due??v?.current_invoice_amount??0),G=H?Number(v?.current_period_paid_amount??Math.max(0,W-Number(v?.outstanding_amount??0))):Number(B?.amount_paid??Math.min(W,Number(v?.subscription_paid_amount??0))),K=H?Number(v?.current_period_balance_amount??Math.max(0,W-G)):Number(B?.balance??v?.outstanding_amount??Math.max(0,W-G)),q=W<=0?0:Math.min(100,Math.round(G/W*100)),J=v?.unpaid_students||[],he=Number(v?.summary?.paid||0),ge=Number((v?.summary?.unpaid||0)+(v?.summary?.grace||0)),Y=v?.online_collection,_e=Number(v?.current_period_online_collected_amount??Y?.current_period_collected_amount??0),X=Number(v?.current_period_invoice_paid_amount||0),Z=Number(v?.current_period_subscription_credit_amount??v?.subscription_paid_amount??0),ve=Number(Y?.current_period_collected_count||0),Q=async()=>{await I(!0)},ye=async()=>{h(!0);try{await a.post(`/school/billing/offline-invoice/generate`,{}),await I(!1),t?.(`SchoolProfit invoice generated.`)}catch(t){console.error(t),e?.(t?.response?.data?.message||`Unable to generate SchoolProfit invoice.`)}finally{h(!1)}},$=async n=>{h(!0);try{await a.put(`/school/billing/settings`,{payment_mode:n}),await I(!1),t?.(n===`online`?`Online transaction fee model enabled.`:`Offline term invoice model enabled.`)}catch(t){console.error(t);let r=null;try{let e=await a.get(`/school/billing/dashboard`);y(e.data||null),r=e.data?.transition_invoice||e.data?.switch_check?.transition_invoice||null}catch{await I(!1)}e?.(t?.response?.data?.message||(n===`online`?`Unable to switch to online model. Make sure online bank payment is enabled and outstanding SchoolProfit revenue is settled.`:`Unable to switch to offline model.`)),n===`offline`&&r?.id&&Number(r.balance||0)>0&&f(`/billing/invoice-payment/${r.id}`)}finally{h(!1)}};return(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)(`style`,{children:`
        /* ===== AdminDashboard template styles (aligned with your upgraded pages) ===== */
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');
        .db-main {
          background: #F8FAFC;
          min-height: 100vh;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          padding: 24px 28px 0;
        }

        .db-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 18px;
          padding: 32px 36px;
          position: relative;
          overflow: hidden;
          margin-bottom: 24px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
        }
        .db-hero-glow {
          position: absolute;
          top: -60px;
          right: -60px;
          width: 320px;
          height: 320px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.15) 0%, transparent 65%);
          pointer-events: none;
        }
        .db-hero-glow2 {
          position: absolute;
          bottom: -40px;
          left: 25%;
          width: 220px;
          height: 220px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(37, 99, 235, 0.10) 0%, transparent 70%);
          pointer-events: none;
        }
        .db-hero-inner {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 32px;
          flex-wrap: wrap;
        }
        @media (min-width: 768px) { .db-hero-inner { flex-wrap: nowrap; } }

        .db-session-badge {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.20);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius: 100px;
          padding: 4px 12px;
          margin-bottom: 12px;
        }
        .db-session-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #10B981;
          animation: dbPulse 2s ease infinite;
        }
        @keyframes dbPulse {
          0%,100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.4; transform: scale(1.5); }
        }

        .db-greeting {
          font-size: 26px;
          font-weight: 800;
          color: #fff;
          line-height: 1.1;
          margin-bottom: 8px;
        }
        .db-greeting em { font-style: normal; color: #FBBF24; }

        .db-hero-sub {
          font-size: 13.5px;
          color: #CBD5E1;
          line-height: 1.6;
          max-width: 560px;
          margin-bottom: 18px;
        }

        .db-hero-btns { display: flex; gap: 10px; flex-wrap: wrap; }

        .db-btn-gold {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 9px 18px;
          font-size: 13px;
          font-weight: 700;
          color: #FFFFFF;
          background: #D97706;
          border: none;
          border-radius: 10px;
          cursor: pointer;
          transition: all 0.2s ease;
          white-space: nowrap;
        }
        .db-btn-gold:hover { background: #B45309; transform: translateY(-1px); color: #FFFFFF; }
        .db-btn-gold:disabled { opacity: 0.55; cursor: not-allowed; transform: none; }

        .db-btn-outline {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 9px 18px;
          font-size: 13px;
          font-weight: 600;
          color: #FFFFFF;
          background: rgba(255, 255, 255, 0.10);
          border: 1px solid rgba(255, 255, 255, 0.20);
          border-radius: 10px;
          cursor: pointer;
          transition: all 0.2s ease;
          white-space: nowrap;
        }
        .db-btn-outline:hover { background: rgba(255, 255, 255, 0.18); color: #fff; }
        .db-btn-outline:disabled { opacity: 0.55; cursor: not-allowed; }

        .db-hero-stat-card {
          background: rgba(255, 255, 255, 0.08);
          border: 1px solid rgba(255, 255, 255, 0.15);
          backdrop-filter: blur(8px);
          border-radius: 14px;
          padding: 18px 20px;
          min-width: 270px;
          margin-left: auto;
          align-self: flex-end;
        }
        .db-hero-stat-row { display: flex; flex-direction: column; gap: 10px; }
        .db-hero-stat-item { display: flex; justify-content: space-between; align-items: center; gap: 16px; }
        .db-hero-stat-label { font-size: 12px; font-weight: 400; color: #CBD5E1; }
        .db-hero-stat-val { font-size: 18px; font-weight: 800; color: #FBBF24; }
        .db-hero-stat-sep { height: 1px; background: rgba(255, 255, 255, 0.08); }

        .db-panel {
          background: #fff;
          border: 1px solid #E2E8F0;
          border-radius: 16px;
          overflow: hidden;
          box-shadow: 0 4px 16px rgba(15,39,68,0.03);
          margin-bottom: 20px;
        }

        .db-panel-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 18px 20px;
          border-bottom: 1px solid #E2E8F0;
          gap: 12px;
          flex-wrap: wrap;
        }

        .db-panel-title {
          font-size: 16px;
          font-weight: 800;
          color: #0F2744;
          margin: 0;
        }

        .db-panel-sub {
          font-size: 12px;
          color: #64748B;
          margin: 0;
        }

        .db-refresh-btn {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 8px 14px;
          font-size: 12.5px;
          font-weight: 600;
          color: #0F2744;
          background: #F1F5F9;
          border: 1px solid #E2E8F0;
          border-radius: 8px;
          cursor: pointer;
          transition: all 0.2s ease;
          white-space: nowrap;
        }
        .db-refresh-btn:hover { background: #E2E8F0; }
        .db-refresh-btn:disabled { opacity: 0.5; cursor: not-allowed; }

        .db-pill {
          display: inline-flex;
          align-items: center;
          font-size: 11.5px;
          font-weight: 700;
          padding: 5px 10px;
          border-radius: 999px;
          white-space: nowrap;
          border: 1px solid rgba(0,0,0,0.06);
        }

        .db-muted { color: #64748B; }
        .db-strong { font-weight: 700; color: #0F2744; }

        .db-table { width: 100%; border-collapse: separate; border-spacing: 0; }
        .db-table th {
          padding: 12px 16px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #64748B;
          background: #F8FAFC;
          border-bottom: 1px solid #E2E8F0;
          text-align: left;
          white-space: nowrap;
        }
        .db-table td {
          padding: 14px 16px;
          font-size: 13px;
          color: #334155;
          border-bottom: 1px solid #E2E8F0;
          vertical-align: middle;
        }
        .db-table tbody tr:last-child td { border-bottom: none; }
        .db-table tbody tr:hover { background: #F8FAFC; }

        .db-search {
          display: flex;
          align-items: center;
          gap: 10px;
          background: #fff;
          border: 1px solid #E2E8F0;
          border-radius: 10px;
          padding: 10px 14px;
          min-width: 260px;
        }
        .db-search input { border: none; outline: none; width: 100%; font-size: 13px; color: #0F2744; }

        @media (max-width: 991.98px) { .db-main { padding: 18px 14px 0; } }
      `}),(0,s.jsx)(te,{sidebarOpen:p,setSidebarOpen:oe}),(0,s.jsx)(r,{title:`Billing`}),(0,s.jsx)(`div`,{className:`container-fluid`,children:(0,s.jsxs)(`div`,{className:`row`,children:[(0,s.jsx)(ee,{sidebarOpen:p}),(0,s.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto db-main`,children:[m&&(0,s.jsx)(i,{message:`Loading billing...`}),(0,s.jsxs)(`div`,{className:`db-hero`,children:[(0,s.jsx)(`div`,{className:`db-hero-glow`,"aria-hidden":`true`}),(0,s.jsx)(`div`,{className:`db-hero-glow2`,"aria-hidden":`true`}),(0,s.jsxs)(`div`,{className:`db-hero-inner`,children:[(0,s.jsxs)(`div`,{children:[(0,s.jsxs)(`div`,{className:`db-session-badge`,children:[(0,s.jsx)(`span`,{className:`db-session-dot`}),`Student Clearance — Billing`]}),(0,s.jsxs)(`h1`,{className:`db-greeting`,children:[`Student Clearance `,(0,s.jsx)(`em`,{children:`&`}),` Billing`]}),(0,s.jsx)(`p`,{className:`db-hero-sub`,children:`Manage student fee clearances, track your SchoolProfit wallet balance, and review fee payment history.`}),(0,s.jsxs)(`div`,{className:`db-hero-btns`,children:[(0,s.jsxs)(`button`,{className:`db-btn-gold`,onClick:()=>f(`/wallet`),disabled:m,children:[(0,s.jsx)(`i`,{className:`bi bi-wallet2`}),`Wallet & Credits`]}),(0,s.jsxs)(`button`,{className:`db-btn-outline`,onClick:()=>f(`/students`),disabled:m,children:[(0,s.jsx)(`i`,{className:`bi bi-people`}),`Student List`]}),(0,s.jsxs)(`button`,{className:`db-btn-outline`,onClick:Q,disabled:m,children:[(0,s.jsx)(`i`,{className:`bi bi-arrow-clockwise`}),`Refresh`]})]})]}),(0,s.jsxs)(`div`,{className:`db-hero-stat-card d-none d-md-block`,children:[(0,s.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,marginBottom:16},children:[(0,s.jsx)(`span`,{style:{fontSize:11,fontWeight:500,letterSpacing:`0.14em`,textTransform:`uppercase`,color:`#c9a84c`},children:`Quick glance`}),(0,s.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:(0,s.jsx)(`path`,{d:`M2 10V6M5 10V4M8 10V7M11 10V3`,stroke:`#64748b`,strokeWidth:`1.5`,strokeLinecap:`round`})})]}),(0,s.jsxs)(`div`,{className:`db-hero-stat-row`,children:[(0,s.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,s.jsx)(`span`,{className:`db-hero-stat-label`,children:`Model`}),(0,s.jsx)(`span`,{className:`db-hero-stat-val`,style:{fontSize:13,fontFamily:`DM Sans`},children:`Free Core (Pay-As-You-Go)`})]}),(0,s.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,s.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,s.jsx)(`span`,{className:`db-hero-stat-label`,children:`Status`}),(0,s.jsx)(`span`,{className:`db-pill`,style:{background:`rgba(34,197,94,0.16)`,color:`#22c55e`},children:`ACTIVE (UNLIMITED)`})]}),(0,s.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,s.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,s.jsx)(`span`,{className:`db-hero-stat-label`,children:`Fee / Student`}),(0,s.jsx)(`span`,{className:`db-hero-stat-val`,style:{fontSize:14,fontFamily:`DM Sans`},children:c(Number(v?.price_per_student||500))})]}),(0,s.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,s.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,s.jsx)(`span`,{className:`db-hero-stat-label`,children:`Total Paid`}),(0,s.jsx)(`span`,{className:`db-hero-stat-val`,children:c(z.totalPaid)})]})]})]})]})]}),(0,s.jsxs)(`div`,{className:`db-panel`,children:[(0,s.jsxs)(`div`,{className:`db-panel-head`,children:[(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`p`,{className:`db-panel-title`,children:`Clearance & Wallet Summary`}),(0,s.jsx)(`p`,{className:`db-panel-sub`,children:`100% Free Core school management. Per-student termly fee is cleared automatically online or via school wallet.`})]}),(0,s.jsx)(`span`,{className:`db-pill`,style:{background:`rgba(34,197,94,0.16)`,color:`#22c55e`},children:`FREE CORE ACTIVE`})]}),(0,s.jsxs)(`div`,{style:{padding:16},children:[(0,s.jsx)(`div`,{className:`row g-3`,children:[{k:`Active Students`,v:Number(A?.total_students||v?.active_student_count||0).toLocaleString(),icon:`people`,color:`#1e293b`},{k:`Cleared (Active)`,v:Number(A?.cleared_count||0).toLocaleString(),icon:`check-circle-fill`,color:`#16a34a`},{k:`Pending Clearance`,v:Number(A?.pending_count||0).toLocaleString(),icon:`exclamation-circle-fill`,color:`#d97706`},{k:`Wallet Balance`,v:c(Number(A?.wallet_balance||0)),icon:`wallet2`,color:`#c9a84c`}].map(e=>(0,s.jsx)(`div`,{className:`col-12 col-md-6 col-lg-3`,children:(0,s.jsxs)(`div`,{style:{background:`#faf8f5`,border:`1px solid rgba(0,0,0,0.06)`,borderRadius:14,padding:14,height:`100%`},children:[(0,s.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`},children:[(0,s.jsx)(`div`,{className:`db-muted`,style:{fontSize:12},children:e.k}),(0,s.jsx)(`i`,{className:`bi bi-${e.icon}`,style:{color:e.color}})]}),(0,s.jsx)(`div`,{className:`db-strong`,style:{fontFamily:`Lora, serif`,fontSize:18,marginTop:6,color:e.color},children:e.v})]})},e.k))}),(0,s.jsxs)(`div`,{className:`row g-3 mt-1`,children:[(0,s.jsx)(`div`,{className:`col-12 col-md-6`,children:(0,s.jsxs)(`div`,{style:{background:`#fff`,border:`1px solid rgba(0,0,0,0.08)`,borderRadius:14,padding:16,height:`100%`,display:`flex`,flexDirection:`column`,justifyContent:`space-between`},children:[(0,s.jsxs)(`div`,{children:[(0,s.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:8,marginBottom:6},children:[(0,s.jsx)(`i`,{className:`bi bi-calendar2-check text-primary`,style:{fontSize:18}}),(0,s.jsx)(`div`,{className:`db-strong`,style:{fontSize:15},children:`Clear Whole School (Current Term)`})]}),(0,s.jsxs)(`p`,{className:`db-muted`,style:{fontSize:12.5,margin:`6px 0 12px 0`},children:[`Clear all `,(0,s.jsxs)(`strong`,{children:[A?.pending_count||0,` unpaid student(s)`]}),` for the active term at once from your SchoolProfit wallet.`]}),(0,s.jsxs)(`div`,{className:`db-strong`,style:{fontSize:14,color:`#2563eb`,marginBottom:12},children:[`Total: `,c(Number(A?.term_clearance_fee||0)),` (`,c(Number(A?.fee_per_student||500)),`/student)`]})]}),(0,s.jsx)(`button`,{className:`db-btn-gold`,style:{width:`100%`,justifyContent:`center`,padding:`10px 14px`,fontSize:13},onClick:pe,disabled:M||(A?.pending_count||0)===0,children:M?(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)(`span`,{className:`spinner-border spinner-border-sm me-2`}),` Clearing Students…`]}):(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)(`i`,{className:`bi bi-check2-all me-1`}),` Clear Whole School (`,c(Number(A?.term_clearance_fee||0)),`)`]})})]})}),(0,s.jsx)(`div`,{className:`col-12 col-md-6`,children:(0,s.jsxs)(`div`,{style:{background:`#fff`,border:`1px solid rgba(0,0,0,0.08)`,borderRadius:14,padding:16,height:`100%`,display:`flex`,flexDirection:`column`,justifyContent:`space-between`},children:[(0,s.jsxs)(`div`,{children:[(0,s.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:8,marginBottom:6},children:[(0,s.jsx)(`i`,{className:`bi bi-stars text-success`,style:{fontSize:18}}),(0,s.jsx)(`div`,{className:`db-strong`,style:{fontSize:15},children:`Clear Full Session (All Terms Upfront)`})]}),(0,s.jsxs)(`p`,{className:`db-muted`,style:{fontSize:12.5,margin:`6px 0 12px 0`},children:[`Clear all `,(0,s.jsxs)(`strong`,{children:[A?.total_students||0,` active students`]}),` across all `,A?.terms_count||3,` terms for the entire academic session.`]}),(0,s.jsxs)(`div`,{className:`db-strong`,style:{fontSize:14,color:`#16a34a`,marginBottom:12},children:[`Total Upfront: `,c(Number(A?.session_clearance_fee||0))]})]}),(0,s.jsx)(`button`,{className:`db-btn-outline`,style:{width:`100%`,justifyContent:`center`,padding:`10px 14px`,fontSize:13,borderColor:`#16a34a`,color:`#16a34a`},onClick:L,disabled:P||(A?.total_students||0)===0,children:P?(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)(`span`,{className:`spinner-border spinner-border-sm me-2`}),` Clearing Session…`]}):(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)(`i`,{className:`bi bi-award-fill me-1`}),` Clear Entire Academic Session`]})})]})})]}),(0,s.jsxs)(`div`,{style:{marginTop:16,display:`flex`,gap:10,flexWrap:`wrap`},children:[(0,s.jsxs)(`button`,{className:`db-refresh-btn`,onClick:()=>f(`/wallet`),disabled:m,children:[(0,s.jsx)(`i`,{className:`bi bi-wallet2`}),`Top Up School Wallet`]}),(0,s.jsxs)(`button`,{className:`db-refresh-btn`,onClick:()=>f(`/students`),disabled:m,children:[(0,s.jsx)(`i`,{className:`bi bi-people`}),`Manage Students List`]})]})]})]}),(0,s.jsxs)(`div`,{className:`db-panel`,children:[(0,s.jsxs)(`div`,{className:`db-panel-head`,children:[(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`p`,{className:`db-panel-title`,children:`SchoolProfit per-student invoice`}),(0,s.jsx)(`p`,{className:`db-panel-sub`,children:`Current term invoice is calculated from active students and package price per student.`})]}),(0,s.jsx)(`span`,{className:`db-pill`,style:{background:`rgba(15,23,42,0.08)`,color:`#0f172a`},children:`Enforcement managed by SchoolProfit`})]}),(0,s.jsxs)(`div`,{style:{padding:16},children:[(0,s.jsxs)(`div`,{style:{marginBottom:16,background:v?.revenue_model===`online_transaction_fee`?`#ecfdf5`:`#fffbeb`,border:`1px solid ${v?.revenue_model===`online_transaction_fee`?`#bbf7d0`:`#fde68a`}`,borderRadius:16,padding:`16px 18px`,display:`flex`,justifyContent:`space-between`,gap:14,flexWrap:`wrap`,alignItems:`center`},children:[(0,s.jsxs)(`div`,{style:{display:`flex`,gap:12,alignItems:`flex-start`},children:[(0,s.jsx)(`div`,{style:{width:40,height:40,borderRadius:12,display:`grid`,placeItems:`center`,background:v?.revenue_model===`online_transaction_fee`?`#16a34a`:`#d97706`,color:`#fff`,flex:`0 0 auto`},children:(0,s.jsx)(`i`,{className:`bi bi-${v?.revenue_model===`online_transaction_fee`?`cash-coin`:`receipt`}`})}),(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`div`,{className:`db-muted`,style:{fontSize:12,textTransform:`uppercase`,letterSpacing:0,fontWeight:800},children:`SchoolProfit revenue model`}),(0,s.jsx)(`div`,{className:`db-strong`,style:{fontSize:20,marginTop:2},children:u(v?.revenue_model)}),(0,s.jsx)(`div`,{className:`db-muted`,style:{fontSize:13,marginTop:4,maxWidth:720},children:d(v?.revenue_model)})]})]}),(0,s.jsxs)(`span`,{className:`db-pill`,style:{background:`#fff`,color:v?.revenue_model===`online_transaction_fee`?`#15803d`:`#92400e`,border:`1px solid ${v?.revenue_model===`online_transaction_fee`?`#bbf7d0`:`#fde68a`}`},children:[(v?.settings?.payment_mode||`offline`).toUpperCase(),` MODE`]}),(0,s.jsxs)(`div`,{style:{display:`flex`,gap:10,flexWrap:`wrap`},children:[v?.settings?.payment_mode===`online`?(0,s.jsxs)(`button`,{className:`db-refresh-btn`,type:`button`,onClick:()=>$(`offline`),disabled:m,children:[(0,s.jsx)(`i`,{className:`bi bi-receipt`}),`Switch to Offline Model`]}):(0,s.jsxs)(`button`,{className:`db-refresh-btn`,type:`button`,onClick:()=>$(`online`),disabled:m,children:[(0,s.jsx)(`i`,{className:`bi bi-lightning-charge`}),`Switch to Online Model`]}),(0,s.jsxs)(`button`,{className:`db-refresh-btn`,type:`button`,onClick:()=>f(`/school/bank-account-setting`),disabled:m,children:[(0,s.jsx)(`i`,{className:`bi bi-bank`}),`Bank Settings`]})]})]}),(0,s.jsx)(`div`,{className:`row g-3`,children:[{k:`Payment Mode`,v:v?.settings?.payment_mode||`offline`,icon:`toggle2-on`},{k:`Revenue Model`,v:u(v?.revenue_model),icon:`diagram-3`},{k:`Current Period`,v:v?.period?`${v.period.term} - ${v.period.session}`:`Not set`,icon:`calendar-range`},{k:`Package`,v:v?.package?.name||`No active package`,icon:`boxes`},{k:`Price / Student`,v:c(Number(v?.price_per_student||0)),icon:`person-badge`},{k:`Active Students`,v:Number(v?.active_student_count||0).toLocaleString(),icon:`people`},{k:`Student Limit`,v:v?.student_limit===0?`Unlimited`:String(v?.student_limit??`Not set`),icon:`speedometer2`},{k:H?`Expected GQ Fee`:`Invoice Amount`,v:c(Number(v?.current_invoice_amount||0)),icon:H?`cash-coin`:`receipt-cutoff`},{k:H?`Uncovered Students`:`Unpaid Students`,v:ge.toLocaleString(),icon:`exclamation-circle`}].map(e=>(0,s.jsx)(`div`,{className:`col-12 col-md-6 col-lg-3`,children:(0,s.jsxs)(`div`,{style:{background:`#faf8f5`,border:`1px solid rgba(0,0,0,0.06)`,borderRadius:14,padding:14,height:`100%`},children:[(0,s.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`},children:[(0,s.jsx)(`div`,{className:`db-muted`,style:{fontSize:12},children:e.k}),(0,s.jsx)(`i`,{className:`bi bi-${e.icon}`,style:{color:`#c8bfb5`}})]}),(0,s.jsx)(`div`,{className:`db-strong`,style:{fontFamily:`Lora, serif`,fontSize:18,marginTop:6},children:e.v})]})},e.k))}),(0,s.jsxs)(`div`,{style:{marginTop:14,background:v?.revenue_model===`online_transaction_fee`?`rgba(34,197,94,0.1)`:`rgba(245,158,11,0.12)`,border:`1px solid ${v?.revenue_model===`online_transaction_fee`?`rgba(34,197,94,0.22)`:`rgba(245,158,11,0.24)`}`,borderRadius:14,padding:14,display:`flex`,gap:12,alignItems:`flex-start`},children:[(0,s.jsx)(`i`,{className:`bi bi-${v?.revenue_model===`online_transaction_fee`?`check-circle`:`receipt`}`,style:{color:v?.revenue_model===`online_transaction_fee`?`#16a34a`:`#b7791f`,fontSize:20}}),(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`div`,{className:`db-strong`,style:{fontSize:15},children:u(v?.revenue_model)}),(0,s.jsx)(`div`,{className:`db-muted`,style:{fontSize:13,marginTop:3},children:d(v?.revenue_model)})]})]}),(0,s.jsxs)(`div`,{className:`row g-3 mt-1`,children:[(0,s.jsx)(`div`,{className:`col-12 col-xl-5`,children:(0,s.jsx)(`div`,{style:{background:`#fff`,border:`1px solid rgba(0,0,0,0.06)`,borderRadius:14,padding:16,height:`100%`},children:me?(0,s.jsxs)(s.Fragment,{children:[(0,s.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:12,flexWrap:`wrap`},children:[(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`div`,{className:`db-muted`,style:{fontSize:12},children:`Legacy subscription`}),(0,s.jsxs)(`div`,{className:`db-strong`,style:{fontSize:18},children:[`Active until `,l(U?.ends_at)]}),(0,s.jsx)(`div`,{className:`db-muted`,style:{fontSize:12,marginTop:4},children:`Existing subscription is honored. Per-student billing starts from the next renewal.`})]}),(0,s.jsx)(`span`,{className:`db-pill`,style:{background:`rgba(34,197,94,0.14)`,color:`#16a34a`},children:`Protected`})]}),(0,s.jsxs)(`div`,{style:{marginTop:18,padding:14,borderRadius:12,background:`#faf8f5`,border:`1px solid rgba(0,0,0,0.06)`,display:`grid`,gridTemplateColumns:`repeat(auto-fit, minmax(130px, 1fr))`,gap:12},children:[(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`div`,{className:`db-muted`,style:{fontSize:11},children:`Current Debt`}),(0,s.jsx)(`div`,{className:`db-strong`,style:{fontSize:18,color:`#15803d`},children:c(0)})]}),(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`div`,{className:`db-muted`,style:{fontSize:11},children:`Next Billing Estimate`}),(0,s.jsx)(`div`,{className:`db-strong`,style:{fontSize:18},children:c(Number(v?.next_billing_estimate_amount??v?.current_invoice_amount??0))})]}),(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`div`,{className:`db-muted`,style:{fontSize:11},children:`Active Students`}),(0,s.jsx)(`div`,{className:`db-strong`,style:{fontSize:18},children:Number(v?.active_student_count||0).toLocaleString()})]})]}),(0,s.jsx)(`div`,{style:{marginTop:16,display:`flex`,gap:10,flexWrap:`wrap`},children:(0,s.jsxs)(`button`,{className:`db-refresh-btn`,onClick:()=>f(`/wallet`),disabled:m,children:[(0,s.jsx)(`i`,{className:`bi bi-wallet2`}),`Manage Wallet`]})})]}):H?(0,s.jsxs)(s.Fragment,{children:[(0,s.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:12,flexWrap:`wrap`},children:[(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`div`,{className:`db-muted`,style:{fontSize:12},children:`Current term invoice`}),(0,s.jsx)(`div`,{className:`db-strong`,style:{fontSize:18},children:v?.period?`${v.period.term} - ${v.period.session}`:`Current billing period`}),(0,s.jsx)(`div`,{className:`db-muted`,style:{fontSize:12,marginTop:4},children:`One simple view of what is expected, what has been recovered, and what remains.`})]}),(0,s.jsx)(`span`,{className:`db-pill`,style:{background:K<=0?`rgba(34,197,94,0.14)`:`rgba(245,158,11,0.16)`,color:K<=0?`#16a34a`:`#b45309`},children:K<=0?`Paid`:`Balance due`})]}),(0,s.jsxs)(`div`,{style:{marginTop:18,padding:14,borderRadius:12,background:`#faf8f5`,border:`1px solid rgba(0,0,0,0.06)`,display:`grid`,gridTemplateColumns:`repeat(auto-fit, minmax(130px, 1fr))`,gap:12},children:[(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`div`,{className:`db-muted`,style:{fontSize:11},children:`Amount Expected`}),(0,s.jsx)(`div`,{className:`db-strong`,style:{fontSize:18},children:c(W)})]}),(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`div`,{className:`db-muted`,style:{fontSize:11},children:`Amount Recovered`}),(0,s.jsx)(`div`,{className:`db-strong`,style:{fontSize:18},children:c(G)})]}),(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`div`,{className:`db-muted`,style:{fontSize:11},children:`Balance`}),(0,s.jsx)(`div`,{className:`db-strong`,style:{fontSize:18,color:K<=0?`#15803d`:`#b91c1c`},children:c(K)})]})]}),(0,s.jsxs)(`div`,{style:{marginTop:12,display:`grid`,gridTemplateColumns:`repeat(auto-fit, minmax(150px, 1fr))`,gap:10},children:[(0,s.jsxs)(`div`,{style:{padding:12,borderRadius:12,background:`rgba(34,197,94,0.08)`,border:`1px solid rgba(34,197,94,0.16)`},children:[(0,s.jsx)(`div`,{className:`db-muted`,style:{fontSize:11},children:`From parent payments`}),(0,s.jsx)(`div`,{className:`db-strong`,children:c(_e)}),(0,s.jsxs)(`div`,{className:`db-muted`,style:{fontSize:11},children:[ve.toLocaleString(),` record(s) this term`]})]}),(0,s.jsxs)(`div`,{style:{padding:12,borderRadius:12,background:X>0?`rgba(245,158,11,0.1)`:`#faf8f5`,border:X>0?`1px solid rgba(245,158,11,0.24)`:`1px solid rgba(0,0,0,0.06)`},children:[(0,s.jsx)(`div`,{className:`db-muted`,style:{fontSize:11},children:`From invoice payment`}),(0,s.jsx)(`div`,{className:`db-strong`,children:c(X)}),(0,s.jsx)(`div`,{className:`db-muted`,style:{fontSize:11},children:`School-paid or transition invoice`})]})]}),(0,s.jsxs)(`div`,{style:{marginTop:14},children:[(0,s.jsx)(`div`,{style:{height:10,background:`#ede8e0`,borderRadius:999,overflow:`hidden`},children:(0,s.jsx)(`div`,{style:{height:`100%`,width:`${q}%`,background:K<=0?`#16a34a`:`#c9a84c`}})}),(0,s.jsxs)(`div`,{className:`db-muted`,style:{fontSize:12,marginTop:8},children:[he.toLocaleString(),` of `,Number(v?.summary?.total||0).toLocaleString(),` student(s) covered.`]})]}),(0,s.jsxs)(`div`,{style:{marginTop:16,display:`flex`,gap:10,flexWrap:`wrap`},children:[(0,s.jsxs)(`button`,{className:`db-refresh-btn`,onClick:()=>f(`/pay-school-fee`),disabled:m,children:[(0,s.jsx)(`i`,{className:`bi bi-link-45deg`}),`Open Payment Link`]}),(0,s.jsxs)(`button`,{className:`db-refresh-btn`,onClick:()=>f(`/school/bank-account-setting`),disabled:m,children:[(0,s.jsx)(`i`,{className:`bi bi-bank`}),`Bank Settings`]})]}),V&&Number(V.balance||0)>0&&(0,s.jsxs)(`div`,{style:{marginTop:14,border:`1px solid rgba(245,158,11,0.24)`,background:`rgba(245,158,11,0.1)`,borderRadius:12,padding:12},children:[(0,s.jsx)(`div`,{className:`db-strong`,style:{fontSize:14},children:`Offline switch invoice pending`}),(0,s.jsxs)(`div`,{className:`db-muted`,style:{fontSize:12,marginTop:4},children:[`To switch from online to offline, settle invoice `,V.invoice_no,`.`]}),(0,s.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`repeat(3,minmax(0,1fr))`,gap:8,marginTop:10},children:[(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`div`,{className:`db-muted`,style:{fontSize:11},children:`Due`}),(0,s.jsx)(`div`,{className:`db-strong`,children:c(Number(V.amount_due||0))})]}),(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`div`,{className:`db-muted`,style:{fontSize:11},children:`Paid`}),(0,s.jsx)(`div`,{className:`db-strong`,children:c(Number(V.amount_paid||0))})]}),(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`div`,{className:`db-muted`,style:{fontSize:11},children:`Balance`}),(0,s.jsx)(`div`,{className:`db-strong`,children:c(Number(V.balance||0))})]})]}),(0,s.jsxs)(`button`,{className:`db-refresh-btn mt-2`,onClick:()=>f(`/billing/invoice-payment/${V.id}`),disabled:m,children:[(0,s.jsx)(`i`,{className:`bi bi-credit-card`}),`Pay Transition Invoice`]})]})]}):(0,s.jsxs)(s.Fragment,{children:[(0,s.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:12,flexWrap:`wrap`},children:[(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`div`,{className:`db-muted`,style:{fontSize:12},children:B?.id?`Invoice`:`Estimated invoice`}),(0,s.jsx)(`div`,{className:`db-strong`,style:{fontSize:18},children:B?.invoice_no||`Not created yet`}),(0,s.jsx)(`div`,{className:`db-muted`,style:{fontSize:12,marginTop:4},children:B?.id?`Status: ${B.status||`none`} | Due: ${l(B.due_date)}`:`Create the invoice before collecting the remaining balance.`})]}),K>0&&B?.id?(0,s.jsxs)(`button`,{className:`db-refresh-btn`,onClick:()=>f(`/billing/invoice-payment/${B.id}`),disabled:m,children:[(0,s.jsx)(`i`,{className:`bi bi-credit-card`}),`Make Payment`]}):K>0?(0,s.jsxs)(`button`,{className:`db-refresh-btn`,onClick:ye,disabled:m,children:[(0,s.jsx)(`i`,{className:`bi bi-receipt`}),`Generate Invoice`]}):(0,s.jsx)(`span`,{className:`db-pill`,style:{background:`rgba(34,197,94,0.14)`,color:`#16a34a`},children:`Paid`})]}),(0,s.jsx)(`div`,{className:`progress mt-3`,style:{height:8,borderRadius:999},children:(0,s.jsx)(`div`,{className:`progress-bar`,style:{width:`${q}%`,background:q>=100?`#16a34a`:`#c9a84c`}})}),(0,s.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`repeat(3, minmax(0, 1fr))`,gap:10,marginTop:14},children:[(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`div`,{className:`db-muted`,style:{fontSize:11},children:`Expected`}),(0,s.jsx)(`div`,{className:`db-strong`,children:c(W)})]}),(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`div`,{className:`db-muted`,style:{fontSize:11},children:`Applied Credit`}),(0,s.jsx)(`div`,{className:`db-strong`,children:c(G)})]}),(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`div`,{className:`db-muted`,style:{fontSize:11},children:`Balance`}),(0,s.jsx)(`div`,{className:`db-strong`,children:c(K)})]})]}),(0,s.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`repeat(auto-fit, minmax(150px, 1fr))`,gap:10,marginTop:12},children:[(0,s.jsxs)(`div`,{style:{padding:12,borderRadius:12,background:Z>0?`rgba(34,197,94,0.08)`:`#faf8f5`,border:Z>0?`1px solid rgba(34,197,94,0.16)`:`1px solid rgba(0,0,0,0.06)`},children:[(0,s.jsx)(`div`,{className:`db-muted`,style:{fontSize:11},children:`Previous subscription credit`}),(0,s.jsx)(`div`,{className:`db-strong`,children:c(Z)})]}),(0,s.jsxs)(`div`,{style:{padding:12,borderRadius:12,background:X>0?`rgba(245,158,11,0.1)`:`#faf8f5`,border:X>0?`1px solid rgba(245,158,11,0.24)`:`1px solid rgba(0,0,0,0.06)`},children:[(0,s.jsx)(`div`,{className:`db-muted`,style:{fontSize:11},children:`Invoice payment received`}),(0,s.jsx)(`div`,{className:`db-strong`,children:c(X)})]})]})]})})}),(0,s.jsx)(`div`,{className:`col-12 col-xl-7`,children:(0,s.jsxs)(`div`,{style:{background:`#fff`,border:`1px solid rgba(0,0,0,0.06)`,borderRadius:14,padding:16,height:`100%`},children:[(0,s.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:12,flexWrap:`wrap`,marginBottom:10},children:[(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`div`,{className:`db-strong`,children:`Students at risk`}),(0,s.jsx)(`div`,{className:`db-muted`,style:{fontSize:12},children:`Teachers will be protected from entering resources when SchoolProfit revenue is not covered.`})]}),(0,s.jsxs)(`span`,{className:`db-pill`,style:{background:`rgba(245,158,11,0.14)`,color:`#b45309`},children:[J.length,` shown`]})]}),J.length===0?(0,s.jsx)(`div`,{className:`db-muted`,style:{padding:`18px 0`},children:`No unpaid students found for the current term.`}):(0,s.jsx)(`div`,{style:{display:`grid`,gap:8},children:J.slice(0,8).map(e=>(0,s.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,gap:10,flexWrap:`wrap`,borderTop:`1px solid rgba(0,0,0,0.06)`,paddingTop:8},children:[(0,s.jsxs)(`div`,{children:[(0,s.jsxs)(`div`,{className:`db-strong`,style:{fontSize:13},children:[e.surname,` `,e.firstname]}),(0,s.jsxs)(`div`,{className:`db-muted`,style:{fontSize:12},children:[e.reg_no||`No reg no`,` | `,e.class_name||`No class`]})]}),(0,s.jsx)(`span`,{className:`db-pill`,style:{background:`rgba(245,158,11,0.14)`,color:`#b45309`},children:e.status})]},e.id))})]})})]})]})]}),(0,s.jsxs)(`div`,{className:`db-panel`,children:[(0,s.jsxs)(`div`,{className:`db-panel-head`,children:[(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`p`,{className:`db-panel-title`,children:`Payment history`}),(0,s.jsx)(`p`,{className:`db-panel-sub`,children:`Search records, adjust page size, and review transaction details.`})]}),(0,s.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:10,flexWrap:`wrap`},children:[(0,s.jsxs)(`div`,{className:`db-search`,children:[(0,s.jsx)(`i`,{className:`bi bi-search`,style:{color:`#9a8a7a`}}),(0,s.jsx)(`input`,{placeholder:`Search by reference, plan, status, channel…`,value:b,onChange:e=>le(e.target.value)})]}),(0,s.jsx)(`select`,{className:`form-select`,style:{width:140,borderRadius:12,borderColor:`#e5ddd3`},value:C,onChange:e=>w(Number(e.target.value)),children:[5,10,20,50].map(e=>(0,s.jsxs)(`option`,{value:e,children:[e,`/page`]},e))}),(0,s.jsxs)(`button`,{className:`db-refresh-btn`,onClick:Q,disabled:m,children:[(0,s.jsx)(`i`,{className:`bi bi-arrow-clockwise`}),`Refresh`]})]})]}),(0,s.jsx)(`div`,{style:{overflowX:`auto`},children:(0,s.jsxs)(`table`,{className:`db-table`,children:[(0,s.jsx)(`thead`,{children:(0,s.jsxs)(`tr`,{children:[(0,s.jsx)(`th`,{children:`Date`}),(0,s.jsx)(`th`,{children:`Plan`}),(0,s.jsx)(`th`,{children:`Amount`}),(0,s.jsx)(`th`,{children:`Channel`}),(0,s.jsx)(`th`,{children:`Reference`}),(0,s.jsx)(`th`,{children:`Status`})]})}),(0,s.jsx)(`tbody`,{children:k.length===0?(0,s.jsx)(`tr`,{children:(0,s.jsxs)(`td`,{colSpan:6,style:{padding:46,textAlign:`center`,color:`#b5a090`},children:[(0,s.jsx)(`div`,{style:{fontWeight:800,color:`#1a1a2e`},children:`No billing records found`}),(0,s.jsx)(`div`,{style:{fontSize:12.5,marginTop:4},children:`Try a different search keyword or refresh.`})]})}):k.map(e=>{let t=ie(e.status);return(0,s.jsxs)(`tr`,{children:[(0,s.jsx)(`td`,{className:`db-muted`,children:l(e.created_at||e.starts_at)}),(0,s.jsxs)(`td`,{children:[(0,s.jsx)(`div`,{className:`db-strong`,style:{fontWeight:700},children:e.plan?.name||`—`}),(0,s.jsx)(`div`,{className:`db-muted`,style:{fontSize:12,marginTop:2},children:e.card_type&&e.last4?`${e.card_type} • ${e.last4}`:`—`})]}),(0,s.jsx)(`td`,{className:`db-strong`,children:c(Number(e.amount||0))}),(0,s.jsx)(`td`,{style:{textTransform:`capitalize`},children:e.channel||`—`}),(0,s.jsx)(`td`,{children:(0,s.jsx)(`code`,{style:{fontSize:12,color:`#1a1a2e`},children:e.reference})}),(0,s.jsx)(`td`,{children:(0,s.jsx)(`span`,{className:`db-pill`,style:{background:t.bg,color:t.fg},children:t.text})})]},e.id)})})]})}),(0,s.jsxs)(`div`,{style:{padding:16,display:`flex`,justifyContent:`space-between`,alignItems:`center`,gap:12,flexWrap:`wrap`},children:[(0,s.jsxs)(`div`,{className:`db-muted`,style:{fontSize:12.5},children:[`Showing `,(0,s.jsx)(`b`,{children:de}),`–`,(0,s.jsx)(`b`,{children:fe}),` of `,(0,s.jsx)(`b`,{children:E}),(0,s.jsx)(`span`,{className:`ms-2`,children:`•`}),(0,s.jsxs)(`span`,{className:`ms-2`,children:[`Successful: `,(0,s.jsx)(`b`,{children:z.successCount})]}),(0,s.jsx)(`span`,{className:`ms-2`,children:`•`}),(0,s.jsxs)(`span`,{className:`ms-2`,children:[`Last payment: `,(0,s.jsx)(`b`,{children:z.lastPaymentDate})]})]}),(0,s.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,gap:8,flexWrap:`wrap`},children:[(0,s.jsxs)(`button`,{className:`db-refresh-btn`,disabled:O<=1,onClick:()=>S(e=>Math.max(1,e-1)),children:[(0,s.jsx)(`i`,{className:`bi bi-chevron-left`}),`Prev`]}),O>3&&(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)(`button`,{className:`db-refresh-btn`,onClick:()=>S(1),children:`1`}),(0,s.jsx)(`span`,{className:`db-muted`,children:`…`})]}),ue.map(e=>(0,s.jsx)(`button`,{className:`db-refresh-btn`,onClick:()=>S(e),style:{background:e===O?`#c9a84c`:void 0,color:e===O?`#0f172a`:void 0,borderColor:e===O?`#c9a84c`:void 0,fontWeight:e===O?800:400,minWidth:44,justifyContent:`center`},children:e},e)),O<D-2&&(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)(`span`,{className:`db-muted`,children:`…`}),(0,s.jsx)(`button`,{className:`db-refresh-btn`,onClick:()=>S(D),children:D})]}),(0,s.jsxs)(`button`,{className:`db-refresh-btn`,disabled:O>=D,onClick:()=>S(e=>Math.min(D,e+1)),children:[`Next`,(0,s.jsx)(`i`,{className:`bi bi-chevron-right`})]})]})]}),(0,s.jsxs)(`div`,{style:{padding:`0 16px 16px`},className:`db-muted`,children:[(0,s.jsx)(`i`,{className:`bi bi-info-circle me-1`}),`Tip: If you don’t see a recent payment, refresh after verification or contact support.`]})]}),(0,s.jsx)(`div`,{className:`mt-auto`,children:(0,s.jsx)(re,{})})]})]})})]})}export{f as default};