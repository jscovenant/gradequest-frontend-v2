import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{p as t}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as n,P as r,d as i,f as a,u as o}from"./index-D6TxbaCx.js";var s=e();const c={dashboard:()=>r.get(`/transport`),createRoute:e=>r.post(`/transport/routes`,e),createStop:(e,t)=>r.post(`/transport/routes/${e}/stops`,t),createVehicle:e=>r.post(`/transport/vehicles`,e),assign:e=>r.post(`/transport/assignments`,e),endAssignment:e=>r.post(`/transport/assignments/${e}/end`)};var l=t(),u={routes:[],students:[],assignments:[],summary:{routes:0,stops:0,vehicles:0,capacity:0,passengers:0}},d=e=>`${e.firstname||``} ${e.surname||``}`.trim(),f=e=>e?.response?.data?.message||Object.values(e?.response?.data?.errors||{}).flat()[0]||`Something went wrong.`;function p(){let[e,t]=(0,s.useState)(!1),[r,p]=(0,s.useState)(u),[m,h]=(0,s.useState)(!0),[g,_]=(0,s.useState)(!1),[v,y]=(0,s.useState)(``),[b,x]=(0,s.useState)(``),[S,C]=(0,s.useState)(``),[w,T]=(0,s.useState)({name:``,start_location:``,end_location:``,default_fee:``}),[E,D]=(0,s.useState)({transport_route_id:``,registration_number:``,name:``,capacity:1,driver_name:``,driver_phone:``}),[O,k]=(0,s.useState)({transport_route_id:``,name:``,pickup_time:``,dropoff_time:``,fee:``}),[A,j]=(0,s.useState)({student_id:``,transport_vehicle_id:``,transport_stop_id:``,trip_type:`both`,notes:``}),M=async()=>{h(!0),y(``);try{p((await c.dashboard()).data)}catch(e){y(String(f(e)))}finally{h(!1)}};(0,s.useEffect)(()=>{M()},[]);let N=(0,s.useMemo)(()=>r.routes.flatMap(e=>e.vehicles.map(t=>({...t,route:e}))),[r.routes]),P=N.find(e=>e.id===Number(A.transport_vehicle_id))?.route.stops||[],F=N.filter(e=>e.is_active&&e.route.is_active&&e.occupied<e.capacity),I=r.summary.capacity?Math.round(r.summary.passengers/r.summary.capacity*100):0,L=r.assignments.filter(e=>`${d(e.student)} ${e.student.reg_no||``} ${e.route.name} ${e.vehicle.registration_number}`.toLowerCase().includes(S.toLowerCase())),R=async(e,t)=>{_(!0),y(``),x(``);try{return await e(),x(t),await M(),!0}catch(e){return y(String(f(e))),!1}finally{_(!1)}},z=async e=>{e.preventDefault(),await R(()=>c.createRoute(w),`Route created successfully.`)&&T({name:``,start_location:``,end_location:``,default_fee:``})},B=async e=>{e.preventDefault(),await R(()=>c.createVehicle(E),`Vehicle added successfully.`)&&D({transport_route_id:``,registration_number:``,name:``,capacity:1,driver_name:``,driver_phone:``})},V=async e=>{e.preventDefault(),await R(()=>c.createStop(Number(O.transport_route_id),O),`Stop added successfully.`)&&k({transport_route_id:``,name:``,pickup_time:``,dropoff_time:``,fee:``})},H=async e=>{e.preventDefault(),await R(()=>c.assign(A),`Student assigned successfully.`)&&j({student_id:``,transport_vehicle_id:``,transport_stop_id:``,trip_type:`both`,notes:``})};return(0,l.jsxs)(l.Fragment,{children:[(0,l.jsx)(n,{title:`Transport Management`}),(0,l.jsx)(`style`,{children:`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');

        :root {
          --sp-dark: #0F2744;
          --sp-accent: #D97706;
          --sp-accent-dim: rgba(217, 119, 6, 0.10);
          --sp-accent-border: rgba(217, 119, 6, 0.25);
          --sp-light: #FFFFFF;
          --sp-border: #E2E8F0;
        }

        .db-main {
          padding: 24px 28px 48px;
          background: #F8FAFC;
          font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
          min-height: 100vh;
        }

        /* Hero */
        .db-hero {
          background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
          border-radius: 18px;
          padding: 32px 36px;
          position: relative;
          overflow: hidden;
          margin-bottom: 24px;
          box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
        }
        .db-hero-glow {
          position: absolute;
          top: -90px;
          right: -40px;
          width: 380px;
          height: 380px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(217, 119, 6, 0.15), transparent 70%);
          pointer-events: none;
        }
        .db-hero-inner {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 28px;
          flex-wrap: wrap;
        }
        .db-kicker {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: #FBBF24;
          background: rgba(217, 119, 6, 0.20);
          border: 1px solid rgba(217, 119, 6, 0.35);
          border-radius: 999px;
          padding: 4px 12px;
          margin-bottom: 12px;
        }
        .db-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #10B981;
        }
        .db-title {
          font-size: 26px;
          font-weight: 800;
          color: #fff;
          line-height: 1.15;
          margin: 0 0 8px;
        }
        .db-title em {
          color: #FBBF24;
          font-style: normal;
        }
        .db-hero-sub {
          font-size: 13.5px;
          color: #CBD5E1;
          line-height: 1.6;
          max-width: 600px;
          margin: 0;
        }
        .db-btn-gold {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          background: #D97706;
          color: #FFFFFF;
          font-weight: 700;
          font-size: 13px;
          padding: 9px 18px;
          border-radius: 10px;
          border: none;
          cursor: pointer;
          transition: all 0.2s ease;
          text-decoration: none;
        }
        .db-btn-gold:hover {
          background: #B45309;
          transform: translateY(-1px);
          color: #FFFFFF;
        }
        .db-hero-stats {
          background: rgba(255,255,255,0.06);
          border: 1px solid rgba(255,255,255,0.1);
          border-radius: 14px;
          padding: 16px 20px;
          min-width: 260px;
          backdrop-filter: blur(10px);
        }
        .db-hero-row {
          display: flex;
          justify-content: space-between;
          gap: 24px;
          padding: 6px 0;
          color: #94a3b8;
          font-size: 12.5px;
        }
        .db-hero-row + .db-hero-row {
          border-top: 1px solid rgba(255,255,255,0.08);
        }
        .db-hero-row strong {
          font-family: "Playfair Display", Georgia, serif;
          color: #fff;
          font-size: 16px;
        }

        /* KPI Cards */
        .db-stats {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
          gap: 16px;
          margin-bottom: 24px;
        }
        .db-stat {
          background: #fff;
          border: 1px solid var(--sp-border);
          border-radius: 16px;
          padding: 20px;
          position: relative;
          overflow: hidden;
          transition: transform 0.2s, box-shadow 0.2s;
        }
        .db-stat:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 24px rgba(5,0,8,0.06);
        }
        .db-stat::before {
          content: "";
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          height: 3px;
          background: var(--sc, #c9a84c);
        }
        .db-stat-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 12px;
        }
        .db-stat-label {
          font-size: 11.5px;
          font-weight: 700;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          color: #7a6a5a;
        }
        .db-stat-icon {
          width: 36px;
          height: 36px;
          border-radius: 10px;
          background: var(--si, rgba(201,168,76,0.12));
          color: var(--sc, #c9a84c);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 16px;
        }
        .db-stat-val {
          font-family: "Playfair Display", Georgia, serif;
          font-size: 26px;
          font-weight: 700;
          color: #1a1a2e;
          line-height: 1.1;
        }
        .db-stat-sub {
          font-size: 11.5px;
          color: #9a8a7a;
          margin-top: 4px;
        }

        /* Panel */
        .db-panel {
          background: #fff;
          border: 1px solid var(--sp-border);
          border-radius: 16px;
          box-shadow: 0 4px 20px rgba(5,0,8,0.04);
          overflow: hidden;
        }
        .db-panel-head {
          padding: 18px 22px;
          border-bottom: 1px solid var(--sp-border);
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 16px;
          flex-wrap: wrap;
          background: #faf8f5;
        }
        .db-panel-title {
          font-family: "Playfair Display", Georgia, serif;
          font-size: 16px;
          font-weight: 700;
          color: #1a1a2e;
          margin: 0;
        }
        .db-panel-sub {
          font-size: 11.5px;
          color: #7a6a5a;
          margin: 2px 0 0;
        }

        /* Forms */
        .db-form-label {
          font-size: 12px;
          font-weight: 600;
          color: #5a4d41;
          margin-bottom: 5px;
        }
        .db-form-control, .db-form-select {
          border: 1px solid #e5ddd3;
          border-radius: 10px;
          padding: 8px 12px;
          font-size: 13px;
          background: #fff;
          color: #1a1a2e;
        }
        .db-form-control:focus, .db-form-select:focus {
          border-color: #c9a84c;
          box-shadow: 0 0 0 3px rgba(201,168,76,0.18);
          outline: none;
        }

        /* Badges */
        .db-badge {
          display: inline-flex;
          align-items: center;
          gap: 5px;
          padding: 4px 10px;
          border-radius: 999px;
          font-size: 11.5px;
          font-weight: 700;
          white-space: nowrap;
        }
        .db-badge--blue { background: rgba(59,130,246,0.12); color: #1d4ed8; }
        .db-badge--green { background: rgba(34,197,94,0.14); color: #15803d; }
        .db-badge--amber { background: rgba(245,158,11,0.14); color: #b45309; }
        .db-badge--red { background: rgba(239,68,68,0.12); color: #dc2626; }
        .db-badge--gray { background: rgba(100,116,139,0.14); color: #475569; }

        /* Icon action buttons */
        .db-icon-btn {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          width: 34px;
          height: 34px;
          border-radius: 8px;
          font-size: 14px;
          border: 1px solid #e5ddd3;
          background: #f5f1eb;
          color: #7a6a5a;
          cursor: pointer;
          transition: all 0.2s ease;
          flex-shrink: 0;
        }
        .db-icon-btn:hover { background: #ede8e0; transform: translateY(-1px); }
        .db-icon-btn--r { background: rgba(244,63,94,0.10); border-color: rgba(244,63,94,0.25); color: #be123c; }
        .db-icon-btn--r:hover { background: rgba(244,63,94,0.20); }
      `}),(0,l.jsx)(a,{sidebarOpen:e,setSidebarOpen:t,title:`Transport Management`}),(0,l.jsx)(`div`,{className:`container-fluid`,children:(0,l.jsxs)(`div`,{className:`row`,children:[(0,l.jsx)(i,{sidebarOpen:e,setSidebarOpen:t}),(0,l.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto db-main`,children:[(0,l.jsxs)(`div`,{className:`db-hero`,children:[(0,l.jsx)(`div`,{className:`db-hero-glow`}),(0,l.jsxs)(`div`,{className:`db-hero-inner`,children:[(0,l.jsxs)(`div`,{children:[(0,l.jsxs)(`div`,{className:`db-kicker`,children:[(0,l.jsx)(`span`,{className:`db-dot`}),`School Fleet & Mobility Operations`]}),(0,l.jsxs)(`h1`,{className:`db-title`,children:[`Transport `,(0,l.jsx)(`em`,{children:`Management`})]}),(0,l.jsx)(`p`,{className:`db-hero-sub`,children:`Coordinate school bus routes, designated pickup/drop-off stops, vehicle capacity, and student transport assignments.`})]}),(0,l.jsxs)(`div`,{className:`db-hero-stats d-none d-md-block`,children:[(0,l.jsxs)(`div`,{className:`db-hero-row`,children:[(0,l.jsx)(`span`,{children:`Fleet Occupancy`}),(0,l.jsxs)(`strong`,{children:[I,`%`]})]}),(0,l.jsxs)(`div`,{className:`db-hero-row`,children:[(0,l.jsx)(`span`,{children:`Available Seats`}),(0,l.jsx)(`strong`,{children:Math.max(0,r.summary.capacity-r.summary.passengers)})]}),(0,l.jsxs)(`div`,{className:`db-hero-row`,children:[(0,l.jsx)(`span`,{children:`Active Passengers`}),(0,l.jsx)(`strong`,{children:r.summary.passengers})]})]})]})]}),v&&(0,l.jsxs)(`div`,{className:`alert alert-danger d-flex align-items-center gap-2 mb-4`,role:`alert`,children:[(0,l.jsx)(`i`,{className:`bi bi-exclamation-triangle-fill`}),(0,l.jsx)(`div`,{children:v})]}),b&&(0,l.jsxs)(`div`,{className:`alert alert-success d-flex align-items-center gap-2 mb-4`,role:`alert`,children:[(0,l.jsx)(`i`,{className:`bi bi-check-circle-fill`}),(0,l.jsx)(`div`,{children:b})]}),(0,l.jsxs)(`div`,{className:`db-stats`,children:[(0,l.jsxs)(`div`,{className:`db-stat`,style:{"--sc":`#2563eb`,"--si":`rgba(37,99,235,0.10)`},children:[(0,l.jsxs)(`div`,{className:`db-stat-head`,children:[(0,l.jsx)(`span`,{className:`db-stat-label`,children:`Routes`}),(0,l.jsx)(`div`,{className:`db-stat-icon`,children:(0,l.jsx)(`i`,{className:`bi bi-signpost-2`})})]}),(0,l.jsx)(`div`,{className:`db-stat-val`,children:r.summary.routes}),(0,l.jsx)(`div`,{className:`db-stat-sub`,children:`Configured travel corridors`})]}),(0,l.jsxs)(`div`,{className:`db-stat`,style:{"--sc":`#0891b2`,"--si":`rgba(8,145,178,0.10)`},children:[(0,l.jsxs)(`div`,{className:`db-stat-head`,children:[(0,l.jsx)(`span`,{className:`db-stat-label`,children:`Stops`}),(0,l.jsx)(`div`,{className:`db-stat-icon`,children:(0,l.jsx)(`i`,{className:`bi bi-geo-alt`})})]}),(0,l.jsx)(`div`,{className:`db-stat-val`,children:r.summary.stops}),(0,l.jsx)(`div`,{className:`db-stat-sub`,children:`Pickup & drop-off locations`})]}),(0,l.jsxs)(`div`,{className:`db-stat`,style:{"--sc":`#b45309`,"--si":`rgba(245,158,11,0.12)`},children:[(0,l.jsxs)(`div`,{className:`db-stat-head`,children:[(0,l.jsx)(`span`,{className:`db-stat-label`,children:`Fleet Vehicles`}),(0,l.jsx)(`div`,{className:`db-stat-icon`,children:(0,l.jsx)(`i`,{className:`bi bi-bus-front`})})]}),(0,l.jsx)(`div`,{className:`db-stat-val`,children:r.summary.vehicles}),(0,l.jsxs)(`div`,{className:`db-stat-sub`,children:[r.summary.capacity,` total seats`]})]}),(0,l.jsxs)(`div`,{className:`db-stat`,style:{"--sc":`#15803d`,"--si":`rgba(34,197,94,0.12)`},children:[(0,l.jsxs)(`div`,{className:`db-stat-head`,children:[(0,l.jsx)(`span`,{className:`db-stat-label`,children:`Assigned Passengers`}),(0,l.jsx)(`div`,{className:`db-stat-icon`,children:(0,l.jsx)(`i`,{className:`bi bi-people`})})]}),(0,l.jsx)(`div`,{className:`db-stat-val`,children:r.summary.passengers}),(0,l.jsxs)(`div`,{className:`db-stat-sub`,children:[I,`% seat utilization`]})]})]}),(0,l.jsxs)(`div`,{className:`row g-4 mb-4`,children:[(0,l.jsx)(`div`,{className:`col-xl-6`,children:(0,l.jsxs)(`div`,{className:`db-panel h-100`,children:[(0,l.jsx)(`div`,{className:`db-panel-head`,children:(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`h5`,{className:`db-panel-title`,children:`Add Transport Route`}),(0,l.jsx)(`p`,{className:`db-panel-sub`,children:`Define a corridor and standard transportation fee`})]})}),(0,l.jsxs)(`form`,{className:`p-4`,onSubmit:z,children:[(0,l.jsxs)(`div`,{className:`mb-3`,children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Route Name`}),(0,l.jsx)(`input`,{required:!0,className:`form-control db-form-control`,value:w.name,onChange:e=>T({...w,name:e.target.value}),placeholder:`e.g. Victoria Island - Lekki Corridor`})]}),(0,l.jsxs)(`div`,{className:`row g-2 mb-3`,children:[(0,l.jsxs)(`div`,{className:`col-6`,children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Starting Point`}),(0,l.jsx)(`input`,{className:`form-control db-form-control`,value:w.start_location,onChange:e=>T({...w,start_location:e.target.value}),placeholder:`e.g. CMS / Marina`})]}),(0,l.jsxs)(`div`,{className:`col-6`,children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Destination`}),(0,l.jsx)(`input`,{className:`form-control db-form-control`,value:w.end_location,onChange:e=>T({...w,end_location:e.target.value}),placeholder:`e.g. School Campus`})]})]}),(0,l.jsxs)(`div`,{className:`mb-4`,children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Default Route Fee (₦)`}),(0,l.jsx)(`input`,{type:`number`,min:`0`,className:`form-control db-form-control`,value:w.default_fee,onChange:e=>T({...w,default_fee:e.target.value}),placeholder:`e.g. 25000`})]}),(0,l.jsx)(`button`,{className:`db-btn-gold w-100 justify-content-center`,disabled:g,children:`Create Route`})]})]})}),(0,l.jsx)(`div`,{className:`col-xl-6`,children:(0,l.jsxs)(`div`,{className:`db-panel h-100`,children:[(0,l.jsx)(`div`,{className:`db-panel-head`,children:(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`h5`,{className:`db-panel-title`,children:`Add Vehicle to Fleet`}),(0,l.jsx)(`p`,{className:`db-panel-sub`,children:`Assign a bus or van and driver to a route`})]})}),(0,l.jsxs)(`form`,{className:`p-4`,onSubmit:B,children:[(0,l.jsxs)(`div`,{className:`mb-3`,children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Assigned Route`}),(0,l.jsxs)(`select`,{required:!0,className:`form-select db-form-select`,value:E.transport_route_id,onChange:e=>D({...E,transport_route_id:e.target.value}),children:[(0,l.jsx)(`option`,{value:``,children:`Select route`}),r.routes.map(e=>(0,l.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]}),(0,l.jsxs)(`div`,{className:`row g-2 mb-3`,children:[(0,l.jsxs)(`div`,{className:`col-7`,children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Registration Number`}),(0,l.jsx)(`input`,{required:!0,className:`form-control db-form-control`,value:E.registration_number,onChange:e=>D({...E,registration_number:e.target.value}),placeholder:`e.g. KSF-123-XY`})]}),(0,l.jsxs)(`div`,{className:`col-5`,children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Passenger Seats`}),(0,l.jsx)(`input`,{required:!0,type:`number`,min:`1`,max:`500`,className:`form-control db-form-control`,value:E.capacity,onChange:e=>D({...E,capacity:Number(e.target.value)})})]})]}),(0,l.jsxs)(`div`,{className:`row g-2 mb-4`,children:[(0,l.jsxs)(`div`,{className:`col-6`,children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Driver Name`}),(0,l.jsx)(`input`,{className:`form-control db-form-control`,value:E.driver_name,onChange:e=>D({...E,driver_name:e.target.value}),placeholder:`e.g. Driver Musa`})]}),(0,l.jsxs)(`div`,{className:`col-6`,children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Driver Phone`}),(0,l.jsx)(`input`,{className:`form-control db-form-control`,value:E.driver_phone,onChange:e=>D({...E,driver_phone:e.target.value}),placeholder:`e.g. 08033344455`})]})]}),(0,l.jsx)(`button`,{className:`db-btn-gold w-100 justify-content-center`,disabled:g||!r.routes.length,children:`Add Vehicle`})]})]})}),(0,l.jsx)(`div`,{className:`col-xl-6`,children:(0,l.jsxs)(`div`,{className:`db-panel h-100`,children:[(0,l.jsx)(`div`,{className:`db-panel-head`,children:(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`h5`,{className:`db-panel-title`,children:`Add Route Stop`}),(0,l.jsx)(`p`,{className:`db-panel-sub`,children:`Configure designated pickup and drop-off points`})]})}),(0,l.jsxs)(`form`,{className:`p-4`,onSubmit:V,children:[(0,l.jsxs)(`div`,{className:`mb-3`,children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Route`}),(0,l.jsxs)(`select`,{required:!0,className:`form-select db-form-select`,value:O.transport_route_id,onChange:e=>k({...O,transport_route_id:e.target.value}),children:[(0,l.jsx)(`option`,{value:``,children:`Select route`}),r.routes.map(e=>(0,l.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]}),(0,l.jsxs)(`div`,{className:`mb-3`,children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Stop Name`}),(0,l.jsx)(`input`,{required:!0,className:`form-control db-form-control`,value:O.name,onChange:e=>k({...O,name:e.target.value}),placeholder:`e.g. Chevron Tollgate Junction`})]}),(0,l.jsxs)(`div`,{className:`row g-2 mb-4`,children:[(0,l.jsxs)(`div`,{className:`col-6`,children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Pickup Time`}),(0,l.jsx)(`input`,{type:`time`,className:`form-control db-form-control`,value:O.pickup_time,onChange:e=>k({...O,pickup_time:e.target.value})})]}),(0,l.jsxs)(`div`,{className:`col-6`,children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Stop Specific Fee (₦)`}),(0,l.jsx)(`input`,{type:`number`,min:`0`,className:`form-control db-form-control`,value:O.fee,onChange:e=>k({...O,fee:e.target.value}),placeholder:`Optional override`})]})]}),(0,l.jsx)(`button`,{className:`db-btn-gold w-100 justify-content-center`,disabled:g||!r.routes.length,children:`Add Stop`})]})]})}),(0,l.jsx)(`div`,{className:`col-xl-6`,children:(0,l.jsxs)(`div`,{className:`db-panel h-100`,children:[(0,l.jsx)(`div`,{className:`db-panel-head`,children:(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`h5`,{className:`db-panel-title`,children:`Assign Student to Transport`}),(0,l.jsx)(`p`,{className:`db-panel-sub`,children:`Enroll student on a vehicle route and stop`})]})}),(0,l.jsxs)(`form`,{className:`p-4`,onSubmit:H,children:[(0,l.jsxs)(`div`,{className:`mb-3`,children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Student`}),(0,l.jsxs)(`select`,{required:!0,className:`form-select db-form-select`,value:A.student_id,onChange:e=>j({...A,student_id:e.target.value}),children:[(0,l.jsx)(`option`,{value:``,children:`Select student`}),r.students.map(e=>(0,l.jsxs)(`option`,{value:e.id,children:[d(e),` `,e.reg_no?`(${e.reg_no})`:``]},e.id))]})]}),(0,l.jsxs)(`div`,{className:`mb-3`,children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Vehicle & Route`}),(0,l.jsxs)(`select`,{required:!0,className:`form-select db-form-select`,value:A.transport_vehicle_id,onChange:e=>j({...A,transport_vehicle_id:e.target.value,transport_stop_id:``}),children:[(0,l.jsx)(`option`,{value:``,children:`Select vehicle`}),F.map(e=>(0,l.jsxs)(`option`,{value:e.id,children:[e.route.name,` · `,e.registration_number,` (`,e.capacity-e.occupied,` seats free)`]},e.id))]})]}),(0,l.jsxs)(`div`,{className:`row g-2 mb-4`,children:[(0,l.jsxs)(`div`,{className:`col-7`,children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Designated Stop`}),(0,l.jsxs)(`select`,{className:`form-select db-form-select`,value:A.transport_stop_id,onChange:e=>j({...A,transport_stop_id:e.target.value}),children:[(0,l.jsx)(`option`,{value:``,children:`No specific stop`}),P.map(e=>(0,l.jsx)(`option`,{value:e.id,children:e.name},e.id))]})]}),(0,l.jsxs)(`div`,{className:`col-5`,children:[(0,l.jsx)(`label`,{className:`db-form-label`,children:`Trip Direction`}),(0,l.jsxs)(`select`,{className:`form-select db-form-select`,value:A.trip_type,onChange:e=>j({...A,trip_type:e.target.value}),children:[(0,l.jsx)(`option`,{value:`both`,children:`Both Ways`}),(0,l.jsx)(`option`,{value:`pickup`,children:`Pickup Only`}),(0,l.jsx)(`option`,{value:`dropoff`,children:`Drop-off Only`})]})]})]}),(0,l.jsx)(`button`,{className:`db-btn-gold w-100 justify-content-center`,disabled:g||!F.length,children:`Assign Student`})]})]})})]}),(0,l.jsxs)(`div`,{className:`db-panel mb-4`,children:[(0,l.jsx)(`div`,{className:`db-panel-head`,children:(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`h5`,{className:`db-panel-title`,children:`Active Routes and Fleet`}),(0,l.jsx)(`p`,{className:`db-panel-sub`,children:`Real-time status of corridors, stops, and vehicle capacity`})]})}),(0,l.jsx)(`div`,{className:`p-4`,children:(0,l.jsxs)(`div`,{className:`row g-3`,children:[r.routes.map(e=>(0,l.jsx)(`div`,{className:`col-xl-6`,children:(0,l.jsxs)(`div`,{className:`p-3 border rounded-3 h-100`,style:{background:`#faf8f5`},children:[(0,l.jsxs)(`div`,{className:`d-flex justify-content-between align-items-start`,children:[(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`h5`,{className:`mb-1`,style:{fontFamily:`Playfair Display, serif`,color:`#1a1a2e`},children:e.name}),(0,l.jsxs)(`div`,{className:`small text-muted`,children:[e.start_location||`Start`,` → `,e.end_location||`School Campus`]})]}),(0,l.jsxs)(`span`,{className:`db-badge db-badge--green`,children:[e.passengers,` passengers`]})]}),(0,l.jsxs)(`div`,{className:`small text-muted mt-2 mb-3 fw-bold`,children:[(0,l.jsx)(`i`,{className:`bi bi-geo-alt me-1 text-warning`}),e.stops.length,` designated stop(s)`]}),e.vehicles.map(e=>{let t=Math.min(100,e.capacity?e.occupied/e.capacity*100:0);return(0,l.jsxs)(`div`,{className:`bg-white rounded-3 p-3 border mb-2`,style:{borderColor:`#e5ddd3`},children:[(0,l.jsxs)(`div`,{className:`d-flex justify-content-between small fw-bold`,children:[(0,l.jsxs)(`span`,{children:[(0,l.jsx)(`i`,{className:`bi bi-bus-front me-2 text-warning`}),e.name||e.registration_number]}),(0,l.jsxs)(`span`,{style:{color:t>=100?`#dc2626`:`#15803d`},children:[e.occupied,`/`,e.capacity,` seats`]})]}),(0,l.jsx)(`div`,{className:`progress mt-2`,style:{height:6,background:`#f0ece4`},children:(0,l.jsx)(`div`,{className:`progress-bar`,style:{width:`${t}%`,background:t>=100?`#dc2626`:t>=75?`#f59e0b`:`#22c55e`}})}),(0,l.jsxs)(`div`,{className:`small text-muted mt-1`,style:{fontSize:11},children:[`Driver: `,e.driver_name||`Unassigned`,` `,e.driver_phone?`(${e.driver_phone})`:``]})]},e.id)}),!e.vehicles.length&&(0,l.jsx)(`div`,{className:`text-muted small p-2`,children:`No vehicles assigned to this route yet.`})]})},e.id)),!m&&!r.routes.length&&(0,l.jsx)(`div`,{className:`text-center text-muted py-5`,children:`No routes configured yet. Use the form above to add your first route.`})]})})]}),(0,l.jsxs)(`div`,{className:`db-panel mb-4`,children:[(0,l.jsxs)(`div`,{className:`db-panel-head`,children:[(0,l.jsxs)(`div`,{children:[(0,l.jsx)(`h5`,{className:`db-panel-title`,children:`Student Passengers`}),(0,l.jsx)(`p`,{className:`db-panel-sub`,children:`Current active student transportation enrollments`})]}),(0,l.jsxs)(`div`,{className:`position-relative`,style:{maxWidth:280},children:[(0,l.jsx)(`input`,{className:`form-control db-form-control`,placeholder:`Search student, route, bus...`,value:S,onChange:e=>C(e.target.value),style:{paddingLeft:32}}),(0,l.jsx)(`i`,{className:`bi bi-search position-absolute text-muted`,style:{left:10,top:`50%`,transform:`translateY(-50%)`,fontSize:12}})]})]}),(0,l.jsx)(`div`,{className:`table-responsive`,children:(0,l.jsxs)(`table`,{className:`table align-middle mb-0`,style:{fontSize:13.5},children:[(0,l.jsx)(`thead`,{style:{background:`#faf8f5`},children:(0,l.jsxs)(`tr`,{children:[(0,l.jsx)(`th`,{className:`ps-4 text-muted small fw-bold`,children:`Student`}),(0,l.jsx)(`th`,{className:`text-muted small fw-bold`,children:`Route`}),(0,l.jsx)(`th`,{className:`text-muted small fw-bold`,children:`Vehicle`}),(0,l.jsx)(`th`,{className:`text-muted small fw-bold`,children:`Stop`}),(0,l.jsx)(`th`,{className:`text-muted small fw-bold`,children:`Trip Type`}),(0,l.jsx)(`th`,{className:`text-end pe-4 text-muted small fw-bold`,children:`Action`})]})}),(0,l.jsxs)(`tbody`,{children:[L.map(e=>(0,l.jsxs)(`tr`,{style:{borderBottom:`1px solid #ede8e0`},children:[(0,l.jsxs)(`td`,{className:`ps-4`,children:[(0,l.jsx)(`strong`,{style:{color:`#1a1a2e`},children:d(e.student)}),(0,l.jsx)(`div`,{className:`small text-muted`,children:e.student.reg_no||e.student.email})]}),(0,l.jsx)(`td`,{children:(0,l.jsx)(`span`,{className:`db-badge db-badge--blue`,children:e.route.name})}),(0,l.jsx)(`td`,{children:(0,l.jsx)(`span`,{className:`db-badge db-badge--gray`,children:e.vehicle.registration_number})}),(0,l.jsx)(`td`,{children:e.stop?.name||`—`}),(0,l.jsx)(`td`,{className:`text-capitalize`,children:(0,l.jsx)(`span`,{className:`db-badge db-badge--amber`,children:e.trip_type})}),(0,l.jsx)(`td`,{className:`text-end pe-4`,children:(0,l.jsx)(`button`,{className:`db-icon-btn db-icon-btn--r`,disabled:g,title:`End transport assignment`,onClick:()=>window.confirm(`End this transport assignment?`)&&R(()=>c.endAssignment(e.id),`Transport assignment ended.`),children:(0,l.jsx)(`i`,{className:`bi bi-x-circle`})})})]},e.id)),!m&&!L.length&&(0,l.jsx)(`tr`,{children:(0,l.jsx)(`td`,{colSpan:6,className:`text-center text-muted py-5`,children:`No active transport assignments found.`})})]})]})})]}),(0,l.jsx)(`div`,{className:`mt-5`,children:(0,l.jsx)(o,{})})]})]})})]})}export{p as default};