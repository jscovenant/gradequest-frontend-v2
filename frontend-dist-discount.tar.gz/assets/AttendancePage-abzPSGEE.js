import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{p as t}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as n,E as r,P as i,R as a,d as o,f as s,l as c,u as l}from"./index-D6TxbaCx.js";var u=e(),d=t();function f(){let e=new Date().getHours();return e<12?`Good morning`:e<17?`Good afternoon`:`Good evening`}function p(){let{showSuccess:e,showError:t}=c(),[p,m]=(0,u.useState)(!1),[h,g]=(0,u.useState)(`other`),[_,v]=(0,u.useState)([]),[y,b]=(0,u.useState)(``),[x,S]=(0,u.useState)(new Date().toISOString().slice(0,10)),[C,w]=(0,u.useState)({configured:!1,weeks:[]}),[T,E]=(0,u.useState)(``),[D,O]=(0,u.useState)([]),[k,A]=(0,u.useState)(!0),[j,M]=(0,u.useState)(!1),[N,P]=(0,u.useState)(!1),F=h===`teacher`,I=F&&_.length<=1,L=e=>a(e,`/media/profile.jpg`),R=(0,u.useMemo)(()=>_.find(e=>String(e.id)===String(y))?.name||`Select class`,[_,y]),z=(0,u.useMemo)(()=>{let e=D.length,t=0,n=0,r=0,i=0;D.forEach(e=>{let a=e.attendances?.[0]?.status;a===`present`?t++:a===`absent`?n++:a===`late`?r++:a===`excused`&&i++});let a=D.filter(e=>!e.attendances?.[0]?.status).length;return{total:e,present:t,absent:n,late:r,excused:i,unmarked:a}},[D]),B=(0,u.useMemo)(()=>z.total?Math.round((z.total-z.unmarked)/z.total*100):0,[z.total,z.unmarked]),V=async()=>{A(!0);try{let e=(await i.get(`/attendance/classes`)).data,t=e.classes||e||[];v(t);let n=e.academic_calendar||{configured:!1,weeks:[]};w(n),n.current_week&&E(String(n.current_week.number));let r=String(e.role||``).toLowerCase();g(r===`admin`?`admin`:r===`teacher`?`teacher`:`other`),e.default_class_id?b(String(e.default_class_id)):t.length===1&&b(String(t[0].id))}catch(e){console.error(e),t(`Failed to load classes`)}finally{A(!1)}},H=async()=>{if(!y||!T){O([]);return}M(!0);try{O(((await i.get(`/attendance`,{params:{class_id:y,date:x,week_number:Number(T)}})).data||[]).map(e=>({id:e.id,firstname:e.firstname,surname:e.surname,adm_no:e.reg_no||`STD-${e.id}`,photo:e.photo,attendances:e.attendances})))}catch(e){console.error(e),t(e?.response?.data?.message??`Failed to load students`),O([])}finally{M(!1)}},U=async()=>{if(!(!y||D.length===0)){P(!0);try{await i.post(`/attendance`,{class_id:y,date:x,week_number:Number(T),students:D.map(e=>({student_id:e.id,status:e.attendances?.[0]?.status||`absent`,remarks:e.attendances?.[0]?.remarks||null}))}),e(`Saved attendance successfully`),H()}catch(e){console.error(e),t(e?.response?.data?.message??`Failed to save attendance`)}finally{P(!1)}}},W=(e,t)=>{let n=[...D];n[e].attendances=[{status:t,remarks:n[e].attendances?.[0]?.remarks||``}],O(n)},G=(e,t)=>{let n=[...D];n[e].attendances||(n[e].attendances=[{status:`absent`}]),n[e].attendances[0].remarks=t,O(n)};(0,u.useEffect)(()=>{V()},[]),(0,u.useEffect)(()=>{H()},[y,x,T]);let K=e=>{E(e);let t=C.weeks.find(t=>String(t.number)===e);t&&(x<t.start_date||x>t.end_date)&&S(t.start_date)},q=e=>e?e===`present`?{bg:`rgba(34,197,94,0.14)`,color:`#16a34a`,label:`Present`}:e===`absent`?{bg:`rgba(244,63,94,0.12)`,color:`#e11d48`,label:`Absent`}:e===`late`?{bg:`rgba(14,165,233,0.14)`,color:`#0284c7`,label:`Late`}:{bg:`rgba(245,158,11,0.14)`,color:`#b45309`,label:`Excused`}:{bg:`rgba(148,163,184,0.18)`,color:`#64748b`,label:`Unmarked`},J=(e,t)=>e?t===`g`?`db-mini-btn db-mini-btn--g`:t===`r`?`db-mini-btn db-mini-btn--r`:t===`b`?`db-mini-btn db-mini-btn--b`:`db-mini-btn db-mini-btn--o`:`db-mini-btn`;return(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(`style`,{children:`
/* ========= Attendance page uses AdminDashboard template styles ========= */
.db-main{
  background: var(--bs-body-bg, #f5f1eb);
  min-height: 100vh;
  font-family: "DM Sans", system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
  padding: 28px 28px 0;
}
.db-hero{
  background:#0f172a;
  border-radius:16px;
  padding:32px 36px;
  position:relative;
  overflow:hidden;
  margin-bottom:22px;
  border:1px solid rgba(255,255,255,0.06);
}
.db-hero::before{
  content:"";
  position:absolute; inset:0;
  background-image: radial-gradient(circle, rgba(255,255,255,0.045) 1px, transparent 1px);
  background-size:24px 24px;
  pointer-events:none;
}
.db-hero-glow{
  position:absolute; top:-60px; right:-60px;
  width:320px; height:320px; border-radius:50%;
  background: radial-gradient(circle, rgba(201,168,76,0.12) 0%, transparent 65%);
  pointer-events:none;
}
.db-hero-glow2{
  position:absolute; bottom:-40px; left:25%;
  width:220px; height:220px; border-radius:50%;
  background: radial-gradient(circle, rgba(99,102,241,0.10) 0%, transparent 70%);
  pointer-events:none;
}
.db-hero-inner{ position:relative; z-index:1; display:flex; align-items:center; justify-content:space-between; gap:28px; flex-wrap:wrap; }
.db-session-badge{
  display:inline-flex; align-items:center; gap:7px;
  font-size:11px; font-weight:500; letter-spacing:0.12em; text-transform:uppercase;
  color:#e8c97a; background: rgba(201,168,76,0.10);
  border:1px solid rgba(201,168,76,0.22);
  border-radius:999px; padding:4px 12px; margin-bottom:12px;
}
.db-session-dot{ width:6px; height:6px; border-radius:50%; background:#22c55e; animation:dbPulse 2s ease infinite; }
@keyframes dbPulse{ 0%,100%{opacity:1; transform:scale(1);} 50%{opacity:.4; transform:scale(1.5);} }

.db-greeting{
  font-family:"Lora", Georgia, serif;
  font-size: clamp(22px, 2.5vw, 32px);
  font-weight:700; color:#fff; line-height:1.1; margin-bottom:8px;
}
.db-greeting em{ font-style:italic; color:#e8c97a; }
.db-hero-sub{ font-size:13.5px; font-weight:300; color:#94a3b8; line-height:1.7; max-width:520px; margin-bottom:18px; }

.db-hero-btns{ display:flex; gap:10px; flex-wrap:wrap; }
.db-btn-gold{
  display:inline-flex; align-items:center; gap:7px;
  padding:10px 18px;
  font-size:13px; font-weight:600;
  color:#0f172a; background:#c9a84c; border:none;
  border-radius:10px; cursor:pointer;
  transition: background .2s, transform .2s;
  text-decoration:none; white-space:nowrap;
}
.db-btn-gold:hover{ background:#e8c97a; transform: translateY(-1px); }
.db-btn-outline{
  display:inline-flex; align-items:center; gap:7px;
  padding:10px 18px;
  font-size:13px; font-weight:500;
  color: rgba(255,255,255,0.78);
  background:transparent;
  border:1px solid rgba(255,255,255,0.16);
  border-radius:10px; cursor:pointer;
  transition: background .2s, border-color .2s, color .2s;
}
.db-btn-outline:hover{ background: rgba(255,255,255,0.06); border-color: rgba(255,255,255,0.28); color:#fff; }

.db-hero-stat-card{
  background: rgba(255,255,255,0.05);
  border:1px solid rgba(255,255,255,0.09);
  backdrop-filter: blur(8px);
  border-radius:12px;
  padding:18px 20px;
  min-width: 220px;
}
.db-hero-stat-item{ display:flex; align-items:center; justify-content:space-between; gap:14px; }
.db-hero-stat-label{ font-size:12px; font-weight:300; color:#94a3b8; }
.db-hero-stat-val{ font-family:"Lora", serif; font-size:18px; font-weight:700; color:#fff; }
.db-hero-stat-sep{ height:1px; background: rgba(255,255,255,0.06); margin:10px 0; }

.db-stats{
  display:grid;
  grid-template-columns: repeat(5, 1fr);
  gap:16px;
  margin-bottom: 18px;
}
@media (max-width: 1199.98px){ .db-stats{ grid-template-columns: repeat(2, 1fr);} }
@media (max-width: 575.98px){ .db-stats{ grid-template-columns: 1fr;} }

.db-stat{
  background:#fff;
  border:1px solid #ede8e0;
  border-radius:14px;
  padding:22px 20px;
  position:relative;
  overflow:hidden;
  transition: box-shadow .25s, transform .25s;
}
.db-stat:hover{ box-shadow: 0 8px 28px rgba(0,0,0,0.08); transform: translateY(-3px); }
.db-stat::before{
  content:""; position:absolute; top:0; left:0; right:0; height:3px;
  background: var(--sc, #b45309);
  transform: scaleX(0); transform-origin:left;
  transition: transform .3s ease;
}
.db-stat:hover::before{ transform: scaleX(1); }
.db-stat-head{ display:flex; align-items:flex-start; justify-content:space-between; margin-bottom:14px; }
.db-stat-icon{
  width:42px; height:42px; border-radius:10px;
  background: var(--si, #fef3c7);
  color: var(--sc, #b45309);
  display:flex; align-items:center; justify-content:center;
}
.db-stat-label{ font-size:12px; font-weight:400; color:#9a8a7a; margin-bottom:5px; letter-spacing:.03em; }
.db-stat-val{ font-family:"Lora", Georgia, serif; font-size:28px; font-weight:700; color:#1a1a2e; line-height:1; }
.db-stat-footer{
  display:flex; align-items:center; gap:6px;
  margin-top:12px; padding-top:12px;
  border-top:1px solid rgba(0,0,0,0.06);
  font-size:12px; color:#9a8a7a;
}
.db-stat-trend{ color:#22c55e; font-weight:600; }

.db-grid{
  display:grid;
  grid-template-columns: 1fr;
  gap:20px;
  margin-bottom: 22px;
}

.db-panel{
  background:#fff;
  border:1px solid #ede8e0;
  border-radius:14px;
  overflow:hidden;
}
.db-panel-head{
  display:flex; align-items:center; justify-content:space-between;
  padding:18px 20px;
  border-bottom:1px solid rgba(0,0,0,0.06);
  gap:12px;
}
.db-panel-title-group{ display:flex; align-items:center; gap:12px; }
.db-panel-icon{
  width:36px; height:36px; border-radius:9px;
  display:flex; align-items:center; justify-content:center;
  background: var(--pi, #fef3c7);
  color: var(--pc, #b45309);
  flex-shrink:0;
}
.db-panel-title{
  font-family:"Lora", serif;
  font-size:16px; font-weight:700;
  color:#1a1a2e; margin:0;
}
.db-panel-sub{ font-size:11.5px; font-weight:300; color:#9a8a7a; margin:0; }

.db-refresh-btn{
  display:inline-flex; align-items:center; gap:6px;
  padding:7px 14px;
  font-size:12px; font-weight:500;
  color:#7a6a5a;
  background:#f5f1eb;
  border:1px solid #e5ddd3;
  border-radius:7px;
  cursor:pointer;
  transition: background .2s;
}
.db-refresh-btn:hover{ background:#ede8e0; }
.db-refresh-btn:disabled{ opacity:.55; cursor:not-allowed; }

.db-toolbar{
  padding: 14px 20px;
  display:flex; align-items:center; justify-content:space-between;
  flex-wrap:wrap; gap:12px;
}
.db-field{
  display:flex; align-items:center; gap:10px; flex-wrap:wrap;
}
.db-select, .db-input{
  border:1px solid #e5ddd3;
  background:#fff;
  border-radius:10px;
  padding:10px 12px;
  font-size:13px;
  color:#1a1a2e;
  outline:none;
  min-height: 40px;
}
.db-select{ min-width: 220px; }
.db-input{ width: 170px; }
.db-select:disabled, .db-input:disabled{ opacity:.65; cursor:not-allowed; background:#faf8f5; }

.db-mini-btn{
  display:inline-flex; align-items:center; justify-content:center;
  gap:6px;
  border-radius:10px;
  padding:9px 12px;
  font-size:12.5px;
  font-weight:600;
  border:1px solid #e5ddd3;
  background:#f5f1eb;
  color:#7a6a5a;
  cursor:pointer;
  transition: background .2s, transform .2s;
  min-height: 40px;
}
.db-mini-btn:hover{ background:#ede8e0; transform: translateY(-1px); }
.db-mini-btn:disabled{ opacity:.55; cursor:not-allowed; transform:none; }
.db-mini-btn--g{ background: rgba(34,197,94,0.12); border-color: rgba(34,197,94,0.25); color:#15803d; }
.db-mini-btn--r{ background: rgba(244,63,94,0.10); border-color: rgba(244,63,94,0.22); color:#be123c; }
.db-mini-btn--b{ background: rgba(14,165,233,0.10); border-color: rgba(14,165,233,0.22); color:#0369a1; }
.db-mini-btn--o{ background: rgba(245,158,11,0.12); border-color: rgba(245,158,11,0.22); color:#b45309; }

.db-table{
  width:100%;
  border-collapse:collapse;
}
.db-table th{
  padding:10px 16px;
  font-size:11px;
  font-weight:600;
  letter-spacing:0.1em;
  text-transform:uppercase;
  color:#9a8a7a;
  background:#faf8f5;
  border-bottom:1px solid rgba(0,0,0,0.06);
  text-align:left;
  white-space:nowrap;
}
.db-table td{
  padding:13px 16px;
  font-size:13.5px;
  color:#4a4a5a;
  border-bottom:1px solid rgba(0,0,0,0.06);
  vertical-align:middle;
}
.db-table tbody tr{ transition: background .15s; }
.db-table tbody tr:hover{ background:#faf8f5; }

.db-avatar{
  width:42px; height:42px;
  border-radius:999px;
  border:1px solid rgba(0,0,0,0.08);
  object-fit:cover;
}
.db-name{ font-weight:600; color:#1a1a2e; }
.db-muted{ color:#9a8a7a; font-size:12.5px; }

.db-score-pill{
  display:inline-flex;
  align-items:center;
  font-size:12.5px;
  font-weight:600;
  padding:4px 10px;
  border-radius:999px;
}

.db-remark{
  width: 100%;
  border:1px solid #e5ddd3;
  background:#fff;
  border-radius:10px;
  padding:9px 10px;
  font-size:13px;
  outline:none;
}
.db-remark:focus{ border-color: rgba(201,168,76,0.7); box-shadow: 0 0 0 3px rgba(201,168,76,0.15); }

.db-table-empty{
  padding:46px 16px;
  text-align:center;
  color:#b5a090;
  font-size:13.5px;
}

.db-skeleton{
  height: 14px;
  border-radius: 7px;
  background: linear-gradient(90deg, #f0ebe3 25%, #e8e0d5 50%, #f0ebe3 75%);
  background-size: 200% 100%;
  animation: dbSkeleton 1.4s ease infinite;
}
@keyframes dbSkeleton { from { background-position: 200% 0; } to { background-position: -200% 0; } }

@keyframes dbSpin { to { transform: rotate(360deg); } }
      `}),(0,d.jsx)(s,{sidebarOpen:p,setSidebarOpen:m}),(0,d.jsx)(n,{title:`Attendance`}),(0,d.jsx)(`div`,{className:`container-fluid`,children:(0,d.jsxs)(`div`,{className:`row`,children:[(0,d.jsx)(o,{sidebarOpen:p}),(0,d.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto db-main`,children:[(k||N)&&(0,d.jsx)(r,{message:N?`Saving attendance...`:`Loading attendance page...`}),(0,d.jsxs)(`div`,{className:`db-hero`,children:[(0,d.jsx)(`div`,{className:`db-hero-glow`,"aria-hidden":`true`}),(0,d.jsx)(`div`,{className:`db-hero-glow2`,"aria-hidden":`true`}),(0,d.jsxs)(`div`,{className:`db-hero-inner`,children:[(0,d.jsxs)(`div`,{children:[(0,d.jsxs)(`div`,{className:`db-session-badge`,children:[(0,d.jsx)(`span`,{className:`db-session-dot`}),`Attendance · `,(0,d.jsx)(`span`,{style:{color:`#94a3b8`},children:R}),` ·`,` `,(0,d.jsx)(`span`,{style:{color:`#94a3b8`},children:x})]}),(0,d.jsxs)(`h1`,{className:`db-greeting`,children:[f(),`, `,(0,d.jsxs)(`em`,{children:[F?`Teacher`:`Admin`,`.`]})]}),(0,d.jsxs)(`p`,{className:`db-hero-sub`,children:[`Mark daily attendance quickly. Unmarked students will default to `,(0,d.jsx)(`b`,{style:{color:`#e8c97a`},children:`Absent`}),` `,`when you save.`]}),(0,d.jsxs)(`div`,{className:`db-hero-btns`,children:[(0,d.jsx)(`button`,{className:`db-btn-gold`,onClick:U,disabled:N||!y||D.length===0,title:y?D.length===0?`No students loaded`:`Save attendance`:`Select a class`,children:N?(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(`span`,{style:{width:14,height:14,borderRadius:`50%`,border:`2px solid rgba(15,23,42,0.35)`,borderTopColor:`#0f172a`,display:`inline-block`,animation:`dbSpin 0.8s linear infinite`}}),`Saving…`]}):(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:(0,d.jsx)(`path`,{d:`M13.5 4.5l-6.5 7L2.5 7`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`,strokeLinejoin:`round`})}),`Save Attendance`]})}),(0,d.jsxs)(`button`,{className:`db-btn-outline`,onClick:H,disabled:j||!y,children:[(0,d.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,style:{animation:j?`dbSpin 0.8s linear infinite`:`none`},children:[(0,d.jsx)(`path`,{d:`M14 8A6 6 0 112 8`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`}),(0,d.jsx)(`path`,{d:`M14 4v4h-4`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),j?`Loading…`:`Refresh List`]}),(0,d.jsxs)(`button`,{className:`db-btn-outline`,onClick:()=>S(new Date().toISOString().slice(0,10)),disabled:j||k,title:`Jump to today`,children:[(0,d.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,d.jsx)(`path`,{d:`M5 2v2M11 2v2M2.5 6.2h11`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,d.jsx)(`rect`,{x:`2.5`,y:`3.5`,width:`11`,height:`10`,rx:`2`,stroke:`currentColor`,strokeWidth:`1.4`})]}),`Today`]})]})]}),(0,d.jsxs)(`div`,{className:`db-hero-stat-card d-none d-md-block`,children:[(0,d.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,marginBottom:12},children:[(0,d.jsx)(`span`,{style:{fontSize:11,fontWeight:600,letterSpacing:`0.14em`,textTransform:`uppercase`,color:`#c9a84c`},children:`Quick glance`}),(0,d.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:(0,d.jsx)(`path`,{d:`M2 10V6M5 10V4M8 10V7M11 10V3`,stroke:`#94a3b8`,strokeWidth:`1.5`,strokeLinecap:`round`})})]}),(0,d.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,d.jsx)(`span`,{className:`db-hero-stat-label`,children:`Total students`}),(0,d.jsx)(`span`,{className:`db-hero-stat-val`,children:z.total})]}),(0,d.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,d.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,d.jsx)(`span`,{className:`db-hero-stat-label`,children:`Completion`}),(0,d.jsxs)(`span`,{className:`db-hero-stat-val`,children:[B,`%`]})]}),(0,d.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,d.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,d.jsx)(`span`,{className:`db-hero-stat-label`,children:`Unmarked`}),(0,d.jsx)(`span`,{className:`db-hero-stat-val`,children:z.unmarked})]}),(0,d.jsxs)(`div`,{style:{marginTop:12,paddingTop:12,borderTop:`1px solid rgba(255,255,255,0.06)`},children:[(0,d.jsxs)(`div`,{style:{fontSize:12,color:`#94a3b8`},children:[`Role: `,(0,d.jsx)(`b`,{style:{color:`#fff`},children:F?`Teacher`:`Admin`})]}),(0,d.jsxs)(`div`,{style:{fontSize:12,color:`#94a3b8`},children:[`Class: `,(0,d.jsx)(`b`,{style:{color:`#fff`},children:R})]})]})]})]})]}),(0,d.jsx)(`div`,{className:`db-stats`,children:[{title:`Students Loaded`,value:z.total,color:`#1e40af`,bg:`#dbeafe`,hint:`class list`},{title:`Present`,value:z.present,color:`#065f46`,bg:`#d1fae5`,hint:`checked in`},{title:`Late`,value:z.late,color:`#0284c7`,bg:`rgba(14,165,233,0.12)`,hint:`arrived late`},{title:`Absent + Excused`,value:z.absent+z.excused,color:`#be123c`,bg:`rgba(244,63,94,0.10)`,hint:`not in class`},{title:`Unmarked`,value:z.unmarked,color:`#b45309`,bg:`#fef3c7`,hint:`needs action`}].map((e,t)=>{let n=[(0,d.jsxs)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 20 20`,fill:`none`,children:[(0,d.jsx)(`circle`,{cx:`8`,cy:`6`,r:`3`,stroke:`currentColor`,strokeWidth:`1.5`}),(0,d.jsx)(`path`,{d:`M2 18c0-3.314 2.686-6 6-6`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`}),(0,d.jsx)(`circle`,{cx:`15`,cy:`10`,r:`2.5`,stroke:`currentColor`,strokeWidth:`1.4`})]},`i1`),(0,d.jsxs)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 20 20`,fill:`none`,children:[(0,d.jsx)(`path`,{d:`M16 6l-7 9-3-3`,stroke:`currentColor`,strokeWidth:`1.7`,strokeLinecap:`round`,strokeLinejoin:`round`}),(0,d.jsx)(`circle`,{cx:`10`,cy:`10`,r:`8`,stroke:`currentColor`,strokeWidth:`1.2`,opacity:`0.35`})]},`i2`),(0,d.jsxs)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 20 20`,fill:`none`,children:[(0,d.jsx)(`path`,{d:`M10 6v5l3 2`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`,strokeLinejoin:`round`}),(0,d.jsx)(`circle`,{cx:`10`,cy:`10`,r:`7.5`,stroke:`currentColor`,strokeWidth:`1.2`})]},`i3`),(0,d.jsxs)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 20 20`,fill:`none`,children:[(0,d.jsx)(`path`,{d:`M6 6l8 8M14 6l-8 8`,stroke:`currentColor`,strokeWidth:`1.7`,strokeLinecap:`round`}),(0,d.jsx)(`circle`,{cx:`10`,cy:`10`,r:`8`,stroke:`currentColor`,strokeWidth:`1.2`,opacity:`0.35`})]},`i4`),(0,d.jsxs)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 20 20`,fill:`none`,children:[(0,d.jsx)(`path`,{d:`M10 6v5`,stroke:`currentColor`,strokeWidth:`1.7`,strokeLinecap:`round`}),(0,d.jsx)(`path`,{d:`M10 14v.5`,stroke:`currentColor`,strokeWidth:`1.9`,strokeLinecap:`round`}),(0,d.jsx)(`circle`,{cx:`10`,cy:`10`,r:`8`,stroke:`currentColor`,strokeWidth:`1.2`})]},`i5`)];return(0,d.jsxs)(`div`,{className:`db-stat`,style:{"--sc":e.color,"--si":e.bg},children:[(0,d.jsxs)(`div`,{className:`db-stat-head`,children:[(0,d.jsx)(`div`,{className:`db-stat-icon`,children:n[t]}),(0,d.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,style:{color:`#c8bfb5`},children:[(0,d.jsx)(`circle`,{cx:`4`,cy:`8`,r:`1.2`,fill:`currentColor`}),(0,d.jsx)(`circle`,{cx:`8`,cy:`8`,r:`1.2`,fill:`currentColor`}),(0,d.jsx)(`circle`,{cx:`12`,cy:`8`,r:`1.2`,fill:`currentColor`})]})]}),(0,d.jsx)(`p`,{className:`db-stat-label`,children:e.title}),(0,d.jsx)(`div`,{className:`db-stat-val`,children:e.value}),(0,d.jsxs)(`div`,{className:`db-stat-footer`,children:[(0,d.jsx)(`svg`,{width:`12`,height:`12`,viewBox:`0 0 12 12`,fill:`none`,children:(0,d.jsx)(`path`,{d:`M2 9l3-4 2 2 3-5`,stroke:`#22c55e`,strokeWidth:`1.4`,strokeLinecap:`round`,strokeLinejoin:`round`})}),(0,d.jsxs)(`span`,{className:`db-stat-trend`,children:[B,`%`]}),(0,d.jsx)(`span`,{children:e.hint})]})]},e.title)})}),(0,d.jsxs)(`div`,{className:`db-panel`,children:[(0,d.jsxs)(`div`,{className:`db-panel-head`,children:[(0,d.jsxs)(`div`,{className:`db-panel-title-group`,children:[(0,d.jsx)(`div`,{className:`db-panel-icon`,style:{"--pi":`#fef3c7`,"--pc":`#b45309`},children:(0,d.jsx)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:(0,d.jsx)(`path`,{d:`M4 3h8M5 7h6M6 11h4`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})})}),(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`p`,{className:`db-panel-title`,children:`Attendance Register`}),(0,d.jsxs)(`p`,{className:`db-panel-sub`,children:[F?`Teacher access · assigned class`:`Admin access · all classes`,` ·`,` `,(0,d.jsx)(`span`,{style:{fontWeight:500},children:R})]})]})]}),(0,d.jsxs)(`button`,{className:`db-refresh-btn`,onClick:H,disabled:j||!y,children:[(0,d.jsxs)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,style:{animation:j?`dbSpin 0.8s linear infinite`:`none`},children:[(0,d.jsx)(`path`,{d:`M12 7A5 5 0 112 7`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,d.jsx)(`path`,{d:`M12 3v4h-4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),j?`Loading…`:`Refresh`]})]}),(0,d.jsxs)(`div`,{className:`db-toolbar`,children:[(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`div`,{style:{fontWeight:700,color:`#1a1a2e`},children:`Filters`}),(0,d.jsxs)(`div`,{style:{fontSize:12.5,color:`#9a8a7a`},children:[`Select the academic week, class and attendance date. `,F?`Your class may be locked.`:`Admins can switch classes.`]})]}),(0,d.jsxs)(`div`,{className:`db-field`,children:[(0,d.jsxs)(`select`,{className:`db-select`,value:T,onChange:e=>K(e.target.value),disabled:j||k||!C.configured,title:`Select academic week`,children:[(0,d.jsx)(`option`,{value:``,children:C.configured?`Select Week`:`Set session dates first`}),C.weeks.map(e=>(0,d.jsxs)(`option`,{value:e.number,children:[e.label,` · `,e.start_date,` to `,e.end_date]},e.number))]}),(0,d.jsxs)(`select`,{className:`db-select`,value:y,disabled:j||k||I,onChange:e=>b(e.target.value),title:I?`Teacher class is fixed`:`Select class`,children:[(0,d.jsx)(`option`,{value:``,children:k?`Loading classes…`:`Select Class`}),_.map(e=>(0,d.jsx)(`option`,{value:e.id,children:e.name},e.id))]}),(0,d.jsx)(`input`,{type:`date`,className:`db-input`,value:x,onChange:e=>S(e.target.value),disabled:j||k,min:C.weeks.find(e=>String(e.number)===T)?.start_date,max:C.weeks.find(e=>String(e.number)===T)?.end_date}),(0,d.jsx)(`button`,{className:`db-mini-btn`,onClick:H,disabled:j||!y,children:j?(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(`span`,{style:{width:14,height:14,borderRadius:`50%`,border:`2px solid rgba(122,106,90,0.35)`,borderTopColor:`#7a6a5a`,display:`inline-block`,animation:`dbSpin 0.8s linear infinite`}}),`Load`]}):(0,d.jsxs)(d.Fragment,{children:[(0,d.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,d.jsx)(`path`,{d:`M13.5 8A5.5 5.5 0 113 8`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`}),(0,d.jsx)(`path`,{d:`M13.5 4.5V8H10`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),`Load`]})}),(0,d.jsxs)(`button`,{className:`db-mini-btn db-mini-btn--g`,onClick:U,disabled:N||!y||!T||D.length===0,children:[(0,d.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:(0,d.jsx)(`path`,{d:`M13.5 4.5l-6.5 7L2.5 7`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`,strokeLinejoin:`round`})}),`Save`]})]})]}),(0,d.jsx)(`div`,{style:{overflowX:`auto`},children:(0,d.jsxs)(`table`,{className:`db-table`,children:[(0,d.jsx)(`thead`,{children:(0,d.jsxs)(`tr`,{children:[(0,d.jsx)(`th`,{style:{width:60},children:`#`}),(0,d.jsx)(`th`,{style:{width:160},children:`Adm No`}),(0,d.jsx)(`th`,{style:{width:360},children:`Student`}),(0,d.jsx)(`th`,{style:{width:160},children:`Status`}),(0,d.jsx)(`th`,{style:{width:420},children:`Mark`}),(0,d.jsx)(`th`,{style:{width:320},children:`Remark`})]})}),(0,d.jsx)(`tbody`,{children:j?Array.from({length:8}).map((e,t)=>(0,d.jsxs)(`tr`,{children:[(0,d.jsx)(`td`,{children:(0,d.jsx)(`div`,{className:`db-skeleton`,style:{width:36}})}),(0,d.jsx)(`td`,{children:(0,d.jsx)(`div`,{className:`db-skeleton`,style:{width:120}})}),(0,d.jsx)(`td`,{children:(0,d.jsx)(`div`,{className:`db-skeleton`,style:{width:220}})}),(0,d.jsx)(`td`,{children:(0,d.jsx)(`div`,{className:`db-skeleton`,style:{width:110}})}),(0,d.jsx)(`td`,{children:(0,d.jsx)(`div`,{className:`db-skeleton`,style:{width:280}})}),(0,d.jsx)(`td`,{children:(0,d.jsx)(`div`,{className:`db-skeleton`,style:{width:220}})})]},t)):y?D.length===0?(0,d.jsx)(`tr`,{children:(0,d.jsxs)(`td`,{colSpan:6,className:`db-table-empty`,children:[(0,d.jsx)(`div`,{style:{fontWeight:700,color:`#1a1a2e`},children:`No students found`}),(0,d.jsx)(`div`,{style:{marginTop:6},children:`This class has no students or you don’t have permission.`})]})}):D.map((e,t)=>{let n=e.attendances?.[0]?.status,r=q(n);return(0,d.jsxs)(`tr`,{children:[(0,d.jsx)(`td`,{children:(0,d.jsx)(`img`,{src:L(e.photo),alt:`${e.firstname} ${e.surname}`,className:`db-avatar`})}),(0,d.jsx)(`td`,{children:(0,d.jsx)(`span`,{className:`db-score-pill`,style:{background:`rgba(30,64,175,0.10)`,color:`#1e40af`},children:e.adm_no})}),(0,d.jsxs)(`td`,{children:[(0,d.jsxs)(`div`,{className:`db-name`,children:[e.firstname,` `,e.surname]}),(0,d.jsxs)(`div`,{className:`db-muted`,children:[R,` · `,x]})]}),(0,d.jsx)(`td`,{children:(0,d.jsx)(`span`,{className:`db-score-pill`,style:{background:r.bg,color:r.color},children:r.label})}),(0,d.jsx)(`td`,{children:(0,d.jsxs)(`div`,{style:{display:`flex`,gap:8,flexWrap:`wrap`},children:[(0,d.jsx)(`button`,{className:J(n===`present`,`g`),onClick:()=>W(t,`present`),type:`button`,children:`Present`}),(0,d.jsx)(`button`,{className:J(n===`absent`,`r`),onClick:()=>W(t,`absent`),type:`button`,children:`Absent`}),(0,d.jsx)(`button`,{className:J(n===`late`,`b`),onClick:()=>W(t,`late`),type:`button`,children:`Late`}),(0,d.jsx)(`button`,{className:J(n===`excused`,`o`),onClick:()=>W(t,`excused`),type:`button`,children:`Excused`})]})}),(0,d.jsx)(`td`,{children:(0,d.jsx)(`input`,{className:`db-remark`,value:e.attendances?.[0]?.remarks||``,onChange:e=>G(t,e.target.value),placeholder:`Optional remark…`})})]},e.id)}):(0,d.jsx)(`tr`,{children:(0,d.jsxs)(`td`,{colSpan:6,className:`db-table-empty`,children:[(0,d.jsx)(`div`,{style:{fontWeight:700,color:`#1a1a2e`},children:`Select a class`}),(0,d.jsx)(`div`,{style:{marginTop:6},children:`Choose a class to load students for attendance.`})]})})})]})}),(0,d.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,gap:12,flexWrap:`wrap`,padding:`14px 20px`,borderTop:`1px solid rgba(0,0,0,0.06)`},children:[(0,d.jsxs)(`div`,{style:{fontSize:12.5,color:`#9a8a7a`},children:[`Tip: Save once after marking everyone. Unmarked students default to `,(0,d.jsx)(`b`,{children:`Absent`}),`.`]}),(0,d.jsxs)(`button`,{className:`db-mini-btn db-mini-btn--g`,onClick:U,disabled:N||!y||!T||D.length===0,type:`button`,children:[(0,d.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:(0,d.jsx)(`path`,{d:`M13.5 4.5l-6.5 7L2.5 7`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`,strokeLinejoin:`round`})}),`Save Attendance`]})]})]}),(0,d.jsx)(`div`,{className:`mt-auto`,style:{paddingTop:18},children:(0,d.jsx)(l,{})})]})]})})]})}export{p as default};