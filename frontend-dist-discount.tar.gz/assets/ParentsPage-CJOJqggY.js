import{i as e}from"./rolldown-runtime-CWU8vmCm.js";import{Ut as t}from"./vendor-misc-OZLc0tLq.js";import{p as n}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as r,E as i,P as a,d as ee,f as te,l as ne,u as re}from"./index-D6TxbaCx.js";import{t as ie}from"./PeopleImportPanel-CHz9v6Iy.js";var o=e(t(),1),s=n(),ae=e=>e?e.charAt(0).toUpperCase()+e.slice(1).toLowerCase():``,c=e=>[ae(e?.firstname),ae(e?.surname)].filter(Boolean).join(` `).trim()||`-`,oe=e=>((e?.firstname||``).trim().charAt(0).toUpperCase()+(e?.surname||``).trim().charAt(0).toUpperCase()).trim()||`P`,l=e=>(e??``).toString().toLowerCase(),u=e=>!!(e&&e!==`0000-00-00 00:00:00`),d=({label:e,value:t,icon:n})=>(0,s.jsxs)(`div`,{className:`pr-info`,children:[(0,s.jsxs)(`div`,{className:`pr-info-label`,children:[n?(0,s.jsx)(`span`,{className:`pr-info-ico`,children:n}):null,e]}),(0,s.jsx)(`div`,{className:`pr-info-val`,children:t&&t!==``?t:`N/A`})]}),se=({label:e,value:t,tone:n=`gray`,icon:r})=>(0,s.jsxs)(`div`,{className:`pr-info`,children:[(0,s.jsxs)(`div`,{className:`pr-info-label`,children:[r?(0,s.jsx)(`span`,{className:`pr-info-ico`,children:r}):null,e]}),(0,s.jsx)(`div`,{className:`pr-pill pr-pill--${n}`,children:t&&t!==``?t:`N/A`})]}),f={people:(0,s.jsxs)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 20 20`,fill:`none`,children:[(0,s.jsx)(`circle`,{cx:`8`,cy:`6`,r:`3`,stroke:`currentColor`,strokeWidth:`1.5`}),(0,s.jsx)(`path`,{d:`M2 18c0-3.314 2.686-6 6-6`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`}),(0,s.jsx)(`circle`,{cx:`15`,cy:`10`,r:`2.5`,stroke:`currentColor`,strokeWidth:`1.4`}),(0,s.jsx)(`path`,{d:`M11 18c0-2.209 1.791-4 4-4s4 1.791 4 4`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`})]}),mail:(0,s.jsxs)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 20 20`,fill:`none`,children:[(0,s.jsx)(`path`,{d:`M3 6a2 2 0 012-2h10a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2V6z`,stroke:`currentColor`,strokeWidth:`1.5`}),(0,s.jsx)(`path`,{d:`M4 6l6 5 6-5`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),phone:(0,s.jsx)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 20 20`,fill:`none`,children:(0,s.jsx)(`path`,{d:`M7.2 4.2l1.5 3.1c.2.4.1.9-.2 1.2l-1.3 1.3c1.1 2 2.8 3.7 4.8 4.8l1.3-1.3c.3-.3.8-.4 1.2-.2l3.1 1.5c.5.2.7.8.5 1.3l-.7 1.8c-.2.5-.7.8-1.2.8C8.7 18.6 1.4 11.3 1.7 3.9c0-.5.3-1 .8-1.2l1.8-.7c.5-.2 1.1 0 1.3.5z`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinejoin:`round`})}),child:(0,s.jsxs)(`svg`,{width:`18`,height:`18`,viewBox:`0 0 20 20`,fill:`none`,children:[(0,s.jsx)(`circle`,{cx:`10`,cy:`7`,r:`3.2`,stroke:`currentColor`,strokeWidth:`1.5`}),(0,s.jsx)(`path`,{d:`M3 18c0-3.9 3.1-7 7-7s7 3.1 7 7`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`}),(0,s.jsx)(`path`,{d:`M6.2 6.2c.5-1.8 2-3.1 3.8-3.1s3.3 1.3 3.8 3.1`,stroke:`currentColor`,strokeWidth:`1.2`,strokeLinecap:`round`})]}),refresh:(0,s.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,children:[(0,s.jsx)(`path`,{d:`M12 7A5 5 0 112 7`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,s.jsx)(`path`,{d:`M12 3v4h-4`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),plus:(0,s.jsx)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,children:(0,s.jsx)(`path`,{d:`M7 2v10M2 7h10`,stroke:`currentColor`,strokeWidth:`1.6`,strokeLinecap:`round`})}),search:(0,s.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 14 14`,fill:`none`,children:[(0,s.jsx)(`circle`,{cx:`6`,cy:`6`,r:`4`,stroke:`currentColor`,strokeWidth:`1.4`}),(0,s.jsx)(`path`,{d:`M9.5 9.5L12.5 12.5`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`})]}),eye:(0,s.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,s.jsx)(`path`,{d:`M1.5 8s2.5-4.5 6.5-4.5S14.5 8 14.5 8s-2.5 4.5-6.5 4.5S1.5 8 1.5 8z`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,s.jsx)(`circle`,{cx:`8`,cy:`8`,r:`2`,stroke:`currentColor`,strokeWidth:`1.3`})]}),trash:(0,s.jsxs)(`svg`,{width:`14`,height:`14`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,s.jsx)(`path`,{d:`M3 5h10`,stroke:`currentColor`,strokeWidth:`1.4`,strokeLinecap:`round`}),(0,s.jsx)(`path`,{d:`M6 5V3.5A1.5 1.5 0 017.5 2h1A1.5 1.5 0 0110 3.5V5`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,s.jsx)(`path`,{d:`M5 5l.5 9h5L11 5`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinejoin:`round`}),(0,s.jsx)(`path`,{d:`M7 7.5v5M9 7.5v5`,stroke:`currentColor`,strokeWidth:`1.2`,strokeLinecap:`round`})]}),shield:(0,s.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,s.jsx)(`path`,{d:`M8 1.5l5 2v4.4c0 3.3-2.2 6-5 6.6-2.8-.6-5-3.3-5-6.6V3.5l5-2z`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinejoin:`round`}),(0,s.jsx)(`path`,{d:`M6.2 8.2l1.2 1.2 2.6-2.6`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})]}),key:(0,s.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,s.jsx)(`circle`,{cx:`5.2`,cy:`8.2`,r:`2.6`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,s.jsx)(`path`,{d:`M7.8 8.2H14V6.6h-2V5h-2V3.8`,stroke:`currentColor`,strokeWidth:`1.3`,strokeLinecap:`round`,strokeLinejoin:`round`})]})};function p(){let{showSuccess:e,showError:t}=ne(),[n,ae]=(0,o.useState)(!1),[p,ce]=(0,o.useState)([]),[m,le]=(0,o.useState)([]),[h,ue]=(0,o.useState)(``),[g,_]=(0,o.useState)(1),[v]=(0,o.useState)(8),[de,fe]=(0,o.useState)(1),[y,b]=(0,o.useState)(!1),[pe,me]=(0,o.useState)(!1),[x,S]=(0,o.useState)(null),[C,w]=(0,o.useState)(null),[T,E]=(0,o.useState)(!1),[D,O]=(0,o.useState)(`overview`),[k,he]=(0,o.useState)(!1),[ge,A]=(0,o.useState)(!1),[j,_e]=(0,o.useState)(!1),[M,N]=(0,o.useState)({firstname:``,surname:``,email:``,phone:``,address:``,password:``}),[ve,P]=(0,o.useState)(!1),[F,ye]=(0,o.useState)(!1),[I,L]=(0,o.useState)({firstname:``,surname:``,email:``,phone:``,address:``}),[be,xe]=(0,o.useState)(``),[Se,Ce]=(0,o.useState)(!1),[R,we]=(0,o.useState)(!1),[z,Te]=(0,o.useState)([]),[Ee,De]=(0,o.useState)(!1),[Oe,ke]=(0,o.useState)(``),[B,Ae]=(0,o.useState)([]),[V,je]=(0,o.useState)(!1),[H,Me]=(0,o.useState)([]),[Ne,Pe]=(0,o.useState)(``),[U,W]=(0,o.useState)([]),[Fe,Ie]=(0,o.useState)(``),[G,Le]=(0,o.useState)(``),[K,q]=(0,o.useState)(``),[J,Y]=(0,o.useState)(null),X=(0,o.useMemo)(()=>p.find(e=>e.id===Number(Fe))||null,[p,Fe]);(0,o.useEffect)(()=>{X&&(Le(X.whatsapp_number||X.whatsapp_no||X.phone||``),q(``))},[X]);let Re=e=>{e?.id&&(ce(t=>t.map(t=>t.id===e.id?{...t,...e}:t)),le(t=>t.map(t=>t.id===e.id?{...t,...e}:t)),w(t=>t?.parent?.id===e.id?{...t,parent:{...t.parent,...e}}:t),S(t=>t?.id===e.id?{...t,...e}:t))},ze=async()=>{if(!X)return t(`Select a parent first`);if(!G.trim())return t(`Enter a phone number first`);Y(`phone`);try{let t=await a.post(`/parents/${X.id}/validate-phone`,{phone:G.trim()});Re(t.data?.parent),e(t.data?.message||`Phone number validated`)}catch(e){t(e?.response?.data?.message||`Phone validation failed`)}finally{Y(null)}},Be=async()=>{if(!X)return t(`Select a parent first`);if(!G.trim())return t(`Enter a WhatsApp number first`);Y(`send`);try{let t=await a.post(`/parents/${X.id}/whatsapp/send-code`,{phone:G.trim()});Re(t.data?.parent),q(``),e(t.data?.message||`WhatsApp code sent`)}catch(e){t(e?.response?.data?.message||`Unable to send WhatsApp code`)}finally{Y(null)}},Ve=async()=>{if(!X)return t(`Select a parent first`);if(!K.trim())return t(`Enter the WhatsApp code`);Y(`verify`);try{let t=await a.post(`/parents/${X.id}/whatsapp/verify-code`,{code:K.trim()});Re(t.data?.parent),q(``),e(t.data?.message||`WhatsApp number verified`)}catch(e){t(e?.response?.data?.message||`WhatsApp verification failed`)}finally{Y(null)}},He=()=>{let e=new Date().getHours();return e<12?`Good morning`:e<17?`Good afternoon`:`Good evening`},Z=async()=>{b(!0);try{ce((await a.get(`/parents`)).data||[])}catch(e){console.error(e),t(e?.response?.data?.message??`Failed to load parents`)}finally{b(!1)}},Ue=()=>{let e=h.trim().toLowerCase(),t=e?p.filter(t=>[l(t.firstname),l(t.surname),l(t.email),l(t.phone)].join(` `).includes(e)):p,n=Math.max(1,Math.ceil(t.length/v));fe(n);let r=Math.min(g,n);r!==g&&_(r);let i=(r-1)*v;le(t.slice(i,i+v))};(0,o.useEffect)(()=>{Z()},[]),(0,o.useEffect)(()=>{Ue()},[p,h,g]);let Q=async e=>{S(e),w(null),E(!0),O(`overview`),A(!1),N({firstname:``,surname:``,email:``,phone:``,address:``,password:``}),he(!1);try{w((await a.get(`/parents/${e.id}`)).data)}catch(e){console.error(e),t(e?.response?.data?.message??`Failed to load parent profile`),S(null)}finally{E(!1)}},$=()=>{S(null),w(null),E(!1),O(`overview`),A(!1),N({firstname:``,surname:``,email:``,phone:``,address:``,password:``}),he(!1)},We=async()=>{if(x){E(!0),O(`overview`);try{let e=(await a.get(`/parents/${x.id}/edit`)).data?.parent;A(!0),w(t=>({parent:e,children:t?.children??[]})),N({firstname:e?.firstname||``,surname:e?.surname||``,email:e?.email||``,phone:e?.phone||``,address:e?.address||``,password:``})}catch(e){console.error(e),t(e?.response?.data?.message??`Failed to fetch parent for edit`)}finally{E(!1)}}},Ge=()=>{A(!1),N({firstname:``,surname:``,email:``,phone:``,address:``,password:``})},Ke=async()=>{if(x){if(!M.firstname.trim())return t(`Firstname is required`);if(!M.surname.trim())return t(`Surname is required`);if(!M.email.trim())return t(`Email is required`);if(!M.phone.trim())return t(`Phone is required`);_e(!0);try{await a.put(`/parents/${x.id}`,{firstname:M.firstname.trim(),surname:M.surname.trim(),email:M.email.trim(),phone:M.phone.trim(),address:M.address?.trim()||null,password:M.password?.trim()||null}),e(`Parent updated successfully!`),A(!1),await Z(),await Q({id:x.id})}catch(e){console.error(e),t(e?.response?.data?.message||`Failed to update parent`)}finally{_e(!1)}}},qe=async n=>{if(window.confirm(`Delete ${c(n)}?`)){b(!0);try{await a.delete(`/delete-parent/${n.id}`),e(`Parent deleted successfully`),$(),_(1),await Z()}catch(e){console.error(e),t(e?.response?.data?.message||`Failed to delete parent`)}finally{b(!1)}}},Je=()=>{L({firstname:``,surname:``,email:``,phone:``,address:``}),xe(``),P(!0)},Ye=()=>{F||P(!1)},Xe=async()=>{if(!I.firstname.trim())return t(`Firstname is required`);if(!I.surname.trim())return t(`Surname is required`);if(!I.email.trim())return t(`Email is required`);if(!I.phone.trim())return t(`Phone is required`);ye(!0);try{let t=await a.post(`/parents/register`,{firstname:I.firstname.trim(),surname:I.surname.trim(),email:I.email.trim(),phone:I.phone.trim(),address:I.address?.trim()||null});xe(t.data?.default_password||``),e(t.data?.message||`Parent registered successfully!`),await Z();let n=t.data?.parent;n?.id&&(P(!1),await Q(n),O(`security`))}catch(e){console.error(e),t(e?.response?.data?.message||`Failed to register parent`)}finally{ye(!1)}},Ze=async()=>{De(!0);try{Te((await a.get(`/student-classes`)).data||[])}catch(e){console.error(e),t(e?.response?.data?.message||`Failed to load classes`),Te([])}finally{De(!1)}},Qe=async()=>{x&&(Ce(!0),ke(``),Ae([]),Me([]),Pe(``),W([]),await Ze())},$e=()=>{R||V||Ee||Ce(!1)},et=(0,o.useMemo)(()=>{let e=Oe.trim().toLowerCase();return e?z.filter(t=>l(t.name).includes(e)):z},[z,Oe]),tt=e=>{Ae(t=>t.includes(e)?t.filter(t=>t!==e):[...t,e])},nt=async()=>{if(!B.length)return t(`Select at least one class`);if(!x)return t(`No parent selected`);je(!0);try{let e=(await a.post(`/students/by-classes`,{class_ids:B,parent_id:x.id})).data?.students||[];Me(e),W(e.filter(e=>e.assigned_parent_id===x.id).map(e=>e.id)),e.length===0&&t(`No students found in selected classes`)}catch(e){console.error(e),t(e?.response?.data?.message||`Failed to load students`)}finally{je(!1)}},rt=(0,o.useMemo)(()=>{let e=Ne.trim().toLowerCase();return e?H.filter(t=>(t.level?.name,hay.includes(e))):H},[H,Ne]),it=e=>{if(x){if(e.assigned_parent_id&&e.assigned_parent_id!==x.id)return t(`This student is already assigned to ${`${e.assigned_parent_firstname||``} ${e.assigned_parent_surname||``}`.trim()||`another parent`}`);W(t=>t.includes(e.id)?t.filter(t=>t!==e.id):[...t,e.id])}},at=async()=>{if(!x)return t(`No parent selected`);if(!U.length)return t(`Select at least one student`);let n=new Set(H.filter(e=>e.assigned_parent_id===x.id).map(e=>e.id)),r=U.filter(e=>!n.has(e));if(r.length===0)return t(`Selected students are already assigned to this parent.`);we(!0);try{await a.post(`/parents/assign-child`,{parent_id:x.id,student_ids:r}),e(`Students assigned successfully`),Ce(!1),await Q({id:x.id}),O(`children`)}catch(e){console.error(e),t(e?.response?.data?.message||`Failed to assign students`)}finally{we(!1)}},ot=async n=>{if(x&&window.confirm(`Remove this student from this parent?`)){E(!0);try{await a.delete(`/parents/remove-child`,{data:{parent_id:x.id,student_id:n}}),e(`Student removed from parent`),await Q({id:x.id}),O(`children`)}catch(e){console.error(e),t(e?.response?.data?.message||`Failed to remove student`)}finally{E(!1)}}},st=m?.length??0,ct=(0,o.useMemo)(()=>m.filter(e=>!!(e.email&&e.email.trim())).length,[m]),lt=(0,o.useMemo)(()=>m.filter(e=>!!(e.phone&&e.phone.trim())).length,[m]),ut=(0,o.useMemo)(()=>m.filter(e=>u(e.phone_validated_at)).length,[m]),dt=(0,o.useMemo)(()=>m.filter(e=>u(e.whatsapp_verified_at)).length,[m]),ft=C?.children?.length??0,pt=async n=>{try{await navigator.clipboard.writeText(n),e(`Copied!`)}catch{t(`Copy failed (browser blocked)`)}},mt=y||j||F||R||!!J;return(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)(`style`,{children:`
/* =========================
   ParentsPage - "AdminDashboard" template skin
   (inline styles per your request)
========================= */

/* Fonts:
   Put this in public/index.html (recommended):
   <link rel="preconnect" href="https://fonts.googleapis.com">
   <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
   <link href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,700;1,400&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
*/

.pr-main{
  background: var(--bs-body-bg, #f5f1eb);
  min-height: 100vh;
  background: #F8FAFC;
  font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
  padding: 24px 28px 34px;
  margin-left: 280px;
  width: calc(100% - 280px);
  max-width: calc(100% - 280px);
  overflow-x: hidden;
}
@media (max-width: 991.98px){
  .pr-main{
    margin-left: 0;
    width: 100%;
    max-width: 100%;
    padding: 18px 14px 28px;
  }
}

.pr-hero{
  background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
  border-radius: 18px;
  padding: 32px 36px;
  position:relative;
  overflow:hidden;
  margin-bottom: 24px;
  box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
}
.pr-hero-glow{
  position:absolute; top:-60px; right:-60px;
  width:320px; height:320px; border-radius:50%;
  background: radial-gradient(circle, rgba(217,119,6,0.15) 0%, transparent 65%);
  pointer-events:none;
}
.pr-hero-glow2{
  position:absolute; bottom:-40px; left:30%;
  width:220px; height:220px; border-radius:50%;
  background: radial-gradient(circle, rgba(37,99,235,0.10) 0%, transparent 70%);
  pointer-events:none;
}
.pr-hero-inner{
  position:relative; z-index:1;
  display:flex; align-items:center; justify-content:space-between;
  gap:32px; flex-wrap:wrap;
}
.pr-session-badge{
  display:inline-flex; align-items:center; gap:7px;
  font-size:11.5px; font-weight:700; letter-spacing:0.04em;
  text-transform:uppercase;
  color:#FBBF24;
  background: rgba(217,119,6,0.20);
  border: 1px solid rgba(217,119,6,0.35);
  border-radius:999px;
  padding: 4px 12px;
  margin-bottom: 12px;
}
.pr-session-dot{
  width:6px; height:6px; border-radius:50%;
  background:#10B981;
  animation: prPulse 2s ease infinite;
}
@keyframes prPulse{
  0%,100%{ opacity:1; transform:scale(1); }
  50%{ opacity:.4; transform:scale(1.5); }
}
.pr-greeting{
  font-size: 26px;
  font-weight:800;
  color:#fff;
  line-height:1.1;
  margin-bottom: 8px;
}
.pr-greeting em{ font-style:normal; color:#FBBF24; }
.pr-hero-sub{
  font-size: 13.5px; color:#CBD5E1;
  line-height:1.6; max-width:520px; margin-bottom: 20px;
}
.pr-hero-btns{ display:flex; gap:10px; flex-wrap:wrap; }

.pr-btn-gold{
  display:inline-flex; align-items:center; gap:7px;
  padding: 9px 18px;
  font-size:13px; font-weight:700;
  color:#FFFFFF;
  background:#D97706;
  border:none;
  border-radius: 10px;
  cursor:pointer;
  transition: all .2s ease;
  text-decoration:none;
  white-space:nowrap;
}
.pr-btn-gold:hover{ background:#B45309; transform: translateY(-1px); color:#fff; }

.pr-btn-outline{
  display:inline-flex; align-items:center; gap:7px;
  padding: 9px 18px;
  font-size:13px; font-weight:600;
  color: #FFFFFF;
  background: rgba(255,255,255,0.10);
  border: 1px solid rgba(255,255,255,0.20);
  border-radius: 10px;
  cursor:pointer;
  transition: all .2s ease;
  white-space:nowrap;
}
.pr-btn-outline:hover{
  background: rgba(255,255,255,0.06);
  color:#fff;
  border-color: rgba(255,255,255,0.28);
}
.pr-btn-outline:disabled, .pr-btn-gold:disabled{
  opacity:.6; cursor:not-allowed;
}

.pr-hero-stat-card{
  background: rgba(255,255,255,0.05);
  border: 1px solid rgba(255,255,255,0.09);
  backdrop-filter: blur(8px);
  border-radius: 12px;
  padding: 18px 20px;
  min-width: 240px;
}
.pr-hero-stat-row{ display:flex; flex-direction:column; gap:10px; }
.pr-hero-stat-item{ display:flex; align-items:center; justify-content:space-between; gap:16px; }
.pr-hero-stat-label{ font-size:12px; font-weight:300; color:#64748b; }
.pr-hero-stat-val{ font-family:"Lora", serif; font-size:18px; font-weight:700; color:#fff; }
.pr-hero-stat-sep{ height:1px; background: rgba(255,255,255,0.06); }

.pr-stats{
  display:grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
  margin-bottom: 18px;
}
@media (max-width: 1199.98px){ .pr-stats{ grid-template-columns: repeat(2, 1fr);} }
@media (max-width: 575.98px){ .pr-stats{ grid-template-columns: 1fr; } }

.pr-stat{
  background: var(--bs-body-bg, #fff);
  border: 1px solid var(--bs-border-color, #ede8e0);
  border-radius: 14px;
  padding: 22px 20px;
  position: relative;
  overflow:hidden;
  transition: box-shadow .25s, transform .25s;
}
.pr-stat:hover{ box-shadow: 0 8px 28px rgba(0,0,0,0.08); transform: translateY(-3px); }
.pr-stat::before{
  content:"";
  position:absolute; top:0; left:0; right:0; height:3px;
  background: var(--sc, #b45309);
  transform: scaleX(0);
  transform-origin: left;
  transition: transform .3s ease;
}
.pr-stat:hover::before{ transform: scaleX(1); }

.pr-stat-head{ display:flex; align-items:flex-start; justify-content:space-between; margin-bottom: 14px; }
.pr-stat-icon{
  width:42px; height:42px; border-radius:10px;
  background: var(--si, #fef3c7);
  color: var(--sc, #b45309);
  display:flex; align-items:center; justify-content:center;
  transition: transform .3s cubic-bezier(0.34, 1.56, 0.64, 1);
}
.pr-stat:hover .pr-stat-icon{ transform: scale(1.1) rotate(-4deg); }
.pr-stat-label{ font-size:12px; font-weight:400; color:#9a8a7a; margin-bottom:5px; letter-spacing:.03em; }
.pr-stat-val{
  font-family:"Lora", Georgia, serif;
  font-size: 30px;
  font-weight:700;
  color:#1a1a2e;
  line-height:1;
}
.pr-stat-footer{
  display:flex; align-items:center; gap:6px;
  margin-top: 14px; padding-top: 12px;
  border-top: 1px solid rgba(0,0,0,0.06);
  font-size:12px; color:#9a8a7a;
}
.pr-stat-trend{ color:#22c55e; font-weight:500; }

.pr-grid{
  display:grid;
  grid-template-columns: 1fr 360px;
  gap: 20px;
  margin-bottom: 18px;
}
@media (max-width: 991.98px){ .pr-grid{ grid-template-columns: 1fr; } }

.pr-panel{
  background: var(--bs-body-bg, #fff);
  border: 1px solid var(--bs-border-color, #ede8e0);
  border-radius: 14px;
  overflow:hidden;
}
.pr-panel-head{
  display:flex; align-items:center; justify-content:space-between;
  padding: 20px 22px 16px;
  border-bottom: 1px solid rgba(0,0,0,0.06);
  gap: 12px;
}
.pr-panel-title-group{ display:flex; align-items:center; gap: 12px; }
.pr-panel-icon{
  width:36px; height:36px; border-radius: 9px;
  display:flex; align-items:center; justify-content:center;
  background: var(--pi, #fef3c7);
  color: var(--pc, #b45309);
  flex-shrink:0;
}
.pr-panel-title{
  font-family:"Lora", serif;
  font-size:16px; font-weight:700;
  color:#1a1a2e; margin:0;
}
.pr-panel-sub{ font-size:11.5px; font-weight:300; color:#9a8a7a; margin:0; }

.pr-table{ width:100%; border-collapse: collapse; }
.pr-table th{
  padding: 10px 16px;
  font-size: 11px;
  font-weight: 500;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: #9a8a7a;
  background: #faf8f5;
  border-bottom: 1px solid rgba(0,0,0,0.06);
  text-align:left;
  white-space:nowrap;
}
.pr-table th:last-child{ text-align:right; }
.pr-table td{
  padding: 13px 16px;
  font-size: 13.5px;
  color: #4a4a5a;
  border-bottom: 1px solid rgba(0,0,0,0.06);
  vertical-align: middle;
}
.pr-table tbody tr:last-child td{ border-bottom:none; }
.pr-table tbody tr{ transition: background .15s; }
.pr-table tbody tr:hover{ background:#faf8f5; }

.pr-row-title{
  display:flex; align-items:center; gap:12px;
}
.pr-avatar{
  width: 42px; height: 42px;
  border-radius: 999px;
  background: #fef3c7;
  color: #b45309;
  display:flex; align-items:center; justify-content:center;
  font-weight: 800;
  border: 1px solid rgba(180,83,9,0.18);
  flex-shrink:0;
}
.pr-name{ font-weight:600; color:#1a1a2e; line-height:1.1; }
.pr-subtle{ color:#9a8a7a; font-size: 12.5px; }

.pr-actions{
  display:grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 14px;
  margin-bottom: 22px;
}
@media (max-width: 991.98px){ .pr-actions{ grid-template-columns: repeat(2, 1fr);} }
@media (max-width: 575.98px){ .pr-actions{ grid-template-columns: 1fr 1fr; } }

.pr-action{
  background: var(--bs-body-bg, #fff);
  border: 1px solid var(--bs-border-color, #ede8e0);
  border-radius: 14px;
  padding: 20px 18px;
  cursor:pointer;
  display:flex;
  flex-direction:column;
  gap:10px;
  transition: box-shadow .25s, transform .25s, border-color .25s;
  text-decoration:none;
  color: inherit;
}
.pr-action:hover{
  box-shadow: 0 8px 24px rgba(0,0,0,0.08);
  transform: translateY(-4px);
  border-color: var(--ac-border, #fde68a);
}
.pr-action-icon{
  width:46px; height:46px; border-radius: 12px;
  background: var(--ac-bg, #fef3c7);
  color: var(--ac-color, #b45309);
  display:flex; align-items:center; justify-content:center;
  transition: transform .3s cubic-bezier(0.34, 1.56, 0.64, 1);
}
.pr-action:hover .pr-action-icon{ transform: scale(1.1) rotate(-5deg); }
.pr-action-label{ font-size: 13.5px; font-weight: 600; color:#1a1a2e; }
.pr-action-desc{ font-size: 11.5px; font-weight: 300; color:#9a8a7a; }

.pr-pagination{
  display:flex; align-items:center; justify-content:space-between;
  padding: 14px 18px;
  flex-wrap:wrap;
  gap:10px;
  border-top: 1px solid rgba(0,0,0,0.06);
}
.pr-page-info{ font-size: 12px; font-weight: 300; color:#9a8a7a; }
.pr-page-btns{ display:flex; align-items:center; gap: 6px; }
.pr-page-btn{
  display:inline-flex; align-items:center; gap: 6px;
  padding: 6px 12px;
  font-size: 12.5px;
  font-weight: 400;
  color:#7a6a5a;
  background:#f5f1eb;
  border: 1px solid #e5ddd3;
  border-radius: 7px;
  cursor:pointer;
  transition: background .2s, color .2s;
}
.pr-page-btn:hover:not(:disabled){ background:#ede8e0; color:#1a1a2e; }
.pr-page-btn:disabled{ opacity:.45; cursor:not-allowed; }
.pr-page-current{ padding: 6px 12px; font-size: 12px; color:#9a8a7a; }

.pr-toolbar{
  padding: 14px 16px;
  display:flex;
  flex-wrap:wrap;
  gap: 10px;
  align-items:center;
  justify-content:space-between;
}
.pr-input{
  display:flex;
  align-items:center;
  gap: 8px;
  padding: 9px 12px;
  border-radius: 10px;
  background:#fff;
  border: 1px solid #ede8e0;
  min-width: 320px;
}
.pr-input input{
  border:none;
  outline:none;
  width: 100%;
  font-size: 13px;
  color:#1a1a2e;
}
.pr-clear{
  border:none;
  background: transparent;
  color:#9a8a7a;
  cursor:pointer;
  padding: 2px 4px;
}
.pr-clear:hover{ color:#1a1a2e; }

.pr-refresh{
  display:inline-flex; align-items:center; gap: 7px;
  padding: 9px 14px;
  font-size: 12.5px;
  font-weight: 400;
  color:#7a6a5a;
  background:#f5f1eb;
  border: 1px solid #e5ddd3;
  border-radius: 10px;
  cursor:pointer;
}
.pr-refresh:hover{ background:#ede8e0; }
.pr-refresh:disabled{ opacity:.55; cursor:not-allowed; }

.pr-mini-btn{
  display:inline-flex; align-items:center; gap: 7px;
  padding: 8px 12px;
  font-size: 12.5px;
  border-radius: 10px;
  border: 1px solid rgba(0,0,0,0.08);
  background: #fff;
  color:#1a1a2e;
  cursor:pointer;
}
.pr-mini-btn:hover{ background:#faf8f5; }
.pr-mini-btn--danger{ color:#9a3412; border-color: rgba(154,52,18,0.18); }
.pr-mini-btn--danger:hover{ background:#fff7ed; }
.pr-mini-btn:disabled{ opacity:.6; cursor:not-allowed; }

.pr-icon-btn{
  display:inline-flex; align-items:center; justify-content:center;
  width:36px; height:36px;
  border-radius:10px;
  font-size:15px;
  border: 1px solid rgba(0,0,0,0.08);
  background: #fff;
  color:#1a1a2e;
  cursor:pointer;
  transition: all .2s ease;
  flex-shrink:0;
}
.pr-icon-btn:hover{ background:#faf8f5; transform: translateY(-1px); }
.pr-icon-btn--view{ background: #fef3c7; color:#b45309; border-color:#fde68a; }
.pr-icon-btn--view:hover{ background: #fde68a; }
.pr-icon-btn--validate{ background: #dbeafe; color:#1e40af; border-color:#bfdbfe; }
.pr-icon-btn--validate:hover{ background: #bfdbfe; }
.pr-icon-btn--danger{ background:#fee2e2; color:#b91c1c; border-color: #fca5a5; }
.pr-icon-btn--danger:hover{ background:#fecaca; }

/* Modal shell */
.pr-overlay{
  position:fixed; inset:0;
  background: rgba(10, 25, 47, 0.70);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  display:flex; align-items:center; justify-content:center;
  z-index: 1400;
  padding: 16px;
}
.pr-modal{
  width: min(1100px, 96vw);
  max-height: 92vh;
  border-radius: 18px;
  overflow: hidden;
  background: #fff;
  border: 1px solid rgba(15, 39, 68, 0.12);
  box-shadow: 0 25px 60px -12px rgba(15, 39, 68, 0.35);
  font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
}
.pr-modal--md{ width: min(900px, 96vw); }
.pr-modal-head{
  background: linear-gradient(135deg, #0A192F 0%, #0F2744 100%);
  position:relative;
  padding: 22px 28px 16px;
  overflow:hidden;
  border-bottom: 1px solid rgba(255, 255, 255, 0.12);
}
.pr-modal-head::before{
  content:"";
  position:absolute;
  inset:0;
  background-image:
    linear-gradient(rgba(255, 255, 255, 0.035) 1px, transparent 1px),
    linear-gradient(90deg, rgba(255, 255, 255, 0.035) 1px, transparent 1px);
  background-size:24px 24px;
  pointer-events:none;
}
.pr-modal-head-inner{
  position:relative; z-index:1;
  display:flex; align-items:flex-start; justify-content:space-between;
  gap: 16px; flex-wrap: wrap;
}
.pr-modal-title{
  display:flex; align-items:center; gap: 14px;
  color:#fff;
}
.pr-modal-title h5{
  margin:0;
  font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
  font-weight:800;
  font-size: 18px;
  color: #FFFFFF;
}
.pr-modal-title p{
  margin:4px 0 0;
  font-size: 12.5px;
  color:#CBD5E1;
}
.pr-modal-body{
  background:#F8FAFC;
  padding: 24px;
  overflow:auto;
  max-height: calc(92vh - 150px);
}
.pr-modal-foot{
  padding: 16px 24px;
  border-top: 1px solid #E2E8F0;
  background:#fff;
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap: 12px;
  flex-wrap: wrap;
}
.pr-tabs{
  display:flex; flex-wrap:wrap; gap: 4px;
  margin-top: 16px;
  position: relative;
  z-index: 1;
  border-bottom: 2px solid rgba(255, 255, 255, 0.08);
}
.pr-tab{
  display:inline-flex; align-items:center; gap: 7px;
  padding: 9px 16px;
  border-radius: 8px 8px 0 0;
  font-size: 13px;
  font-weight: 600;
  border: none;
  background: transparent;
  color: rgba(255,255,255,0.7);
  cursor: pointer;
  transition: all 0.2s ease;
}
.pr-tab:hover{ background: rgba(255,255,255,0.08); color:#fff; }
.pr-tab--active{
  background: rgba(217,119,6,0.18);
  border-bottom: 2px solid #FBBF24;
  color:#FBBF24;
  font-weight: 700;
}

/* Inside modal content cards */
.pr-card{
  background:#fff;
  border: 1px solid #E2E8F0;
  border-radius: 14px;
  overflow:hidden;
  box-shadow: 0 2px 10px rgba(15, 39, 68, 0.04);
}
.pr-card-pad{ padding: 20px; }
.pr-form-grid{
  display:grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 12px;
}
@media (max-width: 991.98px){ .pr-form-grid{ grid-template-columns: repeat(2,1fr); } }
@media (max-width: 575.98px){ .pr-form-grid{ grid-template-columns: 1fr; } }

.pr-field label{
  display:block;
  font-size: 12px;
  color:#9a8a7a;
  font-weight: 500;
  margin-bottom: 6px;
  letter-spacing: .02em;
}
.pr-field input{
  width: 100%;
  border: 1px solid #ede8e0;
  border-radius: 10px;
  padding: 10px 12px;
  font-size: 13px;
  outline: none;
}
.pr-field input:focus{
  border-color: rgba(201,168,76,0.55);
  box-shadow: 0 0 0 3px rgba(201,168,76,0.16);
}

.pr-info-grid{
  display:grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 14px;
}
@media (max-width: 991.98px){ .pr-info-grid{ grid-template-columns: repeat(2, 1fr);} }
@media (max-width: 575.98px){ .pr-info-grid{ grid-template-columns: 1fr;} }

.pr-info-label{
  font-size: 12px;
  color:#9a8a7a;
  display:flex;
  align-items:center;
  gap: 8px;
  margin-bottom: 6px;
}
.pr-info-ico{
  width: 28px; height: 28px;
  border-radius: 9px;
  background:#faf8f5;
  border: 1px solid rgba(0,0,0,0.06);
  display:flex; align-items:center; justify-content:center;
  color:#7a6a5a;
  flex-shrink:0;
}
.pr-info-val{
  font-size: 13.5px;
  font-weight: 600;
  color:#1a1a2e;
}

.pr-pill{
  display:inline-flex; align-items:center; justify-content:center;
  font-size: 12.5px;
  font-weight: 600;
  padding: 5px 12px;
  border-radius: 999px;
  border: 1px solid rgba(0,0,0,0.06);
  background:#faf8f5;
  color:#7a6a5a;
  width: fit-content;
}
.pr-pill--gold{ background:#fef3c7; border-color: rgba(180,83,9,0.18); color:#b45309; }
.pr-pill--blue{ background:#dbeafe; border-color: rgba(30,64,175,0.18); color:#1e40af; }
.pr-pill--green{ background:#d1fae5; border-color: rgba(6,95,70,0.18); color:#065f46; }
.pr-pill--purple{ background:#ede9fe; border-color: rgba(124,58,237,0.18); color:#7c3aed; }
.pr-pill--gray{ background:#f1f5f9; border-color: rgba(71,85,105,0.16); color:#475569; }

.pr-validation-grid{
  display:grid;
  grid-template-columns: minmax(220px, 1.1fr) minmax(220px, 1fr) minmax(160px, .8fr);
  gap:12px;
  padding:16px;
}
@media (max-width: 991.98px){ .pr-validation-grid{ grid-template-columns:1fr; } }
.pr-field select{
  width:100%;
  border:1px solid #ede8e0;
  border-radius:10px;
  padding:10px 12px;
  font-size:13px;
  outline:none;
  background:#fff;
  color:#1a1a2e;
}
.pr-contact-actions{
  display:flex;
  flex-wrap:wrap;
  gap:8px;
  align-items:center;
  padding:0 16px 16px;
}
.pr-status-strip{
  display:flex;
  flex-wrap:wrap;
  gap:8px;
  padding:0 16px 16px;
  color:#7a6a5a;
  font-size:12.5px;
}
.pr-contact-note{
  margin:0 16px 16px;
  padding:10px 12px;
  border:1px solid #dbeafe;
  background:#eff6ff;
  color:#1e40af;
  border-radius:10px;
  font-size:12.5px;
}
.pr-alert{
  display:flex; align-items:flex-start; gap:10px;
  background:#fff7ed;
  border: 1px solid #fed7aa;
  border-radius: 10px;
  padding: 11px 12px;
  font-size: 13px;
  color:#9a3412;
  margin-bottom: 12px;
}

.pr-kbd{
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
}

/* Spin */
@keyframes prSpin{ to { transform: rotate(360deg); } }
      `}),(0,s.jsx)(te,{sidebarOpen:n,setSidebarOpen:ae}),(0,s.jsx)(r,{title:`Parents`}),(0,s.jsx)(`div`,{className:`container-fluid`,children:(0,s.jsxs)(`div`,{className:`row`,children:[(0,s.jsx)(ee,{sidebarOpen:n}),(0,s.jsxs)(`main`,{className:`pr-main`,children:[mt&&(0,s.jsx)(i,{message:F?`Creating parent...`:j?`Saving parent...`:R?`Assigning students...`:`Loading parents...`}),(0,s.jsxs)(`div`,{className:`pr-hero`,children:[(0,s.jsx)(`div`,{className:`pr-hero-glow`,"aria-hidden":`true`}),(0,s.jsx)(`div`,{className:`pr-hero-glow2`,"aria-hidden":`true`}),(0,s.jsxs)(`div`,{className:`pr-hero-inner`,children:[(0,s.jsxs)(`div`,{children:[(0,s.jsxs)(`div`,{className:`pr-session-badge`,children:[(0,s.jsx)(`span`,{className:`pr-session-dot`}),`Parents Registry`]}),(0,s.jsxs)(`h1`,{className:`pr-greeting`,children:[He(),`, `,(0,s.jsx)(`em`,{children:`Admin.`})]}),(0,s.jsx)(`p`,{className:`pr-hero-sub`,children:`Search parents, open profiles, edit details, manage default passwords, and assign children by selecting class(es).`}),(0,s.jsxs)(`div`,{className:`pr-hero-btns`,children:[(0,s.jsxs)(`button`,{className:`pr-btn-gold`,onClick:Je,disabled:mt,children:[f.plus,` Add Parent`]}),(0,s.jsxs)(`button`,{className:`pr-btn-outline`,onClick:Z,disabled:y,children:[(0,s.jsx)(`span`,{style:{display:`inline-flex`,alignItems:`center`,...y?{animation:`prSpin .8s linear infinite`}:{}},children:f.refresh}),`Refresh`]})]})]}),(0,s.jsxs)(`div`,{className:`pr-hero-stat-card d-none d-md-block`,children:[(0,s.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,marginBottom:14},children:[(0,s.jsx)(`span`,{style:{fontSize:11,fontWeight:500,letterSpacing:`0.14em`,textTransform:`uppercase`,color:`#c9a84c`},children:`Quick glance`}),(0,s.jsx)(`svg`,{width:`13`,height:`13`,viewBox:`0 0 14 14`,fill:`none`,children:(0,s.jsx)(`path`,{d:`M2 10V6M5 10V4M8 10V7M11 10V3`,stroke:`#64748b`,strokeWidth:`1.5`,strokeLinecap:`round`})})]}),(0,s.jsxs)(`div`,{className:`pr-hero-stat-row`,children:[(0,s.jsxs)(`div`,{className:`pr-hero-stat-item`,children:[(0,s.jsx)(`span`,{className:`pr-hero-stat-label`,children:`On this page`}),(0,s.jsx)(`span`,{className:`pr-hero-stat-val`,children:st})]}),(0,s.jsx)(`div`,{className:`pr-hero-stat-sep`}),(0,s.jsxs)(`div`,{className:`pr-hero-stat-item`,children:[(0,s.jsx)(`span`,{className:`pr-hero-stat-label`,children:`With email`}),(0,s.jsx)(`span`,{className:`pr-hero-stat-val`,children:ct})]}),(0,s.jsx)(`div`,{className:`pr-hero-stat-sep`}),(0,s.jsxs)(`div`,{className:`pr-hero-stat-item`,children:[(0,s.jsx)(`span`,{className:`pr-hero-stat-label`,children:`With phone`}),(0,s.jsx)(`span`,{className:`pr-hero-stat-val`,children:lt})]})]})]})]})]}),(0,s.jsx)(`div`,{className:`pr-stats`,children:[{title:`Parents (Page)`,value:st,color:`#b45309`,bg:`#fef3c7`,icon:f.people,label:`loaded in view`},{title:`With Email`,value:ct,color:`#1e40af`,bg:`#dbeafe`,icon:f.mail,label:`contactable`},{title:`With Phone`,value:lt,color:`#065f46`,bg:`#d1fae5`,icon:f.phone,label:`reachable`},{title:`Children (Open Profile)`,value:ft,color:`#7c3aed`,bg:`#ede9fe`,icon:f.child,label:`in selected profile`}].map(e=>(0,s.jsxs)(`div`,{className:`pr-stat`,style:{"--sc":e.color,"--si":e.bg},children:[(0,s.jsxs)(`div`,{className:`pr-stat-head`,children:[(0,s.jsx)(`div`,{className:`pr-stat-icon`,children:e.icon}),(0,s.jsxs)(`svg`,{width:`16`,height:`16`,viewBox:`0 0 16 16`,fill:`none`,style:{color:`#c8bfb5`},children:[(0,s.jsx)(`circle`,{cx:`4`,cy:`8`,r:`1.2`,fill:`currentColor`}),(0,s.jsx)(`circle`,{cx:`8`,cy:`8`,r:`1.2`,fill:`currentColor`}),(0,s.jsx)(`circle`,{cx:`12`,cy:`8`,r:`1.2`,fill:`currentColor`})]})]}),(0,s.jsx)(`p`,{className:`pr-stat-label`,children:e.title}),(0,s.jsx)(`div`,{className:`pr-stat-val`,children:e.value}),(0,s.jsxs)(`div`,{className:`pr-stat-footer`,children:[(0,s.jsx)(`svg`,{width:`12`,height:`12`,viewBox:`0 0 12 12`,fill:`none`,children:(0,s.jsx)(`path`,{d:`M2 9l3-4 2 2 3-5`,stroke:`#22c55e`,strokeWidth:`1.4`,strokeLinecap:`round`,strokeLinejoin:`round`})}),(0,s.jsx)(`span`,{className:`pr-stat-trend`,children:`+`}),(0,s.jsx)(`span`,{children:e.label})]})]},e.title))}),(0,s.jsx)(`div`,{className:`pr-actions`,children:[{label:`Add Parent`,desc:`Create a parent account`,color:`#b45309`,bg:`#fef3c7`,onClick:Je,icon:f.plus},{label:`Refresh List`,desc:`Reload parents data`,color:`#1e40af`,bg:`#dbeafe`,onClick:Z,icon:f.refresh},{label:`Clear Search`,desc:`Reset filters`,color:`#065f46`,bg:`#d1fae5`,onClick:()=>{ue(``),_(1)},icon:f.search},{label:`Help Tip`,desc:`Assign children from profile`,color:`#7c3aed`,bg:`#ede9fe`,onClick:()=>e(`Tip: Open a parent -> Assign Child -> select class(es), load students, then assign.`),icon:f.shield}].map(e=>(0,s.jsxs)(`a`,{href:`#`,className:`pr-action`,style:{"--ac-color":e.color,"--ac-bg":e.bg,"--ac-border":e.bg},onClick:t=>{t.preventDefault(),e.onClick()},children:[(0,s.jsx)(`div`,{className:`pr-action-icon`,children:e.icon}),(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`div`,{className:`pr-action-label`,children:e.label}),(0,s.jsx)(`div`,{className:`pr-action-desc`,children:e.desc})]})]},e.label))}),(0,s.jsxs)(`div`,{className:`pr-panel`,style:{marginBottom:18},children:[(0,s.jsxs)(`div`,{className:`pr-panel-head`,children:[(0,s.jsxs)(`div`,{className:`pr-panel-title-group`,children:[(0,s.jsx)(`div`,{className:`pr-panel-icon`,style:{"--pi":`#dbeafe`,"--pc":`#1e40af`},children:f.phone}),(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`p`,{className:`pr-panel-title`,children:`Parent Contact Validation`}),(0,s.jsx)(`p`,{className:`pr-panel-sub`,children:`Confirm regular phone numbers and WhatsApp numbers separately`})]})]}),(0,s.jsxs)(`div`,{style:{display:`flex`,gap:8,flexWrap:`wrap`},children:[(0,s.jsxs)(`span`,{className:`pr-pill pr-pill--green`,children:[`Phone: `,ut,`/`,m.length]}),(0,s.jsxs)(`span`,{className:`pr-pill pr-pill--blue`,children:[`WhatsApp: `,dt,`/`,m.length]})]})]}),(0,s.jsxs)(`div`,{className:`pr-validation-grid`,children:[(0,s.jsxs)(`div`,{className:`pr-field`,children:[(0,s.jsx)(`label`,{children:`Parent`}),(0,s.jsxs)(`select`,{value:Fe,onChange:e=>Ie(e.target.value?Number(e.target.value):``),children:[(0,s.jsx)(`option`,{value:``,children:`Select parent`}),p.map(e=>(0,s.jsxs)(`option`,{value:e.id,children:[c(e),` - `,e.phone||e.email||`ID ${e.id}`]},e.id))]})]}),(0,s.jsxs)(`div`,{className:`pr-field`,children:[(0,s.jsx)(`label`,{children:`Phone / WhatsApp Number`}),(0,s.jsx)(`input`,{value:G,onChange:e=>Le(e.target.value),placeholder:`08030000000 or +2348030000000`})]}),(0,s.jsxs)(`div`,{className:`pr-field`,children:[(0,s.jsx)(`label`,{children:`WhatsApp Code`}),(0,s.jsx)(`input`,{value:K,onChange:e=>q(e.target.value),placeholder:`6-digit code`})]})]}),(0,s.jsxs)(`div`,{className:`pr-contact-actions`,children:[(0,s.jsx)(`button`,{className:`pr-refresh`,onClick:ze,disabled:!X||J!==null,children:J===`phone`?`Checking...`:`Validate Phone`}),(0,s.jsx)(`button`,{className:`pr-refresh`,onClick:Be,disabled:!X||J!==null,children:J===`send`?`Sending...`:`Send WhatsApp Code`}),(0,s.jsx)(`button`,{className:`pr-btn-gold`,onClick:Ve,disabled:!X||J!==null||!K.trim(),children:J===`verify`?`Verifying...`:`Verify WhatsApp`})]}),(0,s.jsxs)(`div`,{className:`pr-status-strip`,children:[(0,s.jsxs)(`span`,{className:`pr-pill ${u(X?.phone_validated_at)?`pr-pill--green`:`pr-pill--gray`}`,children:[`Phone `,u(X?.phone_validated_at)?`validated`:`not validated`]}),(0,s.jsxs)(`span`,{className:`pr-pill ${u(X?.whatsapp_verified_at)?`pr-pill--green`:`pr-pill--gray`}`,children:[`WhatsApp `,u(X?.whatsapp_verified_at)?`verified`:`not verified`]}),X?.phone_normalized&&(0,s.jsxs)(`span`,{children:[`Normalized: `,(0,s.jsx)(`b`,{children:X.phone_normalized})]})]}),(0,s.jsx)(`p`,{className:`pr-contact-note`,children:`During Twilio sandbox testing, the parent number must join your WhatsApp sandbox before messages can be delivered.`})]}),(0,s.jsxs)(`div`,{className:`pr-grid`,children:[(0,s.jsxs)(`div`,{className:`pr-panel`,children:[(0,s.jsxs)(`div`,{className:`pr-panel-head`,children:[(0,s.jsxs)(`div`,{className:`pr-panel-title-group`,children:[(0,s.jsx)(`div`,{className:`pr-panel-icon`,style:{"--pi":`#fef3c7`,"--pc":`#b45309`},children:f.people}),(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`p`,{className:`pr-panel-title`,children:`Parent Directory`}),(0,s.jsx)(`p`,{className:`pr-panel-sub`,children:`Search by name, email or phone - Click "View" to open profile`})]})]}),(0,s.jsxs)(`div`,{className:`pr-toolbar`,style:{padding:0},children:[(0,s.jsxs)(`div`,{className:`pr-input`,children:[(0,s.jsx)(`span`,{style:{color:`#9a8a7a`},children:f.search}),(0,s.jsx)(`input`,{placeholder:`Search (e.g. Grace, parent@email.com)`,value:h,onChange:e=>{ue(e.target.value),_(1)}}),!!h.trim()&&(0,s.jsx)(`button`,{className:`pr-clear`,type:`button`,title:`Clear`,onClick:()=>{ue(``),_(1)},children:`x`})]}),(0,s.jsxs)(`button`,{className:`pr-refresh`,onClick:Z,disabled:y,children:[(0,s.jsx)(`span`,{style:{display:`inline-flex`,alignItems:`center`,...y?{animation:`prSpin .8s linear infinite`}:{}},children:f.refresh}),`Refresh`]}),(0,s.jsx)(`button`,{className:`pr-refresh`,onClick:()=>me(e=>!e),disabled:y,children:pe?`Close Import`:`Import`}),(0,s.jsxs)(`button`,{className:`pr-btn-gold`,onClick:Je,disabled:mt,children:[f.plus,` Add Parent`]})]})]}),pe&&(0,s.jsx)(ie,{kind:`parents`,onImported:Z}),(0,s.jsx)(`div`,{style:{overflowX:`auto`},children:(0,s.jsxs)(`table`,{className:`pr-table`,children:[(0,s.jsx)(`thead`,{children:(0,s.jsxs)(`tr`,{children:[(0,s.jsx)(`th`,{style:{width:460},children:`Parent`}),(0,s.jsx)(`th`,{style:{width:300},children:`Email`}),(0,s.jsx)(`th`,{style:{width:220},children:`Phone`}),(0,s.jsx)(`th`,{style:{width:220},children:`Validation`}),(0,s.jsx)(`th`,{style:{width:260,textAlign:`right`},children:`Action`})]})}),(0,s.jsx)(`tbody`,{children:y?(0,s.jsx)(`tr`,{children:(0,s.jsx)(`td`,{colSpan:5,style:{padding:`44px 16px`,textAlign:`center`,color:`#9a8a7a`},children:`Loading parents...`})}):m.length===0?(0,s.jsx)(`tr`,{children:(0,s.jsx)(`td`,{colSpan:5,style:{padding:`44px 16px`,textAlign:`center`,color:`#9a8a7a`},children:`No parents found. Try a different search or add a new parent.`})}):m.map(e=>(0,s.jsxs)(`tr`,{children:[(0,s.jsx)(`td`,{children:(0,s.jsxs)(`div`,{className:`pr-row-title`,children:[(0,s.jsx)(`div`,{className:`pr-avatar`,children:oe(e)}),(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`div`,{className:`pr-name`,children:c(e)}),(0,s.jsxs)(`div`,{className:`pr-subtle`,children:[`ID: `,e.id]})]})]})}),(0,s.jsx)(`td`,{style:{color:`#9a8a7a`},children:e.email||`-`}),(0,s.jsx)(`td`,{style:{color:`#9a8a7a`},children:e.phone||`-`}),(0,s.jsx)(`td`,{children:(0,s.jsxs)(`div`,{style:{display:`flex`,flexWrap:`wrap`,gap:6},children:[(0,s.jsx)(`span`,{className:`pr-pill ${u(e.phone_validated_at)?`pr-pill--green`:`pr-pill--gray`}`,children:`Phone`}),(0,s.jsx)(`span`,{className:`pr-pill ${u(e.whatsapp_verified_at)?`pr-pill--green`:`pr-pill--gray`}`,children:`WhatsApp`})]})}),(0,s.jsx)(`td`,{style:{textAlign:`right`},children:(0,s.jsxs)(`div`,{style:{display:`inline-flex`,gap:8,flexWrap:`wrap`,justifyContent:`flex-end`},children:[(0,s.jsx)(`button`,{className:`pr-icon-btn pr-icon-btn--view`,onClick:()=>Q(e),title:`View Profile: ${c(e)}`,"aria-label":`View Parent Profile`,children:f.eye}),(0,s.jsx)(`button`,{className:`pr-icon-btn pr-icon-btn--validate`,onClick:()=>{Ie(e.id),window.scrollTo({top:520,behavior:`smooth`})},title:`Validate Contact: ${c(e)}`,"aria-label":`Validate Contact`,children:f.phone}),(0,s.jsx)(`button`,{className:`pr-icon-btn pr-icon-btn--danger`,onClick:()=>qe(e),title:`Delete Parent: ${c(e)}`,"aria-label":`Delete Parent`,children:f.trash})]})})]},e.id))})]})}),(0,s.jsxs)(`div`,{className:`pr-pagination`,children:[(0,s.jsxs)(`span`,{className:`pr-page-info`,children:[`Page `,(0,s.jsx)(`b`,{children:g}),` of `,(0,s.jsx)(`b`,{children:de})]}),(0,s.jsxs)(`div`,{className:`pr-page-btns`,children:[(0,s.jsxs)(`button`,{className:`pr-page-btn`,disabled:g===1,onClick:()=>_(e=>e-1),children:[(0,s.jsx)(`svg`,{width:`12`,height:`12`,viewBox:`0 0 12 12`,fill:`none`,children:(0,s.jsx)(`path`,{d:`M8 2L4 6l4 4`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`,strokeLinejoin:`round`})}),`Previous`]}),(0,s.jsxs)(`span`,{className:`pr-page-current`,children:[m.length,` shown - `,p.length,` total`]}),(0,s.jsxs)(`button`,{className:`pr-page-btn`,disabled:g===de,onClick:()=>_(e=>e+1),children:[`Next`,(0,s.jsx)(`svg`,{width:`12`,height:`12`,viewBox:`0 0 12 12`,fill:`none`,children:(0,s.jsx)(`path`,{d:`M4 2l4 4-4 4`,stroke:`currentColor`,strokeWidth:`1.5`,strokeLinecap:`round`,strokeLinejoin:`round`})})]})]})]})]}),(0,s.jsxs)(`div`,{className:`pr-panel`,style:{display:`flex`,flexDirection:`column`},children:[(0,s.jsx)(`div`,{className:`pr-panel-head`,children:(0,s.jsxs)(`div`,{className:`pr-panel-title-group`,children:[(0,s.jsx)(`div`,{className:`pr-panel-icon`,style:{"--pi":`#d1fae5`,"--pc":`#065f46`},children:f.shield}),(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`p`,{className:`pr-panel-title`,children:`Operational Notes`}),(0,s.jsx)(`p`,{className:`pr-panel-sub`,children:`How assignment & security behave`})]})]})}),(0,s.jsxs)(`div`,{style:{padding:16,display:`flex`,flexDirection:`column`,gap:12},children:[(0,s.jsxs)(`div`,{className:`pr-alert`,style:{marginBottom:0},children:[(0,s.jsx)(`span`,{style:{flexShrink:0},children:f.shield}),(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`div`,{style:{fontWeight:700,marginBottom:2},children:`One student to one parent`}),`Students already assigned to another parent are locked in the assign modal, and an error toast shows the parent name.`]})]}),(0,s.jsx)(`div`,{className:`pr-card`,children:(0,s.jsxs)(`div`,{className:`pr-card-pad`,children:[(0,s.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,marginBottom:10},children:[(0,s.jsx)(`div`,{style:{fontWeight:800,color:`#1a1a2e`},children:`Quick Tips`}),(0,s.jsx)(`span`,{className:`pr-pill pr-pill--gold`,children:`Workflow`})]}),(0,s.jsxs)(`ol`,{style:{margin:0,paddingLeft:18,color:`#7a6a5a`,fontSize:13.5,lineHeight:1.7},children:[(0,s.jsxs)(`li`,{children:[`Click `,(0,s.jsx)(`b`,{children:`View`}),` on a parent.`]}),(0,s.jsxs)(`li`,{children:[`Use `,(0,s.jsx)(`b`,{children:`Assign Child`}),` in the profile header.`]}),(0,s.jsxs)(`li`,{children:[`Select class(es), click `,(0,s.jsx)(`b`,{children:`Load Students`}),`, then `,(0,s.jsx)(`b`,{children:`Assign Selected`}),`.`]})]})]})}),(0,s.jsx)(`div`,{className:`pr-card`,children:(0,s.jsxs)(`div`,{className:`pr-card-pad`,children:[(0,s.jsx)(`div`,{style:{fontWeight:800,color:`#1a1a2e`,marginBottom:8},children:`Security`}),(0,s.jsxs)(`div`,{style:{color:`#7a6a5a`,fontSize:13.5,lineHeight:1.7},children:[`Default passwords are shown in the `,(0,s.jsx)(`b`,{children:`Security`}),` tab, with `,(0,s.jsx)(`b`,{children:`show/hide`}),` and `,(0,s.jsx)(`b`,{children:`copy`}),` controls. Consider rotating passwords after first login.`]})]})}),(0,s.jsx)(`div`,{style:{marginTop:`auto`},children:(0,s.jsx)(re,{})})]})]})]})]})]})}),ve&&(0,s.jsx)(`div`,{className:`pr-overlay`,onMouseDown:Ye,children:(0,s.jsxs)(`div`,{className:`pr-modal pr-modal--md`,onMouseDown:e=>e.stopPropagation(),children:[(0,s.jsx)(`div`,{className:`pr-modal-head`,children:(0,s.jsxs)(`div`,{className:`pr-modal-head-inner`,children:[(0,s.jsxs)(`div`,{className:`pr-modal-title`,children:[(0,s.jsx)(`div`,{style:{width:52,height:52,borderRadius:14,background:`rgba(255,255,255,0.06)`,border:`1px solid rgba(255,255,255,0.10)`,display:`flex`,alignItems:`center`,justifyContent:`center`,color:`#e8c97a`},children:f.plus}),(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`h5`,{children:`Add Parent`}),(0,s.jsx)(`p`,{children:`Create a parent account - password is auto-generated.`})]})]}),(0,s.jsx)(`button`,{className:`pr-btn-outline`,onClick:Ye,disabled:F,children:`Close`})]})}),(0,s.jsx)(`div`,{className:`pr-modal-body`,children:(0,s.jsx)(`div`,{className:`pr-card`,children:(0,s.jsxs)(`div`,{className:`pr-card-pad`,children:[(0,s.jsxs)(`div`,{className:`pr-form-grid`,children:[(0,s.jsxs)(`div`,{className:`pr-field`,children:[(0,s.jsx)(`label`,{children:`First Name *`}),(0,s.jsx)(`input`,{value:I.firstname,onChange:e=>L({...I,firstname:e.target.value})})]}),(0,s.jsxs)(`div`,{className:`pr-field`,children:[(0,s.jsx)(`label`,{children:`Surname *`}),(0,s.jsx)(`input`,{value:I.surname,onChange:e=>L({...I,surname:e.target.value})})]}),(0,s.jsxs)(`div`,{className:`pr-field`,children:[(0,s.jsx)(`label`,{children:`Email *`}),(0,s.jsx)(`input`,{type:`email`,value:I.email,onChange:e=>L({...I,email:e.target.value})})]}),(0,s.jsxs)(`div`,{className:`pr-field`,children:[(0,s.jsx)(`label`,{children:`Phone *`}),(0,s.jsx)(`input`,{value:I.phone,onChange:e=>L({...I,phone:e.target.value})})]}),(0,s.jsxs)(`div`,{className:`pr-field`,style:{gridColumn:`1 / -1`},children:[(0,s.jsx)(`label`,{children:`Address (optional)`}),(0,s.jsx)(`input`,{value:I.address,onChange:e=>L({...I,address:e.target.value})})]})]}),be?(0,s.jsx)(`div`,{style:{marginTop:14},children:(0,s.jsxs)(`div`,{className:`pr-alert`,style:{background:`#d1fae5`,borderColor:`rgba(6,95,70,0.18)`,color:`#065f46`,marginBottom:0},children:[(0,s.jsx)(`span`,{style:{flexShrink:0},children:f.key}),(0,s.jsxs)(`div`,{style:{width:`100%`},children:[(0,s.jsx)(`div`,{style:{fontWeight:800,marginBottom:4},children:`Generated Password`}),(0,s.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,justifyContent:`space-between`,gap:10,flexWrap:`wrap`},children:[(0,s.jsx)(`span`,{className:`pr-kbd`,children:be}),(0,s.jsx)(`button`,{className:`pr-mini-btn`,onClick:()=>pt(be),children:`Copy`})]})]})]})}):null]})})}),(0,s.jsxs)(`div`,{className:`pr-modal-foot`,children:[(0,s.jsx)(`small`,{style:{color:`#9a8a7a`},children:`Tip: After creation, open profile, then Security tab to view default password.`}),(0,s.jsxs)(`div`,{style:{display:`inline-flex`,gap:8,flexWrap:`wrap`},children:[(0,s.jsx)(`button`,{className:`pr-mini-btn`,onClick:Ye,disabled:F,children:`Cancel`}),(0,s.jsx)(`button`,{className:`pr-btn-gold`,onClick:Xe,disabled:F,children:F?(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)(`span`,{className:`spinner-border spinner-border-sm me-2`}),`Creating...`]}):(0,s.jsxs)(s.Fragment,{children:[f.plus,` Create Parent`]})})]})]})]})}),x&&(0,s.jsx)(`div`,{className:`pr-overlay`,style:{zIndex:1500},onMouseDown:$,children:(0,s.jsxs)(`div`,{className:`pr-modal`,onMouseDown:e=>e.stopPropagation(),children:[(0,s.jsxs)(`div`,{className:`pr-modal-head`,children:[(0,s.jsxs)(`div`,{className:`pr-modal-head-inner`,children:[(0,s.jsxs)(`div`,{className:`pr-modal-title`,children:[(0,s.jsx)(`div`,{style:{width:52,height:52,borderRadius:999,background:`rgba(255,255,255,0.06)`,border:`1px solid rgba(255,255,255,0.10)`,display:`flex`,alignItems:`center`,justifyContent:`center`,color:`#e8c97a`,fontWeight:900},children:oe(C?.parent||x)}),(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`h5`,{children:C?.parent?c(C.parent):c(x)}),(0,s.jsxs)(`p`,{children:[C?.parent?.email??x.email??`-`,` - `,C?.parent?.phone??x.phone??`-`]})]})]}),(0,s.jsxs)(`div`,{style:{display:`inline-flex`,gap:8,flexWrap:`wrap`,alignItems:`center`},children:[!T&&(0,s.jsx)(s.Fragment,{children:ge?(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)(`button`,{className:`pr-btn-gold`,onClick:Ke,disabled:j,children:j?`Saving...`:`Save`}),(0,s.jsx)(`button`,{className:`pr-btn-outline`,onClick:Ge,disabled:j,children:`Cancel`})]}):(0,s.jsxs)(s.Fragment,{children:[(0,s.jsxs)(`button`,{className:`pr-btn-gold`,onClick:Qe,children:[f.plus,` Assign Child`]}),(0,s.jsx)(`button`,{className:`pr-btn-outline`,onClick:We,children:`Edit`})]})}),(0,s.jsx)(`button`,{className:`pr-btn-outline`,onClick:$,children:`Close`})]})]}),(0,s.jsxs)(`div`,{className:`pr-tabs`,children:[(0,s.jsx)(`button`,{className:`pr-tab ${D===`overview`?`pr-tab--active`:``}`,onClick:()=>O(`overview`),disabled:T,children:`Overview`}),(0,s.jsx)(`button`,{className:`pr-tab ${D===`children`?`pr-tab--active`:``}`,onClick:()=>O(`children`),disabled:T,children:`Children`}),(0,s.jsx)(`button`,{className:`pr-tab ${D===`security`?`pr-tab--active`:``}`,onClick:()=>O(`security`),disabled:T,children:`Security`})]})]}),(0,s.jsx)(`div`,{className:`pr-modal-body`,children:T?(0,s.jsx)(`div`,{style:{padding:30,textAlign:`center`,color:`#9a8a7a`},children:`Loading parent details...`}):C?.parent?(0,s.jsxs)(s.Fragment,{children:[D===`overview`&&(0,s.jsx)(`div`,{className:`pr-card`,children:(0,s.jsx)(`div`,{className:`pr-card-pad`,children:ge?(0,s.jsxs)(`div`,{className:`pr-form-grid`,children:[(0,s.jsxs)(`div`,{className:`pr-field`,children:[(0,s.jsx)(`label`,{children:`First Name *`}),(0,s.jsx)(`input`,{value:M.firstname,onChange:e=>N({...M,firstname:e.target.value})})]}),(0,s.jsxs)(`div`,{className:`pr-field`,children:[(0,s.jsx)(`label`,{children:`Surname *`}),(0,s.jsx)(`input`,{value:M.surname,onChange:e=>N({...M,surname:e.target.value})})]}),(0,s.jsxs)(`div`,{className:`pr-field`,children:[(0,s.jsx)(`label`,{children:`Email *`}),(0,s.jsx)(`input`,{type:`email`,value:M.email,onChange:e=>N({...M,email:e.target.value})})]}),(0,s.jsxs)(`div`,{className:`pr-field`,children:[(0,s.jsx)(`label`,{children:`Phone *`}),(0,s.jsx)(`input`,{value:M.phone,onChange:e=>N({...M,phone:e.target.value})})]}),(0,s.jsxs)(`div`,{className:`pr-field`,style:{gridColumn:`1 / -1`},children:[(0,s.jsx)(`label`,{children:`Address`}),(0,s.jsx)(`input`,{value:M.address,onChange:e=>N({...M,address:e.target.value})})]}),(0,s.jsxs)(`div`,{className:`pr-field`,style:{gridColumn:`1 / -1`},children:[(0,s.jsx)(`label`,{children:`New Password (optional)`}),(0,s.jsx)(`input`,{className:`pr-kbd`,value:M.password,onChange:e=>N({...M,password:e.target.value}),placeholder:`Leave empty to keep current`})]})]}):(0,s.jsxs)(`div`,{className:`pr-info-grid`,children:[(0,s.jsx)(d,{label:`Full Name`,value:c(C.parent),icon:f.people}),(0,s.jsx)(d,{label:`Email`,value:C.parent.email||null,icon:f.mail}),(0,s.jsx)(d,{label:`Phone`,value:C.parent.phone||null,icon:f.phone}),(0,s.jsx)(d,{label:`Address`,value:C.parent.address||null,icon:(0,s.jsx)(`span`,{children:`Address`})}),(0,s.jsx)(se,{label:`Children Linked`,value:String(C.children?.length??0),tone:`blue`,icon:f.child}),(0,s.jsx)(se,{label:`Account Role`,value:`Parent`,tone:`gray`,icon:(0,s.jsx)(`span`,{children:`Parent`})})]})})}),D===`children`&&(0,s.jsx)(`div`,{className:`pr-card`,children:(0,s.jsxs)(`div`,{className:`pr-card-pad`,style:{padding:0},children:[(0,s.jsxs)(`div`,{className:`pr-panel-head`,style:{border:`none`,borderBottom:`1px solid rgba(0,0,0,0.06)`},children:[(0,s.jsxs)(`div`,{className:`pr-panel-title-group`,children:[(0,s.jsx)(`div`,{className:`pr-panel-icon`,style:{"--pi":`#ede9fe`,"--pc":`#7c3aed`},children:f.child}),(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`p`,{className:`pr-panel-title`,children:`Linked Children`}),(0,s.jsx)(`p`,{className:`pr-panel-sub`,children:`Remove or assign students`})]})]}),(0,s.jsxs)(`div`,{style:{display:`inline-flex`,gap:8,flexWrap:`wrap`},children:[(0,s.jsxs)(`button`,{className:`pr-mini-btn`,onClick:Qe,children:[f.plus,` Assign`]}),(0,s.jsxs)(`button`,{className:`pr-mini-btn pr-mini-btn--danger`,onClick:()=>qe(C.parent),children:[f.trash,` Delete Parent`]})]})]}),(0,s.jsx)(`div`,{style:{overflowX:`auto`},children:(0,s.jsxs)(`table`,{className:`pr-table`,children:[(0,s.jsx)(`thead`,{children:(0,s.jsxs)(`tr`,{children:[(0,s.jsx)(`th`,{style:{width:70},children:`#`}),(0,s.jsx)(`th`,{children:`Student`}),(0,s.jsx)(`th`,{style:{width:220},children:`Reg No`}),(0,s.jsx)(`th`,{style:{width:240},children:`Class`}),(0,s.jsx)(`th`,{style:{width:180,textAlign:`right`},children:`Action`})]})}),(0,s.jsx)(`tbody`,{children:(C.children??[]).length===0?(0,s.jsx)(`tr`,{children:(0,s.jsx)(`td`,{colSpan:5,style:{padding:`44px 16px`,textAlign:`center`,color:`#9a8a7a`},children:`No students linked. Click "Assign" to add children to this parent.`})}):C.children.map((e,t)=>(0,s.jsxs)(`tr`,{children:[(0,s.jsx)(`td`,{style:{color:`#9a8a7a`},children:t+1}),(0,s.jsxs)(`td`,{children:[(0,s.jsx)(`div`,{className:`pr-name`,children:c(e)}),(0,s.jsxs)(`div`,{className:`pr-subtle`,children:[`ID: `,e.id]})]}),(0,s.jsx)(`td`,{children:(0,s.jsx)(`span`,{className:`pr-pill pr-pill--blue`,children:e.reg_no||`-`})}),(0,s.jsx)(`td`,{children:(0,s.jsx)(`span`,{className:`pr-pill pr-pill--gold`,children:e.level?.name||`-`})}),(0,s.jsx)(`td`,{style:{textAlign:`right`},children:(0,s.jsx)(`button`,{className:`pr-mini-btn pr-mini-btn--danger`,onClick:()=>ot(e.id),children:`Remove`})})]},e.id))})]})})]})}),D===`security`&&(0,s.jsx)(`div`,{className:`pr-card`,children:(0,s.jsxs)(`div`,{className:`pr-card-pad`,children:[(0,s.jsxs)(`div`,{className:`pr-info-grid`,children:[(0,s.jsx)(d,{label:`Email`,value:C.parent?.email||`-`,icon:f.mail}),(0,s.jsx)(d,{label:`Phone`,value:C.parent?.phone||`-`,icon:f.phone}),(0,s.jsxs)(`div`,{className:`pr-info`,style:{gridColumn:`1 / -1`},children:[(0,s.jsxs)(`div`,{className:`pr-info-label`,children:[(0,s.jsx)(`span`,{className:`pr-info-ico`,children:f.key}),`Default Password`]}),(0,s.jsxs)(`div`,{style:{display:`flex`,gap:10,flexWrap:`wrap`,alignItems:`center`},children:[(0,s.jsx)(`input`,{type:k?`text`:`password`,value:k?C.parent?.default_password||`N/A`:C.parent?.default_password?`**********`:`N/A`,readOnly:!0,className:`pr-kbd`,style:{flex:`1 1 320px`,border:`1px solid #ede8e0`,borderRadius:10,padding:`10px 12px`,fontSize:13}}),(0,s.jsx)(`button`,{className:`pr-mini-btn`,onClick:()=>he(e=>!e),disabled:!C.parent?.default_password||C.parent?.default_password===`N/A`,title:k?`Hide`:`Show`,children:k?`Hide`:`Show`}),(0,s.jsx)(`button`,{className:`pr-mini-btn`,onClick:()=>{let e=C.parent?.default_password||``;if(!e||e===`N/A`)return t(`No password to copy`);pt(e)},disabled:!C.parent?.default_password||C.parent?.default_password===`N/A`,title:`Copy`,children:`Copy`})]})]})]}),(0,s.jsx)(`div`,{style:{marginTop:12,color:`#9a8a7a`,fontSize:12.5},children:`Tip: Encourage parents to change their password after first login.`})]})})]}):(0,s.jsxs)(`div`,{className:`pr-alert`,children:[(0,s.jsx)(`span`,{style:{flexShrink:0},children:`!`}),`No parent details available.`]})}),(0,s.jsxs)(`div`,{className:`pr-modal-foot`,children:[(0,s.jsx)(`small`,{style:{color:`#9a8a7a`},children:`Tip: Assign children by selecting classes in the Assign modal.`}),(0,s.jsx)(`button`,{className:`pr-mini-btn`,onClick:$,children:`Close`})]})]})}),Se&&x&&(0,s.jsx)(`div`,{className:`pr-overlay`,style:{zIndex:1600},onMouseDown:$e,children:(0,s.jsxs)(`div`,{className:`pr-modal`,onMouseDown:e=>e.stopPropagation(),children:[(0,s.jsx)(`div`,{className:`pr-modal-head`,children:(0,s.jsxs)(`div`,{className:`pr-modal-head-inner`,children:[(0,s.jsxs)(`div`,{className:`pr-modal-title`,children:[(0,s.jsx)(`div`,{style:{width:52,height:52,borderRadius:14,background:`rgba(255,255,255,0.06)`,border:`1px solid rgba(255,255,255,0.10)`,display:`flex`,alignItems:`center`,justifyContent:`center`,color:`#e8c97a`},children:f.child}),(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`h5`,{children:`Assign Children`}),(0,s.jsxs)(`p`,{children:[`Parent: `,(0,s.jsx)(`b`,{style:{color:`#e8c97a`},children:c(x)}),` - Select class(es), load students, then assign.`]})]})]}),(0,s.jsx)(`button`,{className:`pr-btn-outline`,onClick:$e,disabled:R||V||Ee,children:`Close`})]})}),(0,s.jsx)(`div`,{className:`pr-modal-body`,children:(0,s.jsxs)(`div`,{className:`pr-grid`,style:{gridTemplateColumns:`380px 1fr`,marginBottom:0},children:[(0,s.jsxs)(`div`,{className:`pr-panel`,children:[(0,s.jsxs)(`div`,{className:`pr-panel-head`,children:[(0,s.jsxs)(`div`,{className:`pr-panel-title-group`,children:[(0,s.jsx)(`div`,{className:`pr-panel-icon`,style:{"--pi":`#dbeafe`,"--pc":`#1e40af`},children:(0,s.jsx)(`span`,{children:`School`})}),(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`p`,{className:`pr-panel-title`,children:`Classes`}),(0,s.jsx)(`p`,{className:`pr-panel-sub`,children:`Loaded from student_classes`})]})]}),(0,s.jsxs)(`span`,{className:`pr-pill pr-pill--blue`,children:[`Selected: `,B.length]})]}),(0,s.jsxs)(`div`,{style:{padding:14},children:[(0,s.jsxs)(`div`,{className:`pr-input`,style:{minWidth:`unset`},children:[(0,s.jsx)(`span`,{style:{color:`#9a8a7a`},children:f.search}),(0,s.jsx)(`input`,{placeholder:`Search class...`,value:Oe,onChange:e=>ke(e.target.value)})]}),(0,s.jsx)(`div`,{style:{marginTop:10,maxHeight:320,overflow:`auto`,background:`#fff`,borderRadius:12,border:`1px solid #ede8e0`,padding:8},children:Ee?(0,s.jsx)(`div`,{style:{padding:14,textAlign:`center`,color:`#9a8a7a`},children:`Loading classes...`}):et.length===0?(0,s.jsx)(`div`,{style:{padding:14,textAlign:`center`,color:`#9a8a7a`},children:`No classes found`}):et.map(e=>{let t=B.includes(e.id);return(0,s.jsxs)(`label`,{style:{display:`flex`,alignItems:`flex-start`,justifyContent:`space-between`,gap:10,padding:10,borderRadius:10,cursor:`pointer`,background:t?`#faf8f5`:`transparent`,border:t?`1px solid rgba(201,168,76,0.25)`:`1px solid transparent`},children:[(0,s.jsxs)(`div`,{style:{display:`flex`,gap:10},children:[(0,s.jsx)(`input`,{type:`checkbox`,checked:t,onChange:()=>tt(e.id),style:{marginTop:3}}),(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`div`,{style:{fontWeight:700,color:`#1a1a2e`},children:e.name}),e.description?(0,s.jsx)(`div`,{style:{color:`#9a8a7a`,fontSize:12.5},children:e.description}):null]})]}),(0,s.jsxs)(`span`,{className:`pr-pill pr-pill--gray`,style:{flexShrink:0},children:[`ID: `,e.id]})]},e.id)})}),(0,s.jsxs)(`div`,{style:{display:`grid`,gap:8,marginTop:12},children:[(0,s.jsx)(`button`,{className:`pr-mini-btn`,style:{justifyContent:`center`,fontWeight:800},onClick:nt,disabled:V||!B.length,children:V?`Loading students...`:`Load Students`}),(0,s.jsx)(`button`,{className:`pr-mini-btn`,style:{justifyContent:`center`},onClick:()=>Ae([]),disabled:!B.length,children:`Clear class selection`})]})]})]}),(0,s.jsxs)(`div`,{className:`pr-panel`,children:[(0,s.jsxs)(`div`,{className:`pr-panel-head`,children:[(0,s.jsxs)(`div`,{className:`pr-panel-title-group`,children:[(0,s.jsx)(`div`,{className:`pr-panel-icon`,style:{"--pi":`#d1fae5`,"--pc":`#065f46`},children:f.child}),(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`p`,{className:`pr-panel-title`,children:`Students`}),(0,s.jsx)(`p`,{className:`pr-panel-sub`,children:`Locked if assigned to another parent`})]})]}),(0,s.jsxs)(`span`,{className:`pr-pill pr-pill--green`,children:[`Selected: `,U.length]})]}),(0,s.jsxs)(`div`,{style:{padding:14},children:[(0,s.jsxs)(`div`,{className:`pr-input`,style:{minWidth:`unset`},children:[(0,s.jsx)(`span`,{style:{color:`#9a8a7a`},children:f.search}),(0,s.jsx)(`input`,{placeholder:`Search students (name, reg no)...`,value:Ne,onChange:e=>Pe(e.target.value)})]}),(0,s.jsx)(`div`,{style:{marginTop:10,maxHeight:380,overflow:`auto`,borderRadius:12,border:`1px solid #ede8e0`,background:`#fff`},children:(0,s.jsxs)(`table`,{className:`pr-table`,children:[(0,s.jsx)(`thead`,{style:{position:`sticky`,top:0,zIndex:1},children:(0,s.jsxs)(`tr`,{children:[(0,s.jsx)(`th`,{style:{width:58}}),(0,s.jsx)(`th`,{children:`Student`}),(0,s.jsx)(`th`,{style:{width:220},children:`Reg No`}),(0,s.jsx)(`th`,{style:{width:240},children:`Class`})]})}),(0,s.jsx)(`tbody`,{children:rt.length===0?(0,s.jsx)(`tr`,{children:(0,s.jsxs)(`td`,{colSpan:5,style:{padding:`44px 16px`,textAlign:`center`,color:`#9a8a7a`},children:[(0,s.jsx)(`div`,{style:{fontWeight:800,color:`#1a1a2e`},children:H.length===0?`No students loaded`:`No matches`}),(0,s.jsx)(`div`,{style:{marginTop:6},children:H.length===0?`Select class(es) and click Load Students.`:`Try a different keyword.`})]})}):rt.map(e=>{let t=!!e.assigned_parent_id&&e.assigned_parent_id!==x.id,n=!!e.assigned_parent_id&&e.assigned_parent_id===x.id,r=U.includes(e.id)||n;return(0,s.jsxs)(`tr`,{style:{cursor:t?`not-allowed`:`pointer`,opacity:t?.6:1},onClick:()=>it(e),children:[(0,s.jsx)(`td`,{children:(0,s.jsx)(`input`,{type:`checkbox`,checked:r,disabled:t,onChange:()=>it(e),onClick:e=>e.stopPropagation()})}),(0,s.jsxs)(`td`,{children:[(0,s.jsx)(`div`,{style:{fontWeight:800,color:`#1a1a2e`},children:c(e)}),(0,s.jsxs)(`div`,{className:`pr-subtle`,children:[`ID: `,e.id]}),t?(0,s.jsx)(`div`,{style:{marginTop:6},children:(0,s.jsxs)(`span`,{className:`pr-pill pr-pill--gray`,style:{background:`#fff7ed`,color:`#9a3412`,borderColor:`rgba(154,52,18,0.16)`},children:[`Assigned to`,` `,`${e.assigned_parent_firstname||``} ${e.assigned_parent_surname||``}`.trim()||`another parent`]})}):n?(0,s.jsx)(`div`,{style:{marginTop:6},children:(0,s.jsx)(`span`,{className:`pr-pill pr-pill--green`,children:`Already assigned to this parent`})}):null]}),(0,s.jsx)(`td`,{children:(0,s.jsx)(`span`,{className:`pr-pill pr-pill--blue`,children:e.reg_no||`-`})}),(0,s.jsx)(`td`,{children:(0,s.jsx)(`span`,{className:`pr-pill pr-pill--gold`,children:e.level?.name||`-`})})]},e.id)})})]})}),(0,s.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,gap:10,flexWrap:`wrap`,marginTop:12},children:[(0,s.jsx)(`button`,{className:`pr-mini-btn`,onClick:()=>W([]),disabled:!U.length,children:`Clear selection`}),(0,s.jsx)(`button`,{className:`pr-btn-gold`,onClick:at,disabled:R||!U.length,children:R?`Assigning...`:`Assign Selected`})]}),(0,s.jsxs)(`div`,{style:{marginTop:12,color:`#9a8a7a`,fontSize:12.5},children:[`Students already assigned to `,(0,s.jsx)(`b`,{children:`this`}),` parent are pre-checked. Students assigned to `,(0,s.jsx)(`b`,{children:`another`}),` parent are locked.`]})]})]})]})}),(0,s.jsxs)(`div`,{className:`pr-modal-foot`,children:[(0,s.jsx)(`small`,{style:{color:`#9a8a7a`},children:`Classes are fetched dynamically from Student Classes.`}),(0,s.jsx)(`button`,{className:`pr-mini-btn`,onClick:$e,children:`Close`})]})]})})]})}export{p as default};