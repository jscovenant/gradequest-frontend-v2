import{Ut as e}from"./vendor-misc-OZLc0tLq.js";import{p as t}from"./vendor-react-BhRGw7qi.js";import"./vendor-pdf-B04jN_ph.js";import"./vendor-http-DXqav090.js";import{C as n,E as r,P as i,d as a,f as o,l as s,u as c}from"./index-D6TxbaCx.js";var l=e(),u=t();function d(e){if(!e)return`-`;let t=new Date(e);return Number.isNaN(t.getTime())?String(e):t.toLocaleString()}function f(){let e=new Date;return`${e.getFullYear()}-${String(e.getMonth()+1).padStart(2,`0`)}-${String(e.getDate()).padStart(2,`0`)}`}function p(){let e=new Date;return`${e.getFullYear()}-${String(e.getMonth()+1).padStart(2,`0`)}-01`}function m(){let e=new Date().getHours();return e<12?`Good morning`:e<17?`Good afternoon`:`Good evening`}function h(){let[e,t]=(0,l.useState)(!1),{showError:h,showSuccess:g,showWarning:_}=s(),[v,y]=(0,l.useState)(!0),[b,x]=(0,l.useState)(p()),[S,C]=(0,l.useState)(f()),[w,T]=(0,l.useState)(``),[E,D]=(0,l.useState)(``),[O,k]=(0,l.useState)(1),[A,j]=(0,l.useState)(20),[M,N]=(0,l.useState)([]),[P,F]=(0,l.useState)({total:0,present:0,late:0,absent:0,on_leave:0}),[I,L]=(0,l.useState)({total:0,last_page:1,current_page:1}),R=e=>{let t=(e||``).toLowerCase();return t===`present`?{bg:`#dcfce7`,fg:`#166534`,label:`PRESENT`}:t===`late`?{bg:`#fef9c3`,fg:`#854d0e`,label:`LATE`}:t===`absent`?{bg:`#fee2e2`,fg:`#991b1b`,label:`ABSENT`}:t===`on_leave`?{bg:`#dbeafe`,fg:`#1d4ed8`,label:`ON LEAVE`}:{bg:`#e2e8f0`,fg:`#0f172a`,label:(e||`UNKNOWN`).toUpperCase()}},z=async(e=O)=>{try{y(!0);let t=(await i.get(`/staff-attendance/logs`,{params:{from:b,to:S,q:w.trim()||void 0,status:E||void 0,page:e,per_page:A}})).data,n=t.data;N(n.data||[]),F(t.summary),L({total:n.total,last_page:n.last_page,current_page:n.current_page})}catch(e){console.error(e),h?.(e?.response?.data?.message||`Failed to load attendance logs`)}finally{y(!1)}};(0,l.useEffect)(()=>{z(1)},[]),(0,l.useEffect)(()=>{k(1),z(1)},[b,S,E,A]);let B=(0,l.useMemo)(()=>{let e=[];return b&&e.push(`From ${b}`),S&&e.push(`To ${S}`),E&&e.push(`Status: ${E}`),w.trim()&&e.push(`Search: "${w.trim()}"`),e.length?e.join(` • `):`All logs`},[b,S,E,w]),V=()=>{if(!M.length)return _?.(`No rows on this page to export.`);let e=[`Date`,`Staff Name`,`Reg No`,`Email`,`Status`,`Check In`,`Check Out`,`Source`,`Device`,`Notes`],t=M.map(e=>{let t=`${e.staff?.firstname??``} ${e.staff?.surname??``}`.trim(),n=e=>`"${String(e??``).replaceAll(`"`,`""`)}"`;return[n(e.att_date),n(t),n(e.staff?.reg_no??``),n(e.staff?.email??``),n(e.status),n(e.check_in_at??``),n(e.check_out_at??``),n(e.source??``),n(e.device_id??``),n(e.notes??``)].join(`,`)}),n=[e.join(`,`),...t].join(`
`),r=new Blob([n],{type:`text/csv;charset=utf-8;`}),i=window.URL.createObjectURL(r),a=document.createElement(`a`);a.href=i,a.download=`staff_attendance_${b}_to_${S}_page_${I.current_page}.csv`,a.click(),window.URL.revokeObjectURL(i),g?.(`Export started`)},H=()=>{x(p()),C(f()),D(``),j(20),T(``),k(1),g?.(`Filters reset`),z(1)},U=(0,l.useMemo)(()=>({total:P.total,present:P.present,late:P.late,absent:P.absent,on_leave:P.on_leave}),[P]),W=(0,l.useMemo)(()=>[{label:`Present`,value:U.present,icon:`person-check`,top:`linear-gradient(135deg,#16a34a 0%,#22c55e 100%)`,hint:`Checked-in staff`},{label:`Absent`,value:U.absent,icon:`person-x`,top:`linear-gradient(135deg,#ef4444 0%,#f43f5e 100%)`,hint:`No check-in`},{label:`Late`,value:U.late,icon:`alarm`,top:`linear-gradient(135deg,#f59e0b 0%,#fbbf24 100%)`,hint:`After cutoff time`},{label:`On Leave`,value:U.on_leave,icon:`calendar2-check`,top:`linear-gradient(135deg,#3b82f6 0%,#60a5fa 100%)`,hint:`Approved leave`}],[U]);return(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)(`style`,{children:`
    /* ======= StaffAttendanceLogsPage - Modern SaaS style ======= */
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');
    .db-main {
      background: #F8FAFC;
      min-height: 100vh;
      font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
      padding: 24px 28px 0;
    }
    @media (max-width: 991.98px) { .db-main { padding: 18px 14px 0; } }

    .db-hero {
      background: linear-gradient(135deg, #0A192F 0%, #0F2744 60%, #1E3A8A 100%);
      border-radius: 18px;
      padding: 32px 36px;
      position: relative;
      overflow: hidden;
      margin: 10px 0 24px;
      box-shadow: 0 10px 30px -5px rgba(15, 39, 68, 0.15);
    }
    .db-hero-glow {
      position: absolute;
      top: -60px;
      right: -60px;
      width: 320px;
      height: 320px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(217, 119, 6, 0.15) 0%, transparent 65%);
      pointer-events: none;
    }
    .db-hero-glow2 {
      position: absolute;
      bottom: -40px;
      left: 26%;
      width: 220px;
      height: 220px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(37, 99, 235, 0.10) 0%, transparent 70%);
      pointer-events: none;
    }
    .db-hero-inner {
      position: relative;
      z-index: 1;
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
      gap: 28px;
      flex-wrap: wrap;
    }

    .db-session-badge {
      display: inline-flex;
      align-items: center;
      gap: 7px;
      font-size: 11.5px;
      font-weight: 700;
      letter-spacing: 0.04em;
      text-transform: uppercase;
      color: #FBBF24;
      background: rgba(217, 119, 6, 0.20);
      border: 1px solid rgba(217, 119, 6, 0.35);
      border-radius: 100px;
      padding: 4px 12px;
      margin-bottom: 12px;
    }
    .db-session-dot {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: #10B981;
      animation: dbPulse 2s ease infinite;
    }
    @keyframes dbPulse {
      0%,100% { opacity: 1; transform: scale(1); }
      50% { opacity: 0.4; transform: scale(1.5); }
    }
    .db-greeting {
      font-size: 26px;
      font-weight: 800;
      color: #fff;
      line-height: 1.1;
      margin-bottom: 8px;
    }
    .db-greeting em { font-style: normal; color: #FBBF24; }

    .db-hero-sub {
      font-size: 13.5px;
      color: #CBD5E1;
      line-height: 1.6;
      max-width: 760px;
      margin-bottom: 20px;
    }
    .db-hero-btns { display: flex; gap: 10px; flex-wrap: wrap; }

    .db-btn-gold {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 9px 18px;
      font-size: 13px;
      font-weight: 700;
      color: #FFFFFF;
      background: #D97706;
      border: none;
      border-radius: 10px;
      cursor: pointer;
      transition: all 0.2s ease;
      white-space: nowrap;
    }
    .db-btn-gold:hover { background: #B45309; transform: translateY(-1px); color: #FFFFFF; }
    .db-btn-gold:disabled { opacity: 0.55; cursor: not-allowed; transform: none; }

    .db-btn-outline {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 9px 18px;
      font-size: 13px;
      font-weight: 600;
      color: #FFFFFF;
      background: rgba(255, 255, 255, 0.10);
      border: 1px solid rgba(255, 255, 255, 0.20);
      border-radius: 10px;
      cursor: pointer;
      transition: all 0.2s ease;
      white-space: nowrap;
    }
    .db-btn-outline:hover { background: rgba(255, 255, 255, 0.18); color: #fff; }
    .db-btn-outline:disabled { opacity: 0.55; cursor: not-allowed; }

    .db-hero-stat-card {
      background: rgba(255, 255, 255, 0.08);
      border: 1px solid rgba(255, 255, 255, 0.15);
      backdrop-filter: blur(8px);
      border-radius: 14px;
      padding: 18px 20px;
      min-width: 330px;
    }
    @media (max-width: 991.98px) { .db-hero { padding: 24px 20px; } .db-hero-stat-card { min-width: 0; width: 100%; } }
    .db-hero-stat-row { display: flex; flex-direction: column; gap: 10px; }
    .db-hero-stat-item { display: flex; justify-content: space-between; align-items: center; gap: 16px; }
    .db-hero-stat-label { font-size: 12px; font-weight: 300; color: #94a3b8; }
    .db-hero-stat-val {
      font-family: "Lora", serif;
      font-size: 18px;
      font-weight: 700;
      color: #fff;
    }
    .db-hero-stat-sep { height: 1px; background: rgba(255, 255, 255, 0.06); }

    .db-panel {
      background: #ffffff;
      border: 1px solid #ede8e0;
      border-radius: 14px;
      overflow: hidden;
      box-shadow: 0 2px 10px rgba(15,23,42,0.04);
    }
    .db-panel-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 16px 18px;
      border-bottom: 1px solid rgba(0, 0, 0, 0.06);
      gap: 12px;
      flex-wrap: wrap;
    }
    .db-panel-title {
      font-family: "Lora", serif;
      font-size: 16px;
      font-weight: 800;
      color: #1a1a2e;
      margin: 0;
    }
    .db-panel-sub { font-size: 11.5px; font-weight: 300; color: #9a8a7a; margin: 0; }

    .db-pill {
      display: inline-flex;
      align-items: center;
      font-size: 12px;
      font-weight: 800;
      padding: 6px 10px;
      border-radius: 999px;
      white-space: nowrap;
      border: 1px solid rgba(0,0,0,0.06);
    }

    .db-refresh-btn {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 8px 12px;
      font-size: 12px;
      font-weight: 600;
      color: #7a6a5a;
      background: #f5f1eb;
      border: 1px solid #e5ddd3;
      border-radius: 10px;
      cursor: pointer;
      transition: background 0.2s;
      white-space: nowrap;
    }
    .db-refresh-btn:hover { background: #ede8e0; }
    .db-refresh-btn:disabled { opacity: 0.55; cursor: not-allowed; }

    .db-grid2 { display: grid; grid-template-columns: 0.95fr 1.05fr; gap: 18px; margin: 16px 0 18px; }
    @media (max-width: 991.98px) { .db-grid2 { grid-template-columns: 1fr; } }

    .db-input {
      width: 100%;
      padding: 10px 12px;
      border-radius: 10px;
      border: 1px solid #e5ddd3;
      outline: none;
      font-size: 13px;
      background: #fff;
    }
    .db-input:focus { border-color: rgba(201,168,76,0.7); box-shadow: 0 0 0 3px rgba(201,168,76,0.18); }

    .db-table { width: 100%; border-collapse: collapse; }
    .db-table th {
      padding: 10px 14px;
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: #9a8a7a;
      background: #faf8f5;
      border-bottom: 1px solid rgba(0, 0, 0, 0.06);
      text-align: left;
      white-space: nowrap;
    }
    .db-table td {
      padding: 12px 14px;
      font-size: 13.5px;
      color: #4a4a5a;
      border-bottom: 1px solid rgba(0, 0, 0, 0.06);
      vertical-align: middle;
    }
    .db-table tbody tr:hover { background: #faf8f5; }

    .db-foot {
      padding: 12px 18px;
      display: flex;
      justify-content: space-between;
      gap: 12px;
      flex-wrap: wrap;
      border-top: 1px solid rgba(0,0,0,0.06);
      color: #9a8a7a;
      font-size: 12px;
    }

    .db-cardGrid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 14px; margin: 14px 0 8px; }
    @media (max-width: 991.98px) { .db-cardGrid { grid-template-columns: repeat(2, 1fr); } }
    @media (max-width: 575.98px) { .db-cardGrid { grid-template-columns: 1fr; } }

    .miniCard {
      background: #fff;
      border: 1px solid #ede8e0;
      border-radius: 14px;
      box-shadow: 0 2px 10px rgba(15,23,42,0.04);
      overflow: hidden;
    }
    .miniCardTop {
      height: 4px;
      background: linear-gradient(135deg, #c9a84c 0%, #e8c97a 100%);
    }
    .miniCardBody { padding: 14px 14px; display: grid; gap: 8px; }
    .miniCardLabel { font-size: 11px; color: #9a8a7a; font-weight: 700; letter-spacing: 0.1em; text-transform: uppercase; }
    .miniCardValue { font-family: "Lora", serif; font-size: 22px; font-weight: 900; color: #1a1a2e; line-height: 1.1; }
    .miniCardHint { font-size: 12px; color: #9a8a7a; }
    .miniCardIcon {
      width: 38px; height: 38px; border-radius: 12px;
      display: flex; align-items: center; justify-content: center;
      background: rgba(201,168,76,0.12);
      border: 1px solid rgba(201,168,76,0.18);
      color: #b45309;
    }

    .db-avatar {
      width: 34px; height: 34px; border-radius: 50%;
      background: #e2e8f0; overflow: hidden;
      display: flex; align-items: center; justify-content: center;
      border: 1px solid rgba(0,0,0,0.06);
      flex: 0 0 auto;
    }
    .db-avatar img { width: 100%; height: 100%; object-fit: cover; }
    .db-muted { color: #9a8a7a; }
    .db-strong { font-weight: 900; color: #1a1a2e; }
  `}),(0,u.jsx)(o,{sidebarOpen:e,setSidebarOpen:t}),(0,u.jsx)(n,{title:`Staff Attendance`}),(0,u.jsx)(`div`,{className:`container-fluid`,children:(0,u.jsxs)(`div`,{className:`row`,children:[(0,u.jsx)(a,{sidebarOpen:e}),(0,u.jsxs)(`main`,{className:`col-md-9 col-lg-10 ms-auto db-main`,children:[v&&(0,u.jsx)(r,{message:`Loading attendance logs...`}),(0,u.jsxs)(`div`,{className:`db-hero`,children:[(0,u.jsx)(`div`,{className:`db-hero-glow`,"aria-hidden":`true`}),(0,u.jsx)(`div`,{className:`db-hero-glow2`,"aria-hidden":`true`}),(0,u.jsxs)(`div`,{className:`db-hero-inner`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsxs)(`div`,{className:`db-session-badge`,children:[(0,u.jsx)(`span`,{className:`db-session-dot`}),`Attendance • Logs`]}),(0,u.jsxs)(`h1`,{className:`db-greeting`,children:[m(),`, `,(0,u.jsx)(`em`,{children:`Admin.`})]}),(0,u.jsxs)(`p`,{className:`db-hero-sub`,children:[`View, filter, and export staff attendance logs. Current filters: `,(0,u.jsx)(`b`,{children:B}),`.`]}),(0,u.jsxs)(`div`,{className:`db-hero-btns`,children:[(0,u.jsxs)(`button`,{className:`db-btn-gold`,onClick:()=>z(1),disabled:v,children:[(0,u.jsx)(`i`,{className:`bi bi-arrow-clockwise`}),`Refresh`]}),(0,u.jsxs)(`button`,{className:`db-btn-outline`,onClick:H,disabled:v,children:[(0,u.jsx)(`i`,{className:`bi bi-sliders`}),`Reset filters`]}),(0,u.jsxs)(`button`,{className:`db-btn-outline`,onClick:V,disabled:v||M.length===0,children:[(0,u.jsx)(`i`,{className:`bi bi-download`}),`Export CSV (page)`]})]})]}),(0,u.jsx)(`div`,{className:`db-hero-stat-card d-none d-md-block`,children:(0,u.jsxs)(`div`,{className:`db-hero-stat-row`,children:[(0,u.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,u.jsx)(`span`,{className:`db-hero-stat-label`,children:`Total`}),(0,u.jsx)(`span`,{className:`db-hero-stat-val`,children:U.total})]}),(0,u.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,u.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,u.jsx)(`span`,{className:`db-hero-stat-label`,children:`Present`}),(0,u.jsx)(`span`,{className:`db-hero-stat-val`,children:U.present})]}),(0,u.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,u.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,u.jsx)(`span`,{className:`db-hero-stat-label`,children:`Absent`}),(0,u.jsx)(`span`,{className:`db-hero-stat-val`,children:U.absent})]}),(0,u.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,u.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,u.jsx)(`span`,{className:`db-hero-stat-label`,children:`Late`}),(0,u.jsx)(`span`,{className:`db-hero-stat-val`,children:U.late})]}),(0,u.jsx)(`div`,{className:`db-hero-stat-sep`}),(0,u.jsxs)(`div`,{className:`db-hero-stat-item`,children:[(0,u.jsx)(`span`,{className:`db-hero-stat-label`,children:`On Leave`}),(0,u.jsx)(`span`,{className:`db-hero-stat-val`,children:U.on_leave})]})]})})]})]}),(0,u.jsx)(`div`,{className:`db-cardGrid`,children:W.map(e=>(0,u.jsxs)(`div`,{className:`miniCard`,children:[(0,u.jsx)(`div`,{className:`miniCardTop`,style:{background:e.top}}),(0,u.jsxs)(`div`,{className:`miniCardBody`,children:[(0,u.jsxs)(`div`,{style:{display:`flex`,justifyContent:`space-between`,alignItems:`start`,gap:12},children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`miniCardLabel`,children:e.label}),(0,u.jsx)(`div`,{className:`miniCardValue`,children:e.value})]}),(0,u.jsx)(`div`,{className:`miniCardIcon`,style:{background:`rgba(0,0,0,0.04)`,borderColor:`rgba(0,0,0,0.06)`,color:`#0f172a`},children:(0,u.jsx)(`i`,{className:`bi bi-${e.icon}`})})]}),(0,u.jsx)(`div`,{className:`miniCardHint`,children:e.hint})]})]},e.label))}),(0,u.jsxs)(`div`,{className:`db-panel`,style:{marginTop:14},children:[(0,u.jsxs)(`div`,{className:`db-panel-head`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`p`,{className:`db-panel-title`,children:`Attendance log table`}),(0,u.jsxs)(`p`,{className:`db-panel-sub`,children:[`Page `,(0,u.jsx)(`b`,{children:I.current_page}),` of `,(0,u.jsx)(`b`,{children:I.last_page}),` • Total `,(0,u.jsx)(`b`,{children:I.total})]})]}),(0,u.jsxs)(`div`,{style:{display:`flex`,gap:8,flexWrap:`wrap`},children:[(0,u.jsxs)(`button`,{className:`db-refresh-btn`,onClick:()=>z(1),disabled:v,children:[(0,u.jsx)(`i`,{className:`bi bi-arrow-clockwise`}),` Refresh`]}),(0,u.jsxs)(`button`,{className:`db-refresh-btn`,onClick:V,disabled:v||M.length===0,children:[(0,u.jsx)(`i`,{className:`bi bi-download`}),` Export (page)`]})]})]}),(0,u.jsxs)(`div`,{style:{padding:16},children:[(0,u.jsxs)(`div`,{className:`db-grid2`,style:{gridTemplateColumns:`1fr 1fr`,margin:0},children:[(0,u.jsxs)(`div`,{className:`db-panel`,style:{borderRadius:14},children:[(0,u.jsxs)(`div`,{className:`db-panel-head`,children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`p`,{className:`db-panel-title`,style:{fontSize:14},children:`Filters`}),(0,u.jsx)(`p`,{className:`db-panel-sub`,children:`Date range, status, search, and page size`})]}),(0,u.jsxs)(`button`,{className:`db-refresh-btn`,onClick:H,disabled:v,children:[(0,u.jsx)(`i`,{className:`bi bi-sliders`}),` Reset`]})]}),(0,u.jsxs)(`div`,{style:{padding:14,display:`grid`,gap:10},children:[(0,u.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`1fr 1fr`,gap:10},children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`miniCardLabel`,style:{marginBottom:6},children:`From`}),(0,u.jsx)(`input`,{type:`date`,className:`db-input`,value:b,onChange:e=>x(e.target.value),disabled:v})]}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`miniCardLabel`,style:{marginBottom:6},children:`To`}),(0,u.jsx)(`input`,{type:`date`,className:`db-input`,value:S,onChange:e=>C(e.target.value),disabled:v})]})]}),(0,u.jsxs)(`div`,{style:{display:`grid`,gridTemplateColumns:`1fr 1fr`,gap:10},children:[(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`miniCardLabel`,style:{marginBottom:6},children:`Status`}),(0,u.jsxs)(`select`,{className:`db-input`,value:E,onChange:e=>D(e.target.value),disabled:v,children:[(0,u.jsx)(`option`,{value:``,children:`All`}),(0,u.jsx)(`option`,{value:`present`,children:`Present`}),(0,u.jsx)(`option`,{value:`late`,children:`Late`}),(0,u.jsx)(`option`,{value:`absent`,children:`Absent`}),(0,u.jsx)(`option`,{value:`on_leave`,children:`On Leave`})]})]}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`miniCardLabel`,style:{marginBottom:6},children:`Per page`}),(0,u.jsx)(`select`,{className:`db-input`,value:A,onChange:e=>j(Number(e.target.value)),disabled:v,children:[10,20,30,50,100].map(e=>(0,u.jsx)(`option`,{value:e,children:e},e))})]})]}),(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`div`,{className:`miniCardLabel`,style:{marginBottom:6},children:`Search`}),(0,u.jsxs)(`div`,{style:{display:`flex`,gap:10,flexWrap:`wrap`,alignItems:`center`},children:[(0,u.jsx)(`input`,{className:`db-input`,style:{flex:1,minWidth:240},placeholder:`Search name, reg no, email...`,value:w,onChange:e=>T(e.target.value),onKeyDown:e=>{e.key===`Enter`&&z(1)},disabled:v}),(0,u.jsxs)(`button`,{className:`db-btn-gold`,onClick:()=>z(1),disabled:v,children:[(0,u.jsx)(`i`,{className:`bi bi-search`}),` Search`]})]}),(0,u.jsx)(`div`,{style:{marginTop:8,fontSize:12,color:`#9a8a7a`},children:`Search doesn’t auto-run on typing. Press Enter or click Search.`})]})]})]}),(0,u.jsxs)(`div`,{className:`db-panel`,style:{borderRadius:14},children:[(0,u.jsx)(`div`,{className:`db-panel-head`,children:(0,u.jsxs)(`div`,{children:[(0,u.jsx)(`p`,{className:`db-panel-title`,style:{fontSize:14},children:`Pagination`}),(0,u.jsx)(`p`,{className:`db-panel-sub`,children:`Navigate pages`})]})}),(0,u.jsxs)(`div`,{style:{padding:14,display:`grid`,gap:10},children:[(0,u.jsxs)(`div`,{style:{display:`flex`,gap:10,flexWrap:`wrap`},children:[(0,u.jsxs)(`button`,{className:`db-refresh-btn`,disabled:v||I.current_page<=1,onClick:()=>{let e=Math.max(1,I.current_page-1);k(e),z(e)},children:[(0,u.jsx)(`i`,{className:`bi bi-chevron-left`}),` Prev`]}),(0,u.jsxs)(`button`,{className:`db-refresh-btn`,disabled:!0,children:[`Page `,I.current_page,` / `,I.last_page]}),(0,u.jsxs)(`button`,{className:`db-refresh-btn`,disabled:v||I.current_page>=I.last_page,onClick:()=>{let e=Math.min(I.last_page,I.current_page+1);k(e),z(e)},children:[`Next `,(0,u.jsx)(`i`,{className:`bi bi-chevron-right`})]})]}),(0,u.jsxs)(`div`,{style:{fontSize:12,color:`#9a8a7a`,lineHeight:1.6},children:[`Export downloads only the `,(0,u.jsx)(`b`,{children:`current page`}),`. Use filters + pagination to export multiple pages.`]})]})]})]}),(0,u.jsx)(`div`,{style:{marginTop:14,overflow:`auto`,borderRadius:14,border:`1px solid rgba(0,0,0,0.06)`},children:(0,u.jsxs)(`table`,{className:`db-table`,children:[(0,u.jsx)(`thead`,{children:(0,u.jsxs)(`tr`,{children:[(0,u.jsx)(`th`,{children:`Date`}),(0,u.jsx)(`th`,{children:`Staff`}),(0,u.jsx)(`th`,{children:`Reg No`}),(0,u.jsx)(`th`,{children:`Status`}),(0,u.jsx)(`th`,{children:`Check In`}),(0,u.jsx)(`th`,{children:`Check Out`}),(0,u.jsx)(`th`,{children:`Source`}),(0,u.jsx)(`th`,{children:`Device`}),(0,u.jsx)(`th`,{children:`Notes`})]})}),(0,u.jsx)(`tbody`,{children:M.length?M.map(e=>{let t=`${e.staff?.firstname??``} ${e.staff?.surname??``}`.trim(),n=R(e.status);return(0,u.jsxs)(`tr`,{children:[(0,u.jsx)(`td`,{style:{whiteSpace:`nowrap`},children:(0,u.jsx)(`span`,{className:`db-strong`,children:e.att_date})}),(0,u.jsx)(`td`,{style:{minWidth:240},children:(0,u.jsxs)(`div`,{style:{display:`flex`,gap:10,alignItems:`center`},children:[(0,u.jsx)(`div`,{className:`db-avatar`,children:e.staff?.photo?(0,u.jsx)(`img`,{src:e.staff.photo,alt:`staff`}):(0,u.jsx)(`i`,{className:`bi bi-person-fill`,style:{color:`#64748b`}})}),(0,u.jsxs)(`div`,{style:{minWidth:0},children:[(0,u.jsx)(`div`,{className:`db-strong`,style:{fontSize:13.5},children:t||`—`}),(0,u.jsx)(`div`,{className:`db-muted`,style:{fontSize:12},children:e.staff?.email||`—`})]})]})}),(0,u.jsx)(`td`,{style:{whiteSpace:`nowrap`},className:`db-muted`,children:e.staff?.reg_no||`—`}),(0,u.jsx)(`td`,{children:(0,u.jsx)(`span`,{className:`db-pill`,style:{background:n.bg,color:n.fg},children:n.label})}),(0,u.jsx)(`td`,{className:`db-muted`,style:{whiteSpace:`nowrap`},children:d(e.check_in_at)}),(0,u.jsx)(`td`,{className:`db-muted`,style:{whiteSpace:`nowrap`},children:d(e.check_out_at)}),(0,u.jsx)(`td`,{className:`db-muted`,style:{whiteSpace:`nowrap`},children:e.source?(0,u.jsx)(`span`,{className:`db-pill`,style:{background:`rgba(100,116,139,0.10)`,color:`#334155`},children:e.source}):`—`}),(0,u.jsx)(`td`,{className:`db-muted`,style:{whiteSpace:`nowrap`},children:e.device_id||`—`}),(0,u.jsx)(`td`,{className:`db-muted`,style:{maxWidth:320},children:e.notes||`—`})]},e.id)}):(0,u.jsx)(`tr`,{children:(0,u.jsx)(`td`,{colSpan:9,style:{padding:18,color:`#9a8a7a`,textAlign:`center`},children:`No attendance logs found for the selected filters.`})})})]})}),(0,u.jsxs)(`div`,{className:`db-foot`,style:{marginTop:12},children:[(0,u.jsxs)(`div`,{children:[`Showing page `,(0,u.jsx)(`b`,{children:I.current_page}),` of `,(0,u.jsx)(`b`,{children:I.last_page})]}),(0,u.jsx)(`div`,{children:`Tip: Narrow date range for faster queries.`})]})]})]}),(0,u.jsx)(`div`,{className:`mt-auto`,children:(0,u.jsx)(c,{})})]})]})})]})}export{h as default};